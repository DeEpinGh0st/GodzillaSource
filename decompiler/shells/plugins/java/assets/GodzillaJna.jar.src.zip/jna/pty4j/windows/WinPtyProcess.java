package jna.pty4j.windows;

import com.sun.jna.platform.win32.Advapi32Util;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jna.pty4j.PtyProcess;
import jna.pty4j.PtyProcessOptions;
import jna.pty4j.WinSize;

public class WinPtyProcess
  extends PtyProcess {
  private WinPty myWinPty;
  private InputStream myInputStream;
  private InputStream myErrorStream;
  private WinPTYOutputStream myOutputStream;
  
  @Deprecated
  public WinPtyProcess(String[] command, String[] environment, String workingDirectory, boolean consoleMode) throws IOException {
    this(command, convertEnvironment(environment), workingDirectory, consoleMode);
  }
  private List<String> myCommand; private boolean myUsedInputStream = false; private boolean myUsedOutputStream = false; private boolean myUsedErrorStream = false;
  private static String convertEnvironment(String[] environment) {
    StringBuilder envString = new StringBuilder();
    for (String s : environment) {
      envString.append(s).append(false);
    }
    envString.append(false);
    return envString.toString();
  }
  
  @Deprecated
  public WinPtyProcess(String[] command, String environment, String workingDirectory, boolean consoleMode) throws IOException {
    this(command, environment, workingDirectory, null, null, consoleMode, false);
  }
  
  public WinPtyProcess(String commandLine) throws IOException {
    try {
      HashMap<String, String> envMap = new HashMap<String, String>(System.getenv());
      envMap.put("TERM", "xterm");
      this
        .myWinPty = new WinPty(commandLine, null, convertEnvironment(envMap), false, Integer.valueOf(200), Integer.valueOf(100), true);
    } catch (WinPtyException e) {
      throw new IOException("Couldn't create PTY", e);
    } 
    this.myInputStream = new WinPTYInputStream(this.myWinPty, this.myWinPty.getInputPipe());
    this.myOutputStream = new WinPTYOutputStream(this.myWinPty, this.myWinPty.getOutputPipe(), true, true);
    this.myErrorStream = new WinPTYInputStream(this.myWinPty, this.myWinPty.getErrorPipe());
    
    PipedOutputStream out = new PipedOutputStream();
    PipedInputStream in = new PipedInputStream(out);
    
    (new RedirectStream(out, this.myInputStream)).start();
    (new RedirectStream(out, this.myErrorStream)).start();
    
    this.myInputStream = in;
    this.myErrorStream = in;
  }

  
  public WinPtyProcess(PtyProcessOptions options, boolean consoleMode) throws IOException {
    this(options.getCommand(), 
        convertEnvironment(options.getEnvironment()), options
        .getDirectory(), options
        .getInitialColumns(), options
        .getInitialRows(), consoleMode, options
        
        .isWindowsAnsiColorEnabled());
  }

  
  private static String convertEnvironment(Map<String, String> environment) {
    return Advapi32Util.getEnvironmentBlock((environment != null) ? environment : Collections.emptyMap());
  }






  
  private WinPtyProcess(String[] command, String environment, String workingDirectory, Integer initialColumns, Integer initialRows, boolean consoleMode, boolean enableAnsiColor) throws IOException {
    this.myCommand = Arrays.asList(command);
    try {
      this.myWinPty = new WinPty(joinCmdArgs(command), workingDirectory, environment, consoleMode, initialColumns, initialRows, enableAnsiColor);
    }
    catch (WinPtyException e) {
      throw new IOException("Couldn't create PTY", e);
    } 
    this.myInputStream = new WinPTYInputStream(this.myWinPty, this.myWinPty.getInputPipe());
    this.myOutputStream = new WinPTYOutputStream(this.myWinPty, this.myWinPty.getOutputPipe(), consoleMode, true);
    if (!consoleMode) {
      this.myErrorStream = new InputStream()
        {
          public int read() {
            return -1;
          }
        };
    } else {
      this.myErrorStream = new WinPTYInputStream(this.myWinPty, this.myWinPty.getErrorPipe());
    } 
  }
  
  static String joinCmdArgs(String[] commands) {
    StringBuilder cmd = new StringBuilder();
    boolean flag = false;
    for (String s : commands) {
      if (flag) {
        cmd.append(' ');
      } else {
        flag = true;
      } 
      
      if (s.indexOf(' ') >= 0 || s.indexOf('\t') >= 0) {
        if (s.charAt(0) != '"') {
          cmd.append('"').append(s);
          
          if (s.endsWith("\\")) {
            cmd.append("\\");
          }
          cmd.append('"');
        } else {
          cmd.append(s);
        } 
      } else {
        cmd.append(s);
      } 
    } 
    
    return cmd.toString();
  }
  
  public List<String> getCommand() {
    return this.myCommand;
  }

  
  public boolean isRunning() {
    return this.myWinPty.isRunning();
  }

  
  public void setWinSize(WinSize winSize) {
    try {
      this.myWinPty.setWinSize(winSize);
    }
    catch (IOException e) {
      throw new IllegalStateException(e);
    } 
  }

  
  public WinSize getWinSize() throws IOException {
    return this.myWinPty.getWinSize();
  }

  
  public int getPid() {
    return this.myWinPty.getChildProcessId();
  }

  
  public String getWorkingDirectory() throws IOException {
    return this.myWinPty.getWorkingDirectory();
  }





  
  public int getConsoleProcessCount() throws IOException {
    return this.myWinPty.getConsoleProcessList();
  }

  
  public synchronized OutputStream getOutputStream() {
    this.myUsedOutputStream = true;
    return this.myOutputStream;
  }

  
  public synchronized InputStream getInputStream() {
    this.myUsedInputStream = true;
    return this.myInputStream;
  }

  
  public synchronized InputStream getErrorStream() {
    this.myUsedErrorStream = true;
    return this.myErrorStream;
  }

  
  public int waitFor() throws InterruptedException {
    return this.myWinPty.waitFor();
  }
  
  public int getChildProcessId() {
    return this.myWinPty.getChildProcessId();
  }

  
  public int exitValue() {
    return this.myWinPty.exitValue();
  }

  
  public synchronized void destroy() {
    this.myWinPty.close();

    
    if (!this.myUsedInputStream) {
      try {
        this.myInputStream.close();
      } catch (IOException iOException) {}
    }
    if (!this.myUsedOutputStream) {
      try {
        this.myOutputStream.close();
      } catch (IOException iOException) {}
    }
    if (!this.myUsedErrorStream)
      try {
        this.myErrorStream.close();
      } catch (IOException iOException) {} 
  }
  
  class RedirectStream extends Thread {
    private OutputStream out;
    private InputStream in;
    
    public RedirectStream(OutputStream outputStream, InputStream inputStream) {
      this.out = outputStream;
      this.in = inputStream;
    }
    public void dup() {
      if (this.out != null && this.in != null) {
        byte[] buffer = new byte[521];
        int readNum = 0;
        try {
          while ((readNum = this.in.read(buffer)) > -1) {
            this.out.write(buffer, 0, readNum);
            this.out.flush();
          } 
        } catch (Exception exception) {}
      } 
    }



    
    public void run() {
      dup();
    }
  }
}
