package jna.pty4j.windows;

public class WinPtyException
  extends Exception {
  WinPtyException(String message) {
    super(message);
  }
}
