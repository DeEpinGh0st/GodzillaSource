package jna.pty4j.windows;

import java.io.IOException;
import java.io.InputStream;







public class WinPTYInputStream
  extends InputStream
{
  private final WinPty myWinPty;
  private final NamedPipe myNamedPipe;
  
  public WinPTYInputStream(WinPty winPty, NamedPipe namedPipe) {
    this.myWinPty = winPty;
    this.myNamedPipe = namedPipe;
  }






  
  public int read() throws IOException {
    byte[] b = new byte[1];
    if (1 != read(b, 0, 1)) {
      return -1;
    }
    return b[0];
  }

  
  public int read(byte[] buf, int off, int len) throws IOException {
    return this.myNamedPipe.read(buf, off, len);
  }










  
  public void close() throws IOException {
    this.myWinPty.decrementOpenInputStreamCount();
    this.myNamedPipe.close();
  }

  
  public int available() throws IOException {
    return this.myNamedPipe.available();
  }
}
