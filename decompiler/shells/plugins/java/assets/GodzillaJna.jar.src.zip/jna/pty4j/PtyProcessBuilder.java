package jna.pty4j;

import com.sun.jna.Platform;
import java.io.File;
import java.io.IOException;
import java.util.Map;
import jna.pty4j.windows.WinPtyProcess;


public class PtyProcessBuilder
{
  private String[] myCommand;
  private Map<String, String> myEnvironment;
  private String myDirectory;
  private boolean myConsole;
  private boolean myCygwin;
  private File myLogFile;
  private boolean myRedirectErrorStream = false;
  private Integer myInitialColumns;
  private Integer myInitialRows;
  private boolean myWindowsAnsiColorEnabled = false;
  private boolean myUnixOpenTtyToPreserveOutputAfterTermination = false;
  
  public PtyProcessBuilder() {}
  
  public PtyProcessBuilder(String[] command) {
    this.myCommand = command;
  }

  
  public PtyProcessBuilder setCommand(String[] command) {
    this.myCommand = command;
    return this;
  }

  
  public PtyProcessBuilder setEnvironment(Map<String, String> environment) {
    this.myEnvironment = environment;
    return this;
  }

  
  public PtyProcessBuilder setDirectory(String directory) {
    this.myDirectory = directory;
    return this;
  }

  
  public PtyProcessBuilder setConsole(boolean console) {
    this.myConsole = console;
    return this;
  }

  
  public PtyProcessBuilder setCygwin(boolean cygwin) {
    this.myCygwin = cygwin;
    return this;
  }

  
  public PtyProcessBuilder setLogFile(File logFile) {
    this.myLogFile = logFile;
    return this;
  }

  
  public PtyProcessBuilder setRedirectErrorStream(boolean redirectErrorStream) {
    this.myRedirectErrorStream = redirectErrorStream;
    return this;
  }

  
  public PtyProcessBuilder setInitialColumns(Integer initialColumns) {
    this.myInitialColumns = initialColumns;
    return this;
  }

  
  public PtyProcessBuilder setInitialRows(Integer initialRows) {
    this.myInitialRows = initialRows;
    return this;
  }

  
  public PtyProcessBuilder setWindowsAnsiColorEnabled(boolean windowsAnsiColorEnabled) {
    this.myWindowsAnsiColorEnabled = windowsAnsiColorEnabled;
    return this;
  }









  
  public PtyProcessBuilder setUnixOpenTtyToPreserveOutputAfterTermination(boolean unixOpenTtyToPreserveOutputAfterTermination) {
    this.myUnixOpenTtyToPreserveOutputAfterTermination = unixOpenTtyToPreserveOutputAfterTermination;
    return this;
  }

  
  public PtyProcess start() throws IOException {
    if (this.myEnvironment == null) {
      this.myEnvironment = System.getenv();
    }
    PtyProcessOptions options = new PtyProcessOptions(this.myCommand, this.myEnvironment, this.myDirectory, this.myRedirectErrorStream, this.myInitialColumns, this.myInitialRows, this.myWindowsAnsiColorEnabled, this.myUnixOpenTtyToPreserveOutputAfterTermination);






    
    if (Platform.isWindows()) {
      return (PtyProcess)new WinPtyProcess(options, this.myConsole);
    }
    return null;
  }
}
