package jna.pty4j.windows;

import com.sun.jna.Library;
import com.sun.jna.Memory;
import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.WString;
import com.sun.jna.platform.win32.Kernel32;
import com.sun.jna.platform.win32.WinBase;
import com.sun.jna.platform.win32.WinNT;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.PointerByReference;
import java.io.File;
import java.io.IOException;
import jna.pty4j.WinSize;





public class WinPty
{
  private static final boolean DEFAULT_MIN_INITIAL_TERMINAL_WINDOW_HEIGHT = !Boolean.getBoolean("disable.minimal.initial.terminal.window.height");
  
  private Pointer myWinpty;
  
  private WinNT.HANDLE myProcess;
  
  private NamedPipe myConinPipe;
  private NamedPipe myConoutPipe;
  private NamedPipe myConerrPipe;
  private boolean myChildExited = false;
  private int myStatus = -1;
  
  private boolean myClosed = false;
  private WinSize myLastWinSize;
  private int openInputStreamCount = 0;






  
  WinPty(String cmdline, String cwd, String env, boolean consoleMode, Integer initialColumns, Integer initialRows, boolean enableAnsiColor) throws WinPtyException, IOException {
    int cols = ((initialColumns != null) ? initialColumns : Integer.getInteger("win.pty.cols", 80)).intValue();
    int rows = getInitialRows(initialRows);
    IntByReference errCode = new IntByReference();
    PointerByReference errPtr = new PointerByReference(null);
    Pointer agentCfg = null;
    Pointer spawnCfg = null;
    Pointer winpty = null;
    WinNT.HANDLEByReference processHandle = new WinNT.HANDLEByReference();
    NamedPipe coninPipe = null;
    NamedPipe conoutPipe = null;
    NamedPipe conerrPipe = null;

    
    try {
      long agentFlags = 0L;
      if (consoleMode) {
        agentFlags = 3L;
        if (enableAnsiColor) {
          agentFlags |= 0x4L;
        }
      } 
      agentCfg = getINSTANCE().winpty_config_new(agentFlags, null);
      if (agentCfg == null) {
        throw new WinPtyException("winpty agent cfg is null");
      }
      getINSTANCE().winpty_config_set_initial_size(agentCfg, cols, rows);
      this.myLastWinSize = new WinSize(cols, rows);

      
      winpty = getINSTANCE().winpty_open(agentCfg, errPtr);
      if (winpty == null) {
        WString errMsg = getINSTANCE().winpty_error_msg(errPtr.getValue());
        String errorMessage = errMsg.toString();
        if ("ConnectNamedPipe failed: Windows error 232".equals(errorMessage)) {
          errorMessage = errorMessage + "\n" + suggestFixForError232();
        }
        throw new WinPtyException("Error starting winpty: " + errorMessage);
      } 

      
      coninPipe = NamedPipe.connectToServer(getINSTANCE().winpty_conin_name(winpty).toString(), 1073741824);
      conoutPipe = NamedPipe.connectToServer(getINSTANCE().winpty_conout_name(winpty).toString(), -2147483648);
      if (consoleMode) {
        conerrPipe = NamedPipe.connectToServer(getINSTANCE().winpty_conerr_name(winpty).toString(), -2147483648);
      }
      
      for (int i = 0; i < 5; i++) {
        boolean result = getINSTANCE().winpty_set_size(winpty, cols, rows, null);
        if (!result) {
          break;
        }
        try {
          Thread.sleep(10L);
        }
        catch (InterruptedException e) {
          e.printStackTrace();
        } 
      } 

      
      spawnCfg = getINSTANCE().winpty_spawn_config_new(3L, null, 


          
          toWString(cmdline), 
          toWString(cwd), 
          toWString(env), null);
      
      if (spawnCfg == null) {
        throw new WinPtyException("winpty spawn cfg is null");
      }
      if (!getINSTANCE().winpty_spawn(winpty, spawnCfg, processHandle, null, errCode, errPtr)) {
        WString errMsg = getINSTANCE().winpty_error_msg(errPtr.getValue());
        throw new WinPtyException("Error running process: " + errMsg.toString() + ". Code " + errCode.getValue());
      } 


      
      this.myWinpty = winpty;
      this.myProcess = processHandle.getValue();
      this.myConinPipe = coninPipe;
      this.myConoutPipe = conoutPipe;
      this.myConerrPipe = conerrPipe;
      this.openInputStreamCount = consoleMode ? 2 : 1;

      
      Thread waitForExit = new WaitForExitThread();
      waitForExit.setDaemon(true);
      waitForExit.start();
      
      winpty = null;
      processHandle.setValue(null);
      coninPipe = conoutPipe = conerrPipe = null;
    } finally {
      
      getINSTANCE().winpty_error_free(errPtr.getValue());
      getINSTANCE().winpty_config_free(agentCfg);
      getINSTANCE().winpty_spawn_config_free(spawnCfg);
      getINSTANCE().winpty_free(winpty);
      if (processHandle.getValue() != null) {
        Kernel32.INSTANCE.CloseHandle(processHandle.getValue());
      }
      closeNamedPipeQuietly(coninPipe);
      closeNamedPipeQuietly(conoutPipe);
      closeNamedPipeQuietly(conerrPipe);
    } 
  }

  
  private static String suggestFixForError232() {
    try {
      File dllFile = new File(getLibraryPath());
      File exeFile = new File(dllFile.getParentFile(), "winpty-agent.exe");
      return "This error can occur due to antivirus blocking winpty from creating a pty. Please exclude the following files in your antivirus:\n - " + exeFile
        .getAbsolutePath() + "\n - " + dllFile
        .getAbsolutePath();
    }
    catch (Exception e) {
      return e.getMessage();
    } 
  }
  
  private int getInitialRows(Integer initialRows) {
    if (initialRows != null) {
      return initialRows.intValue();
    }
    Integer rows = Integer.getInteger("win.pty.rows");
    if (rows != null) {
      return rows.intValue();
    }
    
    try {
      return DEFAULT_MIN_INITIAL_TERMINAL_WINDOW_HEIGHT ? 1 : 25;
    }
    catch (Exception e) {
      e.printStackTrace();
      return 25;
    } 
  }
  
  private static void closeNamedPipeQuietly(NamedPipe pipe) {
    try {
      if (pipe != null) {
        pipe.close();
      }
    } catch (IOException iOException) {}
  }

  
  private static WString toWString(String string) {
    return (string == null) ? null : new WString(string);
  }
  
  synchronized void setWinSize(WinSize winSize) throws IOException {
    if (this.myClosed) {
      throw new IOException("Unable to set window size: closed=" + this.myClosed + ", winSize=" + winSize);
    }
    boolean result = getINSTANCE().winpty_set_size(this.myWinpty, winSize.getColumns(), winSize.getRows(), null);
    if (result) {
      this.myLastWinSize = new WinSize(winSize.getColumns(), winSize.getRows());
    }
  }

  
  synchronized WinSize getWinSize() throws IOException {
    WinSize lastWinSize = this.myLastWinSize;
    if (this.myClosed || lastWinSize == null) {
      throw new IOException("Unable to get window size: closed=" + this.myClosed + ", lastWinSize=" + lastWinSize);
    }
    return new WinSize(lastWinSize.getColumns(), lastWinSize.getRows());
  }
  
  synchronized void decrementOpenInputStreamCount() {
    this.openInputStreamCount--;
    if (this.openInputStreamCount == 0) {
      close();
    }
  }







  
  synchronized void close() {
    if (this.myClosed) {
      return;
    }
    getINSTANCE().winpty_free(this.myWinpty);
    this.myWinpty = null;
    this.myClosed = true;
    closeUnusedProcessHandle();
  }







  
  private synchronized void closeUnusedProcessHandle() {
    if (this.myClosed && this.myChildExited && this.myProcess != null) {
      Kernel32.INSTANCE.CloseHandle(this.myProcess);
      this.myProcess = null;
    } 
  }



  
  synchronized boolean isRunning() {
    return !this.myChildExited;
  }

  
  synchronized int waitFor() throws InterruptedException {
    while (!this.myChildExited) {
      wait();
    }
    return this.myStatus;
  }
  
  synchronized int getChildProcessId() {
    if (this.myClosed) {
      return -1;
    }
    return Kernel32.INSTANCE.GetProcessId(this.myProcess);
  }
  
  synchronized int exitValue() {
    if (!this.myChildExited) {
      throw new IllegalThreadStateException("Process not Terminated");
    }
    return this.myStatus;
  }

  
  protected void finalize() throws Throwable {
    close();
    super.finalize();
  }
  
  NamedPipe getInputPipe() {
    return this.myConoutPipe;
  }
  
  NamedPipe getOutputPipe() {
    return this.myConinPipe;
  }
  
  NamedPipe getErrorPipe() {
    return this.myConerrPipe;
  }

  
  String getWorkingDirectory() throws IOException {
    if (this.myClosed) {
      return null;
    }
    int bufferLength = 1024;
    Memory memory = new Memory((Native.WCHAR_SIZE * bufferLength));
    PointerByReference errPtr = new PointerByReference();
    try {
      int result = getINSTANCE().winpty_get_current_directory(this.myWinpty, bufferLength, (Pointer)memory, errPtr);
      if (result > 0) {
        return memory.getWideString(0L);
      }
      WString message = getINSTANCE().winpty_error_msg(errPtr.getValue());
      int code = getINSTANCE().winpty_error_code(errPtr.getValue());
      throw new IOException("winpty_get_current_directory failed, code: " + code + ", message: " + message);
    } finally {
      
      getINSTANCE().winpty_error_free(errPtr.getValue());
    } 
  } private static interface WinPtyLib extends Library {
    public static final long WINPTY_FLAG_CONERR = 1L; public static final long WINPTY_FLAG_PLAIN_OUTPUT = 2L; public static final long WINPTY_FLAG_COLOR_ESCAPES = 4L; public static final long WINPTY_SPAWN_FLAG_AUTO_SHUTDOWN = 1L; public static final long WINPTY_SPAWN_FLAG_EXIT_AFTER_SHUTDOWN = 2L; int winpty_error_code(Pointer param1Pointer); WString winpty_error_msg(Pointer param1Pointer); void winpty_error_free(Pointer param1Pointer); Pointer winpty_config_new(long param1Long, PointerByReference param1PointerByReference); void winpty_config_free(Pointer param1Pointer); void winpty_config_set_initial_size(Pointer param1Pointer, int param1Int1, int param1Int2); Pointer winpty_open(Pointer param1Pointer, PointerByReference param1PointerByReference); WString winpty_conin_name(Pointer param1Pointer); WString winpty_conout_name(Pointer param1Pointer); WString winpty_conerr_name(Pointer param1Pointer); Pointer winpty_spawn_config_new(long param1Long, WString param1WString1, WString param1WString2, WString param1WString3, WString param1WString4, PointerByReference param1PointerByReference); void winpty_spawn_config_free(Pointer param1Pointer); boolean winpty_spawn(Pointer param1Pointer1, Pointer param1Pointer2, WinNT.HANDLEByReference param1HANDLEByReference1, WinNT.HANDLEByReference param1HANDLEByReference2, IntByReference param1IntByReference, PointerByReference param1PointerByReference); boolean winpty_set_size(Pointer param1Pointer, int param1Int1, int param1Int2, PointerByReference param1PointerByReference); int winpty_get_console_process_list(Pointer param1Pointer1, Pointer param1Pointer2, int param1Int, PointerByReference param1PointerByReference); int winpty_get_current_directory(Pointer param1Pointer1, int param1Int, Pointer param1Pointer2, PointerByReference param1PointerByReference); void winpty_free(Pointer param1Pointer); }
  int getConsoleProcessList() throws IOException {
    if (this.myClosed) {
      return 0;
    }
    int MAX_COUNT = 64;
    Memory memory = new Memory((Native.LONG_SIZE * MAX_COUNT));
    PointerByReference errPtr = new PointerByReference();
    try {
      int actualProcessCount = getINSTANCE().winpty_get_console_process_list(this.myWinpty, (Pointer)memory, MAX_COUNT, errPtr);
      if (actualProcessCount == 0) {
        WString message = getINSTANCE().winpty_error_msg(errPtr.getValue());
        int code = getINSTANCE().winpty_error_code(errPtr.getValue());
        throw new IOException("winpty_get_console_process_list failed, code: " + code + ", message: " + message);
      } 
      
      return actualProcessCount;
    } finally {
      
      getINSTANCE().winpty_error_free(errPtr.getValue());
    } 
  } static interface Kern32 extends Library {
    boolean PeekNamedPipe(WinNT.HANDLE param1HANDLE, Pointer param1Pointer, int param1Int, IntByReference param1IntByReference1, IntByReference param1IntByReference2, IntByReference param1IntByReference3); boolean ReadFile(WinNT.HANDLE param1HANDLE, Pointer param1Pointer1, int param1Int, IntByReference param1IntByReference, Pointer param1Pointer2); boolean WriteFile(WinNT.HANDLE param1HANDLE, Pointer param1Pointer1, int param1Int, IntByReference param1IntByReference, Pointer param1Pointer2); boolean GetOverlappedResult(WinNT.HANDLE param1HANDLE, Pointer param1Pointer, IntByReference param1IntByReference, boolean param1Boolean);
    WinNT.HANDLE CreateNamedPipeA(String param1String, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, WinBase.SECURITY_ATTRIBUTES param1SECURITY_ATTRIBUTES);
    boolean ConnectNamedPipe(WinNT.HANDLE param1HANDLE, WinBase.OVERLAPPED param1OVERLAPPED);
    boolean CloseHandle(WinNT.HANDLE param1HANDLE);
    WinNT.HANDLE CreateEventA(WinBase.SECURITY_ATTRIBUTES param1SECURITY_ATTRIBUTES, boolean param1Boolean1, boolean param1Boolean2, String param1String);
    int GetLastError();
    int WaitForSingleObject(WinNT.HANDLE param1HANDLE, int param1Int);
    boolean CancelIo(WinNT.HANDLE param1HANDLE);
    int GetCurrentProcessId(); }
  private class WaitForExitThread extends Thread { private IntByReference myStatusByRef = new IntByReference(-1);

    
    public void run() {
      Kernel32.INSTANCE.WaitForSingleObject(WinPty.this.myProcess, -1);
      Kernel32.INSTANCE.GetExitCodeProcess(WinPty.this.myProcess, this.myStatusByRef);
      synchronized (WinPty.this) {
        WinPty.this.myChildExited = true;
        WinPty.this.myStatus = this.myStatusByRef.getValue();
        WinPty.this.closeUnusedProcessHandle();
        WinPty.this.notifyAll();
      } 
    }
    
    private WaitForExitThread() {} }
  static final Kern32 KERNEL32 = (Kern32)Native.loadLibrary("kernel32", Kern32.class);






































  
  private static WinPtyLib INSTANCE = null;
  private static Object INSTANCE_LOCK = new Object();
  
  private static WinPtyLib getINSTANCE() {
    synchronized (INSTANCE_LOCK) {
      if (INSTANCE == null) {
        INSTANCE = (WinPtyLib)Native.loadLibrary(getLibraryPath(), WinPtyLib.class);
      }
      return INSTANCE;
    } 
  }
  private static String getLibraryPath() {
    try {
      String tmpdir = System.getProperty("java.io.tmpdir");
      char lastChar = tmpdir.charAt(tmpdir.length() - 1);
      if (lastChar != '\\' && lastChar != '/') {
        tmpdir = tmpdir + File.separator;
      }
      
      return String.format("%swinpty_x%s.dll", new Object[] { tmpdir, System.getProperty("sun.arch.data.model") });
    }
    catch (Exception e) {
      throw new IllegalStateException("Couldn't detect jar containing folder", e);
    } 
  }
}
