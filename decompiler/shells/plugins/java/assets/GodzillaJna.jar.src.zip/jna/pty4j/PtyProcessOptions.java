package jna.pty4j;

import java.util.Map;









public class PtyProcessOptions
{
  private final String[] myCommand;
  private final Map<String, String> myEnvironment;
  private final String myDirectory;
  private final boolean myRedirectErrorStream;
  private final Integer myInitialColumns;
  private final Integer myInitialRows;
  private final boolean myWindowsAnsiColorEnabled;
  private final boolean myUnixOpenTtyToPreserveOutputAfterTermination;
  
  PtyProcessOptions(String[] command, Map<String, String> environment, String directory, boolean redirectErrorStream, Integer initialColumns, Integer initialRows, boolean windowsAnsiColorEnabled, boolean unixOpenTtyToPreserveOutputAfterTermination) {
    this.myCommand = command;
    this.myEnvironment = environment;
    this.myDirectory = directory;
    this.myRedirectErrorStream = redirectErrorStream;
    this.myInitialColumns = initialColumns;
    this.myInitialRows = initialRows;
    this.myWindowsAnsiColorEnabled = windowsAnsiColorEnabled;
    this.myUnixOpenTtyToPreserveOutputAfterTermination = unixOpenTtyToPreserveOutputAfterTermination;
  }

  
  public String[] getCommand() {
    return this.myCommand;
  }

  
  public Map<String, String> getEnvironment() {
    return this.myEnvironment;
  }

  
  public String getDirectory() {
    return this.myDirectory;
  }
  
  public boolean isRedirectErrorStream() {
    return this.myRedirectErrorStream;
  }

  
  public Integer getInitialColumns() {
    return this.myInitialColumns;
  }

  
  public Integer getInitialRows() {
    return this.myInitialRows;
  }
  
  public boolean isWindowsAnsiColorEnabled() {
    return this.myWindowsAnsiColorEnabled;
  }
  
  public boolean isUnixOpenTtyToPreserveOutputAfterTermination() {
    return this.myUnixOpenTtyToPreserveOutputAfterTermination;
  }
}
