package jna.pty4j;












































public final class WinSize
{
  private final int myColumns;
  private final int myRows;
  @Deprecated
  public short ws_col;
  @Deprecated
  public short ws_row;
  @Deprecated
  public short ws_xpixel;
  @Deprecated
  public short ws_ypixel;
  
  public WinSize() {
    this(0, 0);
  }



  
  public WinSize(int columns, int rows) {
    this.myColumns = columns;
    this.myRows = rows;
    this.ws_col = (short)columns;
    this.ws_row = (short)rows;
  }



  
  @Deprecated
  public WinSize(int columns, int rows, int width, int height) {
    this(columns, rows);
  }
  
  public int getColumns() {
    return this.myColumns;
  }
  
  public int getRows() {
    return this.myRows;
  }

  
  public boolean equals(Object o) {
    if (this == o) return true; 
    if (o == null || getClass() != o.getClass()) return false; 
    WinSize winSize = (WinSize)o;
    return (this.myColumns == winSize.myColumns && this.myRows == winSize.myRows && this.ws_row == winSize.ws_row && this.ws_col == winSize.ws_col);
  }

  
  public int hashCode() {
    return super.hashCode();
  }

  
  public String toString() {
    return "columns=" + this.myColumns + ", rows=" + this.myRows + ", ws_col=" + this.ws_col + ", ws_row=" + this.ws_row;
  }
}
