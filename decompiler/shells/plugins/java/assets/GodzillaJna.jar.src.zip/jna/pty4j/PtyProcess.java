package jna.pty4j;

import com.sun.jna.Platform;
import java.io.File;
import java.io.IOException;
import java.util.Map;
import jna.pty4j.windows.WinPtyProcess;


















public abstract class PtyProcess
  extends Process
{
  public abstract boolean isRunning();
  
  public abstract void setWinSize(WinSize paramWinSize);
  
  public abstract WinSize getWinSize() throws IOException;
  
  public long pid() {
    return getPid();
  }


  
  public abstract int getPid();

  
  public byte getEnterKeyCode() {
    return 13;
  }
  
  public static PtyProcess exec(String[] command) throws IOException {
    return exec(command, (Map<String, String>)null);
  }
  
  public static PtyProcess exec(String[] command, Map<String, String> environment) throws IOException {
    return exec(command, environment, null, false, false, null);
  }
  
  public static PtyProcess exec(String[] command, Map<String, String> environment, String workingDirectory) throws IOException {
    return exec(command, environment, workingDirectory, false, false, null);
  }
  
  @Deprecated
  public static PtyProcess exec(String[] command, String[] environment) throws IOException {
    return exec(command, environment, (String)null, false);
  }
  
  @Deprecated
  public static PtyProcess exec(String[] command, String[] environment, String workingDirectory, boolean console) throws IOException {
    if (Platform.isWindows()) {
      return (PtyProcess)new WinPtyProcess(command, environment, workingDirectory, console);
    }
    return null;
  }

  
  public static PtyProcess exec(String[] command, Map<String, String> environment, String workingDirectory, boolean console) throws IOException {
    return exec(command, environment, workingDirectory, console, false, null);
  }






  
  public static PtyProcess exec(String[] command, Map<String, String> environment, String workingDirectory, boolean console, boolean cygwin, File logFile) throws IOException {
    PtyProcessBuilder builder = (new PtyProcessBuilder(command)).setEnvironment(environment).setDirectory(workingDirectory).setConsole(console).setCygwin(cygwin).setLogFile(logFile);
    return builder.start();
  }
}
