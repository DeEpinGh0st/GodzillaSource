package com.sun.jna.platform.win32.COM.tlb.imp;

import com.sun.jna.platform.win32.COM.TypeInfoUtil;
import com.sun.jna.platform.win32.COM.TypeLibUtil;
import com.sun.jna.platform.win32.OaIdl;































public class TlbPropertyGet
  extends TlbAbstractMethod
{
  public TlbPropertyGet(int count, int index, TypeLibUtil typeLibUtil, OaIdl.FUNCDESC funcDesc, TypeInfoUtil typeInfoUtil) {
    super(index, typeLibUtil, funcDesc, typeInfoUtil);
    
    this.methodName = "get" + getMethodName();
    
    replaceVariable("helpstring", this.docStr);
    replaceVariable("returntype", this.returnType);
    replaceVariable("methodname", this.methodName);
    replaceVariable("vtableid", String.valueOf(this.vtableId));
    replaceVariable("memberid", String.valueOf(this.memberid));
    replaceVariable("functionCount", String.valueOf(count));
  }






  
  protected String getClassTemplate() {
    return "com/sun/jna/platform/win32/COM/tlb/imp/TlbPropertyGet.template";
  }
}
