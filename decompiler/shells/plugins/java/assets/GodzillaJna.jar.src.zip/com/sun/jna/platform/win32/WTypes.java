package com.sun.jna.platform.win32;

import com.sun.jna.Memory;
import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.PointerType;
import com.sun.jna.Structure;

























public interface WTypes
{
  public static final int CLSCTX_INPROC_SERVER = 1;
  public static final int CLSCTX_INPROC_HANDLER = 2;
  public static final int CLSCTX_LOCAL_SERVER = 4;
  public static final int CLSCTX_INPROC_SERVER16 = 8;
  public static final int CLSCTX_REMOTE_SERVER = 16;
  public static final int CLSCTX_INPROC_HANDLER16 = 32;
  public static final int CLSCTX_RESERVED1 = 64;
  public static final int CLSCTX_RESERVED2 = 128;
  public static final int CLSCTX_RESERVED3 = 256;
  public static final int CLSCTX_RESERVED4 = 512;
  public static final int CLSCTX_NO_CODE_DOWNLOAD = 1024;
  public static final int CLSCTX_RESERVED5 = 2048;
  public static final int CLSCTX_NO_CUSTOM_MARSHAL = 4096;
  public static final int CLSCTX_ENABLE_CODE_DOWNLOAD = 8192;
  public static final int CLSCTX_NO_FAILURE_LOG = 16384;
  public static final int CLSCTX_DISABLE_AAA = 32768;
  public static final int CLSCTX_ENABLE_AAA = 65536;
  public static final int CLSCTX_FROM_DEFAULT_CONTEXT = 131072;
  public static final int CLSCTX_ACTIVATE_32_BIT_SERVER = 262144;
  public static final int CLSCTX_ACTIVATE_64_BIT_SERVER = 524288;
  public static final int CLSCTX_ENABLE_CLOAKING = 1048576;
  public static final int CLSCTX_APPCONTAINER = 4194304;
  public static final int CLSCTX_ACTIVATE_AAA_AS_IU = 8388608;
  public static final int CLSCTX_PS_DLL = -2147483648;
  public static final int CLSCTX_SERVER = 21;
  public static final int CLSCTX_ALL = 7;
  
  public static class BSTR
    extends PointerType
  {
    public static class ByReference
      extends BSTR
      implements Structure.ByReference {}
    
    public BSTR() {
      super((Pointer)new Memory(Pointer.SIZE));
    }
    
    public BSTR(Pointer pointer) {
      super(pointer);
    }
    
    public BSTR(String value) {
      super((Pointer)new Memory((value.length() + 1L) * Native.WCHAR_SIZE));
      setValue(value);
    }
    
    public void setValue(String value) {
      getPointer().setWideString(0L, value);
    }
    
    public String getValue() {
      Pointer pointer = getPointer();
      String str = null;
      if (pointer != null) {
        str = pointer.getWideString(0L);
      }
      return str;
    }

    
    public String toString() {
      return getValue();
    }
  }
  
  public static class BSTRByReference extends com.sun.jna.ptr.ByReference {
    public BSTRByReference() {
      super(Pointer.SIZE);
    }
    
    public BSTRByReference(WTypes.BSTR value) {
      this();
      setValue(value);
    }
    
    public void setValue(WTypes.BSTR value) {
      getPointer().setPointer(0L, value.getPointer());
    }
    
    public WTypes.BSTR getValue() {
      return new WTypes.BSTR(getPointer().getPointer(0L));
    }
    
    public String getString() {
      return getValue().getValue();
    }
  }
  
  public static class LPSTR
    extends PointerType {
    public static class ByReference
      extends WTypes.BSTR implements Structure.ByReference {}
    
    public LPSTR() {
      super(Pointer.NULL);
    }
    
    public LPSTR(Pointer pointer) {
      super(pointer);
    }
    
    public LPSTR(String value) {
      this();
      setValue(value);
    }
    
    public void setValue(String value) {
      getPointer().setWideString(0L, value);
    }
    
    public String getValue() {
      Pointer pointer = getPointer();
      String str = null;
      if (pointer != null) {
        str = pointer.getWideString(0L);
      }
      return str;
    }

    
    public String toString() {
      return getValue();
    }
  }
  
  public static class LPWSTR
    extends PointerType {
    public static class ByReference
      extends WTypes.BSTR implements Structure.ByReference {}
    
    public LPWSTR() {
      super(Pointer.NULL);
    }
    
    public LPWSTR(Pointer pointer) {
      super(pointer);
    }
    
    public LPWSTR(String value) {
      this();
      setValue(value);
    }
    
    public void setValue(String value) {
      getPointer().setWideString(0L, value);
    }
    
    public String getValue() {
      Pointer pointer = getPointer();
      String str = null;
      if (pointer != null) {
        str = pointer.getWideString(0L);
      }
      return str;
    }

    
    public String toString() {
      return getValue();
    }
  }
  
  public static class LPOLESTR
    extends PointerType {
    public static class ByReference
      extends WTypes.BSTR implements Structure.ByReference {}
    
    public LPOLESTR() {
      super(Pointer.NULL);
    }
    
    public LPOLESTR(Pointer pointer) {
      super(pointer);
    }
    
    public LPOLESTR(String value) {
      super((Pointer)new Memory((value.length() + 1L) * Native.WCHAR_SIZE));
      setValue(value);
    }
    
    public void setValue(String value) {
      getPointer().setWideString(0L, value);
    }
    
    public String getValue() {
      Pointer pointer = getPointer();
      String str = null;
      if (pointer != null) {
        str = pointer.getWideString(0L);
      }
      return str;
    }

    
    public String toString() {
      return getValue();
    }
  }
  
  public static class VARTYPE extends WinDef.USHORT {
    public VARTYPE() {
      this(0);
    }
    
    public VARTYPE(int value) {
      super(value);
    }
  }
}
