package com.sun.jna;

public interface AltCallingConvention {}
