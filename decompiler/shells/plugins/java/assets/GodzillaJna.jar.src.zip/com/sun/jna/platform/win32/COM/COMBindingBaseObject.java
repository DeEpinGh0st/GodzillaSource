package com.sun.jna.platform.win32.COM;

import com.sun.jna.WString;
import com.sun.jna.platform.win32.Guid;
import com.sun.jna.platform.win32.Kernel32;
import com.sun.jna.platform.win32.OaIdl;
import com.sun.jna.platform.win32.Ole32;
import com.sun.jna.platform.win32.OleAuto;
import com.sun.jna.platform.win32.Variant;
import com.sun.jna.platform.win32.WinDef;
import com.sun.jna.platform.win32.WinNT;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.PointerByReference;



























public class COMBindingBaseObject
  extends COMInvoker
{
  public static final WinDef.LCID LOCALE_USER_DEFAULT = Kernel32.INSTANCE.GetUserDefaultLCID();


  
  public static final WinDef.LCID LOCALE_SYSTEM_DEFAULT = Kernel32.INSTANCE.GetSystemDefaultLCID();


  
  private IUnknown iUnknown;

  
  private IDispatch iDispatch;

  
  private PointerByReference pDispatch = new PointerByReference();

  
  private PointerByReference pUnknown = new PointerByReference();

  
  public COMBindingBaseObject(IDispatch dispatch) {
    this.iDispatch = dispatch;
  }
  
  public COMBindingBaseObject(Guid.CLSID clsid, boolean useActiveInstance) {
    this(clsid, useActiveInstance, 21);
  }


  
  public COMBindingBaseObject(Guid.CLSID clsid, boolean useActiveInstance, int dwClsContext) {
    WinNT.HRESULT hr = Ole32.INSTANCE.CoInitialize(null);
    
    if (COMUtils.FAILED(hr)) {
      Ole32.INSTANCE.CoUninitialize();
      throw new COMException("CoInitialize() failed!");
    } 
    
    if (useActiveInstance) {
      hr = OleAuto.INSTANCE.GetActiveObject((Guid.GUID)clsid, null, this.pUnknown);
      
      if (COMUtils.SUCCEEDED(hr)) {
        this.iUnknown = new Unknown(this.pUnknown.getValue());
        hr = this.iUnknown.QueryInterface(IDispatch.IID_IDISPATCH, this.pDispatch);
      } else {
        
        hr = Ole32.INSTANCE.CoCreateInstance((Guid.GUID)clsid, null, dwClsContext, (Guid.GUID)IDispatch.IID_IDISPATCH, this.pDispatch);
      } 
    } else {
      
      hr = Ole32.INSTANCE.CoCreateInstance((Guid.GUID)clsid, null, dwClsContext, (Guid.GUID)IDispatch.IID_IDISPATCH, this.pDispatch);
    } 

    
    if (COMUtils.FAILED(hr)) {
      throw new COMException("COM object with CLSID " + clsid.toGuidString() + " not registered properly!");
    }

    
    this.iDispatch = new Dispatch(this.pDispatch.getValue());
  }


  
  public COMBindingBaseObject(String progId, boolean useActiveInstance, int dwClsContext) throws COMException {
    WinNT.HRESULT hr = Ole32.INSTANCE.CoInitialize(null);
    
    if (COMUtils.FAILED(hr)) {
      release();
      throw new COMException("CoInitialize() failed!");
    } 

    
    Guid.CLSID.ByReference clsid = new Guid.CLSID.ByReference();
    hr = Ole32.INSTANCE.CLSIDFromProgID(progId, clsid);
    
    if (COMUtils.FAILED(hr)) {
      Ole32.INSTANCE.CoUninitialize();
      throw new COMException("CLSIDFromProgID() failed!");
    } 
    
    if (useActiveInstance) {
      hr = OleAuto.INSTANCE.GetActiveObject((Guid.GUID)clsid, null, this.pUnknown);
      
      if (COMUtils.SUCCEEDED(hr)) {
        this.iUnknown = new Unknown(this.pUnknown.getValue());
        hr = this.iUnknown.QueryInterface(IDispatch.IID_IDISPATCH, this.pDispatch);
      } else {
        
        hr = Ole32.INSTANCE.CoCreateInstance((Guid.GUID)clsid, null, dwClsContext, (Guid.GUID)IDispatch.IID_IDISPATCH, this.pDispatch);
      } 
    } else {
      
      hr = Ole32.INSTANCE.CoCreateInstance((Guid.GUID)clsid, null, dwClsContext, (Guid.GUID)IDispatch.IID_IDISPATCH, this.pDispatch);
    } 

    
    if (COMUtils.FAILED(hr)) {
      throw new COMException("COM object with ProgID '" + progId + "' and CLSID " + clsid.toGuidString() + " not registered properly!");
    }


    
    this.iDispatch = new Dispatch(this.pDispatch.getValue());
  }

  
  public COMBindingBaseObject(String progId, boolean useActiveInstance) throws COMException {
    this(progId, useActiveInstance, 21);
  }





  
  public IDispatch getIDispatch() {
    return this.iDispatch;
  }





  
  public PointerByReference getIDispatchPointer() {
    return this.pDispatch;
  }





  
  public IUnknown getIUnknown() {
    return this.iUnknown;
  }





  
  public PointerByReference getIUnknownPointer() {
    return this.pUnknown;
  }



  
  public void release() {
    if (this.iDispatch != null) {
      this.iDispatch.Release();
    }
    Ole32.INSTANCE.CoUninitialize();
  }


  
  protected WinNT.HRESULT oleMethod(int nType, Variant.VARIANT.ByReference pvResult, IDispatch pDisp, String name, Variant.VARIANT[] pArgs) throws COMException {
    if (pDisp == null) {
      throw new COMException("pDisp (IDispatch) parameter is null!");
    }
    
    WString[] ptName = { new WString(name) };
    OaIdl.DISPIDByReference pdispID = new OaIdl.DISPIDByReference();

    
    WinNT.HRESULT hr = pDisp.GetIDsOfNames(Guid.IID_NULL, ptName, 1, LOCALE_USER_DEFAULT, pdispID);

    
    COMUtils.checkRC(hr);
    
    return oleMethod(nType, pvResult, pDisp, pdispID.getValue(), pArgs);
  }




  
  protected WinNT.HRESULT oleMethod(int nType, Variant.VARIANT.ByReference pvResult, IDispatch pDisp, OaIdl.DISPID dispId, Variant.VARIANT[] pArgs) throws COMException {
    if (pDisp == null) {
      throw new COMException("pDisp (IDispatch) parameter is null!");
    }
    
    int _argsLen = 0;
    Variant.VARIANT[] _args = null;
    OleAuto.DISPPARAMS dp = new OleAuto.DISPPARAMS();
    OaIdl.EXCEPINFO.ByReference pExcepInfo = new OaIdl.EXCEPINFO.ByReference();
    IntByReference puArgErr = new IntByReference();

    
    if (pArgs != null && pArgs.length > 0) {
      _argsLen = pArgs.length;
      _args = new Variant.VARIANT[_argsLen];
      
      int revCount = _argsLen;
      for (int i = 0; i < _argsLen; i++) {
        _args[i] = pArgs[--revCount];
      }
    } 

    
    if (nType == 4) {
      dp.cNamedArgs = new WinDef.UINT(_argsLen);
      dp.rgdispidNamedArgs = new OaIdl.DISPIDByReference(OaIdl.DISPID_PROPERTYPUT);
    } 


    
    if (_argsLen > 0) {
      dp.cArgs = new WinDef.UINT(_args.length);
      
      dp.rgvarg = new Variant.VariantArg.ByReference(_args);

      
      dp.write();
    } 

    
    WinNT.HRESULT hr = pDisp.Invoke(dispId, Guid.IID_NULL, LOCALE_SYSTEM_DEFAULT, new OaIdl.DISPID(nType), dp, pvResult, pExcepInfo, puArgErr);

    
    COMUtils.checkRC(hr, (OaIdl.EXCEPINFO)pExcepInfo, puArgErr);
    return hr;
  }



















  
  protected WinNT.HRESULT oleMethod(int nType, Variant.VARIANT.ByReference pvResult, IDispatch pDisp, String name, Variant.VARIANT pArg) throws COMException {
    return oleMethod(nType, pvResult, pDisp, name, new Variant.VARIANT[] { pArg });
  }



  
  protected WinNT.HRESULT oleMethod(int nType, Variant.VARIANT.ByReference pvResult, IDispatch pDisp, OaIdl.DISPID dispId, Variant.VARIANT pArg) throws COMException {
    return oleMethod(nType, pvResult, pDisp, dispId, new Variant.VARIANT[] { pArg });
  }


















  
  protected WinNT.HRESULT oleMethod(int nType, Variant.VARIANT.ByReference pvResult, IDispatch pDisp, String name) throws COMException {
    return oleMethod(nType, pvResult, pDisp, name, (Variant.VARIANT[])null);
  }


  
  protected WinNT.HRESULT oleMethod(int nType, Variant.VARIANT.ByReference pvResult, IDispatch pDisp, OaIdl.DISPID dispId) throws COMException {
    return oleMethod(nType, pvResult, pDisp, dispId, (Variant.VARIANT[])null);
  }






  
  protected void checkFailed(WinNT.HRESULT hr) {
    COMUtils.checkRC(hr, null, null);
  }
}
