package com.sun.jna;

public interface TypeMapper {
  FromNativeConverter getFromNativeConverter(Class paramClass);
  
  ToNativeConverter getToNativeConverter(Class paramClass);
}
