package com.sun.jna;

public class ToNativeContext {}
