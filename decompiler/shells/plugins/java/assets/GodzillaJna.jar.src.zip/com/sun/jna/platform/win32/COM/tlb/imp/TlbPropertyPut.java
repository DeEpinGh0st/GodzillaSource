package com.sun.jna.platform.win32.COM.tlb.imp;

import com.sun.jna.platform.win32.COM.TypeInfoUtil;
import com.sun.jna.platform.win32.COM.TypeLibUtil;
import com.sun.jna.platform.win32.OaIdl;
































public class TlbPropertyPut
  extends TlbAbstractMethod
{
  public TlbPropertyPut(int count, int index, TypeLibUtil typeLibUtil, OaIdl.FUNCDESC funcDesc, TypeInfoUtil typeInfoUtil) {
    super(index, typeLibUtil, funcDesc, typeInfoUtil);
    
    this.methodName = "set" + getMethodName();
    String[] names = typeInfoUtil.getNames(funcDesc.memid, this.paramCount + 1);
    
    if (this.paramCount > 0) {
      this.methodvariables += ", ";
    }
    for (int i = 0; i < this.paramCount; i++) {
      OaIdl.ELEMDESC elemdesc = funcDesc.lprgelemdescParam.elemDescArg[i];
      String varType = getType(elemdesc);
      this.methodparams += varType + " " + replaceJavaKeyword(names[i].toLowerCase());
      
      this.methodvariables += replaceJavaKeyword(names[i].toLowerCase());

      
      if (i < this.paramCount - 1) {
        this.methodparams += ", ";
        this.methodvariables += ", ";
      } 
    } 
    
    replaceVariable("helpstring", this.docStr);
    replaceVariable("methodname", this.methodName);
    replaceVariable("methodparams", this.methodparams);
    replaceVariable("methodvariables", this.methodvariables);
    replaceVariable("vtableid", String.valueOf(this.vtableId));
    replaceVariable("memberid", String.valueOf(this.memberid));
    replaceVariable("functionCount", String.valueOf(count));
  }






  
  protected String getClassTemplate() {
    return "com/sun/jna/platform/win32/COM/tlb/imp/TlbPropertyPut.template";
  }
}
