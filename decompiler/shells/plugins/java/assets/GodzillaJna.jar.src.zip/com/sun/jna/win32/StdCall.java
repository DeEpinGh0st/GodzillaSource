package com.sun.jna.win32;

import com.sun.jna.AltCallingConvention;

public interface StdCall extends AltCallingConvention {}
