package com.microsoft.sqlserver.jdbc;

final class DateTimeException extends Exception {}
