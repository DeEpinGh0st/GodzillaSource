package com.microsoft.sqlserver.jdbc;

import java.util.logging.Logger;














final class AuthenticationJNI
  extends SSPIAuthentication
{
  private static final int maximumpointersize = 128;
  private static boolean enabled = false;
  private static Logger authLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.AuthenticationJNI");
  private static int sspiBlobMaxlen = 0;
  private byte[] sniSec = new byte[128];
  private int[] sniSecLen = new int[] { 0 };
  
  private final String DNSName;
  private final int port;
  
  static int GetMaxSSPIBlobSize() {
    return sspiBlobMaxlen;
  }
  private SQLServerConnection con; private static final UnsatisfiedLinkError linkError;
  static {
    UnsatisfiedLinkError unsatisfiedLinkError = null;

    
    try {
      String str = "sqljdbc_auth";
      System.loadLibrary(str);
      int[] arrayOfInt = new int[1];
      arrayOfInt[0] = 0;
      if (0 == SNISecInitPackage(arrayOfInt, authLogger)) {
        
        sspiBlobMaxlen = arrayOfInt[0];
      } else {
        
        throw new UnsatisfiedLinkError();
      }  enabled = true;
    }
    catch (UnsatisfiedLinkError unsatisfiedLinkError1) {
      
      unsatisfiedLinkError = unsatisfiedLinkError1;
      authLogger.warning("Failed to load the sqljdbc_auth.dll cause : " + unsatisfiedLinkError1.getMessage());
    
    }
    finally {
      
      linkError = unsatisfiedLinkError;
    } 
  }


  
  AuthenticationJNI(SQLServerConnection paramSQLServerConnection, String paramString, int paramInt) throws SQLServerException {
    if (!enabled) {
      paramSQLServerConnection.terminate(0, SQLServerException.getErrString("R_notConfiguredForIntegrated"), linkError);
    }
    this.con = paramSQLServerConnection;
    this.DNSName = GetDNSName(paramString);
    this.port = paramInt;
  }
  
  static FedAuthDllInfo getAccessTokenForWindowsIntegrated(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong) throws DLLException {
    return ADALGetAccessTokenForWindowsIntegrated(paramString1, paramString2, paramString3, paramString4, paramLong, authLogger);
  }

  
  static FedAuthDllInfo getAccessToken(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, long paramLong) throws DLLException {
    return ADALGetAccessToken(paramString1, paramString2, paramString3, paramString4, paramString5, paramString6, paramLong, authLogger);
  }






  
  byte[] GenerateClientContext(byte[] paramArrayOfbyte, boolean[] paramArrayOfboolean) throws SQLServerException {
    int[] arrayOfInt = new int[1];
    arrayOfInt[0] = GetMaxSSPIBlobSize();
    byte[] arrayOfByte1 = new byte[arrayOfInt[0]];

    
    assert this.DNSName != null;
    
    int i = SNISecGenClientContext(this.sniSec, this.sniSecLen, paramArrayOfbyte, paramArrayOfbyte.length, arrayOfByte1, arrayOfInt, paramArrayOfboolean, this.DNSName, this.port, null, null, authLogger);
    
    if (i != 0) {
      
      authLogger.warning(toString() + " Authentication failed code : " + i);
      this.con.terminate(0, SQLServerException.getErrString("R_integratedAuthenticationFailed"), linkError);
    } 
    
    byte[] arrayOfByte2 = new byte[arrayOfInt[0]];
    System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, arrayOfInt[0]);
    return arrayOfByte2;
  }


  
  int ReleaseClientContext() {
    int i = 0;
    if (this.sniSecLen[0] > 0) {
      
      i = SNISecReleaseClientContext(this.sniSec, this.sniSecLen[0], authLogger);
      this.sniSecLen[0] = 0;
    } 
    return i;
  }


  
  private static String GetDNSName(String paramString) {
    String[] arrayOfString = new String[1];
    if (GetDNSName(paramString, arrayOfString, authLogger) != 0)
    {
      
      arrayOfString[0] = paramString;
    }
    return arrayOfString[0];
  }
  
  private static native int SNISecGenClientContext(byte[] paramArrayOfbyte1, int[] paramArrayOfint1, byte[] paramArrayOfbyte2, int paramInt1, byte[] paramArrayOfbyte3, int[] paramArrayOfint2, boolean[] paramArrayOfboolean, String paramString1, int paramInt2, String paramString2, String paramString3, Logger paramLogger);
  
  private static native int SNISecReleaseClientContext(byte[] paramArrayOfbyte, int paramInt, Logger paramLogger);
  
  private static native int SNISecInitPackage(int[] paramArrayOfint, Logger paramLogger);
  
  private static native int SNISecTerminatePackage(Logger paramLogger);
  
  private static native int SNIGetSID(byte[] paramArrayOfbyte, Logger paramLogger);
  
  private static native boolean SNIIsEqualToCurrentSID(byte[] paramArrayOfbyte, Logger paramLogger);
  
  private static native int GetDNSName(String paramString, String[] paramArrayOfString, Logger paramLogger);
  
  private static native FedAuthDllInfo ADALGetAccessTokenForWindowsIntegrated(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong, Logger paramLogger);
  
  private static native FedAuthDllInfo ADALGetAccessToken(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, long paramLong, Logger paramLogger);
  
  static native byte[] DecryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws DLLException;
}
