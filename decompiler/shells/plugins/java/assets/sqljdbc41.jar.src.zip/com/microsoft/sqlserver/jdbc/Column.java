package com.microsoft.sqlserver.jdbc;

import java.text.MessageFormat;
import java.util.Calendar;




final class Column
{
  private TypeInfo typeInfo;
  private CryptoMetadata cryptoMetadata;
  private DTV updaterDTV;
  
  final TypeInfo getTypeInfo() {
    return this.typeInfo;
  }
  private final DTV getterDTV = new DTV();

  
  private JDBCType jdbcTypeSetByUser = null; private String columnName;
  private String baseColumnName;
  private int tableNum;
  private int valueLength = 0; private int infoStatus; private SQLIdentifier tableName;
  ColumnFilter filter;
  
  final void setColumnName(String paramString) {
    this.columnName = paramString; } final String getColumnName() {
    return this.columnName;
  }

  
  final void setBaseColumnName(String paramString)
  {
    this.baseColumnName = paramString; } final String getBaseColumnName() {
    return this.baseColumnName;
  }
  
  final void setTableNum(int paramInt) { this.tableNum = paramInt; } final int getTableNum() {
    return this.tableNum;
  }
  
  final void setInfoStatus(int paramInt) { this.infoStatus = paramInt; }
  final boolean hasDifferentName() { return (0 != (this.infoStatus & 0x20)); }
  final boolean isHidden() { return (0 != (this.infoStatus & 0x10)); }
  final boolean isKey() { return (0 != (this.infoStatus & 0x8)); } final boolean isExpression() {
    return (0 != (this.infoStatus & 0x4));
  }
  final boolean isUpdatable() {
    return (!isExpression() && !isHidden() && this.tableName.getObjectName().length() > 0);
  }


  
  final void setTableName(SQLIdentifier paramSQLIdentifier)
  {
    this.tableName = paramSQLIdentifier; } final SQLIdentifier getTableName() {
    return this.tableName;
  }








  
  Column(TypeInfo paramTypeInfo, String paramString, SQLIdentifier paramSQLIdentifier, CryptoMetadata paramCryptoMetadata) {
    this.typeInfo = paramTypeInfo;
    this.columnName = paramString;
    this.baseColumnName = paramString;
    this.tableName = paramSQLIdentifier;
    this.cryptoMetadata = paramCryptoMetadata;
  }
  
  CryptoMetadata getCryptoMetadata() {
    return this.cryptoMetadata;
  }




  
  final void clear() {
    this.getterDTV.clear();
  }








  
  final void skipValue(TDSReader paramTDSReader, boolean paramBoolean) throws SQLServerException {
    this.getterDTV.skipValue(this.typeInfo, paramTDSReader, paramBoolean);
  }




  
  final void initFromCompressedNull() {
    this.getterDTV.initFromCompressedNull();
  }

  
  void setFilter(ColumnFilter paramColumnFilter) {
    this.filter = paramColumnFilter;
  }







  
  final boolean isNull() {
    return this.getterDTV.isNull();
  }







  
  final boolean isInitialized() {
    return this.getterDTV.isInitialized();
  }







  
  Object getValue(JDBCType paramJDBCType, InputStreamGetterArgs paramInputStreamGetterArgs, Calendar paramCalendar, TDSReader paramTDSReader) throws SQLServerException {
    Object object = this.getterDTV.getValue(paramJDBCType, this.typeInfo.getScale(), paramInputStreamGetterArgs, paramCalendar, this.typeInfo, this.cryptoMetadata, paramTDSReader);
    return (null != this.filter) ? this.filter.apply(object, paramJDBCType) : object;
  }

  
  int getInt(TDSReader paramTDSReader) throws SQLServerException {
    return ((Integer)getValue(JDBCType.INTEGER, null, null, paramTDSReader)).intValue();
  }












  
  void updateValue(JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, StreamSetterArgs paramStreamSetterArgs, Calendar paramCalendar, Integer paramInteger1, SQLServerConnection paramSQLServerConnection, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting, Integer paramInteger2, boolean paramBoolean, int paramInt) throws SQLServerException {
    SSType sSType = this.typeInfo.getSSType();

    
    if (null != this.cryptoMetadata)
    {
      if (null != paramObject) {
        
        if (JDBCType.TINYINT == this.cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType() && paramJavaType == JavaType.SHORT) {
          if (paramObject instanceof Boolean) {
            if (true == ((Boolean)paramObject).booleanValue()) {
              paramObject = Integer.valueOf(1);
            } else {
              
              paramObject = Integer.valueOf(0);
            } 
          }
          String str = "" + paramObject;
          Short short_ = Short.valueOf(str);
          
          if (short_.shortValue() >= 0 && short_.shortValue() <= 255) {
            paramObject = Byte.valueOf(short_.byteValue());
            paramJavaType = JavaType.BYTE;
            paramJDBCType = JDBCType.TINYINT;
          }
        
        }
      
      } else if (paramJDBCType.isBinary()) {
        paramJDBCType = this.cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType();
      } 
    }
    
    if (null == paramInteger1 && null != this.cryptoMetadata) {
      paramInteger1 = Integer.valueOf(this.cryptoMetadata.getBaseTypeInfo().getScale());
    }


    
    if (null != this.cryptoMetadata && (JDBCType.CHAR == paramJDBCType || JDBCType.VARCHAR == paramJDBCType) && (
      JDBCType.NVARCHAR == this.cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType() || JDBCType.NCHAR == this.cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType() || JDBCType.LONGNVARCHAR == this.cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType()))
    {
      
      paramJDBCType = this.cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType();
    }

    
    if (Util.shouldHonorAEForParameters(paramSQLServerStatementColumnEncryptionSetting, paramSQLServerConnection)) {
      
      if (null == this.cryptoMetadata && true == paramBoolean) {
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_ForceEncryptionTrue_HonorAETrue_UnencryptedColumnRS"));
        Object[] arrayOfObject = { Integer.valueOf(paramInt) };
        
        throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
      } 





      
      setJdbcTypeSetByUser(paramJDBCType);
      
      this.valueLength = Util.getValueLengthBaseOnJavaType(paramObject, paramJavaType, paramInteger2, paramInteger1, paramJDBCType);


      
      if (null != this.cryptoMetadata && (
        JDBCType.NCHAR == this.cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType() || JDBCType.NVARCHAR == this.cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType() || JDBCType.LONGNVARCHAR == this.cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType()))
      {
        
        this.valueLength *= 2;

      
      }
    
    }
    else if (true == paramBoolean) {
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_ForceEncryptionTrue_HonorAEFalseRS"));
      Object[] arrayOfObject = { Integer.valueOf(paramInt) };
      
      throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
    } 






    
    if (null != paramStreamSetterArgs) {
      
      if (!paramStreamSetterArgs.streamType.convertsTo(this.typeInfo)) {
        DataTypes.throwConversionError(paramStreamSetterArgs.streamType.toString(), sSType.toString());
      
      }
    }
    else if (null != this.cryptoMetadata) {

      
      if (JDBCType.UNKNOWN == paramJDBCType && paramObject instanceof java.util.UUID) {

        
        paramJavaType = JavaType.STRING;
        paramJDBCType = JDBCType.GUID;
        setJdbcTypeSetByUser(paramJDBCType);
      } 
      
      SSType sSType1 = this.cryptoMetadata.baseTypeInfo.getSSType();
      if (!paramJDBCType.convertsTo(sSType1)) {
        DataTypes.throwConversionError(paramJDBCType.toString(), sSType.toString());
      }
      JDBCType jDBCType = getJDBCTypeFromBaseSSType(sSType1, paramJDBCType);


      
      if (jDBCType != paramJDBCType)
      {
        setJdbcTypeSetByUser(jDBCType);
        paramJDBCType = jDBCType;
        this.valueLength = Util.getValueLengthBaseOnJavaType(paramObject, paramJavaType, paramInteger2, paramInteger1, paramJDBCType);
      
      }
    
    }
    else if (!paramJDBCType.convertsTo(sSType)) {
      DataTypes.throwConversionError(paramJDBCType.toString(), sSType.toString());
    } 


    
    if ((JDBCType.DATETIMEOFFSET == paramJDBCType || JavaType.DATETIMEOFFSET == paramJavaType) && !paramSQLServerConnection.isKatmaiOrLater())
    {
      
      throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
    }








    
    if (null != this.cryptoMetadata && paramSQLServerConnection.sendStringParametersAsUnicode() && (JavaType.STRING == paramJavaType || JavaType.READER == paramJavaType || JavaType.CLOB == paramJavaType))
    {


      
      paramJDBCType = getSSPAUJDBCType(paramJDBCType);
    }










    
    if ((SSType.NCHAR == sSType || SSType.NVARCHAR == sSType || SSType.NVARCHARMAX == sSType || SSType.NTEXT == sSType || SSType.XML == sSType) && (JDBCType.CHAR == paramJDBCType || JDBCType.VARCHAR == paramJDBCType || JDBCType.LONGVARCHAR == paramJDBCType || JDBCType.CLOB == paramJDBCType)) {











      
      paramJDBCType = (JDBCType.CLOB == paramJDBCType) ? JDBCType.NCLOB : JDBCType.NVARCHAR;

    
    }
    else if ((SSType.BINARY == sSType || SSType.VARBINARY == sSType || SSType.VARBINARYMAX == sSType || SSType.IMAGE == sSType || SSType.UDT == sSType) && (JDBCType.CHAR == paramJDBCType || JDBCType.VARCHAR == paramJDBCType || JDBCType.LONGVARCHAR == paramJDBCType)) {










      
      paramJDBCType = JDBCType.VARBINARY;


    
    }
    else if ((JDBCType.TIMESTAMP == paramJDBCType || JDBCType.DATE == paramJDBCType || JDBCType.TIME == paramJDBCType || JDBCType.DATETIMEOFFSET == paramJDBCType) && (SSType.CHAR == sSType || SSType.VARCHAR == sSType || SSType.VARCHARMAX == sSType || SSType.TEXT == sSType || SSType.NCHAR == sSType || SSType.NVARCHAR == sSType || SSType.NVARCHARMAX == sSType || SSType.NTEXT == sSType)) {
















      
      paramJDBCType = JDBCType.NCHAR;
    } 

    
    if (null == this.updaterDTV) {
      this.updaterDTV = new DTV();
    }

    
    this.updaterDTV.setValue(this.typeInfo.getSQLCollation(), paramJDBCType, paramObject, paramJavaType, paramStreamSetterArgs, paramCalendar, paramInteger1, paramSQLServerConnection, false);
  }





  
  private static JDBCType getSSPAUJDBCType(JDBCType paramJDBCType) {
    switch (paramJDBCType) {
      case CHAR:
        return JDBCType.NCHAR;
      case VARCHAR: return JDBCType.NVARCHAR;
      case LONGVARCHAR: return JDBCType.LONGNVARCHAR;
      case CLOB: return JDBCType.NCLOB;
    }  return paramJDBCType;
  }


  
  private static JDBCType getJDBCTypeFromBaseSSType(SSType paramSSType, JDBCType paramJDBCType) {
    switch (paramJDBCType) {
      
      case TIMESTAMP:
        if (SSType.DATETIME == paramSSType)
          return JDBCType.DATETIME; 
        if (SSType.SMALLDATETIME == paramSSType)
          return JDBCType.SMALLDATETIME; 
        return paramJDBCType;
      
      case NUMERIC:
      case DECIMAL:
        if (SSType.MONEY == paramSSType)
          return JDBCType.MONEY; 
        if (SSType.SMALLMONEY == paramSSType)
          return JDBCType.SMALLMONEY; 
        return paramJDBCType;
      
      case CHAR:
        if (SSType.GUID == paramSSType)
          return JDBCType.GUID; 
        break;
    } 
    return paramJDBCType;
  }


  
  boolean hasUpdates() {
    return (null != this.updaterDTV);
  }

  
  void cancelUpdates() {
    this.updaterDTV = null;
  }




  
  void sendByRPC(TDSWriter paramTDSWriter, SQLServerConnection paramSQLServerConnection) throws SQLServerException {
    if (null == this.updaterDTV) {
      return;
    }
    try {
      this.updaterDTV.sendCryptoMetaData(this.cryptoMetadata, paramTDSWriter);
      this.updaterDTV.jdbcTypeSetByUser(getJdbcTypeSetByUser(), getValueLength());

      
      this.updaterDTV.sendByRPC(this.baseColumnName, this.typeInfo, (null != this.cryptoMetadata) ? this.cryptoMetadata.getBaseTypeInfo().getSQLCollation() : this.typeInfo.getSQLCollation(), (null != this.cryptoMetadata) ? this.cryptoMetadata.getBaseTypeInfo().getPrecision() : this.typeInfo.getPrecision(), (null != this.cryptoMetadata) ? this.cryptoMetadata.getBaseTypeInfo().getScale() : this.typeInfo.getScale(), false, paramTDSWriter, paramSQLServerConnection);



    
    }
    finally {




      
      this.updaterDTV.sendCryptoMetaData(null, paramTDSWriter);
    } 
  }
  
  JDBCType getJdbcTypeSetByUser() {
    return this.jdbcTypeSetByUser;
  }
  void setJdbcTypeSetByUser(JDBCType paramJDBCType) {
    this.jdbcTypeSetByUser = paramJDBCType;
  }
  
  int getValueLength() {
    return this.valueLength;
  }
}
