package com.microsoft.sqlserver.jdbc;

import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.logging.Level;
import javax.naming.Reference;
import javax.sql.ConnectionPoolDataSource;
import javax.sql.PooledConnection;





public class SQLServerConnectionPoolDataSource
  extends SQLServerDataSource
  implements ConnectionPoolDataSource
{
  public PooledConnection getPooledConnection() throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getPooledConnection"); 
    PooledConnection pooledConnection = getPooledConnection(getUser(), getPassword());
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.exiting(getClassNameLogging(), "getPooledConnection", pooledConnection); 
    return pooledConnection;
  }

  
  public PooledConnection getPooledConnection(String paramString1, String paramString2) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getPooledConnection", new Object[] { paramString1, "Password not traced" }); 
    SQLServerPooledConnection sQLServerPooledConnection = new SQLServerPooledConnection(this, paramString1, paramString2);
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.exiting(getClassNameLogging(), "getPooledConnection", sQLServerPooledConnection); 
    return sQLServerPooledConnection;
  }



  
  public Reference getReference() {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getReference"); 
    Reference reference = getReferenceInternal("com.microsoft.sqlserver.jdbc.SQLServerConnectionPoolDataSource");
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.exiting(getClassNameLogging(), "getReference", reference); 
    return reference;
  }
  
  private Object writeReplace() throws ObjectStreamException {
    return new SerializationProxy(this);
  }






  
  private void readObject(ObjectInputStream paramObjectInputStream) throws InvalidObjectException {
    throw new InvalidObjectException("");
  }


  
  private static class SerializationProxy
    implements Serializable
  {
    private final Reference ref;

    
    private static final long serialVersionUID = 654661379842314126L;

    
    SerializationProxy(SQLServerConnectionPoolDataSource param1SQLServerConnectionPoolDataSource) {
      this.ref = param1SQLServerConnectionPoolDataSource.getReferenceInternal(null);
    }
    
    private Object readResolve() {
      SQLServerConnectionPoolDataSource sQLServerConnectionPoolDataSource = new SQLServerConnectionPoolDataSource();
      sQLServerConnectionPoolDataSource.initializeFromReference(this.ref);
      return sQLServerConnectionPoolDataSource;
    }
  }
}
