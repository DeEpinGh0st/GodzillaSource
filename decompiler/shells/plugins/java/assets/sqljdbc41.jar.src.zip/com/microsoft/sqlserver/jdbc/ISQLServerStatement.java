package com.microsoft.sqlserver.jdbc;

import java.sql.Statement;

public interface ISQLServerStatement extends Statement {
  void setResponseBuffering(String paramString) throws SQLServerException;
  
  String getResponseBuffering() throws SQLServerException;
}
