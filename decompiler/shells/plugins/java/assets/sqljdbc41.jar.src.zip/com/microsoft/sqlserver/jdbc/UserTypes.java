package com.microsoft.sqlserver.jdbc;

final class UserTypes {
  static final int TIMESTAMP = 80;
}
