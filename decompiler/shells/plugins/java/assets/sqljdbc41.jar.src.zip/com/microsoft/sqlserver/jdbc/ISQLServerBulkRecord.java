package com.microsoft.sqlserver.jdbc;

import java.util.Set;

public interface ISQLServerBulkRecord {
  Set<Integer> getColumnOrdinals();
  
  String getColumnName(int paramInt);
  
  int getColumnType(int paramInt);
  
  int getPrecision(int paramInt);
  
  int getScale(int paramInt);
  
  boolean isAutoIncrement(int paramInt);
  
  Object[] getRowData() throws SQLServerException;
  
  boolean next() throws SQLServerException;
}
