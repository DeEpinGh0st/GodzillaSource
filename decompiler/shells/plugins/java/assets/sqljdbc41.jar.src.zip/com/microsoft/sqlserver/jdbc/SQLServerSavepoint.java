package com.microsoft.sqlserver.jdbc;

import java.sql.Savepoint;
import java.text.MessageFormat;














public final class SQLServerSavepoint
  implements Savepoint
{
  private final String sName;
  private final int nId;
  private final SQLServerConnection con;
  
  public SQLServerSavepoint(SQLServerConnection paramSQLServerConnection, String paramString) {
    this.con = paramSQLServerConnection;
    if (paramString == null) {
      
      this.nId = paramSQLServerConnection.getNextSavepointId();
      this.sName = null;
    }
    else {
      
      this.sName = paramString;
      this.nId = 0;
    } 
  }
  
  public String getSavepointName() throws SQLServerException {
    if (this.sName == null)
      SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_savepointNotNamed"), null, false); 
    return this.sName;
  }




  
  public String getLabel() {
    if (this.sName == null) {
      return "S" + this.nId;
    }
    return this.sName;
  }
  
  public boolean isNamed() {
    return (this.sName != null);
  }
  
  public int getSavepointId() throws SQLServerException {
    if (this.sName != null) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_savepointNamed"));
      Object[] arrayOfObject = { new String(this.sName) };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, false);
    } 
    return this.nId;
  }
}
