package com.microsoft.sqlserver.jdbc;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.NClob;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Map;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import microsoft.sql.DateTimeOffset;

public final class SQLServerCallableStatement extends SQLServerPreparedStatement implements ISQLServerCallableStatement {
  private ArrayList<String> paramNames;
  int nOutParams = 0;

  
  int nOutParamsAssigned = 0;
  
  private int outParamIndex = -1;

  
  private Parameter lastParamAccessed;

  
  private Closeable activeStream;


  
  String getClassNameInternal() {
    return "SQLServerCallableStatement";
  }











  
  SQLServerCallableStatement(SQLServerConnection paramSQLServerConnection, String paramString, int paramInt1, int paramInt2, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
    super(paramSQLServerConnection, paramString, paramInt1, paramInt2, paramSQLServerStatementColumnEncryptionSetting);
  }

  
  public void registerOutParameter(int paramInt1, int paramInt2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { new Integer(paramInt1), new Integer(paramInt2) }); 
    checkClosed();
    if (paramInt1 < 1 || paramInt1 > this.inOutParam.length) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_indexOutOfRange"));
      Object[] arrayOfObject = { new Integer(paramInt1) };
      SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), "7009", false);
    } 



    
    if (2012 == paramInt2) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_featureNotSupported"));
      Object[] arrayOfObject = { new String("REF_CURSOR") };
      SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), null, false);
    } 
    
    JDBCType jDBCType = JDBCType.of(paramInt2);


    
    discardLastExecutionResults();


    
    if (jDBCType.isUnsupported()) {
      jDBCType = JDBCType.BINARY;
    }
    Parameter parameter = this.inOutParam[paramInt1 - 1];
    assert null != parameter;


    
    if (!parameter.isOutput()) {
      this.nOutParams++;
    }

    
    parameter.registerForOutput(jDBCType, this.connection);
    switch (paramInt2) {
      
      case -151:
        parameter.setOutScale(3);
        break;
      case -155:
      case 92:
      case 93:
        parameter.setOutScale(7);
        break;
    } 


    
    loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
  }

  
  public void registerOutParameter(int paramInt, SQLType paramSQLType) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { new Integer(paramInt), paramSQLType });
    }
    
    registerOutParameter(paramInt, paramSQLType.getVendorTypeNumber().intValue());
    loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
  }








  
  private final Parameter getOutParameter(int paramInt) throws SQLServerException {
    processResults();

    
    if (this.inOutParam[paramInt - 1] == this.lastParamAccessed || this.inOutParam[paramInt - 1].isValueGotten()) {
      return this.inOutParam[paramInt - 1];
    }

    
    while (this.outParamIndex != paramInt - 1) {
      skipOutParameters(1, false);
    }
    return this.inOutParam[paramInt - 1];
  }

  
  void startResults() {
    super.startResults();
    this.outParamIndex = -1;
    this.nOutParamsAssigned = 0;
    this.lastParamAccessed = null;
    assert null == this.activeStream;
  }

  
  void processBatch() throws SQLServerException {
    processResults();




    
    assert this.nOutParams >= 0;
    if (this.nOutParams > 0) {
      
      processOutParameters();
      processBatchRemainder();
    } 
  }

  
  final void processOutParameters() throws SQLServerException {
    assert this.nOutParams > 0;
    assert null != this.inOutParam;

    
    closeActiveStream();


    
    if (this.outParamIndex >= 0)
    {



      
      for (byte b = 0; b < this.inOutParam.length; b++) {
        
        if (b != this.outParamIndex && this.inOutParam[b].isValueGotten()) {
          
          assert this.inOutParam[b].isOutput();
          this.inOutParam[b].resetOutputValue();
        } 
      } 
    }

    
    assert this.nOutParamsAssigned <= this.nOutParams;
    if (this.nOutParamsAssigned < this.nOutParams) {
      skipOutParameters(this.nOutParams - this.nOutParamsAssigned, true);
    }



    
    if (this.outParamIndex >= 0) {
      
      this.inOutParam[this.outParamIndex].skipValue(resultsReader(), true);
      this.inOutParam[this.outParamIndex].resetOutputValue();
      this.outParamIndex = -1;
    } 
  }





  
  private void processBatchRemainder() throws SQLServerException {
    final class ExecDoneHandler
      extends TDSTokenHandler
    {
      ExecDoneHandler() {
        super("ExecDoneHandler");
      }


      
      boolean onDone(TDSReader param1TDSReader) throws SQLServerException {
        StreamDone streamDone = new StreamDone();
        streamDone.setFromTDS(param1TDSReader);



        
        if (streamDone.wasRPCInBatch()) {
          
          SQLServerCallableStatement.this.startResults();
          return false;
        } 


        
        return true;
      }
    };
    
    ExecDoneHandler execDoneHandler = new ExecDoneHandler();
    TDSParser.parse(resultsReader(), execDoneHandler);
  }

  
  private void skipOutParameters(int paramInt, boolean paramBoolean) throws SQLServerException {
    final class OutParamHandler
      extends TDSTokenHandler
    {
      final StreamRetValue srv = new StreamRetValue(); private boolean foundParam;
      
      final boolean foundParam() {
        return this.foundParam;
      }
      
      OutParamHandler() {
        super("OutParamHandler");
      }

      
      final void reset() {
        this.foundParam = false;
      }

      
      boolean onRetValue(TDSReader param1TDSReader) throws SQLServerException {
        this.srv.setFromTDS(param1TDSReader);
        this.foundParam = true;
        return false;
      }
    };
    
    OutParamHandler outParamHandler = new OutParamHandler();

    
    assert paramInt <= this.nOutParams - this.nOutParamsAssigned;
    for (byte b = 0; b < paramInt; b++) {


      
      if (-1 != this.outParamIndex) {
        
        this.inOutParam[this.outParamIndex].skipValue(resultsReader(), paramBoolean);
        if (paramBoolean) {
          this.inOutParam[this.outParamIndex].resetOutputValue();
        }
      } 
      
      outParamHandler.reset();
      TDSParser.parse(resultsReader(), outParamHandler);



      
      if (!outParamHandler.foundParam()) {





        
        if (paramBoolean) {
          break;
        }



        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_valueNotSetForParameter"));
        Object[] arrayOfObject = { new Integer(this.outParamIndex + 1) };
        SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), null, false);
      } 







      
      this.outParamIndex = outParamHandler.srv.getOrdinalOrLength();


      
      this.outParamIndex -= this.outParamIndexAdjustment;
      if (this.outParamIndex < 0 || this.outParamIndex >= this.inOutParam.length || !this.inOutParam[this.outParamIndex].isOutput()) {
        
        getStatementLogger().info(toString() + " Unexpected outParamIndex: " + this.outParamIndex + "; adjustment: " + this.outParamIndexAdjustment);
        this.connection.throwInvalidTDS();
      } 

      
      this.nOutParamsAssigned++;
    } 
  }

  
  public void registerOutParameter(int paramInt1, int paramInt2, String paramString) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { new Integer(paramInt1), new Integer(paramInt2), paramString });
    }
    checkClosed();
    
    registerOutParameter(paramInt1, paramInt2);
    
    loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
  }

  
  public void registerOutParameter(int paramInt, SQLType paramSQLType, String paramString) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { new Integer(paramInt), paramSQLType, paramString });
    }
    
    registerOutParameter(paramInt, paramSQLType.getVendorTypeNumber().intValue(), paramString);
    
    loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
  }

  
  public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { new Integer(paramInt1), new Integer(paramInt2), new Integer(paramInt3) });
    }
    checkClosed();
    
    registerOutParameter(paramInt1, paramInt2);
    this.inOutParam[paramInt1 - 1].setOutScale(paramInt3);
    
    loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
  }

  
  public void registerOutParameter(int paramInt1, SQLType paramSQLType, int paramInt2) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { new Integer(paramInt1), paramSQLType, new Integer(paramInt2) });
    }
    
    registerOutParameter(paramInt1, paramSQLType.getVendorTypeNumber().intValue(), paramInt2);
    
    loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
  }

  
  public void registerOutParameter(int paramInt1, SQLType paramSQLType, int paramInt2, int paramInt3) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { new Integer(paramInt1), paramSQLType, new Integer(paramInt3) });
    }
    
    registerOutParameter(paramInt1, paramSQLType.getVendorTypeNumber().intValue(), paramInt2, paramInt3);
    
    loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
  }

  
  public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { new Integer(paramInt1), new Integer(paramInt2), new Integer(paramInt4), new Integer(paramInt3) });
    }
    checkClosed();
    
    registerOutParameter(paramInt1, paramInt2);
    this.inOutParam[paramInt1 - 1].setValueLength(paramInt3);
    this.inOutParam[paramInt1 - 1].setOutScale(paramInt4);
    
    loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
  }



  
  private Parameter getterGetParam(int paramInt) throws SQLServerException {
    checkClosed();

    
    if (paramInt < 1 || paramInt > this.inOutParam.length) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidOutputParameter"));
      Object[] arrayOfObject = { new Integer(paramInt) };
      SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), "07009", false);
    } 

    
    if (!this.inOutParam[paramInt - 1].isOutput()) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_outputParameterNotRegisteredForOutput"));
      Object[] arrayOfObject = { new Integer(paramInt) };
      SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), "07009", true);
    } 

    
    if (!wasExecuted()) {
      SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_statementMustBeExecuted"), "07009", false);
    }
    resultsReader().getCommand().checkForInterrupt();
    
    closeActiveStream();
    if (getStatementLogger().isLoggable(Level.FINER)) {
      getStatementLogger().finer(toString() + " Getting Param:" + paramInt);
    }
    
    this.lastParamAccessed = getOutParameter(paramInt);
    return this.lastParamAccessed;
  }

  
  private Object getValue(int paramInt, JDBCType paramJDBCType) throws SQLServerException {
    return getterGetParam(paramInt).getValue(paramJDBCType, null, null, resultsReader());
  }

  
  private Object getValue(int paramInt, JDBCType paramJDBCType, Calendar paramCalendar) throws SQLServerException {
    return getterGetParam(paramInt).getValue(paramJDBCType, null, paramCalendar, resultsReader());
  }

  
  private Object getStream(int paramInt, StreamType paramStreamType) throws SQLServerException {
    Object object = getterGetParam(paramInt).getValue(paramStreamType.getJDBCType(), new InputStreamGetterArgs(paramStreamType, getIsResponseBufferingAdaptive(), getIsResponseBufferingAdaptive(), toString()), null, resultsReader());








    
    this.activeStream = (Closeable)object;
    return object;
  }
  
  private Object getSQLXMLInternal(int paramInt) throws SQLServerException {
    SQLServerSQLXML sQLServerSQLXML = (SQLServerSQLXML)getterGetParam(paramInt).getValue(JDBCType.SQLXML, new InputStreamGetterArgs(StreamType.SQLXML, getIsResponseBufferingAdaptive(), getIsResponseBufferingAdaptive(), toString()), null, resultsReader());








    
    if (null != sQLServerSQLXML)
      this.activeStream = sQLServerSQLXML.getStream(); 
    return sQLServerSQLXML;
  }

  
  public int getInt(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getInt", Integer.valueOf(paramInt));
    checkClosed();
    Integer integer = (Integer)getValue(paramInt, JDBCType.INTEGER);
    loggerExternal.exiting(getClassNameLogging(), "getInt", integer);
    return (null != integer) ? integer.intValue() : 0;
  }

  
  public int getInt(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getInt", paramString);
    checkClosed();
    Integer integer = (Integer)getValue(findColumn(paramString), JDBCType.INTEGER);
    loggerExternal.exiting(getClassNameLogging(), "getInt", integer);
    return (null != integer) ? integer.intValue() : 0;
  }

  
  public String getString(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getString", Integer.valueOf(paramInt));
    checkClosed();
    String str = (String)getValue(paramInt, JDBCType.CHAR);
    loggerExternal.exiting(getClassNameLogging(), "getString", str);
    return str;
  }

  
  public String getString(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getString", paramString);
    checkClosed();
    String str = (String)getValue(findColumn(paramString), JDBCType.CHAR);
    loggerExternal.exiting(getClassNameLogging(), "getString", str);
    return str;
  }

  
  public final String getNString(int paramInt) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    
    loggerExternal.entering(getClassNameLogging(), "getNString", Integer.valueOf(paramInt));
    checkClosed();
    String str = (String)getValue(paramInt, JDBCType.NCHAR);
    loggerExternal.exiting(getClassNameLogging(), "getNString", str);
    return str;
  }

  
  public final String getNString(String paramString) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    
    loggerExternal.entering(getClassNameLogging(), "getNString", paramString);
    checkClosed();
    String str = (String)getValue(findColumn(paramString), JDBCType.NCHAR);
    loggerExternal.exiting(getClassNameLogging(), "getNString", str);
    return str;
  }
  
  @Deprecated
  public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getBigDecimal", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) }); 
    checkClosed();
    BigDecimal bigDecimal = (BigDecimal)getValue(paramInt1, JDBCType.DECIMAL);
    if (null != bigDecimal)
      bigDecimal = bigDecimal.setScale(paramInt2, 1); 
    loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", bigDecimal);
    return bigDecimal;
  }
  
  @Deprecated
  public BigDecimal getBigDecimal(String paramString, int paramInt) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getBigDecimal", new Object[] { paramString, Integer.valueOf(paramInt) }); 
    checkClosed();
    BigDecimal bigDecimal = (BigDecimal)getValue(findColumn(paramString), JDBCType.DECIMAL);
    if (null != bigDecimal)
      bigDecimal = bigDecimal.setScale(paramInt, 1); 
    loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", bigDecimal);
    return bigDecimal;
  }

  
  public boolean getBoolean(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getBoolean", Integer.valueOf(paramInt));
    checkClosed();
    Boolean bool = (Boolean)getValue(paramInt, JDBCType.BIT);
    loggerExternal.exiting(getClassNameLogging(), "getBoolean", bool);
    return (null != bool) ? bool.booleanValue() : false;
  }

  
  public boolean getBoolean(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getBoolean", paramString);
    checkClosed();
    Boolean bool = (Boolean)getValue(findColumn(paramString), JDBCType.BIT);
    loggerExternal.exiting(getClassNameLogging(), "getBoolean", bool);
    return (null != bool) ? bool.booleanValue() : false;
  }

  
  public byte getByte(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getByte", Integer.valueOf(paramInt));
    checkClosed();
    Short short_ = (Short)getValue(paramInt, JDBCType.TINYINT);
    boolean bool = (null != short_) ? short_.byteValue() : false;
    loggerExternal.exiting(getClassNameLogging(), "getByte", Byte.valueOf(bool));
    return bool;
  }

  
  public byte getByte(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getByte", paramString);
    checkClosed();
    Short short_ = (Short)getValue(findColumn(paramString), JDBCType.TINYINT);
    boolean bool = (null != short_) ? short_.byteValue() : false;
    loggerExternal.exiting(getClassNameLogging(), "getByte", Byte.valueOf(bool));
    return bool;
  }

  
  public byte[] getBytes(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getBytes", Integer.valueOf(paramInt));
    checkClosed();
    byte[] arrayOfByte = (byte[])getValue(paramInt, JDBCType.BINARY);
    loggerExternal.exiting(getClassNameLogging(), "getBytes", arrayOfByte);
    return arrayOfByte;
  }

  
  public byte[] getBytes(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getBytes", paramString);
    checkClosed();
    byte[] arrayOfByte = (byte[])getValue(findColumn(paramString), JDBCType.BINARY);
    loggerExternal.exiting(getClassNameLogging(), "getBytes", arrayOfByte);
    return arrayOfByte;
  }

  
  public Date getDate(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getDate", Integer.valueOf(paramInt));
    checkClosed();
    Date date = (Date)getValue(paramInt, JDBCType.DATE);
    loggerExternal.exiting(getClassNameLogging(), "getDate", date);
    return date;
  }

  
  public Date getDate(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getDate", paramString);
    checkClosed();
    Date date = (Date)getValue(findColumn(paramString), JDBCType.DATE);
    loggerExternal.exiting(getClassNameLogging(), "getDate", date);
    return date;
  }

  
  public Date getDate(int paramInt, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getDate", new Object[] { Integer.valueOf(paramInt), paramCalendar }); 
    checkClosed();
    Date date = (Date)getValue(paramInt, JDBCType.DATE, paramCalendar);
    loggerExternal.exiting(getClassNameLogging(), "getDate", date);
    return date;
  }

  
  public Date getDate(String paramString, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getDate", new Object[] { paramString, paramCalendar }); 
    checkClosed();
    Date date = (Date)getValue(findColumn(paramString), JDBCType.DATE, paramCalendar);
    loggerExternal.exiting(getClassNameLogging(), "getDate", date);
    return date;
  }

  
  public double getDouble(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getDouble", Integer.valueOf(paramInt));
    checkClosed();
    Double double_ = (Double)getValue(paramInt, JDBCType.DOUBLE);
    loggerExternal.exiting(getClassNameLogging(), "getDouble", double_);
    return (null != double_) ? double_.doubleValue() : 0.0D;
  }

  
  public double getDouble(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getDouble", paramString);
    checkClosed();
    Double double_ = (Double)getValue(findColumn(paramString), JDBCType.DOUBLE);
    loggerExternal.exiting(getClassNameLogging(), "getDouble", double_);
    return (null != double_) ? double_.doubleValue() : 0.0D;
  }

  
  public float getFloat(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getFloat", Integer.valueOf(paramInt));
    checkClosed();
    Float float_ = (Float)getValue(paramInt, JDBCType.REAL);
    loggerExternal.exiting(getClassNameLogging(), "getFloat", float_);
    return (null != float_) ? float_.floatValue() : 0.0F;
  }


  
  public float getFloat(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getFloat", paramString);
    checkClosed();
    Float float_ = (Float)getValue(findColumn(paramString), JDBCType.REAL);
    loggerExternal.exiting(getClassNameLogging(), "getFloat", float_);
    return (null != float_) ? float_.floatValue() : 0.0F;
  }


  
  public long getLong(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getLong", Integer.valueOf(paramInt));
    checkClosed();
    Long long_ = (Long)getValue(paramInt, JDBCType.BIGINT);
    loggerExternal.exiting(getClassNameLogging(), "getLong", long_);
    return (null != long_) ? long_.longValue() : 0L;
  }

  
  public long getLong(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getLong", paramString);
    checkClosed();
    Long long_ = (Long)getValue(findColumn(paramString), JDBCType.BIGINT);
    loggerExternal.exiting(getClassNameLogging(), "getLong", long_);
    return (null != long_) ? long_.longValue() : 0L;
  }


  
  public Object getObject(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getObject", Integer.valueOf(paramInt));
    checkClosed();
    Object object = getValue(paramInt, (getterGetParam(paramInt).getJdbcTypeSetByUser() != null) ? getterGetParam(paramInt).getJdbcTypeSetByUser() : getterGetParam(paramInt).getJdbcType());


    
    loggerExternal.exiting(getClassNameLogging(), "getObject", object);
    return object;
  }

  
  public <T> T getObject(int paramInt, Class<T> paramClass) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC41();

    
    throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
  }

  
  public Object getObject(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getObject", paramString);
    checkClosed();
    int i = findColumn(paramString);
    Object object = getValue(i, (getterGetParam(i).getJdbcTypeSetByUser() != null) ? getterGetParam(i).getJdbcTypeSetByUser() : getterGetParam(i).getJdbcType());


    
    loggerExternal.exiting(getClassNameLogging(), "getObject", object);
    return object;
  }

  
  public <T> T getObject(String paramString, Class<T> paramClass) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC41();

    
    throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
  }


  
  public short getShort(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getShort", Integer.valueOf(paramInt));
    checkClosed();
    Short short_ = (Short)getValue(paramInt, JDBCType.SMALLINT);
    loggerExternal.exiting(getClassNameLogging(), "getShort", short_);
    return (null != short_) ? short_.shortValue() : 0;
  }

  
  public short getShort(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getShort", paramString);
    checkClosed();
    Short short_ = (Short)getValue(findColumn(paramString), JDBCType.SMALLINT);
    loggerExternal.exiting(getClassNameLogging(), "getShort", short_);
    return (null != short_) ? short_.shortValue() : 0;
  }


  
  public Time getTime(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getTime", Integer.valueOf(paramInt));
    checkClosed();
    Time time = (Time)getValue(paramInt, JDBCType.TIME);
    loggerExternal.exiting(getClassNameLogging(), "getTime", time);
    return time;
  }

  
  public Time getTime(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getTime", paramString);
    checkClosed();
    Time time = (Time)getValue(findColumn(paramString), JDBCType.TIME);
    loggerExternal.exiting(getClassNameLogging(), "getTime", time);
    return time;
  }

  
  public Time getTime(int paramInt, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getTime", new Object[] { Integer.valueOf(paramInt), paramCalendar }); 
    checkClosed();
    Time time = (Time)getValue(paramInt, JDBCType.TIME, paramCalendar);
    loggerExternal.exiting(getClassNameLogging(), "getTime", time);
    return time;
  }

  
  public Time getTime(String paramString, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getTime", new Object[] { paramString, paramCalendar }); 
    checkClosed();
    Time time = (Time)getValue(findColumn(paramString), JDBCType.TIME, paramCalendar);
    loggerExternal.exiting(getClassNameLogging(), "getTime", time);
    return time;
  }

  
  public Timestamp getTimestamp(int paramInt) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getTimestamp", Integer.valueOf(paramInt)); 
    checkClosed();
    Timestamp timestamp = (Timestamp)getValue(paramInt, JDBCType.TIMESTAMP);
    loggerExternal.exiting(getClassNameLogging(), "getTimestamp", timestamp);
    return timestamp;
  }

  
  public Timestamp getTimestamp(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getTimestamp", paramString);
    checkClosed();
    Timestamp timestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.TIMESTAMP);
    loggerExternal.exiting(getClassNameLogging(), "getTimestamp", timestamp);
    return timestamp;
  }

  
  public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getTimestamp", new Object[] { Integer.valueOf(paramInt), paramCalendar }); 
    checkClosed();
    Timestamp timestamp = (Timestamp)getValue(paramInt, JDBCType.TIMESTAMP, paramCalendar);
    loggerExternal.exiting(getClassNameLogging(), "getTimestamp", timestamp);
    return timestamp;
  }

  
  public Timestamp getTimestamp(String paramString, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getTimestamp", new Object[] { paramString, paramCalendar }); 
    checkClosed();
    Timestamp timestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.TIMESTAMP, paramCalendar);
    loggerExternal.exiting(getClassNameLogging(), "getTimestamp", timestamp);
    return timestamp;
  }

  
  public Timestamp getDateTime(int paramInt) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getDateTime", Integer.valueOf(paramInt)); 
    checkClosed();
    Timestamp timestamp = (Timestamp)getValue(paramInt, JDBCType.DATETIME);
    loggerExternal.exiting(getClassNameLogging(), "getDateTime", timestamp);
    return timestamp;
  }

  
  public Timestamp getDateTime(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getDateTime", paramString);
    checkClosed();
    Timestamp timestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.DATETIME);
    loggerExternal.exiting(getClassNameLogging(), "getDateTime", timestamp);
    return timestamp;
  }

  
  public Timestamp getDateTime(int paramInt, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getDateTime", new Object[] { Integer.valueOf(paramInt), paramCalendar }); 
    checkClosed();
    Timestamp timestamp = (Timestamp)getValue(paramInt, JDBCType.DATETIME, paramCalendar);
    loggerExternal.exiting(getClassNameLogging(), "getDateTime", timestamp);
    return timestamp;
  }

  
  public Timestamp getDateTime(String paramString, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getDateTime", new Object[] { paramString, paramCalendar }); 
    checkClosed();
    Timestamp timestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.DATETIME, paramCalendar);
    loggerExternal.exiting(getClassNameLogging(), "getDateTime", timestamp);
    return timestamp;
  }

  
  public Timestamp getSmallDateTime(int paramInt) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getSmallDateTime", Integer.valueOf(paramInt)); 
    checkClosed();
    Timestamp timestamp = (Timestamp)getValue(paramInt, JDBCType.SMALLDATETIME);
    loggerExternal.exiting(getClassNameLogging(), "getSmallDateTime", timestamp);
    return timestamp;
  }

  
  public Timestamp getSmallDateTime(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getSmallDateTime", paramString);
    checkClosed();
    Timestamp timestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.SMALLDATETIME);
    loggerExternal.exiting(getClassNameLogging(), "getSmallDateTime", timestamp);
    return timestamp;
  }

  
  public Timestamp getSmallDateTime(int paramInt, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getSmallDateTime", new Object[] { Integer.valueOf(paramInt), paramCalendar }); 
    checkClosed();
    Timestamp timestamp = (Timestamp)getValue(paramInt, JDBCType.SMALLDATETIME, paramCalendar);
    loggerExternal.exiting(getClassNameLogging(), "getSmallDateTime", timestamp);
    return timestamp;
  }

  
  public Timestamp getSmallDateTime(String paramString, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getSmallDateTime", new Object[] { paramString, paramCalendar }); 
    checkClosed();
    Timestamp timestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.SMALLDATETIME, paramCalendar);
    loggerExternal.exiting(getClassNameLogging(), "getSmallDateTime", timestamp);
    return timestamp;
  }

  
  public DateTimeOffset getDateTimeOffset(int paramInt) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getDateTimeOffset", Integer.valueOf(paramInt)); 
    checkClosed();

    
    if (!this.connection.isKatmaiOrLater()) {
      throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
    }



    
    DateTimeOffset dateTimeOffset = (DateTimeOffset)getValue(paramInt, JDBCType.DATETIMEOFFSET);
    loggerExternal.exiting(getClassNameLogging(), "getDateTimeOffset", dateTimeOffset);
    return dateTimeOffset;
  }

  
  public DateTimeOffset getDateTimeOffset(String paramString) throws SQLException {
    loggerExternal.entering(getClassNameLogging(), "getDateTimeOffset", paramString);
    checkClosed();

    
    if (!this.connection.isKatmaiOrLater()) {
      throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
    }



    
    DateTimeOffset dateTimeOffset = (DateTimeOffset)getValue(findColumn(paramString), JDBCType.DATETIMEOFFSET);
    loggerExternal.exiting(getClassNameLogging(), "getDateTimeOffset", dateTimeOffset);
    return dateTimeOffset;
  }

  
  public boolean wasNull() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "wasNull");
    checkClosed();
    boolean bool = false;
    if (null != this.lastParamAccessed)
    {
      bool = this.lastParamAccessed.isNull();
    }
    loggerExternal.exiting(getClassNameLogging(), "wasNull", Boolean.valueOf(bool));
    return bool;
  }

  
  public final InputStream getAsciiStream(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getAsciiStream", Integer.valueOf(paramInt));
    checkClosed();
    InputStream inputStream = (InputStream)getStream(paramInt, StreamType.ASCII);
    loggerExternal.exiting(getClassNameLogging(), "getAsciiStream", inputStream);
    return inputStream;
  }

  
  public final InputStream getAsciiStream(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getAsciiStream", paramString);
    checkClosed();
    InputStream inputStream = (InputStream)getStream(findColumn(paramString), StreamType.ASCII);
    loggerExternal.exiting(getClassNameLogging(), "getAsciiStream", inputStream);
    return inputStream;
  }

  
  public BigDecimal getBigDecimal(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getBigDecimal", Integer.valueOf(paramInt));
    checkClosed();
    BigDecimal bigDecimal = (BigDecimal)getValue(paramInt, JDBCType.DECIMAL);
    loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", bigDecimal);
    return bigDecimal;
  }

  
  public BigDecimal getBigDecimal(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getBigDecimal", paramString);
    checkClosed();
    BigDecimal bigDecimal = (BigDecimal)getValue(findColumn(paramString), JDBCType.DECIMAL);
    loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", bigDecimal);
    return bigDecimal;
  }

  
  public BigDecimal getMoney(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getMoney", Integer.valueOf(paramInt));
    checkClosed();
    BigDecimal bigDecimal = (BigDecimal)getValue(paramInt, JDBCType.MONEY);
    loggerExternal.exiting(getClassNameLogging(), "getMoney", bigDecimal);
    return bigDecimal;
  }

  
  public BigDecimal getMoney(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getMoney", paramString);
    checkClosed();
    BigDecimal bigDecimal = (BigDecimal)getValue(findColumn(paramString), JDBCType.MONEY);
    loggerExternal.exiting(getClassNameLogging(), "getMoney", bigDecimal);
    return bigDecimal;
  }

  
  public BigDecimal getSmallMoney(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getSmallMoney", Integer.valueOf(paramInt));
    checkClosed();
    BigDecimal bigDecimal = (BigDecimal)getValue(paramInt, JDBCType.SMALLMONEY);
    loggerExternal.exiting(getClassNameLogging(), "getSmallMoney", bigDecimal);
    return bigDecimal;
  }

  
  public BigDecimal getSmallMoney(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getSmallMoney", paramString);
    checkClosed();
    BigDecimal bigDecimal = (BigDecimal)getValue(findColumn(paramString), JDBCType.SMALLMONEY);
    loggerExternal.exiting(getClassNameLogging(), "getSmallMoney", bigDecimal);
    return bigDecimal;
  }

  
  public final InputStream getBinaryStream(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getBinaryStream", Integer.valueOf(paramInt));
    checkClosed();
    InputStream inputStream = (InputStream)getStream(paramInt, StreamType.BINARY);
    loggerExternal.exiting(getClassNameLogging(), "getBinaryStream", inputStream);
    return inputStream;
  }

  
  public final InputStream getBinaryStream(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getBinaryStream", paramString);
    checkClosed();
    InputStream inputStream = (InputStream)getStream(findColumn(paramString), StreamType.BINARY);
    loggerExternal.exiting(getClassNameLogging(), "getBinaryStream", inputStream);
    return inputStream;
  }

  
  public Blob getBlob(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getBlob", Integer.valueOf(paramInt));
    checkClosed();
    Blob blob = (Blob)getValue(paramInt, JDBCType.BLOB);
    loggerExternal.exiting(getClassNameLogging(), "getBlob", blob);
    return blob;
  }

  
  public Blob getBlob(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getBlob", paramString);
    checkClosed();
    Blob blob = (Blob)getValue(findColumn(paramString), JDBCType.BLOB);
    loggerExternal.exiting(getClassNameLogging(), "getBlob", blob);
    return blob;
  }

  
  public final Reader getCharacterStream(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getCharacterStream", Integer.valueOf(paramInt));
    checkClosed();
    Reader reader = (Reader)getStream(paramInt, StreamType.CHARACTER);
    loggerExternal.exiting(getClassNameLogging(), "getCharacterStream", reader);
    return reader;
  }

  
  public final Reader getCharacterStream(String paramString) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    
    loggerExternal.entering(getClassNameLogging(), "getCharacterStream", paramString);
    checkClosed();
    Reader reader = (Reader)getStream(findColumn(paramString), StreamType.CHARACTER);
    loggerExternal.exiting(getClassNameLogging(), "getCharacterSream", reader);
    return reader;
  }

  
  public final Reader getNCharacterStream(int paramInt) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    loggerExternal.entering(getClassNameLogging(), "getNCharacterStream", Integer.valueOf(paramInt));
    checkClosed();
    Reader reader = (Reader)getStream(paramInt, StreamType.NCHARACTER);
    loggerExternal.exiting(getClassNameLogging(), "getNCharacterStream", reader);
    return reader;
  }

  
  public final Reader getNCharacterStream(String paramString) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    
    loggerExternal.entering(getClassNameLogging(), "getNCharacterStream", paramString);
    checkClosed();
    Reader reader = (Reader)getStream(findColumn(paramString), StreamType.NCHARACTER);
    loggerExternal.exiting(getClassNameLogging(), "getNCharacterStream", reader);
    return reader;
  }

  
  void closeActiveStream() throws SQLServerException {
    if (null != this.activeStream) {
      
      try {
        
        this.activeStream.close();
      }
      catch (IOException iOException) {
        
        SQLServerException.makeFromDriverError(null, null, iOException.getMessage(), null, true);
      }
      finally {
        
        this.activeStream = null;
      } 
    }
  }


  
  public Clob getClob(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getClob", Integer.valueOf(paramInt));
    checkClosed();
    Clob clob = (Clob)getValue(paramInt, JDBCType.CLOB);
    loggerExternal.exiting(getClassNameLogging(), "getClob", clob);
    return clob;
  }

  
  public Clob getClob(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getClob", paramString);
    checkClosed();
    Clob clob = (Clob)getValue(findColumn(paramString), JDBCType.CLOB);
    loggerExternal.exiting(getClassNameLogging(), "getClob", clob);
    return clob;
  }

  
  public NClob getNClob(int paramInt) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    loggerExternal.entering(getClassNameLogging(), "getNClob", Integer.valueOf(paramInt));
    checkClosed();
    NClob nClob = (NClob)getValue(paramInt, JDBCType.NCLOB);
    loggerExternal.exiting(getClassNameLogging(), "getNClob", nClob);
    return nClob;
  }

  
  public NClob getNClob(String paramString) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    loggerExternal.entering(getClassNameLogging(), "getNClob", paramString);
    checkClosed();
    NClob nClob = (NClob)getValue(findColumn(paramString), JDBCType.NCLOB);
    loggerExternal.exiting(getClassNameLogging(), "getNClob", nClob);
    return nClob;
  }
  
  public Object getObject(int paramInt, Map<String, Class<?>> paramMap) throws SQLServerException {
    NotImplemented();
    return null;
  }
  
  public Object getObject(String paramString, Map<String, Class<?>> paramMap) throws SQLServerException {
    checkClosed();
    return getObject(findColumn(paramString), paramMap);
  }
  
  public Ref getRef(int paramInt) throws SQLServerException {
    NotImplemented();
    return null;
  }
  public Ref getRef(String paramString) throws SQLServerException {
    checkClosed();
    return getRef(findColumn(paramString));
  }
  
  public Array getArray(int paramInt) throws SQLServerException {
    NotImplemented();
    return null;
  }
  public Array getArray(String paramString) throws SQLServerException {
    checkClosed();
    return getArray(findColumn(paramString));
  }











  
  private int findColumn(String paramString) throws SQLServerException {
    final class ThreePartNamesParser
    {
      private String procedurePart = null;
      private String ownerPart = null;
      private String databasePart = null;
      
      String getProcedurePart() { return this.procedurePart; }
      String getOwnerPart() { return this.ownerPart; } String getDatabasePart() {
        return this.databasePart;
      }








      
      private final Pattern threePartName = Pattern.compile(JDBCSyntaxTranslator.getSQLIdentifierWithGroups());



      
      final void parseProcedureNameIntoParts(String param1String) {
        if (null != param1String) {
          
          Matcher matcher = this.threePartName.matcher(param1String);
          if (matcher.matches()) {




            
            if (matcher.group(2) != null)
            {
              this.databasePart = matcher.group(1);

              
              matcher = this.threePartName.matcher(matcher.group(2));
              if (matcher.matches())
              {
                if (null != matcher.group(2))
                {
                  this.ownerPart = matcher.group(1);
                  this.procedurePart = matcher.group(2);
                }
                else
                {
                  this.ownerPart = this.databasePart;
                  this.databasePart = null;
                  this.procedurePart = matcher.group(1);
                
                }

              
              }
            
            }
            else
            {
              this.procedurePart = matcher.group(1);
            }
          
          } else {
            
            this.procedurePart = param1String;
          } 
        } 
      }
    };



    
    if (this.paramNames == null) {
      
      try {



        
        SQLServerStatement sQLServerStatement = (SQLServerStatement)this.connection.createStatement();
        ThreePartNamesParser threePartNamesParser = new ThreePartNamesParser();
        threePartNamesParser.parseProcedureNameIntoParts(this.procedureName);
        StringBuilder stringBuilder = new StringBuilder("exec sp_sproc_columns ");
        if (null != threePartNamesParser.getDatabasePart()) {
          
          stringBuilder.append("@procedure_qualifier=");
          stringBuilder.append(threePartNamesParser.getDatabasePart());
          stringBuilder.append(", ");
        } 
        if (null != threePartNamesParser.getOwnerPart()) {
          
          stringBuilder.append("@procedure_owner=");
          stringBuilder.append(threePartNamesParser.getOwnerPart());
          stringBuilder.append(", ");
        } 
        if (null != threePartNamesParser.getProcedurePart()) {

          
          stringBuilder.append("@procedure_name=");
          stringBuilder.append(threePartNamesParser.getProcedurePart());
          stringBuilder.append(" , @ODBCVer=3");
        
        }
        else {

          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_parameterNotDefinedForProcedure"));
          Object[] arrayOfObject = { paramString, "" };
          SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), "07009", false);
        } 
        
        SQLServerResultSet sQLServerResultSet = sQLServerStatement.executeQueryInternal(stringBuilder.toString());
        this.paramNames = new ArrayList<>();
        while (sQLServerResultSet.next())
        {
          String str = sQLServerResultSet.getString(4);
          this.paramNames.add(str.trim());
        }
      
      } catch (SQLException sQLException) {
        
        SQLServerException.makeFromDriverError(this.connection, this, sQLException.toString(), null, false);
      } 
    }
    
    int i = 0;
    if (this.paramNames != null) {
      i = this.paramNames.size();
    }






    
    byte b = 0;
    byte b1 = -1;

    
    for (b = 0; b < i; b++) {
      
      String str = this.paramNames.get(b);
      str = str.substring(1, str.length());
      if (str.equals(paramString)) {
        
        b1 = b;
        
        break;
      } 
    } 
    if (-1 == b1)
    {

      
      for (b = 0; b < i; b++) {
        
        String str = this.paramNames.get(b);
        str = str.substring(1, str.length());
        if (str.equalsIgnoreCase(paramString)) {
          
          b1 = b;
          
          break;
        } 
      } 
    }
    if (-1 == b1) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_parameterNotDefinedForProcedure"));
      Object[] arrayOfObject = { paramString, this.procedureName };
      SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), "07009", false);
    } 

    
    if (this.bReturnValueSyntax) {
      return b1 + 1;
    }
    return b1;
  }

  
  public void setTimestamp(String paramString, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setTimeStamp", new Object[] { paramString, paramTimestamp, paramCalendar }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, paramCalendar, false);
    loggerExternal.exiting(getClassNameLogging(), "setTimeStamp");
  }

  
  public void setTimestamp(String paramString, Timestamp paramTimestamp, Calendar paramCalendar, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setTimeStamp", new Object[] { paramString, paramTimestamp, paramCalendar, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, paramCalendar, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setTimeStamp");
  }

  
  public void setTime(String paramString, Time paramTime, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { paramString, paramTime, paramCalendar }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.TIME, paramTime, JavaType.TIME, paramCalendar, false);
    loggerExternal.exiting(getClassNameLogging(), "setTime");
  }

  
  public void setTime(String paramString, Time paramTime, Calendar paramCalendar, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { paramString, paramTime, paramCalendar, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.TIME, paramTime, JavaType.TIME, paramCalendar, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setTime");
  }

  
  public void setDate(String paramString, Date paramDate, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setDate", new Object[] { paramString, paramDate, paramCalendar }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.DATE, paramDate, JavaType.DATE, paramCalendar, false);
    loggerExternal.exiting(getClassNameLogging(), "setDate");
  }

  
  public void setDate(String paramString, Date paramDate, Calendar paramCalendar, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setDate", new Object[] { paramString, paramDate, paramCalendar, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.DATE, paramDate, JavaType.DATE, paramCalendar, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setDate");
  }

  
  public final void setCharacterStream(String paramString, Reader paramReader) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setCharacterStream", new Object[] { paramString, paramReader }); 
    checkClosed();
    setStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, -1L);
    loggerExternal.exiting(getClassNameLogging(), "setCharacterStream");
  }

  
  public final void setCharacterStream(String paramString, Reader paramReader, int paramInt) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setCharacterStream", new Object[] { paramString, paramReader, Integer.valueOf(paramInt) }); 
    checkClosed();
    setStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, paramInt);
    loggerExternal.exiting(getClassNameLogging(), "setCharacterStream");
  }


  
  public final void setCharacterStream(String paramString, Reader paramReader, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setCharacterStream", new Object[] { paramString, paramReader, Long.valueOf(paramLong) }); 
    checkClosed();
    setStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, paramLong);
    loggerExternal.exiting(getClassNameLogging(), "setCharacterStream");
  }

  
  public final void setNCharacterStream(String paramString, Reader paramReader) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setNCharacterStream", new Object[] { paramString, paramReader }); 
    checkClosed();
    setStream(findColumn(paramString), StreamType.NCHARACTER, paramReader, JavaType.READER, -1L);
    loggerExternal.exiting(getClassNameLogging(), "setNCharacterStream");
  }

  
  public final void setNCharacterStream(String paramString, Reader paramReader, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setNCharacterStream", new Object[] { paramString, paramReader, Long.valueOf(paramLong) }); 
    checkClosed();
    setStream(findColumn(paramString), StreamType.NCHARACTER, paramReader, JavaType.READER, paramLong);
    loggerExternal.exiting(getClassNameLogging(), "setNCharacterStream");
  }

  
  public final void setClob(String paramString, Clob paramClob) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setClob", new Object[] { paramString, paramClob }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.CLOB, paramClob, JavaType.CLOB, false);
    loggerExternal.exiting(getClassNameLogging(), "setClob");
  }

  
  public final void setClob(String paramString, Reader paramReader) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setClob", new Object[] { paramString, paramReader }); 
    checkClosed();
    setStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, -1L);
    loggerExternal.exiting(getClassNameLogging(), "setClob");
  }

  
  public final void setClob(String paramString, Reader paramReader, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setClob", new Object[] { paramString, paramReader, Long.valueOf(paramLong) }); 
    checkClosed();
    setStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, paramLong);
    loggerExternal.exiting(getClassNameLogging(), "setClob");
  }

  
  public final void setNClob(String paramString, NClob paramNClob) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setNClob", new Object[] { paramString, paramNClob }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.NCLOB, paramNClob, JavaType.NCLOB, false);
    loggerExternal.exiting(getClassNameLogging(), "setNClob");
  }

  
  public final void setNClob(String paramString, Reader paramReader) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setNClob", new Object[] { paramString, paramReader }); 
    checkClosed();
    setStream(findColumn(paramString), StreamType.NCHARACTER, paramReader, JavaType.READER, -1L);
    loggerExternal.exiting(getClassNameLogging(), "setNClob");
  }

  
  public final void setNClob(String paramString, Reader paramReader, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setNClob", new Object[] { paramString, paramReader, Long.valueOf(paramLong) }); 
    checkClosed();
    setStream(findColumn(paramString), StreamType.NCHARACTER, paramReader, JavaType.READER, paramLong);
    loggerExternal.exiting(getClassNameLogging(), "setNClob");
  }

  
  public final void setNString(String paramString1, String paramString2) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setNString", new Object[] { paramString1, paramString2 }); 
    checkClosed();
    setValue(findColumn(paramString1), JDBCType.NVARCHAR, paramString2, JavaType.STRING, false);
    loggerExternal.exiting(getClassNameLogging(), "setNString");
  }

  
  public final void setNString(String paramString1, String paramString2, boolean paramBoolean) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setNString", new Object[] { paramString1, paramString2, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(findColumn(paramString1), JDBCType.NVARCHAR, paramString2, JavaType.STRING, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setNString");
  }

  
  public void setObject(String paramString, Object paramObject) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { paramString, paramObject }); 
    checkClosed();
    setObjectNoType(findColumn(paramString), paramObject, false);
    loggerExternal.exiting(getClassNameLogging(), "setObject");
  }

  
  public void setObject(String paramString, Object paramObject, int paramInt) throws SQLServerException {
    String str = null;
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { paramString, paramObject, Integer.valueOf(paramInt) }); 
    checkClosed();
    if (-153 == paramInt) {
      
      str = getTVPNameIfNull(findColumn(paramString), (String)null);
      setObject(setterGetParam(findColumn(paramString)), paramObject, JavaType.TVP, JDBCType.TVP, (Integer)null, (Integer)null, false, findColumn(paramString), str);
    } else {
      
      setObject(setterGetParam(findColumn(paramString)), paramObject, JavaType.of(paramObject), JDBCType.of(paramInt), (Integer)null, (Integer)null, false, findColumn(paramString), str);
    }  loggerExternal.exiting(getClassNameLogging(), "setObject");
  }

  
  public void setObject(String paramString, Object paramObject, SQLType paramSQLType) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { paramString, paramObject, paramSQLType });
    }
    
    setObject(paramString, paramObject, paramSQLType.getVendorTypeNumber().intValue());
    
    loggerExternal.exiting(getClassNameLogging(), "setObject");
  }

  
  public void setObject(String paramString, Object paramObject, int paramInt1, int paramInt2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { paramString, paramObject, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) }); 
    checkClosed();
    
    setObject(setterGetParam(findColumn(paramString)), paramObject, JavaType.of(paramObject), JDBCType.of(paramInt1), Integer.valueOf(paramInt2), (Integer)null, false, findColumn(paramString), (String)null);










    
    loggerExternal.exiting(getClassNameLogging(), "setObject");
  }

  
  public void setObject(String paramString, Object paramObject, int paramInt1, int paramInt2, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { paramString, paramObject, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean) }); 
    checkClosed();




    
    setObject(setterGetParam(findColumn(paramString)), paramObject, JavaType.of(paramObject), JDBCType.of(paramInt1), (2 == paramInt1 || 3 == paramInt1) ? Integer.valueOf(paramInt2) : null, (Integer)null, paramBoolean, findColumn(paramString), (String)null);











    
    loggerExternal.exiting(getClassNameLogging(), "setObject");
  }

  
  public void setObject(String paramString, Object paramObject, SQLType paramSQLType, int paramInt) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { paramString, paramObject, paramSQLType, Integer.valueOf(paramInt) });
    }
    
    setObject(paramString, paramObject, paramSQLType.getVendorTypeNumber().intValue(), paramInt);
    
    loggerExternal.exiting(getClassNameLogging(), "setObject");
  }

  
  public void setObject(String paramString, Object paramObject, SQLType paramSQLType, int paramInt, boolean paramBoolean) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { paramString, paramObject, paramSQLType, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) });
    }
    
    setObject(paramString, paramObject, paramSQLType.getVendorTypeNumber().intValue(), paramInt, paramBoolean);
    
    loggerExternal.exiting(getClassNameLogging(), "setObject");
  }

  
  public final void setObject(String paramString, Object paramObject, int paramInt1, Integer paramInteger, int paramInt2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { paramString, paramObject, Integer.valueOf(paramInt1), paramInteger, Integer.valueOf(paramInt2) }); 
    checkClosed();





    
    setObject(setterGetParam(findColumn(paramString)), paramObject, JavaType.of(paramObject), JDBCType.of(paramInt1), (2 == paramInt1 || 3 == paramInt1 || InputStream.class.isInstance(paramObject) || Reader.class.isInstance(paramObject)) ? Integer.valueOf(paramInt2) : null, paramInteger, false, findColumn(paramString), (String)null);














    
    loggerExternal.exiting(getClassNameLogging(), "setObject");
  }

  
  public final void setAsciiStream(String paramString, InputStream paramInputStream) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setAsciiStream", new Object[] { paramString, paramInputStream }); 
    DriverJDBCVersion.checkSupportsJDBC4();
    checkClosed();
    setStream(findColumn(paramString), StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, -1L);
    loggerExternal.exiting(getClassNameLogging(), "setAsciiStream");
  }

  
  public final void setAsciiStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setAsciiStream", new Object[] { paramString, paramInputStream, Integer.valueOf(paramInt) }); 
    checkClosed();
    setStream(findColumn(paramString), StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, paramInt);
    loggerExternal.exiting(getClassNameLogging(), "setAsciiStream");
  }

  
  public final void setAsciiStream(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setAsciiStream", new Object[] { paramString, paramInputStream, Long.valueOf(paramLong) }); 
    DriverJDBCVersion.checkSupportsJDBC4();
    checkClosed();
    setStream(findColumn(paramString), StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, paramLong);
    loggerExternal.exiting(getClassNameLogging(), "setAsciiStream");
  }


  
  public final void setBinaryStream(String paramString, InputStream paramInputStream) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBinaryStream", new Object[] { paramString, paramInputStream }); 
    checkClosed();
    setStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, -1L);
    loggerExternal.exiting(getClassNameLogging(), "setBinaryStream");
  }

  
  public final void setBinaryStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBinaryStream", new Object[] { paramString, paramInputStream, Integer.valueOf(paramInt) }); 
    checkClosed();
    setStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramInt);
    loggerExternal.exiting(getClassNameLogging(), "setBinaryStream");
  }

  
  public final void setBinaryStream(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBinaryStream", new Object[] { paramString, paramInputStream, Long.valueOf(paramLong) }); 
    checkClosed();
    setStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramLong);
    loggerExternal.exiting(getClassNameLogging(), "setBinaryStream");
  }

  
  public final void setBlob(String paramString, Blob paramBlob) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBlob", new Object[] { paramString, paramBlob }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.BLOB, paramBlob, JavaType.BLOB, false);
    loggerExternal.exiting(getClassNameLogging(), "setBlob");
  }

  
  public final void setBlob(String paramString, InputStream paramInputStream) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBlob", new Object[] { paramString, paramInputStream }); 
    checkClosed();
    setStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, -1L);
    loggerExternal.exiting(getClassNameLogging(), "setBlob");
  }

  
  public final void setBlob(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBlob", new Object[] { paramString, paramInputStream, Long.valueOf(paramLong) }); 
    checkClosed();
    setStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramLong);
    loggerExternal.exiting(getClassNameLogging(), "setBlob");
  }

  
  public void setTimestamp(String paramString, Timestamp paramTimestamp) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { paramString, paramTimestamp }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, false);
    loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
  }

  
  public void setTimestamp(String paramString, Timestamp paramTimestamp, int paramInt) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { paramString, paramTimestamp }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, (Integer)null, Integer.valueOf(paramInt), false);
    loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
  }

  
  public void setTimestamp(String paramString, Timestamp paramTimestamp, int paramInt, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { paramString, paramTimestamp, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, (Integer)null, Integer.valueOf(paramInt), paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
  }

  
  public void setDateTimeOffset(String paramString, DateTimeOffset paramDateTimeOffset) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setDateTimeOffset", new Object[] { paramString, paramDateTimeOffset }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET, false);
    loggerExternal.exiting(getClassNameLogging(), "setDateTimeOffset");
  }

  
  public void setDateTimeOffset(String paramString, DateTimeOffset paramDateTimeOffset, int paramInt) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setDateTimeOffset", new Object[] { paramString, paramDateTimeOffset }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET, (Integer)null, Integer.valueOf(paramInt), false);
    loggerExternal.exiting(getClassNameLogging(), "setDateTimeOffset");
  }

  
  public void setDateTimeOffset(String paramString, DateTimeOffset paramDateTimeOffset, int paramInt, boolean paramBoolean) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setDateTimeOffset", new Object[] { paramString, paramDateTimeOffset, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET, (Integer)null, Integer.valueOf(paramInt), paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setDateTimeOffset");
  }

  
  public void setDate(String paramString, Date paramDate) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setDate", new Object[] { paramString, paramDate }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.DATE, paramDate, JavaType.DATE, false);
    loggerExternal.exiting(getClassNameLogging(), "setDate");
  }

  
  public void setTime(String paramString, Time paramTime) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { paramString, paramTime }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.TIME, paramTime, JavaType.TIME, false);
    loggerExternal.exiting(getClassNameLogging(), "setTime");
  }

  
  public void setTime(String paramString, Time paramTime, int paramInt) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { paramString, paramTime }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.TIME, paramTime, JavaType.TIME, (Integer)null, Integer.valueOf(paramInt), false);
    loggerExternal.exiting(getClassNameLogging(), "setTime");
  }

  
  public void setTime(String paramString, Time paramTime, int paramInt, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { paramString, paramTime, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.TIME, paramTime, JavaType.TIME, (Integer)null, Integer.valueOf(paramInt), paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setTime");
  }
  
  public void setDateTime(String paramString, Timestamp paramTimestamp) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setDateTime", new Object[] { paramString, paramTimestamp }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.DATETIME, paramTimestamp, JavaType.TIMESTAMP, false);
    loggerExternal.exiting(getClassNameLogging(), "setDateTime");
  }

  
  public void setDateTime(String paramString, Timestamp paramTimestamp, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setDateTime", new Object[] { paramString, paramTimestamp, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.DATETIME, paramTimestamp, JavaType.TIMESTAMP, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setDateTime");
  }

  
  public void setSmallDateTime(String paramString, Timestamp paramTimestamp) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setSmallDateTime", new Object[] { paramString, paramTimestamp }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.SMALLDATETIME, paramTimestamp, JavaType.TIMESTAMP, false);
    loggerExternal.exiting(getClassNameLogging(), "setSmallDateTime");
  }

  
  public void setSmallDateTime(String paramString, Timestamp paramTimestamp, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setSmallDateTime", new Object[] { paramString, paramTimestamp, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.SMALLDATETIME, paramTimestamp, JavaType.TIMESTAMP, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setSmallDateTime");
  }

  
  public void setUniqueIdentifier(String paramString1, String paramString2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setUniqueIdentifier", new Object[] { paramString1, paramString2 }); 
    checkClosed();
    setValue(findColumn(paramString1), JDBCType.GUID, paramString2, JavaType.STRING, false);
    loggerExternal.exiting(getClassNameLogging(), "setUniqueIdentifier");
  }

  
  public void setUniqueIdentifier(String paramString1, String paramString2, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setUniqueIdentifier", new Object[] { paramString1, paramString2, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(findColumn(paramString1), JDBCType.GUID, paramString2, JavaType.STRING, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setUniqueIdentifier");
  }

  
  public void setBytes(String paramString, byte[] paramArrayOfbyte) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBytes", new Object[] { paramString, paramArrayOfbyte }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.BINARY, paramArrayOfbyte, JavaType.BYTEARRAY, false);
    loggerExternal.exiting(getClassNameLogging(), "setBytes");
  }

  
  public void setBytes(String paramString, byte[] paramArrayOfbyte, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBytes", new Object[] { paramString, paramArrayOfbyte, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.BINARY, paramArrayOfbyte, JavaType.BYTEARRAY, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setBytes");
  }

  
  public void setByte(String paramString, byte paramByte) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setByte", new Object[] { paramString, Byte.valueOf(paramByte) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.TINYINT, Byte.valueOf(paramByte), JavaType.BYTE, false);
    loggerExternal.exiting(getClassNameLogging(), "setByte");
  }

  
  public void setByte(String paramString, byte paramByte, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setByte", new Object[] { paramString, Byte.valueOf(paramByte), Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.TINYINT, Byte.valueOf(paramByte), JavaType.BYTE, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setByte");
  }

  
  public void setString(String paramString1, String paramString2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setString", new Object[] { paramString1, paramString2 }); 
    checkClosed();
    setValue(findColumn(paramString1), JDBCType.VARCHAR, paramString2, JavaType.STRING, false);
    loggerExternal.exiting(getClassNameLogging(), "setString");
  }

  
  public void setString(String paramString1, String paramString2, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setString", new Object[] { paramString1, paramString2, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(findColumn(paramString1), JDBCType.VARCHAR, paramString2, JavaType.STRING, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setString");
  }

  
  public void setMoney(String paramString, BigDecimal paramBigDecimal) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setMoney", new Object[] { paramString, paramBigDecimal }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.MONEY, paramBigDecimal, JavaType.BIGDECIMAL, false);
    loggerExternal.exiting(getClassNameLogging(), "setMoney");
  }

  
  public void setMoney(String paramString, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setMoney", new Object[] { paramString, paramBigDecimal, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.MONEY, paramBigDecimal, JavaType.BIGDECIMAL, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setMoney");
  }

  
  public void setSmallMoney(String paramString, BigDecimal paramBigDecimal) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setSmallMoney", new Object[] { paramString, paramBigDecimal }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.SMALLMONEY, paramBigDecimal, JavaType.BIGDECIMAL, false);
    loggerExternal.exiting(getClassNameLogging(), "setSmallMoney");
  }

  
  public void setSmallMoney(String paramString, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setSmallMoney", new Object[] { paramString, paramBigDecimal, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.SMALLMONEY, paramBigDecimal, JavaType.BIGDECIMAL, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setSmallMoney");
  }

  
  public void setBigDecimal(String paramString, BigDecimal paramBigDecimal) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBigDecimal", new Object[] { paramString, paramBigDecimal }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, false);
    loggerExternal.exiting(getClassNameLogging(), "setBigDecimal");
  }

  
  public void setBigDecimal(String paramString, BigDecimal paramBigDecimal, int paramInt1, int paramInt2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBigDecimal", new Object[] { paramString, paramBigDecimal, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), false);
    loggerExternal.exiting(getClassNameLogging(), "setBigDecimal");
  }

  
  public void setBigDecimal(String paramString, BigDecimal paramBigDecimal, int paramInt1, int paramInt2, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBigDecimal", new Object[] { paramString, paramBigDecimal, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setBigDecimal");
  }

  
  public void setDouble(String paramString, double paramDouble) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setDouble", new Object[] { paramString, Double.valueOf(paramDouble) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.DOUBLE, Double.valueOf(paramDouble), JavaType.DOUBLE, false);
    loggerExternal.exiting(getClassNameLogging(), "setDouble");
  }

  
  public void setDouble(String paramString, double paramDouble, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setDouble", new Object[] { paramString, Double.valueOf(paramDouble), Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.DOUBLE, Double.valueOf(paramDouble), JavaType.DOUBLE, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setDouble");
  }

  
  public void setFloat(String paramString, float paramFloat) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setFloat", new Object[] { paramString, Float.valueOf(paramFloat) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.REAL, Float.valueOf(paramFloat), JavaType.FLOAT, false);
    loggerExternal.exiting(getClassNameLogging(), "setFloat");
  }

  
  public void setFloat(String paramString, float paramFloat, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setFloat", new Object[] { paramString, Float.valueOf(paramFloat), Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.REAL, Float.valueOf(paramFloat), JavaType.FLOAT, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setFloat");
  }

  
  public void setInt(String paramString, int paramInt) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setInt", new Object[] { paramString, Integer.valueOf(paramInt) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.INTEGER, Integer.valueOf(paramInt), JavaType.INTEGER, false);
    loggerExternal.exiting(getClassNameLogging(), "setInt");
  }

  
  public void setInt(String paramString, int paramInt, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setInt", new Object[] { paramString, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.INTEGER, Integer.valueOf(paramInt), JavaType.INTEGER, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setInt");
  }

  
  public void setLong(String paramString, long paramLong) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setLong", new Object[] { paramString, Long.valueOf(paramLong) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.BIGINT, Long.valueOf(paramLong), JavaType.LONG, false);
    loggerExternal.exiting(getClassNameLogging(), "setLong");
  }

  
  public void setLong(String paramString, long paramLong, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setLong", new Object[] { paramString, Long.valueOf(paramLong), Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.BIGINT, Long.valueOf(paramLong), JavaType.LONG, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setLong");
  }

  
  public void setShort(String paramString, short paramShort) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setShort", new Object[] { paramString, Short.valueOf(paramShort) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.SMALLINT, Short.valueOf(paramShort), JavaType.SHORT, false);
    loggerExternal.exiting(getClassNameLogging(), "setShort");
  }

  
  public void setShort(String paramString, short paramShort, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setShort", new Object[] { paramString, Short.valueOf(paramShort), Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.SMALLINT, Short.valueOf(paramShort), JavaType.SHORT, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setShort");
  }

  
  public void setBoolean(String paramString, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBoolean", new Object[] { paramString, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.BIT, Boolean.valueOf(paramBoolean), JavaType.BOOLEAN, false);
    loggerExternal.exiting(getClassNameLogging(), "setBoolean");
  }

  
  public void setBoolean(String paramString, boolean paramBoolean1, boolean paramBoolean2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBoolean", new Object[] { paramString, Boolean.valueOf(paramBoolean1), Boolean.valueOf(paramBoolean2) }); 
    checkClosed();
    setValue(findColumn(paramString), JDBCType.BIT, Boolean.valueOf(paramBoolean1), JavaType.BOOLEAN, paramBoolean2);
    loggerExternal.exiting(getClassNameLogging(), "setBoolean");
  }

  
  public void setNull(String paramString, int paramInt) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setNull", new Object[] { paramString, Integer.valueOf(paramInt) }); 
    checkClosed();
    setObject(setterGetParam(findColumn(paramString)), (Object)null, JavaType.OBJECT, JDBCType.of(paramInt), (Integer)null, (Integer)null, false, findColumn(paramString), (String)null);
    loggerExternal.exiting(getClassNameLogging(), "setNull");
  }

  
  public void setNull(String paramString1, int paramInt, String paramString2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setNull", new Object[] { paramString1, Integer.valueOf(paramInt), paramString2 }); 
    checkClosed();
    setObject(setterGetParam(findColumn(paramString1)), (Object)null, JavaType.OBJECT, JDBCType.of(paramInt), (Integer)null, (Integer)null, false, findColumn(paramString1), paramString2);
    loggerExternal.exiting(getClassNameLogging(), "setNull");
  }

  
  public void setURL(String paramString, URL paramURL) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "setURL", paramString);
    checkClosed();
    setURL(findColumn(paramString), paramURL);
    loggerExternal.exiting(getClassNameLogging(), "setURL");
  }

  
  public final void setStructured(String paramString1, String paramString2, SQLServerDataTable paramSQLServerDataTable) throws SQLServerException {
    paramString2 = getTVPNameIfNull(findColumn(paramString1), paramString2);
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setStructured", new Object[] { paramString1, paramString2, paramSQLServerDataTable }); 
    checkClosed();
    setValue(findColumn(paramString1), JDBCType.TVP, paramSQLServerDataTable, JavaType.TVP, paramString2);
    loggerExternal.exiting(getClassNameLogging(), "setStructured");
  }

  
  public final void setStructured(String paramString1, String paramString2, ResultSet paramResultSet) throws SQLServerException {
    paramString2 = getTVPNameIfNull(findColumn(paramString1), paramString2);
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setStructured", new Object[] { paramString1, paramString2, paramResultSet }); 
    checkClosed();
    setValue(findColumn(paramString1), JDBCType.TVP, paramResultSet, JavaType.TVP, paramString2);
    loggerExternal.exiting(getClassNameLogging(), "setStructured");
  }

  
  public final void setStructured(String paramString1, String paramString2, ISQLServerDataRecord paramISQLServerDataRecord) throws SQLServerException {
    paramString2 = getTVPNameIfNull(findColumn(paramString1), paramString2);
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setStructured", new Object[] { paramString1, paramString2, paramISQLServerDataRecord }); 
    checkClosed();
    setValue(findColumn(paramString1), JDBCType.TVP, paramISQLServerDataRecord, JavaType.TVP, paramString2);
    loggerExternal.exiting(getClassNameLogging(), "setStructured");
  }

  
  public URL getURL(int paramInt) throws SQLServerException {
    NotImplemented();
    return null;
  }

  
  public URL getURL(String paramString) throws SQLServerException {
    NotImplemented();
    return null;
  }

  
  public final void setSQLXML(String paramString, SQLXML paramSQLXML) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setSQLXML", new Object[] { paramString, paramSQLXML }); 
    checkClosed();
    setSQLXMLInternal(findColumn(paramString), paramSQLXML);
    loggerExternal.exiting(getClassNameLogging(), "setSQLXML");
  }

  
  public final SQLXML getSQLXML(int paramInt) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    loggerExternal.entering(getClassNameLogging(), "getSQLXML", Integer.valueOf(paramInt));
    checkClosed();
    SQLServerSQLXML sQLServerSQLXML = (SQLServerSQLXML)getSQLXMLInternal(paramInt);
    loggerExternal.exiting(getClassNameLogging(), "getSQLXML", sQLServerSQLXML);
    return sQLServerSQLXML;
  }

  
  public final SQLXML getSQLXML(String paramString) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    loggerExternal.entering(getClassNameLogging(), "getSQLXML", paramString);
    checkClosed();
    SQLServerSQLXML sQLServerSQLXML = (SQLServerSQLXML)getSQLXMLInternal(findColumn(paramString));
    loggerExternal.exiting(getClassNameLogging(), "getSQLXML", sQLServerSQLXML);
    return sQLServerSQLXML;
  }

  
  public final void setRowId(String paramString, RowId paramRowId) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();

    
    throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
  }

  
  public final RowId getRowId(int paramInt) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();

    
    throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
  }

  
  public final RowId getRowId(String paramString) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();

    
    throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
  }

  
  public void registerOutParameter(String paramString1, int paramInt, String paramString2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { paramString1, new Integer(paramInt), paramString2 }); 
    checkClosed();
    registerOutParameter(findColumn(paramString1), paramInt, paramString2);
    loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
  }

  
  public void registerOutParameter(String paramString1, SQLType paramSQLType, String paramString2) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { paramString1, paramSQLType, paramString2 });
    }
    
    registerOutParameter(paramString1, paramSQLType.getVendorTypeNumber().intValue(), paramString2);
    
    loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
  }

  
  public void registerOutParameter(String paramString, int paramInt1, int paramInt2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { paramString, new Integer(paramInt1), new Integer(paramInt2) });
    }
    checkClosed();
    registerOutParameter(findColumn(paramString), paramInt1, paramInt2);
    loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
  }

  
  public void registerOutParameter(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { paramString, new Integer(paramInt1), new Integer(paramInt3) });
    }
    checkClosed();
    registerOutParameter(findColumn(paramString), paramInt1, paramInt2, paramInt3);
    loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
  }

  
  public void registerOutParameter(String paramString, SQLType paramSQLType, int paramInt) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { paramString, paramSQLType, new Integer(paramInt) });
    }

    
    registerOutParameter(paramString, paramSQLType.getVendorTypeNumber().intValue(), paramInt);
    
    loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
  }

  
  public void registerOutParameter(String paramString, SQLType paramSQLType, int paramInt1, int paramInt2) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { paramString, paramSQLType, new Integer(paramInt2) });
    }

    
    registerOutParameter(paramString, paramSQLType.getVendorTypeNumber().intValue(), paramInt1, paramInt2);
    
    loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
  }

  
  public void registerOutParameter(String paramString, int paramInt) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { paramString, new Integer(paramInt) }); 
    checkClosed();
    registerOutParameter(findColumn(paramString), paramInt);
    loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
  }

  
  public void registerOutParameter(String paramString, SQLType paramSQLType) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { paramString, paramSQLType });
    }
    
    registerOutParameter(paramString, paramSQLType.getVendorTypeNumber().intValue());
    
    loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
  }
}
