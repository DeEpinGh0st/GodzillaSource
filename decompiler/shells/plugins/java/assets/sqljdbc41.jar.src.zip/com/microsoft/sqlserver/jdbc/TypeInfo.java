package com.microsoft.sqlserver.jdbc;

import java.util.EnumMap;
import java.util.Map;





















































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































final class TypeInfo
{
  private int maxLength;
  private SSLenType ssLenType;
  private int precision;
  private int displaySize;
  private int scale;
  private short flags;
  private SSType ssType;
  private int userType;
  private String udtTypeName;
  private SQLCollation collation;
  private String charset;
  
  SSType getSSType() {
    return this.ssType;
  } SSLenType getSSLenType() { return this.ssLenType; }
  String getSSTypeName() { return (SSType.UDT == this.ssType) ? this.udtTypeName : this.ssType.toString(); }
  int getMaxLength() { return this.maxLength; }
  int getPrecision() { return this.precision; }
  int getDisplaySize() { return this.displaySize; }
  int getScale() { return this.scale; }
  SQLCollation getSQLCollation() { return this.collation; }
  void setSQLCollation(SQLCollation paramSQLCollation) { this.collation = paramSQLCollation; }
  String getCharset() { return this.charset; }
  boolean isNullable() { return (1 == (this.flags & 0x1)); }
  boolean isCaseSensitive() { return (2 == (this.flags & 0x2)); }
  boolean isSparseColumnSet() { return (1024 == (this.flags & 0x400)); } boolean isEncrypted() {
    return (2048 == (this.flags & 0x800));
  }
  static int UPDATABLE_READ_ONLY = 0;
  static int UPDATABLE_READ_WRITE = 1;
  static int UPDATABLE_UNKNOWN = 2; int getUpdatability() {
    return this.flags >> 2 & 0x3;
  } boolean isIdentity() {
    return (16 == (this.flags & 0x10));
  }
  
  byte[] getFlags() {
    byte[] arrayOfByte = new byte[2];
    arrayOfByte[0] = (byte)(this.flags & 0xFF);
    arrayOfByte[1] = (byte)(this.flags >> 8 & 0xFF);
    return arrayOfByte;
  }

  
  short getFlagsAsShort() {
    return this.flags;
  }
  
  void setFlags(Short paramShort) {
    this.flags = paramShort.shortValue();
  }



  
  enum Builder
  {
    BIT((String)TDSType.BIT1, new FixedLenStrategy(SSType.BIT, 1, 1, "1".length(), 0)),






    
    BIGINT((String)TDSType.INT8, new FixedLenStrategy(SSType.BIGINT, 8, Long.toString(Long.MAX_VALUE).length(), ("-" + Long.toString(Long.MAX_VALUE)).length(), 0)),






    
    INTEGER((String)TDSType.INT4, new FixedLenStrategy(SSType.INTEGER, 4, Integer.toString(2147483647).length(), ("-" + Integer.toString(2147483647)).length(), 0)),






    
    SMALLINT((String)TDSType.INT2, new FixedLenStrategy(SSType.SMALLINT, 2, Short.toString('翿').length(), ("-" + Short.toString('翿')).length(), 0)),






    
    TINYINT((String)TDSType.INT1, new FixedLenStrategy(SSType.TINYINT, 1, Byte.toString(127).length(), Byte.toString(127).length(), 0)),






    
    REAL((String)TDSType.FLOAT4, new FixedLenStrategy(SSType.REAL, 4, 7, 13, 0)),






    
    FLOAT((String)TDSType.FLOAT8, new FixedLenStrategy(SSType.FLOAT, 8, 15, 22, 0)),






    
    SMALLDATETIME((String)TDSType.DATETIME4, new FixedLenStrategy(SSType.SMALLDATETIME, 4, "yyyy-mm-dd hh:mm".length(), "yyyy-mm-dd hh:mm".length(), 0)),






    
    DATETIME((String)TDSType.DATETIME8, new FixedLenStrategy(SSType.DATETIME, 8, "yyyy-mm-dd hh:mm:ss.fff".length(), "yyyy-mm-dd hh:mm:ss.fff".length(), 3)),






    
    SMALLMONEY((String)TDSType.MONEY4, new FixedLenStrategy(SSType.SMALLMONEY, 4, Integer.toString(2147483647).length(), ("-." + Integer.toString(2147483647)).length(), 4)),






    
    MONEY((String)TDSType.MONEY8, new FixedLenStrategy(SSType.MONEY, 8, Long.toString(Long.MAX_VALUE).length(), ("-." + Long.toString(Long.MAX_VALUE)).length(), 4)),






    
    BITN((String)TDSType.BITN, new Strategy()
      {
        public void apply(TypeInfo param2TypeInfo, TDSReader param2TDSReader) throws SQLServerException
        {
          if (1 != param2TDSReader.readUnsignedByte()) {
            param2TDSReader.throwInvalidTDS();
          }
          TypeInfo.Builder.BIT.build(param2TypeInfo, param2TDSReader);
          param2TypeInfo.ssLenType = SSLenType.BYTELENTYPE;
        }
      }),
    
    INTN((String)TDSType.INTN, new Strategy()
      {
        public void apply(TypeInfo param2TypeInfo, TDSReader param2TDSReader) throws SQLServerException
        {
          switch (param2TDSReader.readUnsignedByte()) {
            case 8:
              TypeInfo.Builder.BIGINT.build(param2TypeInfo, param2TDSReader); break;
            case 4: TypeInfo.Builder.INTEGER.build(param2TypeInfo, param2TDSReader); break;
            case 2: TypeInfo.Builder.SMALLINT.build(param2TypeInfo, param2TDSReader); break;
            case 1: TypeInfo.Builder.TINYINT.build(param2TypeInfo, param2TDSReader); break;
            default: param2TDSReader.throwInvalidTDS();
              break;
          } 
          param2TypeInfo.ssLenType = SSLenType.BYTELENTYPE;
        }
      }),
    
    DECIMAL((String)TDSType.DECIMALN, new DecimalNumericStrategy(SSType.DECIMAL)),
    NUMERIC((String)TDSType.NUMERICN, new DecimalNumericStrategy(SSType.NUMERIC)),
    FLOATN((String)TDSType.FLOATN, new BigOrSmallByteLenStrategy(FLOAT, REAL)),
    MONEYN((String)TDSType.MONEYN, new BigOrSmallByteLenStrategy(MONEY, SMALLMONEY)),
    DATETIMEN((String)TDSType.DATETIMEN, new BigOrSmallByteLenStrategy(DATETIME, SMALLDATETIME)),
    
    TIME((String)TDSType.TIMEN, new KatmaiScaledTemporalStrategy(SSType.TIME)),
    DATETIME2((String)TDSType.DATETIME2N, new KatmaiScaledTemporalStrategy(SSType.DATETIME2)),
    DATETIMEOFFSET((String)TDSType.DATETIMEOFFSETN, new KatmaiScaledTemporalStrategy(SSType.DATETIMEOFFSET)),
    
    DATE((String)TDSType.DATEN, new Strategy()
      {
        public void apply(TypeInfo param2TypeInfo, TDSReader param2TDSReader) throws SQLServerException
        {
          param2TypeInfo.ssType = SSType.DATE;
          param2TypeInfo.ssLenType = SSLenType.BYTELENTYPE;
          param2TypeInfo.maxLength = 3;
          param2TypeInfo.displaySize = param2TypeInfo.precision = "yyyy-mm-dd".length();
        }
      }),
    
    BIGBINARY((String)TDSType.BIGBINARY, new Strategy()
      {
        public void apply(TypeInfo param2TypeInfo, TDSReader param2TDSReader) throws SQLServerException
        {
          param2TypeInfo.ssLenType = SSLenType.USHORTLENTYPE;
          param2TypeInfo.maxLength = param2TDSReader.readUnsignedShort();
          if (param2TypeInfo.maxLength > 8000)
            param2TDSReader.throwInvalidTDS(); 
          param2TypeInfo.precision = param2TypeInfo.maxLength;
          param2TypeInfo.displaySize = 2 * param2TypeInfo.maxLength;
          param2TypeInfo.ssType = (80 == param2TypeInfo.userType) ? SSType.TIMESTAMP : SSType.BINARY;
        }
      }),

    
    BIGVARBINARY((String)TDSType.BIGVARBINARY, new Strategy()
      {
        public void apply(TypeInfo param2TypeInfo, TDSReader param2TDSReader) throws SQLServerException
        {
          param2TypeInfo.maxLength = param2TDSReader.readUnsignedShort();
          if (65535 == param2TypeInfo.maxLength)
          {
            param2TypeInfo.ssLenType = SSLenType.PARTLENTYPE;
            param2TypeInfo.ssType = SSType.VARBINARYMAX;
            param2TypeInfo.displaySize = param2TypeInfo.precision = 2147483647;
          }
          else if (param2TypeInfo.maxLength <= 8000)
          {
            param2TypeInfo.ssLenType = SSLenType.USHORTLENTYPE;
            param2TypeInfo.ssType = SSType.VARBINARY;
            param2TypeInfo.precision = param2TypeInfo.maxLength;
            param2TypeInfo.displaySize = 2 * param2TypeInfo.maxLength;
          }
          else
          {
            param2TDSReader.throwInvalidTDS();
          }
        
        }
      }),
    IMAGE((String)TDSType.IMAGE, new Strategy()
      {
        public void apply(TypeInfo param2TypeInfo, TDSReader param2TDSReader) throws SQLServerException
        {
          param2TypeInfo.ssLenType = SSLenType.LONGLENTYPE;
          param2TypeInfo.maxLength = param2TDSReader.readInt();
          if (param2TypeInfo.maxLength < 0)
            param2TDSReader.throwInvalidTDS(); 
          param2TypeInfo.ssType = SSType.IMAGE;
          param2TypeInfo.displaySize = param2TypeInfo.precision = 2147483647;
        }
      }),
    
    BIGCHAR((String)TDSType.BIGCHAR, new Strategy()
      {
        public void apply(TypeInfo param2TypeInfo, TDSReader param2TDSReader) throws SQLServerException
        {
          param2TypeInfo.ssLenType = SSLenType.USHORTLENTYPE;
          param2TypeInfo.maxLength = param2TDSReader.readUnsignedShort();
          if (param2TypeInfo.maxLength > 8000)
            param2TDSReader.throwInvalidTDS(); 
          param2TypeInfo.displaySize = param2TypeInfo.precision = param2TypeInfo.maxLength;
          param2TypeInfo.ssType = SSType.CHAR;
          param2TypeInfo.collation = param2TDSReader.readCollation();
          param2TypeInfo.charset = param2TypeInfo.collation.getCharset();
        }
      }),
    
    BIGVARCHAR((String)TDSType.BIGVARCHAR, new Strategy()
      {
        public void apply(TypeInfo param2TypeInfo, TDSReader param2TDSReader) throws SQLServerException
        {
          param2TypeInfo.maxLength = param2TDSReader.readUnsignedShort();
          if (65535 == param2TypeInfo.maxLength) {
            
            param2TypeInfo.ssLenType = SSLenType.PARTLENTYPE;
            param2TypeInfo.ssType = SSType.VARCHARMAX;
            param2TypeInfo.displaySize = param2TypeInfo.precision = 2147483647;
          }
          else if (param2TypeInfo.maxLength <= 8000) {
            
            param2TypeInfo.ssLenType = SSLenType.USHORTLENTYPE;
            param2TypeInfo.ssType = SSType.VARCHAR;
            param2TypeInfo.displaySize = param2TypeInfo.precision = param2TypeInfo.maxLength;
          }
          else {
            
            param2TDSReader.throwInvalidTDS();
          } 
          
          param2TypeInfo.collation = param2TDSReader.readCollation();
          param2TypeInfo.charset = param2TypeInfo.collation.getCharset();
        }
      }),
    
    TEXT((String)TDSType.TEXT, new Strategy()
      {
        public void apply(TypeInfo param2TypeInfo, TDSReader param2TDSReader) throws SQLServerException
        {
          param2TypeInfo.ssLenType = SSLenType.LONGLENTYPE;
          param2TypeInfo.maxLength = param2TDSReader.readInt();
          if (param2TypeInfo.maxLength < 0)
            param2TDSReader.throwInvalidTDS(); 
          param2TypeInfo.ssType = SSType.TEXT;
          param2TypeInfo.displaySize = param2TypeInfo.precision = 2147483647;
          param2TypeInfo.collation = param2TDSReader.readCollation();
          param2TypeInfo.charset = param2TypeInfo.collation.getCharset();
        }
      }),
    
    NCHAR((String)TDSType.NCHAR, new Strategy()
      {
        public void apply(TypeInfo param2TypeInfo, TDSReader param2TDSReader) throws SQLServerException
        {
          param2TypeInfo.ssLenType = SSLenType.USHORTLENTYPE;
          param2TypeInfo.maxLength = param2TDSReader.readUnsignedShort();
          if (param2TypeInfo.maxLength > 8000 || 0 != param2TypeInfo.maxLength % 2)
            param2TDSReader.throwInvalidTDS(); 
          param2TypeInfo.displaySize = param2TypeInfo.precision = param2TypeInfo.maxLength / 2;
          param2TypeInfo.ssType = SSType.NCHAR;
          param2TypeInfo.collation = param2TDSReader.readCollation();
          param2TypeInfo.charset = Encoding.UNICODE.charsetName();
        }
      }),
    
    NVARCHAR((String)TDSType.NVARCHAR, new Strategy()
      {
        public void apply(TypeInfo param2TypeInfo, TDSReader param2TDSReader) throws SQLServerException
        {
          param2TypeInfo.maxLength = param2TDSReader.readUnsignedShort();
          if (65535 == param2TypeInfo.maxLength) {
            
            param2TypeInfo.ssLenType = SSLenType.PARTLENTYPE;
            param2TypeInfo.ssType = SSType.NVARCHARMAX;
            param2TypeInfo.displaySize = param2TypeInfo.precision = 1073741823;
          }
          else if (param2TypeInfo.maxLength <= 8000 && 0 == param2TypeInfo.maxLength % 2) {
            
            param2TypeInfo.ssLenType = SSLenType.USHORTLENTYPE;
            param2TypeInfo.ssType = SSType.NVARCHAR;
            param2TypeInfo.displaySize = param2TypeInfo.precision = param2TypeInfo.maxLength / 2;
          }
          else {
            
            param2TDSReader.throwInvalidTDS();
          } 
          param2TypeInfo.collation = param2TDSReader.readCollation();
          param2TypeInfo.charset = Encoding.UNICODE.charsetName();
        }
      }),
    
    NTEXT((String)TDSType.NTEXT, new Strategy()
      {
        public void apply(TypeInfo param2TypeInfo, TDSReader param2TDSReader) throws SQLServerException
        {
          param2TypeInfo.ssLenType = SSLenType.LONGLENTYPE;
          param2TypeInfo.maxLength = param2TDSReader.readInt();
          if (param2TypeInfo.maxLength < 0)
            param2TDSReader.throwInvalidTDS(); 
          param2TypeInfo.ssType = SSType.NTEXT;
          param2TypeInfo.displaySize = param2TypeInfo.precision = 1073741823;
          param2TypeInfo.collation = param2TDSReader.readCollation();
          param2TypeInfo.charset = Encoding.UNICODE.charsetName();
        }
      }),
    
    GUID((String)TDSType.GUID, new Strategy()
      {
        public void apply(TypeInfo param2TypeInfo, TDSReader param2TDSReader) throws SQLServerException
        {
          int i = param2TDSReader.readUnsignedByte();
          if (i != 16 && i != 0) {
            param2TDSReader.throwInvalidTDS();
          }
          param2TypeInfo.ssLenType = SSLenType.BYTELENTYPE;
          param2TypeInfo.ssType = SSType.GUID;
          param2TypeInfo.maxLength = i;
          param2TypeInfo.displaySize = param2TypeInfo.precision = "NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN".length();
        }
      }),

    
    UDT((String)TDSType.UDT, new Strategy()
      {
        public void apply(TypeInfo param2TypeInfo, TDSReader param2TDSReader) throws SQLServerException
        {
          UDTTDSHeader uDTTDSHeader = new UDTTDSHeader(param2TDSReader);
          param2TypeInfo.maxLength = uDTTDSHeader.getMaxLen();
          if (65535 == param2TypeInfo.maxLength) {
            
            param2TypeInfo.precision = 2147483647;
            param2TypeInfo.displaySize = 2147483647;
          }
          else if (param2TypeInfo.maxLength <= 8000) {
            
            param2TypeInfo.precision = param2TypeInfo.maxLength;
            param2TypeInfo.displaySize = 2 * param2TypeInfo.maxLength;
          }
          else {
            
            param2TDSReader.throwInvalidTDS();
          } 
          
          param2TypeInfo.ssLenType = SSLenType.PARTLENTYPE;
          param2TypeInfo.ssType = SSType.UDT;



          
          param2TypeInfo.udtTypeName = uDTTDSHeader.getTypeName();
        }
      }),
    
    XML((String)TDSType.XML, new Strategy()
      {
        public void apply(TypeInfo param2TypeInfo, TDSReader param2TDSReader) throws SQLServerException
        {
          XMLTDSHeader xMLTDSHeader = new XMLTDSHeader(param2TDSReader);
          param2TypeInfo.ssLenType = SSLenType.PARTLENTYPE;
          param2TypeInfo.ssType = SSType.XML;
          param2TypeInfo.displaySize = param2TypeInfo.precision = 1073741823;
          param2TypeInfo.charset = Encoding.UNICODE.charsetName();
        }
      }),
    
    SQL_VARIANT((String)TDSType.SQL_VARIANT, new Strategy()
      {


        
        public void apply(TypeInfo param2TypeInfo, TDSReader param2TDSReader) throws SQLServerException
        {
          SQLServerException.makeFromDriverError(param2TDSReader.getConnection(), null, SQLServerException.getErrString("R_variantNotSupported"), "08006", false);
        }
      });


    
    private final TDSType tdsType;
    
    private final Strategy strategy;

    
    private static interface Strategy
    {
      void apply(TypeInfo param2TypeInfo, TDSReader param2TDSReader) throws SQLServerException;
    }

    
    private static final class FixedLenStrategy
      implements Strategy
    {
      private final SSType ssType;
      
      private final int maxLength;
      
      private final int precision;
      
      private final int displaySize;
      
      private final int scale;

      
      FixedLenStrategy(SSType param2SSType, int param2Int1, int param2Int2, int param2Int3, int param2Int4) {
        this.ssType = param2SSType;
        this.maxLength = param2Int1;
        this.precision = param2Int2;
        this.displaySize = param2Int3;
        this.scale = param2Int4;
      }

      
      public void apply(TypeInfo param2TypeInfo, TDSReader param2TDSReader) {
        param2TypeInfo.ssLenType = SSLenType.FIXEDLENTYPE;
        param2TypeInfo.ssType = this.ssType;
        param2TypeInfo.maxLength = this.maxLength;
        param2TypeInfo.precision = this.precision;
        param2TypeInfo.displaySize = this.displaySize;
        param2TypeInfo.scale = this.scale;
      }
    }
    
    private static final class DecimalNumericStrategy
      implements Strategy
    {
      private final SSType ssType;
      
      DecimalNumericStrategy(SSType param2SSType) {
        this.ssType = param2SSType;
      }

      
      public void apply(TypeInfo param2TypeInfo, TDSReader param2TDSReader) throws SQLServerException {
        int i = param2TDSReader.readUnsignedByte();
        int j = param2TDSReader.readUnsignedByte();
        int k = param2TDSReader.readUnsignedByte();
        
        if (i > 17) {
          param2TDSReader.throwInvalidTDS();
        }
        param2TypeInfo.ssLenType = SSLenType.BYTELENTYPE;
        param2TypeInfo.ssType = this.ssType;
        param2TypeInfo.maxLength = i;
        param2TypeInfo.precision = j;
        param2TypeInfo.displaySize = j + 2;
        param2TypeInfo.scale = k;
      }
    }
    
    private static final class BigOrSmallByteLenStrategy
      implements Strategy
    {
      private final TypeInfo.Builder bigBuilder;
      private final TypeInfo.Builder smallBuilder;
      
      BigOrSmallByteLenStrategy(TypeInfo.Builder param2Builder1, TypeInfo.Builder param2Builder2) {
        this.bigBuilder = param2Builder1;
        this.smallBuilder = param2Builder2;
      }

      
      public void apply(TypeInfo param2TypeInfo, TDSReader param2TDSReader) throws SQLServerException {
        switch (param2TDSReader.readUnsignedByte()) {
          case 8:
            this.bigBuilder.build(param2TypeInfo, param2TDSReader); break;
          case 4: this.smallBuilder.build(param2TypeInfo, param2TDSReader); break;
          default: param2TDSReader.throwInvalidTDS();
            break;
        } 
        param2TypeInfo.ssLenType = SSLenType.BYTELENTYPE;
      }
    }
    
    private static final class KatmaiScaledTemporalStrategy
      implements Strategy
    {
      private final SSType ssType;
      
      KatmaiScaledTemporalStrategy(SSType param2SSType) {
        this.ssType = param2SSType;
      }



      
      private int getPrecision(String param2String, int param2Int) {
        return param2String.length() + ((param2Int > 0) ? (1 + param2Int) : 0);
      }

      
      public void apply(TypeInfo param2TypeInfo, TDSReader param2TDSReader) throws SQLServerException {
        param2TypeInfo.scale = param2TDSReader.readUnsignedByte();
        if (param2TypeInfo.scale > 7) {
          param2TDSReader.throwInvalidTDS();
        }
        switch (this.ssType) {
          
          case TIME:
            param2TypeInfo.precision = getPrecision("hh:mm:ss", param2TypeInfo.scale);
            param2TypeInfo.maxLength = TDS.timeValueLength(param2TypeInfo.scale);
            break;
          
          case DATETIME2:
            param2TypeInfo.precision = getPrecision("yyyy-mm-dd hh:mm:ss", param2TypeInfo.scale);
            param2TypeInfo.maxLength = TDS.datetime2ValueLength(param2TypeInfo.scale);
            break;
          
          case DATETIMEOFFSET:
            param2TypeInfo.precision = getPrecision("yyyy-mm-dd hh:mm:ss +HH:MM", param2TypeInfo.scale);
            param2TypeInfo.maxLength = TDS.datetimeoffsetValueLength(param2TypeInfo.scale);
            break;
          
          default:
            assert false : "Unexpected SSType: " + this.ssType;
            break;
        } 
        param2TypeInfo.ssLenType = SSLenType.BYTELENTYPE;
        param2TypeInfo.ssType = this.ssType;
        param2TypeInfo.displaySize = param2TypeInfo.precision;
      }
    }



    
    Builder(TDSType param1TDSType, Strategy param1Strategy) {
      this.tdsType = param1TDSType;
      this.strategy = param1Strategy;
    }
    final TDSType getTDSType() {
      return this.tdsType;
    }
    
    final TypeInfo build(TypeInfo param1TypeInfo, TDSReader param1TDSReader) throws SQLServerException {
      this.strategy.apply(param1TypeInfo, param1TDSReader);

      
      assert null != param1TypeInfo.ssType;
      assert null != param1TypeInfo.ssLenType;
      
      return param1TypeInfo;
    }
  }





  
  boolean supportsFastAsciiConversion() {
    switch (this.ssType) {
      
      case CHAR:
      case VARCHAR:
      case VARCHARMAX:
      case TEXT:
        return this.collation.hasAsciiCompatibleSBCS();
    } 
    
    return false;
  }

  
  private static final Map<TDSType, Builder> builderMap = new EnumMap<>(TDSType.class);


  
  static {
    for (Builder builder : Builder.values()) {
      builderMap.put(builder.getTDSType(), builder);
    }
  }


  
  static TypeInfo getInstance(TDSReader paramTDSReader, boolean paramBoolean) throws SQLServerException {
    TypeInfo typeInfo = new TypeInfo();

    
    typeInfo.userType = paramTDSReader.readInt();
    
    if (paramBoolean)
    {
      
      typeInfo.flags = paramTDSReader.readShort();
    }
    
    TDSType tDSType = null;

    
    try {
      tDSType = TDSType.valueOf(paramTDSReader.readUnsignedByte());
    }
    catch (IllegalArgumentException illegalArgumentException) {
      
      paramTDSReader.getConnection().terminate(4, illegalArgumentException.getMessage(), illegalArgumentException);
    } 

    
    assert null != builderMap.get(tDSType) : "Missing TypeInfo builder for TDSType " + tDSType;
    return ((Builder)builderMap.get(tDSType)).build(typeInfo, paramTDSReader);
  }
}
