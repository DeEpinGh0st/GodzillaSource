package com.microsoft.sqlserver.jdbc;


































































































































class CekTable
{
  CekTableEntry[] keyList;
  
  CekTable(int paramInt) {
    this.keyList = new CekTableEntry[paramInt];
  }

  
  int getSize() {
    return this.keyList.length;
  }

  
  CekTableEntry getCekTableEntry(int paramInt) {
    return this.keyList[paramInt];
  }

  
  void setCekTableEntry(int paramInt, CekTableEntry paramCekTableEntry) {
    this.keyList[paramInt] = paramCekTableEntry;
  }
}
