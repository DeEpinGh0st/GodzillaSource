package com.microsoft.sqlserver.jdbc;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.DriverPropertyInfo;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.text.MessageFormat;
import java.util.Enumeration;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;





















































































































































































































































































































































































































































































































































































































































































































































































































































































































































public final class SQLServerDriver
  implements Driver
{
  static final String PRODUCT_NAME = "Microsoft JDBC Driver 6.0 for SQL Server";
  static final String DEFAULT_APP_NAME = "Microsoft JDBC Driver for SQL Server";
  private static final String[] TRUE_FALSE = new String[] { "true", "false" };
  private static final SQLServerDriverPropertyInfo[] DRIVER_PROPERTIES = new SQLServerDriverPropertyInfo[] { new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.APPLICATION_INTENT.toString(), SQLServerDriverStringProperty.APPLICATION_INTENT.getDefaultValue(), false, new String[] { ApplicationIntent.READ_ONLY.toString(), ApplicationIntent.READ_WRITE.toString() }), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.APPLICATION_NAME.toString(), SQLServerDriverStringProperty.APPLICATION_NAME.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.COLUMN_ENCRYPTION.toString(), SQLServerDriverStringProperty.COLUMN_ENCRYPTION.getDefaultValue(), false, new String[] { ColumnEncryptionSetting.Disabled.toString(), ColumnEncryptionSetting.Enabled.toString() }), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.DATABASE_NAME.toString(), SQLServerDriverStringProperty.DATABASE_NAME.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.DISABLE_STATEMENT_POOLING.toString(), Boolean.toString(SQLServerDriverBooleanProperty.DISABLE_STATEMENT_POOLING.getDefaultValue()), false, new String[] { "true" }), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.ENCRYPT.toString(), Boolean.toString(SQLServerDriverBooleanProperty.ENCRYPT.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.FAILOVER_PARTNER.toString(), SQLServerDriverStringProperty.FAILOVER_PARTNER.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.HOSTNAME_IN_CERTIFICATE.toString(), SQLServerDriverStringProperty.HOSTNAME_IN_CERTIFICATE.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.INSTANCE_NAME.toString(), SQLServerDriverStringProperty.INSTANCE_NAME.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.INTEGRATED_SECURITY.toString(), Boolean.toString(SQLServerDriverBooleanProperty.INTEGRATED_SECURITY.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.KEY_STORE_AUTHENTICATION.toString(), SQLServerDriverStringProperty.KEY_STORE_AUTHENTICATION.getDefaultValue(), false, new String[] { KeyStoreAuthentication.JavaKeyStorePassword.toString() }), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.KEY_STORE_SECRET.toString(), SQLServerDriverStringProperty.KEY_STORE_SECRET.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.KEY_STORE_LOCATION.toString(), SQLServerDriverStringProperty.KEY_STORE_LOCATION.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.toString(), Boolean.toString(SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverIntProperty.LOCK_TIMEOUT.toString(), Integer.toString(SQLServerDriverIntProperty.LOCK_TIMEOUT.getDefaultValue()), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverIntProperty.LOGIN_TIMEOUT.toString(), Integer.toString(SQLServerDriverIntProperty.LOGIN_TIMEOUT.getDefaultValue()), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.toString(), Boolean.toString(SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverIntProperty.PACKET_SIZE.toString(), Integer.toString(SQLServerDriverIntProperty.PACKET_SIZE.getDefaultValue()), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.PASSWORD.toString(), SQLServerDriverStringProperty.PASSWORD.getDefaultValue(), true, null), new SQLServerDriverPropertyInfo(SQLServerDriverIntProperty.PORT_NUMBER.toString(), Integer.toString(SQLServerDriverIntProperty.PORT_NUMBER.getDefaultValue()), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.RESPONSE_BUFFERING.toString(), SQLServerDriverStringProperty.RESPONSE_BUFFERING.getDefaultValue(), false, new String[] { "adaptive", "full" }), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.SELECT_METHOD.toString(), SQLServerDriverStringProperty.SELECT_METHOD.getDefaultValue(), false, new String[] { "direct", "cursor" }), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.toString(), Boolean.toString(SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE.toString(), Boolean.toString(SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.SERVER_NAME.toString(), SQLServerDriverStringProperty.SERVER_NAME.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.SERVER_SPN.toString(), SQLServerDriverStringProperty.SERVER_SPN.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.TRANSPARENT_NETWORK_IP_RESOLUTION.toString(), Boolean.toString(SQLServerDriverBooleanProperty.TRANSPARENT_NETWORK_IP_RESOLUTION.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.toString(), Boolean.toString(SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.TRUST_STORE.toString(), SQLServerDriverStringProperty.TRUST_STORE.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString(), SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.toString(), Boolean.toString(SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.USER.toString(), SQLServerDriverStringProperty.USER.getDefaultValue(), true, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.WORKSTATION_ID.toString(), SQLServerDriverStringProperty.WORKSTATION_ID.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.XOPEN_STATES.toString(), Boolean.toString(SQLServerDriverBooleanProperty.XOPEN_STATES.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.AUTHENTICATION_SCHEME.toString(), SQLServerDriverStringProperty.AUTHENTICATION_SCHEME.getDefaultValue(), false, new String[] { AuthenticationScheme.javaKerberos.toString(), AuthenticationScheme.nativeAuthentication.toString() }), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.AUTHENTICATION.toString(), SQLServerDriverStringProperty.AUTHENTICATION.getDefaultValue(), false, new String[] { SqlAuthentication.NotSpecified.toString(), SqlAuthentication.SqlPassword.toString(), SqlAuthentication.ActiveDirectoryPassword.toString(), SqlAuthentication.ActiveDirectoryIntegrated.toString() }) };










































  
  private static final SQLServerDriverPropertyInfo[] DRIVER_PROPERTIES_PROPERTY_ONLY = new SQLServerDriverPropertyInfo[] { new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.ACCESS_TOKEN.toString(), SQLServerDriverStringProperty.ACCESS_TOKEN.getDefaultValue(), false, null) };





  
  private static final String[][] driverPropertiesSynonyms = new String[][] { { "database", SQLServerDriverStringProperty.DATABASE_NAME.toString() }, { "userName", SQLServerDriverStringProperty.USER.toString() }, { "server", SQLServerDriverStringProperty.SERVER_NAME.toString() }, { "port", SQLServerDriverIntProperty.PORT_NUMBER.toString() } };




  
  private static int baseID = 0;
  
  private final int instanceID;
  
  private final String traceID;
  
  private static synchronized int nextInstanceID() {
    baseID++;
    return baseID;
  }
  
  public final String toString() {
    return this.traceID;
  }
  private static final Logger loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.Driver");
  
  private final String loggingClassName;
  
  String getClassNameLogging() {
    return this.loggingClassName;
  }
  
  private static final Logger drLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerDriver");
  
  static {
    try {
      DriverManager.registerDriver(new SQLServerDriver());
    }
    catch (SQLException sQLException) {
      sQLException.printStackTrace();
    } 
  }

  
  public SQLServerDriver() {
    this.instanceID = nextInstanceID();
    this.traceID = "SQLServerDriver:" + this.instanceID;
    this.loggingClassName = "com.microsoft.sqlserver.jdbc.SQLServerDriver:" + this.instanceID;
  }




  
  static Properties fixupProperties(Properties paramProperties) throws SQLServerException {
    Properties properties = new Properties();
    Enumeration<String> enumeration = paramProperties.keys();
    while (enumeration.hasMoreElements()) {
      
      String str1 = enumeration.nextElement();
      String str2 = getNormalizedPropertyName(str1, drLogger);
      
      if (null == str2) {
        str2 = getPropertyOnlyName(str1, drLogger);
      }
      
      if (null != str2) {
        
        String str = paramProperties.getProperty(str1);
        if (null != str) {

          
          properties.setProperty(str2, str);
          
          continue;
        } 
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidpropertyValue"));
        Object[] arrayOfObject = { str1 };
        throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
      } 
    } 

    
    return properties;
  }



  
  static Properties mergeURLAndSuppliedProperties(Properties paramProperties1, Properties paramProperties2) throws SQLServerException {
    if (null == paramProperties2) return paramProperties1; 
    if (paramProperties2.isEmpty()) return paramProperties1;
    
    Properties properties = fixupProperties(paramProperties2);
    
    byte b;
    for (b = 0; b < DRIVER_PROPERTIES.length; b++) {
      
      String str1 = DRIVER_PROPERTIES[b].getName();
      String str2 = properties.getProperty(str1);
      if (null != str2)
      {
        
        paramProperties1.put(str1, str2);
      }
    } 

    
    for (b = 0; b < DRIVER_PROPERTIES_PROPERTY_ONLY.length; b++) {
      
      String str1 = DRIVER_PROPERTIES_PROPERTY_ONLY[b].getName();
      String str2 = properties.getProperty(str1);
      if (null != str2)
      {
        
        paramProperties1.put(str1, str2);
      }
    } 
    
    return paramProperties1;
  }






  
  static String getNormalizedPropertyName(String paramString, Logger paramLogger) {
    if (null == paramString)
      return paramString; 
    byte b;
    for (b = 0; b < driverPropertiesSynonyms.length; b++) {
      
      if (driverPropertiesSynonyms[b][0].equalsIgnoreCase(paramString))
      {
        return driverPropertiesSynonyms[b][1];
      }
    } 
    for (b = 0; b < DRIVER_PROPERTIES.length; b++) {
      
      if (DRIVER_PROPERTIES[b].getName().equalsIgnoreCase(paramString))
      {
        return DRIVER_PROPERTIES[b].getName();
      }
    } 
    
    if (paramLogger.isLoggable(Level.FINER))
      paramLogger.finer("Unknown property" + paramString); 
    return null;
  }






  
  static String getPropertyOnlyName(String paramString, Logger paramLogger) {
    if (null == paramString) {
      return paramString;
    }
    for (byte b = 0; b < DRIVER_PROPERTIES_PROPERTY_ONLY.length; b++) {
      
      if (DRIVER_PROPERTIES_PROPERTY_ONLY[b].getName().equalsIgnoreCase(paramString)) {
        return DRIVER_PROPERTIES_PROPERTY_ONLY[b].getName();
      }
    } 
    
    if (paramLogger.isLoggable(Level.FINER))
      paramLogger.finer("Unknown property" + paramString); 
    return null;
  }

  
  public Connection connect(String paramString, Properties paramProperties) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "connect", "Arguments not traced.");
    SQLServerConnection sQLServerConnection = null;

    
    Properties properties = parseAndMergeProperties(paramString, paramProperties);
    if (properties != null) {
      
      sQLServerConnection = new SQLServerConnection(toString());
      sQLServerConnection.connect(properties, null);
    } 
    loggerExternal.exiting(getClassNameLogging(), "connect", sQLServerConnection);
    return sQLServerConnection;
  }


  
  private final Properties parseAndMergeProperties(String paramString, Properties paramProperties) throws SQLServerException {
    if (paramString == null)
    {
      throw new SQLServerException(null, SQLServerException.getErrString("R_nullConnection"), null, 0, false);
    }
    
    Properties properties = Util.parseUrl(paramString, drLogger);
    if (properties == null) {
      return null;
    }
    
    int i = DriverManager.getLoginTimeout();
    if (i > 0)
    {
      properties.put(SQLServerDriverIntProperty.LOGIN_TIMEOUT.toString(), (new Integer(i)).toString());
    }

    
    properties = mergeURLAndSuppliedProperties(properties, paramProperties);
    return properties;
  }


  
  public boolean acceptsURL(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "acceptsURL", "Arguments not traced.");
    
    if (null == paramString)
    {
      throw new SQLServerException(null, SQLServerException.getErrString("R_nullConnection"), null, 0, false);
    }
    
    boolean bool = false;
    
    try {
      bool = (Util.parseUrl(paramString, drLogger) != null) ? true : false;
    }
    catch (SQLServerException sQLServerException) {

      
      bool = false;
    } 
    loggerExternal.exiting(getClassNameLogging(), "acceptsURL", Boolean.valueOf(bool));
    return bool;
  }

  
  public DriverPropertyInfo[] getPropertyInfo(String paramString, Properties paramProperties) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getPropertyInfo", "Arguments not traced.");

    
    Properties properties = parseAndMergeProperties(paramString, paramProperties);
    
    if (null == properties)
      throw new SQLServerException(null, SQLServerException.getErrString("R_invalidConnection"), null, 0, false); 
    DriverPropertyInfo[] arrayOfDriverPropertyInfo = getPropertyInfoFromProperties(properties);
    loggerExternal.exiting(getClassNameLogging(), "getPropertyInfo");
    
    return arrayOfDriverPropertyInfo;
  }

  
  static final DriverPropertyInfo[] getPropertyInfoFromProperties(Properties paramProperties) {
    DriverPropertyInfo[] arrayOfDriverPropertyInfo = new DriverPropertyInfo[DRIVER_PROPERTIES.length];
    
    for (byte b = 0; b < DRIVER_PROPERTIES.length; b++)
      arrayOfDriverPropertyInfo[b] = DRIVER_PROPERTIES[b].build(paramProperties); 
    return arrayOfDriverPropertyInfo;
  }

  
  public int getMajorVersion() {
    loggerExternal.entering(getClassNameLogging(), "getMajorVersion");
    loggerExternal.exiting(getClassNameLogging(), "getMajorVersion", new Integer(6));
    return 6;
  }

  
  public int getMinorVersion() {
    loggerExternal.entering(getClassNameLogging(), "getMinorVersion");
    loggerExternal.exiting(getClassNameLogging(), "getMinorVersion", new Integer(0));
    return 0;
  }
  
  public Logger getParentLogger() throws SQLFeatureNotSupportedException {
    DriverJDBCVersion.checkSupportsJDBC41();

    
    throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
  }
  
  public boolean jdbcCompliant() {
    loggerExternal.entering(getClassNameLogging(), "jdbcCompliant");
    loggerExternal.exiting(getClassNameLogging(), "jdbcCompliant", Boolean.valueOf(true));
    return true;
  }
}
