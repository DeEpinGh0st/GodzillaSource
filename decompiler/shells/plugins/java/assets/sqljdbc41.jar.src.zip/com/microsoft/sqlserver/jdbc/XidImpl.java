package com.microsoft.sqlserver.jdbc;

import javax.transaction.xa.Xid;































final class XidImpl
  implements Xid
{
  private final int formatId;
  private final byte[] gtrid;
  private final byte[] bqual;
  private final String traceID;
  
  public XidImpl(int paramInt, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    this.formatId = paramInt;
    this.gtrid = paramArrayOfbyte1;
    this.bqual = paramArrayOfbyte2;
    this.traceID = " XID:" + xidDisplay(this);
  }
  
  public byte[] getGlobalTransactionId() {
    return this.gtrid;
  }
  
  public byte[] getBranchQualifier() {
    return this.bqual;
  }
  
  public int getFormatId() {
    return this.formatId;
  }
  
  public String toString() {
    return this.traceID;
  }


  
  static String xidDisplay(Xid paramXid) {
    if (null == paramXid) return "(null)"; 
    StringBuilder stringBuilder = new StringBuilder(300);
    stringBuilder.append("formatId=");
    stringBuilder.append(paramXid.getFormatId());
    stringBuilder.append(" gtrid=");
    stringBuilder.append(Util.byteToHexDisplayString(paramXid.getGlobalTransactionId()));
    stringBuilder.append(" bqual=");
    stringBuilder.append(Util.byteToHexDisplayString(paramXid.getBranchQualifier()));
    return stringBuilder.toString();
  }
}
