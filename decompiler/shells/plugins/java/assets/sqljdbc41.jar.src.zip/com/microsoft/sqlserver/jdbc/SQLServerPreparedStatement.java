package com.microsoft.sqlserver.jdbc;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.BatchUpdateException;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.NClob;
import java.sql.ParameterMetaData;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Vector;
import java.util.logging.Level;
import microsoft.sql.DateTimeOffset;

public class SQLServerPreparedStatement
  extends SQLServerStatement implements ISQLServerPreparedStatement {
  boolean isInternalEncryptionQuery = false;
  private static final int BATCH_STATEMENT_DELIMITER_TDS_71 = 128;
  private static final int BATCH_STATEMENT_DELIMITER_TDS_72 = 255;
  final int nBatchStatementDelimiter = 255;



  
  private String sqlCommand;


  
  private String preparedTypeDefinitions;


  
  final String userSQL;


  
  private String preparedSQL;


  
  private ArrayList<String> parameterNames;


  
  final boolean bReturnValueSyntax;


  
  int outParamIndexAdjustment;


  
  ArrayList<Parameter[]> batchParamValues;


  
  private int prepStmtHandle = 0;

  
  private boolean expectPrepStmtHandle = false;


  
  String getClassNameInternal() {
    return "SQLServerPreparedStatement";
  }











  
  SQLServerPreparedStatement(SQLServerConnection paramSQLServerConnection, String paramString, int paramInt1, int paramInt2, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
    super(paramSQLServerConnection, paramInt1, paramInt2, paramSQLServerStatementColumnEncryptionSetting);
    this.stmtPoolable = true;
    this.sqlCommand = paramString;
    
    JDBCSyntaxTranslator jDBCSyntaxTranslator = new JDBCSyntaxTranslator();
    paramString = jDBCSyntaxTranslator.translate(paramString);
    this.procedureName = jDBCSyntaxTranslator.getProcedureName();
    this.bReturnValueSyntax = jDBCSyntaxTranslator.hasReturnValueSyntax();
    
    this.userSQL = paramString;
    initParams(this.userSQL);
  }




  
  private void closePreparedHandle() {
    if (0 == this.prepStmtHandle) {
      return;
    }


    
    if (this.connection.isSessionUnAvailable()) {
      
      if (getStatementLogger().isLoggable(Level.FINER)) {
        getStatementLogger().finer(this + ": Not closing PreparedHandle:" + this.prepStmtHandle + "; connection is already closed.");
      }
    } else {
      
      if (getStatementLogger().isLoggable(Level.FINER)) {
        getStatementLogger().finer(this + ": Closing PreparedHandle:" + this.prepStmtHandle);
      }






















      
      try {
        executeCommand(new PreparedHandleClose());
      }
      catch (SQLServerException sQLServerException) {
        
        if (getStatementLogger().isLoggable(Level.FINER)) {
          getStatementLogger().log(Level.FINER, this + ": Error (ignored) closing PreparedHandle:" + this.prepStmtHandle, sQLServerException);
        }
      } 
      if (getStatementLogger().isLoggable(Level.FINER)) {
        getStatementLogger().finer(this + ": Closed PreparedHandle:" + this.prepStmtHandle);
      }
    } 
  }









  
  final void closeInternal() {
    super.closeInternal();

    
    closePreparedHandle();

    
    this.batchParamValues = null;
  }





  
  final void initParams(String paramString) {
    byte b1 = 0;


    
    int i = -1;
    while ((i = ParameterUtils.scanSQLForChar('?', paramString, ++i)) < paramString.length()) {
      b1++;
    }
    this.inOutParam = new Parameter[b1];
    for (byte b2 = 0; b2 < b1; b2++) {
      this.inOutParam[b2] = new Parameter(Util.shouldHonorAEForParameters(this.stmtColumnEncriptionSetting, this.connection));
    }
  }

  
  public final void clearParameters() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "clearParameters");
    checkClosed();
    
    if (this.inOutParam == null)
      return;  for (byte b = 0; b < this.inOutParam.length; b++)
    {
      this.inOutParam[b].clearInputValue();
    }
    loggerExternal.exiting(getClassNameLogging(), "clearParameters");
  }






  
  private final boolean buildPreparedStrings(Parameter[] paramArrayOfParameter, boolean paramBoolean) throws SQLServerException {
    String str = buildParamTypeDefinitions(paramArrayOfParameter, paramBoolean);
    if (null != this.preparedTypeDefinitions && str.equals(this.preparedTypeDefinitions)) {
      return false;
    }
    this.preparedTypeDefinitions = str;

    
    this.preparedSQL = this.connection.replaceParameterMarkers(this.userSQL, paramArrayOfParameter, this.bReturnValueSyntax);
    if (this.bRequestedGeneratedKeys) {
      this.preparedSQL += " select SCOPE_IDENTITY() AS GENERATED_KEYS";
    }
    return true;
  }








  
  private String buildParamTypeDefinitions(Parameter[] paramArrayOfParameter, boolean paramBoolean) throws SQLServerException {
    StringBuilder stringBuilder = new StringBuilder();
    int i = paramArrayOfParameter.length;
    char[] arrayOfChar = new char[10];
    this.parameterNames = new ArrayList<>();
    
    for (byte b = 0; b < i; b++) {
      if (b > 0) {
        stringBuilder.append(',');
      }
      int j = SQLServerConnection.makeParamName(b, arrayOfChar, 0);
      for (byte b1 = 0; b1 < j; b1++)
        stringBuilder.append(arrayOfChar[b1]); 
      stringBuilder.append(' ');
      
      this.parameterNames.add(b, (new String(arrayOfChar)).trim());
      
      (paramArrayOfParameter[b]).renewDefinition = paramBoolean;
      String str = paramArrayOfParameter[b].getTypeDefinition(this.connection, resultsReader());
      if (null == str) {
        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_valueNotSetForParameter"));
        Object[] arrayOfObject = { new Integer(b + 1) };
        SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), (String)null, false);
      } 
      
      stringBuilder.append(str);
      
      if (paramArrayOfParameter[b].isOutput())
        stringBuilder.append(" OUTPUT"); 
    } 
    return stringBuilder.toString();
  }







  
  public ResultSet executeQuery() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "executeQuery");
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();
    executeStatement(new PrepStmtExecCmd(this, 1));
    loggerExternal.exiting(getClassNameLogging(), "executeQuery");
    return this.resultSet;
  }






  
  final ResultSet executeQueryInternal() throws SQLServerException {
    checkClosed();
    executeStatement(new PrepStmtExecCmd(this, 5));
    return this.resultSet;
  }





  
  public int executeUpdate() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "executeUpdate");
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    
    checkClosed();
    
    executeStatement(new PrepStmtExecCmd(this, 2));

    
    if (this.updateCount < -2147483648L || this.updateCount > 2147483647L) {
      SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_updateCountOutofRange"), (String)null, true);
    }
    loggerExternal.exiting(getClassNameLogging(), "executeUpdate", new Long(this.updateCount));
    
    return (int)this.updateCount;
  }

  
  public long executeLargeUpdate() throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    loggerExternal.entering(getClassNameLogging(), "executeLargeUpdate");
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();
    executeStatement(new PrepStmtExecCmd(this, 2));
    loggerExternal.exiting(getClassNameLogging(), "executeLargeUpdate", new Long(this.updateCount));
    return this.updateCount;
  }






  
  public boolean execute() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "execute");
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();
    executeStatement(new PrepStmtExecCmd(this, 3));
    loggerExternal.exiting(getClassNameLogging(), "execute", Boolean.valueOf((null != this.resultSet)));
    return (null != this.resultSet);
  }
  
  private final class PrepStmtExecCmd
    extends TDSCommand
  {
    private final SQLServerPreparedStatement stmt;
    
    PrepStmtExecCmd(SQLServerPreparedStatement param1SQLServerPreparedStatement1, int param1Int) {
      super(param1SQLServerPreparedStatement1.toString() + " executeXXX", SQLServerPreparedStatement.this.queryTimeout);
      this.stmt = param1SQLServerPreparedStatement1;
      param1SQLServerPreparedStatement1.executeMethod = param1Int;
    }

    
    final boolean doExecute() throws SQLServerException {
      this.stmt.doExecutePreparedStatement(this);
      return false;
    }

    
    final void processResponse(TDSReader param1TDSReader) throws SQLServerException {
      SQLServerPreparedStatement.this.ensureExecuteResultsReader(param1TDSReader);
      SQLServerPreparedStatement.this.processExecuteResults();
    }
  }

  
  final void doExecutePreparedStatement(PrepStmtExecCmd paramPrepStmtExecCmd) throws SQLServerException {
    resetForReexecute();










    
    setMaxRowsAndMaxFieldSize();
    
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    
    boolean bool = buildPreparedStrings(this.inOutParam, false);
    if (Util.shouldHonorAEForParameters(this.stmtColumnEncriptionSetting, this.connection) && 0 < this.inOutParam.length && !this.isInternalEncryptionQuery) {


      
      getParameterEncryptionMetadata(this.inOutParam);


      
      setMaxRowsAndMaxFieldSize();

      
      buildPreparedStrings(this.inOutParam, true);
    } 


    
    TDSWriter tDSWriter = paramPrepStmtExecCmd.startRequest((byte)3);
    
    doPrepExec(tDSWriter, this.inOutParam, bool);
    
    ensureExecuteResultsReader(paramPrepStmtExecCmd.startResponse(getIsResponseBufferingAdaptive()));
    startResults();
    getNextResult();
    
    if (1 == this.executeMethod && null == this.resultSet) {
      
      SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_noResultset"), (String)null, true);




    
    }
    else if (2 == this.executeMethod && null != this.resultSet) {
      
      SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_resultsetGeneratedForUpdate"), (String)null, false);
    } 
  }















  
  boolean consumeExecOutParam(TDSReader paramTDSReader) throws SQLServerException {
    final class PrepStmtExecOutParamHandler
      extends SQLServerStatement.StmtExecOutParamHandler
    {
      boolean onRetValue(TDSReader param1TDSReader) throws SQLServerException {
        if (!SQLServerPreparedStatement.this.expectPrepStmtHandle) {
          return super.onRetValue(param1TDSReader);
        }

        
        SQLServerPreparedStatement.this.expectPrepStmtHandle = false;
        Parameter parameter = new Parameter(Util.shouldHonorAEForParameters(SQLServerPreparedStatement.this.stmtColumnEncriptionSetting, SQLServerPreparedStatement.this.connection));
        parameter.skipRetValStatus(param1TDSReader);
        SQLServerPreparedStatement.this.prepStmtHandle = parameter.getInt(param1TDSReader);
        parameter.skipValue(param1TDSReader, true);
        if (SQLServerPreparedStatement.this.getStatementLogger().isLoggable(Level.FINER)) {
          SQLServerPreparedStatement.this.getStatementLogger().finer(toString() + ": Setting PreparedHandle:" + SQLServerPreparedStatement.this.prepStmtHandle);
        }
        return true;
      }
    };
    
    if (this.expectPrepStmtHandle || this.expectCursorOutParams) {
      
      TDSParser.parse(paramTDSReader, new PrepStmtExecOutParamHandler());
      return true;
    } 
    
    return false;
  }





  
  void sendParamsByRPC(TDSWriter paramTDSWriter, Parameter[] paramArrayOfParameter) throws SQLServerException {
    for (byte b = 0; b < paramArrayOfParameter.length; b++) {
      
      if (JDBCType.TVP == paramArrayOfParameter[b].getJdbcType()) {
        
        char[] arrayOfChar = new char[10];
        int i = SQLServerConnection.makeParamName(b, arrayOfChar, 0);
        paramTDSWriter.writeByte((byte)i);
        paramTDSWriter.writeString(new String(arrayOfChar, 0, i));
      } 
      paramArrayOfParameter[b].sendByRPC(paramTDSWriter, this.connection);
    } 
  }

  
  private final void buildServerCursorPrepExecParams(TDSWriter paramTDSWriter) throws SQLServerException {
    if (getStatementLogger().isLoggable(Level.FINE)) {
      getStatementLogger().fine(toString() + ": calling sp_cursorprepexec: PreparedHandle:" + this.prepStmtHandle + ", SQL:" + this.preparedSQL);
    }
    this.expectPrepStmtHandle = true;
    this.executedSqlDirectly = false;
    this.expectCursorOutParams = true;
    this.outParamIndexAdjustment = 7;
    
    paramTDSWriter.writeShort((short)-1);
    paramTDSWriter.writeShort((short)5);
    paramTDSWriter.writeByte((byte)0);
    paramTDSWriter.writeByte((byte)0);



    
    paramTDSWriter.writeRPCInt(null, new Integer(this.prepStmtHandle), true);
    this.prepStmtHandle = 0;

    
    paramTDSWriter.writeRPCInt(null, new Integer(0), true);

    
    paramTDSWriter.writeRPCStringUnicode((this.preparedTypeDefinitions.length() > 0) ? this.preparedTypeDefinitions : null);

    
    paramTDSWriter.writeRPCStringUnicode(this.preparedSQL);



    
    paramTDSWriter.writeRPCInt(null, new Integer(getResultSetScrollOpt() & (((0 == this.preparedTypeDefinitions.length()) ? 4096 : 0) ^ 0xFFFFFFFF)), false);

    
    paramTDSWriter.writeRPCInt(null, new Integer(getResultSetCCOpt()), false);

    
    paramTDSWriter.writeRPCInt(null, new Integer(0), true);
  }

  
  private final void buildPrepExecParams(TDSWriter paramTDSWriter) throws SQLServerException {
    if (getStatementLogger().isLoggable(Level.FINE)) {
      getStatementLogger().fine(toString() + ": calling sp_prepexec: PreparedHandle:" + this.prepStmtHandle + ", SQL:" + this.preparedSQL);
    }
    this.expectPrepStmtHandle = true;
    this.executedSqlDirectly = true;
    this.expectCursorOutParams = false;
    this.outParamIndexAdjustment = 3;
    
    paramTDSWriter.writeShort((short)-1);
    paramTDSWriter.writeShort((short)13);
    paramTDSWriter.writeByte((byte)0);
    paramTDSWriter.writeByte((byte)0);



    
    paramTDSWriter.writeRPCInt(null, new Integer(this.prepStmtHandle), true);
    this.prepStmtHandle = 0;

    
    paramTDSWriter.writeRPCStringUnicode((this.preparedTypeDefinitions.length() > 0) ? this.preparedTypeDefinitions : null);

    
    paramTDSWriter.writeRPCStringUnicode(this.preparedSQL);
  }

  
  private final void buildServerCursorExecParams(TDSWriter paramTDSWriter) throws SQLServerException {
    if (getStatementLogger().isLoggable(Level.FINE)) {
      getStatementLogger().fine(toString() + ": calling sp_cursorexecute: PreparedHandle:" + this.prepStmtHandle + ", SQL:" + this.preparedSQL);
    }
    this.expectPrepStmtHandle = false;
    this.executedSqlDirectly = false;
    this.expectCursorOutParams = true;
    this.outParamIndexAdjustment = 5;
    
    paramTDSWriter.writeShort((short)-1);
    paramTDSWriter.writeShort((short)4);
    paramTDSWriter.writeByte((byte)0);
    paramTDSWriter.writeByte((byte)0);

    
    assert 0 != this.prepStmtHandle;
    paramTDSWriter.writeRPCInt(null, new Integer(this.prepStmtHandle), false);

    
    paramTDSWriter.writeRPCInt(null, new Integer(0), true);

    
    paramTDSWriter.writeRPCInt(null, new Integer(getResultSetScrollOpt() & 0xFFFFEFFF), false);

    
    paramTDSWriter.writeRPCInt(null, new Integer(getResultSetCCOpt()), false);

    
    paramTDSWriter.writeRPCInt(null, new Integer(0), true);
  }

  
  private final void buildExecParams(TDSWriter paramTDSWriter) throws SQLServerException {
    if (getStatementLogger().isLoggable(Level.FINE)) {
      getStatementLogger().fine(toString() + ": calling sp_execute: PreparedHandle:" + this.prepStmtHandle + ", SQL:" + this.preparedSQL);
    }
    this.expectPrepStmtHandle = false;
    this.executedSqlDirectly = true;
    this.expectCursorOutParams = false;
    this.outParamIndexAdjustment = 1;
    
    paramTDSWriter.writeShort((short)-1);
    paramTDSWriter.writeShort((short)12);
    paramTDSWriter.writeByte((byte)0);
    paramTDSWriter.writeByte((byte)0);

    
    assert 0 != this.prepStmtHandle;
    paramTDSWriter.writeRPCInt(null, new Integer(this.prepStmtHandle), false);
  }







  
  private void getParameterEncryptionMetadata(Parameter[] paramArrayOfParameter) throws SQLServerException {
    SQLServerResultSet sQLServerResultSet = null;
    SQLServerCallableStatement sQLServerCallableStatement = null;
    
    assert this.connection != null : "Connection should not be null";
    
    try {
      if (getStatementLogger().isLoggable(Level.FINE)) {
        getStatementLogger().fine("Calling stored procedure sp_describe_parameter_encryption to get parameter encryption information.");
      }
      
      sQLServerCallableStatement = (SQLServerCallableStatement)this.connection.prepareCall("exec sp_describe_parameter_encryption ?,?");
      sQLServerCallableStatement.isInternalEncryptionQuery = true;
      sQLServerCallableStatement.setNString(1, this.preparedSQL);
      sQLServerCallableStatement.setNString(2, this.preparedTypeDefinitions);
      sQLServerResultSet = (SQLServerResultSet)sQLServerCallableStatement.executeQueryInternal();
    }
    catch (SQLException sQLException) {
      
      if (sQLException instanceof SQLServerException)
      {
        throw (SQLServerException)sQLException;
      }

      
      throw new SQLServerException(SQLServerException.getErrString("R_UnableRetrieveParameterMetadata"), null, 0, sQLException);
    } 

    
    if (null == sQLServerResultSet) {
      return;
    }



    
    HashMap<Object, Object> hashMap = new HashMap<>();
    CekTableEntry cekTableEntry = null;
    
    try {
      while (sQLServerResultSet.next()) {
        
        int i = sQLServerResultSet.getInt(DescribeParameterEncryptionResultSet1.KeyOrdinal.value());
        if (!hashMap.containsKey(Integer.valueOf(i))) {
          
          cekTableEntry = new CekTableEntry(i);
          hashMap.put(Integer.valueOf(cekTableEntry.ordinal), cekTableEntry);
        }
        else {
          
          cekTableEntry = (CekTableEntry)hashMap.get(Integer.valueOf(i));
        } 
        cekTableEntry.add(sQLServerResultSet.getBytes(DescribeParameterEncryptionResultSet1.EncryptedKey.value()), sQLServerResultSet.getInt(DescribeParameterEncryptionResultSet1.DbId.value()), sQLServerResultSet.getInt(DescribeParameterEncryptionResultSet1.KeyId.value()), sQLServerResultSet.getInt(DescribeParameterEncryptionResultSet1.KeyVersion.value()), sQLServerResultSet.getBytes(DescribeParameterEncryptionResultSet1.KeyMdVersion.value()), sQLServerResultSet.getString(DescribeParameterEncryptionResultSet1.KeyPath.value()), sQLServerResultSet.getString(DescribeParameterEncryptionResultSet1.ProviderName.value()), sQLServerResultSet.getString(DescribeParameterEncryptionResultSet1.KeyEncryptionAlgorithm.value()));
      } 








      
      if (getStatementLogger().isLoggable(Level.FINE)) {
        getStatementLogger().fine("Matadata of CEKs is retrieved.");
      }
    }
    catch (SQLException sQLException) {
      
      if (sQLException instanceof SQLServerException)
      {
        throw (SQLServerException)sQLException;
      }

      
      throw new SQLServerException(SQLServerException.getErrString("R_UnableRetrieveParameterMetadata"), null, 0, sQLException);
    } 


    
    if (!sQLServerCallableStatement.getMoreResults())
    {
      throw new SQLServerException(this, SQLServerException.getErrString("R_UnexpectedDescribeParamFormat"), null, 0, false);
    }

    
    byte b = 0;
    
    try {
      sQLServerResultSet = (SQLServerResultSet)sQLServerCallableStatement.getResultSet();
      while (sQLServerResultSet.next()) {
        
        b++;
        String str = sQLServerResultSet.getString(DescribeParameterEncryptionResultSet2.ParameterName.value());
        int i = this.parameterNames.indexOf(str);
        int j = sQLServerResultSet.getInt(DescribeParameterEncryptionResultSet2.ColumnEncryptionKeyOrdinal.value());
        cekTableEntry = (CekTableEntry)hashMap.get(Integer.valueOf(j));

        
        if (null != cekTableEntry && hashMap.size() < j) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidEncryptionKeyOridnal"));
          Object[] arrayOfObject = { Integer.valueOf(j), Integer.valueOf(cekTableEntry.getSize()) };
          throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
        } 
        SQLServerEncryptionType sQLServerEncryptionType = SQLServerEncryptionType.of((byte)sQLServerResultSet.getInt(DescribeParameterEncryptionResultSet2.ColumnEncrytionType.value()));
        
        if (SQLServerEncryptionType.PlainText != sQLServerEncryptionType) {
          
          (paramArrayOfParameter[i]).cryptoMeta = new CryptoMetadata(cekTableEntry, (short)j, (byte)sQLServerResultSet.getInt(DescribeParameterEncryptionResultSet2.ColumnEncryptionAlgorithm.value()), null, sQLServerEncryptionType.value, (byte)sQLServerResultSet.getInt(DescribeParameterEncryptionResultSet2.NormalizationRuleVersion.value()));







          
          SQLServerSecurityUtility.decryptSymmetricKey((paramArrayOfParameter[i]).cryptoMeta, this.connection);
          continue;
        } 
        if (true == paramArrayOfParameter[i].getForceEncryption()) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_ForceEncryptionTrue_HonorAETrue_UnencryptedColumn"));
          Object[] arrayOfObject = { this.userSQL, Integer.valueOf(i + 1) };
          SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), (String)null, true);
        } 
      } 
      
      if (getStatementLogger().isLoggable(Level.FINE)) {
        getStatementLogger().fine("Parameter encryption metadata is set.");
      }
    }
    catch (SQLException sQLException) {
      
      if (sQLException instanceof SQLServerException)
      {
        throw (SQLServerException)sQLException;
      }

      
      throw new SQLServerException(SQLServerException.getErrString("R_UnableRetrieveParameterMetadata"), null, 0, sQLException);
    } 

    
    if (b != paramArrayOfParameter.length) {



      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_MissingParamEncryptionMetadata"));
      Object[] arrayOfObject = { this.userSQL };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    } 

    
    sQLServerResultSet.close();
    
    if (null != sQLServerCallableStatement)
    {
      sQLServerCallableStatement.close();
    }
    this.connection.resetCurrentCommand();
  }













  
  private final boolean doPrepExec(TDSWriter paramTDSWriter, Parameter[] paramArrayOfParameter, boolean paramBoolean) throws SQLServerException {
    boolean bool = (paramBoolean || 0 == this.prepStmtHandle) ? true : false;
    
    if (bool) {
      
      if (isCursorable(this.executeMethod)) {
        buildServerCursorPrepExecParams(paramTDSWriter);
      } else {
        buildPrepExecParams(paramTDSWriter);
      }
    
    }
    else if (isCursorable(this.executeMethod)) {
      buildServerCursorExecParams(paramTDSWriter);
    } else {
      buildExecParams(paramTDSWriter);
    } 
    
    sendParamsByRPC(paramTDSWriter, paramArrayOfParameter);
    return bool;
  }

  
  public final ResultSetMetaData getMetaData() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getMetaData");
    checkClosed();
    boolean bool = false;
    ResultSetMetaData resultSetMetaData = null;

    
    try {
      if (this.resultSet != null) {
        this.resultSet.checkClosed();
      }
    } catch (SQLServerException sQLServerException) {
      
      bool = true;
    } 
    if (this.resultSet == null || bool) {
      
      SQLServerResultSet sQLServerResultSet = (SQLServerResultSet)buildExecuteMetaData();
      if (null != sQLServerResultSet) {
        resultSetMetaData = sQLServerResultSet.getMetaData();
      }
    }
    else if (this.resultSet != null) {
      
      resultSetMetaData = this.resultSet.getMetaData();
    } 
    loggerExternal.exiting(getClassNameLogging(), "getMetaData", resultSetMetaData);
    return resultSetMetaData;
  }








  
  private ResultSet buildExecuteMetaData() throws SQLServerException {
    String str = this.sqlCommand;
    if (str.indexOf('{') >= 0)
    {
      str = (new JDBCSyntaxTranslator()).translate(str);
    }
    
    SQLServerResultSet sQLServerResultSet = null;
    try {
      str = replaceMarkerWithNull(str);
      SQLServerStatement sQLServerStatement = (SQLServerStatement)this.connection.createStatement();
      sQLServerResultSet = sQLServerStatement.executeQueryInternal("set fmtonly on " + str + "\nset fmtonly off");
    }
    catch (SQLException sQLException) {
      
      if (false == sQLException.getMessage().equals(SQLServerException.getErrString("R_noResultset"))) {

        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_processingError"));
        Object[] arrayOfObject = { new String(sQLException.getMessage()) };
        
        SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), (String)null, true);
      } 
    } 
    
    return sQLServerResultSet;
  }











  
  final Parameter setterGetParam(int paramInt) throws SQLServerException {
    if (paramInt < 1 || paramInt > this.inOutParam.length) {
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_indexOutOfRange"));
      Object[] arrayOfObject = { new Integer(paramInt) };
      SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), "07009", false);
    } 

    
    return this.inOutParam[paramInt - 1];
  }


  
  final void setValue(int paramInt, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, String paramString) throws SQLServerException {
    setterGetParam(paramInt).setValue(paramJDBCType, paramObject, paramJavaType, null, null, null, null, this.connection, false, this.stmtColumnEncriptionSetting, paramInt, this.userSQL, paramString);
  }

  
  final void setValue(int paramInt, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, boolean paramBoolean) throws SQLServerException {
    setterGetParam(paramInt).setValue(paramJDBCType, paramObject, paramJavaType, null, null, null, null, this.connection, paramBoolean, this.stmtColumnEncriptionSetting, paramInt, this.userSQL, null);
  }

  
  final void setValue(int paramInt, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, Integer paramInteger1, Integer paramInteger2, boolean paramBoolean) throws SQLServerException {
    setterGetParam(paramInt).setValue(paramJDBCType, paramObject, paramJavaType, null, null, paramInteger1, paramInteger2, this.connection, paramBoolean, this.stmtColumnEncriptionSetting, paramInt, this.userSQL, null);
  }

  
  final void setValue(int paramInt, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, Calendar paramCalendar, boolean paramBoolean) throws SQLServerException {
    setterGetParam(paramInt).setValue(paramJDBCType, paramObject, paramJavaType, null, paramCalendar, null, null, this.connection, paramBoolean, this.stmtColumnEncriptionSetting, paramInt, this.userSQL, null);
  }

  
  final void setStream(int paramInt, StreamType paramStreamType, Object paramObject, JavaType paramJavaType, long paramLong) throws SQLServerException {
    setterGetParam(paramInt).setValue(paramStreamType.getJDBCType(), paramObject, paramJavaType, new StreamSetterArgs(paramStreamType, paramLong), null, null, null, this.connection, false, this.stmtColumnEncriptionSetting, paramInt, this.userSQL, null);
  }













  
  final void setSQLXMLInternal(int paramInt, SQLXML paramSQLXML) throws SQLServerException {
    setterGetParam(paramInt).setValue(JDBCType.SQLXML, paramSQLXML, JavaType.SQLXML, new StreamSetterArgs(StreamType.SQLXML, -1L), null, null, null, this.connection, false, this.stmtColumnEncriptionSetting, paramInt, this.userSQL, null);
  }













  
  public final void setAsciiStream(int paramInt, InputStream paramInputStream) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setAsciiStream", new Object[] { Integer.valueOf(paramInt), paramInputStream }); 
    checkClosed();
    setStream(paramInt, StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, -1L);
    loggerExternal.exiting(getClassNameLogging(), "setAsciiStream");
  }

  
  public final void setAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setAsciiStream", new Object[] { Integer.valueOf(paramInt1), paramInputStream, Integer.valueOf(paramInt2) }); 
    checkClosed();
    setStream(paramInt1, StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, paramInt2);
    loggerExternal.exiting(getClassNameLogging(), "setAsciiStream");
  }

  
  public final void setAsciiStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setAsciiStream", new Object[] { Integer.valueOf(paramInt), paramInputStream, Long.valueOf(paramLong) }); 
    checkClosed();
    setStream(paramInt, StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, paramLong);
    loggerExternal.exiting(getClassNameLogging(), "setAsciiStream");
  }

  
  private final Parameter getParam(int paramInt) throws SQLServerException {
    paramInt--;
    if (paramInt < 0 || paramInt >= this.inOutParam.length) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_indexOutOfRange"));
      Object[] arrayOfObject = { new Integer(paramInt + 1) };
      SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), "07009", false);
    } 
    
    return this.inOutParam[paramInt];
  }


  
  public final void setBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBigDecimal", new Object[] { Integer.valueOf(paramInt), paramBigDecimal }); 
    checkClosed();
    setValue(paramInt, JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, false);
    loggerExternal.exiting(getClassNameLogging(), "setBigDecimal");
  }

  
  public final void setBigDecimal(int paramInt1, BigDecimal paramBigDecimal, int paramInt2, int paramInt3) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBigDecimal", new Object[] { Integer.valueOf(paramInt1), paramBigDecimal, Integer.valueOf(paramInt2), Integer.valueOf(paramInt3) }); 
    checkClosed();
    setValue(paramInt1, JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), false);
    loggerExternal.exiting(getClassNameLogging(), "setBigDecimal");
  }

  
  public final void setBigDecimal(int paramInt1, BigDecimal paramBigDecimal, int paramInt2, int paramInt3, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBigDecimal", new Object[] { Integer.valueOf(paramInt1), paramBigDecimal, Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(paramInt1, JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setBigDecimal");
  }

  
  public final void setMoney(int paramInt, BigDecimal paramBigDecimal) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setMoney", new Object[] { Integer.valueOf(paramInt), paramBigDecimal }); 
    checkClosed();
    setValue(paramInt, JDBCType.MONEY, paramBigDecimal, JavaType.BIGDECIMAL, false);
    loggerExternal.exiting(getClassNameLogging(), "setMoney");
  }

  
  public final void setMoney(int paramInt, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setMoney", new Object[] { Integer.valueOf(paramInt), paramBigDecimal, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(paramInt, JDBCType.MONEY, paramBigDecimal, JavaType.BIGDECIMAL, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setMoney");
  }

  
  public final void setSmallMoney(int paramInt, BigDecimal paramBigDecimal) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setSmallMoney", new Object[] { Integer.valueOf(paramInt), paramBigDecimal }); 
    checkClosed();
    setValue(paramInt, JDBCType.SMALLMONEY, paramBigDecimal, JavaType.BIGDECIMAL, false);
    loggerExternal.exiting(getClassNameLogging(), "setSmallMoney");
  }

  
  public final void setSmallMoney(int paramInt, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setSmallMoney", new Object[] { Integer.valueOf(paramInt), paramBigDecimal, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(paramInt, JDBCType.SMALLMONEY, paramBigDecimal, JavaType.BIGDECIMAL, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setSmallMoney");
  }

  
  public final void setBinaryStream(int paramInt, InputStream paramInputStream) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBinaryStreaml", new Object[] { Integer.valueOf(paramInt), paramInputStream }); 
    checkClosed();
    setStream(paramInt, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, -1L);
    loggerExternal.exiting(getClassNameLogging(), "setBinaryStream");
  }

  
  public final void setBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBinaryStream", new Object[] { Integer.valueOf(paramInt1), paramInputStream, Integer.valueOf(paramInt2) }); 
    checkClosed();
    setStream(paramInt1, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramInt2);
    loggerExternal.exiting(getClassNameLogging(), "setBinaryStream");
  }

  
  public final void setBinaryStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBinaryStream", new Object[] { Integer.valueOf(paramInt), paramInputStream, Long.valueOf(paramLong) }); 
    checkClosed();
    setStream(paramInt, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramLong);
    loggerExternal.exiting(getClassNameLogging(), "setBinaryStream");
  }

  
  public final void setBoolean(int paramInt, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBoolean", new Object[] { Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(paramInt, JDBCType.BIT, Boolean.valueOf(paramBoolean), JavaType.BOOLEAN, false);
    loggerExternal.exiting(getClassNameLogging(), "setBoolean");
  }

  
  public final void setBoolean(int paramInt, boolean paramBoolean1, boolean paramBoolean2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBoolean", new Object[] { Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean1), Boolean.valueOf(paramBoolean2) }); 
    checkClosed();
    setValue(paramInt, JDBCType.BIT, Boolean.valueOf(paramBoolean1), JavaType.BOOLEAN, paramBoolean2);
    loggerExternal.exiting(getClassNameLogging(), "setBoolean");
  }

  
  public final void setByte(int paramInt, byte paramByte) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setByte", new Object[] { Integer.valueOf(paramInt), Byte.valueOf(paramByte) }); 
    checkClosed();
    setValue(paramInt, JDBCType.TINYINT, Byte.valueOf(paramByte), JavaType.BYTE, false);
    loggerExternal.exiting(getClassNameLogging(), "setByte");
  }

  
  public final void setByte(int paramInt, byte paramByte, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setByte", new Object[] { Integer.valueOf(paramInt), Byte.valueOf(paramByte), Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(paramInt, JDBCType.TINYINT, Byte.valueOf(paramByte), JavaType.BYTE, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setByte");
  }

  
  public final void setBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBytes", new Object[] { Integer.valueOf(paramInt), paramArrayOfbyte }); 
    checkClosed();
    setValue(paramInt, JDBCType.BINARY, paramArrayOfbyte, JavaType.BYTEARRAY, false);
    loggerExternal.exiting(getClassNameLogging(), "setBytes");
  }

  
  public final void setBytes(int paramInt, byte[] paramArrayOfbyte, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBytes", new Object[] { Integer.valueOf(paramInt), paramArrayOfbyte, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(paramInt, JDBCType.BINARY, paramArrayOfbyte, JavaType.BYTEARRAY, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setBytes");
  }

  
  public final void setUniqueIdentifier(int paramInt, String paramString) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setUniqueIdentifier", new Object[] { Integer.valueOf(paramInt), paramString }); 
    checkClosed();
    setValue(paramInt, JDBCType.GUID, paramString, JavaType.STRING, false);
    loggerExternal.exiting(getClassNameLogging(), "setUniqueIdentifier");
  }

  
  public final void setUniqueIdentifier(int paramInt, String paramString, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setUniqueIdentifier", new Object[] { Integer.valueOf(paramInt), paramString, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(paramInt, JDBCType.GUID, paramString, JavaType.STRING, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setUniqueIdentifier");
  }

  
  public final void setDouble(int paramInt, double paramDouble) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setDouble", new Object[] { Integer.valueOf(paramInt), Double.valueOf(paramDouble) }); 
    checkClosed();
    setValue(paramInt, JDBCType.DOUBLE, Double.valueOf(paramDouble), JavaType.DOUBLE, false);
    loggerExternal.exiting(getClassNameLogging(), "setDouble");
  }

  
  public final void setDouble(int paramInt, double paramDouble, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setDouble", new Object[] { Integer.valueOf(paramInt), Double.valueOf(paramDouble), Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(paramInt, JDBCType.DOUBLE, Double.valueOf(paramDouble), JavaType.DOUBLE, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setDouble");
  }

  
  public final void setFloat(int paramInt, float paramFloat) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setFloat", new Object[] { Integer.valueOf(paramInt), Float.valueOf(paramFloat) }); 
    checkClosed();
    setValue(paramInt, JDBCType.REAL, Float.valueOf(paramFloat), JavaType.FLOAT, false);
    loggerExternal.exiting(getClassNameLogging(), "setFloat");
  }

  
  public final void setFloat(int paramInt, float paramFloat, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setFloat", new Object[] { Integer.valueOf(paramInt), Float.valueOf(paramFloat), Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(paramInt, JDBCType.REAL, Float.valueOf(paramFloat), JavaType.FLOAT, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setFloat");
  }

  
  public final void setInt(int paramInt1, int paramInt2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setInt", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) }); 
    checkClosed();
    setValue(paramInt1, JDBCType.INTEGER, Integer.valueOf(paramInt2), JavaType.INTEGER, false);
    loggerExternal.exiting(getClassNameLogging(), "setInt");
  }

  
  public final void setInt(int paramInt1, int paramInt2, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setInt", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(paramInt1, JDBCType.INTEGER, Integer.valueOf(paramInt2), JavaType.INTEGER, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setInt");
  }

  
  public final void setLong(int paramInt, long paramLong) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setLong", new Object[] { Integer.valueOf(paramInt), Long.valueOf(paramLong) }); 
    checkClosed();
    setValue(paramInt, JDBCType.BIGINT, Long.valueOf(paramLong), JavaType.LONG, false);
    loggerExternal.exiting(getClassNameLogging(), "setLong");
  }

  
  public final void setLong(int paramInt, long paramLong, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setLong", new Object[] { Integer.valueOf(paramInt), Long.valueOf(paramLong), Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(paramInt, JDBCType.BIGINT, Long.valueOf(paramLong), JavaType.LONG, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setLong");
  }


  
  public final void setNull(int paramInt1, int paramInt2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setNull", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) }); 
    checkClosed();
    setObject(setterGetParam(paramInt1), (Object)null, JavaType.OBJECT, JDBCType.of(paramInt2), (Integer)null, (Integer)null, false, paramInt1, (String)null);
    loggerExternal.exiting(getClassNameLogging(), "setNull");
  }



  
  final void setObjectNoType(int paramInt, Object paramObject, boolean paramBoolean) throws SQLServerException {
    Parameter parameter = setterGetParam(paramInt);
    JDBCType jDBCType = parameter.getJdbcType();
    String str = null;
    
    if (null == paramObject) {


      
      if (JDBCType.UNKNOWN == jDBCType) {
        jDBCType = JDBCType.CHAR;
      }
      setObject(parameter, (Object)null, JavaType.OBJECT, jDBCType, (Integer)null, (Integer)null, paramBoolean, paramInt, (String)null);
    }
    else {
      
      JavaType javaType = JavaType.of(paramObject);
      if (JavaType.TVP == javaType)
        str = getTVPNameIfNull(paramInt, (String)null); 
      jDBCType = javaType.getJDBCType(SSType.UNKNOWN, jDBCType);
      
      if (JDBCType.UNKNOWN == jDBCType && 
        paramObject instanceof java.util.UUID) {
        javaType = JavaType.STRING;
        jDBCType = JDBCType.GUID;
      } 

      
      setObject(parameter, paramObject, javaType, jDBCType, (Integer)null, (Integer)null, paramBoolean, paramInt, str);
    } 
  }

  
  public final void setObject(int paramInt, Object paramObject) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { Integer.valueOf(paramInt), paramObject }); 
    checkClosed();
    setObjectNoType(paramInt, paramObject, false);
    loggerExternal.exiting(getClassNameLogging(), "setObject");
  }

  
  public final void setObject(int paramInt1, Object paramObject, int paramInt2) throws SQLServerException {
    String str = null;
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { Integer.valueOf(paramInt1), paramObject, Integer.valueOf(paramInt2) }); 
    checkClosed();
    if (-153 == paramInt2)
      str = getTVPNameIfNull(paramInt1, (String)null); 
    setObject(setterGetParam(paramInt1), paramObject, JavaType.of(paramObject), JDBCType.of(paramInt2), (Integer)null, (Integer)null, false, paramInt1, str);
    loggerExternal.exiting(getClassNameLogging(), "setObject");
  }

  
  public final void setObject(int paramInt, Object paramObject, SQLType paramSQLType) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { Integer.valueOf(paramInt), paramObject, paramSQLType });
    }
    
    setObject(paramInt, paramObject, paramSQLType.getVendorTypeNumber().intValue());
    
    loggerExternal.exiting(getClassNameLogging(), "setObject");
  }

  
  public final void setObject(int paramInt1, Object paramObject, int paramInt2, int paramInt3) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { Integer.valueOf(paramInt1), paramObject, Integer.valueOf(paramInt2), Integer.valueOf(paramInt3) }); 
    checkClosed();





    
    setObject(setterGetParam(paramInt1), paramObject, JavaType.of(paramObject), JDBCType.of(paramInt2), (2 == paramInt2 || 3 == paramInt2 || 93 == paramInt2 || 92 == paramInt2 || -155 == paramInt2 || InputStream.class.isInstance(paramObject) || Reader.class.isInstance(paramObject)) ? Integer.valueOf(paramInt3) : null, (Integer)null, false, paramInt1, (String)null);

















    
    loggerExternal.exiting(getClassNameLogging(), "setObject");
  }

  
  public final void setObject(int paramInt1, Object paramObject, int paramInt2, Integer paramInteger, int paramInt3) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { Integer.valueOf(paramInt1), paramObject, Integer.valueOf(paramInt2), paramInteger, Integer.valueOf(paramInt3) }); 
    checkClosed();





    
    setObject(setterGetParam(paramInt1), paramObject, JavaType.of(paramObject), JDBCType.of(paramInt2), (2 == paramInt2 || 3 == paramInt2 || InputStream.class.isInstance(paramObject) || Reader.class.isInstance(paramObject)) ? Integer.valueOf(paramInt3) : null, paramInteger, false, paramInt1, (String)null);














    
    loggerExternal.exiting(getClassNameLogging(), "setObject");
  }

  
  public final void setObject(int paramInt1, Object paramObject, int paramInt2, Integer paramInteger, int paramInt3, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { Integer.valueOf(paramInt1), paramObject, Integer.valueOf(paramInt2), paramInteger, Integer.valueOf(paramInt3), Boolean.valueOf(paramBoolean) }); 
    checkClosed();





    
    setObject(setterGetParam(paramInt1), paramObject, JavaType.of(paramObject), JDBCType.of(paramInt2), (2 == paramInt2 || 3 == paramInt2 || InputStream.class.isInstance(paramObject) || Reader.class.isInstance(paramObject)) ? Integer.valueOf(paramInt3) : null, paramInteger, paramBoolean, paramInt1, (String)null);














    
    loggerExternal.exiting(getClassNameLogging(), "setObject");
  }

  
  public final void setObject(int paramInt1, Object paramObject, SQLType paramSQLType, int paramInt2) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { Integer.valueOf(paramInt1), paramObject, paramSQLType, Integer.valueOf(paramInt2) });
    }
    
    setObject(paramInt1, paramObject, paramSQLType.getVendorTypeNumber().intValue(), paramInt2);
    
    loggerExternal.exiting(getClassNameLogging(), "setObject");
  }

  
  public final void setObject(int paramInt, Object paramObject, SQLType paramSQLType, Integer paramInteger1, Integer paramInteger2) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { Integer.valueOf(paramInt), paramObject, paramSQLType, paramInteger1, paramInteger2 });
    }
    
    setObject(paramInt, paramObject, paramSQLType.getVendorTypeNumber().intValue(), paramInteger1, paramInteger2.intValue(), false);
    
    loggerExternal.exiting(getClassNameLogging(), "setObject");
  }

  
  public final void setObject(int paramInt, Object paramObject, SQLType paramSQLType, Integer paramInteger1, Integer paramInteger2, boolean paramBoolean) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { Integer.valueOf(paramInt), paramObject, paramSQLType, paramInteger1, paramInteger2, Boolean.valueOf(paramBoolean) });
    }
    
    setObject(paramInt, paramObject, paramSQLType.getVendorTypeNumber().intValue(), paramInteger1, paramInteger2.intValue(), paramBoolean);
    
    loggerExternal.exiting(getClassNameLogging(), "setObject");
  }










  
  final void setObject(Parameter paramParameter, Object paramObject, JavaType paramJavaType, JDBCType paramJDBCType, Integer paramInteger1, Integer paramInteger2, boolean paramBoolean, int paramInt, String paramString) throws SQLServerException {
    assert JDBCType.UNKNOWN != paramJDBCType;


    
    if (null != paramObject || JavaType.TVP == paramJavaType) {

      
      JDBCType jDBCType = paramJavaType.getJDBCType(SSType.UNKNOWN, paramJDBCType);

      
      if (!jDBCType.convertsTo(paramJDBCType)) {
        DataTypes.throwConversionError(jDBCType.toString(), paramJDBCType.toString());
      }
      StreamSetterArgs streamSetterArgs = null;
      
      switch (paramJavaType) {
        
        case READER:
          streamSetterArgs = new StreamSetterArgs(StreamType.CHARACTER, -1L);
          break;


        
        case INPUTSTREAM:
          streamSetterArgs = new StreamSetterArgs(paramJDBCType.isTextual() ? StreamType.CHARACTER : StreamType.BINARY, -1L);
          break;




        
        case SQLXML:
          streamSetterArgs = new StreamSetterArgs(StreamType.SQLXML, -1L);
          break;
      } 






      
      paramParameter.setValue(paramJDBCType, paramObject, paramJavaType, streamSetterArgs, null, paramInteger2, paramInteger1, this.connection, paramBoolean, this.stmtColumnEncriptionSetting, paramInt, this.userSQL, paramString);

    
    }
    else {

      
      assert JavaType.OBJECT == paramJavaType;
      
      if (paramJDBCType.isUnsupported()) {
        paramJDBCType = JDBCType.BINARY;
      }
      
      paramParameter.setValue(paramJDBCType, null, JavaType.OBJECT, null, null, paramInteger2, paramInteger1, this.connection, false, this.stmtColumnEncriptionSetting, paramInt, this.userSQL, paramString);
    } 
  }

  
  public final void setShort(int paramInt, short paramShort) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setShort", new Object[] { Integer.valueOf(paramInt), Short.valueOf(paramShort) }); 
    checkClosed();
    setValue(paramInt, JDBCType.SMALLINT, Short.valueOf(paramShort), JavaType.SHORT, false);
    loggerExternal.exiting(getClassNameLogging(), "setShort");
  }

  
  public final void setShort(int paramInt, short paramShort, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setShort", new Object[] { Integer.valueOf(paramInt), Short.valueOf(paramShort), Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(paramInt, JDBCType.SMALLINT, Short.valueOf(paramShort), JavaType.SHORT, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setShort");
  }

  
  public final void setString(int paramInt, String paramString) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setString", new Object[] { Integer.valueOf(paramInt), paramString }); 
    checkClosed();
    setValue(paramInt, JDBCType.VARCHAR, paramString, JavaType.STRING, false);
    loggerExternal.exiting(getClassNameLogging(), "setString");
  }

  
  public final void setString(int paramInt, String paramString, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setString", new Object[] { Integer.valueOf(paramInt), paramString, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(paramInt, JDBCType.VARCHAR, paramString, JavaType.STRING, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setString");
  }

  
  public final void setNString(int paramInt, String paramString) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setNString", new Object[] { Integer.valueOf(paramInt), paramString }); 
    checkClosed();
    setValue(paramInt, JDBCType.NVARCHAR, paramString, JavaType.STRING, false);
    loggerExternal.exiting(getClassNameLogging(), "setNString");
  }

  
  public final void setNString(int paramInt, String paramString, boolean paramBoolean) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setNString", new Object[] { Integer.valueOf(paramInt), paramString, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(paramInt, JDBCType.NVARCHAR, paramString, JavaType.STRING, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setNString");
  }

  
  public final void setTime(int paramInt, Time paramTime) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { Integer.valueOf(paramInt), paramTime }); 
    checkClosed();
    setValue(paramInt, JDBCType.TIME, paramTime, JavaType.TIME, false);
    loggerExternal.exiting(getClassNameLogging(), "setTime");
  }

  
  public final void setTime(int paramInt1, Time paramTime, int paramInt2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { Integer.valueOf(paramInt1), paramTime, Integer.valueOf(paramInt2) }); 
    checkClosed();
    setValue(paramInt1, JDBCType.TIME, paramTime, JavaType.TIME, (Integer)null, Integer.valueOf(paramInt2), false);
    loggerExternal.exiting(getClassNameLogging(), "setTime");
  }

  
  public final void setTime(int paramInt1, Time paramTime, int paramInt2, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { Integer.valueOf(paramInt1), paramTime, Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(paramInt1, JDBCType.TIME, paramTime, JavaType.TIME, (Integer)null, Integer.valueOf(paramInt2), paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setTime");
  }

  
  public final void setTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { Integer.valueOf(paramInt), paramTimestamp }); 
    checkClosed();
    setValue(paramInt, JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, false);
    loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
  }

  
  public final void setTimestamp(int paramInt1, Timestamp paramTimestamp, int paramInt2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { Integer.valueOf(paramInt1), paramTimestamp, Integer.valueOf(paramInt2) }); 
    checkClosed();
    setValue(paramInt1, JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, (Integer)null, Integer.valueOf(paramInt2), false);
    loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
  }

  
  public final void setTimestamp(int paramInt1, Timestamp paramTimestamp, int paramInt2, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { Integer.valueOf(paramInt1), paramTimestamp, Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(paramInt1, JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, (Integer)null, Integer.valueOf(paramInt2), paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
  }

  
  public final void setDateTimeOffset(int paramInt, DateTimeOffset paramDateTimeOffset) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setDateTimeOffset", new Object[] { Integer.valueOf(paramInt), paramDateTimeOffset }); 
    checkClosed();
    setValue(paramInt, JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET, false);
    loggerExternal.exiting(getClassNameLogging(), "setDateTimeOffset");
  }

  
  public final void setDateTimeOffset(int paramInt1, DateTimeOffset paramDateTimeOffset, int paramInt2) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setDateTimeOffset", new Object[] { Integer.valueOf(paramInt1), paramDateTimeOffset, Integer.valueOf(paramInt2) }); 
    checkClosed();
    setValue(paramInt1, JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET, (Integer)null, Integer.valueOf(paramInt2), false);
    loggerExternal.exiting(getClassNameLogging(), "setDateTimeOffset");
  }

  
  public final void setDateTimeOffset(int paramInt1, DateTimeOffset paramDateTimeOffset, int paramInt2, boolean paramBoolean) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setDateTimeOffset", new Object[] { Integer.valueOf(paramInt1), paramDateTimeOffset, Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(paramInt1, JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET, (Integer)null, Integer.valueOf(paramInt2), paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setDateTimeOffset");
  }

  
  public final void setDate(int paramInt, Date paramDate) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setDate", new Object[] { Integer.valueOf(paramInt), paramDate }); 
    checkClosed();
    setValue(paramInt, JDBCType.DATE, paramDate, JavaType.DATE, false);
    loggerExternal.exiting(getClassNameLogging(), "setDate");
  }

  
  public final void setDateTime(int paramInt, Timestamp paramTimestamp) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setDateTime", new Object[] { Integer.valueOf(paramInt), paramTimestamp }); 
    checkClosed();
    setValue(paramInt, JDBCType.DATETIME, paramTimestamp, JavaType.TIMESTAMP, false);
    loggerExternal.exiting(getClassNameLogging(), "setDateTime");
  }

  
  public final void setDateTime(int paramInt, Timestamp paramTimestamp, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setDateTime", new Object[] { Integer.valueOf(paramInt), paramTimestamp, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(paramInt, JDBCType.DATETIME, paramTimestamp, JavaType.TIMESTAMP, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setDateTime");
  }

  
  public final void setSmallDateTime(int paramInt, Timestamp paramTimestamp) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setSmallDateTime", new Object[] { Integer.valueOf(paramInt), paramTimestamp }); 
    checkClosed();
    setValue(paramInt, JDBCType.SMALLDATETIME, paramTimestamp, JavaType.TIMESTAMP, false);
    loggerExternal.exiting(getClassNameLogging(), "setSmallDateTime");
  }

  
  public final void setSmallDateTime(int paramInt, Timestamp paramTimestamp, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setSmallDateTime", new Object[] { Integer.valueOf(paramInt), paramTimestamp, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(paramInt, JDBCType.SMALLDATETIME, paramTimestamp, JavaType.TIMESTAMP, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setSmallDateTime");
  }

  
  public final void setStructured(int paramInt, String paramString, SQLServerDataTable paramSQLServerDataTable) throws SQLServerException {
    paramString = getTVPNameIfNull(paramInt, paramString);
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setStructured", new Object[] { Integer.valueOf(paramInt), paramString, paramSQLServerDataTable }); 
    checkClosed();
    setValue(paramInt, JDBCType.TVP, paramSQLServerDataTable, JavaType.TVP, paramString);
    loggerExternal.exiting(getClassNameLogging(), "setStructured");
  }

  
  public final void setStructured(int paramInt, String paramString, ResultSet paramResultSet) throws SQLServerException {
    paramString = getTVPNameIfNull(paramInt, paramString);
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setStructured", new Object[] { Integer.valueOf(paramInt), paramString, paramResultSet }); 
    checkClosed();
    setValue(paramInt, JDBCType.TVP, paramResultSet, JavaType.TVP, paramString);
    loggerExternal.exiting(getClassNameLogging(), "setStructured");
  }

  
  public final void setStructured(int paramInt, String paramString, ISQLServerDataRecord paramISQLServerDataRecord) throws SQLServerException {
    paramString = getTVPNameIfNull(paramInt, paramString);
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setStructured", new Object[] { Integer.valueOf(paramInt), paramString, paramISQLServerDataRecord }); 
    checkClosed();
    setValue(paramInt, JDBCType.TVP, paramISQLServerDataRecord, JavaType.TVP, paramString);
    loggerExternal.exiting(getClassNameLogging(), "setStructured");
  }

  
  String getTVPNameIfNull(int paramInt, String paramString) throws SQLServerException {
    if (null == paramString || 0 == paramString.length())
    {
      if (this instanceof SQLServerCallableStatement) {
        
        ParameterMetaData parameterMetaData = getParameterMetaData();
        try {
          paramString = parameterMetaData.getParameterTypeName(paramInt);
        } catch (SQLException sQLException) {
          throw new SQLServerException(SQLServerException.getErrString("R_metaDataErrorForParameter"), null, 0, sQLException);
        } 
      } 
    }
    return paramString;
  }
  @Deprecated
  public final void setUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
    NotImplemented();
  }

  
  public final void addBatch() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "addBatch");
    checkClosed();

    
    if (this.batchParamValues == null) {
      this.batchParamValues = (ArrayList)new ArrayList<>();
    }
    int i = this.inOutParam.length;
    Parameter[] arrayOfParameter = new Parameter[i];
    for (byte b = 0; b < i; b++)
      arrayOfParameter[b] = this.inOutParam[b].cloneForBatch(); 
    this.batchParamValues.add(arrayOfParameter);
    loggerExternal.exiting(getClassNameLogging(), "addBatch");
  }

  
  public final void clearBatch() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "clearBatch");
    checkClosed();
    this.batchParamValues = null;
    loggerExternal.exiting(getClassNameLogging(), "clearBatch");
  }
  
  public int[] executeBatch() throws SQLServerException, BatchUpdateException {
    int[] arrayOfInt;
    loggerExternal.entering(getClassNameLogging(), "executeBatch");
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();
    discardLastExecutionResults();


    
    if (this.batchParamValues == null) {
      arrayOfInt = new int[0];
    } else {

      
      try {








        
        for (byte b1 = 0; b1 < this.batchParamValues.size(); b1++) {
          
          Parameter[] arrayOfParameter = this.batchParamValues.get(b1);
          for (byte b = 0; b < arrayOfParameter.length; b++) {
            
            if (arrayOfParameter[b].isOutput())
            {
              throw new BatchUpdateException(SQLServerException.getErrString("R_outParamsNotPermittedinBatch"), null, 0, null);
            }
          } 
        } 




        
        PrepStmtBatchExecCmd prepStmtBatchExecCmd = new PrepStmtBatchExecCmd(this);
        
        executeStatement(prepStmtBatchExecCmd);
        
        arrayOfInt = new int[prepStmtBatchExecCmd.updateCounts.length];
        for (byte b2 = 0; b2 < prepStmtBatchExecCmd.updateCounts.length; b2++) {
          arrayOfInt[b2] = (int)prepStmtBatchExecCmd.updateCounts[b2];
        }
        
        if (null != prepStmtBatchExecCmd.batchException)
        {
          throw new BatchUpdateException(prepStmtBatchExecCmd.batchException.getMessage(), prepStmtBatchExecCmd.batchException.getSQLState(), prepStmtBatchExecCmd.batchException.getErrorCode(), arrayOfInt);

        
        }

      
      }
      finally {

        
        this.batchParamValues = null;
      } 
    } 
    loggerExternal.exiting(getClassNameLogging(), "executeBatch", arrayOfInt);
    return arrayOfInt;
  }
  
  public long[] executeLargeBatch() throws SQLServerException, BatchUpdateException {
    long[] arrayOfLong;
    DriverJDBCVersion.checkSupportsJDBC42();
    
    loggerExternal.entering(getClassNameLogging(), "executeLargeBatch");
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();
    discardLastExecutionResults();


    
    if (this.batchParamValues == null) {
      arrayOfLong = new long[0];
    } else {

      
      try {








        
        for (byte b1 = 0; b1 < this.batchParamValues.size(); b1++) {
          
          Parameter[] arrayOfParameter = this.batchParamValues.get(b1);
          for (byte b = 0; b < arrayOfParameter.length; b++) {
            
            if (arrayOfParameter[b].isOutput())
            {
              throw new BatchUpdateException(SQLServerException.getErrString("R_outParamsNotPermittedinBatch"), null, 0, null);
            }
          } 
        } 




        
        PrepStmtBatchExecCmd prepStmtBatchExecCmd = new PrepStmtBatchExecCmd(this);
        
        executeStatement(prepStmtBatchExecCmd);
        
        arrayOfLong = new long[prepStmtBatchExecCmd.updateCounts.length];
        
        for (byte b2 = 0; b2 < prepStmtBatchExecCmd.updateCounts.length; b2++) {
          arrayOfLong[b2] = prepStmtBatchExecCmd.updateCounts[b2];
        }
        
        if (null != prepStmtBatchExecCmd.batchException)
        {
          DriverJDBCVersion.throwBatchUpdateException(prepStmtBatchExecCmd.batchException, arrayOfLong);
        
        }
      }
      finally {
        
        this.batchParamValues = null;
      } 
    }  loggerExternal.exiting(getClassNameLogging(), "executeLargeBatch", arrayOfLong);
    return arrayOfLong;
  }
  
  private final class PrepStmtBatchExecCmd
    extends TDSCommand
  {
    private final SQLServerPreparedStatement stmt;
    SQLServerException batchException;
    long[] updateCounts;
    
    PrepStmtBatchExecCmd(SQLServerPreparedStatement param1SQLServerPreparedStatement1) {
      super(param1SQLServerPreparedStatement1.toString() + " executeBatch", SQLServerPreparedStatement.this.queryTimeout);
      this.stmt = param1SQLServerPreparedStatement1;
    }

    
    final boolean doExecute() throws SQLServerException {
      this.stmt.doExecutePreparedStatementBatch(this);
      return true;
    }

    
    final void processResponse(TDSReader param1TDSReader) throws SQLServerException {
      SQLServerPreparedStatement.this.ensureExecuteResultsReader(param1TDSReader);
      SQLServerPreparedStatement.this.processExecuteResults();
    }
  }

  
  final void doExecutePreparedStatementBatch(PrepStmtBatchExecCmd paramPrepStmtBatchExecCmd) throws SQLServerException {
    this.executeMethod = 4;
    
    paramPrepStmtBatchExecCmd.batchException = null;
    int i = this.batchParamValues.size();
    paramPrepStmtBatchExecCmd.updateCounts = new long[i]; byte b1;
    for (b1 = 0; b1 < i; b1++) {
      paramPrepStmtBatchExecCmd.updateCounts[b1] = -3L;
    }
    b1 = 0;
    byte b2 = 0;
    Vector<CryptoMetadata> vector = new Vector();
    
    if (isSelect(this.userSQL))
    {
      SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_selectNotPermittedinBatch"), (String)null, true);
    }






    
    this.connection.setMaxRows(0);
    
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    
    Parameter[] arrayOfParameter = new Parameter[this.inOutParam.length];
    
    TDSWriter tDSWriter = null;
    while (b2 < i) {

      
      Parameter[] arrayOfParameter1 = this.batchParamValues.get(b1);
      assert arrayOfParameter1.length == arrayOfParameter.length;
      for (byte b = 0; b < arrayOfParameter1.length; b++) {
        arrayOfParameter[b] = arrayOfParameter1[b];
      }
      boolean bool = buildPreparedStrings(arrayOfParameter, false);
      
      if (0 == b2 && Util.shouldHonorAEForParameters(this.stmtColumnEncriptionSetting, this.connection) && 0 < arrayOfParameter.length && !this.isInternalEncryptionQuery) {



        
        getParameterEncryptionMetadata(arrayOfParameter);

        
        buildPreparedStrings(arrayOfParameter, true);

        
        for (byte b3 = 0; b3 < arrayOfParameter.length; b3++)
        {
          vector.add((arrayOfParameter[b3]).cryptoMeta);
        }
      } 

      
      if (0 < b2)
      {
        
        for (byte b3 = 0; b3 < vector.size(); b3++)
        {
          (arrayOfParameter[b3]).cryptoMeta = vector.get(b3);
        }
      }
      
      if (b2 < b1) {

        
        tDSWriter.writeByte((byte)-1);
      }
      else {
        
        resetForReexecute();
        tDSWriter = paramPrepStmtBatchExecCmd.startRequest((byte)3);
      } 








      
      b1++;
      if (doPrepExec(tDSWriter, arrayOfParameter, bool) || b1 == i) {
        
        ensureExecuteResultsReader(paramPrepStmtBatchExecCmd.startResponse(getIsResponseBufferingAdaptive()));
        
        while (b2 < b1) {




          
          startResults();




          
          try {
            if (!getNextResult()) {
              return;
            }


            
            if (null != this.resultSet)
            {
              SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_resultsetGeneratedForUpdate"), (String)null, false);


            
            }

          
          }
          catch (SQLServerException sQLServerException) {



            
            if (this.connection.isSessionUnAvailable() || this.connection.rolledBackTransaction()) {
              throw sQLServerException;
            }

            
            this.updateCount = -3L;
            if (null == paramPrepStmtBatchExecCmd.batchException) {
              paramPrepStmtBatchExecCmd.batchException = sQLServerException;
            }
          } 

          
          paramPrepStmtBatchExecCmd.updateCounts[b2++] = (-1L == this.updateCount) ? -2L : this.updateCount;

          
          processBatch();
        } 


        
        assert b2 == b1;
      } 
    } 
  }

  
  public final void setCharacterStream(int paramInt, Reader paramReader) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setCharacterStream", new Object[] { Integer.valueOf(paramInt), paramReader }); 
    checkClosed();
    setStream(paramInt, StreamType.CHARACTER, paramReader, JavaType.READER, -1L);
    loggerExternal.exiting(getClassNameLogging(), "setCharacterStream");
  }

  
  public final void setCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setCharacterStream", new Object[] { Integer.valueOf(paramInt1), paramReader, Integer.valueOf(paramInt2) }); 
    checkClosed();
    setStream(paramInt1, StreamType.CHARACTER, paramReader, JavaType.READER, paramInt2);
    loggerExternal.exiting(getClassNameLogging(), "setCharacterStream");
  }

  
  public final void setCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setCharacterStream", new Object[] { Integer.valueOf(paramInt), paramReader, Long.valueOf(paramLong) }); 
    checkClosed();
    setStream(paramInt, StreamType.CHARACTER, paramReader, JavaType.READER, paramLong);
    loggerExternal.exiting(getClassNameLogging(), "setCharacterStream");
  }

  
  public final void setNCharacterStream(int paramInt, Reader paramReader) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setNCharacterStream", new Object[] { Integer.valueOf(paramInt), paramReader }); 
    checkClosed();
    setStream(paramInt, StreamType.NCHARACTER, paramReader, JavaType.READER, -1L);
    loggerExternal.exiting(getClassNameLogging(), "setNCharacterStream");
  }

  
  public final void setNCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setNCharacterStream", new Object[] { Integer.valueOf(paramInt), paramReader, Long.valueOf(paramLong) }); 
    checkClosed();
    setStream(paramInt, StreamType.NCHARACTER, paramReader, JavaType.READER, paramLong);
    loggerExternal.exiting(getClassNameLogging(), "setNCharacterStream");
  }
  
  public final void setRef(int paramInt, Ref paramRef) throws SQLServerException {
    NotImplemented();
  }

  
  public final void setBlob(int paramInt, Blob paramBlob) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBlob", new Object[] { Integer.valueOf(paramInt), paramBlob }); 
    checkClosed();
    setValue(paramInt, JDBCType.BLOB, paramBlob, JavaType.BLOB, false);
    loggerExternal.exiting(getClassNameLogging(), "setBlob");
  }

  
  public final void setBlob(int paramInt, InputStream paramInputStream) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBlob", new Object[] { Integer.valueOf(paramInt), paramInputStream }); 
    checkClosed();
    setStream(paramInt, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, -1L);
    loggerExternal.exiting(getClassNameLogging(), "setBlob");
  }

  
  public final void setBlob(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setBlob", new Object[] { Integer.valueOf(paramInt), paramInputStream, Long.valueOf(paramLong) }); 
    checkClosed();
    setStream(paramInt, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramLong);
    loggerExternal.exiting(getClassNameLogging(), "setBlob");
  }

  
  public final void setClob(int paramInt, Clob paramClob) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setClob", new Object[] { Integer.valueOf(paramInt), paramClob }); 
    checkClosed();
    setValue(paramInt, JDBCType.CLOB, paramClob, JavaType.CLOB, false);
    loggerExternal.exiting(getClassNameLogging(), "setClob");
  }

  
  public final void setClob(int paramInt, Reader paramReader) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setClob", new Object[] { Integer.valueOf(paramInt), paramReader }); 
    checkClosed();
    setStream(paramInt, StreamType.CHARACTER, paramReader, JavaType.READER, -1L);
    loggerExternal.exiting(getClassNameLogging(), "setClob");
  }

  
  public final void setClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setClob", new Object[] { Integer.valueOf(paramInt), paramReader, Long.valueOf(paramLong) }); 
    checkClosed();
    setStream(paramInt, StreamType.CHARACTER, paramReader, JavaType.READER, paramLong);
    loggerExternal.exiting(getClassNameLogging(), "setClob");
  }

  
  public final void setNClob(int paramInt, NClob paramNClob) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setNClob", new Object[] { Integer.valueOf(paramInt), paramNClob }); 
    checkClosed();
    setValue(paramInt, JDBCType.NCLOB, paramNClob, JavaType.NCLOB, false);
    loggerExternal.exiting(getClassNameLogging(), "setNClob");
  }

  
  public final void setNClob(int paramInt, Reader paramReader) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setNClob", new Object[] { Integer.valueOf(paramInt), paramReader }); 
    checkClosed();
    setStream(paramInt, StreamType.NCHARACTER, paramReader, JavaType.READER, -1L);
    loggerExternal.exiting(getClassNameLogging(), "setNClob");
  }

  
  public final void setNClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setNClob", new Object[] { Integer.valueOf(paramInt), paramReader, Long.valueOf(paramLong) }); 
    checkClosed();
    setStream(paramInt, StreamType.NCHARACTER, paramReader, JavaType.READER, paramLong);
    loggerExternal.exiting(getClassNameLogging(), "setNClob");
  }
  
  public final void setArray(int paramInt, Array paramArray) throws SQLServerException {
    NotImplemented();
  }

  
  public final void setDate(int paramInt, Date paramDate, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setDate", new Object[] { Integer.valueOf(paramInt), paramDate, paramCalendar }); 
    checkClosed();
    setValue(paramInt, JDBCType.DATE, paramDate, JavaType.DATE, paramCalendar, false);
    loggerExternal.exiting(getClassNameLogging(), "setDate");
  }

  
  public final void setDate(int paramInt, Date paramDate, Calendar paramCalendar, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setDate", new Object[] { Integer.valueOf(paramInt), paramDate, paramCalendar, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(paramInt, JDBCType.DATE, paramDate, JavaType.DATE, paramCalendar, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setDate");
  }

  
  public final void setTime(int paramInt, Time paramTime, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { Integer.valueOf(paramInt), paramTime, paramCalendar }); 
    checkClosed();
    setValue(paramInt, JDBCType.TIME, paramTime, JavaType.TIME, paramCalendar, false);
    loggerExternal.exiting(getClassNameLogging(), "setTime");
  }

  
  public final void setTime(int paramInt, Time paramTime, Calendar paramCalendar, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { Integer.valueOf(paramInt), paramTime, paramCalendar, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(paramInt, JDBCType.TIME, paramTime, JavaType.TIME, paramCalendar, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setTime");
  }

  
  public final void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { Integer.valueOf(paramInt), paramTimestamp, paramCalendar }); 
    checkClosed();
    setValue(paramInt, JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, paramCalendar, false);
    loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
  }

  
  public final void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { Integer.valueOf(paramInt), paramTimestamp, paramCalendar, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    setValue(paramInt, JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, paramCalendar, paramBoolean);
    loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
  }

  
  public final void setNull(int paramInt1, int paramInt2, String paramString) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setNull", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), paramString }); 
    checkClosed();
    if (-153 == paramInt2) {
      
      setObject(setterGetParam(paramInt1), (Object)null, JavaType.TVP, JDBCType.of(paramInt2), (Integer)null, (Integer)null, false, paramInt1, paramString);
    }
    else {
      
      setObject(setterGetParam(paramInt1), (Object)null, JavaType.OBJECT, JDBCType.of(paramInt2), (Integer)null, (Integer)null, false, paramInt1, paramString);
    } 
    loggerExternal.exiting(getClassNameLogging(), "setNull");
  }



  
  public final ParameterMetaData getParameterMetaData() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getParameterMetaData");
    checkClosed();
    SQLServerParameterMetaData sQLServerParameterMetaData = new SQLServerParameterMetaData(this, this.userSQL);
    loggerExternal.exiting(getClassNameLogging(), "getParameterMetaData", sQLServerParameterMetaData);
    return sQLServerParameterMetaData;
  }
  
  public final void setURL(int paramInt, URL paramURL) throws SQLServerException {
    NotImplemented();
  }

  
  public final void setRowId(int paramInt, RowId paramRowId) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();

    
    throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
  }

  
  public final void setSQLXML(int paramInt, SQLXML paramSQLXML) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setSQLXML", new Object[] { Integer.valueOf(paramInt), paramSQLXML }); 
    checkClosed();
    setSQLXMLInternal(paramInt, paramSQLXML);
    loggerExternal.exiting(getClassNameLogging(), "setSQLXML");
  }



  
  public final int executeUpdate(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "executeUpdate", paramString);
    MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_cannotTakeArgumentsPreparedOrCallable"));
    Object[] arrayOfObject = { new String("executeUpdate()") };
    throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
  }
  public final boolean execute(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "execute", paramString);
    MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_cannotTakeArgumentsPreparedOrCallable"));
    Object[] arrayOfObject = { new String("execute()") };
    throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
  }
  public final ResultSet executeQuery(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "executeQuery", paramString);
    MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_cannotTakeArgumentsPreparedOrCallable"));
    Object[] arrayOfObject = { new String("executeQuery()") };
    throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
  }
  public void addBatch(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "addBatch", paramString);
    MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_cannotTakeArgumentsPreparedOrCallable"));
    Object[] arrayOfObject = { new String("addBatch()") };
    throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
  }
}
