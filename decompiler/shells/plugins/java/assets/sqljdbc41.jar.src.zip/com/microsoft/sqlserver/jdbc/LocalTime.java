package com.microsoft.sqlserver.jdbc;

final class LocalTime extends TemporalCompatibility {}
