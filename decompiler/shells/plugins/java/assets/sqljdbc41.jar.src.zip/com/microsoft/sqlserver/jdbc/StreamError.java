package com.microsoft.sqlserver.jdbc;











final class StreamError
  extends StreamPacket
{
  String errorMessage = "";
  
  int errorNumber;
  
  int errorState;
  
  int errorSeverity;
  
  String serverName;
  String procName;
  long lineNumber;
  
  final String getMessage() {
    return this.errorMessage;
  }
  final int getErrorNumber() {
    return this.errorNumber;
  }
  final int getErrorState() {
    return this.errorState;
  }
  final int getErrorSeverity() {
    return this.errorSeverity;
  }

  
  StreamError() {
    super(170);
  }

  
  void setFromTDS(TDSReader paramTDSReader) throws SQLServerException {
    if (170 != paramTDSReader.readUnsignedByte() && !$assertionsDisabled) throw new AssertionError(); 
    setContentsFromTDS(paramTDSReader);
  }

  
  void setContentsFromTDS(TDSReader paramTDSReader) throws SQLServerException {
    paramTDSReader.readUnsignedShort();
    this.errorNumber = paramTDSReader.readInt();
    this.errorState = paramTDSReader.readUnsignedByte();
    this.errorSeverity = paramTDSReader.readUnsignedByte();
    this.errorMessage = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedShort());
    this.serverName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
    this.procName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
    this.lineNumber = paramTDSReader.readUnsignedInt();
  }
}
