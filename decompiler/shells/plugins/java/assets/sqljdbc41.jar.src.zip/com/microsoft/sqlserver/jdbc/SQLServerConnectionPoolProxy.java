package com.microsoft.sqlserver.jdbc;
import java.io.Serializable;
import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.sql.SQLPermission;
import java.sql.SQLXML;
import java.sql.Savepoint;
import java.sql.Statement;
import java.sql.Struct;
import java.text.MessageFormat;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.logging.Level;

class SQLServerConnectionPoolProxy implements ISQLServerConnection, Serializable {
  private static int baseConnectionID = 0;

  
  private SQLServerConnection wrappedConnection;
  
  private boolean bIsOpen;
  
  private final String traceID;
  
  private static final String callAbortPerm = "callAbort";

  
  private static synchronized int nextConnectionID() {
    baseConnectionID++;
    return baseConnectionID;
  }

  
  public String toString() {
    return this.traceID;
  }

  
  SQLServerConnectionPoolProxy(SQLServerConnection paramSQLServerConnection) {
    this.traceID = " ProxyConnectionID:" + nextConnectionID();
    this.wrappedConnection = paramSQLServerConnection;

    
    paramSQLServerConnection.setAssociatedProxy(this);
    this.bIsOpen = true;
  }

  
  void checkClosed() throws SQLServerException {
    if (!this.bIsOpen)
    {
      SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_connectionIsClosed"), null, false);
    }
  }
  
  public Statement createStatement() throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.createStatement();
  }

  
  public PreparedStatement prepareStatement(String paramString) throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.prepareStatement(paramString);
  }

  
  public CallableStatement prepareCall(String paramString) throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.prepareCall(paramString);
  }

  
  public String nativeSQL(String paramString) throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.nativeSQL(paramString);
  }

  
  public void setAutoCommit(boolean paramBoolean) throws SQLServerException {
    checkClosed();
    this.wrappedConnection.setAutoCommit(paramBoolean);
  }

  
  public boolean getAutoCommit() throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.getAutoCommit();
  }




  
  public void commit() throws SQLServerException {
    checkClosed();
    this.wrappedConnection.commit();
  }






  
  public void rollback() throws SQLServerException {
    checkClosed();
    this.wrappedConnection.rollback();
  }

  
  public void abort(Executor paramExecutor) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC41();
    
    if (!this.bIsOpen || null == this.wrappedConnection) {
      return;
    }
    if (null == paramExecutor) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
      Object[] arrayOfObject = { "executor" };
      SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), null, false);
    } 

    
    SecurityManager securityManager = System.getSecurityManager();
    if (securityManager != null) {
      
      try {
        
        SQLPermission sQLPermission = new SQLPermission("callAbort");
        securityManager.checkPermission(sQLPermission);
      }
      catch (SecurityException securityException) {
        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_permissionDenied"));
        Object[] arrayOfObject = { "callAbort" };
        throw new SQLServerException(messageFormat.format(arrayOfObject), null, 0, securityException);
      } 
    }
    
    this.bIsOpen = false;

    
    paramExecutor.execute(new Runnable()
        {
          public void run() {
            if (SQLServerConnectionPoolProxy.this.wrappedConnection.getConnectionLogger().isLoggable(Level.FINER)) {
              SQLServerConnectionPoolProxy.this.wrappedConnection.getConnectionLogger().finer(toString() + " Connection proxy aborted ");
            }
            try {
              SQLServerConnectionPoolProxy.this.wrappedConnection.poolCloseEventNotify();
              SQLServerConnectionPoolProxy.this.wrappedConnection = null;
            }
            catch (SQLException sQLException) {
              
              throw new RuntimeException(sQLException);
            } 
          }
        });
  }

  
  public void close() throws SQLServerException {
    if (this.bIsOpen && null != this.wrappedConnection) {
      
      if (this.wrappedConnection.getConnectionLogger().isLoggable(Level.FINER))
        this.wrappedConnection.getConnectionLogger().finer(toString() + " Connection proxy closed "); 
      this.wrappedConnection.poolCloseEventNotify();
      this.wrappedConnection = null;
    } 
    this.bIsOpen = false;
  }
  
  void internalClose() {
    this.bIsOpen = false;
    this.wrappedConnection = null;
  }


  
  public boolean isClosed() throws SQLServerException {
    return !this.bIsOpen;
  }

  
  public DatabaseMetaData getMetaData() throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.getMetaData();
  }

  
  public void setReadOnly(boolean paramBoolean) throws SQLServerException {
    checkClosed();
    this.wrappedConnection.setReadOnly(paramBoolean);
  }

  
  public boolean isReadOnly() throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.isReadOnly();
  }

  
  public void setCatalog(String paramString) throws SQLServerException {
    checkClosed();
    this.wrappedConnection.setCatalog(paramString);
  }

  
  public String getCatalog() throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.getCatalog();
  }

  
  public void setTransactionIsolation(int paramInt) throws SQLServerException {
    checkClosed();
    this.wrappedConnection.setTransactionIsolation(paramInt);
  }

  
  public int getTransactionIsolation() throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.getTransactionIsolation();
  }

  
  public SQLWarning getWarnings() throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.getWarnings();
  }

  
  public void clearWarnings() throws SQLServerException {
    checkClosed();
    this.wrappedConnection.clearWarnings();
  }





  
  public Statement createStatement(int paramInt1, int paramInt2) throws SQLException {
    checkClosed();
    return this.wrappedConnection.createStatement(paramInt1, paramInt2);
  }




  
  public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2) throws SQLException {
    checkClosed();
    return this.wrappedConnection.prepareStatement(paramString, paramInt1, paramInt2);
  }


  
  public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2) throws SQLException {
    checkClosed();
    return this.wrappedConnection.prepareCall(paramString, paramInt1, paramInt2);
  }

  
  public void setTypeMap(Map<String, Class<?>> paramMap) throws SQLServerException {
    checkClosed();
    this.wrappedConnection.setTypeMap(paramMap);
  }

  
  public Map<String, Class<?>> getTypeMap() throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.getTypeMap();
  }

  
  public Statement createStatement(int paramInt1, int paramInt2, int paramInt3) throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.createStatement(paramInt1, paramInt2, paramInt3);
  }






  
  public Statement createStatement(int paramInt1, int paramInt2, int paramInt3, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.createStatement(paramInt1, paramInt2, paramInt3, paramSQLServerStatementColumnEncryptionSetting);
  }

  
  public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.prepareStatement(paramString, paramInt1, paramInt2, paramInt3);
  }







  
  public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2, int paramInt3, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.prepareStatement(paramString, paramInt1, paramInt2, paramInt3, paramSQLServerStatementColumnEncryptionSetting);
  }

  
  public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.prepareCall(paramString, paramInt1, paramInt2, paramInt3);
  }







  
  public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2, int paramInt3, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.prepareCall(paramString, paramInt1, paramInt2, paramInt3, paramSQLServerStatementColumnEncryptionSetting);
  }



  
  public PreparedStatement prepareStatement(String paramString, int paramInt) throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.prepareStatement(paramString, paramInt);
  }

  
  public PreparedStatement prepareStatement(String paramString, int paramInt, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.prepareStatement(paramString, paramInt, paramSQLServerStatementColumnEncryptionSetting);
  }

  
  public PreparedStatement prepareStatement(String paramString, int[] paramArrayOfint) throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.prepareStatement(paramString, paramArrayOfint);
  }

  
  public PreparedStatement prepareStatement(String paramString, int[] paramArrayOfint, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.prepareStatement(paramString, paramArrayOfint, paramSQLServerStatementColumnEncryptionSetting);
  }

  
  public PreparedStatement prepareStatement(String paramString, String[] paramArrayOfString) throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.prepareStatement(paramString, paramArrayOfString);
  }

  
  public PreparedStatement prepareStatement(String paramString, String[] paramArrayOfString, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.prepareStatement(paramString, paramArrayOfString, paramSQLServerStatementColumnEncryptionSetting);
  }



  
  public void releaseSavepoint(Savepoint paramSavepoint) throws SQLServerException {
    checkClosed();
    this.wrappedConnection.releaseSavepoint(paramSavepoint);
  }

  
  public Savepoint setSavepoint(String paramString) throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.setSavepoint(paramString);
  }

  
  public Savepoint setSavepoint() throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.setSavepoint();
  }

  
  public void rollback(Savepoint paramSavepoint) throws SQLServerException {
    checkClosed();
    this.wrappedConnection.rollback(paramSavepoint);
  }

  
  public int getHoldability() throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.getHoldability();
  }

  
  public void setHoldability(int paramInt) throws SQLServerException {
    checkClosed();
    this.wrappedConnection.setHoldability(paramInt);
  }

  
  public int getNetworkTimeout() throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC41();

    
    throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
  }

  
  public void setNetworkTimeout(Executor paramExecutor, int paramInt) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC41();

    
    throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
  }

  
  public String getSchema() throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC41();
    
    checkClosed();
    return this.wrappedConnection.getSchema();
  }

  
  public void setSchema(String paramString) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC41();
    
    checkClosed();
    this.wrappedConnection.setSchema(paramString);
  }

  
  public Array createArrayOf(String paramString, Object[] paramArrayOfObject) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    
    checkClosed();
    return this.wrappedConnection.createArrayOf(paramString, paramArrayOfObject);
  }

  
  public Blob createBlob() throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    
    checkClosed();
    return this.wrappedConnection.createBlob();
  }

  
  public Clob createClob() throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    
    checkClosed();
    return this.wrappedConnection.createClob();
  }

  
  public NClob createNClob() throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    
    checkClosed();
    return this.wrappedConnection.createNClob();
  }

  
  public SQLXML createSQLXML() throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    
    checkClosed();
    return this.wrappedConnection.createSQLXML();
  }

  
  public Struct createStruct(String paramString, Object[] paramArrayOfObject) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    
    checkClosed();
    return this.wrappedConnection.createStruct(paramString, paramArrayOfObject);
  }

  
  public Properties getClientInfo() throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    
    checkClosed();
    return this.wrappedConnection.getClientInfo();
  }

  
  public String getClientInfo(String paramString) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    
    checkClosed();
    return this.wrappedConnection.getClientInfo(paramString);
  }

  
  public void setClientInfo(Properties paramProperties) throws SQLClientInfoException {
    DriverJDBCVersion.checkSupportsJDBC4();

    
    this.wrappedConnection.setClientInfo(paramProperties);
  }

  
  public void setClientInfo(String paramString1, String paramString2) throws SQLClientInfoException {
    DriverJDBCVersion.checkSupportsJDBC4();

    
    this.wrappedConnection.setClientInfo(paramString1, paramString2);
  }

  
  public boolean isValid(int paramInt) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    
    checkClosed();
    return this.wrappedConnection.isValid(paramInt);
  }

  
  public boolean isWrapperFor(Class<?> paramClass) throws SQLException {
    this.wrappedConnection.getConnectionLogger().entering(toString(), "isWrapperFor", paramClass);
    DriverJDBCVersion.checkSupportsJDBC4();
    boolean bool = paramClass.isInstance(this);
    this.wrappedConnection.getConnectionLogger().exiting(toString(), "isWrapperFor", Boolean.valueOf(bool));
    return bool;
  }
  
  public <T> T unwrap(Class<T> paramClass) throws SQLException {
    T t;
    this.wrappedConnection.getConnectionLogger().entering(toString(), "unwrap", paramClass);
    DriverJDBCVersion.checkSupportsJDBC4();


    
    try {
      t = paramClass.cast(this);
    }
    catch (ClassCastException classCastException) {
      
      SQLServerException sQLServerException = new SQLServerException(classCastException.getMessage(), classCastException);
      throw sQLServerException;
    } 
    this.wrappedConnection.getConnectionLogger().exiting(toString(), "unwrap", t);
    return t;
  }

  
  public UUID getClientConnectionId() throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.getClientConnectionId();
  }

  
  public synchronized void setSendTimeAsDatetime(boolean paramBoolean) throws SQLServerException {
    checkClosed();
    this.wrappedConnection.setSendTimeAsDatetime(paramBoolean);
  }

  
  public final synchronized boolean getSendTimeAsDatetime() throws SQLServerException {
    checkClosed();
    return this.wrappedConnection.getSendTimeAsDatetime();
  }
}
