package com.microsoft.sqlserver.jdbc;






abstract class StreamPacket
{
  int packetType;
  
  final int getTokenType() {
    return this.packetType;
  }
  
  StreamPacket() {
    this.packetType = 0;
  }

  
  StreamPacket(int paramInt) {
    this.packetType = paramInt;
  }
  
  abstract void setFromTDS(TDSReader paramTDSReader) throws SQLServerException;
}
