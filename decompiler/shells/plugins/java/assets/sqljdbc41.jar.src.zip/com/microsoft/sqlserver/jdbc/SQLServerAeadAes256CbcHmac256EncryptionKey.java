package com.microsoft.sqlserver.jdbc;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.text.MessageFormat;





















class SQLServerAeadAes256CbcHmac256EncryptionKey
  extends SQLServerSymmetricKey
{
  static final int keySize = 256;
  private final String algorithmName;
  private String encryptionKeySaltFormat;
  private String macKeySaltFormat;
  private String ivKeySaltFormat;
  private SQLServerSymmetricKey encryptionKey;
  private SQLServerSymmetricKey macKey;
  private SQLServerSymmetricKey ivKey;
  
  SQLServerAeadAes256CbcHmac256EncryptionKey(byte[] paramArrayOfbyte, String paramString) throws SQLServerException {
    super(paramArrayOfbyte);
    this.algorithmName = paramString;
    this.encryptionKeySaltFormat = "Microsoft SQL Server cell encryption key with encryption algorithm:" + this.algorithmName + " and key length:" + 'Ā';
    
    this.macKeySaltFormat = "Microsoft SQL Server cell MAC key with encryption algorithm:" + this.algorithmName + " and key length:" + 'Ā';
    
    this.ivKeySaltFormat = "Microsoft SQL Server cell IV key with encryption algorithm:" + this.algorithmName + " and key length:" + 'Ā';
    
    byte b = 32;
    if (paramArrayOfbyte.length != b) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidKeySize"));
      Object[] arrayOfObject = { Integer.valueOf(paramArrayOfbyte.length), Integer.valueOf(b), this.algorithmName };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    } 



    
    byte[] arrayOfByte = new byte[b];


    
    try {
      arrayOfByte = SQLServerSecurityUtility.getHMACWithSHA256(this.encryptionKeySaltFormat.getBytes("UTF-16LE"), paramArrayOfbyte, arrayOfByte.length);



      
      this.encryptionKey = new SQLServerSymmetricKey(arrayOfByte);

      
      byte[] arrayOfByte1 = new byte[b];
      arrayOfByte1 = SQLServerSecurityUtility.getHMACWithSHA256(this.macKeySaltFormat.getBytes("UTF-16LE"), paramArrayOfbyte, arrayOfByte1.length);



      
      this.macKey = new SQLServerSymmetricKey(arrayOfByte1);

      
      byte[] arrayOfByte2 = new byte[b];
      arrayOfByte2 = SQLServerSecurityUtility.getHMACWithSHA256(this.ivKeySaltFormat.getBytes("UTF-16LE"), paramArrayOfbyte, arrayOfByte2.length);


      
      this.ivKey = new SQLServerSymmetricKey(arrayOfByte2);
    }
    catch (UnsupportedEncodingException unsupportedEncodingException) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
      
      Object[] arrayOfObject = { "UTF-16LE" };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    }
    catch (InvalidKeyException|java.security.NoSuchAlgorithmException invalidKeyException) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_KeyExtractionFailed"));
      
      Object[] arrayOfObject = { invalidKeyException.getMessage() };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    } 
  }







  
  byte[] getEncryptionKey() {
    return this.encryptionKey.getRootKey();
  }





  
  byte[] getMacKey() {
    return this.macKey.getRootKey();
  }





  
  byte[] getIVKey() {
    return this.ivKey.getRootKey();
  }
}
