package com.microsoft.sqlserver.jdbc;

import java.security.Key;
import java.security.cert.X509Certificate;




















class CertificateDetails
{
  X509Certificate certificate;
  Key privateKey;
  
  CertificateDetails(X509Certificate paramX509Certificate, Key paramKey) {
    this.certificate = paramX509Certificate;
    this.privateKey = paramKey;
  }
}
