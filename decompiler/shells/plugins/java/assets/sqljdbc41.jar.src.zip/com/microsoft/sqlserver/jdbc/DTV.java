package com.microsoft.sqlserver.jdbc;

import java.io.InputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.MathContext;
import java.math.RoundingMode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.MessageFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.SimpleTimeZone;
import java.util.TimeZone;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import microsoft.sql.DateTimeOffset;





















































final class DTV
{
  private static final Logger aeLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.DTV");

  
  private DTVImpl impl;

  
  CryptoMetadata cryptoMeta = null;
  JDBCType jdbcTypeSetByUser = null;
  int valueLength = 0;
















  
  void setValue(SQLCollation paramSQLCollation, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, StreamSetterArgs paramStreamSetterArgs, Calendar paramCalendar, Integer paramInteger, SQLServerConnection paramSQLServerConnection, boolean paramBoolean) throws SQLServerException {
    if (null == this.impl) {
      this.impl = new AppDTVImpl();
    }
    this.impl.setValue(this, paramSQLCollation, paramJDBCType, paramObject, paramJavaType, paramStreamSetterArgs, paramCalendar, paramInteger, paramSQLServerConnection, paramBoolean);
  }

  
  final void setValue(Object paramObject, JavaType paramJavaType) {
    this.impl.setValue(paramObject, paramJavaType);
  }
  final void clear() {
    this.impl = null;
  }
  
  final void skipValue(TypeInfo paramTypeInfo, TDSReader paramTDSReader, boolean paramBoolean) throws SQLServerException {
    if (null == this.impl) {
      this.impl = new ServerDTVImpl();
    }
    this.impl.skipValue(paramTypeInfo, paramTDSReader, paramBoolean);
  }

  
  final void initFromCompressedNull() {
    if (null == this.impl) {
      this.impl = new ServerDTVImpl();
    }
    this.impl.initFromCompressedNull();
  }

  
  final void setStreamSetterArgs(StreamSetterArgs paramStreamSetterArgs) {
    this.impl.setStreamSetterArgs(paramStreamSetterArgs);
  }

  
  final void setCalendar(Calendar paramCalendar) {
    this.impl.setCalendar(paramCalendar);
  }

  
  final void setScale(Integer paramInteger) {
    this.impl.setScale(paramInteger);
  }

  
  final void setForceEncrypt(boolean paramBoolean) {
    this.impl.setForceEncrypt(paramBoolean);
  }
  
  StreamSetterArgs getStreamSetterArgs() { return this.impl.getStreamSetterArgs(); }
  Calendar getCalendar() { return this.impl.getCalendar(); } Integer getScale() {
    return this.impl.getScale();
  }



  
  boolean isNull() {
    return (null == this.impl || this.impl.isNull());
  }





  
  final boolean isInitialized() {
    return (null != this.impl);
  }

  
  final void setJdbcType(JDBCType paramJDBCType) {
    if (null == this.impl) {
      this.impl = new AppDTVImpl();
    }
    this.impl.setJdbcType(paramJDBCType);
  }




  
  final JDBCType getJdbcType() {
    assert null != this.impl;
    return this.impl.getJdbcType();
  }




  
  final JavaType getJavaType() {
    assert null != this.impl;
    return this.impl.getJavaType();
  }















  
  Object getValue(JDBCType paramJDBCType, int paramInt, InputStreamGetterArgs paramInputStreamGetterArgs, Calendar paramCalendar, TypeInfo paramTypeInfo, CryptoMetadata paramCryptoMetadata, TDSReader paramTDSReader) throws SQLServerException {
    if (null == this.impl)
      this.impl = new ServerDTVImpl(); 
    return this.impl.getValue(this, paramJDBCType, paramInt, paramInputStreamGetterArgs, paramCalendar, paramTypeInfo, paramCryptoMetadata, paramTDSReader);
  }

  
  Object getSetterValue() {
    return this.impl.getSetterValue();
  }





  
  void setImpl(DTVImpl paramDTVImpl) {
    this.impl = paramDTVImpl;
  }

  
  final class SendByRPCOp
    extends DTVExecuteOp
  {
    private final String name;
    
    private final TypeInfo typeInfo;
    
    private final SQLCollation collation;
    
    private final int precision;
    
    private final int outScale;
    
    private final boolean isOutParam;
    
    private final TDSWriter tdsWriter;
    
    private final SQLServerConnection conn;
    
    SendByRPCOp(String param1String, TypeInfo param1TypeInfo, SQLCollation param1SQLCollation, int param1Int1, int param1Int2, boolean param1Boolean, TDSWriter param1TDSWriter, SQLServerConnection param1SQLServerConnection) {
      this.name = param1String;
      this.typeInfo = param1TypeInfo;
      this.collation = param1SQLCollation;
      this.precision = param1Int1;
      this.outScale = param1Int2;
      this.isOutParam = param1Boolean;
      this.tdsWriter = param1TDSWriter;
      this.conn = param1SQLServerConnection;
    }

    
    void execute(DTV param1DTV, String param1String) throws SQLServerException {
      this.tdsWriter.writeRPCStringUnicode(this.name, param1String, this.isOutParam, this.collation);
    }


    
    void execute(DTV param1DTV, Clob param1Clob) throws SQLServerException {
      assert null != param1Clob;
      
      long l = 0L;
      Reader reader = null;

      
      try {
        l = DataTypes.getCheckedLength(this.conn, param1DTV.getJdbcType(), param1Clob.length(), false);
        reader = param1Clob.getCharacterStream();
      }
      catch (SQLException sQLException) {
        
        SQLServerException.makeFromDriverError(this.conn, null, sQLException.getMessage(), null, false);
      } 

      
      JDBCType jDBCType = param1DTV.getJdbcType();
      if (null != this.collation && (JDBCType.CHAR == jDBCType || JDBCType.VARCHAR == jDBCType || JDBCType.LONGVARCHAR == jDBCType || JDBCType.CLOB == jDBCType)) {




        
        if (null == reader)
        {
          this.tdsWriter.writeRPCByteArray(this.name, null, this.isOutParam, jDBCType, this.collation);


        
        }
        else
        {

          
          ReaderInputStream readerInputStream = null;

          
          try {
            readerInputStream = new ReaderInputStream(reader, this.collation.getCharset(), l);


          
          }
          catch (UnsupportedEncodingException unsupportedEncodingException) {
            
            MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_encodingErrorWritingTDS"));
            Object[] arrayOfObject = { new String(unsupportedEncodingException.getMessage()) };
            SQLServerException.makeFromDriverError(this.conn, null, messageFormat.format(arrayOfObject), null, true);
          } 





          
          this.tdsWriter.writeRPCInputStream(this.name, readerInputStream, -1L, this.isOutParam, jDBCType, this.collation);



        
        }



      
      }
      else if (null == reader) {
        
        this.tdsWriter.writeRPCStringUnicode(this.name, null, this.isOutParam, this.collation);
      }
      else {
        
        this.tdsWriter.writeRPCReaderUnicode(this.name, reader, l, this.isOutParam, this.collation);
      } 
    }







    
    void execute(DTV param1DTV, Byte param1Byte) throws SQLServerException {
      this.tdsWriter.writeRPCByte(this.name, param1Byte, this.isOutParam);
    }

    
    void execute(DTV param1DTV, Integer param1Integer) throws SQLServerException {
      this.tdsWriter.writeRPCInt(this.name, param1Integer, this.isOutParam);
    }

    
    void execute(DTV param1DTV, Time param1Time) throws SQLServerException {
      sendTemporal(param1DTV, JavaType.TIME, param1Time);
    }




    
    void execute(DTV param1DTV, Date param1Date) throws SQLServerException {
      sendTemporal(param1DTV, JavaType.DATE, param1Date);
    }




    
    void execute(DTV param1DTV, Timestamp param1Timestamp) throws SQLServerException {
      sendTemporal(param1DTV, JavaType.TIMESTAMP, param1Timestamp);
    }




    
    void execute(DTV param1DTV, Date param1Date) throws SQLServerException {
      sendTemporal(param1DTV, JavaType.UTILDATE, param1Date);
    }




    
    void execute(DTV param1DTV, Calendar param1Calendar) throws SQLServerException {
      sendTemporal(param1DTV, JavaType.CALENDAR, param1Calendar);
    }




    
    void execute(DTV param1DTV, LocalDate param1LocalDate) throws SQLServerException {
      sendTemporal(param1DTV, JavaType.LOCALDATE, param1LocalDate);
    }




    
    void execute(DTV param1DTV, LocalTime param1LocalTime) throws SQLServerException {
      sendTemporal(param1DTV, JavaType.LOCALTIME, param1LocalTime);
    }




    
    void execute(DTV param1DTV, LocalDateTime param1LocalDateTime) throws SQLServerException {
      sendTemporal(param1DTV, JavaType.LOCALDATETIME, param1LocalDateTime);
    }




    
    void execute(DTV param1DTV, OffsetTime param1OffsetTime) throws SQLServerException {
      sendTemporal(param1DTV, JavaType.OFFSETTIME, param1OffsetTime);
    }




    
    void execute(DTV param1DTV, OffsetDateTime param1OffsetDateTime) throws SQLServerException {
      sendTemporal(param1DTV, JavaType.OFFSETDATETIME, param1OffsetDateTime);
    }




    
    void execute(DTV param1DTV, DateTimeOffset param1DateTimeOffset) throws SQLServerException {
      sendTemporal(param1DTV, JavaType.DATETIMEOFFSET, param1DateTimeOffset);
    }





    
    void execute(DTV param1DTV, TVP param1TVP) throws SQLServerException {
      this.tdsWriter.writeTVP(param1TVP);
    }







    
    private void clearSetCalendar(Calendar param1Calendar, boolean param1Boolean, Integer param1Integer1, Integer param1Integer2, Integer param1Integer3, Integer param1Integer4, Integer param1Integer5, Integer param1Integer6) {
      param1Calendar.clear();
      param1Calendar.setLenient(param1Boolean);
      if (null != param1Integer1)
      {
        param1Calendar.set(1, param1Integer1.intValue());
      }
      if (null != param1Integer2)
      {
        param1Calendar.set(2, param1Integer2.intValue());
      }
      if (null != param1Integer3)
      {
        param1Calendar.set(5, param1Integer3.intValue());
      }
      if (null != param1Integer4)
      {
        param1Calendar.set(11, param1Integer4.intValue());
      }
      if (null != param1Integer5)
      {
        param1Calendar.set(12, param1Integer5.intValue());
      }
      if (null != param1Integer6)
      {
        param1Calendar.set(13, param1Integer6.intValue());
      }
    }

















    
    private void sendTemporal(DTV param1DTV, JavaType param1JavaType, Object param1Object) throws SQLServerException {
      JDBCType jDBCType = param1DTV.getJdbcType();
      GregorianCalendar gregorianCalendar = null;
      int i = 0;
      int j = 0;
























      
      if (null != param1Object) {
        Timestamp timestamp; LocalTime localTime; LocalDateTime localDateTime; OffsetTime offsetTime; String str1; OffsetDateTime offsetDateTime; String str2; DateTimeOffset dateTimeOffset;
        TimeZone timeZone = TimeZone.getDefault();
        long l = 0L;

        
        switch (param1JavaType) {


          
          case DATETIME2:
            timeZone = (null != param1DTV.getCalendar()) ? param1DTV.getCalendar().getTimeZone() : TimeZone.getDefault();

            
            l = ((Time)param1Object).getTime();
            i = 1000000 * (int)(l % 1000L);







            
            if (i < 0) {
              i += 1000000000;
            }
            break;



          
          case DATE:
            timeZone = (null != param1DTV.getCalendar()) ? param1DTV.getCalendar().getTimeZone() : TimeZone.getDefault();

            
            l = ((Date)param1Object).getTime();
            break;



          
          case TIME:
            timeZone = (null != param1DTV.getCalendar()) ? param1DTV.getCalendar().getTimeZone() : TimeZone.getDefault();

            
            timestamp = (Timestamp)param1Object;
            l = timestamp.getTime();
            i = timestamp.getNanos();
            break;





          
          case DATETIMEOFFSET:
            timeZone = (null != param1DTV.getCalendar()) ? param1DTV.getCalendar().getTimeZone() : TimeZone.getDefault();

            
            l = ((Date)param1Object).getTime();


            
            i = 1000000 * (int)(l % 1000L);







            
            if (i < 0) {
              i += 1000000000;
            }
            break;




          
          case DATETIME:
            timeZone = (null != param1DTV.getCalendar()) ? param1DTV.getCalendar().getTimeZone() : TimeZone.getDefault();

            
            l = ((Calendar)param1Object).getTimeInMillis();


            
            i = 1000000 * (int)(l % 1000L);







            
            if (i < 0) {
              i += 1000000000;
            }
            break;

          
          case SMALLDATETIME:
            gregorianCalendar = new GregorianCalendar(UTC.timeZone, Locale.US);

            
            clearSetCalendar(gregorianCalendar, true, Integer.valueOf(((LocalDate)param1Object).getYear()), Integer.valueOf(((LocalDate)param1Object).getMonthValue() - 1), Integer.valueOf(((LocalDate)param1Object).getDayOfMonth()), null, null, null);
            break;





          
          case VARBINARY:
            gregorianCalendar = new GregorianCalendar(UTC.timeZone, Locale.US);

            
            localTime = (LocalTime)param1Object;
            clearSetCalendar(gregorianCalendar, true, Integer.valueOf(this.conn.baseYear()), Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(localTime.getHour()), Integer.valueOf(localTime.getMinute()), Integer.valueOf(localTime.getSecond()));



            
            i = localTime.getNano();
            break;





          
          case VARBINARYMAX:
            gregorianCalendar = new GregorianCalendar(UTC.timeZone, Locale.US);
            
            localDateTime = (LocalDateTime)param1Object;
            clearSetCalendar(gregorianCalendar, true, Integer.valueOf(localDateTime.getYear()), Integer.valueOf(localDateTime.getMonthValue() - 1), Integer.valueOf(localDateTime.getDayOfMonth()), Integer.valueOf(localDateTime.getHour()), Integer.valueOf(localDateTime.getMinute()), Integer.valueOf(localDateTime.getSecond()));





            
            i = localDateTime.getNano();
            break;



          
          case null:
            offsetTime = (OffsetTime)param1Object;



            
            try {
              j = offsetTime.getOffset().getTotalSeconds() / 60;
            }
            catch (Exception exception) {
              
              throw new SQLServerException(SQLServerException.getErrString("R_zoneOffsetError"), null, 0, null);
            } 



            
            i = offsetTime.getNano();





            
            timeZone = (JDBCType.TIME_WITH_TIMEZONE == jDBCType && (null == this.typeInfo || SSType.DATETIMEOFFSET == this.typeInfo.getSSType())) ? UTC.timeZone : new SimpleTimeZone(j * 60 * 1000, "");






            
            str1 = this.conn.baseYear() + "-01-01" + ' ' + offsetTime.getHour() + ':' + offsetTime.getMinute() + ':' + offsetTime.getSecond();


            
            l = Timestamp.valueOf(str1).getTime();
            break;
          
          case null:
            offsetDateTime = (OffsetDateTime)param1Object;



            
            try {
              j = offsetDateTime.getOffset().getTotalSeconds() / 60;
            }
            catch (Exception exception) {
              
              throw new SQLServerException(SQLServerException.getErrString("R_zoneOffsetError"), null, 0, null);
            } 




            
            i = offsetDateTime.getNano();





            
            timeZone = ((JDBCType.TIMESTAMP_WITH_TIMEZONE == jDBCType || JDBCType.TIME_WITH_TIMEZONE == jDBCType) && (null == this.typeInfo || SSType.DATETIMEOFFSET == this.typeInfo.getSSType())) ? UTC.timeZone : new SimpleTimeZone(j * 60 * 1000, "");






            
            str2 = String.format("%04d", new Object[] { Integer.valueOf(offsetDateTime.getYear()) }) + '-' + offsetDateTime.getMonthValue() + '-' + offsetDateTime.getDayOfMonth() + ' ' + offsetDateTime.getHour() + ':' + offsetDateTime.getMinute() + ':' + offsetDateTime.getSecond();




            
            l = Timestamp.valueOf(str2).getTime();
            break;

          
          case null:
            dateTimeOffset = (DateTimeOffset)param1Object;
            
            l = dateTimeOffset.getTimestamp().getTime();
            i = dateTimeOffset.getTimestamp().getNanos();
            j = dateTimeOffset.getMinutesOffset();


            
            assert null == param1DTV.getCalendar();





            
            timeZone = (JDBCType.DATETIMEOFFSET == jDBCType && (null == this.typeInfo || SSType.DATETIMEOFFSET == this.typeInfo.getSSType() || SSType.VARBINARY == this.typeInfo.getSSType() || SSType.VARBINARYMAX == this.typeInfo.getSSType())) ? UTC.timeZone : new SimpleTimeZone(j * 60 * 1000, "");
            break;







          
          default:
            throw new AssertionError("Unexpected JavaType: " + param1JavaType);
        } 

        
        if (null == gregorianCalendar) {


          
          gregorianCalendar = new GregorianCalendar(timeZone, Locale.US);


          
          gregorianCalendar.setLenient(true);


          
          gregorianCalendar.clear();

          
          gregorianCalendar.setTimeInMillis(l);
        } 
      } 




      
      if (null != this.typeInfo) {
        
        switch (this.typeInfo.getSSType()) {

          
          case DATETIME2:
            this.tdsWriter.writeRPCDateTime2(this.name, timestampNormalizedCalendar(gregorianCalendar, param1JavaType, this.conn.baseYear()), i, this.typeInfo.getScale(), this.isOutParam);
            return;






          
          case DATE:
            this.tdsWriter.writeRPCDate(this.name, gregorianCalendar, this.isOutParam);
            return;





          
          case TIME:
            this.tdsWriter.writeRPCTime(this.name, gregorianCalendar, i, this.typeInfo.getScale(), this.isOutParam);
            return;









          
          case DATETIMEOFFSET:
            if (JavaType.DATETIMEOFFSET != param1JavaType) {
              
              gregorianCalendar = timestampNormalizedCalendar(localCalendarAsUTC(gregorianCalendar), param1JavaType, this.conn.baseYear());




              
              j = 0;
            } 
            
            this.tdsWriter.writeRPCDateTimeOffset(this.name, gregorianCalendar, j, i, this.typeInfo.getScale(), this.isOutParam);
            return;







          
          case DATETIME:
          case SMALLDATETIME:
            this.tdsWriter.writeRPCDateTime(this.name, timestampNormalizedCalendar(gregorianCalendar, param1JavaType, this.conn.baseYear()), i, this.isOutParam);
            return;




          
          case VARBINARY:
          case VARBINARYMAX:
            switch (jDBCType) {
              
              case DATETIME2:
              case DATE:
                this.tdsWriter.writeEncryptedRPCDateTime(this.name, timestampNormalizedCalendar(gregorianCalendar, param1JavaType, this.conn.baseYear()), i, this.isOutParam, jDBCType);
                return;





              
              case TIME:
                assert null != DTV.this.cryptoMeta;
                this.tdsWriter.writeEncryptedRPCDateTime2(this.name, timestampNormalizedCalendar(gregorianCalendar, param1JavaType, this.conn.baseYear()), i, DTV.this.valueLength, this.isOutParam);
                return;






              
              case DATETIMEOFFSET:
                assert null != DTV.this.cryptoMeta;
                this.tdsWriter.writeEncryptedRPCTime(this.name, gregorianCalendar, i, DTV.this.valueLength, this.isOutParam);
                return;




              
              case DATETIME:
                assert null != DTV.this.cryptoMeta;
                this.tdsWriter.writeEncryptedRPCDate(this.name, gregorianCalendar, this.isOutParam);
                return;



              
              case SMALLDATETIME:
              case VARBINARY:
                if (JavaType.DATETIMEOFFSET != param1JavaType && JavaType.OFFSETDATETIME != param1JavaType) {

                  
                  gregorianCalendar = timestampNormalizedCalendar(localCalendarAsUTC(gregorianCalendar), param1JavaType, this.conn.baseYear());




                  
                  j = 0;
                } 
                
                assert null != DTV.this.cryptoMeta;
                this.tdsWriter.writeEncryptedRPCDateTimeOffset(this.name, gregorianCalendar, j, i, DTV.this.valueLength, this.isOutParam);
                return;
            } 






            
            assert false : "Unexpected JDBCType: " + jDBCType;
            return;
        } 

        
        assert false : "Unexpected SSType: " + this.typeInfo.getSSType();











      
      }
      else if (this.conn.isKatmaiOrLater()) {
        
        if (DTV.aeLogger.isLoggable(Level.FINE) && null != DTV.this.cryptoMeta)
        {
          DTV.aeLogger.fine("Encrypting temporal data type.");
        }
        
        switch (jDBCType) {
          
          case DATETIME2:
          case DATE:
          case TIME:
            if (null != DTV.this.cryptoMeta) {
              
              if (JDBCType.DATETIME == jDBCType || JDBCType.SMALLDATETIME == jDBCType)
              {
                this.tdsWriter.writeEncryptedRPCDateTime(this.name, timestampNormalizedCalendar(gregorianCalendar, param1JavaType, this.conn.baseYear()), i, this.isOutParam, jDBCType);




              
              }
              else if (0 == DTV.this.valueLength)
              {
                this.tdsWriter.writeEncryptedRPCDateTime2(this.name, timestampNormalizedCalendar(gregorianCalendar, param1JavaType, this.conn.baseYear()), i, this.outScale, this.isOutParam);


              
              }
              else
              {

                
                this.tdsWriter.writeEncryptedRPCDateTime2(this.name, timestampNormalizedCalendar(gregorianCalendar, param1JavaType, this.conn.baseYear()), i, DTV.this.valueLength, this.isOutParam);
              
              }

            
            }
            else {

              
              this.tdsWriter.writeRPCDateTime2(this.name, timestampNormalizedCalendar(gregorianCalendar, param1JavaType, this.conn.baseYear()), i, 7, this.isOutParam);
            } 
            return;






          
          case DATETIMEOFFSET:
            if (null != DTV.this.cryptoMeta) {
              
              if (0 == DTV.this.valueLength) {
                this.tdsWriter.writeEncryptedRPCTime(this.name, gregorianCalendar, i, this.outScale, this.isOutParam);

              
              }
              else {

                
                this.tdsWriter.writeEncryptedRPCTime(this.name, gregorianCalendar, i, DTV.this.valueLength, this.isOutParam);


              
              }



            
            }
            else if (this.conn.getSendTimeAsDatetime()) {
              
              this.tdsWriter.writeRPCDateTime(this.name, timestampNormalizedCalendar(gregorianCalendar, JavaType.TIME, 1970), i, this.isOutParam);

            
            }
            else {

              
              this.tdsWriter.writeRPCTime(this.name, gregorianCalendar, i, 7, this.isOutParam);
            } 
            return;







          
          case DATETIME:
            if (null != DTV.this.cryptoMeta) {
              this.tdsWriter.writeEncryptedRPCDate(this.name, gregorianCalendar, this.isOutParam);
            } else {
              this.tdsWriter.writeRPCDate(this.name, gregorianCalendar, this.isOutParam);
            } 
            return;






          
          case VARBINARYMAX:
            if (JavaType.OFFSETDATETIME != param1JavaType && JavaType.OFFSETTIME != param1JavaType) {

              
              gregorianCalendar = timestampNormalizedCalendar(localCalendarAsUTC(gregorianCalendar), param1JavaType, this.conn.baseYear());




              
              j = 0;
            } 
            
            this.tdsWriter.writeRPCDateTimeOffset(this.name, gregorianCalendar, j, i, 7, this.isOutParam);
            return;










          
          case SMALLDATETIME:
          case VARBINARY:
            if (JavaType.DATETIMEOFFSET != param1JavaType && JavaType.OFFSETDATETIME != param1JavaType) {

              
              gregorianCalendar = timestampNormalizedCalendar(localCalendarAsUTC(gregorianCalendar), param1JavaType, this.conn.baseYear());




              
              j = 0;
            } 
            
            if (null != DTV.this.cryptoMeta) {
              
              if (0 == DTV.this.valueLength) {
                this.tdsWriter.writeEncryptedRPCDateTimeOffset(this.name, gregorianCalendar, j, i, this.outScale, this.isOutParam);


              
              }
              else {


                
                this.tdsWriter.writeEncryptedRPCDateTimeOffset(this.name, gregorianCalendar, j, i, (0 == DTV.this.valueLength) ? 7 : DTV.this.valueLength, this.isOutParam);

              
              }

            
            }
            else {

              
              this.tdsWriter.writeRPCDateTimeOffset(this.name, gregorianCalendar, j, i, 7, this.isOutParam);
            } 
            return;
        } 






        
        assert false : "Unexpected JDBCType: " + jDBCType;







      
      }
      else {







        
        assert JDBCType.TIME == jDBCType || JDBCType.DATE == jDBCType || JDBCType.TIMESTAMP == jDBCType : "Unexpected JDBCType: " + jDBCType;
        
        this.tdsWriter.writeRPCDateTime(this.name, timestampNormalizedCalendar(gregorianCalendar, param1JavaType, 1970), i, this.isOutParam);
      } 
    }






















    
    private GregorianCalendar timestampNormalizedCalendar(GregorianCalendar param1GregorianCalendar, JavaType param1JavaType, int param1Int) {
      if (null != param1GregorianCalendar)
      {
        switch (param1JavaType) {



          
          case DATE:
          case SMALLDATETIME:
            param1GregorianCalendar.set(11, 0);
            param1GregorianCalendar.set(12, 0);
            param1GregorianCalendar.set(13, 0);
            param1GregorianCalendar.set(14, 0);
            break;
          
          case DATETIME2:
          case VARBINARY:
          case null:
            assert 1970 == param1Int || 1900 == param1Int;
            param1GregorianCalendar.set(param1Int, 0, 1);
            break;
        } 



      
      }
      return param1GregorianCalendar;
    }







    
    private GregorianCalendar localCalendarAsUTC(GregorianCalendar param1GregorianCalendar) {
      if (null == param1GregorianCalendar) {
        return null;
      }
      
      int i = param1GregorianCalendar.get(1);
      int j = param1GregorianCalendar.get(2);
      int k = param1GregorianCalendar.get(5);
      int m = param1GregorianCalendar.get(11);
      int n = param1GregorianCalendar.get(12);
      int i1 = param1GregorianCalendar.get(13);
      int i2 = param1GregorianCalendar.get(14);
      
      param1GregorianCalendar.setTimeZone(UTC.timeZone);
      param1GregorianCalendar.set(i, j, k, m, n, i1);
      param1GregorianCalendar.set(14, i2);
      return param1GregorianCalendar;
    }

    
    void execute(DTV param1DTV, Float param1Float) throws SQLServerException {
      if (JDBCType.REAL == param1DTV.getJdbcType()) {
        
        this.tdsWriter.writeRPCReal(this.name, param1Float, this.isOutParam);


      
      }
      else {



        
        Double double_ = (null == param1Float) ? null : new Double(param1Float.floatValue());
        this.tdsWriter.writeRPCDouble(this.name, double_, this.isOutParam);
      } 
    }

    
    void execute(DTV param1DTV, Double param1Double) throws SQLServerException {
      this.tdsWriter.writeRPCDouble(this.name, param1Double, this.isOutParam);
    }

    
    void execute(DTV param1DTV, BigDecimal param1BigDecimal) throws SQLServerException {
      if (DDC.exceedsMaxRPCDecimalPrecisionOrScale(param1BigDecimal)) {
        
        String str = param1BigDecimal.toString();
        this.tdsWriter.writeRPCStringUnicode(this.name, str, this.isOutParam, this.collation);
      }
      else {
        
        this.tdsWriter.writeRPCBigDecimal(this.name, param1BigDecimal, this.outScale, this.isOutParam);
      } 
    }





    
    void execute(DTV param1DTV, Long param1Long) throws SQLServerException {
      this.tdsWriter.writeRPCLong(this.name, param1Long, this.isOutParam);
    }

    
    void execute(DTV param1DTV, BigInteger param1BigInteger) throws SQLServerException {
      this.tdsWriter.writeRPCLong(this.name, Long.valueOf(param1BigInteger.longValue()), this.isOutParam);
    }

    
    void execute(DTV param1DTV, Short param1Short) throws SQLServerException {
      this.tdsWriter.writeRPCShort(this.name, param1Short, this.isOutParam);
    }

    
    void execute(DTV param1DTV, Boolean param1Boolean) throws SQLServerException {
      this.tdsWriter.writeRPCBit(this.name, param1Boolean, this.isOutParam);
    }

    
    void execute(DTV param1DTV, byte[] param1ArrayOfbyte) throws SQLServerException {
      if (null != DTV.this.cryptoMeta) {
        
        this.tdsWriter.writeRPCNameValType(this.name, this.isOutParam, TDSType.BIGVARBINARY);
        if (null != param1ArrayOfbyte)
        {
          param1ArrayOfbyte = SQLServerSecurityUtility.encryptWithKey(param1ArrayOfbyte, DTV.this.cryptoMeta, this.conn);
          this.tdsWriter.writeEncryptedRPCByteArray(param1ArrayOfbyte);
          writeEncryptData(param1DTV, false);
        }
        else
        {
          this.tdsWriter.writeEncryptedRPCByteArray(param1ArrayOfbyte);
          writeEncryptData(param1DTV, true);
        }
      
      } else {
        
        this.tdsWriter.writeRPCByteArray(this.name, param1ArrayOfbyte, this.isOutParam, param1DTV.getJdbcType(), this.collation);
      } 
    }





    
    void writeEncryptData(DTV param1DTV, boolean param1Boolean) throws SQLServerException {
      MessageFormat messageFormat;
      JDBCType jDBCType = (null == DTV.this.jdbcTypeSetByUser) ? param1DTV.getJdbcType() : DTV.this.jdbcTypeSetByUser;
      
      switch (jDBCType.getIntValue()) {
        
        case 4:
          this.tdsWriter.writeByte(TDSType.INTN.byteValue());
          this.tdsWriter.writeByte((byte)4);
          break;
        
        case -5:
          this.tdsWriter.writeByte(TDSType.INTN.byteValue());
          this.tdsWriter.writeByte((byte)8);
          break;
        
        case -7:
          this.tdsWriter.writeByte(TDSType.BITN.byteValue());
          this.tdsWriter.writeByte((byte)1);
          break;
        
        case 5:
          this.tdsWriter.writeByte(TDSType.INTN.byteValue());
          this.tdsWriter.writeByte((byte)2);
          break;
        
        case -6:
          this.tdsWriter.writeByte(TDSType.INTN.byteValue());
          this.tdsWriter.writeByte((byte)1);
          break;
        
        case 8:
          this.tdsWriter.writeByte(TDSType.FLOATN.byteValue());
          this.tdsWriter.writeByte((byte)8);
          break;
        
        case 7:
          this.tdsWriter.writeByte(TDSType.FLOATN.byteValue());
          this.tdsWriter.writeByte((byte)4);
          break;

        
        case -148:
        case -146:
        case 2:
        case 3:
          if (JDBCType.MONEY == jDBCType || JDBCType.SMALLMONEY == jDBCType) {
            
            this.tdsWriter.writeByte(TDSType.MONEYN.byteValue());
            this.tdsWriter.writeByte((byte)((JDBCType.MONEY == jDBCType) ? 8 : 4));
            
            break;
          } 
          this.tdsWriter.writeByte(TDSType.NUMERICN.byteValue());
          if (param1Boolean) {
            this.tdsWriter.writeByte((byte)17);
            
            if (null != DTV.this.cryptoMeta && null != DTV.this.cryptoMeta.getBaseTypeInfo()) {
              this.tdsWriter.writeByte((byte)((0 != DTV.this.valueLength) ? DTV.this.valueLength : DTV.this.cryptoMeta.getBaseTypeInfo().getPrecision()));
            } else {
              
              this.tdsWriter.writeByte((byte)((0 != DTV.this.valueLength) ? DTV.this.valueLength : 18));
            } 
            
            this.tdsWriter.writeByte((byte)((0 != this.outScale) ? this.outScale : 0));
            
            break;
          } 
          this.tdsWriter.writeByte((byte)17);
          
          if (null != DTV.this.cryptoMeta && null != DTV.this.cryptoMeta.getBaseTypeInfo()) {
            this.tdsWriter.writeByte((byte)DTV.this.cryptoMeta.getBaseTypeInfo().getPrecision());
          } else {
            
            this.tdsWriter.writeByte((byte)((0 != DTV.this.valueLength) ? DTV.this.valueLength : 18));
          } 
          
          if (null != DTV.this.cryptoMeta && null != DTV.this.cryptoMeta.getBaseTypeInfo()) {
            this.tdsWriter.writeByte((byte)DTV.this.cryptoMeta.getBaseTypeInfo().getScale());
            break;
          } 
          this.tdsWriter.writeByte((byte)((null != param1DTV.getScale()) ? param1DTV.getScale().intValue() : 0));
          break;



        
        case -145:
          this.tdsWriter.writeByte(TDSType.GUID.byteValue());
          if (param1Boolean) {
            this.tdsWriter.writeByte((byte)((0 != DTV.this.valueLength) ? DTV.this.valueLength : 1)); break;
          } 
          this.tdsWriter.writeByte((byte)16);
          break;

        
        case 1:
          this.tdsWriter.writeByte(TDSType.BIGCHAR.byteValue());
          
          if (param1Boolean) {
            this.tdsWriter.writeShort((short)((0 != DTV.this.valueLength) ? DTV.this.valueLength : 1));
          } else {
            this.tdsWriter.writeShort((short)DTV.this.valueLength);
          } 
          if (null != this.collation) {
            this.collation.writeCollation(this.tdsWriter); break;
          } 
          this.conn.getDatabaseCollation().writeCollation(this.tdsWriter);
          break;
        
        case -15:
          this.tdsWriter.writeByte(TDSType.NCHAR.byteValue());
          if (param1Boolean) {
            this.tdsWriter.writeShort((short)((0 != DTV.this.valueLength) ? (DTV.this.valueLength * 2) : 1));
          }
          else if (this.isOutParam) {
            this.tdsWriter.writeShort((short)(DTV.this.valueLength * 2));
          } else {
            
            this.tdsWriter.writeShort((short)DTV.this.valueLength);
          } 
          
          if (null != this.collation) {
            this.collation.writeCollation(this.tdsWriter); break;
          } 
          this.conn.getDatabaseCollation().writeCollation(this.tdsWriter);
          break;

        
        case -1:
        case 12:
          this.tdsWriter.writeByte(TDSType.BIGVARCHAR.byteValue());
          if (param1Boolean) {
            if (param1DTV.jdbcTypeSetByUser.getIntValue() == -1) {
              this.tdsWriter.writeShort((short)-1);
            } else {
              
              this.tdsWriter.writeShort((short)((0 != DTV.this.valueLength) ? DTV.this.valueLength : 1));
            
            }
          
          }
          else if (param1DTV.getJdbcType().getIntValue() == -1 || param1DTV.getJdbcType().getIntValue() == -16) {


            
            this.tdsWriter.writeShort((short)1);
          
          }
          else if (param1DTV.jdbcTypeSetByUser.getIntValue() == -1) {
            this.tdsWriter.writeShort((short)-1);
          } else {
            
            this.tdsWriter.writeShort((short)DTV.this.valueLength);
          } 


          
          if (null != this.collation) {
            this.collation.writeCollation(this.tdsWriter); break;
          } 
          this.conn.getDatabaseCollation().writeCollation(this.tdsWriter);
          break;
        
        case -16:
        case -9:
          this.tdsWriter.writeByte(TDSType.NVARCHAR.byteValue());
          if (param1Boolean) {
            if (param1DTV.jdbcTypeSetByUser.getIntValue() == -16) {
              this.tdsWriter.writeShort((short)-1);
            } else {
              
              this.tdsWriter.writeShort((short)((0 != DTV.this.valueLength) ? (DTV.this.valueLength * 2) : 1));
            }
          
          }
          else if (this.isOutParam) {


            
            if (param1DTV.jdbcTypeSetByUser.getIntValue() == -16) {
              this.tdsWriter.writeShort((short)-1);
            } else {
              
              this.tdsWriter.writeShort((short)(DTV.this.valueLength * 2));
            } 
          } else {
            
            this.tdsWriter.writeShort((short)DTV.this.valueLength);
          } 

          
          if (null != this.collation) {
            this.collation.writeCollation(this.tdsWriter); break;
          } 
          this.conn.getDatabaseCollation().writeCollation(this.tdsWriter);
          break;
        
        case -2:
          this.tdsWriter.writeByte(TDSType.BIGBINARY.byteValue());
          if (param1Boolean) {
            this.tdsWriter.writeShort((short)((0 != DTV.this.valueLength) ? DTV.this.valueLength : 1)); break;
          } 
          this.tdsWriter.writeShort((short)DTV.this.valueLength);
          break;

        
        case -4:
        case -3:
          this.tdsWriter.writeByte(TDSType.BIGVARBINARY.byteValue());
          if (param1Boolean) {
            if (param1DTV.jdbcTypeSetByUser.getIntValue() == -4) {
              this.tdsWriter.writeShort((short)-1);
              break;
            } 
            this.tdsWriter.writeShort((short)((0 != DTV.this.valueLength) ? DTV.this.valueLength : 1));
            
            break;
          } 
          if (param1DTV.jdbcTypeSetByUser.getIntValue() == -4) {
            this.tdsWriter.writeShort((short)-1);
            break;
          } 
          this.tdsWriter.writeShort((short)DTV.this.valueLength);
          break;

        
        default:
          messageFormat = new MessageFormat(SQLServerException.getErrString("R_UnsupportedDataTypeAE"));
          throw new SQLServerException(messageFormat.format(new Object[] { jDBCType }, ), null, 0, null);
      } 
      
      this.tdsWriter.writeCryptoMetaData();
    }

    
    void execute(DTV param1DTV, Blob param1Blob) throws SQLServerException {
      assert null != param1Blob;
      
      long l = 0L;
      InputStream inputStream = null;

      
      try {
        l = DataTypes.getCheckedLength(this.conn, param1DTV.getJdbcType(), param1Blob.length(), false);
        inputStream = param1Blob.getBinaryStream();
      }
      catch (SQLException sQLException) {
        
        SQLServerException.makeFromDriverError(this.conn, null, sQLException.getMessage(), null, false);
      } 
      
      if (null == inputStream) {
        
        this.tdsWriter.writeRPCByteArray(this.name, null, this.isOutParam, param1DTV.getJdbcType(), this.collation);


      
      }
      else {


        
        this.tdsWriter.writeRPCInputStream(this.name, inputStream, l, this.isOutParam, param1DTV.getJdbcType(), this.collation);
      } 
    }







    
    void execute(DTV param1DTV, SQLServerSQLXML param1SQLServerSQLXML) throws SQLServerException {
      InputStream inputStream = (null == param1SQLServerSQLXML) ? null : param1SQLServerSQLXML.getValue();
      this.tdsWriter.writeRPCXML(this.name, inputStream, (null == inputStream) ? 0L : param1DTV.getStreamSetterArgs().getLength(), this.isOutParam);
    }




    
    void execute(DTV param1DTV, InputStream param1InputStream) throws SQLServerException {
      this.tdsWriter.writeRPCInputStream(this.name, param1InputStream, (null == param1InputStream) ? 0L : param1DTV.getStreamSetterArgs().getLength(), this.isOutParam, param1DTV.getJdbcType(), this.collation);
    }







    
    void execute(DTV param1DTV, Reader param1Reader) throws SQLServerException {
      JDBCType jDBCType = param1DTV.getJdbcType();

      
      assert null != param1Reader;





      
      assert JDBCType.NCHAR == jDBCType || JDBCType.NVARCHAR == jDBCType || JDBCType.LONGNVARCHAR == jDBCType || JDBCType.NCLOB == jDBCType : "SendByRPCOp(Reader): Unexpected JDBC type " + jDBCType;

      
      this.tdsWriter.writeRPCReaderUnicode(this.name, param1Reader, param1DTV.getStreamSetterArgs().getLength(), this.isOutParam, this.collation);
    }
  }











  
  final void executeOp(DTVExecuteOp paramDTVExecuteOp) throws SQLServerException {
    JDBCType jDBCType = getJdbcType();
    Object object = getSetterValue();
    JavaType javaType = getJavaType();
    boolean bool = false;
    byte[] arrayOfByte = null;
    
    if (null != this.cryptoMeta && !JavaType.SetterConversionAE.converts(javaType, jDBCType)) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedConversionAE"));
      Object[] arrayOfObject = { javaType.toString().toLowerCase(Locale.ENGLISH), jDBCType.toString().toLowerCase(Locale.ENGLISH) };
      throw new SQLServerException(messageFormat.format(arrayOfObject), null);
    } 
    
    if (null == object) {

      
      switch (jDBCType) {
        
        case null:
        case null:
        case null:
        case null:
          if (null != this.cryptoMeta) {
            paramDTVExecuteOp.execute(this, (byte[])null); break;
          } 
          paramDTVExecuteOp.execute(this, (String)null);
          break;
        
        case null:
          if (null != this.cryptoMeta) {
            paramDTVExecuteOp.execute(this, (byte[])null); break;
          } 
          paramDTVExecuteOp.execute(this, (Integer)null);
          break;
        
        case DATETIME:
          paramDTVExecuteOp.execute(this, (Date)null);
          break;
        
        case DATETIMEOFFSET:
          paramDTVExecuteOp.execute(this, (Time)null);
          break;
        
        case DATETIME2:
        case DATE:
        case TIME:
          paramDTVExecuteOp.execute(this, (Timestamp)null);
          break;
        
        case SMALLDATETIME:
        case VARBINARY:
        case VARBINARYMAX:
          paramDTVExecuteOp.execute(this, (DateTimeOffset)null);
          break;
        
        case null:
        case null:
          if (null != this.cryptoMeta) {
            paramDTVExecuteOp.execute(this, (byte[])null); break;
          } 
          paramDTVExecuteOp.execute(this, (Float)null);
          break;
        
        case null:
        case null:
        case null:
        case null:
          if (null != this.cryptoMeta) {
            paramDTVExecuteOp.execute(this, (byte[])null); break;
          } 
          paramDTVExecuteOp.execute(this, (BigDecimal)null);
          break;
        
        case null:
        case null:
        case null:
        case null:
        case null:
        case null:
        case null:
        case null:
        case null:
          if (null != this.cryptoMeta) {
            paramDTVExecuteOp.execute(this, (byte[])null); break;
          } 
          paramDTVExecuteOp.execute(this, (byte[])null);
          break;
        
        case null:
          if (null != this.cryptoMeta) {
            paramDTVExecuteOp.execute(this, (byte[])null); break;
          } 
          paramDTVExecuteOp.execute(this, (Byte)null);
          break;
        
        case null:
          if (null != this.cryptoMeta) {
            paramDTVExecuteOp.execute(this, (byte[])null); break;
          } 
          paramDTVExecuteOp.execute(this, (Long)null);
          break;
        
        case null:
          if (null != this.cryptoMeta) {
            paramDTVExecuteOp.execute(this, (byte[])null); break;
          } 
          paramDTVExecuteOp.execute(this, (Double)null);
          break;
        
        case null:
          if (null != this.cryptoMeta) {
            paramDTVExecuteOp.execute(this, (byte[])null); break;
          } 
          paramDTVExecuteOp.execute(this, (Short)null);
          break;
        
        case null:
        case null:
          if (null != this.cryptoMeta) {
            paramDTVExecuteOp.execute(this, (byte[])null); break;
          } 
          paramDTVExecuteOp.execute(this, (Boolean)null);
          break;
        
        case null:
          paramDTVExecuteOp.execute(this, (SQLServerSQLXML)null);
          break;
        
        case null:
        case null:
        case null:
        case null:
        case null:
        case null:
        case null:
        case null:
        case null:
          bool = true;
          break;

        
        default:
          assert false : "Unexpected JDBCType: " + jDBCType;
          bool = true;
          break;
      } 

    
    } else {
      if (aeLogger.isLoggable(Level.FINE) && null != this.cryptoMeta)
      {
        aeLogger.fine("Encrypting java data type: " + javaType);
      }
      
      switch (javaType) {
        
        case null:
          if (JDBCType.GUID == jDBCType) {
            
            if (object instanceof String)
              object = UUID.fromString((String)object); 
            byte[] arrayOfByte1 = Util.asGuidByteArray((UUID)object);
            paramDTVExecuteOp.execute(this, arrayOfByte1);
            break;
          } 
          if (null != this.cryptoMeta) {


            
            if (jDBCType == JDBCType.LONGNVARCHAR && JDBCType.VARCHAR == this.jdbcTypeSetByUser && Integer.MAX_VALUE < this.valueLength) {


              
              MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_StreamingDataTypeAE"));
              Object[] arrayOfObject = { Integer.valueOf(2147483647), JDBCType.LONGVARCHAR };
              throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
            } 
            if (JDBCType.NVARCHAR == this.jdbcTypeSetByUser && 1073741823 < this.valueLength) {

              
              MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_StreamingDataTypeAE"));
              Object[] arrayOfObject = { Integer.valueOf(1073741823), JDBCType.LONGNVARCHAR };
              throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
            } 
            
            if (JDBCType.NVARCHAR == this.jdbcTypeSetByUser || JDBCType.NCHAR == this.jdbcTypeSetByUser || JDBCType.LONGNVARCHAR == this.jdbcTypeSetByUser) {
              
              arrayOfByte = ((String)object).getBytes(Charset.forName("UTF-16LE"));
            
            }
            else if (JDBCType.VARCHAR == this.jdbcTypeSetByUser || JDBCType.CHAR == this.jdbcTypeSetByUser || JDBCType.LONGVARCHAR == this.jdbcTypeSetByUser) {
              
              arrayOfByte = ((String)object).getBytes();
            } 
            
            paramDTVExecuteOp.execute(this, arrayOfByte);
            break;
          } 
          paramDTVExecuteOp.execute(this, (String)object);
          break;

        
        case null:
          if (null != this.cryptoMeta) {
            
            arrayOfByte = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(((Integer)object).longValue()).array();
            paramDTVExecuteOp.execute(this, arrayOfByte);
            break;
          } 
          paramDTVExecuteOp.execute(this, (Integer)object);
          break;
        
        case DATE:
          paramDTVExecuteOp.execute(this, (Date)object);
          break;
        
        case DATETIME2:
          paramDTVExecuteOp.execute(this, (Time)object);
          break;
        
        case TIME:
          if (JDBCType.SMALLDATETIME == jDBCType) {
            
            Timestamp timestamp = (Timestamp)object;
            if (timestamp.after(TDS.MAX_TIMESTAMP) || timestamp.before(TDS.MIN_TIMESTAMP)) {
              
              MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
              throw new SQLServerException(messageFormat.format(new Object[] { jDBCType }, ), null, 0, null);
            } 
          } 
          paramDTVExecuteOp.execute(this, (Timestamp)object);
          break;
        
        case null:
          paramDTVExecuteOp.execute(this, (TVP)object);
          break;
        
        case DATETIMEOFFSET:
          paramDTVExecuteOp.execute(this, (Date)object);
          break;
        
        case DATETIME:
          paramDTVExecuteOp.execute(this, (Calendar)object);
          break;
        
        case SMALLDATETIME:
          paramDTVExecuteOp.execute(this, (LocalDate)object);
          break;
        
        case VARBINARY:
          paramDTVExecuteOp.execute(this, (LocalTime)object);
          break;
        
        case VARBINARYMAX:
          paramDTVExecuteOp.execute(this, (LocalDateTime)object);
          break;
        
        case null:
          paramDTVExecuteOp.execute(this, (OffsetTime)object);
          break;
        
        case null:
          paramDTVExecuteOp.execute(this, (OffsetDateTime)object);
          break;
        
        case null:
          paramDTVExecuteOp.execute(this, (DateTimeOffset)object);
          break;
        
        case null:
          if (null != this.cryptoMeta) {
            
            if (Float.isInfinite(((Float)object).floatValue())) {
              
              MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
              throw new SQLServerException(messageFormat.format(new Object[] { jDBCType }, ), null, 0, null);
            } 
            
            arrayOfByte = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat(((Float)object).floatValue()).array();
            paramDTVExecuteOp.execute(this, arrayOfByte);
            break;
          } 
          paramDTVExecuteOp.execute(this, (Float)object);
          break;
        
        case null:
          if (null != this.cryptoMeta) {




            
            if (JDBCType.MONEY == jDBCType || JDBCType.SMALLMONEY == jDBCType) {



              
              BigDecimal bigDecimal1 = (BigDecimal)object;
              
              Util.validateMoneyRange(bigDecimal1, jDBCType);


              
              int i = Math.max(bigDecimal1.precision() - bigDecimal1.scale(), 0) + 4;
              
              long l = ((BigDecimal)object).multiply(new BigDecimal(10000), new MathContext(i, RoundingMode.HALF_UP)).longValue();
              ByteBuffer byteBuffer = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);
              byteBuffer.putInt((int)(l >> 32L)).array();
              byteBuffer.putInt((int)l).array();
              paramDTVExecuteOp.execute(this, byteBuffer.array());
              
              break;
            } 
            BigDecimal bigDecimal = (BigDecimal)object;
            byte[] arrayOfByte1 = DDC.convertBigDecimalToBytes(bigDecimal, bigDecimal.scale());
            arrayOfByte = new byte[16];
            
            System.arraycopy(arrayOfByte1, 2, arrayOfByte, 0, arrayOfByte1.length - 2);
            setScale(Integer.valueOf(bigDecimal.scale()));
            paramDTVExecuteOp.execute(this, arrayOfByte);
            
            break;
          } 
          paramDTVExecuteOp.execute(this, (BigDecimal)object);
          break;
        
        case null:
          if (null != this.cryptoMeta && Integer.MAX_VALUE < this.valueLength) {
            
            MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_StreamingDataTypeAE"));
            Object[] arrayOfObject = { Integer.valueOf(2147483647), JDBCType.BINARY };
            throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
          } 
          
          paramDTVExecuteOp.execute(this, (byte[])object);
          break;

        
        case null:
          if (null != this.cryptoMeta) {
            
            arrayOfByte = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong((((Byte)object).byteValue() & 0xFF)).array();
            paramDTVExecuteOp.execute(this, arrayOfByte);
            break;
          } 
          paramDTVExecuteOp.execute(this, (Byte)object);
          break;
        
        case null:
          if (null != this.cryptoMeta) {
            
            arrayOfByte = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(((Long)object).longValue()).array();
            paramDTVExecuteOp.execute(this, arrayOfByte);
            break;
          } 
          paramDTVExecuteOp.execute(this, (Long)object);
          break;
        
        case null:
          paramDTVExecuteOp.execute(this, (BigInteger)object);
          break;
        
        case null:
          if (null != this.cryptoMeta) {
            
            if (Double.isInfinite(((Double)object).doubleValue())) {
              
              MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
              throw new SQLServerException(messageFormat.format(new Object[] { jDBCType }, ), null, 0, null);
            } 
            arrayOfByte = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putDouble(((Double)object).doubleValue()).array();
            paramDTVExecuteOp.execute(this, arrayOfByte);
            break;
          } 
          paramDTVExecuteOp.execute(this, (Double)object);
          break;
        
        case null:
          if (null != this.cryptoMeta) {
            
            arrayOfByte = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(((Short)object).shortValue()).array();
            paramDTVExecuteOp.execute(this, arrayOfByte);
            break;
          } 
          paramDTVExecuteOp.execute(this, (Short)object);
          break;
        
        case null:
          if (null != this.cryptoMeta) {
            
            arrayOfByte = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(((Boolean)object).booleanValue() ? 1L : 0L).array();
            paramDTVExecuteOp.execute(this, arrayOfByte);
            break;
          } 
          paramDTVExecuteOp.execute(this, (Boolean)object);
          break;
        
        case null:
          paramDTVExecuteOp.execute(this, (Blob)object);
          break;
        
        case null:
        case null:
          paramDTVExecuteOp.execute(this, (Clob)object);
          break;
        
        case null:
          paramDTVExecuteOp.execute(this, (InputStream)object);
          break;
        
        case null:
          paramDTVExecuteOp.execute(this, (Reader)object);
          break;
        
        case null:
          paramDTVExecuteOp.execute(this, (SQLServerSQLXML)object);
          break;
        
        default:
          assert false : "Unexpected JavaType: " + javaType;
          bool = true;
          break;
      } 
    
    } 
    if (bool) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedConversionFromTo"));
      Object[] arrayOfObject = { javaType, jDBCType };
      throw new SQLServerException(messageFormat.format(arrayOfObject), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
    } 
  }





  
  void sendCryptoMetaData(CryptoMetadata paramCryptoMetadata, TDSWriter paramTDSWriter) {
    this.cryptoMeta = paramCryptoMetadata;
    paramTDSWriter.setCryptoMetaData(paramCryptoMetadata);
  }

  
  void jdbcTypeSetByUser(JDBCType paramJDBCType, int paramInt) {
    this.jdbcTypeSetByUser = paramJDBCType;
    this.valueLength = paramInt;
  }













  
  void sendByRPC(String paramString, TypeInfo paramTypeInfo, SQLCollation paramSQLCollation, int paramInt1, int paramInt2, boolean paramBoolean, TDSWriter paramTDSWriter, SQLServerConnection paramSQLServerConnection) throws SQLServerException {
    executeOp(new SendByRPCOp(paramString, paramTypeInfo, paramSQLCollation, paramInt1, paramInt2, paramBoolean, paramTDSWriter, paramSQLServerConnection));
  }
}
