package com.microsoft.sqlserver.jdbc;

import java.io.UnsupportedEncodingException;
import java.text.MessageFormat;
import java.util.concurrent.ConcurrentHashMap;
import javax.xml.bind.DatatypeConverter;






class SQLServerAeadAes256CbcHmac256Factory
  extends SQLServerEncryptionAlgorithmFactory
{
  private byte algorithmVersion = 1;
  private ConcurrentHashMap<String, SQLServerAeadAes256CbcHmac256Algorithm> encryptionAlgorithms = new ConcurrentHashMap<>();




  
  SQLServerEncryptionAlgorithm create(SQLServerSymmetricKey paramSQLServerSymmetricKey, SQLServerEncryptionType paramSQLServerEncryptionType, String paramString) throws SQLServerException {
    assert paramSQLServerSymmetricKey != null;
    if (paramSQLServerEncryptionType != SQLServerEncryptionType.Deterministic && paramSQLServerEncryptionType != SQLServerEncryptionType.Randomized) {
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidEncryptionType"));
      Object[] arrayOfObject = { paramSQLServerEncryptionType, paramString, "'" + SQLServerEncryptionType.Deterministic + "," + SQLServerEncryptionType.Randomized + "'" };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    } 
    
    String str = "";
    
    try {
      StringBuffer stringBuffer = new StringBuffer();
      stringBuffer.append(DatatypeConverter.printBase64Binary((new String(paramSQLServerSymmetricKey.getRootKey(), "UTF-8")).getBytes()));







      
      stringBuffer.append(":");
      stringBuffer.append(paramSQLServerEncryptionType);
      stringBuffer.append(":");
      stringBuffer.append(this.algorithmVersion);
      
      str = stringBuffer.toString();


      
      if (!this.encryptionAlgorithms.containsKey(str)) {
        SQLServerAeadAes256CbcHmac256EncryptionKey sQLServerAeadAes256CbcHmac256EncryptionKey = new SQLServerAeadAes256CbcHmac256EncryptionKey(paramSQLServerSymmetricKey.getRootKey(), "AEAD_AES_256_CBC_HMAC_SHA256");
        SQLServerAeadAes256CbcHmac256Algorithm sQLServerAeadAes256CbcHmac256Algorithm = new SQLServerAeadAes256CbcHmac256Algorithm(sQLServerAeadAes256CbcHmac256EncryptionKey, paramSQLServerEncryptionType, this.algorithmVersion);
        this.encryptionAlgorithms.putIfAbsent(str, sQLServerAeadAes256CbcHmac256Algorithm);
      
      }
    
    }
    catch (UnsupportedEncodingException unsupportedEncodingException) {
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
      
      Object[] arrayOfObject = { "UTF-8" };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    } 
    return this.encryptionAlgorithms.get(str);
  }
}
