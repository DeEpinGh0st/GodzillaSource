package com.microsoft.sqlserver.jdbc;








final class StreamColInfo
  extends StreamPacket
{
  private TDSReader tdsReader;
  private TDSReaderMark colInfoMark;
  
  StreamColInfo() {
    super(165);
  }

  
  void setFromTDS(TDSReader paramTDSReader) throws SQLServerException {
    if (165 != paramTDSReader.readUnsignedByte() && 
      !$assertionsDisabled) throw new AssertionError("Not a COLINFO token");
    
    this.tdsReader = paramTDSReader;
    int i = paramTDSReader.readUnsignedShort();
    this.colInfoMark = paramTDSReader.mark();
    paramTDSReader.skip(i);
  }

  
  int applyTo(Column[] paramArrayOfColumn) throws SQLServerException {
    int i = 0;

    
    TDSReaderMark tDSReaderMark = this.tdsReader.mark();
    this.tdsReader.reset(this.colInfoMark);
    for (byte b = 0; b < paramArrayOfColumn.length; b++) {
      
      Column column = paramArrayOfColumn[b];



      
      this.tdsReader.readUnsignedByte();


      
      column.setTableNum(this.tdsReader.readUnsignedByte());
      if (column.getTableNum() > i) {
        i = column.getTableNum();
      }
      
      column.setInfoStatus(this.tdsReader.readUnsignedByte());
      if (column.hasDifferentName()) {
        column.setBaseColumnName(this.tdsReader.readUnicodeString(this.tdsReader.readUnsignedByte()));
      }
    } 
    this.tdsReader.reset(tDSReaderMark);
    return i;
  }
}
