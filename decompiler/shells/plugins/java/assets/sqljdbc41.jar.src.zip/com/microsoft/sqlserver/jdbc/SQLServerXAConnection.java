package com.microsoft.sqlserver.jdbc;

import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.XAConnection;
import javax.transaction.xa.XAResource;












public final class SQLServerXAConnection
  extends SQLServerPooledConnection
  implements XAConnection
{
  private SQLServerXAResource XAResource;
  private SQLServerConnection physicalControlConnection;
  private Logger xaLogger;
  
  SQLServerXAConnection(SQLServerDataSource paramSQLServerDataSource, String paramString1, String paramString2) throws SQLException {
    super(paramSQLServerDataSource, paramString1, paramString2);
    
    this.xaLogger = SQLServerXADataSource.xaLogger;
    SQLServerConnection sQLServerConnection = getPhysicalConnection();
    
    Properties properties = (Properties)sQLServerConnection.activeConnectionProperties.clone();
    
    properties.setProperty(SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.toString(), "true");
    properties.remove(SQLServerDriverStringProperty.SELECT_METHOD.toString());
    
    if (this.xaLogger.isLoggable(Level.FINER))
      this.xaLogger.finer("Creating an internal control connection for" + toString()); 
    this.physicalControlConnection = new SQLServerConnection(toString());
    this.physicalControlConnection.connect(properties, null);
    if (this.xaLogger.isLoggable(Level.FINER)) {
      this.xaLogger.finer("Created an internal control connection" + this.physicalControlConnection.toString() + " for " + toString() + " Physical connection:" + getPhysicalConnection().toString());
    }

    
    if (this.xaLogger.isLoggable(Level.FINER)) {
      this.xaLogger.finer(paramSQLServerDataSource.toString() + " user:" + paramString1);
    }
  }






  
  public synchronized XAResource getXAResource() throws SQLException {
    if (this.XAResource == null) {
      this.XAResource = new SQLServerXAResource(getPhysicalConnection(), this.physicalControlConnection, toString());
    }
    return this.XAResource;
  }



  
  public void close() throws SQLException {
    synchronized (this) {
      
      if (this.XAResource != null) {
        
        this.XAResource.close();
        this.XAResource = null;
      } 
      if (null != this.physicalControlConnection) {
        
        this.physicalControlConnection.close();
        this.physicalControlConnection = null;
      } 
    } 
    super.close();
  }
}
