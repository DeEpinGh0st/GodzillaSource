package com.microsoft.sqlserver.jdbc;

























final class XMLTDSHeader
{
  private final String databaseName;
  private final String owningSchema;
  private final String xmlSchemaCollection;
  
  XMLTDSHeader(TDSReader paramTDSReader) throws SQLServerException {
    if (0 != paramTDSReader.readUnsignedByte()) {

      
      this.databaseName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
      this.owningSchema = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
      this.xmlSchemaCollection = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedShort());
    }
    else {
      
      this.xmlSchemaCollection = null;
      this.owningSchema = null;
      this.databaseName = null;
    } 
  }
}
