package com.microsoft.sqlserver.jdbc;
import java.net.IDN;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.security.auth.Subject;
import javax.security.auth.login.AppConfigurationEntry;
import javax.security.auth.login.Configuration;
import javax.security.auth.login.LoginException;
import org.ietf.jgss.GSSCredential;
import org.ietf.jgss.GSSException;
import org.ietf.jgss.GSSManager;
import org.ietf.jgss.GSSName;
import org.ietf.jgss.Oid;

final class KerbAuthentication extends SSPIAuthentication {
  private static final Logger authLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.KerbAuthentication");
  
  private static final String CONFIGNAME = "SQLJDBCDriver";
  
  private final SQLServerConnection con;
  private final String spn;
  private final GSSManager manager = GSSManager.getInstance();
  private LoginContext lc = null;
  private GSSCredential peerCredentials = null;
  private GSSContext peerContext = null;

  
  static {
    class SQLJDBCDriverConfig
      extends Configuration
    {
      Configuration current;
      AppConfigurationEntry[] driverConf;
      
      SQLJDBCDriverConfig() {
        AppConfigurationEntry[] arrayOfAppConfigurationEntry;
        this.current = null;




        
        try {
          this.current = Configuration.getConfiguration();
        }
        catch (SecurityException securityException) {

          
          KerbAuthentication.authLogger.finer(toString() + " No configurations provided, setting driver default");
        } 
        this$0 = null;
        
        if (null != this.current)
        {
          arrayOfAppConfigurationEntry = this.current.getAppConfigurationEntry("SQLJDBCDriver");
        }
        
        if (null == arrayOfAppConfigurationEntry) {
          AppConfigurationEntry appConfigurationEntry;
          if (KerbAuthentication.authLogger.isLoggable(Level.FINER)) {
            KerbAuthentication.authLogger.finer(toString() + " SQLJDBCDriver configuration entry is not provided, setting driver default");
          }
          
          if (Util.isIBM()) {
            
            HashMap<Object, Object> hashMap = new HashMap<>();
            hashMap.put("useDefaultCcache", "true");
            hashMap.put("moduleBanner", "false");
            appConfigurationEntry = new AppConfigurationEntry("com.ibm.security.auth.module.Krb5LoginModule", AppConfigurationEntry.LoginModuleControlFlag.REQUIRED, (Map)hashMap);
            if (KerbAuthentication.authLogger.isLoggable(Level.FINER)) {
              KerbAuthentication.authLogger.finer(toString() + " Setting IBM Krb5LoginModule");
            }
          } else {
            
            HashMap<Object, Object> hashMap = new HashMap<>();
            hashMap.put("useTicketCache", "true");
            hashMap.put("doNotPrompt", "true");
            appConfigurationEntry = new AppConfigurationEntry("com.sun.security.auth.module.Krb5LoginModule", AppConfigurationEntry.LoginModuleControlFlag.REQUIRED, (Map)hashMap);
            if (KerbAuthentication.authLogger.isLoggable(Level.FINER))
              KerbAuthentication.authLogger.finer(toString() + " Setting Sun Krb5LoginModule"); 
          } 
          this.driverConf = new AppConfigurationEntry[1];
          this.driverConf[0] = appConfigurationEntry;
          Configuration.setConfiguration(this);
        } 
      }




      
      public AppConfigurationEntry[] getAppConfigurationEntry(String param1String) {
        if (param1String.equals("SQLJDBCDriver"))
        {
          return this.driverConf;
        }

        
        if (null != this.current) {
          return this.current.getAppConfigurationEntry(param1String);
        }
        return null;
      }


      
      public void refresh() {
        if (null != this.current)
          this.current.refresh(); 
      }
    };
    SQLJDBCDriverConfig sQLJDBCDriverConfig = new SQLJDBCDriverConfig();
  }




  
  private void intAuthInit() throws SQLServerException {
    try {
      Oid oid = new Oid("1.2.840.113554.1.2.2");
      Subject subject = null;
      
      try {
        AccessControlContext accessControlContext = AccessController.getContext();
        subject = Subject.getSubject(accessControlContext);
        if (null == subject)
        {
          this.lc = new LoginContext("SQLJDBCDriver");
          this.lc.login();
          
          subject = this.lc.getSubject();
        }
      
      } catch (LoginException loginException) {
        
        this.con.terminate(0, SQLServerException.getErrString("R_integratedAuthenticationFailed"), loginException);
      } 


      
      GSSName gSSName = this.manager.createName(this.spn, (Oid)null);
      if (authLogger.isLoggable(Level.FINER))
      {
        authLogger.finer(toString() + " Getting client credentials");
      }
      this.peerCredentials = getClientCredential(subject, this.manager, oid);
      if (authLogger.isLoggable(Level.FINER))
      {
        authLogger.finer(toString() + " creating security context");
      }
      
      this.peerContext = this.manager.createContext(gSSName, oid, this.peerCredentials, 0);



      
      this.peerContext.requestCredDeleg(true);
      this.peerContext.requestMutualAuth(true);
      this.peerContext.requestInteg(true);
    
    }
    catch (GSSException gSSException) {
      
      authLogger.finer(toString() + "initAuthInit failed GSSException:-" + gSSException);
      
      this.con.terminate(0, SQLServerException.getErrString("R_integratedAuthenticationFailed"), gSSException);
    }
    catch (PrivilegedActionException privilegedActionException) {
      
      authLogger.finer(toString() + "initAuthInit failed privileged exception:-" + privilegedActionException);
      
      this.con.terminate(0, SQLServerException.getErrString("R_integratedAuthenticationFailed"), privilegedActionException);
    } 
  }





  
  private static GSSCredential getClientCredential(Subject paramSubject, final GSSManager MANAGER, final Oid kerboid) throws PrivilegedActionException {
    PrivilegedExceptionAction<GSSCredential> privilegedExceptionAction = new PrivilegedExceptionAction<GSSCredential>()
      {
        public GSSCredential run() throws GSSException {
          return MANAGER.createCredential((GSSName)null, 0, kerboid, 1);
        }
      };






    
    GSSCredential gSSCredential = (GSSCredential)Subject.doAs(paramSubject, (PrivilegedExceptionAction)privilegedExceptionAction);
    return gSSCredential;
  }

  
  private byte[] intAuthHandShake(byte[] paramArrayOfbyte, boolean[] paramArrayOfboolean) throws SQLServerException {
    try {
      if (authLogger.isLoggable(Level.FINER))
      {
        authLogger.finer(toString() + " Sending token to server over secure context");
      }
      byte[] arrayOfByte = this.peerContext.initSecContext(paramArrayOfbyte, 0, paramArrayOfbyte.length);
      
      if (this.peerContext.isEstablished()) {
        
        paramArrayOfboolean[0] = true;
        if (authLogger.isLoggable(Level.FINER)) {
          authLogger.finer(toString() + "Authentication done.");
        }
      }
      else if (null == arrayOfByte) {

        
        authLogger.info(toString() + "byteToken is null in initSecContext.");
        this.con.terminate(0, SQLServerException.getErrString("R_integratedAuthenticationFailed"));
      } 
      return arrayOfByte;
    }
    catch (GSSException gSSException) {
      
      authLogger.finer(toString() + "initSecContext Failed :-" + gSSException);
      
      this.con.terminate(0, SQLServerException.getErrString("R_integratedAuthenticationFailed"), gSSException);

      
      return null;
    } 
  }
  
  private String makeSpn(String paramString, int paramInt) throws SQLServerException {
    if (authLogger.isLoggable(Level.FINER))
    {
      authLogger.finer(toString() + " Server: " + paramString + " port: " + paramInt);
    }
    StringBuilder stringBuilder = new StringBuilder("MSSQLSvc/");

    
    if (this.con.serverNameAsACE()) {
      
      stringBuilder.append(IDN.toASCII(paramString));
    }
    else {
      
      stringBuilder.append(paramString);
    } 
    stringBuilder.append(":");
    stringBuilder.append(paramInt);
    String str = stringBuilder.toString();
    if (authLogger.isLoggable(Level.FINER))
    {
      authLogger.finer(toString() + " SPN: " + str);
    }
    return str;
  }


  
  KerbAuthentication(SQLServerConnection paramSQLServerConnection, String paramString, int paramInt) throws SQLServerException {
    this.con = paramSQLServerConnection;
    
    String str = paramSQLServerConnection.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.SERVER_SPN.toString());

    
    if (null != str) {

      
      if (paramSQLServerConnection.serverNameAsACE())
      {
        int i = str.indexOf("/");
        this.spn = str.substring(0, i + 1) + IDN.toASCII(str.substring(i + 1));
      
      }
      else
      {
        this.spn = str;
      }
    
    } else {
      
      this.spn = makeSpn(paramString, paramInt);
    } 
  }

  
  byte[] GenerateClientContext(byte[] paramArrayOfbyte, boolean[] paramArrayOfboolean) throws SQLServerException {
    if (null == this.peerContext)
    {
      intAuthInit();
    }
    return intAuthHandShake(paramArrayOfbyte, paramArrayOfboolean);
  }

  
  int ReleaseClientContext() throws SQLServerException {
    try {
      if (null != this.peerCredentials)
        this.peerCredentials.dispose(); 
      if (null != this.peerContext)
        this.peerContext.dispose(); 
      if (null != this.lc) {
        this.lc.logout();
      }
    } catch (LoginException loginException) {


      
      authLogger.fine(toString() + " Release of the credentials failed LoginException: " + loginException);
    }
    catch (GSSException gSSException) {


      
      authLogger.fine(toString() + " Release of the credentials failed GSSException: " + gSSException);
    } 
    return 0;
  }
}
