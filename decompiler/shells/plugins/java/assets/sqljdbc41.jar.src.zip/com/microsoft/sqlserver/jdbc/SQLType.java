package com.microsoft.sqlserver.jdbc;

interface SQLType {
  Integer getVendorTypeNumber();
}
