package com.microsoft.sqlserver.jdbc;

import com.microsoft.azure.keyvault.KeyVaultClient;
import com.microsoft.azure.keyvault.KeyVaultClientImpl;
import com.microsoft.azure.keyvault.models.KeyBundle;
import com.microsoft.azure.keyvault.models.KeyOperationResult;
import com.microsoft.windowsazure.credentials.CloudCredentials;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.MessageFormat;
import java.util.concurrent.ExecutorService;
import org.apache.http.impl.client.HttpClientBuilder;


















public class SQLServerColumnEncryptionAzureKeyVaultProvider
  extends SQLServerColumnEncryptionKeyStoreProvider
{
  String name = "AZURE_KEY_VAULT";
  
  private final String azureKeyVaultDomainName = "vault.azure.net";
  
  private final String rsaEncryptionAlgorithmWithOAEPForAKV = "RSA-OAEP";



  
  private final byte[] firstVersion = new byte[] { 1 };

  
  private KeyVaultClient keyVaultClient;
  
  private KeyVaultCredential credential;

  
  public void setName(String paramString) {
    this.name = paramString;
  }

  
  public String getName() {
    return this.name;
  }







  
  public SQLServerColumnEncryptionAzureKeyVaultProvider(SQLServerKeyVaultAuthenticationCallback paramSQLServerKeyVaultAuthenticationCallback, ExecutorService paramExecutorService) throws SQLServerException {
    if (null == paramSQLServerKeyVaultAuthenticationCallback) {
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_NullValue"));
      Object[] arrayOfObject = { "SQLServerKeyVaultAuthenticationCallback" };
      throw new SQLServerException(messageFormat.format(arrayOfObject), null);
    } 
    this.credential = new KeyVaultCredential(paramSQLServerKeyVaultAuthenticationCallback);
    HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
    this.keyVaultClient = (KeyVaultClient)new KeyVaultClientImpl(httpClientBuilder, paramExecutorService, (CloudCredentials)this.credential);
  }













  
  public byte[] decryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException {
    ValidateNonEmptyAKVPath(paramString1);
    
    if (null == paramArrayOfbyte)
    {
      throw new SQLServerException(SQLServerException.getErrString("R_NullEncryptedColumnEncryptionKey"), null);
    }
    
    if (0 == paramArrayOfbyte.length)
    {
      throw new SQLServerException(SQLServerException.getErrString("R_EmptyEncryptedColumnEncryptionKey"), null);
    }

    
    paramString2 = validateEncryptionAlgorithm(paramString2);

    
    int i = getAKVKeySize(paramString1);








    
    if (paramArrayOfbyte[0] != this.firstVersion[0]) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidEcryptionAlgorithmVersion"));
      Object[] arrayOfObject = { String.format("%02X ", new Object[] { Byte.valueOf(paramArrayOfbyte[0]) }), String.format("%02X ", new Object[] { Byte.valueOf(this.firstVersion[0]) }) };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    } 

    
    int j = this.firstVersion.length;
    short s1 = convertTwoBytesToShort(paramArrayOfbyte, j);
    
    j += 2;

    
    short s2 = convertTwoBytesToShort(paramArrayOfbyte, j);
    j += 2;


    
    j += s1;

    
    if (s2 != i) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_AKVKeyLengthError"));
      Object[] arrayOfObject = { Short.valueOf(s2), Integer.valueOf(i), paramString1 };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    } 

    
    int k = paramArrayOfbyte.length - j - s2;
    
    if (k != i) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_AKVSignatureLengthError"));
      Object[] arrayOfObject = { Integer.valueOf(k), Integer.valueOf(i), paramString1 };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    } 

    
    byte[] arrayOfByte1 = new byte[s2];
    System.arraycopy(paramArrayOfbyte, j, arrayOfByte1, 0, s2);
    j += s2;

    
    byte[] arrayOfByte2 = new byte[k];
    System.arraycopy(paramArrayOfbyte, j, arrayOfByte2, 0, k);

    
    byte[] arrayOfByte3 = new byte[paramArrayOfbyte.length - arrayOfByte2.length];
    
    System.arraycopy(paramArrayOfbyte, 0, arrayOfByte3, 0, paramArrayOfbyte.length - arrayOfByte2.length);

    
    MessageDigest messageDigest = null;
    try {
      messageDigest = MessageDigest.getInstance("SHA-256");
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
      throw new SQLServerException(SQLServerException.getErrString("R_NoSHA256Algorithm"), null);
    } 
    messageDigest.update(arrayOfByte3);
    byte[] arrayOfByte4 = messageDigest.digest();
    
    if (null == arrayOfByte4)
    {
      throw new SQLServerException(SQLServerException.getErrString("R_HashNull"), null);
    }

    
    if (!AzureKeyVaultVerifySignature(arrayOfByte4, arrayOfByte2, paramString1)) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_CEKSignatureNotMatchCMK"));
      Object[] arrayOfObject = { paramString1 };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    } 

    
    return AzureKeyVaultUnWrap(paramString1, paramString2, arrayOfByte1);
  }




  
  private short convertTwoBytesToShort(byte[] paramArrayOfbyte, int paramInt) throws SQLServerException {
    short s = -1;
    if (paramInt + 1 >= paramArrayOfbyte.length)
    {
      throw new SQLServerException(null, SQLServerException.getErrString("R_ByteToShortConversion"), null, 0, false);
    }




    
    ByteBuffer byteBuffer = ByteBuffer.allocate(2);
    byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
    byteBuffer.put(paramArrayOfbyte[paramInt]);
    byteBuffer.put(paramArrayOfbyte[paramInt + 1]);
    s = byteBuffer.getShort(0);
    return s;
  }














  
  public byte[] encryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException {
    ValidateNonEmptyAKVPath(paramString1);
    
    if (null == paramArrayOfbyte)
    {
      throw new SQLServerException(SQLServerException.getErrString("R_NullColumnEncryptionKey"), null);
    }
    
    if (0 == paramArrayOfbyte.length)
    {
      throw new SQLServerException(SQLServerException.getErrString("R_EmptyCEK"), null);
    }

    
    paramString2 = validateEncryptionAlgorithm(paramString2);

    
    int i = getAKVKeySize(paramString1);





    
    byte[] arrayOfByte1 = { this.firstVersion[0] };

    
    byte[] arrayOfByte2 = null;
    try {
      arrayOfByte2 = paramString1.toLowerCase().getBytes("UTF-16LE");
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
      
      Object[] arrayOfObject = { "UTF-16LE" };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    } 
    
    byte[] arrayOfByte3 = new byte[2];
    arrayOfByte3[0] = (byte)((short)arrayOfByte2.length & 0xFF);
    arrayOfByte3[1] = (byte)((short)arrayOfByte2.length >> 8 & 0xFF);

    
    byte[] arrayOfByte4 = AzureKeyVaultWrap(paramString1, paramString2, paramArrayOfbyte);
    
    byte[] arrayOfByte5 = new byte[2];
    arrayOfByte5[0] = (byte)((short)arrayOfByte4.length & 0xFF);
    arrayOfByte5[1] = (byte)((short)arrayOfByte4.length >> 8 & 0xFF);
    
    if (arrayOfByte4.length != i)
    {
      throw new SQLServerException(SQLServerException.getErrString("R_CipherTextLengthNotMatchRSASize"), null);
    }


    
    byte[] arrayOfByte6 = new byte[arrayOfByte1.length + arrayOfByte3.length + arrayOfByte5.length + arrayOfByte2.length + arrayOfByte4.length];
    int j = arrayOfByte1.length;
    System.arraycopy(arrayOfByte1, 0, arrayOfByte6, 0, arrayOfByte1.length);
    
    System.arraycopy(arrayOfByte3, 0, arrayOfByte6, j, arrayOfByte3.length);
    j += arrayOfByte3.length;
    
    System.arraycopy(arrayOfByte5, 0, arrayOfByte6, j, arrayOfByte5.length);
    j += arrayOfByte5.length;
    
    System.arraycopy(arrayOfByte2, 0, arrayOfByte6, j, arrayOfByte2.length);
    j += arrayOfByte2.length;
    
    System.arraycopy(arrayOfByte4, 0, arrayOfByte6, j, arrayOfByte4.length);
    
    MessageDigest messageDigest = null;
    try {
      messageDigest = MessageDigest.getInstance("SHA-256");
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
      throw new SQLServerException(SQLServerException.getErrString("R_NoSHA256Algorithm"), null);
    } 
    messageDigest.update(arrayOfByte6);
    byte[] arrayOfByte7 = messageDigest.digest();

    
    byte[] arrayOfByte8 = null;
    arrayOfByte8 = AzureKeyVaultSignHashedData(arrayOfByte7, paramString1);
    
    if (arrayOfByte8.length != i)
    {
      throw new SQLServerException(SQLServerException.getErrString("R_SignedHashLengthError"), null);
    }
    
    if (!AzureKeyVaultVerifySignature(arrayOfByte7, arrayOfByte8, paramString1))
    {
      throw new SQLServerException(SQLServerException.getErrString("R_InvalidSignatureComputed"), null);
    }


    
    int k = arrayOfByte1.length + arrayOfByte5.length + arrayOfByte3.length + arrayOfByte4.length + arrayOfByte2.length + arrayOfByte8.length;
    byte[] arrayOfByte9 = new byte[k];

    
    int m = 0;
    System.arraycopy(arrayOfByte1, 0, arrayOfByte9, m, arrayOfByte1.length);
    m += arrayOfByte1.length;

    
    System.arraycopy(arrayOfByte3, 0, arrayOfByte9, m, arrayOfByte3.length);
    m += arrayOfByte3.length;

    
    System.arraycopy(arrayOfByte5, 0, arrayOfByte9, m, arrayOfByte5.length);
    m += arrayOfByte5.length;

    
    System.arraycopy(arrayOfByte2, 0, arrayOfByte9, m, arrayOfByte2.length);
    m += arrayOfByte2.length;

    
    System.arraycopy(arrayOfByte4, 0, arrayOfByte9, m, arrayOfByte4.length);
    m += arrayOfByte4.length;

    
    System.arraycopy(arrayOfByte8, 0, arrayOfByte9, m, arrayOfByte8.length);
    
    return arrayOfByte9;
  }









  
  private String validateEncryptionAlgorithm(String paramString) throws SQLServerException {
    if (null == paramString)
    {
      throw new SQLServerException(null, SQLServerException.getErrString("R_NullKeyEncryptionAlgorithm"), null, 0, false);
    }






    
    if (paramString.equalsIgnoreCase("RSA_OAEP"))
    {
      paramString = "RSA-OAEP";
    }
    
    if (!"RSA-OAEP".equalsIgnoreCase(paramString.trim())) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidKeyEncryptionAlgorithm"));
      
      Object[] arrayOfObject = { paramString, "RSA-OAEP" };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    } 

    
    return paramString;
  }








  
  private void ValidateNonEmptyAKVPath(String paramString) throws SQLServerException {
    if (null == paramString || paramString.trim().isEmpty()) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_AKVPathNull"));
      Object[] arrayOfObject = { paramString };
      throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
    } 

    
    URI uRI = null;
    try {
      uRI = new URI(paramString);
    } catch (URISyntaxException uRISyntaxException) {
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_AKVURLInvalid"));
      Object[] arrayOfObject = { paramString };
      throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
    } 


    
    if (!uRI.getHost().toLowerCase().endsWith("vault.azure.net")) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_AKVMasterKeyPathInvalid"));
      Object[] arrayOfObject = { paramString };
      throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
    } 
  }











  
  private byte[] AzureKeyVaultWrap(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException {
    if (null == paramArrayOfbyte)
    {
      throw new SQLServerException(SQLServerException.getErrString("R_CEKNull"), null);
    }
    
    KeyOperationResult keyOperationResult = null;
    try {
      keyOperationResult = this.keyVaultClient.wrapKeyAsync(paramString1, paramString2, paramArrayOfbyte).get();
    } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {
      throw new SQLServerException(SQLServerException.getErrString("R_EncryptCEKError"), null);
    } 
    return keyOperationResult.getResult();
  }









  
  private byte[] AzureKeyVaultUnWrap(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException {
    KeyOperationResult keyOperationResult;
    if (null == paramArrayOfbyte)
    {
      throw new SQLServerException(SQLServerException.getErrString("R_EncryptedCEKNull"), null);
    }
    
    if (0 == paramArrayOfbyte.length)
    {
      throw new SQLServerException(SQLServerException.getErrString("R_EmptyEncryptedCEK"), null);
    }

    
    try {
      keyOperationResult = this.keyVaultClient.unwrapKeyAsync(paramString1, paramString2, paramArrayOfbyte).get();
    } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {
      throw new SQLServerException(SQLServerException.getErrString("R_DecryptCEKError"), null);
    } 
    return keyOperationResult.getResult();
  }









  
  private byte[] AzureKeyVaultSignHashedData(byte[] paramArrayOfbyte, String paramString) throws SQLServerException {
    assert null != paramArrayOfbyte && 0 != paramArrayOfbyte.length;
    
    KeyOperationResult keyOperationResult = null;
    try {
      keyOperationResult = this.keyVaultClient.signAsync(paramString, "RS256", paramArrayOfbyte).get();
    } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {
      throw new SQLServerException(SQLServerException.getErrString("R_GenerateSignature"), null);
    } 
    return keyOperationResult.getResult();
  }










  
  private boolean AzureKeyVaultVerifySignature(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, String paramString) throws SQLServerException {
    assert null != paramArrayOfbyte1 && 0 != paramArrayOfbyte1.length;
    assert null != paramArrayOfbyte2 && 0 != paramArrayOfbyte2.length;
    
    boolean bool = false;
    try {
      bool = ((Boolean)this.keyVaultClient.verifyAsync(paramString, "RS256", paramArrayOfbyte1, paramArrayOfbyte2).get()).booleanValue();
    } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {
      throw new SQLServerException(SQLServerException.getErrString("R_VerifySignature"), null);
    } 
    
    return bool;
  }









  
  private int getAKVKeySize(String paramString) throws SQLServerException {
    KeyBundle keyBundle = null;
    try {
      keyBundle = this.keyVaultClient.getKeyAsync(paramString).get();
    } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {
      throw new SQLServerException(SQLServerException.getErrString("R_GetAKVKeySize"), null);
    } 
    
    if (!keyBundle.getKey().getKty().equalsIgnoreCase("RSA") && !keyBundle.getKey().getKty().equalsIgnoreCase("RSA-HSM")) {

      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_NonRSAKey"));
      Object[] arrayOfObject = { keyBundle.getKey().getKty() };
      throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
    } 
    
    return (keyBundle.getKey().getN()).length;
  }
}
