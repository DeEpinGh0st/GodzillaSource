package com.microsoft.sqlserver.jdbc;













































































final class OffsetTime
  extends TemporalCompatibility
{
  public static OffsetTime parse(String paramString, DateTimeFormatter paramDateTimeFormatter) throws SQLServerException {
    SQLServerException.makeFromDriverError(null, null, null, null, false);
    return null;
  }
  
  public static OffsetTime parse(String paramString) throws SQLServerException {
    SQLServerException.makeFromDriverError(null, null, null, null, false);
    return null;
  }
}
