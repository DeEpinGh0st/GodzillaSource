package com.microsoft.sqlserver.jdbc;

final class XAReturnValue {
  int nStatus;
  
  byte[] bData;
}
