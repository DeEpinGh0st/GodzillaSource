package com.microsoft.sqlserver.jdbc;

import java.text.MessageFormat;





enum SQLServerEncryptionType
{
  Deterministic((byte)1),
  Randomized((byte)2),
  PlainText((byte)0);
  
  byte value;
  
  SQLServerEncryptionType(byte paramByte) {
    this.value = paramByte;
  }

  
  byte getValue() {
    return this.value;
  }

  
  static SQLServerEncryptionType of(byte paramByte) throws SQLServerException {
    for (SQLServerEncryptionType sQLServerEncryptionType : values()) {
      if (paramByte == sQLServerEncryptionType.value) {
        return sQLServerEncryptionType;
      }
    } 
    MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unknownColumnEncryptionType"));
    Object[] arrayOfObject = { Byte.valueOf(paramByte) };
    SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), null, true);

    
    return null;
  }
}
