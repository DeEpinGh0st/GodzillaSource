package com.microsoft.sqlserver.jdbc;

import java.io.UnsupportedEncodingException;
import java.text.MessageFormat;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.DatatypeConverter;





































final class SQLServerSymmetricKeyCache
{
  static Object lock = new Object();
  private final ConcurrentHashMap<String, SQLServerSymmetricKey> cache;
  private static final SQLServerSymmetricKeyCache instance = new SQLServerSymmetricKeyCache();
  private static ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1, new ThreadFactory()
      {


        
        public Thread newThread(Runnable param1Runnable)
        {
          Thread thread = Executors.defaultThreadFactory().newThread(param1Runnable);
          thread.setDaemon(true);
          return thread;
        }
      });

  
  private static final Logger aeLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.SQLServerSymmetricKeyCache");


  
  private SQLServerSymmetricKeyCache() {
    this.cache = new ConcurrentHashMap<>();
  }

  
  static SQLServerSymmetricKeyCache getInstance() {
    return instance;
  }

  
  ConcurrentHashMap<String, SQLServerSymmetricKey> getCache() {
    return this.cache;
  }







  
  SQLServerSymmetricKey getKey(EncryptionKeyInfo paramEncryptionKeyInfo, SQLServerConnection paramSQLServerConnection) throws SQLServerException {
    SQLServerSymmetricKey sQLServerSymmetricKey = null;
    synchronized (lock) {
      
      String str1 = paramSQLServerConnection.getTrustedServerNameAE();
      assert null != str1 : "serverName should not be null in getKey.";
      
      StringBuffer stringBuffer = new StringBuffer(str1);
      String str2 = null;
      stringBuffer.append(":");

      
      try {
        stringBuffer.append(DatatypeConverter.printBase64Binary((new String(paramEncryptionKeyInfo.encryptedKey, "UTF-8")).getBytes()));
      }
      catch (UnsupportedEncodingException unsupportedEncodingException) {
        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
        Object[] arrayOfObject = { "UTF-8" };
        throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
      } 
      
      stringBuffer.append(":");
      stringBuffer.append(paramEncryptionKeyInfo.keyStoreName);
      str2 = stringBuffer.toString();
      stringBuffer.setLength(0);
      
      if (aeLogger.isLoggable(Level.FINE))
      {
        aeLogger.fine("Checking trusted master key path...");
      }
      Boolean[] arrayOfBoolean = new Boolean[1];
      List<String> list = SQLServerConnection.getColumnEncryptionTrustedMasterKeyPaths(str1, arrayOfBoolean);
      if (true == arrayOfBoolean[0].booleanValue())
      {
        if (null == list || 0 == list.size() || !list.contains(paramEncryptionKeyInfo.keyPath)) {
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_UntrustedKeyPath"));
          Object[] arrayOfObject = { paramEncryptionKeyInfo.keyPath, str1 };
          throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
        } 
      }
      
      if (aeLogger.isLoggable(Level.FINE))
      {
        aeLogger.fine("Checking Symmetric key cache...");
      }

      
      if (!this.cache.containsKey(str2)) {

        
        SQLServerColumnEncryptionKeyStoreProvider sQLServerColumnEncryptionKeyStoreProvider = paramSQLServerConnection.getSystemColumnEncryptionKeyStoreProvider(paramEncryptionKeyInfo.keyStoreName);

        
        if (null == sQLServerColumnEncryptionKeyStoreProvider)
        {
          sQLServerColumnEncryptionKeyStoreProvider = SQLServerConnection.getGlobalSystemColumnEncryptionKeyStoreProvider(paramEncryptionKeyInfo.keyStoreName);
        }

        
        if (null == sQLServerColumnEncryptionKeyStoreProvider)
        {
          sQLServerColumnEncryptionKeyStoreProvider = SQLServerConnection.getGlobalCustomColumnEncryptionKeyStoreProvider(paramEncryptionKeyInfo.keyStoreName);
        }

        
        if (null == sQLServerColumnEncryptionKeyStoreProvider) {
          String str3 = paramSQLServerConnection.getAllSystemColumnEncryptionKeyStoreProviders();
          String str4 = SQLServerConnection.getAllGlobalCustomSystemColumnEncryptionKeyStoreProviders();
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_UnrecognizedKeyStoreProviderName"));
          Object[] arrayOfObject = { paramEncryptionKeyInfo.keyStoreName, str3, str4 };
          throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
        } 

        
        byte[] arrayOfByte = sQLServerColumnEncryptionKeyStoreProvider.decryptColumnEncryptionKey(paramEncryptionKeyInfo.keyPath, paramEncryptionKeyInfo.algorithmName, paramEncryptionKeyInfo.encryptedKey);
        sQLServerSymmetricKey = new SQLServerSymmetricKey(arrayOfByte);






        
        long l = SQLServerConnection.getColumnEncryptionKeyCacheTtl();
        if (0L != l)
        {
          this.cache.putIfAbsent(str2, sQLServerSymmetricKey);
          if (aeLogger.isLoggable(Level.FINE))
          {
            aeLogger.fine("Adding encryption key to cache...");
          }
          scheduler.schedule(new CacheClear(str2), l, TimeUnit.SECONDS);
        
        }

      
      }
      else {
        
        sQLServerSymmetricKey = this.cache.get(str2);
      } 
    } 
    return sQLServerSymmetricKey;
  }
}
