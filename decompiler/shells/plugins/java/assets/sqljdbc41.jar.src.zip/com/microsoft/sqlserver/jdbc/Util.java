package com.microsoft.sqlserver.jdbc;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

final class Util
{
  static final String SYSTEM_SPEC_VERSION = System.getProperty("java.specification.version");
  static final char[] hexChars = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };

  
  static final String WSIDNotAvailable = "";
  
  static final String ActivityIdTraceProperty = "com.microsoft.sqlserver.jdbc.traceactivity";
  
  static final String SYSTEM_JRE = System.getProperty("java.vendor") + " " + System.getProperty("java.version");

  
  static boolean isIBM() {
    return SYSTEM_JRE.startsWith("IBM");
  }


  
  static final Boolean isCharType(int paramInt) {
    switch (paramInt) {
      
      case -16:
      case -15:
      case -9:
      case -1:
      case 1:
      case 12:
        return Boolean.valueOf(true);
    } 
    return Boolean.valueOf(false);
  }


  
  static final Boolean isCharType(SSType paramSSType) {
    switch (paramSSType) {
      
      case OBJECT:
      case STRING:
      case BYTEARRAY:
      case BIGDECIMAL:
      case TIMESTAMP:
      case TIME:
        return Boolean.valueOf(true);
    } 
    return Boolean.valueOf(false);
  }


  
  static final Boolean isBinaryType(SSType paramSSType) {
    switch (paramSSType) {
      
      case DATETIMEOFFSET:
      case READER:
      case CLOB:
      case NCLOB:
        return Boolean.valueOf(true);
    } 
    return Boolean.valueOf(false);
  }


  
  static final Boolean isBinaryType(int paramInt) {
    switch (paramInt) {
      
      case -4:
      case -3:
      case -2:
        return Boolean.valueOf(true);
    } 
    return Boolean.valueOf(false);
  }







  
  static short readShort(byte[] paramArrayOfbyte, int paramInt) {
    return (short)(paramArrayOfbyte[paramInt] & 0xFF | (paramArrayOfbyte[paramInt + 1] & 0xFF) << 8);
  }






  
  static int readUnsignedShort(byte[] paramArrayOfbyte, int paramInt) {
    return paramArrayOfbyte[paramInt] & 0xFF | (paramArrayOfbyte[paramInt + 1] & 0xFF) << 8;
  }

  
  static int readUnsignedShortBigEndian(byte[] paramArrayOfbyte, int paramInt) {
    return (paramArrayOfbyte[paramInt] & 0xFF) << 8 | paramArrayOfbyte[paramInt + 1] & 0xFF;
  }

  
  static void writeShort(short paramShort, byte[] paramArrayOfbyte, int paramInt) {
    paramArrayOfbyte[paramInt + 0] = (byte)(paramShort >> 0 & 0xFF);
    paramArrayOfbyte[paramInt + 1] = (byte)(paramShort >> 8 & 0xFF);
  }

  
  static void writeShortBigEndian(short paramShort, byte[] paramArrayOfbyte, int paramInt) {
    paramArrayOfbyte[paramInt + 0] = (byte)(paramShort >> 8 & 0xFF);
    paramArrayOfbyte[paramInt + 1] = (byte)(paramShort >> 0 & 0xFF);
  }





  
  static int readInt(byte[] paramArrayOfbyte, int paramInt) {
    int i = paramArrayOfbyte[paramInt + 0] & 0xFF;
    int j = (paramArrayOfbyte[paramInt + 1] & 0xFF) << 8;
    int k = (paramArrayOfbyte[paramInt + 2] & 0xFF) << 16;
    int m = (paramArrayOfbyte[paramInt + 3] & 0xFF) << 24;
    return m | k | j | i;
  }

  
  static int readIntBigEndian(byte[] paramArrayOfbyte, int paramInt) {
    return (paramArrayOfbyte[paramInt + 3] & 0xFF) << 0 | (paramArrayOfbyte[paramInt + 2] & 0xFF) << 8 | (paramArrayOfbyte[paramInt + 1] & 0xFF) << 16 | (paramArrayOfbyte[paramInt + 0] & 0xFF) << 24;
  }





  
  static void writeInt(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) {
    paramArrayOfbyte[paramInt2 + 0] = (byte)(paramInt1 >> 0 & 0xFF);
    paramArrayOfbyte[paramInt2 + 1] = (byte)(paramInt1 >> 8 & 0xFF);
    paramArrayOfbyte[paramInt2 + 2] = (byte)(paramInt1 >> 16 & 0xFF);
    paramArrayOfbyte[paramInt2 + 3] = (byte)(paramInt1 >> 24 & 0xFF);
  }

  
  static void writeIntBigEndian(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) {
    paramArrayOfbyte[paramInt2 + 0] = (byte)(paramInt1 >> 24 & 0xFF);
    paramArrayOfbyte[paramInt2 + 1] = (byte)(paramInt1 >> 16 & 0xFF);
    paramArrayOfbyte[paramInt2 + 2] = (byte)(paramInt1 >> 8 & 0xFF);
    paramArrayOfbyte[paramInt2 + 3] = (byte)(paramInt1 >> 0 & 0xFF);
  }

  
  static void writeLongBigEndian(long paramLong, byte[] paramArrayOfbyte, int paramInt) {
    paramArrayOfbyte[paramInt + 0] = (byte)(int)(paramLong >> 56L & 0xFFL);
    paramArrayOfbyte[paramInt + 1] = (byte)(int)(paramLong >> 48L & 0xFFL);
    paramArrayOfbyte[paramInt + 2] = (byte)(int)(paramLong >> 40L & 0xFFL);
    paramArrayOfbyte[paramInt + 3] = (byte)(int)(paramLong >> 32L & 0xFFL);
    paramArrayOfbyte[paramInt + 4] = (byte)(int)(paramLong >> 24L & 0xFFL);
    paramArrayOfbyte[paramInt + 5] = (byte)(int)(paramLong >> 16L & 0xFFL);
    paramArrayOfbyte[paramInt + 6] = (byte)(int)(paramLong >> 8L & 0xFFL);
    paramArrayOfbyte[paramInt + 7] = (byte)(int)(paramLong >> 0L & 0xFFL);
  }

  
  static BigDecimal readBigDecimal(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    boolean bool = (0 == paramArrayOfbyte[0]) ? true : true;
    byte[] arrayOfByte = new byte[paramInt1 - 1];
    for (byte b = 1; b <= arrayOfByte.length; b++)
      arrayOfByte[arrayOfByte.length - b] = paramArrayOfbyte[b]; 
    return new BigDecimal(new BigInteger(bool, arrayOfByte), paramInt2);
  }







  
  static long readLong(byte[] paramArrayOfbyte, int paramInt) {
    long l = 0L;
    for (byte b = 7; b > 0; b--) {
      
      l += (paramArrayOfbyte[paramInt + b] & 0xFF);
      l <<= 8L;
    } 
    return l + (paramArrayOfbyte[paramInt] & 0xFF);
  }






  
  static Properties parseUrl(String paramString, Logger paramLogger) throws SQLServerException {
    Properties properties = new Properties();
    String str1 = paramString;
    String str2 = "jdbc:sqlserver://";
    String str3 = "";
    String str4 = "";
    String str5 = "";
    
    if (!str1.startsWith(str2)) {
      return null;
    }
    str1 = str1.substring(str2.length());
    byte b1 = 0;











    
    byte b2 = 0;
    
    b1 = 0;
    while (b1 < str1.length()) {
      
      char c = str1.charAt(b1);
      switch (b2) {

        
        case false:
          if (c == ';') {

            
            b2 = 7;
            
            break;
          } 
          str3 = str3 + c;
          b2 = 1;
          break;



        
        case true:
          if (c == ';' || c == ':' || c == '\\') {

            
            str3 = str3.trim();
            if (str3.length() > 0) {
              
              properties.put(SQLServerDriverStringProperty.SERVER_NAME.toString(), str3);
              if (paramLogger.isLoggable(Level.FINE))
              {
                paramLogger.fine("Property:serverName Value:" + str3);
              }
            } 
            str3 = "";
            
            if (c == ';') {
              b2 = 7; break;
            } 
            if (c == ':') {
              b2 = 2; break;
            } 
            b2 = 3;
            
            break;
          } 
          str3 = str3 + c;
          break;




        
        case true:
          if (c == ';') {
            
            str3 = str3.trim();
            if (paramLogger.isLoggable(Level.FINE))
            {
              paramLogger.fine("Property:portNumber Value:" + str3);
            }
            properties.put(SQLServerDriverIntProperty.PORT_NUMBER.toString(), str3);
            str3 = "";
            b2 = 7;
            
            break;
          } 
          str3 = str3 + c;
          break;



        
        case true:
          if (c == ';' || c == ':') {

            
            str3 = str3.trim();
            if (paramLogger.isLoggable(Level.FINE))
            {
              paramLogger.fine("Property:instanceName Value:" + str3);
            }
            properties.put(SQLServerDriverStringProperty.INSTANCE_NAME.toString(), str3.toLowerCase(Locale.US));
            str3 = "";
            
            if (c == ';') {
              b2 = 7; break;
            } 
            b2 = 2;
            
            break;
          } 
          str3 = str3 + c;
          break;



        
        case true:
          if (c == '=') {

            
            str4 = str4.trim();
            if (str4.length() <= 0)
            {
              SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
            }
            
            b2 = 6;
            break;
          } 
          if (c == ';') {
            
            str4 = str4.trim();
            if (str4.length() > 0)
            {
              SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
            }

            
            break;
          } 
          
          str4 = str4 + c;
          break;



        
        case true:
          if (c == ';') {

            
            str5 = str5.trim();
            str4 = SQLServerDriver.getNormalizedPropertyName(str4, paramLogger);
            if (null != str4) {
              
              if (paramLogger.isLoggable(Level.FINE))
              {
                if (false == str4.equals(SQLServerDriverStringProperty.USER.toString()) && false == str4.equals(SQLServerDriverStringProperty.PASSWORD.toString()))
                  paramLogger.fine("Property:" + str4 + " Value:" + str5); 
              }
              properties.put(str4, str5);
            } 
            str4 = "";
            str5 = "";
            b2 = 7;
            
            break;
          } 
          if (c == '{') {
            
            b2 = 4;
            str5 = str5.trim();
            if (str5.length() > 0)
            {
              SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
            }
            
            break;
          } 
          str5 = str5 + c;
          break;



        
        case true:
          if (c == '}') {

            
            str4 = SQLServerDriver.getNormalizedPropertyName(str4, paramLogger);
            if (null != str4) {
              
              if (paramLogger.isLoggable(Level.FINE))
              {
                if (false == str4.equals(SQLServerDriverStringProperty.USER.toString()) && false == str4.equals(SQLServerDriverStringProperty.PASSWORD.toString()))
                  paramLogger.fine("Property:" + str4 + " Value:" + str5); 
              }
              properties.put(str4, str5);
            } 
            
            str4 = "";
            str5 = "";

            
            b2 = 5;
            
            break;
          } 
          str5 = str5 + c;
          break;



        
        case true:
          if (c == ';') {
            
            b2 = 7; break;
          } 
          if (c != ' ')
          {
            
            SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
          }
          break;


        
        default:
          assert false : "parseURL: Invalid state " + b2; break;
      } 
      b1++;
    } 

    
    switch (b2) {
      
      case 1:
        str3 = str3.trim();
        if (str3.length() > 0) {
          
          if (paramLogger.isLoggable(Level.FINE))
          {
            paramLogger.fine("Property:serverName Value:" + str3);
          }
          properties.put(SQLServerDriverStringProperty.SERVER_NAME.toString(), str3);
        } 
      
      case 2:
        str3 = str3.trim();
        if (paramLogger.isLoggable(Level.FINE))
        {
          paramLogger.fine("Property:portNumber Value:" + str3);
        }
        properties.put(SQLServerDriverIntProperty.PORT_NUMBER.toString(), str3);
      
      case 3:
        str3 = str3.trim();
        if (paramLogger.isLoggable(Level.FINE))
        {
          paramLogger.fine("Property:instanceName Value:" + str3);
        }
        properties.put(SQLServerDriverStringProperty.INSTANCE_NAME.toString(), str3);

      
      case 6:
        str5 = str5.trim();
        str4 = SQLServerDriver.getNormalizedPropertyName(str4, paramLogger);
        if (null != str4) {
          
          if (paramLogger.isLoggable(Level.FINE))
          {
            if (false == str4.equals(SQLServerDriverStringProperty.USER.toString()) && false == str4.equals(SQLServerDriverStringProperty.PASSWORD.toString()))
              paramLogger.fine("Property:" + str4 + " Value:" + str5); 
          }
          properties.put(str4, str5);
        } 


















      
      case 0:
      case 5:
        return properties;
      case 7:
        str4 = str4.trim();
        if (str4.length() > 0) {
          SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
        }
    } 
    SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
  }











  
  static String escapeSQLId(String paramString) {
    StringBuilder stringBuilder = new StringBuilder(paramString.length() + 2);
    
    stringBuilder.append('[');
    for (byte b = 0; b < paramString.length(); b++) {
      
      char c = paramString.charAt(b);
      if (']' == c) {
        stringBuilder.append("]]");
      } else {
        stringBuilder.append(c);
      } 
    }  stringBuilder.append(']');
    return stringBuilder.toString();
  }

  
  static void checkDuplicateColumnName(String paramString, Map<Integer, ?> paramMap) throws SQLServerException {
    if (paramMap.get(Integer.valueOf(0)) instanceof SQLServerMetaData) {
      
      for (Map.Entry<Integer, ?> entry : paramMap.entrySet()) {
        
        SQLServerMetaData sQLServerMetaData = (SQLServerMetaData)entry.getValue();
        if (sQLServerMetaData.columnName.equals(paramString))
        {
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_TVPDuplicateColumnName"));
          Object[] arrayOfObject = { paramString };
          throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
        }
      
      } 
    } else if (paramMap.get(Integer.valueOf(0)) instanceof SQLServerDataColumn) {
      
      for (Map.Entry<Integer, ?> entry : paramMap.entrySet()) {
        
        SQLServerDataColumn sQLServerDataColumn = (SQLServerDataColumn)entry.getValue();
        if (sQLServerDataColumn.columnName.equals(paramString)) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_TVPDuplicateColumnName"));
          Object[] arrayOfObject = { paramString };
          throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
        } 
      } 
    } 
  }










  
  static String readUnicodeString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, SQLServerConnection paramSQLServerConnection) throws SQLServerException {
    try {
      return new String(paramArrayOfbyte, paramInt1, paramInt2, Encoding.UNICODE.charsetName());
    }
    catch (UnsupportedEncodingException unsupportedEncodingException) {
      
      String str = SQLServerException.checkAndAppendClientConnId(SQLServerException.getErrString("R_stringReadError"), paramSQLServerConnection);
      MessageFormat messageFormat = new MessageFormat(str);
      Object[] arrayOfObject = { new Integer(paramInt1) };
      
      throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, true);
    }
    catch (IndexOutOfBoundsException indexOutOfBoundsException) {
      
      String str = SQLServerException.checkAndAppendClientConnId(SQLServerException.getErrString("R_stringReadError"), paramSQLServerConnection);
      MessageFormat messageFormat = new MessageFormat(str);
      Object[] arrayOfObject = { new Integer(paramInt1) };
      
      throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, true);
    } 
  }








  
  static String byteToHexDisplayString(byte[] paramArrayOfbyte) {
    if (null == paramArrayOfbyte) return "(null)";
    
    StringBuilder stringBuilder = new StringBuilder(paramArrayOfbyte.length * 2 + 2);
    stringBuilder.append("0x");
    for (byte b = 0; b < paramArrayOfbyte.length; b++) {
      
      int i = paramArrayOfbyte[b] & 0xFF;
      stringBuilder.append(hexChars[(i & 0xF0) >> 4]);
      stringBuilder.append(hexChars[i & 0xF]);
    } 
    return stringBuilder.toString();
  }







  
  static String bytesToHexString(byte[] paramArrayOfbyte, int paramInt) {
    StringBuilder stringBuilder = new StringBuilder(paramInt * 2);
    for (byte b = 0; b < paramInt; b++) {
      
      int i = paramArrayOfbyte[b] & 0xFF;
      stringBuilder.append(hexChars[(i & 0xF0) >> 4]);
      stringBuilder.append(hexChars[i & 0xF]);
    } 
    return stringBuilder.toString();
  }









  
  static String lookupHostName() {
    try {
      InetAddress inetAddress = InetAddress.getLocalHost();
      if (null != inetAddress) {
        
        String str = inetAddress.getHostName();
        if (null != str && str.length() > 0) return str;
        
        str = inetAddress.getHostAddress();
        if (null != str && str.length() > 0) return str;
      
      } 
    } catch (UnknownHostException unknownHostException) {
      
      return "";
    } 
    
    return "";
  }

  
  static final byte[] asGuidByteArray(UUID paramUUID) {
    long l1 = paramUUID.getMostSignificantBits();
    long l2 = paramUUID.getLeastSignificantBits();
    byte[] arrayOfByte = new byte[16];
    writeLongBigEndian(l1, arrayOfByte, 0);
    writeLongBigEndian(l2, arrayOfByte, 8);







    
    byte b = arrayOfByte[0];
    arrayOfByte[0] = arrayOfByte[3];
    arrayOfByte[3] = b;
    b = arrayOfByte[1];
    arrayOfByte[1] = arrayOfByte[2];
    arrayOfByte[2] = b;

    
    b = arrayOfByte[4];
    arrayOfByte[4] = arrayOfByte[5];
    arrayOfByte[5] = b;

    
    b = arrayOfByte[6];
    arrayOfByte[6] = arrayOfByte[7];
    arrayOfByte[7] = b;
    
    return arrayOfByte;
  }

  
  static final String readGUID(byte[] paramArrayOfbyte) throws SQLServerException {
    String str = "NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN";
    byte[] arrayOfByte = paramArrayOfbyte;
    
    StringBuilder stringBuilder = new StringBuilder(str.length()); byte b;
    for (b = 0; b < 4; b++) {
      
      stringBuilder.append(hexChars[(arrayOfByte[3 - b] & 0xF0) >> 4]);
      stringBuilder.append(hexChars[arrayOfByte[3 - b] & 0xF]);
    } 
    stringBuilder.append('-');
    for (b = 0; b < 2; b++) {
      
      stringBuilder.append(hexChars[(arrayOfByte[5 - b] & 0xF0) >> 4]);
      stringBuilder.append(hexChars[arrayOfByte[5 - b] & 0xF]);
    } 
    stringBuilder.append('-');
    for (b = 0; b < 2; b++) {
      
      stringBuilder.append(hexChars[(arrayOfByte[7 - b] & 0xF0) >> 4]);
      stringBuilder.append(hexChars[arrayOfByte[7 - b] & 0xF]);
    } 
    stringBuilder.append('-');
    for (b = 0; b < 2; b++) {
      
      stringBuilder.append(hexChars[(arrayOfByte[8 + b] & 0xF0) >> 4]);
      stringBuilder.append(hexChars[arrayOfByte[8 + b] & 0xF]);
    } 
    stringBuilder.append('-');
    for (b = 0; b < 6; b++) {
      
      stringBuilder.append(hexChars[(arrayOfByte[10 + b] & 0xF0) >> 4]);
      stringBuilder.append(hexChars[arrayOfByte[10 + b] & 0xF]);
    } 
    
    return stringBuilder.toString();
  }

  
  static boolean IsActivityTraceOn() {
    LogManager logManager = LogManager.getLogManager();
    String str = logManager.getProperty("com.microsoft.sqlserver.jdbc.traceactivity");
    if (null != str && str.equalsIgnoreCase("on")) {
      return true;
    }
    return false;
  }





  
  static boolean shouldHonorAEForRead(SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting, SQLServerConnection paramSQLServerConnection) {
    switch (paramSQLServerStatementColumnEncryptionSetting) {
      case OBJECT:
        return false;
      case STRING:
        return true;
      case BYTEARRAY:
        return true;
    } 

    
    assert SQLServerStatementColumnEncryptionSetting.UseConnectionSetting == paramSQLServerStatementColumnEncryptionSetting : "Unexpected value for command level override";
    return (paramSQLServerConnection != null && paramSQLServerConnection.isColumnEncryptionSettingEnabled());
  }






  
  static boolean shouldHonorAEForParameters(SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting, SQLServerConnection paramSQLServerConnection) {
    switch (paramSQLServerStatementColumnEncryptionSetting) {
      case OBJECT:
        return false;
      case STRING:
        return true;
      case BYTEARRAY:
        return false;
    } 

    
    assert SQLServerStatementColumnEncryptionSetting.UseConnectionSetting == paramSQLServerStatementColumnEncryptionSetting : "Unexpected value for command level override";
    return (paramSQLServerConnection != null && paramSQLServerConnection.isColumnEncryptionSettingEnabled());
  }


  
  static void validateMoneyRange(BigDecimal paramBigDecimal, JDBCType paramJDBCType) throws SQLServerException {
    if (null == paramBigDecimal) {
      return;
    }
    switch (paramJDBCType) {
      
      case OBJECT:
        if (1 != paramBigDecimal.compareTo(SSType.MAX_VALUE_MONEY) && -1 != paramBigDecimal.compareTo(SSType.MIN_VALUE_MONEY)) {
          return;
        }
        break;

      
      case STRING:
        if (1 != paramBigDecimal.compareTo(SSType.MAX_VALUE_SMALLMONEY) && -1 != paramBigDecimal.compareTo(SSType.MIN_VALUE_SMALLMONEY)) {
          return;
        }
        break;
    } 

    
    MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
    Object[] arrayOfObject = { paramJDBCType };
    throw new SQLServerException(messageFormat.format(arrayOfObject), null);
  }



  
  static int getValueLengthBaseOnJavaType(Object paramObject, JavaType paramJavaType, Integer paramInteger1, Integer paramInteger2, JDBCType paramJDBCType) {
    int i;
    switch (paramJavaType) {


      
      case OBJECT:
        switch (paramJDBCType) {
          case BYTEARRAY:
          case BIGDECIMAL:
            paramJavaType = JavaType.BIGDECIMAL;
            break;
          case TIMESTAMP:
            paramJavaType = JavaType.TIME;
            break;
          case TIME:
            paramJavaType = JavaType.TIMESTAMP;
            break;
          case DATETIMEOFFSET:
            paramJavaType = JavaType.DATETIMEOFFSET;
            break;
        } 

        
        break;
    } 
    
    switch (paramJavaType) {
      
      case STRING:
        if (JDBCType.GUID == paramJDBCType) {
          String str = "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX";
          return (null == paramObject) ? 0 : str.length();
        } 
        if (JDBCType.TIMESTAMP == paramJDBCType || JDBCType.TIME == paramJDBCType || JDBCType.DATETIMEOFFSET == paramJDBCType)
        {
          
          return (null == paramInteger2) ? 7 : paramInteger2.intValue();
        }
        
        return (null == paramObject) ? 0 : ((String)paramObject).length();

      
      case BYTEARRAY:
        return (null == paramObject) ? 0 : ((byte[])paramObject).length;
      
      case BIGDECIMAL:
        i = -1;
        
        if (null == paramInteger1) {
          if (null == paramObject) {
            i = 0;


          
          }
          else if (0 == ((BigDecimal)paramObject).intValue()) {
            String str = "" + (BigDecimal)paramObject;
            str = str.replaceAll("\\.", "");
            str = str.replaceAll("\\-", "");
            i = str.length();
          
          }
          else if (("" + (BigDecimal)paramObject).contains("E")) {
            DecimalFormat decimalFormat = new DecimalFormat("###.#####");
            String str = decimalFormat.format(paramObject);
            str = str.replaceAll("\\.", "");
            str = str.replaceAll("\\-", "");
            i = str.length();
          } else {
            
            i = ((BigDecimal)paramObject).precision();
          }
        
        } else {
          
          i = paramInteger1.intValue();
        } 
        
        return i;
      
      case TIMESTAMP:
      case TIME:
      case DATETIMEOFFSET:
        return (null == paramInteger2) ? 7 : paramInteger2.intValue();
      case READER:
        return (null == paramObject) ? 0 : 1073741823;
      
      case CLOB:
        return (null == paramObject) ? 0 : 2147483646;
      
      case NCLOB:
        return (null == paramObject) ? 0 : 1073741823;
    } 
    return 0;
  }



  
  static synchronized boolean checkIfNeedNewAccessToken(SQLServerConnection paramSQLServerConnection) {
    Date date1 = paramSQLServerConnection.getAuthenticationResult().getExpiresOnDate();
    Date date2 = new Date();


    
    if (date1.getTime() - date2.getTime() < 2700000L) {

      
      if (date1.getTime() - date2.getTime() < 600000L) {
        return true;
      }

      
      if (paramSQLServerConnection.attemptRefreshTokenLocked) {
        return false;
      }
      
      paramSQLServerConnection.attemptRefreshTokenLocked = true;
      return true;
    } 


    
    return false;
  }
}
