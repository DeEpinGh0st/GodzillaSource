package com.microsoft.sqlserver.jdbc;









final class StreamLoginAck
  extends StreamPacket
{
  String sSQLServerVersion;
  int tdsVersion;
  
  StreamLoginAck() {
    super(173);
  }

  
  void setFromTDS(TDSReader paramTDSReader) throws SQLServerException {
    if (173 != paramTDSReader.readUnsignedByte() && !$assertionsDisabled) throw new AssertionError(); 
    paramTDSReader.readUnsignedShort();
    paramTDSReader.readUnsignedByte();
    this.tdsVersion = paramTDSReader.readIntBigEndian();
    paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
    int i = paramTDSReader.readUnsignedByte();
    int j = paramTDSReader.readUnsignedByte();
    int k = paramTDSReader.readUnsignedByte() << 8 | paramTDSReader.readUnsignedByte();
    
    this.sSQLServerVersion = i + "." + ((j <= 9) ? "0" : "") + j + "." + k;
  }
}
