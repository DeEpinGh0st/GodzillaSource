package com.microsoft.sqlserver.jdbc;









final class ParameterUtils
{
  static byte[] HexToBin(String paramString) throws SQLServerException {
    int i = paramString.length();
    char[] arrayOfChar = paramString.toCharArray();
    if (i % 2 != 0) {
      SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_stringNotInHex"), null, false);
    }
    byte[] arrayOfByte = new byte[i / 2];
    for (byte b = 0; b < i / 2; b++)
    {
      arrayOfByte[b] = (byte)((CharToHex(arrayOfChar[2 * b]) << 4) + CharToHex(arrayOfChar[2 * b + 1]));
    }
    return arrayOfByte;
  }




  
  static byte CharToHex(char paramChar) throws SQLServerException {
    byte b = 0;
    if (paramChar >= 'A' && paramChar <= 'F') {
      
      b = (byte)(paramChar - 65 + 10);
    }
    else if (paramChar >= 'a' && paramChar <= 'f') {
      
      b = (byte)(paramChar - 97 + 10);
    
    }
    else if (paramChar >= '0' && paramChar <= '9') {
      
      b = (byte)(paramChar - 48);
    }
    else {
      
      SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_stringNotInHex"), null, false);
    } 
    
    return b;
  }


























  
  static int scanSQLForChar(char paramChar, String paramString, int paramInt) {
    int i = paramString.length();
    
    while (paramInt < i) {
      char c1;
      switch (c1 = paramString.charAt(paramInt++))
      
      { case '/':
          if (paramInt == i) {
            continue;
          }
          if (paramString.charAt(paramInt) == '*') {
            
            while (++paramInt < i) {
              
              if (paramString.charAt(paramInt) == '*' && paramInt + 1 < i && paramString.charAt(paramInt + 1) == '/')
              {

                
                paramInt += 2;
              }
            } 
            
            continue;
          } 
          if (paramString.charAt(paramInt) == '-') {
            continue;
          }
        
        case '-':
          if (paramString.charAt(paramInt) == '-') {
            
            label33: while (++paramInt < i) {
              
              if (paramString.charAt(paramInt) != '\n') { if (paramString.charAt(paramInt) == '\r')
                  break label33;  continue; }
               paramInt++;
            } 
            continue;
          } 


        
        default:
          if (paramChar == c1) {
            return paramInt - 1;
          }
          continue;
        case '[':
          c1 = ']'; break;
        case '"':
        case '\'':
          break; }  char c = c1;
      while (paramInt < i) {
        
        if (paramString.charAt(paramInt++) == c) {
          
          if (i == paramInt || paramString.charAt(paramInt) != c) {
            break;
          }
          paramInt++;
        } 
      } 
    } 


    
    return i;
  }
}
