package com.microsoft.sqlserver.jdbc;

import java.util.logging.Level;
















final class ScrollWindow
{
  private TDSReaderMark[] rowMark;
  private boolean[] updatedRow;
  private boolean[] deletedRow;
  private RowType[] rowType;
  private int size = 0;

  
  private int maxRows = 0; final int getMaxRows() {
    return this.maxRows;
  }
  private int currentRow;
  final int getRow() {
    return this.currentRow;
  }
  
  ScrollWindow(int paramInt) {
    setSize(paramInt);
    reset();
  }

  
  private final void setSize(int paramInt) {
    assert this.size != paramInt;
    this.size = paramInt;
    this.maxRows = paramInt;
    this.rowMark = new TDSReaderMark[paramInt];
    this.updatedRow = new boolean[paramInt];
    this.deletedRow = new boolean[paramInt];
    this.rowType = new RowType[paramInt];
    for (byte b = 0; b < paramInt; b++)
    {
      this.rowType[b] = RowType.UNKNOWN;
    }
  }

  
  final void clear() {
    for (byte b = 0; b < this.rowMark.length; b++) {
      
      this.rowMark[b] = null;
      this.updatedRow[b] = false;
      this.deletedRow[b] = false;
      this.rowType[b] = RowType.UNKNOWN;
    } 
    
    assert this.size > 0;
    this.maxRows = this.size;
    reset();
  }

  
  final void reset() {
    this.currentRow = 0;
  }

  
  final void resize(int paramInt) {
    assert paramInt > 0;
    if (paramInt != this.size) {
      setSize(paramInt);
    }
  }
  
  final String logCursorState() {
    return " currentRow:" + this.currentRow + " maxRows:" + this.maxRows;
  }

  
  final boolean next(SQLServerResultSet paramSQLServerResultSet) throws SQLServerException {
    if (SQLServerResultSet.logger.isLoggable(Level.FINER)) {
      SQLServerResultSet.logger.finer(paramSQLServerResultSet.toString() + logCursorState());
    }


    
    assert 0 <= this.currentRow && this.currentRow <= this.maxRows + 1;


    
    if (this.maxRows + 1 == this.currentRow) {
      return false;
    }



    
    if (this.currentRow >= 1) {
      
      this.updatedRow[this.currentRow - 1] = paramSQLServerResultSet.getUpdatedCurrentRow();
      this.deletedRow[this.currentRow - 1] = paramSQLServerResultSet.getDeletedCurrentRow();
      this.rowType[this.currentRow - 1] = paramSQLServerResultSet.getCurrentRowType();
    } 

    
    this.currentRow++;





    
    if (this.maxRows + 1 == this.currentRow) {
      
      paramSQLServerResultSet.fetchBufferNext();
      return false;
    } 




    
    if (null != this.rowMark[this.currentRow - 1]) {
      
      paramSQLServerResultSet.fetchBufferReset(this.rowMark[this.currentRow - 1]);
      paramSQLServerResultSet.setCurrentRowType(this.rowType[this.currentRow - 1]);
      paramSQLServerResultSet.setUpdatedCurrentRow(this.updatedRow[this.currentRow - 1]);
      paramSQLServerResultSet.setDeletedCurrentRow(this.deletedRow[this.currentRow - 1]);
      return true;
    } 





    
    if (paramSQLServerResultSet.fetchBufferNext()) {
      
      this.rowMark[this.currentRow - 1] = paramSQLServerResultSet.fetchBufferMark();
      this.rowType[this.currentRow - 1] = paramSQLServerResultSet.getCurrentRowType();
      
      if (SQLServerResultSet.logger.isLoggable(Level.FINEST)) {
        SQLServerResultSet.logger.finest(paramSQLServerResultSet.toString() + " Set mark " + this.rowMark[this.currentRow - 1] + " for row " + this.currentRow + " of type " + this.rowType[this.currentRow - 1]);
      }
      return true;
    } 



    
    this.maxRows = this.currentRow - 1;
    return false;
  }

  
  final void previous(SQLServerResultSet paramSQLServerResultSet) throws SQLServerException {
    if (SQLServerResultSet.logger.isLoggable(Level.FINER)) {
      SQLServerResultSet.logger.finer(paramSQLServerResultSet.toString() + logCursorState());
    }


    
    assert 0 <= this.currentRow && this.currentRow <= this.maxRows + 1;


    
    if (0 == this.currentRow) {
      return;
    }



    
    if (this.currentRow <= this.maxRows) {
      
      assert this.currentRow >= 1;
      this.updatedRow[this.currentRow - 1] = paramSQLServerResultSet.getUpdatedCurrentRow();
      this.deletedRow[this.currentRow - 1] = paramSQLServerResultSet.getDeletedCurrentRow();
      this.rowType[this.currentRow - 1] = paramSQLServerResultSet.getCurrentRowType();
    } 

    
    this.currentRow--;


    
    if (0 == this.currentRow) {
      return;
    }



    
    assert null != this.rowMark[this.currentRow - 1];
    paramSQLServerResultSet.fetchBufferReset(this.rowMark[this.currentRow - 1]);
    paramSQLServerResultSet.setCurrentRowType(this.rowType[this.currentRow - 1]);
    paramSQLServerResultSet.setUpdatedCurrentRow(this.updatedRow[this.currentRow - 1]);
    paramSQLServerResultSet.setDeletedCurrentRow(this.deletedRow[this.currentRow - 1]);
  }
}
