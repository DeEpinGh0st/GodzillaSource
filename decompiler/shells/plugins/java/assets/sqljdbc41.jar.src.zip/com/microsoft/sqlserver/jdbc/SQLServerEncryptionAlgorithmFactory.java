package com.microsoft.sqlserver.jdbc;

abstract class SQLServerEncryptionAlgorithmFactory {
  abstract SQLServerEncryptionAlgorithm create(SQLServerSymmetricKey paramSQLServerSymmetricKey, SQLServerEncryptionType paramSQLServerEncryptionType, String paramString) throws SQLServerException;
}
