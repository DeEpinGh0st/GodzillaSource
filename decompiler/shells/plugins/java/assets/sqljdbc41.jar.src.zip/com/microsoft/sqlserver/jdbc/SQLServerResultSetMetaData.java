package com.microsoft.sqlserver.jdbc;

import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.logging.Level;
import java.util.logging.Logger;






public final class SQLServerResultSetMetaData
  implements ResultSetMetaData
{
  private SQLServerConnection con;
  private final SQLServerResultSet rs;
  public int nBeforeExecuteCols;
  private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerResultSetMetaData");

  
  private static int baseID = 0;
  
  private final String traceID;
  
  private static synchronized int nextInstanceID() {
    baseID++;
    return baseID;
  }
  
  public final String toString() {
    return this.traceID;
  }







  
  SQLServerResultSetMetaData(SQLServerConnection paramSQLServerConnection, SQLServerResultSet paramSQLServerResultSet) {
    this.traceID = " SQLServerResultSetMetaData:" + nextInstanceID();
    this.con = paramSQLServerConnection;
    this.rs = paramSQLServerResultSet;
    assert paramSQLServerResultSet != null;
    if (logger.isLoggable(Level.FINE))
    {
      logger.fine(toString() + " created by (" + paramSQLServerResultSet.toString() + ")");
    }
  }
  
  private void checkClosed() throws SQLServerException {
    this.rs.checkClosed();
  }





  
  public boolean isWrapperFor(Class<?> paramClass) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    
    return false;
  }

  
  public <T> T unwrap(Class<T> paramClass) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
  }

  
  public String getCatalogName(int paramInt) throws SQLServerException {
    checkClosed();
    return this.rs.getColumn(paramInt).getTableName().getDatabaseName();
  }
  
  public int getColumnCount() throws SQLServerException {
    checkClosed();
    if (this.rs == null)
      return 0; 
    return this.rs.getColumnCount();
  }

  
  public int getColumnDisplaySize(int paramInt) throws SQLServerException {
    checkClosed();
    
    CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
    if (null != cryptoMetadata) {
      return cryptoMetadata.getBaseTypeInfo().getDisplaySize();
    }
    
    return this.rs.getColumn(paramInt).getTypeInfo().getDisplaySize();
  }

  
  public String getColumnLabel(int paramInt) throws SQLServerException {
    checkClosed();
    return this.rs.getColumn(paramInt).getColumnName();
  }

  
  public String getColumnName(int paramInt) throws SQLServerException {
    checkClosed();
    return this.rs.getColumn(paramInt).getColumnName();
  }

  
  public int getColumnType(int paramInt) throws SQLServerException {
    checkClosed();
    
    TypeInfo typeInfo = this.rs.getColumn(paramInt).getTypeInfo();
    
    CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
    if (null != cryptoMetadata) {
      typeInfo = cryptoMetadata.getBaseTypeInfo();
    }
    
    JDBCType jDBCType = typeInfo.getSSType().getJDBCType();
    int i = jDBCType.asJavaSqlType();
    if (this.con.isKatmaiOrLater()) {
      
      SSType sSType = typeInfo.getSSType();
      
      switch (sSType) {
        
        case VARCHARMAX:
          i = SSType.VARCHAR.getJDBCType().asJavaSqlType();
          break;
        case NVARCHARMAX:
          i = SSType.NVARCHAR.getJDBCType().asJavaSqlType();
          break;
        case VARBINARYMAX:
          i = SSType.VARBINARY.getJDBCType().asJavaSqlType();
          break;
        case DATETIME:
        case SMALLDATETIME:
          i = SSType.DATETIME2.getJDBCType().asJavaSqlType();
          break;
        case MONEY:
        case SMALLMONEY:
          i = SSType.DECIMAL.getJDBCType().asJavaSqlType();
          break;
        case GUID:
          i = SSType.CHAR.getJDBCType().asJavaSqlType();
          break;
      } 


    
    } 
    return i;
  }

  
  public String getColumnTypeName(int paramInt) throws SQLServerException {
    checkClosed();
    
    CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
    if (null != cryptoMetadata) {
      return cryptoMetadata.getBaseTypeInfo().getSSTypeName();
    }
    
    return this.rs.getColumn(paramInt).getTypeInfo().getSSTypeName();
  }

  
  public int getPrecision(int paramInt) throws SQLServerException {
    checkClosed();
    
    CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
    if (null != cryptoMetadata) {
      return cryptoMetadata.getBaseTypeInfo().getPrecision();
    }
    
    return this.rs.getColumn(paramInt).getTypeInfo().getPrecision();
  }

  
  public int getScale(int paramInt) throws SQLServerException {
    checkClosed();
    
    CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
    if (null != cryptoMetadata) {
      return cryptoMetadata.getBaseTypeInfo().getScale();
    }
    
    return this.rs.getColumn(paramInt).getTypeInfo().getScale();
  }

  
  public String getSchemaName(int paramInt) throws SQLServerException {
    checkClosed();
    return this.rs.getColumn(paramInt).getTableName().getSchemaName();
  }

  
  public String getTableName(int paramInt) throws SQLServerException {
    checkClosed();
    return this.rs.getColumn(paramInt).getTableName().getObjectName();
  }

  
  public boolean isAutoIncrement(int paramInt) throws SQLServerException {
    checkClosed();
    
    CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
    if (null != cryptoMetadata) {
      return cryptoMetadata.getBaseTypeInfo().isIdentity();
    }
    
    return this.rs.getColumn(paramInt).getTypeInfo().isIdentity();
  }

  
  public boolean isCaseSensitive(int paramInt) throws SQLServerException {
    checkClosed();
    
    CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
    if (null != cryptoMetadata) {
      return cryptoMetadata.getBaseTypeInfo().isCaseSensitive();
    }
    
    return this.rs.getColumn(paramInt).getTypeInfo().isCaseSensitive();
  }

  
  public boolean isCurrency(int paramInt) throws SQLServerException {
    checkClosed();
    SSType sSType = this.rs.getColumn(paramInt).getTypeInfo().getSSType();
    
    CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
    if (null != cryptoMetadata) {
      sSType = cryptoMetadata.getBaseTypeInfo().getSSType();
    }
    
    return (SSType.MONEY == sSType || SSType.SMALLMONEY == sSType);
  }


  
  public boolean isDefinitelyWritable(int paramInt) throws SQLServerException {
    checkClosed();
    
    CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
    if (null != cryptoMetadata) {
      return (TypeInfo.UPDATABLE_READ_WRITE == cryptoMetadata.getBaseTypeInfo().getUpdatability());
    }
    
    return (TypeInfo.UPDATABLE_READ_WRITE == this.rs.getColumn(paramInt).getTypeInfo().getUpdatability());
  }

  
  public int isNullable(int paramInt) throws SQLServerException {
    checkClosed();
    
    CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
    if (null != cryptoMetadata) {
      return cryptoMetadata.getBaseTypeInfo().isNullable() ? 1 : 0;
    }
    
    return this.rs.getColumn(paramInt).getTypeInfo().isNullable() ? 1 : 0;
  }

  
  public boolean isReadOnly(int paramInt) throws SQLServerException {
    checkClosed();
    
    CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
    if (null != cryptoMetadata) {
      return (TypeInfo.UPDATABLE_READ_ONLY == cryptoMetadata.getBaseTypeInfo().getUpdatability());
    }
    
    return (TypeInfo.UPDATABLE_READ_ONLY == this.rs.getColumn(paramInt).getTypeInfo().getUpdatability());
  }

  
  public boolean isSearchable(int paramInt) throws SQLServerException {
    checkClosed();
    
    SSType sSType = null;
    CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
    
    if (null != cryptoMetadata) {
      sSType = cryptoMetadata.getBaseTypeInfo().getSSType();
    } else {
      
      sSType = this.rs.getColumn(paramInt).getTypeInfo().getSSType();
    } 
    
    switch (sSType) {
      
      case IMAGE:
      case TEXT:
      case NTEXT:
      case UDT:
      case XML:
        return false;
    } 
    
    return true;
  }


  
  public boolean isSigned(int paramInt) throws SQLServerException {
    checkClosed();
    
    CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
    if (null != cryptoMetadata) {
      return cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType().isSigned();
    }
    
    return this.rs.getColumn(paramInt).getTypeInfo().getSSType().getJDBCType().isSigned();
  }







  
  public boolean isSparseColumnSet(int paramInt) throws SQLServerException {
    checkClosed();
    
    CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
    if (null != cryptoMetadata) {
      return cryptoMetadata.getBaseTypeInfo().isSparseColumnSet();
    }
    
    return this.rs.getColumn(paramInt).getTypeInfo().isSparseColumnSet();
  }

  
  public boolean isWritable(int paramInt) throws SQLServerException {
    checkClosed();
    
    int i = -1;
    CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
    if (null != cryptoMetadata) {
      i = cryptoMetadata.getBaseTypeInfo().getUpdatability();
    } else {
      
      i = this.rs.getColumn(paramInt).getTypeInfo().getUpdatability();
    } 
    return (TypeInfo.UPDATABLE_READ_WRITE == i || TypeInfo.UPDATABLE_UNKNOWN == i);
  }


  
  public String getColumnClassName(int paramInt) throws SQLServerException {
    checkClosed();
    
    CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
    if (null != cryptoMetadata) {
      return cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType().className();
    }
    
    return this.rs.getColumn(paramInt).getTypeInfo().getSSType().getJDBCType().className();
  }
}
