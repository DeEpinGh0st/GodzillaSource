package com.microsoft.sqlserver.jdbc;

import java.io.ByteArrayInputStream;
import java.io.IOException;



















































































































































































































































































































































































































final class PLPXMLInputStream
  extends PLPInputStream
{
  private static final byte[] xmlBOM = new byte[] { -1, -2 };
  private final ByteArrayInputStream bomStream = new ByteArrayInputStream(xmlBOM);


  
  static final PLPXMLInputStream makeXMLStream(TDSReader paramTDSReader, InputStreamGetterArgs paramInputStreamGetterArgs, ServerDTVImpl paramServerDTVImpl) throws SQLServerException {
    long l = paramTDSReader.readLong();

    
    if (-1L == l) {
      return null;
    }
    PLPXMLInputStream pLPXMLInputStream = new PLPXMLInputStream(paramTDSReader, l, paramInputStreamGetterArgs, paramServerDTVImpl);
    if (null != pLPXMLInputStream) {
      pLPXMLInputStream.setLoggingInfo(paramInputStreamGetterArgs.logContext);
    }
    return pLPXMLInputStream;
  }





  
  PLPXMLInputStream(TDSReader paramTDSReader, long paramLong, InputStreamGetterArgs paramInputStreamGetterArgs, ServerDTVImpl paramServerDTVImpl) throws SQLServerException {
    super(paramTDSReader, paramLong, paramInputStreamGetterArgs.isAdaptive, paramInputStreamGetterArgs.isStreaming, paramServerDTVImpl);
  }

  
  public void close() throws IOException {
    super.close();
  }

  
  int readBytes(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
    assert paramInt1 >= 0;
    assert paramInt2 >= 0;
    
    if (0 == paramInt2) {
      return 0;
    }
    int i = 0;
    int j = 0;

    
    if (null == paramArrayOfbyte) {
      
      int k = 0;
      while (i < paramInt2 && 0 != (k = (int)this.bomStream.skip((paramInt2 - i)))) {
        i += k;
      }
    }
    else {
      
      int k = 0;
      while (i < paramInt2 && -1 != (k = this.bomStream.read(paramArrayOfbyte, paramInt1 + i, paramInt2 - i))) {
        i += k;
      }
    } 


    
    while (i < paramInt2 && -1 != (j = super.readBytes(paramArrayOfbyte, paramInt1 + i, paramInt2 - i))) {
      i += j;
    }
    
    if (i > 0) {
      return i;
    }
    
    assert -1 == j;
    return -1;
  }

  
  public void mark(int paramInt) {
    this.bomStream.mark(xmlBOM.length);
    super.mark(paramInt);
  }

  
  public void reset() throws IOException {
    this.bomStream.reset();
    super.reset();
  }







  
  byte[] getBytes() throws SQLServerException {
    byte[] arrayOfByte = new byte[2];
    
    try {
      int i = this.bomStream.read(arrayOfByte);
      byte[] arrayOfByte1 = super.getBytes();
      
      if (i > 0) {
        
        assert 2 == i;
        byte[] arrayOfByte2 = new byte[arrayOfByte1.length + i];
        System.arraycopy(arrayOfByte, 0, arrayOfByte2, 0, i);
        System.arraycopy(arrayOfByte1, 0, arrayOfByte2, i, arrayOfByte1.length);
        return arrayOfByte2;
      } 
      
      return arrayOfByte1;
    } catch (IOException iOException) {
      
      SQLServerException.makeFromDriverError(null, null, iOException.getMessage(), null, true);






      
      return null;
    } 
  }
}
