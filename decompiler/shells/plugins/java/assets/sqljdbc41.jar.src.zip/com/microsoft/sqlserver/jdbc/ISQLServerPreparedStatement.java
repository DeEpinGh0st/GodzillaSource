package com.microsoft.sqlserver.jdbc;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import microsoft.sql.DateTimeOffset;

public interface ISQLServerPreparedStatement extends PreparedStatement, ISQLServerStatement {
  void setDateTimeOffset(int paramInt, DateTimeOffset paramDateTimeOffset) throws SQLException;
}
