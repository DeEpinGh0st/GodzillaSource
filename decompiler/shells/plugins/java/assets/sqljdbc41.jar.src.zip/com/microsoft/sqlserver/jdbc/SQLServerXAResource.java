package com.microsoft.sqlserver.jdbc;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.Properties;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.transaction.xa.XAException;
import javax.transaction.xa.XAResource;
import javax.transaction.xa.Xid;







































































































public final class SQLServerXAResource
  implements XAResource
{
  private int timeoutSeconds;
  static final int XA_START = 0;
  static final int XA_END = 1;
  static final int XA_PREPARE = 2;
  static final int XA_COMMIT = 3;
  static final int XA_ROLLBACK = 4;
  static final int XA_FORGET = 5;
  static final int XA_RECOVER = 6;
  static final int XA_PREPARE_EX = 7;
  static final int XA_ROLLBACK_EX = 8;
  static final int XA_FORGET_EX = 9;
  static final int XA_INIT = 10;
  private SQLServerConnection controlConnection;
  private SQLServerConnection con;
  private boolean serverInfoRetrieved;
  private String version;
  private String instanceName;
  private int ArchitectureMSSQL;
  private int ArchitectureOS;
  private static boolean xaInitDone;
  private static Integer xaInitLock;
  private String sResourceManagerId;
  private int enlistedTransactionCount;
  private final Logger xaLogger;
  private static int baseResourceID = 0;
  private int tightlyCoupled = 0;
  private int isTransacrionTimeoutSet = 0;
  
  public static final int SSTRANSTIGHTLYCPLD = 32768;
  private SQLServerCallableStatement[] xaStatements = new SQLServerCallableStatement[] { null, null, null, null, null, null, null, null, null, null };
  
  private final String traceID;

  
  static {
    xaInitLock = new Integer(0);
  }

  
  public String toString() {
    return this.traceID;
  }

  
  SQLServerXAResource(SQLServerConnection paramSQLServerConnection1, SQLServerConnection paramSQLServerConnection2, String paramString) {
    this.traceID = " XAResourceID:" + nextResourceID();
    
    this.xaLogger = SQLServerXADataSource.xaLogger;
    this.controlConnection = paramSQLServerConnection2;
    this.con = paramSQLServerConnection1;
    Properties properties = paramSQLServerConnection1.activeConnectionProperties;
    if (properties == null) {
      this.sResourceManagerId = "";
    } else {
      
      this.sResourceManagerId = properties.getProperty(SQLServerDriverStringProperty.SERVER_NAME.toString()) + "." + properties.getProperty(SQLServerDriverStringProperty.DATABASE_NAME.toString()) + "." + properties.getProperty(SQLServerDriverIntProperty.PORT_NUMBER.toString());
    } 

    
    if (this.xaLogger.isLoggable(Level.FINE)) {
      this.xaLogger.fine(toString() + " created by (" + paramString + ")");
    }
    
    this.serverInfoRetrieved = false;
    this.version = "0";
    this.instanceName = "";
    this.ArchitectureMSSQL = 0;
    this.ArchitectureOS = 0;
  }


  
  private synchronized SQLServerCallableStatement getXACallableStatementHandle(int paramInt) throws SQLServerException {
    assert paramInt >= 0 && paramInt <= 9;
    assert paramInt < this.xaStatements.length;
    if (null != this.xaStatements[paramInt]) {
      return this.xaStatements[paramInt];
    }
    CallableStatement callableStatement = null;
    
    switch (paramInt)
    
    { case 0:
        callableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_start(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");
































        
        this.xaStatements[paramInt] = (SQLServerCallableStatement)callableStatement;
        return this.xaStatements[paramInt];case 1: callableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_end(?, ?, ?, ?, ?, ?, ?)}"); this.xaStatements[paramInt] = (SQLServerCallableStatement)callableStatement; return this.xaStatements[paramInt];case 2: callableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_prepare(?, ?, ?, ?, ?)}"); this.xaStatements[paramInt] = (SQLServerCallableStatement)callableStatement; return this.xaStatements[paramInt];case 3: callableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_commit(?, ?, ?, ?, ?, ?)}"); this.xaStatements[paramInt] = (SQLServerCallableStatement)callableStatement; return this.xaStatements[paramInt];case 4: callableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_rollback(?, ?, ?, ?, ?)}"); this.xaStatements[paramInt] = (SQLServerCallableStatement)callableStatement; return this.xaStatements[paramInt];case 5: callableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_forget(?, ?, ?, ?, ?)}"); this.xaStatements[paramInt] = (SQLServerCallableStatement)callableStatement; return this.xaStatements[paramInt];case 6: callableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_recover(?, ?, ?, ?)}"); this.xaStatements[paramInt] = (SQLServerCallableStatement)callableStatement; return this.xaStatements[paramInt];case 7: callableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_prepare_ex(?, ?, ?, ?, ?, ?)}"); this.xaStatements[paramInt] = (SQLServerCallableStatement)callableStatement; return this.xaStatements[paramInt];case 8: callableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_rollback_ex(?, ?, ?, ?, ?, ?)}"); this.xaStatements[paramInt] = (SQLServerCallableStatement)callableStatement; return this.xaStatements[paramInt];case 9: callableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_forget_ex(?, ?, ?, ?, ?, ?)}"); this.xaStatements[paramInt] = (SQLServerCallableStatement)callableStatement; return this.xaStatements[paramInt]; }  assert false : "Bad handle request:" + paramInt; this.xaStatements[paramInt] = (SQLServerCallableStatement)callableStatement; return this.xaStatements[paramInt];
  }
  
  private synchronized void closeXAStatements() throws SQLServerException {
    for (byte b = 0; b < this.xaStatements.length; b++) {
      if (null != this.xaStatements[b]) {
        
        this.xaStatements[b].close();
        this.xaStatements[b] = null;
      } 
    } 
  }
  
  final synchronized void close() throws SQLServerException {
    try {
      closeXAStatements();
    }
    catch (Exception exception) {
      
      if (this.xaLogger.isLoggable(Level.WARNING)) {
        this.xaLogger.warning(toString() + "Closing exception ignored: " + exception);
      }
    } 
    if (null != this.controlConnection) {
      this.controlConnection.close();
    }
  }





  
  private String flagsDisplay(int paramInt) {
    if (0 == paramInt) return "TMNOFLAGS";

    
    StringBuilder stringBuilder = new StringBuilder(100);
    
    if (0 != (0x800000 & paramInt)) stringBuilder.append("TMENDRSCAN");
    
    if (0 != (0x20000000 & paramInt)) {
      
      if (stringBuilder.length() > 0) stringBuilder.append("|"); 
      stringBuilder.append("TMFAIL");
    } 
    if (0 != (0x200000 & paramInt)) {
      
      if (stringBuilder.length() > 0) stringBuilder.append("|"); 
      stringBuilder.append("TMJOIN");
    } 
    if (0 != (0x40000000 & paramInt)) {
      
      if (stringBuilder.length() > 0) stringBuilder.append("|"); 
      stringBuilder.append("TMONEPHASE");
    } 
    if (0 != (0x8000000 & paramInt)) {
      
      if (stringBuilder.length() > 0) stringBuilder.append("|"); 
      stringBuilder.append("TMRESUME");
    } 
    if (0 != (0x1000000 & paramInt)) {
      
      if (stringBuilder.length() > 0) stringBuilder.append("|"); 
      stringBuilder.append("TMSTARTRSCAN");
    } 
    if (0 != (0x4000000 & paramInt)) {
      
      if (stringBuilder.length() > 0) stringBuilder.append("|"); 
      stringBuilder.append("TMSUCCESS");
    } 
    if (0 != (0x2000000 & paramInt)) {
      
      if (stringBuilder.length() > 0) stringBuilder.append("|"); 
      stringBuilder.append("TMSUSPEND");
    } 
    
    if (0 != (0x8000 & paramInt)) {
      
      if (stringBuilder.length() > 0) stringBuilder.append("|"); 
      stringBuilder.append("SSTRANSTIGHTLYCPLD");
    } 
    return stringBuilder.toString();
  }


  
  private String cookieDisplay(byte[] paramArrayOfbyte) {
    return Util.byteToHexDisplayString(paramArrayOfbyte);
  }


  
  private String typeDisplay(int paramInt) {
    switch (paramInt) {
      case 0:
        return "XA_START";
      case 1: return "XA_END";
      case 2: return "XA_PREPARE";
      case 3: return "XA_COMMIT";
      case 4: return "XA_ROLLBACK";
      case 5: return "XA_FORGET";
      case 6: return "XA_RECOVER";
    }  return "UNKNOWN" + paramInt;
  }





  
  private final XAReturnValue DTC_XA_Interface(int paramInt1, Xid paramXid, int paramInt2) throws XAException {
    if (this.xaLogger.isLoggable(Level.FINER)) {
      this.xaLogger.finer(toString() + " Calling XA function for type:" + typeDisplay(paramInt1) + " flags:" + flagsDisplay(paramInt2) + " xid:" + XidImpl.xidDisplay(paramXid));
    }
    int i = 0;
    byte[] arrayOfByte1 = null;
    byte[] arrayOfByte2 = null;
    if (paramXid != null) {
      
      i = paramXid.getFormatId();
      arrayOfByte1 = paramXid.getGlobalTransactionId();
      arrayOfByte2 = paramXid.getBranchQualifier();
    } 
    
    String str = "DTC_XA_";
    byte b = 1;
    int j = 0;
    XAReturnValue xAReturnValue = new XAReturnValue();
    
    SQLServerCallableStatement sQLServerCallableStatement = null;
    
    try {
      synchronized (this) {
        
        if (this.controlConnection == null) {
          
          try {
            
            synchronized (xaInitLock) {
              
              if (!xaInitDone)
              {
                SQLServerCallableStatement sQLServerCallableStatement1 = null;
                
                sQLServerCallableStatement1 = (SQLServerCallableStatement)this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_init_ex(?, ?,?)}");
                sQLServerCallableStatement1.registerOutParameter(1, 4);
                sQLServerCallableStatement1.registerOutParameter(2, 1);
                sQLServerCallableStatement1.registerOutParameter(3, 1);
                
                try {
                  sQLServerCallableStatement1.execute();
                }
                catch (SQLServerException sQLServerException) {

                  
                  try {
                    sQLServerCallableStatement1.close();
                    
                    this.controlConnection.close();
                  }
                  catch (SQLException sQLException) {

                    
                    if (this.xaLogger.isLoggable(Level.FINER))
                      this.xaLogger.finer(toString() + " Ignoring exception when closing failed execution. exception:" + sQLException); 
                  } 
                  if (this.xaLogger.isLoggable(Level.FINER))
                    this.xaLogger.finer(toString() + " exception:" + sQLServerException); 
                  throw sQLServerException;
                } 

                
                int k = sQLServerCallableStatement1.getInt(1);
                String str2 = sQLServerCallableStatement1.getString(2);
                String str3 = sQLServerCallableStatement1.getString(3);
                if (this.xaLogger.isLoggable(Level.FINE))
                  this.xaLogger.fine(toString() + " Server XA DLL version:" + str3); 
                sQLServerCallableStatement1.close();
                if (0 != k) {
                  
                  assert null != str2 && str2.length() > 1;
                  this.controlConnection.close();
                  
                  MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_failedToInitializeXA"));
                  Object[] arrayOfObject = { String.valueOf(k), str2 };
                  XAException xAException = new XAException(messageFormat.format(arrayOfObject));
                  xAException.errorCode = k;
                  if (this.xaLogger.isLoggable(Level.FINER))
                    this.xaLogger.finer(toString() + " exception:" + xAException); 
                  throw xAException;
                } 
                
                xaInitDone = true;
              }
            
            } 
          } catch (SQLServerException sQLServerException) {
            
            MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_failedToCreateXAConnection"));
            Object[] arrayOfObject = { new String(sQLServerException.getMessage()) };
            if (this.xaLogger.isLoggable(Level.FINER))
              this.xaLogger.finer(toString() + " exception:" + messageFormat.format(arrayOfObject)); 
            SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, messageFormat.format(arrayOfObject), (String)null, true);
          } 
        }
      } 
      
      switch (paramInt1) {
        
        case 0:
          if (!this.serverInfoRetrieved) {
            
            try {
              this.serverInfoRetrieved = true;
              
              String str2 = "select convert(varchar(100), SERVERPROPERTY('Edition'))as edition,  convert(varchar(100), SERVERPROPERTY('InstanceName'))as instance, convert(varchar(100), SERVERPROPERTY('ProductVersion')) as version, SUBSTRING(@@VERSION, CHARINDEX('<', @@VERSION)+2, 2)";



              
              Statement statement = this.controlConnection.createStatement();
              ResultSet resultSet = statement.executeQuery(str2);
              resultSet.next();
              
              String str3 = resultSet.getString(1);
              this.ArchitectureMSSQL = (null != str3 && str3.contains("(64-bit)")) ? 64 : 32;

              
              this.instanceName = (resultSet.getString(2) == null) ? "MSSQLSERVER" : resultSet.getString(2);
              this.version = resultSet.getString(3);
              if (null == this.version) {
                
                this.version = "0";
              }
              else if (-1 != this.version.indexOf('.')) {
                
                this.version = this.version.substring(0, this.version.indexOf('.'));
              } 


              
              this.ArchitectureOS = Integer.parseInt(resultSet.getString(4));
              
              resultSet.close();
              statement.close();

            
            }
            catch (Exception exception) {
              if (this.xaLogger.isLoggable(Level.WARNING)) {
                this.xaLogger.warning(toString() + " Cannot retrieve server information: :" + exception.getMessage());
              }
            } 
          }
          str = "START:";
          sQLServerCallableStatement = getXACallableStatementHandle(0);
          sQLServerCallableStatement.registerOutParameter(b++, 4);
          sQLServerCallableStatement.registerOutParameter(b++, 1);
          sQLServerCallableStatement.setBytes(b++, arrayOfByte1);
          sQLServerCallableStatement.setBytes(b++, arrayOfByte2);
          sQLServerCallableStatement.setInt(b++, paramInt2);
          sQLServerCallableStatement.registerOutParameter(b++, -2);
          sQLServerCallableStatement.setInt(b++, this.timeoutSeconds);
          sQLServerCallableStatement.setInt(b++, i);
          sQLServerCallableStatement.registerOutParameter(b++, 1);
          sQLServerCallableStatement.setInt(b++, Integer.parseInt(this.version));
          sQLServerCallableStatement.setInt(b++, this.instanceName.length());
          sQLServerCallableStatement.setBytes(b++, this.instanceName.getBytes());
          sQLServerCallableStatement.setInt(b++, this.ArchitectureMSSQL);
          sQLServerCallableStatement.setInt(b++, this.ArchitectureOS);
          sQLServerCallableStatement.setInt(b++, this.isTransacrionTimeoutSet);
          sQLServerCallableStatement.registerOutParameter(b++, -2);
          break;

        
        case 1:
          str = "END:";
          sQLServerCallableStatement = getXACallableStatementHandle(1);
          sQLServerCallableStatement.registerOutParameter(b++, 4);
          sQLServerCallableStatement.registerOutParameter(b++, 1);
          sQLServerCallableStatement.setBytes(b++, arrayOfByte1);
          sQLServerCallableStatement.setBytes(b++, arrayOfByte2);
          sQLServerCallableStatement.setInt(b++, paramInt2);
          sQLServerCallableStatement.setInt(b++, i);
          sQLServerCallableStatement.registerOutParameter(b++, -2);
          break;
        
        case 2:
          str = "PREPARE:";
          if ((0x8000 & paramInt2) == 32768) {
            sQLServerCallableStatement = getXACallableStatementHandle(7);
          } else {
            sQLServerCallableStatement = getXACallableStatementHandle(2);
          } 
          sQLServerCallableStatement.registerOutParameter(b++, 4);
          sQLServerCallableStatement.registerOutParameter(b++, 1);
          sQLServerCallableStatement.setBytes(b++, arrayOfByte1);
          sQLServerCallableStatement.setBytes(b++, arrayOfByte2);
          if ((0x8000 & paramInt2) == 32768)
            sQLServerCallableStatement.setInt(b++, paramInt2); 
          sQLServerCallableStatement.setInt(b++, i);
          break;
        
        case 3:
          str = "COMMIT:";
          sQLServerCallableStatement = getXACallableStatementHandle(3);
          sQLServerCallableStatement.registerOutParameter(b++, 4);
          sQLServerCallableStatement.registerOutParameter(b++, 1);
          sQLServerCallableStatement.setBytes(b++, arrayOfByte1);
          sQLServerCallableStatement.setBytes(b++, arrayOfByte2);
          sQLServerCallableStatement.setInt(b++, paramInt2);
          sQLServerCallableStatement.setInt(b++, i);
          break;
        
        case 4:
          str = "ROLLBACK:";
          if ((0x8000 & paramInt2) == 32768) {
            sQLServerCallableStatement = getXACallableStatementHandle(8);
          } else {
            sQLServerCallableStatement = getXACallableStatementHandle(4);
          } 
          sQLServerCallableStatement.registerOutParameter(b++, 4);
          sQLServerCallableStatement.registerOutParameter(b++, 1);
          sQLServerCallableStatement.setBytes(b++, arrayOfByte1);
          sQLServerCallableStatement.setBytes(b++, arrayOfByte2);
          if ((0x8000 & paramInt2) == 32768)
            sQLServerCallableStatement.setInt(b++, paramInt2); 
          sQLServerCallableStatement.setInt(b++, i);
          break;
        
        case 5:
          str = "FORGET:";
          if ((0x8000 & paramInt2) == 32768) {
            sQLServerCallableStatement = getXACallableStatementHandle(9);
          } else {
            sQLServerCallableStatement = getXACallableStatementHandle(5);
          }  sQLServerCallableStatement.registerOutParameter(b++, 4);
          sQLServerCallableStatement.registerOutParameter(b++, 1);
          sQLServerCallableStatement.setBytes(b++, arrayOfByte1);
          sQLServerCallableStatement.setBytes(b++, arrayOfByte2);
          if ((0x8000 & paramInt2) == 32768)
            sQLServerCallableStatement.setInt(b++, paramInt2); 
          sQLServerCallableStatement.setInt(b++, i);
          break;
        
        case 6:
          str = "RECOVER:";
          sQLServerCallableStatement = getXACallableStatementHandle(6);
          sQLServerCallableStatement.registerOutParameter(b++, 4);
          sQLServerCallableStatement.registerOutParameter(b++, 1);
          sQLServerCallableStatement.setInt(b++, paramInt2);
          sQLServerCallableStatement.registerOutParameter(b++, -2);
          break;
        
        default:
          assert false : "Unknown execution type:" + paramInt1;
          break;
      } 



      
      sQLServerCallableStatement.execute();
      j = sQLServerCallableStatement.getInt(1);
      String str1 = sQLServerCallableStatement.getString(2);
      if (paramInt1 == 0) {
        
        String str2 = sQLServerCallableStatement.getString(9);
        if (this.xaLogger.isLoggable(Level.FINE)) {
          
          this.xaLogger.fine(toString() + " Server XA DLL version:" + str2);
          if (null != sQLServerCallableStatement.getString(16)) {
            
            StringBuffer stringBuffer = new StringBuffer(sQLServerCallableStatement.getString(16));
            stringBuffer.insert(20, '-');
            stringBuffer.insert(16, '-');
            stringBuffer.insert(12, '-');
            stringBuffer.insert(8, '-');
            this.xaLogger.fine(toString() + " XID to UoW mapping for XA type:XA_START XID: " + XidImpl.xidDisplay(paramXid) + " UoW: " + stringBuffer.toString());
          } 
        } 
      } 
      if (paramInt1 == 1)
      {
        if (this.xaLogger.isLoggable(Level.FINE))
        {
          if (null != sQLServerCallableStatement.getString(7)) {
            
            StringBuffer stringBuffer = new StringBuffer(sQLServerCallableStatement.getString(7));
            stringBuffer.insert(20, '-');
            stringBuffer.insert(16, '-');
            stringBuffer.insert(12, '-');
            stringBuffer.insert(8, '-');
            this.xaLogger.fine(toString() + " XID to UoW mapping for XA type:XA_END XID: " + XidImpl.xidDisplay(paramXid) + " UoW: " + stringBuffer.toString());
          } 
        }
      }

      
      if ((3 == j && 1 != paramInt1 && 2 != paramInt1) || (0 != j && 3 != j)) {

        
        assert null != str1 && str1.length() > 1;
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_failedFunctionXA"));
        Object[] arrayOfObject = { str, String.valueOf(j), str1 };
        XAException xAException = new XAException(messageFormat.format(arrayOfObject));
        xAException.errorCode = j;
        
        if (paramInt1 == 1 && -7 == j) {
          
          try {
            
            if (this.xaLogger.isLoggable(Level.FINER))
              this.xaLogger.finer(toString() + " Begin un-enlist, enlisted count:" + this.enlistedTransactionCount); 
            this.con.JTAUnenlistConnection();
            this.enlistedTransactionCount--;
            if (this.xaLogger.isLoggable(Level.FINER)) {
              this.xaLogger.finer(toString() + " End un-enlist, enlisted count:" + this.enlistedTransactionCount);
            }
          } catch (SQLServerException sQLServerException) {

            
            if (this.xaLogger.isLoggable(Level.FINER)) {
              this.xaLogger.finer(toString() + " Ignoring exception:" + sQLServerException);
            }
          } 
        }
        
        throw xAException;
      } 

      
      if (paramInt1 == 0) {


        
        byte[] arrayOfByte = sQLServerCallableStatement.getBytes(6);
        if (arrayOfByte == null) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_noTransactionCookie"));
          Object[] arrayOfObject = { str };
          SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, messageFormat.format(arrayOfObject), (String)null, true);
        } else {

          
          try {

            
            if (this.xaLogger.isLoggable(Level.FINER))
              this.xaLogger.finer(toString() + " Begin enlisting, cookie:" + cookieDisplay(arrayOfByte) + " enlisted count:" + this.enlistedTransactionCount); 
            this.con.JTAEnlistConnection(arrayOfByte);
            this.enlistedTransactionCount++;
            if (this.xaLogger.isLoggable(Level.FINER)) {
              this.xaLogger.finer(toString() + " End enlisting, cookie:" + cookieDisplay(arrayOfByte) + " enlisted count:" + this.enlistedTransactionCount);
            }
          } catch (SQLServerException sQLServerException) {
            
            MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_failedToEnlist"));
            Object[] arrayOfObject = { sQLServerException.getMessage() };
            SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, messageFormat.format(arrayOfObject), (String)null, true);
          } 
        } 
      } 
      
      if (paramInt1 == 1) {
        
        try {
          
          if (this.xaLogger.isLoggable(Level.FINER))
            this.xaLogger.finer(toString() + " Begin un-enlist, enlisted count:" + this.enlistedTransactionCount); 
          this.con.JTAUnenlistConnection();
          this.enlistedTransactionCount--;
          if (this.xaLogger.isLoggable(Level.FINER)) {
            this.xaLogger.finer(toString() + " End un-enlist, enlisted count:" + this.enlistedTransactionCount);
          }
        } catch (SQLServerException sQLServerException) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_failedToUnEnlist"));
          Object[] arrayOfObject = { sQLServerException.getMessage() };
          SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, messageFormat.format(arrayOfObject), (String)null, true);
        } 
      }
      if (paramInt1 == 6) {
        try
        {

          
          xAReturnValue.bData = sQLServerCallableStatement.getBytes(4);
        }
        catch (SQLServerException sQLServerException)
        {
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_failedToReadRecoveryXIDs"));
          Object[] arrayOfObject = { sQLServerException.getMessage() };
          SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, messageFormat.format(arrayOfObject), (String)null, true);
        }
      
      }
    }
    catch (SQLServerException sQLServerException) {
      
      if (this.xaLogger.isLoggable(Level.FINER))
        this.xaLogger.finer(toString() + " exception:" + sQLServerException); 
      XAException xAException = new XAException(sQLServerException.toString());
      xAException.errorCode = -3;
      throw xAException;
    } 
    
    if (this.xaLogger.isLoggable(Level.FINER)) {
      this.xaLogger.finer(toString() + " Status:" + j);
    }
    xAReturnValue.nStatus = j;
    return xAReturnValue;
  }


















  
  public void start(Xid paramXid, int paramInt) throws XAException {
    this.tightlyCoupled = paramInt & 0x8000;
    DTC_XA_Interface(0, paramXid, paramInt);
  }









  
  public void end(Xid paramXid, int paramInt) throws XAException {
    DTC_XA_Interface(1, paramXid, paramInt | this.tightlyCoupled);
  }








  
  public int prepare(Xid paramXid) throws XAException {
    int i = 0;
    XAReturnValue xAReturnValue = DTC_XA_Interface(2, paramXid, this.tightlyCoupled);
    i = xAReturnValue.nStatus;
    
    return i;
  }

  
  public void commit(Xid paramXid, boolean paramBoolean) throws XAException {
    DTC_XA_Interface(3, paramXid, (paramBoolean ? 1073741824 : 0) | this.tightlyCoupled);
  }

  
  public void rollback(Xid paramXid) throws XAException {
    DTC_XA_Interface(4, paramXid, this.tightlyCoupled);
  }

  
  public void forget(Xid paramXid) throws XAException {
    DTC_XA_Interface(5, paramXid, this.tightlyCoupled);
  }

  
  public Xid[] recover(int paramInt) throws XAException {
    XAReturnValue xAReturnValue = DTC_XA_Interface(6, null, paramInt | this.tightlyCoupled);
    int i = 0;
    Vector<XidImpl> vector = new Vector();









    
    if (null == xAReturnValue.bData) return (Xid[])new XidImpl[0];
    
    while (i < xAReturnValue.bData.length) {
      
      int j = 1;
      int k = 0; int m;
      for (m = 0; m < 4; m++) {
        
        int i1 = xAReturnValue.bData[i + m] & 0xFF;
        i1 *= j;
        k += i1;
        j *= 256;
      } 
      i += 4;
      m = xAReturnValue.bData[i++] & 0xFF;
      int n = xAReturnValue.bData[i++] & 0xFF;
      byte[] arrayOfByte1 = new byte[m];
      byte[] arrayOfByte2 = new byte[n];
      System.arraycopy(xAReturnValue.bData, i, arrayOfByte1, 0, m);
      i += m;
      System.arraycopy(xAReturnValue.bData, i, arrayOfByte2, 0, n);
      i += n;
      XidImpl xidImpl = new XidImpl(k, arrayOfByte1, arrayOfByte2);
      vector.add(xidImpl);
    } 
    XidImpl[] arrayOfXidImpl = new XidImpl[vector.size()];
    for (byte b = 0; b < vector.size(); b++) {
      
      arrayOfXidImpl[b] = vector.elementAt(b);
      if (this.xaLogger.isLoggable(Level.FINER))
        this.xaLogger.finer(toString() + arrayOfXidImpl[b].toString()); 
    } 
    return (Xid[])arrayOfXidImpl;
  }



  
  public boolean isSameRM(XAResource paramXAResource) throws XAException {
    if (this.xaLogger.isLoggable(Level.FINER)) {
      this.xaLogger.finer(toString() + " xares:" + paramXAResource);
    }
    
    if (!(paramXAResource instanceof SQLServerXAResource))
      return false; 
    SQLServerXAResource sQLServerXAResource = (SQLServerXAResource)paramXAResource;
    return sQLServerXAResource.sResourceManagerId.equals(this.sResourceManagerId);
  }



  
  public boolean setTransactionTimeout(int paramInt) throws XAException {
    this.isTransacrionTimeoutSet = 1;
    this.timeoutSeconds = paramInt;
    if (this.xaLogger.isLoggable(Level.FINER))
      this.xaLogger.finer(toString() + " TransactionTimeout:" + paramInt); 
    return true;
  }

  
  public int getTransactionTimeout() throws XAException {
    return this.timeoutSeconds;
  }


  
  private static synchronized int nextResourceID() {
    baseResourceID++;
    return baseResourceID;
  }
}
