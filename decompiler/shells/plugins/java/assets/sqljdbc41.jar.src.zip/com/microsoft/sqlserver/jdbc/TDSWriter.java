package com.microsoft.sqlserver.jdbc;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Locale;
import java.util.Map;
import java.util.SimpleTimeZone;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.DatatypeConverter;
import microsoft.sql.DateTimeOffset;










































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































final class TDSWriter
{
  private static Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.TDS.Writer"); private final String traceID; private final TDSChannel tdsChannel; private final SQLServerConnection con;
  public final String toString() {
    return this.traceID;
  }


  
  private boolean dataIsLoggable = true;


  
  void setDataLoggable(boolean paramBoolean) {
    this.dataIsLoggable = paramBoolean;
  }
  private TDSCommand command = null;


  
  private byte tdsMessageType;

  
  private volatile int sendResetConnection = 0;




  
  private int currentPacketSize = 0;



  
  private static final int TDS_PACKET_HEADER_SIZE = 8;



  
  private static final byte[] placeholderHeader = new byte[8];



  
  private byte[] valueBytes = new byte[256];

  
  private volatile int packetNum = 0;
  
  private static final int BYTES4 = 4;
  
  private static final int BYTES8 = 8;
  
  private static final int BYTES12 = 12;
  private static final int BYTES16 = 16;
  public static final int BIGDECIMAL_MAX_LENGTH = 17;
  private boolean isEOMSent = false;
  private ByteBuffer stagingBuffer;
  private ByteBuffer socketBuffer;
  private ByteBuffer logBuffer;
  
  boolean isEOMSent() {
    return this.isEOMSent;
  }





  
  private CryptoMetadata cryptoMeta = null;

  
  TDSWriter(TDSChannel paramTDSChannel, SQLServerConnection paramSQLServerConnection) {
    this.tdsChannel = paramTDSChannel;
    this.con = paramSQLServerConnection;
    this.traceID = "TDSWriter@" + Integer.toHexString(hashCode()) + " (" + paramSQLServerConnection.toString() + ")";
  }



  
  void preparePacket() throws SQLServerException {
    if (this.tdsChannel.isLoggingPackets()) {
      
      Arrays.fill(this.logBuffer.array(), (byte)-2);
      this.logBuffer.clear();
    } 


    
    writeBytes(placeholderHeader);
  }









  
  void writeMessageHeader() throws SQLServerException {
    if (1 == this.tdsMessageType || 14 == this.tdsMessageType || 3 == this.tdsMessageType) {


      
      boolean bool = false;
      byte b = 22;
      if (1 == this.tdsMessageType || 3 == this.tdsMessageType)
      {
        if (this.con.isDenaliOrLater() && !ActivityCorrelator.getCurrent().IsSentToServer() && Util.IsActivityTraceOn()) {
          
          bool = true;
          b += 26;
        } 
      }
      writeInt(b);
      writeInt(18);
      writeShort((short)2);
      writeBytes(this.con.getTransactionDescriptor());
      writeInt(1);
      if (bool) {
        
        writeInt(26);
        writeTraceHeaderData();
        ActivityCorrelator.setCurrentActivityIdSentFlag();
      } 
    } 
  }


  
  void writeTraceHeaderData() throws SQLServerException {
    ActivityId activityId = ActivityCorrelator.getCurrent();
    byte[] arrayOfByte = Util.asGuidByteArray(activityId.getId());
    long l = activityId.getSequence();
    writeShort((short)3);
    writeBytes(arrayOfByte, 0, arrayOfByte.length);
    writeInt((int)l);
    
    if (logger.isLoggable(Level.FINER)) {
      logger.finer("Send Trace Header - ActivityID: " + activityId.toString());
    }
  }






  
  void startMessage(TDSCommand paramTDSCommand, byte paramByte) throws SQLServerException {
    this.command = paramTDSCommand;
    this.tdsMessageType = paramByte;
    this.packetNum = 0;
    this.isEOMSent = false;
    this.dataIsLoggable = true;



    
    int i = this.con.getTDSPacketSize();
    if (this.currentPacketSize != i) {
      
      this.socketBuffer = ByteBuffer.allocate(i).order(ByteOrder.LITTLE_ENDIAN);
      this.stagingBuffer = ByteBuffer.allocate(i).order(ByteOrder.LITTLE_ENDIAN);
      this.logBuffer = ByteBuffer.allocate(i).order(ByteOrder.LITTLE_ENDIAN);
      this.currentPacketSize = i;
    } 
    
    this.socketBuffer.position(this.socketBuffer.limit());
    this.stagingBuffer.clear();
    
    preparePacket();
    writeMessageHeader();
  }

  
  final void endMessage() throws SQLServerException {
    if (logger.isLoggable(Level.FINEST))
      logger.finest(toString() + " Finishing TDS message"); 
    writePacket(1);
  }




  
  final boolean ignoreMessage() throws SQLServerException {
    if (this.packetNum > 0) {
      
      assert !this.isEOMSent;
      
      if (logger.isLoggable(Level.FINER))
        logger.finest(toString() + " Finishing TDS message by sending ignore bit and end of message"); 
      writePacket(3);
      return true;
    } 
    return false;
  }

  
  final void resetPooledConnection() {
    if (logger.isLoggable(Level.FINEST))
      logger.finest(toString() + " resetPooledConnection"); 
    this.sendResetConnection = 8;
  }



  
  void writeByte(byte paramByte) throws SQLServerException {
    if (this.stagingBuffer.remaining() >= 1) {
      
      this.stagingBuffer.put(paramByte);
      if (this.tdsChannel.isLoggingPackets())
      {
        if (this.dataIsLoggable) {
          this.logBuffer.put(paramByte);
        } else {
          this.logBuffer.position(this.logBuffer.position() + 1);
        } 
      }
    } else {
      
      this.valueBytes[0] = paramByte;
      writeWrappedBytes(this.valueBytes, 1);
    } 
  }

  
  void writeChar(char paramChar) throws SQLServerException {
    if (this.stagingBuffer.remaining() >= 2) {
      
      this.stagingBuffer.putChar(paramChar);
      if (this.tdsChannel.isLoggingPackets())
      {
        if (this.dataIsLoggable) {
          this.logBuffer.putChar(paramChar);
        } else {
          this.logBuffer.position(this.logBuffer.position() + 2);
        } 
      }
    } else {
      
      Util.writeShort((short)paramChar, this.valueBytes, 0);
      writeWrappedBytes(this.valueBytes, 2);
    } 
  }

  
  void writeShort(short paramShort) throws SQLServerException {
    if (this.stagingBuffer.remaining() >= 2) {
      
      this.stagingBuffer.putShort(paramShort);
      if (this.tdsChannel.isLoggingPackets())
      {
        if (this.dataIsLoggable) {
          this.logBuffer.putShort(paramShort);
        } else {
          this.logBuffer.position(this.logBuffer.position() + 2);
        } 
      }
    } else {
      
      Util.writeShort(paramShort, this.valueBytes, 0);
      writeWrappedBytes(this.valueBytes, 2);
    } 
  }

  
  void writeInt(int paramInt) throws SQLServerException {
    if (this.stagingBuffer.remaining() >= 4) {
      
      this.stagingBuffer.putInt(paramInt);
      if (this.tdsChannel.isLoggingPackets())
      {
        if (this.dataIsLoggable) {
          this.logBuffer.putInt(paramInt);
        } else {
          this.logBuffer.position(this.logBuffer.position() + 4);
        } 
      }
    } else {
      
      Util.writeInt(paramInt, this.valueBytes, 0);
      writeWrappedBytes(this.valueBytes, 4);
    } 
  }


















  
  void writeReal(Float paramFloat) throws SQLServerException {
    writeInt(Float.floatToRawIntBits(paramFloat.floatValue()));
  }






  
  void writeDouble(double paramDouble) throws SQLServerException {
    if (this.stagingBuffer.remaining() >= 8) {
      
      this.stagingBuffer.putDouble(paramDouble);
      if (this.tdsChannel.isLoggingPackets())
      {
        if (this.dataIsLoggable) {
          this.logBuffer.putDouble(paramDouble);
        } else {
          this.logBuffer.position(this.logBuffer.position() + 8);
        } 
      }
    } else {
      
      long l1 = Double.doubleToLongBits(paramDouble);
      long l2 = 255L;
      boolean bool = false;
      for (byte b = 0; b < 8; b++) {
        
        writeByte((byte)(int)((l1 & l2) >> bool));
        bool += true;
        l2 <<= 8L;
      } 
    } 
  }
















  
  void writeBigDecimal(BigDecimal paramBigDecimal, int paramInt1, int paramInt2) throws SQLServerException {
    boolean bool = (paramBigDecimal.signum() < 0) ? true : false;
    BigInteger bigInteger = paramBigDecimal.unscaledValue();
    if (bool)
      bigInteger = bigInteger.negate(); 
    if (9 >= paramInt2) {
      
      writeByte((byte)5);
      writeByte((byte)(bool ? 0 : 1));
      writeInt(bigInteger.intValue());
    }
    else if (19 >= paramInt2) {
      
      writeByte((byte)9);
      writeByte((byte)(bool ? 0 : 1));
      writeLong(bigInteger.longValue());
    } else {
      byte b1;

      
      if (28 >= paramInt2) {
        b1 = 12;
      } else {
        b1 = 16;
      }  writeByte((byte)(b1 + 1));
      writeByte((byte)(bool ? 0 : 1));


      
      byte[] arrayOfByte1 = bigInteger.toByteArray();
      
      if (arrayOfByte1.length > b1) {

        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
        Object[] arrayOfObject = { JDBCType.of(paramInt1) };
        throw new SQLServerException(messageFormat.format(arrayOfObject), SQLState.DATA_EXCEPTION_LENGTH_MISMATCH, DriverError.NOT_SET, null);
      } 





      
      byte[] arrayOfByte2 = new byte[b1];


      
      int i = b1 - arrayOfByte1.length;
      
      byte b2;
      int j;
      for (b2 = 0, j = arrayOfByte1.length - 1; b2 < arrayOfByte1.length;) {
        arrayOfByte2[b2++] = arrayOfByte1[j--];
      }
      
      for (; b2 < i; b2++)
        arrayOfByte2[b2] = 0; 
      writeBytes(arrayOfByte2);
    } 
  }

  
  void writeSmalldatetime(String paramString) throws SQLServerException {
    GregorianCalendar gregorianCalendar = initializeCalender(TimeZone.getDefault());
    long l = 0L;
    Timestamp timestamp = Timestamp.valueOf(paramString);
    l = timestamp.getTime();

    
    gregorianCalendar.setTimeInMillis(l);

    
    int i = DDC.daysSinceBaseDate(gregorianCalendar.get(1), gregorianCalendar.get(6), 1900);





    
    int j = 1000 * gregorianCalendar.get(13) + 60000 * gregorianCalendar.get(12) + 3600000 * gregorianCalendar.get(11);





    
    if (86399999 <= j) {
      
      i++;
      j = 0;
    } 

    
    writeShort((short)i);
    
    int k = j / 1000;
    int m = k / 60;

    
    m = ((k % 60) > 29.998D) ? (m + 1) : m;

    
    writeShort((short)m);
  }

  
  void writeDatetime(String paramString) throws SQLServerException {
    GregorianCalendar gregorianCalendar = initializeCalender(TimeZone.getDefault());
    long l = 0L;
    int i = 0;
    Timestamp timestamp = Timestamp.valueOf(paramString);
    l = timestamp.getTime();
    i = timestamp.getNanos();

    
    gregorianCalendar.setTimeInMillis(l);


    
    int j = DDC.daysSinceBaseDate(gregorianCalendar.get(1), gregorianCalendar.get(6), 1900);





    
    int k = (i + 500000) / 1000000 + 1000 * gregorianCalendar.get(13) + 60000 * gregorianCalendar.get(12) + 3600000 * gregorianCalendar.get(11);






    
    if (86399999 <= k) {
      
      j++;
      k = 0;
    } 






    
    if (j < DDC.daysSinceBaseDate(1753, 1, 1900) || j >= DDC.daysSinceBaseDate(10000, 1, 1900)) {

      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
      Object[] arrayOfObject = { SSType.DATETIME };
      throw new SQLServerException(messageFormat.format(arrayOfObject), SQLState.DATA_EXCEPTION_DATETIME_FIELD_OVERFLOW, DriverError.NOT_SET, null);
    } 





    
    writeInt(j);

    
    writeInt((3 * k + 5) / 10);
  }

  
  void writeDate(String paramString) throws SQLServerException {
    GregorianCalendar gregorianCalendar = initializeCalender(TimeZone.getDefault());
    long l = 0L;
    Date date = Date.valueOf(paramString);
    l = date.getTime();

    
    gregorianCalendar.setTimeInMillis(l);
    
    writeScaledTemporal(gregorianCalendar, 0, 0, SSType.DATE);
  }





  
  void writeTime(Timestamp paramTimestamp, int paramInt) throws SQLServerException {
    GregorianCalendar gregorianCalendar = initializeCalender(TimeZone.getDefault());
    long l = 0L;
    int i = 0;
    l = paramTimestamp.getTime();
    i = paramTimestamp.getNanos();

    
    gregorianCalendar.setTimeInMillis(l);
    
    writeScaledTemporal(gregorianCalendar, i, paramInt, SSType.TIME);
  }





  
  void writeDateTimeOffset(Object paramObject, int paramInt, SSType paramSSType) throws SQLServerException {
    GregorianCalendar gregorianCalendar = null;
    TimeZone timeZone = TimeZone.getDefault();
    long l = 0L;
    int i = 0;
    int j = 0;
    
    DateTimeOffset dateTimeOffset = (DateTimeOffset)paramObject;
    l = dateTimeOffset.getTimestamp().getTime();
    i = dateTimeOffset.getTimestamp().getNanos();
    j = dateTimeOffset.getMinutesOffset();





    
    timeZone = (SSType.DATETIMEOFFSET == paramSSType) ? UTC.timeZone : new SimpleTimeZone(j * 60 * 1000, "");

    
    gregorianCalendar = new GregorianCalendar(timeZone, Locale.US);
    gregorianCalendar.setLenient(true);
    gregorianCalendar.clear();
    gregorianCalendar.setTimeInMillis(l);
    
    writeScaledTemporal(gregorianCalendar, i, paramInt, SSType.DATETIMEOFFSET);




    
    writeShort((short)j);
  }

  
  void writeOffsetDateTimeWithTimezone(OffsetDateTime paramOffsetDateTime, int paramInt) throws SQLServerException {
    GregorianCalendar gregorianCalendar = null;
    
    long l = 0L;
    int i = 0;
    int j = 0;




    
    try {
      j = paramOffsetDateTime.getOffset().getTotalSeconds() / 60;
    }
    catch (Exception exception) {
      
      throw new SQLServerException(SQLServerException.getErrString("R_zoneOffsetError"), null, 0, null);
    } 



    
    i = paramOffsetDateTime.getNano();



    
    int k = 9 - String.valueOf(i).length();
    while (k > 0) {
      
      i *= 10;
      k--;
    } 

    
    TimeZone timeZone = UTC.timeZone;


    
    String str = String.format("%04d", new Object[] { Integer.valueOf(paramOffsetDateTime.getYear()) }) + '-' + paramOffsetDateTime.getMonthValue() + '-' + paramOffsetDateTime.getDayOfMonth() + ' ' + paramOffsetDateTime.getHour() + ':' + paramOffsetDateTime.getMinute() + ':' + paramOffsetDateTime.getSecond();




    
    l = Timestamp.valueOf(str).getTime();
    gregorianCalendar = initializeCalender(timeZone);
    gregorianCalendar.setTimeInMillis(l);

    
    int m = TimeZone.getDefault().getRawOffset() / 60000;
    
    if (TimeZone.getDefault().inDaylightTime(gregorianCalendar.getTime())) {
      m += TimeZone.getDefault().getDSTSavings() / 60000;
    }
    m += (m < 0) ? (j * -1) : j;
    gregorianCalendar.add(12, m);
    
    writeScaledTemporal(gregorianCalendar, i, paramInt, SSType.DATETIMEOFFSET);



    
    writeShort((short)j);
  }

  
  void writeOffsetTimeWithTimezone(OffsetTime paramOffsetTime, int paramInt) throws SQLServerException {
    GregorianCalendar gregorianCalendar = null;
    
    long l = 0L;
    int i = 0;
    int j = 0;




    
    try {
      j = paramOffsetTime.getOffset().getTotalSeconds() / 60;
    }
    catch (Exception exception) {
      
      throw new SQLServerException(SQLServerException.getErrString("R_zoneOffsetError"), null, 0, null);
    } 



    
    i = paramOffsetTime.getNano();



    
    int k = 9 - String.valueOf(i).length();
    while (k > 0) {
      
      i *= 10;
      k--;
    } 

    
    TimeZone timeZone = UTC.timeZone;




    
    String str = "1900-01-01 " + paramOffsetTime.getHour() + ':' + paramOffsetTime.getMinute() + ':' + paramOffsetTime.getSecond();


    
    l = Timestamp.valueOf(str).getTime();
    
    gregorianCalendar = initializeCalender(timeZone);
    gregorianCalendar.setTimeInMillis(l);
    
    int m = TimeZone.getDefault().getRawOffset() / 60000;
    
    if (TimeZone.getDefault().inDaylightTime(gregorianCalendar.getTime())) {
      m += TimeZone.getDefault().getDSTSavings() / 60000;
    }
    m += (m < 0) ? (j * -1) : j;
    gregorianCalendar.add(12, m);
    
    writeScaledTemporal(gregorianCalendar, i, paramInt, SSType.DATETIMEOFFSET);



    
    writeShort((short)j);
  }

  
  void writeLong(long paramLong) throws SQLServerException {
    if (this.stagingBuffer.remaining() >= 8) {
      
      this.stagingBuffer.putLong(paramLong);
      if (this.tdsChannel.isLoggingPackets())
      {
        if (this.dataIsLoggable) {
          this.logBuffer.putLong(paramLong);
        } else {
          this.logBuffer.position(this.logBuffer.position() + 8);
        } 
      }
    } else {
      
      this.valueBytes[0] = (byte)(int)(paramLong >> 0L & 0xFFL);
      this.valueBytes[1] = (byte)(int)(paramLong >> 8L & 0xFFL);
      this.valueBytes[2] = (byte)(int)(paramLong >> 16L & 0xFFL);
      this.valueBytes[3] = (byte)(int)(paramLong >> 24L & 0xFFL);
      this.valueBytes[4] = (byte)(int)(paramLong >> 32L & 0xFFL);
      this.valueBytes[5] = (byte)(int)(paramLong >> 40L & 0xFFL);
      this.valueBytes[6] = (byte)(int)(paramLong >> 48L & 0xFFL);
      this.valueBytes[7] = (byte)(int)(paramLong >> 56L & 0xFFL);
      writeWrappedBytes(this.valueBytes, 8);
    } 
  }

  
  void writeBytes(byte[] paramArrayOfbyte) throws SQLServerException {
    writeBytes(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }

  
  void writeBytes(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLServerException {
    assert paramInt2 <= paramArrayOfbyte.length;
    
    int i = 0;

    
    if (logger.isLoggable(Level.FINEST))
      logger.finest(toString() + " Writing " + paramInt2 + " bytes"); 
    int j;
    while ((j = paramInt2 - i) > 0) {
      
      if (0 == this.stagingBuffer.remaining()) {
        writePacket(0);
      }
      if (j > this.stagingBuffer.remaining()) {
        j = this.stagingBuffer.remaining();
      }
      this.stagingBuffer.put(paramArrayOfbyte, paramInt1 + i, j);
      if (this.tdsChannel.isLoggingPackets())
      {
        if (this.dataIsLoggable) {
          this.logBuffer.put(paramArrayOfbyte, paramInt1 + i, j);
        } else {
          this.logBuffer.position(this.logBuffer.position() + j);
        } 
      }
      i += j;
    } 
  }




  
  void writeWrappedBytes(byte[] paramArrayOfbyte, int paramInt) throws SQLServerException {
    assert paramInt <= paramArrayOfbyte.length;
    assert this.stagingBuffer.remaining() < paramInt;
    assert paramInt <= this.stagingBuffer.capacity();

    
    int i = this.stagingBuffer.remaining();
    if (i > 0) {
      
      this.stagingBuffer.put(paramArrayOfbyte, 0, i);
      if (this.tdsChannel.isLoggingPackets())
      {
        if (this.dataIsLoggable) {
          this.logBuffer.put(paramArrayOfbyte, 0, i);
        } else {
          this.logBuffer.position(this.logBuffer.position() + i);
        } 
      }
    } 
    writePacket(0);


    
    this.stagingBuffer.put(paramArrayOfbyte, i, paramInt - i);
    if (this.tdsChannel.isLoggingPackets())
    {
      if (this.dataIsLoggable) {
        this.logBuffer.put(paramArrayOfbyte, i, paramInt - i);
      } else {
        this.logBuffer.position(this.logBuffer.position() + i);
      } 
    }
  }
  
  void writeString(String paramString) throws SQLServerException {
    byte b = 0;
    int i = paramString.length();
    while (b < i) {
      
      int j = 2 * (i - b);
      
      if (j > this.valueBytes.length) {
        j = this.valueBytes.length;
      }
      byte b1 = 0;
      while (b1 < j) {
        
        char c = paramString.charAt(b++);
        this.valueBytes[b1++] = (byte)(c >> 0 & 0xFF);
        this.valueBytes[b1++] = (byte)(c >> 8 & 0xFF);
      } 
      
      writeBytes(this.valueBytes, 0, b1);
    } 
  }



  
  void writeStream(InputStream paramInputStream, long paramLong, boolean paramBoolean) throws SQLServerException {
    int j;
    assert -1L == paramLong || paramLong >= 0L;
    
    long l = 0L;
    byte[] arrayOfByte = new byte[4 * this.currentPacketSize];
    int i = 0;


    
    do {
      for (j = 0; -1 != i && j < arrayOfByte.length; j += i) {

        
        try {
          i = paramInputStream.read(arrayOfByte, j, arrayOfByte.length - j);
        }
        catch (IOException iOException) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
          Object[] arrayOfObject = { iOException.toString() };
          error(messageFormat.format(arrayOfObject), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET);
        } 
        
        if (-1 == i) {
          break;
        }
        
        if (i < 0 || i > arrayOfByte.length - j) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
          Object[] arrayOfObject = { SQLServerException.getErrString("R_streamReadReturnedInvalidValue") };
          error(messageFormat.format(arrayOfObject), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET);
        } 
      } 

      
      if (paramBoolean) {
        writeInt(j);
      }
      writeBytes(arrayOfByte, 0, j);
      l += j;
    }
    while (-1 != i || j > 0);


    
    if (-1L != paramLong && l != paramLong) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_mismatchedStreamLength"));
      Object[] arrayOfObject = { Long.valueOf(paramLong), Long.valueOf(l) };
      error(messageFormat.format(arrayOfObject), SQLState.DATA_EXCEPTION_LENGTH_MISMATCH, DriverError.NOT_SET);
    } 
  }











  
  void writeNonUnicodeReader(Reader paramReader, long paramLong, boolean paramBoolean, String paramString) throws SQLServerException {
    int j;
    assert -1L == paramLong || paramLong >= 0L;
    
    long l = 0L;
    char[] arrayOfChar = new char[this.currentPacketSize];
    
    byte[] arrayOfByte = new byte[this.currentPacketSize];
    int i = 0;





    
    do {
      for (j = 0; -1 != i && j < arrayOfChar.length; j += i) {

        
        try {
          i = paramReader.read(arrayOfChar, j, arrayOfChar.length - j);
        }
        catch (IOException iOException) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
          Object[] arrayOfObject = { iOException.toString() };
          error(messageFormat.format(arrayOfObject), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET);
        } 
        
        if (-1 == i) {
          break;
        }
        
        if (i < 0 || i > arrayOfChar.length - j) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
          Object[] arrayOfObject = { SQLServerException.getErrString("R_streamReadReturnedInvalidValue") };
          error(messageFormat.format(arrayOfObject), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET);
        } 
      } 
      
      if (!paramBoolean) {




        
        writeInt(j);
        
        for (byte b = 0; b < j; b++) {

          
          try {
            if (null == paramString)
            {
              arrayOfByte[b] = (byte)(arrayOfChar[b] & 0xFF);
            
            }
            else
            {
              arrayOfByte[b] = (new String(arrayOfChar[b] + "")).getBytes(paramString)[0];
            
            }
          
          }
          catch (UnsupportedEncodingException unsupportedEncodingException) {
            
            throw new SQLServerException(SQLServerException.getErrString("R_encodingErrorWritingTDS"), unsupportedEncodingException);
          } 
        } 

        
        writeBytes(arrayOfByte, 0, j);
      }
      else {
        
        int k = j;
        if (0 != j) {
          k = j / 2;
        }
        String str = new String(arrayOfChar);
        byte[] arrayOfByte1 = ParameterUtils.HexToBin(str.trim());
        writeInt(k);
        writeBytes(arrayOfByte1, 0, k);
      } 
      l += j;
    }
    while (-1 != i || j > 0);


    
    if (-1L != paramLong && l != paramLong) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_mismatchedStreamLength"));
      Object[] arrayOfObject = { Long.valueOf(paramLong), Long.valueOf(l) };
      error(messageFormat.format(arrayOfObject), SQLState.DATA_EXCEPTION_LENGTH_MISMATCH, DriverError.NOT_SET);
    } 
  }








  
  void writeReader(Reader paramReader, long paramLong, boolean paramBoolean) throws SQLServerException {
    int j;
    assert -1L == paramLong || paramLong >= 0L;
    
    long l = 0L;
    char[] arrayOfChar = new char[2 * this.currentPacketSize];
    byte[] arrayOfByte = new byte[4 * this.currentPacketSize];
    int i = 0;


    
    do {
      for (j = 0; -1 != i && j < arrayOfChar.length; j += i) {

        
        try {
          i = paramReader.read(arrayOfChar, j, arrayOfChar.length - j);
        }
        catch (IOException iOException) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
          Object[] arrayOfObject = { iOException.toString() };
          error(messageFormat.format(arrayOfObject), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET);
        } 
        
        if (-1 == i) {
          break;
        }
        
        if (i < 0 || i > arrayOfChar.length - j) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
          Object[] arrayOfObject = { SQLServerException.getErrString("R_streamReadReturnedInvalidValue") };
          error(messageFormat.format(arrayOfObject), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET);
        } 
      } 

      
      if (paramBoolean) {
        writeInt(2 * j);
      }




      
      for (byte b = 0; b < j; b++) {
        
        arrayOfByte[2 * b] = (byte)(arrayOfChar[b] >> 0 & 0xFF);
        arrayOfByte[2 * b + 1] = (byte)(arrayOfChar[b] >> 8 & 0xFF);
      } 
      
      writeBytes(arrayOfByte, 0, 2 * j);
      l += j;
    }
    while (-1 != i || j > 0);


    
    if (-1L != paramLong && l != paramLong) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_mismatchedStreamLength"));
      Object[] arrayOfObject = { Long.valueOf(paramLong), Long.valueOf(l) };
      error(messageFormat.format(arrayOfObject), SQLState.DATA_EXCEPTION_LENGTH_MISMATCH, DriverError.NOT_SET);
    } 
  }

  
  GregorianCalendar initializeCalender(TimeZone paramTimeZone) {
    GregorianCalendar gregorianCalendar = null;


    
    gregorianCalendar = new GregorianCalendar(paramTimeZone, Locale.US);


    
    gregorianCalendar.setLenient(true);


    
    gregorianCalendar.clear();
    
    return gregorianCalendar;
  }

  
  final void error(String paramString, SQLState paramSQLState, DriverError paramDriverError) throws SQLServerException {
    assert null != this.command;
    this.command.interrupt(paramString);
    throw new SQLServerException(paramString, paramSQLState, paramDriverError, null);
  }















  
  final boolean sendAttention() throws SQLServerException {
    if (this.packetNum > 0) {







      
      if (logger.isLoggable(Level.FINE)) {
        logger.fine(this + ": sending attention...");
      }
      this.tdsChannel.numMsgsSent++;
      
      startMessage(this.command, (byte)6);
      endMessage();
      
      return true;
    } 
    
    return false;
  }

  
  private final void writePacket(int paramInt) throws SQLServerException {
    boolean bool1 = (1 == (0x1 & paramInt)) ? true : false;
    boolean bool2 = (6 == this.tdsMessageType || (paramInt & 0x2) == 2) ? true : false;



    
    if (null != this.command && !bool2) {
      this.command.checkForInterrupt();
    }
    writePacketHeader(paramInt | this.sendResetConnection);
    this.sendResetConnection = 0;
    
    flush(bool1);





    
    if (bool1) {
      
      flush(bool1);
      this.isEOMSent = true;
      this.tdsChannel.numMsgsSent++;
    } 


    
    if (16 == this.tdsMessageType && 1 == this.packetNum && 0 == this.con.getNegotiatedEncryptionLevel())
    {

      
      this.tdsChannel.disableSSL();
    }


    
    if (null != this.command && !bool2 && bool1) {
      this.command.onRequestComplete();
    }
  }
  
  private final void writePacketHeader(int paramInt) {
    int i = this.stagingBuffer.position();
    this.packetNum++;

    
    this.stagingBuffer.put(0, this.tdsMessageType);
    this.stagingBuffer.put(1, (byte)paramInt);
    this.stagingBuffer.put(2, (byte)(i >> 8 & 0xFF));
    this.stagingBuffer.put(3, (byte)(i >> 0 & 0xFF));
    this.stagingBuffer.put(4, (byte)(this.tdsChannel.getSPID() >> 8 & 0xFF));
    this.stagingBuffer.put(5, (byte)(this.tdsChannel.getSPID() >> 0 & 0xFF));
    this.stagingBuffer.put(6, (byte)(this.packetNum % 256));
    this.stagingBuffer.put(7, (byte)0);

    
    if (this.tdsChannel.isLoggingPackets()) {
      
      this.logBuffer.put(0, this.tdsMessageType);
      this.logBuffer.put(1, (byte)paramInt);
      this.logBuffer.put(2, (byte)(i >> 8 & 0xFF));
      this.logBuffer.put(3, (byte)(i >> 0 & 0xFF));
      this.logBuffer.put(4, (byte)(this.tdsChannel.getSPID() >> 8 & 0xFF));
      this.logBuffer.put(5, (byte)(this.tdsChannel.getSPID() >> 0 & 0xFF));
      this.logBuffer.put(6, (byte)(this.packetNum % 256));
      this.logBuffer.put(7, (byte)0);
    } 
  }


  
  void flush(boolean paramBoolean) throws SQLServerException {
    this.tdsChannel.write(this.socketBuffer.array(), this.socketBuffer.position(), this.socketBuffer.remaining());
    this.socketBuffer.position(this.socketBuffer.limit());



    
    if (this.stagingBuffer.position() >= 8) {

      
      ByteBuffer byteBuffer = this.stagingBuffer;
      this.stagingBuffer = this.socketBuffer;
      this.socketBuffer = byteBuffer;






      
      this.socketBuffer.flip();
      this.stagingBuffer.clear();


      
      if (this.tdsChannel.isLoggingPackets())
      {
        this.tdsChannel.logPacket(this.logBuffer.array(), 0, this.socketBuffer.limit(), toString() + " sending packet (" + this.socketBuffer.limit() + " bytes)");
      }





      
      if (!paramBoolean) {
        preparePacket();
      }
      
      this.tdsChannel.write(this.socketBuffer.array(), this.socketBuffer.position(), this.socketBuffer.remaining());
      this.socketBuffer.position(this.socketBuffer.limit());
    } 
  }










  
  void writeRPCNameValType(String paramString, boolean paramBoolean, TDSType paramTDSType) throws SQLServerException {
    int i = 0;
    
    if (null != paramString) {
      i = paramString.length() + 1;
    }
    writeByte((byte)i);
    if (i > 0) {
      
      writeChar('@');
      writeString(paramString);
    } 
    
    if (null != this.cryptoMeta) {
      writeByte((byte)(paramBoolean ? 9 : 8));
    } else {
      writeByte((byte)(paramBoolean ? 1 : 0));
    }  writeByte(paramTDSType.byteValue());
  }







  
  void writeRPCBit(String paramString, Boolean paramBoolean, boolean paramBoolean1) throws SQLServerException {
    writeRPCNameValType(paramString, paramBoolean1, TDSType.BITN);
    writeByte((byte)1);
    if (null == paramBoolean) {
      
      writeByte((byte)0);
    }
    else {
      
      writeByte((byte)1);
      writeByte((byte)(paramBoolean.booleanValue() ? 1 : 0));
    } 
  }







  
  void writeRPCByte(String paramString, Byte paramByte, boolean paramBoolean) throws SQLServerException {
    writeRPCNameValType(paramString, paramBoolean, TDSType.INTN);
    writeByte((byte)1);
    if (null == paramByte) {
      
      writeByte((byte)0);
    }
    else {
      
      writeByte((byte)1);
      writeByte(paramByte.byteValue());
    } 
  }







  
  void writeRPCShort(String paramString, Short paramShort, boolean paramBoolean) throws SQLServerException {
    writeRPCNameValType(paramString, paramBoolean, TDSType.INTN);
    writeByte((byte)2);
    if (null == paramShort) {
      
      writeByte((byte)0);
    }
    else {
      
      writeByte((byte)2);
      writeShort(paramShort.shortValue());
    } 
  }







  
  void writeRPCInt(String paramString, Integer paramInteger, boolean paramBoolean) throws SQLServerException {
    writeRPCNameValType(paramString, paramBoolean, TDSType.INTN);
    writeByte((byte)4);
    if (null == paramInteger) {
      
      writeByte((byte)0);
    }
    else {
      
      writeByte((byte)4);
      writeInt(paramInteger.intValue());
    } 
  }







  
  void writeRPCLong(String paramString, Long paramLong, boolean paramBoolean) throws SQLServerException {
    writeRPCNameValType(paramString, paramBoolean, TDSType.INTN);
    writeByte((byte)8);
    if (null == paramLong) {
      
      writeByte((byte)0);
    }
    else {
      
      writeByte((byte)8);
      writeLong(paramLong.longValue());
    } 
  }








  
  void writeRPCReal(String paramString, Float paramFloat, boolean paramBoolean) throws SQLServerException {
    writeRPCNameValType(paramString, paramBoolean, TDSType.FLOATN);

    
    if (null == paramFloat) {
      
      writeByte((byte)4);
      writeByte((byte)0);
    }
    else {
      
      writeByte((byte)4);
      writeByte((byte)4);
      writeInt(Float.floatToRawIntBits(paramFloat.floatValue()));
    } 
  }







  
  void writeRPCDouble(String paramString, Double paramDouble, boolean paramBoolean) throws SQLServerException {
    writeRPCNameValType(paramString, paramBoolean, TDSType.FLOATN);
    
    byte b = 8;
    writeByte((byte)b);

    
    if (null == paramDouble) {
      
      writeByte((byte)0);
    }
    else {
      
      writeByte((byte)b);
      long l1 = Double.doubleToLongBits(paramDouble.doubleValue());
      long l2 = 255L;
      boolean bool = false;
      for (byte b1 = 0; b1 < 8; b1++) {
        
        writeByte((byte)(int)((l1 & l2) >> bool));
        bool += true;
        l2 <<= 8L;
      } 
    } 
  }








  
  void writeRPCBigDecimal(String paramString, BigDecimal paramBigDecimal, int paramInt, boolean paramBoolean) throws SQLServerException {
    writeRPCNameValType(paramString, paramBoolean, TDSType.DECIMALN);
    writeByte((byte)17);
    writeByte((byte)38);
    
    byte[] arrayOfByte = DDC.convertBigDecimalToBytes(paramBigDecimal, paramInt);
    writeBytes(arrayOfByte, 0, arrayOfByte.length);
  }








  
  void writeVMaxHeader(long paramLong, boolean paramBoolean, SQLCollation paramSQLCollation) throws SQLServerException {
    writeShort((short)-1);

    
    if (null != paramSQLCollation) {
      paramSQLCollation.writeCollation(this);
    }
    
    if (paramBoolean) {

      
      writeLong(-1L);
    }
    else if (-1L == paramLong) {


      
      writeLong(-2L);

    
    }
    else {


      
      writeLong(paramLong);
    } 
  }




  
  void writeRPCStringUnicode(String paramString) throws SQLServerException {
    writeRPCStringUnicode(null, paramString, false, null);
  }












  
  void writeRPCStringUnicode(String paramString1, String paramString2, boolean paramBoolean, SQLCollation paramSQLCollation) throws SQLServerException {
    boolean bool1 = (paramString2 == null) ? true : false;
    byte b = bool1 ? 0 : (2 * paramString2.length());
    boolean bool2 = (b <= 'ὀ') ? true : false;


    
    if (null == paramSQLCollation) {
      paramSQLCollation = this.con.getDatabaseCollation();
    }
    
    boolean bool3 = (!bool2 || paramBoolean) ? true : false;
    if (bool3) {
      
      writeRPCNameValType(paramString1, paramBoolean, TDSType.NVARCHAR);

      
      writeVMaxHeader(b, bool1, paramSQLCollation);




      
      if (!bool1)
      {
        if (b > 0) {
          
          writeInt(b);
          writeString(paramString2);
        } 

        
        writeInt(0);
      }
    
    }
    else {
      
      if (bool2) {
        
        writeRPCNameValType(paramString1, paramBoolean, TDSType.NVARCHAR);
        writeShort((short)8000);
      }
      else {
        
        writeRPCNameValType(paramString1, paramBoolean, TDSType.NTEXT);
        writeInt(2147483647);
      } 
      
      paramSQLCollation.writeCollation(this);

      
      if (bool1) {
        
        writeShort((short)-1);
      
      }
      else {
        
        if (bool2) {
          writeShort((short)b);
        } else {
          writeInt(b);
        } 
        
        if (0 != b) {
          writeString(paramString2);
        }
      } 
    } 
  }

  
  void writeTVP(TVP paramTVP) throws SQLServerException {
    if (!paramTVP.isNull()) {
      
      writeByte((byte)0);
    
    }
    else {
      
      writeByte((byte)2);
    } 
    
    writeByte((byte)-13);






    
    if (null != paramTVP.getDbNameTVP()) {
      
      writeByte((byte)paramTVP.getDbNameTVP().length());
      writeString(paramTVP.getDbNameTVP());
    } else {
      
      writeByte((byte)0);
    } 
    
    if (null != paramTVP.getOwningSchemaNameTVP()) {
      
      writeByte((byte)paramTVP.getOwningSchemaNameTVP().length());
      writeString(paramTVP.getOwningSchemaNameTVP());
    } else {
      
      writeByte((byte)0);
    } 
    
    if (null != paramTVP.getTVPName()) {
      
      writeByte((byte)paramTVP.getTVPName().length());
      writeString(paramTVP.getTVPName());
    } else {
      
      writeByte((byte)0);
    } 
    
    if (!paramTVP.isNull()) {
      
      writeTVPColumnMetaData(paramTVP);

      
      writeTvpOrderUnique(paramTVP);
    }
    else {
      
      writeShort((short)-1);
    } 

    
    writeByte((byte)0);

    
    try {
      writeTVPRows(paramTVP);
    }
    catch (NumberFormatException numberFormatException) {
      
      throw new SQLServerException(SQLServerException.getErrString("R_TVPInvalidColumnValue"), numberFormatException);
    }
    catch (ClassCastException classCastException) {
      
      throw new SQLServerException(SQLServerException.getErrString("R_TVPInvalidColumnValue"), classCastException);
    } 
  }




  
  void writeTVPRows(TVP paramTVP) throws SQLServerException {
    if (!paramTVP.isNull()) {
      
      Map<Integer, SQLServerMetaData> map = paramTVP.getColumnMetadata();



      
      while (paramTVP.next()) {
        
        Object[] arrayOfObject = paramTVP.getRowData();

        
        writeByte((byte)1);
        Iterator<Map.Entry> iterator = map.entrySet().iterator();
        byte b = 0;
        while (iterator.hasNext()) {
          boolean bool1, bool2, bool3; BigDecimal bigDecimal; long l1; byte[] arrayOfByte1, arrayOfByte2; long l2; boolean bool4; byte b1;
          Map.Entry entry = iterator.next();

          
          if (((SQLServerMetaData)entry.getValue()).useServerDefault) {
            
            b++;
            
            continue;
          } 
          JDBCType jDBCType = JDBCType.of(((SQLServerMetaData)entry.getValue()).javaSqlType);
          String str = null;

          
          Object object = null;
          if (null != arrayOfObject)
          {
            
            if (arrayOfObject.length > b) {
              
              object = arrayOfObject[b];
              if (null != object)
              {
                str = String.valueOf(object);
              }
            } 
          }
          switch (jDBCType) {
            
            case BIGINT:
              if (null == str) {
                writeByte((byte)0);
                break;
              } 
              writeByte((byte)8);
              writeLong(Long.valueOf(str).longValue());
              break;

            
            case BIT:
              if (null == str) {
                writeByte((byte)0);
                break;
              } 
              writeByte((byte)1);
              writeByte((byte)(Boolean.valueOf(str).booleanValue() ? 1 : 0));
              break;

            
            case INTEGER:
              if (null == str) {
                writeByte((byte)0);
                break;
              } 
              writeByte((byte)4);
              writeInt(Integer.valueOf(str).intValue());
              break;

            
            case SMALLINT:
            case TINYINT:
              if (null == str) {
                writeByte((byte)0);
                break;
              } 
              writeByte((byte)2);
              writeShort(Short.valueOf(str).shortValue());
              break;

            
            case DECIMAL:
            case NUMERIC:
              if (null == str) {
                writeByte((byte)0);
                
                break;
              } 
              writeByte((byte)17);
              bigDecimal = new BigDecimal(str);



              
              bigDecimal = bigDecimal.setScale(((SQLServerMetaData)entry.getValue()).scale, RoundingMode.HALF_UP);
              arrayOfByte1 = DDC.convertBigDecimalToBytes(bigDecimal, bigDecimal.scale());

              
              arrayOfByte2 = new byte[17];

              
              System.arraycopy(arrayOfByte1, 2, arrayOfByte2, 0, arrayOfByte1.length - 2);
              writeBytes(arrayOfByte2);
              break;

            
            case DOUBLE:
              if (null == str) {
                writeByte((byte)0);
                break;
              } 
              writeByte((byte)8);
              l1 = Double.doubleToLongBits(Double.valueOf(str).doubleValue());
              l2 = 255L;
              bool4 = false;
              for (b1 = 0; b1 < 8; b1++) {
                
                writeByte((byte)(int)((l1 & l2) >> bool4));
                bool4 += true;
                l2 <<= 8L;
              } 
              break;

            
            case FLOAT:
            case REAL:
              if (null == str) {
                writeByte((byte)0);
                break;
              } 
              writeByte((byte)4);
              writeInt(Float.floatToRawIntBits(Float.valueOf(str).floatValue()));
              break;

            
            case DATE:
            case TIME:
            case TIMESTAMP:
            case DATETIMEOFFSET:
            case TIMESTAMP_WITH_TIMEZONE:
            case TIME_WITH_TIMEZONE:
            case CHAR:
            case VARCHAR:
            case NCHAR:
            case NVARCHAR:
              bool1 = (2 * ((SQLServerMetaData)entry.getValue()).precision <= 8000) ? true : false;
              bool2 = (null == str) ? true : false;
              bool3 = bool2 ? false : (str.length() * 2);
              if (!bool1) {

                
                if (bool2) {
                  
                  writeLong(-1L);
                } else if (-1 == bool3) {

                  
                  writeLong(-2L);
                } else {
                  
                  writeLong(bool3);
                }  if (!bool2) {
                  
                  if (bool3) {
                    
                    writeInt(bool3);
                    writeString(str);
                  } 
                  
                  writeInt(0);
                } 
                
                break;
              } 
              if (bool2) {
                writeShort((short)-1);
                break;
              } 
              writeShort((short)bool3);
              writeString(str);
              break;



            
            case BINARY:
            case VARBINARY:
              bool1 = (((SQLServerMetaData)entry.getValue()).precision <= 8000) ? true : false;
              bool2 = (null == object) ? true : false;
              if (object instanceof String) {
                bool3 = bool2 ? false : (toByteArray(object.toString())).length;
              } else {
                bool3 = bool2 ? false : ((byte[])object).length;
              }  if (!bool1) {

                
                if (bool2) {
                  
                  writeLong(-1L);
                } else if (-1 == bool3) {

                  
                  writeLong(-2L);
                } else {
                  
                  writeLong(bool3);
                }  if (!bool2) {
                  
                  if (bool3) {
                    
                    writeInt(bool3);
                    if (object instanceof String) {
                      writeBytes(toByteArray(object.toString()));
                    } else {
                      writeBytes((byte[])object);
                    } 
                  } 
                  writeInt(0);
                } 
                
                break;
              } 
              if (bool2) {
                writeShort((short)-1);
                break;
              } 
              writeShort((short)bool3);
              if (object instanceof String) {
                writeBytes(toByteArray(object.toString())); break;
              } 
              writeBytes((byte[])object);
              break;


            
            default:
              assert false : "Unexpected JDBC type " + jDBCType.toString(); break;
          } 
          b++;
        } 
      } 
    } 
    
    writeByte((byte)0);
  }

  
  private static byte[] toByteArray(String paramString) {
    return DatatypeConverter.parseHexBinary(paramString);
  }




  
  void writeTVPColumnMetaData(TVP paramTVP) throws SQLServerException {
    writeShort((short)paramTVP.getTVPColumnCount());
    
    Map<Integer, SQLServerMetaData> map = paramTVP.getColumnMetadata();
    Iterator<Map.Entry> iterator = map.entrySet().iterator();






    
    while (iterator.hasNext()) {
      boolean bool;
      Map.Entry entry = iterator.next();
      JDBCType jDBCType = JDBCType.of(((SQLServerMetaData)entry.getValue()).javaSqlType);
      boolean bool1 = ((SQLServerMetaData)entry.getValue()).useServerDefault;

      
      writeInt(0);












      
      short s = 1;
      if (bool1)
      {
        s = (short)(s | 0x200);
      }
      writeShort(s);

      
      switch (jDBCType) {
        
        case BIGINT:
          writeByte(TDSType.INTN.byteValue());
          writeByte((byte)8);
          break;
        case BIT:
          writeByte(TDSType.BITN.byteValue());
          writeByte((byte)1);
          break;
        case INTEGER:
          writeByte(TDSType.INTN.byteValue());
          writeByte((byte)4);
          break;
        case SMALLINT:
        case TINYINT:
          writeByte(TDSType.INTN.byteValue());
          writeByte((byte)2);
          break;
        
        case DECIMAL:
        case NUMERIC:
          writeByte(TDSType.NUMERICN.byteValue());
          writeByte((byte)17);
          writeByte((byte)((SQLServerMetaData)entry.getValue()).precision);
          writeByte((byte)((SQLServerMetaData)entry.getValue()).scale);
          break;
        
        case DOUBLE:
          writeByte(TDSType.FLOATN.byteValue());
          writeByte((byte)8);
          break;
        
        case FLOAT:
        case REAL:
          writeByte(TDSType.FLOATN.byteValue());
          writeByte((byte)4);
          break;
        
        case DATE:
        case TIME:
        case TIMESTAMP:
        case DATETIMEOFFSET:
        case TIMESTAMP_WITH_TIMEZONE:
        case TIME_WITH_TIMEZONE:
        case CHAR:
        case VARCHAR:
        case NCHAR:
        case NVARCHAR:
          writeByte(TDSType.NVARCHAR.byteValue());
          bool = (2 * ((SQLServerMetaData)entry.getValue()).precision <= 8000) ? true : false;
          
          if (!bool) {

            
            writeShort((short)-1);
            this.con.getDatabaseCollation().writeCollation(this);
            
            break;
          } 
          writeShort((short)8000);
          this.con.getDatabaseCollation().writeCollation(this);
          break;



        
        case BINARY:
        case VARBINARY:
          writeByte(TDSType.BIGVARBINARY.byteValue());
          bool = (((SQLServerMetaData)entry.getValue()).precision <= 8000) ? true : false;
          
          if (!bool) {
            
            writeShort((short)-1); break;
          } 
          writeShort((short)8000);
          break;
        
        default:
          assert false : "Unexpected JDBC type " + jDBCType.toString();
          break;
      } 
      writeByte((byte)0);
    } 
  }








  
  void writeTvpOrderUnique(TVP paramTVP) throws SQLServerException {
    Map<Integer, SQLServerMetaData> map = paramTVP.getColumnMetadata();
    Iterator<Map.Entry> iterator = map.entrySet().iterator();
    LinkedList<TdsOrderUnique> linkedList = new LinkedList();
    
    while (iterator.hasNext()) {
      
      byte b = 0;
      Map.Entry entry = iterator.next();
      SQLServerMetaData sQLServerMetaData = (SQLServerMetaData)entry.getValue();
      
      if (SQLServerSortOrder.Ascending == sQLServerMetaData.sortOrder) {
        b = 1;
      } else if (SQLServerSortOrder.Descending == sQLServerMetaData.sortOrder) {
        b = 2;
      }  if (sQLServerMetaData.isUniqueKey) {
        b = (byte)(b | 0x4);
      }
      
      if (0 != b) {
        linkedList.add(new TdsOrderUnique(((Integer)entry.getKey()).intValue(), b));
      }
    } 
    
    if (!linkedList.isEmpty()) {
      
      writeByte((byte)16);
      writeShort((short)linkedList.size());
      for (TdsOrderUnique tdsOrderUnique : linkedList) {
        
        writeShort((short)(tdsOrderUnique.columnOrdinal + 1));
        writeByte(tdsOrderUnique.flags);
      } 
    } 
  }

  
  private class TdsOrderUnique
  {
    int columnOrdinal;
    byte flags;
    
    TdsOrderUnique(int param1Int, byte param1Byte) {
      this.columnOrdinal = param1Int;
      this.flags = param1Byte;
    }
  }

  
  void setCryptoMetaData(CryptoMetadata paramCryptoMetadata) {
    this.cryptoMeta = paramCryptoMetadata;
  }

  
  CryptoMetadata getCryptoMetaData() {
    return this.cryptoMeta;
  }

  
  void writeEncryptedRPCByteArray(byte[] paramArrayOfbyte) throws SQLServerException {
    boolean bool1 = (paramArrayOfbyte == null) ? true : false;
    long l = bool1 ? 0L : paramArrayOfbyte.length;
    boolean bool2 = (l <= 8000L) ? true : false;
    
    boolean bool3 = (!bool2 && l <= 2147483647L) ? true : false;

    
    if (bool2) {
      
      writeShort((short)8000);
    }
    else if (bool3) {
      writeShort((short)-1);
    }
    else {
      
      writeInt(2147483647);
    } 

    
    if (bool1) {
      
      writeShort((short)-1);
    }
    else {
      
      if (bool2) {
        
        writeShort((short)(int)l);
      }
      else if (bool3) {
        
        writeLong(l);
      }
      else {
        
        writeInt((int)l);
      } 

      
      if (0L != l) {
        if (bool3) {
          writeInt((int)l);
        }
        writeBytes(paramArrayOfbyte);
      } 
      
      if (bool3) {
        writeInt(0);
      }
    } 
  }

  
  void writeCryptoMetaData() throws SQLServerException {
    writeByte(this.cryptoMeta.cipherAlgorithmId);
    writeByte(this.cryptoMeta.encryptionType.getValue());
    writeInt(((EncryptionKeyInfo)this.cryptoMeta.cekTableEntry.getColumnEncryptionKeyValues().get(0)).databaseId);
    writeInt(((EncryptionKeyInfo)this.cryptoMeta.cekTableEntry.getColumnEncryptionKeyValues().get(0)).cekId);
    writeInt(((EncryptionKeyInfo)this.cryptoMeta.cekTableEntry.getColumnEncryptionKeyValues().get(0)).cekVersion);
    writeBytes(((EncryptionKeyInfo)this.cryptoMeta.cekTableEntry.getColumnEncryptionKeyValues().get(0)).cekMdVersion);
    writeByte(this.cryptoMeta.normalizationRuleVersion);
  }





  
  void writeRPCByteArray(String paramString, byte[] paramArrayOfbyte, boolean paramBoolean, JDBCType paramJDBCType, SQLCollation paramSQLCollation) throws SQLServerException {
    TDSType tDSType;
    boolean bool1 = (paramArrayOfbyte == null) ? true : false;
    byte b = bool1 ? 0 : paramArrayOfbyte.length;
    boolean bool2 = (b <= 'ὀ') ? true : false;

    
    boolean bool3 = (!bool2 || paramBoolean) ? true : false;


    
    if (null != this.cryptoMeta) {

      
      tDSType = (bool2 || bool3) ? TDSType.BIGVARBINARY : TDSType.IMAGE;
      paramSQLCollation = null;
    } else {
      
      switch (paramJDBCType) {




        
        default:
          tDSType = (bool2 || bool3) ? TDSType.BIGVARBINARY : TDSType.IMAGE;
          paramSQLCollation = null;
          break;
        
        case CHAR:
        case VARCHAR:
        case LONGVARCHAR:
        case CLOB:
          tDSType = (bool2 || bool3) ? TDSType.BIGVARCHAR : TDSType.TEXT;
          if (null == paramSQLCollation) {
            paramSQLCollation = this.con.getDatabaseCollation();
          }
          break;
        case NCHAR:
        case NVARCHAR:
        case LONGNVARCHAR:
        case NCLOB:
          tDSType = (bool2 || bool3) ? TDSType.NVARCHAR : TDSType.NTEXT;
          if (null == paramSQLCollation)
            paramSQLCollation = this.con.getDatabaseCollation(); 
          break;
      } 
    } 
    writeRPCNameValType(paramString, paramBoolean, tDSType);
    
    if (bool3) {

      
      writeVMaxHeader(b, bool1, paramSQLCollation);

      
      if (!bool1)
      {
        if (b > 0) {
          
          writeInt(b);
          writeBytes(paramArrayOfbyte);
        } 

        
        writeInt(0);
      }
    
    }
    else {
      
      if (bool2) {
        
        writeShort((short)8000);
      }
      else {
        
        writeInt(2147483647);
      } 
      
      if (null != paramSQLCollation) {
        paramSQLCollation.writeCollation(this);
      }
      
      if (bool1) {
        
        writeShort((short)-1);
      }
      else {
        
        if (bool2) {
          writeShort((short)b);
        } else {
          writeInt(b);
        } 
        
        if (0 != b) {
          writeBytes(paramArrayOfbyte);
        }
      } 
    } 
  }












  
  void writeRPCDateTime(String paramString, GregorianCalendar paramGregorianCalendar, int paramInt, boolean paramBoolean) throws SQLServerException {
    assert paramInt >= 0 && paramInt < 1000000000 : "Invalid subNanoSeconds value: " + paramInt;
    assert paramGregorianCalendar != null || (paramGregorianCalendar == null && paramInt == 0) : "Invalid subNanoSeconds value when calendar is null: " + paramInt;
    
    writeRPCNameValType(paramString, paramBoolean, TDSType.DATETIMEN);
    writeByte((byte)8);
    
    if (null == paramGregorianCalendar) {
      
      writeByte((byte)0);
      
      return;
    } 
    writeByte((byte)8);

















    
    int i = DDC.daysSinceBaseDate(paramGregorianCalendar.get(1), paramGregorianCalendar.get(6), 1900);





    
    int j = (paramInt + 500000) / 1000000 + 1000 * paramGregorianCalendar.get(13) + 60000 * paramGregorianCalendar.get(12) + 3600000 * paramGregorianCalendar.get(11);






    
    if (j >= 86399999) {
      
      i++;
      j = 0;
    } 






    
    if (i < DDC.daysSinceBaseDate(1753, 1, 1900) || i >= DDC.daysSinceBaseDate(10000, 1, 1900)) {

      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
      Object[] arrayOfObject = { SSType.DATETIME };
      throw new SQLServerException(messageFormat.format(arrayOfObject), SQLState.DATA_EXCEPTION_DATETIME_FIELD_OVERFLOW, DriverError.NOT_SET, null);
    } 







    
    writeInt(i);

    
    writeInt((3 * j + 5) / 10);
  }






  
  void writeRPCTime(String paramString, GregorianCalendar paramGregorianCalendar, int paramInt1, int paramInt2, boolean paramBoolean) throws SQLServerException {
    writeRPCNameValType(paramString, paramBoolean, TDSType.TIMEN);
    writeByte((byte)paramInt2);
    
    if (null == paramGregorianCalendar) {
      
      writeByte((byte)0);
      
      return;
    } 
    writeByte((byte)TDS.timeValueLength(paramInt2));
    writeScaledTemporal(paramGregorianCalendar, paramInt1, paramInt2, SSType.TIME);
  }








  
  void writeRPCDate(String paramString, GregorianCalendar paramGregorianCalendar, boolean paramBoolean) throws SQLServerException {
    writeRPCNameValType(paramString, paramBoolean, TDSType.DATEN);
    if (null == paramGregorianCalendar) {
      
      writeByte((byte)0);
      
      return;
    } 
    writeByte((byte)3);
    writeScaledTemporal(paramGregorianCalendar, 0, 0, SSType.DATE);
  }










  
  void writeEncryptedRPCTime(String paramString, GregorianCalendar paramGregorianCalendar, int paramInt1, int paramInt2, boolean paramBoolean) throws SQLServerException {
    if (this.con.getSendTimeAsDatetime())
    {
      throw new SQLServerException(SQLServerException.getErrString("R_sendTimeAsDateTimeForAE"), null);
    }
    writeRPCNameValType(paramString, paramBoolean, TDSType.BIGVARBINARY);
    
    if (null == paramGregorianCalendar) {
      writeEncryptedRPCByteArray(null);
    } else {
      writeEncryptedRPCByteArray(writeEncryptedScaledTemporal(paramGregorianCalendar, paramInt1, paramInt2, SSType.TIME, (short)0));
    } 





    
    writeByte(TDSType.TIMEN.byteValue());
    writeByte((byte)paramInt2);
    writeCryptoMetaData();
  }




  
  void writeEncryptedRPCDate(String paramString, GregorianCalendar paramGregorianCalendar, boolean paramBoolean) throws SQLServerException {
    writeRPCNameValType(paramString, paramBoolean, TDSType.BIGVARBINARY);
    
    if (null == paramGregorianCalendar) {
      writeEncryptedRPCByteArray(null);
    } else {
      writeEncryptedRPCByteArray(writeEncryptedScaledTemporal(paramGregorianCalendar, 0, 0, SSType.DATE, (short)0));
    } 





    
    writeByte(TDSType.DATEN.byteValue());
    writeCryptoMetaData();
  }






  
  void writeEncryptedRPCDateTime(String paramString, GregorianCalendar paramGregorianCalendar, int paramInt, boolean paramBoolean, JDBCType paramJDBCType) throws SQLServerException {
    assert paramInt >= 0 && paramInt < 1000000000 : "Invalid subNanoSeconds value: " + paramInt;
    assert paramGregorianCalendar != null || (paramGregorianCalendar == null && paramInt == 0) : "Invalid subNanoSeconds value when calendar is null: " + paramInt;
    
    writeRPCNameValType(paramString, paramBoolean, TDSType.BIGVARBINARY);
    
    if (null == paramGregorianCalendar) {
      writeEncryptedRPCByteArray(null);
    } else {
      writeEncryptedRPCByteArray(getEncryptedDateTimeAsBytes(paramGregorianCalendar, paramInt, paramJDBCType));
    } 
    
    if (JDBCType.SMALLDATETIME == paramJDBCType) {
      
      writeByte(TDSType.DATETIMEN.byteValue());
      writeByte((byte)4);
    }
    else {
      
      writeByte(TDSType.DATETIMEN.byteValue());
      writeByte((byte)8);
    } 
    writeCryptoMetaData();
  }


  
  byte[] getEncryptedDateTimeAsBytes(GregorianCalendar paramGregorianCalendar, int paramInt, JDBCType paramJDBCType) throws SQLServerException {
    int i = DDC.daysSinceBaseDate(paramGregorianCalendar.get(1), paramGregorianCalendar.get(6), 1900);





    
    int j = (paramInt + 500000) / 1000000 + 1000 * paramGregorianCalendar.get(13) + 60000 * paramGregorianCalendar.get(12) + 3600000 * paramGregorianCalendar.get(11);






    
    if (j >= 86399999) {
      
      i++;
      j = 0;
    } 






    
    if (i < DDC.daysSinceBaseDate(1753, 1, 1900) || i >= DDC.daysSinceBaseDate(10000, 1, 1900)) {

      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
      Object[] arrayOfObject = { SSType.DATETIME };
      throw new SQLServerException(messageFormat.format(arrayOfObject), SQLState.DATA_EXCEPTION_DATETIME_FIELD_OVERFLOW, DriverError.NOT_SET, null);
    } 




    
    if (JDBCType.SMALLDATETIME == paramJDBCType) {
      
      int k = j / 1000;
      int m = k / 60;

      
      m = ((k % 60) > 29.998D) ? (m + 1) : m;
      
      ByteBuffer byteBuffer1 = ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN);
      byteBuffer1.putShort((short)i);
      ByteBuffer byteBuffer2 = ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN);
      byteBuffer2.putShort((short)m);
      
      byte[] arrayOfByte = new byte[4];
      System.arraycopy(byteBuffer1.array(), 0, arrayOfByte, 0, 2);
      System.arraycopy(byteBuffer2.array(), 0, arrayOfByte, 2, 2);
      return SQLServerSecurityUtility.encryptWithKey(arrayOfByte, this.cryptoMeta, this.con);
    } 
    if (JDBCType.DATETIME == paramJDBCType) {

      
      ByteBuffer byteBuffer1 = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN);
      byteBuffer1.putInt(i);
      ByteBuffer byteBuffer2 = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN);
      byteBuffer2.putInt((3 * j + 5) / 10);
      
      byte[] arrayOfByte = new byte[8];
      System.arraycopy(byteBuffer1.array(), 0, arrayOfByte, 0, 4);
      System.arraycopy(byteBuffer2.array(), 0, arrayOfByte, 4, 4);
      return SQLServerSecurityUtility.encryptWithKey(arrayOfByte, this.cryptoMeta, this.con);
    } 
    
    assert false : "Unexpected JDBCType type " + paramJDBCType;
    return null;
  }






  
  void writeEncryptedRPCDateTime2(String paramString, GregorianCalendar paramGregorianCalendar, int paramInt1, int paramInt2, boolean paramBoolean) throws SQLServerException {
    writeRPCNameValType(paramString, paramBoolean, TDSType.BIGVARBINARY);
    
    if (null == paramGregorianCalendar) {
      writeEncryptedRPCByteArray(null);
    } else {
      writeEncryptedRPCByteArray(writeEncryptedScaledTemporal(paramGregorianCalendar, paramInt1, paramInt2, SSType.DATETIME2, (short)0));
    } 





    
    writeByte(TDSType.DATETIME2N.byteValue());
    writeByte((byte)paramInt2);
    writeCryptoMetaData();
  }







  
  void writeEncryptedRPCDateTimeOffset(String paramString, GregorianCalendar paramGregorianCalendar, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) throws SQLServerException {
    writeRPCNameValType(paramString, paramBoolean, TDSType.BIGVARBINARY);
    
    if (null == paramGregorianCalendar) {
      writeEncryptedRPCByteArray(null);
    } else {
      
      assert 0 == paramGregorianCalendar.get(15);
      writeEncryptedRPCByteArray(writeEncryptedScaledTemporal(paramGregorianCalendar, paramInt2, paramInt3, SSType.DATETIMEOFFSET, (short)paramInt1));
    } 






    
    writeByte(TDSType.DATETIMEOFFSETN.byteValue());
    writeByte((byte)paramInt3);
    writeCryptoMetaData();
  }







  
  void writeRPCDateTime2(String paramString, GregorianCalendar paramGregorianCalendar, int paramInt1, int paramInt2, boolean paramBoolean) throws SQLServerException {
    writeRPCNameValType(paramString, paramBoolean, TDSType.DATETIME2N);
    writeByte((byte)paramInt2);
    
    if (null == paramGregorianCalendar) {
      
      writeByte((byte)0);
      
      return;
    } 
    writeByte((byte)TDS.datetime2ValueLength(paramInt2));
    writeScaledTemporal(paramGregorianCalendar, paramInt1, paramInt2, SSType.DATETIME2);
  }











  
  void writeRPCDateTimeOffset(String paramString, GregorianCalendar paramGregorianCalendar, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) throws SQLServerException {
    writeRPCNameValType(paramString, paramBoolean, TDSType.DATETIMEOFFSETN);
    writeByte((byte)paramInt3);
    
    if (null == paramGregorianCalendar) {
      
      writeByte((byte)0);
      
      return;
    } 
    assert 0 == paramGregorianCalendar.get(15);
    
    writeByte((byte)TDS.datetimeoffsetValueLength(paramInt3));
    writeScaledTemporal(paramGregorianCalendar, paramInt2, paramInt3, SSType.DATETIMEOFFSET);




    
    writeShort((short)paramInt1);
  }










  
  private int getRoundedSubSecondNanos(int paramInt) {
    return (paramInt + Nanos.PER_MAX_SCALE_INTERVAL / 2) / Nanos.PER_MAX_SCALE_INTERVAL * Nanos.PER_MAX_SCALE_INTERVAL;
  }


















  
  private void writeScaledTemporal(GregorianCalendar paramGregorianCalendar, int paramInt1, int paramInt2, SSType paramSSType) throws SQLServerException {
    assert this.con.isKatmaiOrLater();





    
    assert SSType.DATE == paramSSType || SSType.TIME == paramSSType || SSType.DATETIME2 == paramSSType || SSType.DATETIMEOFFSET == paramSSType : "Unexpected SSType: " + paramSSType;

    
    if (SSType.TIME == paramSSType || SSType.DATETIME2 == paramSSType || SSType.DATETIMEOFFSET == paramSSType) {


      
      assert paramInt1 >= 0;
      assert paramInt1 < 1000000000;
      assert paramInt2 >= 0;
      assert paramInt2 <= 7;
      
      int i = paramGregorianCalendar.get(13) + 60 * paramGregorianCalendar.get(12) + 3600 * paramGregorianCalendar.get(11);




      
      long l1 = Nanos.PER_MAX_SCALE_INTERVAL * (long)Math.pow(10.0D, (7 - paramInt2));




      
      long l2 = (1000000000L * i + getRoundedSubSecondNanos(paramInt1) + l1 / 2L) / l1;





      
      if (86400000000000L / l1 == l2)
      {

        
        if (SSType.TIME == paramSSType) {
          
          l2--;
        
        }
        else {

          
          assert SSType.DATETIME2 == paramSSType || SSType.DATETIMEOFFSET == paramSSType : "Unexpected SSType: " + paramSSType;











          
          paramGregorianCalendar.add(13, 1);
          
          if (paramGregorianCalendar.get(1) <= 9999) {
            
            l2 = 0L;
          }
          else {
            
            paramGregorianCalendar.add(13, -1);
            l2--;
          } 
        } 
      }

      
      int j = TDS.nanosSinceMidnightLength(paramInt2);
      byte[] arrayOfByte = scaledNanosToEncodedBytes(l2, j);
      
      writeBytes(arrayOfByte);
    } 

    
    if (SSType.DATE == paramSSType || SSType.DATETIME2 == paramSSType || SSType.DATETIMEOFFSET == paramSSType) {










      
      if (paramGregorianCalendar.getTimeInMillis() < GregorianChange.STANDARD_CHANGE_DATE.getTime() || paramGregorianCalendar.getActualMaximum(6) < 365) {

        
        int j = paramGregorianCalendar.get(1);
        int k = paramGregorianCalendar.get(2);
        int m = paramGregorianCalendar.get(5);

        
        paramGregorianCalendar.setGregorianChange(GregorianChange.PURE_CHANGE_DATE);

        
        paramGregorianCalendar.set(j, k, m);
      } 
      
      int i = DDC.daysSinceBaseDate(paramGregorianCalendar.get(1), paramGregorianCalendar.get(6), 1);









      
      if (i < 0 || i >= DDC.daysSinceBaseDate(10000, 1, 1)) {
        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
        Object[] arrayOfObject = { paramSSType };
        throw new SQLServerException(messageFormat.format(arrayOfObject), SQLState.DATA_EXCEPTION_DATETIME_FIELD_OVERFLOW, DriverError.NOT_SET, null);
      } 




      
      byte[] arrayOfByte = new byte[3];
      arrayOfByte[0] = (byte)(i >> 0 & 0xFF);
      arrayOfByte[1] = (byte)(i >> 8 & 0xFF);
      arrayOfByte[2] = (byte)(i >> 16 & 0xFF);
      writeBytes(arrayOfByte);
    } 
  }

















  
  byte[] writeEncryptedScaledTemporal(GregorianCalendar paramGregorianCalendar, int paramInt1, int paramInt2, SSType paramSSType, short paramShort) throws SQLServerException {
    assert this.con.isKatmaiOrLater();





    
    assert SSType.DATE == paramSSType || SSType.TIME == paramSSType || SSType.DATETIME2 == paramSSType || SSType.DATETIMEOFFSET == paramSSType : "Unexpected SSType: " + paramSSType;

    
    byte[] arrayOfByte = null;
    
    int i = 0;
    long l1 = 0L;
    long l2 = 0L;

    
    if (SSType.TIME == paramSSType || SSType.DATETIME2 == paramSSType || SSType.DATETIMEOFFSET == paramSSType) {


      
      assert paramInt1 >= 0;
      assert paramInt1 < 1000000000;
      assert paramInt2 >= 0;
      assert paramInt2 <= 7;
      
      i = paramGregorianCalendar.get(13) + 60 * paramGregorianCalendar.get(12) + 3600 * paramGregorianCalendar.get(11);




      
      l1 = Nanos.PER_MAX_SCALE_INTERVAL * (long)Math.pow(10.0D, (7 - paramInt2));




      
      l2 = (1000000000L * i + getRoundedSubSecondNanos(paramInt1) + l1 / 2L) / l1 * l1 / 100L;



      
      if (SSType.TIME == paramSSType && 864000000000L <= l2) {
        l2 = (1000000000L * i + getRoundedSubSecondNanos(paramInt1)) / l1 * l1 / 100L;
      }





      
      if (86400000000000L / l1 == l2)
      {

        
        if (SSType.TIME == paramSSType) {
          
          l2--;
        
        }
        else {

          
          assert SSType.DATETIME2 == paramSSType || SSType.DATETIMEOFFSET == paramSSType : "Unexpected SSType: " + paramSSType;











          
          paramGregorianCalendar.add(13, 1);
          
          if (paramGregorianCalendar.get(1) <= 9999) {
            
            l2 = 0L;
          }
          else {
            
            paramGregorianCalendar.add(13, -1);
            l2--;
          } 
        } 
      }

      
      int j = TDS.nanosSinceMidnightLength(7);
      byte[] arrayOfByte1 = scaledNanosToEncodedBytes(l2, j);

      
      if (SSType.TIME == paramSSType)
      {
        return SQLServerSecurityUtility.encryptWithKey(arrayOfByte1, this.cryptoMeta, this.con);
      }
      
      if (SSType.DATETIME2 == paramSSType) {

        
        arrayOfByte = new byte[j + 3];
        System.arraycopy(arrayOfByte1, 0, arrayOfByte, 0, arrayOfByte1.length);
      }
      else if (SSType.DATETIMEOFFSET == paramSSType) {

        
        arrayOfByte = new byte[j + 5];
        System.arraycopy(arrayOfByte1, 0, arrayOfByte, 0, arrayOfByte1.length);
      } 
    } 

    
    if (SSType.DATE == paramSSType || SSType.DATETIME2 == paramSSType || SSType.DATETIMEOFFSET == paramSSType) {
      byte[] arrayOfByte2;









      
      if (paramGregorianCalendar.getTimeInMillis() < GregorianChange.STANDARD_CHANGE_DATE.getTime() || paramGregorianCalendar.getActualMaximum(6) < 365) {

        
        int k = paramGregorianCalendar.get(1);
        int m = paramGregorianCalendar.get(2);
        int n = paramGregorianCalendar.get(5);

        
        paramGregorianCalendar.setGregorianChange(GregorianChange.PURE_CHANGE_DATE);

        
        paramGregorianCalendar.set(k, m, n);
      } 
      
      int j = DDC.daysSinceBaseDate(paramGregorianCalendar.get(1), paramGregorianCalendar.get(6), 1);









      
      if (j < 0 || j >= DDC.daysSinceBaseDate(10000, 1, 1)) {
        
        MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
        Object[] arrayOfObject1 = { paramSSType };
        throw new SQLServerException(messageFormat1.format(arrayOfObject1), SQLState.DATA_EXCEPTION_DATETIME_FIELD_OVERFLOW, DriverError.NOT_SET, null);
      } 




      
      byte[] arrayOfByte1 = new byte[3];
      arrayOfByte1[0] = (byte)(j >> 0 & 0xFF);
      arrayOfByte1[1] = (byte)(j >> 8 & 0xFF);
      arrayOfByte1[2] = (byte)(j >> 16 & 0xFF);

      
      if (SSType.DATE == paramSSType) {
        
        arrayOfByte2 = SQLServerSecurityUtility.encryptWithKey(arrayOfByte1, this.cryptoMeta, this.con);
      }
      else if (SSType.DATETIME2 == paramSSType) {

        
        if (3652058 == j && 
          864000000000L == l2) {
          
          l2 = (1000000000L * i + getRoundedSubSecondNanos(paramInt1)) / l1 * l1 / 100L;

          
          int k = TDS.nanosSinceMidnightLength(7);
          byte[] arrayOfByte3 = scaledNanosToEncodedBytes(l2, k);

          
          arrayOfByte = new byte[k + 3];
          System.arraycopy(arrayOfByte3, 0, arrayOfByte, 0, arrayOfByte3.length);
        } 

        
        System.arraycopy(arrayOfByte1, 0, arrayOfByte, arrayOfByte.length - 3, 3);
        
        arrayOfByte2 = SQLServerSecurityUtility.encryptWithKey(arrayOfByte, this.cryptoMeta, this.con);
      
      }
      else {
        
        if (3652058 == j && 
          864000000000L == l2) {
          
          l2 = (1000000000L * i + getRoundedSubSecondNanos(paramInt1)) / l1 * l1 / 100L;

          
          int k = TDS.nanosSinceMidnightLength(7);
          byte[] arrayOfByte3 = scaledNanosToEncodedBytes(l2, k);

          
          arrayOfByte = new byte[k + 5];
          System.arraycopy(arrayOfByte3, 0, arrayOfByte, 0, arrayOfByte3.length);
        } 


        
        System.arraycopy(arrayOfByte1, 0, arrayOfByte, arrayOfByte.length - 5, 3);
        
        System.arraycopy(ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN).putShort(paramShort).array(), 0, arrayOfByte, arrayOfByte.length - 2, 2);





        
        arrayOfByte2 = SQLServerSecurityUtility.encryptWithKey(arrayOfByte, this.cryptoMeta, this.con);
      } 
      return arrayOfByte2;
    } 

    
    MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unknownSSType"));
    Object[] arrayOfObject = { paramSSType };
    SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), null, true);
    
    return null;
  }
  
  private byte[] scaledNanosToEncodedBytes(long paramLong, int paramInt) {
    byte[] arrayOfByte = new byte[paramInt];
    for (byte b = 0; b < paramInt; b++)
      arrayOfByte[b] = (byte)(int)(paramLong >> 8 * b & 0xFFL); 
    return arrayOfByte;
  }
















  
  void writeRPCInputStream(String paramString, InputStream paramInputStream, long paramLong, boolean paramBoolean, JDBCType paramJDBCType, SQLCollation paramSQLCollation) throws SQLServerException {
    assert null != paramInputStream;
    assert -1L == paramLong || paramLong >= 0L;


    
    boolean bool = (-1L == paramLong || paramLong > 8000L) ? true : false;
    if (bool) {
      
      assert -1L == paramLong || paramLong <= 2147483647L;
      
      writeRPCNameValType(paramString, paramBoolean, paramJDBCType.isTextual() ? TDSType.BIGVARCHAR : TDSType.BIGVARBINARY);






      
      writeVMaxHeader(paramLong, false, paramJDBCType.isTextual() ? paramSQLCollation : null);



    
    }
    else {




      
      if (-1L == paramLong) {


        
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(8000);
        paramLong = 0L;


        
        long l = 65535L * this.con.getTDSPacketSize();

        
        try {
          byte[] arrayOfByte = new byte[8000];
          
          int i;
          while (paramLong < l && -1 != (i = paramInputStream.read(arrayOfByte, 0, arrayOfByte.length)))
          {
            byteArrayOutputStream.write(arrayOfByte);
            paramLong += i;
          }
        
        } catch (IOException iOException) {
          
          throw new SQLServerException(iOException.getMessage(), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, iOException);
        } 




        
        if (paramLong >= l) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
          Object[] arrayOfObject = { Long.valueOf(paramLong) };
          SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), "", true);
        } 
        
        assert paramLong <= 2147483647L;
        paramInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray(), 0, (int)paramLong);
      } 
      
      assert 0L <= paramLong && paramLong <= 2147483647L;
      
      boolean bool1 = (paramLong <= 8000L) ? true : false;
      
      writeRPCNameValType(paramString, paramBoolean, paramJDBCType.isTextual() ? (bool1 ? TDSType.BIGVARCHAR : TDSType.TEXT) : (bool1 ? TDSType.BIGVARBINARY : TDSType.IMAGE));






      
      if (bool1) {
        
        writeShort((short)8000);
        if (paramJDBCType.isTextual())
          paramSQLCollation.writeCollation(this); 
        writeShort((short)(int)paramLong);
      }
      else {
        
        writeInt(2147483647);
        if (paramJDBCType.isTextual())
          paramSQLCollation.writeCollation(this); 
        writeInt((int)paramLong);
      } 
    } 

    
    writeStream(paramInputStream, paramLong, bool);
  }













  
  void writeRPCXML(String paramString, InputStream paramInputStream, long paramLong, boolean paramBoolean) throws SQLServerException {
    assert -1L == paramLong || paramLong >= 0L;
    assert -1L == paramLong || paramLong <= 2147483647L;
    
    writeRPCNameValType(paramString, paramBoolean, TDSType.XML);


    
    writeByte((byte)0);
    
    if (null == paramInputStream) {

      
      writeLong(-1L);
    }
    else if (-1L == paramLong) {


      
      writeLong(-2L);

    
    }
    else {


      
      writeLong(paramLong);
    } 
    if (null != paramInputStream)
    {
      writeStream(paramInputStream, paramLong, true);
    }
  }














  
  void writeRPCReaderUnicode(String paramString, Reader paramReader, long paramLong, boolean paramBoolean, SQLCollation paramSQLCollation) throws SQLServerException {
    assert null != paramReader;
    assert -1L == paramLong || paramLong >= 0L;


    
    if (null == paramSQLCollation) {
      paramSQLCollation = this.con.getDatabaseCollation();
    }

    
    boolean bool = (-1L == paramLong || paramLong > 4000L) ? true : false;
    if (bool) {
      
      assert -1L == paramLong || paramLong <= 1073741823L;
      
      writeRPCNameValType(paramString, paramBoolean, TDSType.NVARCHAR);




      
      writeVMaxHeader((-1L == paramLong) ? -1L : (2L * paramLong), false, paramSQLCollation);



    
    }
    else {




      
      assert 0L <= paramLong && paramLong <= 1073741823L;



      
      boolean bool1 = (paramLong <= 4000L) ? true : false;
      
      writeRPCNameValType(paramString, paramBoolean, bool1 ? TDSType.NVARCHAR : TDSType.NTEXT);




      
      if (bool1) {
        
        writeShort((short)8000);
        paramSQLCollation.writeCollation(this);
        writeShort((short)(int)(2L * paramLong));
      }
      else {
        
        writeInt(1073741823);
        paramSQLCollation.writeCollation(this);
        writeInt((int)(2L * paramLong));
      } 
    } 

    
    writeReader(paramReader, paramLong, bool);
  }
}
