package com.microsoft.sqlserver.jdbc;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.UnrecoverableKeyException;
import java.security.cert.X509Certificate;
import java.text.MessageFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Cipher;








public class SQLServerColumnEncryptionJavaKeyStoreProvider
  extends SQLServerColumnEncryptionKeyStoreProvider
{
  String name = "MSSQL_JAVA_KEYSTORE";

  
  String keyStorePath = null;
  char[] keyStorePwd = null;
  
  private static final Logger javaKeyStoreLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.SQLServerColumnEncryptionJavaKeyStoreProvider");


  
  public void setName(String paramString) {
    this.name = paramString;
  }

  
  public String getName() {
    return this.name;
  }

  
  public SQLServerColumnEncryptionJavaKeyStoreProvider(String paramString, char[] paramArrayOfchar) throws SQLServerException {
    javaKeyStoreLogger.entering(SQLServerColumnEncryptionJavaKeyStoreProvider.class.getName(), "SQLServerColumnEncryptionJavaKeyStoreProvider");
    
    if (null == paramString || 0 == paramString.length()) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidConnectionSetting"));
      Object[] arrayOfObject = { "keyStoreLocation", paramString };
      throw new SQLServerException(messageFormat.format(arrayOfObject), null);
    } 
    
    this.keyStorePath = paramString;
    
    if (javaKeyStoreLogger.isLoggable(Level.FINE)) {
      javaKeyStoreLogger.fine("Path of key store provider is set.");
    }

    
    if (null == paramArrayOfchar)
    {
      paramArrayOfchar = "".toCharArray();
    }
    
    this.keyStorePwd = new char[paramArrayOfchar.length];
    System.arraycopy(paramArrayOfchar, 0, this.keyStorePwd, 0, paramArrayOfchar.length);
    
    if (javaKeyStoreLogger.isLoggable(Level.FINE)) {
      javaKeyStoreLogger.fine("Password for key store provider is set.");
    }
    
    javaKeyStoreLogger.exiting(SQLServerColumnEncryptionJavaKeyStoreProvider.class.getName(), "SQLServerColumnEncryptionJavaKeyStoreProvider");
  }





  
  public byte[] decryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException {
    javaKeyStoreLogger.entering(SQLServerColumnEncryptionJavaKeyStoreProvider.class.getName(), "decryptColumnEncryptionKey", "Decrypting Column Encryption Key.");
    
    KeyStoreProviderCommon.validateNonEmptyMasterKeyPath(paramString1);
    CertificateDetails certificateDetails = getCertificateDetails(paramString1);
    byte[] arrayOfByte = KeyStoreProviderCommon.decryptColumnEncryptionKey(paramString1, paramString2, paramArrayOfbyte, certificateDetails);
    
    javaKeyStoreLogger.exiting(SQLServerColumnEncryptionJavaKeyStoreProvider.class.getName(), "decryptColumnEncryptionKey", "Finished decrypting Column Encryption Key.");
    return arrayOfByte;
  }



  
  private CertificateDetails getCertificateDetails(String paramString) throws SQLServerException {
    FileInputStream fileInputStream = null;
    KeyStore keyStore = null;
    CertificateDetails certificateDetails = null;

    
    try {
      if (null == paramString || 0 == paramString.length())
      {
        throw new SQLServerException(null, SQLServerException.getErrString("R_InvalidMasterKeyDetails"), null, 0, false);
      }







      
      try {
        keyStore = KeyStore.getInstance("JKS");
        fileInputStream = new FileInputStream(this.keyStorePath);
        keyStore.load(fileInputStream, this.keyStorePwd);
      }
      catch (IOException iOException) {
        
        if (null != fileInputStream) fileInputStream.close();

        
        keyStore = KeyStore.getInstance("PKCS12");
        fileInputStream = new FileInputStream(this.keyStorePath);
        keyStore.load(fileInputStream, this.keyStorePwd);
      } 
      
      certificateDetails = getCertificateDetailsByAlias(keyStore, paramString);
    }
    catch (FileNotFoundException fileNotFoundException) {
      
      throw new SQLServerException(this, SQLServerException.getErrString("R_KeyStoreNotFound"), null, 0, false);
    }
    catch (IOException|java.security.cert.CertificateException|NoSuchAlgorithmException|java.security.KeyStoreException iOException) {



      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidKeyStoreFile"));
      
      Object[] arrayOfObject = { this.keyStorePath };
      throw new SQLServerException(messageFormat.format(arrayOfObject), iOException);
    } finally {

      
      try {
        
        if (null != fileInputStream) fileInputStream.close();
      
      }
      catch (IOException iOException) {}
    } 
    
    return certificateDetails;
  }




  
  private CertificateDetails getCertificateDetailsByAlias(KeyStore paramKeyStore, String paramString) throws SQLServerException {
    try {
      X509Certificate x509Certificate = (X509Certificate)paramKeyStore.getCertificate(paramString);
      Key key = paramKeyStore.getKey(paramString, this.keyStorePwd);
      if (null == x509Certificate) {

        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_CertificateNotFoundForAlias"));
        
        Object[] arrayOfObject = { paramString, "MSSQL_JAVA_KEYSTORE" };
        throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
      } 

      
      if (null == key) {
        throw new UnrecoverableKeyException();
      }
      
      return new CertificateDetails(x509Certificate, key);
    }
    catch (UnrecoverableKeyException unrecoverableKeyException) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_UnrecoverableKeyAE"));
      
      Object[] arrayOfObject = { paramString };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    }
    catch (NoSuchAlgorithmException|java.security.KeyStoreException noSuchAlgorithmException) {
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_CertificateError"));
      
      Object[] arrayOfObject = { paramString, this.name };
      throw new SQLServerException(messageFormat.format(arrayOfObject), noSuchAlgorithmException);
    } 
  }


  
  public byte[] encryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException {
    byte[] arrayOfByte4;
    javaKeyStoreLogger.entering(SQLServerColumnEncryptionJavaKeyStoreProvider.class.getName(), Thread.currentThread().getStackTrace()[1].getMethodName(), "Encrypting Column Encryption Key.");
    
    byte[] arrayOfByte1 = KeyStoreProviderCommon.version;
    KeyStoreProviderCommon.validateNonEmptyMasterKeyPath(paramString1);
    
    if (null == paramArrayOfbyte)
    {
      throw new SQLServerException(null, SQLServerException.getErrString("R_NullColumnEncryptionKey"), null, 0, false);
    }





    
    if (0 == paramArrayOfbyte.length)
    {
      throw new SQLServerException(null, SQLServerException.getErrString("R_EmptyColumnEncryptionKey"), null, 0, false);
    }






    
    KeyStoreProviderCommon.validateEncryptionAlgorithm(paramString2, true);
    
    CertificateDetails certificateDetails = getCertificateDetails(paramString1);
    byte[] arrayOfByte2 = encryptRSAOAEP(paramArrayOfbyte, certificateDetails);
    byte[] arrayOfByte3 = getLittleEndianBytesFromShort((short)arrayOfByte2.length);

    
    try {
      arrayOfByte4 = paramString1.toLowerCase().getBytes("UTF-16LE");
    }
    catch (UnsupportedEncodingException unsupportedEncodingException) {
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
      throw new SQLServerException(messageFormat.format(new Object[] { "UTF-16LE" }, ), null, 0, null);
    } 
    
    byte[] arrayOfByte5 = getLittleEndianBytesFromShort((short)arrayOfByte4.length);
    
    byte[] arrayOfByte6 = new byte[arrayOfByte1.length + arrayOfByte5.length + arrayOfByte3.length + arrayOfByte4.length + arrayOfByte2.length];
    int i = arrayOfByte1.length;
    System.arraycopy(arrayOfByte1, 0, arrayOfByte6, 0, arrayOfByte1.length);
    
    System.arraycopy(arrayOfByte5, 0, arrayOfByte6, i, arrayOfByte5.length);
    i += arrayOfByte5.length;
    
    System.arraycopy(arrayOfByte3, 0, arrayOfByte6, i, arrayOfByte3.length);
    i += arrayOfByte3.length;
    
    System.arraycopy(arrayOfByte4, 0, arrayOfByte6, i, arrayOfByte4.length);
    i += arrayOfByte4.length;
    
    System.arraycopy(arrayOfByte2, 0, arrayOfByte6, i, arrayOfByte2.length);
    byte[] arrayOfByte7 = rsaSignHashedData(arrayOfByte6, certificateDetails);
    
    int j = arrayOfByte1.length + arrayOfByte3.length + arrayOfByte5.length + arrayOfByte2.length + arrayOfByte4.length + arrayOfByte7.length;
    byte[] arrayOfByte8 = new byte[j];
    
    int k = 0;
    System.arraycopy(arrayOfByte1, 0, arrayOfByte8, k, arrayOfByte1.length);
    k += arrayOfByte1.length;
    
    System.arraycopy(arrayOfByte5, 0, arrayOfByte8, k, arrayOfByte5.length);
    k += arrayOfByte5.length;
    
    System.arraycopy(arrayOfByte3, 0, arrayOfByte8, k, arrayOfByte3.length);
    k += arrayOfByte3.length;
    
    System.arraycopy(arrayOfByte4, 0, arrayOfByte8, k, arrayOfByte4.length);
    k += arrayOfByte4.length;
    
    System.arraycopy(arrayOfByte2, 0, arrayOfByte8, k, arrayOfByte2.length);
    k += arrayOfByte2.length;
    
    System.arraycopy(arrayOfByte7, 0, arrayOfByte8, k, arrayOfByte7.length);
    
    javaKeyStoreLogger.exiting(SQLServerColumnEncryptionJavaKeyStoreProvider.class.getName(), Thread.currentThread().getStackTrace()[1].getMethodName(), "Finished encrypting Column Encryption Key.");
    return arrayOfByte8;
  }









  
  private byte[] encryptRSAOAEP(byte[] paramArrayOfbyte, CertificateDetails paramCertificateDetails) throws SQLServerException {
    byte[] arrayOfByte = null;
    
    try {
      Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-1AndMGF1Padding");
      cipher.init(1, paramCertificateDetails.certificate.getPublicKey());
      cipher.update(paramArrayOfbyte);
      arrayOfByte = cipher.doFinal();
    }
    catch (InvalidKeyException|NoSuchAlgorithmException|javax.crypto.IllegalBlockSizeException|javax.crypto.NoSuchPaddingException|javax.crypto.BadPaddingException invalidKeyException) {




      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_EncryptionFailed"));
      
      Object[] arrayOfObject = { invalidKeyException.getMessage() };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    } 
    
    return arrayOfByte;
  }


  
  private byte[] rsaSignHashedData(byte[] paramArrayOfbyte, CertificateDetails paramCertificateDetails) throws SQLServerException {
    byte[] arrayOfByte = null;
    
    try {
      Signature signature = Signature.getInstance("SHA256withRSA");
      signature.initSign((PrivateKey)paramCertificateDetails.privateKey);
      signature.update(paramArrayOfbyte);
      arrayOfByte = signature.sign();
    } catch (InvalidKeyException|NoSuchAlgorithmException|java.security.SignatureException invalidKeyException) {
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_EncryptionFailed"));
      
      Object[] arrayOfObject = { invalidKeyException.getMessage() };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    } 
    
    return arrayOfByte;
  }





  
  private byte[] getLittleEndianBytesFromShort(short paramShort) {
    ByteBuffer byteBuffer = ByteBuffer.allocate(2);
    byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
    return byteBuffer.putShort(paramShort).array();
  }
}
