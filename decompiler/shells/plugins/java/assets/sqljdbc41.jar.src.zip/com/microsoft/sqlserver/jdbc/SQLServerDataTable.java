package com.microsoft.sqlserver.jdbc;

import java.math.BigDecimal;
import java.text.MessageFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import microsoft.sql.DateTimeOffset;

public final class SQLServerDataTable {
  int rowCount = 0;
  int columnCount = 0;
  Map<Integer, SQLServerDataColumn> columnMetadata = null;
  Map<Integer, Object[]> rows = null;






  
  public SQLServerDataTable() throws SQLServerException {
    this.columnMetadata = new LinkedHashMap<>();
    this.rows = (Map)new HashMap<>();
  }

  
  public synchronized void clear() {
    this.rowCount = 0;
    this.columnCount = 0;
    this.columnMetadata.clear();
    this.rows.clear();
  }

  
  public synchronized Iterator<Map.Entry<Integer, Object[]>> getIterator() {
    if (null != this.rows && null != this.rows.entrySet())
    {
      return this.rows.entrySet().iterator();
    }
    return null;
  }



  
  public synchronized void addColumnMetadata(String paramString, int paramInt) throws SQLServerException {
    Util.checkDuplicateColumnName(paramString, this.columnMetadata);
    this.columnMetadata.put(Integer.valueOf(this.columnCount++), new SQLServerDataColumn(paramString, paramInt));
  }


  
  public synchronized void addColumnMetadata(SQLServerDataColumn paramSQLServerDataColumn) throws SQLServerException {
    Util.checkDuplicateColumnName(paramSQLServerDataColumn.columnName, this.columnMetadata);
    this.columnMetadata.put(Integer.valueOf(this.columnCount++), paramSQLServerDataColumn);
  }








  
  public synchronized void addRow(Object... paramVarArgs) throws SQLServerException {
    try {
      int i = this.columnMetadata.size();
      
      if (null != paramVarArgs && paramVarArgs.length > i) {
        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_moreDataInRowThanColumnInTVP"));
        Object[] arrayOfObject1 = new Object[0];
        throw new SQLServerException(null, messageFormat.format(arrayOfObject1), null, 0, false);
      } 
      
      Iterator<Map.Entry> iterator = this.columnMetadata.entrySet().iterator();
      Object[] arrayOfObject = new Object[i];
      byte b = 0;
      while (iterator.hasNext()) {
        boolean bool1; byte b1; BigDecimal bigDecimal;
        Object object = null;


        
        if (null != paramVarArgs && b < paramVarArgs.length && null != paramVarArgs[b])
          object = (null == paramVarArgs[b]) ? null : paramVarArgs[b]; 
        b++;
        Map.Entry entry = iterator.next();
        SQLServerDataColumn sQLServerDataColumn = (SQLServerDataColumn)entry.getValue();
        JDBCType jDBCType = JDBCType.of(((SQLServerDataColumn)entry.getValue()).javaSqlType);
        
        boolean bool2 = false;
        switch (jDBCType) {
          
          case BIGINT:
            arrayOfObject[((Integer)entry.getKey()).intValue()] = (null == object) ? null : Long.valueOf(Long.parseLong(object.toString()));
            continue;
          
          case BIT:
            arrayOfObject[((Integer)entry.getKey()).intValue()] = (null == object) ? null : Boolean.valueOf(Boolean.parseBoolean(object.toString()));
            continue;
          
          case INTEGER:
            arrayOfObject[((Integer)entry.getKey()).intValue()] = (null == object) ? null : Integer.valueOf(Integer.parseInt(object.toString()));
            continue;
          
          case SMALLINT:
          case TINYINT:
            arrayOfObject[((Integer)entry.getKey()).intValue()] = (null == object) ? null : Short.valueOf(Short.parseShort(object.toString()));
            continue;
          
          case DECIMAL:
          case NUMERIC:
            bigDecimal = null;
            if (null != object) {
              
              bigDecimal = new BigDecimal(object.toString());
              if (bigDecimal.scale() > sQLServerDataColumn.scale) {
                
                sQLServerDataColumn.scale = bigDecimal.scale();
                bool2 = true;
              } 
              if (bigDecimal.precision() > sQLServerDataColumn.precision) {
                
                sQLServerDataColumn.precision = bigDecimal.precision();
                bool2 = true;
              } 
              if (bool2)
                this.columnMetadata.put((Integer)entry.getKey(), sQLServerDataColumn); 
            } 
            arrayOfObject[((Integer)entry.getKey()).intValue()] = bigDecimal;
            continue;
          
          case DOUBLE:
            arrayOfObject[((Integer)entry.getKey()).intValue()] = (null == object) ? null : Double.valueOf(Double.parseDouble(object.toString()));
            continue;
          
          case FLOAT:
          case REAL:
            arrayOfObject[((Integer)entry.getKey()).intValue()] = (null == object) ? null : Float.valueOf(Float.parseFloat(object.toString()));
            continue;
          
          case TIMESTAMP_WITH_TIMEZONE:
          case TIME_WITH_TIMEZONE:
            DriverJDBCVersion.checkSupportsJDBC42();


          
          case DATE:
          case TIME:
          case TIMESTAMP:
          case DATETIMEOFFSET:
            if (null == object) {
              arrayOfObject[((Integer)entry.getKey()).intValue()] = null; continue;
            } 
            if (object instanceof Date) {
              arrayOfObject[((Integer)entry.getKey()).intValue()] = ((Date)object).toString(); continue;
            }  if (object instanceof DateTimeOffset) {
              arrayOfObject[((Integer)entry.getKey()).intValue()] = ((DateTimeOffset)object).toString(); continue;
            }  if (object instanceof OffsetDateTime) {
              arrayOfObject[((Integer)entry.getKey()).intValue()] = ((OffsetDateTime)object).toString(); continue;
            }  if (object instanceof OffsetTime) {
              arrayOfObject[((Integer)entry.getKey()).intValue()] = ((OffsetTime)object).toString(); continue;
            } 
            arrayOfObject[((Integer)entry.getKey()).intValue()] = (null == object) ? null : object;
            continue;
          
          case BINARY:
          case VARBINARY:
            bool1 = (null == object) ? true : false;
            b1 = bool1 ? 0 : ((byte[])object).length;
            
            if (b1 > sQLServerDataColumn.precision) {
              
              sQLServerDataColumn.precision = b1;
              this.columnMetadata.put((Integer)entry.getKey(), sQLServerDataColumn);
            } 
            arrayOfObject[((Integer)entry.getKey()).intValue()] = bool1 ? null : object;
            continue;

          
          case CHAR:
            if (object instanceof UUID && object != null) {
              object = ((UUID)object).toString();
            }
          
          case VARCHAR:
          case NCHAR:
          case NVARCHAR:
            bool1 = (null == object) ? true : false;
            b1 = bool1 ? 0 : (2 * ((String)object).length());
            
            if (b1 > sQLServerDataColumn.precision) {
              
              sQLServerDataColumn.precision = b1;
              this.columnMetadata.put((Integer)entry.getKey(), sQLServerDataColumn);
            } 
            arrayOfObject[((Integer)entry.getKey()).intValue()] = bool1 ? null : object;
            continue;
        } 
        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedDataTypeTVP"));
        Object[] arrayOfObject1 = { jDBCType };
        throw new SQLServerException(null, messageFormat.format(arrayOfObject1), null, 0, false);
      } 
      
      this.rows.put(Integer.valueOf(this.rowCount++), arrayOfObject);
    }
    catch (NumberFormatException numberFormatException) {
      
      throw new SQLServerException(SQLServerException.getErrString("R_TVPInvalidColumnValue"), numberFormatException);
    }
    catch (ClassCastException classCastException) {
      
      throw new SQLServerException(SQLServerException.getErrString("R_TVPInvalidColumnValue"), classCastException);
    } 
  }


  
  public synchronized Map<Integer, SQLServerDataColumn> getColumnMetadata() {
    return this.columnMetadata;
  }
}
