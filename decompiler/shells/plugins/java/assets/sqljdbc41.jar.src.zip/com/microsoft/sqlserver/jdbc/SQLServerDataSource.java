package com.microsoft.sqlserver.jdbc;
import java.io.InvalidObjectException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.Enumeration;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.RefAddr;
import javax.naming.Reference;
import javax.naming.Referenceable;
import javax.naming.StringRefAddr;

public class SQLServerDataSource implements ISQLServerDataSource, DataSource, Serializable, Referenceable {
  static final Logger dsLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerDataSource");
  static final Logger loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.DataSource");
  
  private final String loggingClassName;
  
  private boolean trustStorePasswordStripped = false;
  private static final long serialVersionUID = 654861379544314296L;
  private Properties connectionProps;
  private String dataSourceURL;
  private String dataSourceDescription;
  private static int baseDataSourceID = 0;
  private final String traceID;
  private transient PrintWriter logWriter;
  
  public SQLServerDataSource() {
    this.connectionProps = new Properties();
    int i = nextDataSourceID();
    String str = getClass().getName();
    this.traceID = str.substring(1 + str.lastIndexOf('.')) + ":" + i;
    this.loggingClassName = "com.microsoft.sqlserver.jdbc." + str.substring(1 + str.lastIndexOf('.')) + ":" + i;
  }

  
  String getClassNameLogging() {
    return this.loggingClassName;
  }
  
  public String toString() {
    return this.traceID;
  }



  
  public Connection getConnection() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getConnection");
    SQLServerConnection sQLServerConnection = getConnectionInternal(null, null, null);
    loggerExternal.exiting(getClassNameLogging(), "getConnection", sQLServerConnection);
    return sQLServerConnection;
  }
  
  public Connection getConnection(String paramString1, String paramString2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getConnection", new Object[] { paramString1, "Password not traced" }); 
    SQLServerConnection sQLServerConnection = getConnectionInternal(paramString1, paramString2, null);
    loggerExternal.exiting(getClassNameLogging(), "getConnection", sQLServerConnection);
    return sQLServerConnection;
  }



  
  public void setLoginTimeout(int paramInt) {
    setIntProperty(this.connectionProps, SQLServerDriverIntProperty.LOGIN_TIMEOUT.toString(), paramInt);
  }
  
  public int getLoginTimeout() {
    int i = SQLServerDriverIntProperty.LOGIN_TIMEOUT.getDefaultValue();
    int j = getIntProperty(this.connectionProps, SQLServerDriverIntProperty.LOGIN_TIMEOUT.toString(), i);
    
    return (j == 0) ? i : j;
  }




  
  public void setLogWriter(PrintWriter paramPrintWriter) {
    loggerExternal.entering(getClassNameLogging(), "setLogWriter", paramPrintWriter);
    this.logWriter = paramPrintWriter;
    loggerExternal.exiting(getClassNameLogging(), "setLogWriter");
  }


  
  public PrintWriter getLogWriter() {
    loggerExternal.entering(getClassNameLogging(), "getLogWriter");
    loggerExternal.exiting(getClassNameLogging(), "getLogWriter", this.logWriter);
    return this.logWriter;
  }

  
  public Logger getParentLogger() throws SQLFeatureNotSupportedException {
    DriverJDBCVersion.checkSupportsJDBC41();

    
    throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
  }





  
  public void setApplicationName(String paramString) {
    setStringProperty(this.connectionProps, SQLServerDriverStringProperty.APPLICATION_NAME.toString(), paramString);
  }
  
  public String getApplicationName() {
    return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.APPLICATION_NAME.toString(), SQLServerDriverStringProperty.APPLICATION_NAME.getDefaultValue());
  }



  
  public void setDatabaseName(String paramString) {
    setStringProperty(this.connectionProps, SQLServerDriverStringProperty.DATABASE_NAME.toString(), paramString);
  }
  
  public String getDatabaseName() {
    return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.DATABASE_NAME.toString(), null);
  }



  
  public void setInstanceName(String paramString) {
    setStringProperty(this.connectionProps, SQLServerDriverStringProperty.INSTANCE_NAME.toString(), paramString);
  }
  
  public String getInstanceName() {
    return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.INSTANCE_NAME.toString(), null);
  }

  
  public void setIntegratedSecurity(boolean paramBoolean) {
    setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.INTEGRATED_SECURITY.toString(), paramBoolean);
  }
  
  public void setAuthenticationScheme(String paramString) {
    setStringProperty(this.connectionProps, SQLServerDriverStringProperty.AUTHENTICATION_SCHEME.toString(), paramString);
  }

  
  public void setAuthentication(String paramString) {
    setStringProperty(this.connectionProps, SQLServerDriverStringProperty.AUTHENTICATION.toString(), paramString);
  }
  
  public String getAuthentication() {
    return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.AUTHENTICATION.toString(), SQLServerDriverStringProperty.AUTHENTICATION.getDefaultValue());
  }

  
  public void setAccessToken(String paramString) {
    setStringProperty(this.connectionProps, SQLServerDriverStringProperty.ACCESS_TOKEN.toString(), paramString);
  }
  
  public String getAccessToken() {
    return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.ACCESS_TOKEN.toString(), null);
  }






  
  public void setColumnEncryptionSetting(String paramString) {
    setStringProperty(this.connectionProps, SQLServerDriverStringProperty.COLUMN_ENCRYPTION.toString(), paramString);
  }
  
  public String getColumnEncryptionSetting() {
    return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.COLUMN_ENCRYPTION.toString(), SQLServerDriverStringProperty.COLUMN_ENCRYPTION.getDefaultValue());
  }

  
  public void setKeyStoreAuthentication(String paramString) {
    setStringProperty(this.connectionProps, SQLServerDriverStringProperty.KEY_STORE_AUTHENTICATION.toString(), paramString);
  }
  
  public String getKeyStoreAuthentication() {
    return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.KEY_STORE_AUTHENTICATION.toString(), SQLServerDriverStringProperty.KEY_STORE_AUTHENTICATION.getDefaultValue());
  }

  
  public void setKeyStoreSecret(String paramString) {
    setStringProperty(this.connectionProps, SQLServerDriverStringProperty.KEY_STORE_SECRET.toString(), paramString);
  }

  
  public void setKeyStoreLocation(String paramString) {
    setStringProperty(this.connectionProps, SQLServerDriverStringProperty.KEY_STORE_LOCATION.toString(), paramString);
  }
  
  public String getKeyStoreLocation() {
    return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.KEY_STORE_LOCATION.toString(), SQLServerDriverStringProperty.KEY_STORE_LOCATION.getDefaultValue());
  }

  
  public void setLastUpdateCount(boolean paramBoolean) {
    setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.toString(), paramBoolean);
  }
  
  public boolean getLastUpdateCount() {
    return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.toString(), SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.getDefaultValue());
  }


  
  public void setEncrypt(boolean paramBoolean) {
    setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.ENCRYPT.toString(), paramBoolean);
  }
  
  public boolean getEncrypt() {
    return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.ENCRYPT.toString(), SQLServerDriverBooleanProperty.ENCRYPT.getDefaultValue());
  }

  
  public void setTransparentNetworkIPResolution(boolean paramBoolean) {
    setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.TRANSPARENT_NETWORK_IP_RESOLUTION.toString(), paramBoolean);
  }
  
  public boolean getTransparentNetworkIPResolution() {
    return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.TRANSPARENT_NETWORK_IP_RESOLUTION.toString(), SQLServerDriverBooleanProperty.TRANSPARENT_NETWORK_IP_RESOLUTION.getDefaultValue());
  }

  
  public void setTrustServerCertificate(boolean paramBoolean) {
    setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.toString(), paramBoolean);
  }
  
  public boolean getTrustServerCertificate() {
    return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.toString(), SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.getDefaultValue());
  }
  
  public void setTrustStore(String paramString) {
    setStringProperty(this.connectionProps, SQLServerDriverStringProperty.TRUST_STORE.toString(), paramString);
  }
  
  public String getTrustStore() {
    return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.TRUST_STORE.toString(), null);
  }


  
  public void setTrustStorePassword(String paramString) {
    if (paramString != null)
      this.trustStorePasswordStripped = false; 
    setStringProperty(this.connectionProps, SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString(), paramString);
  }
  
  public void setHostNameInCertificate(String paramString) {
    setStringProperty(this.connectionProps, SQLServerDriverStringProperty.HOSTNAME_IN_CERTIFICATE.toString(), paramString);
  }
  
  public String getHostNameInCertificate() {
    return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.HOSTNAME_IN_CERTIFICATE.toString(), null);
  }






  
  public void setLockTimeout(int paramInt) {
    setIntProperty(this.connectionProps, SQLServerDriverIntProperty.LOCK_TIMEOUT.toString(), paramInt);
  }
  
  public int getLockTimeout() {
    return getIntProperty(this.connectionProps, SQLServerDriverIntProperty.LOCK_TIMEOUT.toString(), SQLServerDriverIntProperty.LOCK_TIMEOUT.getDefaultValue());
  }




  
  public void setPassword(String paramString) {
    setStringProperty(this.connectionProps, SQLServerDriverStringProperty.PASSWORD.toString(), paramString);
  }
  
  String getPassword() {
    return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.PASSWORD.toString(), null);
  }






  
  public void setPortNumber(int paramInt) {
    setIntProperty(this.connectionProps, SQLServerDriverIntProperty.PORT_NUMBER.toString(), paramInt);
  }
  
  public int getPortNumber() {
    return getIntProperty(this.connectionProps, SQLServerDriverIntProperty.PORT_NUMBER.toString(), SQLServerDriverIntProperty.PORT_NUMBER.getDefaultValue());
  }







  
  public void setSelectMethod(String paramString) {
    setStringProperty(this.connectionProps, SQLServerDriverStringProperty.SELECT_METHOD.toString(), paramString);
  }
  
  public String getSelectMethod() {
    return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.SELECT_METHOD.toString(), SQLServerDriverStringProperty.SELECT_METHOD.getDefaultValue());
  }

  
  public void setResponseBuffering(String paramString) {
    setStringProperty(this.connectionProps, SQLServerDriverStringProperty.RESPONSE_BUFFERING.toString(), paramString);
  }
  
  public String getResponseBuffering() {
    return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.RESPONSE_BUFFERING.toString(), SQLServerDriverStringProperty.RESPONSE_BUFFERING.getDefaultValue());
  }

  
  public void setApplicationIntent(String paramString) {
    setStringProperty(this.connectionProps, SQLServerDriverStringProperty.APPLICATION_INTENT.toString(), paramString);
  }
  
  public String getApplicationIntent() {
    return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.APPLICATION_INTENT.toString(), SQLServerDriverStringProperty.APPLICATION_INTENT.getDefaultValue());
  }

  
  public void setSendTimeAsDatetime(boolean paramBoolean) {
    setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.toString(), paramBoolean);
  }

  
  public boolean getSendTimeAsDatetime() {
    return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.toString(), SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.getDefaultValue());
  }






  
  public void setSendStringParametersAsUnicode(boolean paramBoolean) {
    setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.toString(), paramBoolean);
  }
  
  public boolean getSendStringParametersAsUnicode() {
    return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.toString(), SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.getDefaultValue());
  }

  
  public void setServerNameAsACE(boolean paramBoolean) {
    setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE.toString(), paramBoolean);
  }
  
  public boolean getServerNameAsACE() {
    return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE.toString(), SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE.getDefaultValue());
  }


  
  public void setServerName(String paramString) {
    setStringProperty(this.connectionProps, SQLServerDriverStringProperty.SERVER_NAME.toString(), paramString);
  }
  
  public String getServerName() {
    return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.SERVER_NAME.toString(), null);
  }


  
  public void setServerSpn(String paramString) {
    setStringProperty(this.connectionProps, SQLServerDriverStringProperty.SERVER_SPN.toString(), paramString);
  }
  
  public String getServerSpn() {
    return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.SERVER_SPN.toString(), null);
  }


  
  public void setFailoverPartner(String paramString) {
    setStringProperty(this.connectionProps, SQLServerDriverStringProperty.FAILOVER_PARTNER.toString(), paramString);
  }


  
  public String getFailoverPartner() {
    return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.FAILOVER_PARTNER.toString(), null);
  }

  
  public void setMultiSubnetFailover(boolean paramBoolean) {
    setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.toString(), paramBoolean);
  }

  
  public boolean getMultiSubnetFailover() {
    return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.toString(), SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.getDefaultValue());
  }



  
  public void setUser(String paramString) {
    setStringProperty(this.connectionProps, SQLServerDriverStringProperty.USER.toString(), paramString);
  }
  
  public String getUser() {
    return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.USER.toString(), null);
  }





  
  public void setWorkstationID(String paramString) {
    setStringProperty(this.connectionProps, SQLServerDriverStringProperty.WORKSTATION_ID.toString(), paramString);
  }
  
  public String getWorkstationID() {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getWorkstationID"); 
    String str = this.connectionProps.getProperty(SQLServerDriverStringProperty.WORKSTATION_ID.toString());
    
    if (null == str)
    {
      str = Util.lookupHostName();
    }
    loggerExternal.exiting(getClassNameLogging(), "getWorkstationID", str);
    return str;
  }





  
  public void setXopenStates(boolean paramBoolean) {
    setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.XOPEN_STATES.toString(), paramBoolean);
  }
  
  public boolean getXopenStates() {
    return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.XOPEN_STATES.toString(), SQLServerDriverBooleanProperty.XOPEN_STATES.getDefaultValue());
  }














  
  public void setURL(String paramString) {
    loggerExternal.entering(getClassNameLogging(), "setURL", paramString);
    
    this.dataSourceURL = paramString;
    loggerExternal.exiting(getClassNameLogging(), "setURL");
  }
  
  public String getURL() {
    String str = this.dataSourceURL;
    loggerExternal.entering(getClassNameLogging(), "getURL");
    
    if (null == this.dataSourceURL)
      str = "jdbc:sqlserver://"; 
    loggerExternal.exiting(getClassNameLogging(), "getURL", str);
    return str;
  }





  
  public void setDescription(String paramString) {
    loggerExternal.entering(getClassNameLogging(), "setDescription", paramString);
    this.dataSourceDescription = paramString;
    loggerExternal.exiting(getClassNameLogging(), "setDescription");
  }
  
  public String getDescription() {
    loggerExternal.entering(getClassNameLogging(), "getDescription");
    loggerExternal.exiting(getClassNameLogging(), "getDescription", this.dataSourceDescription);
    return this.dataSourceDescription;
  }





  
  public void setPacketSize(int paramInt) {
    setIntProperty(this.connectionProps, SQLServerDriverIntProperty.PACKET_SIZE.toString(), paramInt);
  }
  
  public int getPacketSize() {
    return getIntProperty(this.connectionProps, SQLServerDriverIntProperty.PACKET_SIZE.toString(), SQLServerDriverIntProperty.PACKET_SIZE.getDefaultValue());
  }
























  
  private void setStringProperty(Properties paramProperties, String paramString1, String paramString2) {
    if (loggerExternal.isLoggable(Level.FINER) && !paramString1.contains("password") && !paramString1.contains("Password")) {
      
      loggerExternal.entering(getClassNameLogging(), "set" + paramString1, paramString2);
    } else {
      
      loggerExternal.entering(getClassNameLogging(), "set" + paramString1);
    }  if (null != paramString2)
      paramProperties.setProperty(paramString1, paramString2); 
    loggerExternal.exiting(getClassNameLogging(), "set" + paramString1);
  }




  
  private String getStringProperty(Properties paramProperties, String paramString1, String paramString2) {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "get" + paramString1); 
    String str = paramProperties.getProperty(paramString1);
    if (null == str)
      str = paramString2; 
    if (loggerExternal.isLoggable(Level.FINER) && !paramString1.contains("password") && !paramString1.contains("Password"))
      loggerExternal.exiting(getClassNameLogging(), "get" + paramString1, str); 
    return str;
  }



  
  private void setIntProperty(Properties paramProperties, String paramString, int paramInt) {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "set" + paramString, new Integer(paramInt)); 
    paramProperties.setProperty(paramString, (new Integer(paramInt)).toString());
    loggerExternal.exiting(getClassNameLogging(), "set" + paramString);
  }




  
  private int getIntProperty(Properties paramProperties, String paramString, int paramInt) {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "get" + paramString); 
    String str = paramProperties.getProperty(paramString);
    int i = paramInt;
    if (null != str) {
      
      try {
        
        i = Integer.parseInt(str);
      }
      catch (NumberFormatException numberFormatException) {


        
        assert false : "Bad portNumber:-" + str;
      } 
    }
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.exiting(getClassNameLogging(), "get" + paramString, new Integer(i)); 
    return i;
  }



  
  private void setBooleanProperty(Properties paramProperties, String paramString, boolean paramBoolean) {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "set" + paramString, Boolean.valueOf(paramBoolean)); 
    paramProperties.setProperty(paramString, paramBoolean ? "true" : "false");
    loggerExternal.exiting(getClassNameLogging(), "set" + paramString);
  }



  
  private boolean getBooleanProperty(Properties paramProperties, String paramString, boolean paramBoolean) {
    Boolean bool;
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "get" + paramString); 
    String str = paramProperties.getProperty(paramString);
    
    if (null == str) {
      
      bool = Boolean.valueOf(paramBoolean);
    
    }
    else {

      
      bool = Boolean.valueOf(str);
    } 
    loggerExternal.exiting(getClassNameLogging(), "get" + paramString, bool);
    return bool.booleanValue();
  }











  
  SQLServerConnection getConnectionInternal(String paramString1, String paramString2, SQLServerPooledConnection paramSQLServerPooledConnection) throws SQLServerException {
    Properties properties1 = null;
    Properties properties2 = null;
    
    if (this.trustStorePasswordStripped) {
      SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_referencingFailedTSP"), null, true);
    }


    
    if (null != paramString1 || null != paramString2) {
      
      properties1 = (Properties)this.connectionProps.clone();



      
      properties1.remove(SQLServerDriverStringProperty.USER.toString());
      properties1.remove(SQLServerDriverStringProperty.PASSWORD.toString());
      
      if (null != paramString1)
        properties1.put(SQLServerDriverStringProperty.USER.toString(), paramString1); 
      if (null != paramString2) {
        properties1.put(SQLServerDriverStringProperty.PASSWORD.toString(), paramString2);
      }
    } else {
      
      properties1 = this.connectionProps;
    } 

    
    if (null != this.dataSourceURL) {
      
      Properties properties = Util.parseUrl(this.dataSourceURL, dsLogger);
      
      if (null == properties) {
        SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
      }
      
      properties2 = SQLServerDriver.mergeURLAndSuppliedProperties(properties, properties1);
    }
    else {
      
      properties2 = properties1;
    } 

    
    if (dsLogger.isLoggable(Level.FINER))
      dsLogger.finer(toString() + " Begin create new connection."); 
    SQLServerConnection sQLServerConnection = new SQLServerConnection(toString());
    sQLServerConnection.connect(properties2, paramSQLServerPooledConnection);
    if (dsLogger.isLoggable(Level.FINER))
      dsLogger.finer(toString() + " End create new connection " + sQLServerConnection.toString()); 
    return sQLServerConnection;
  }



  
  public Reference getReference() {
    loggerExternal.entering(getClassNameLogging(), "getReference");
    Reference reference = getReferenceInternal("com.microsoft.sqlserver.jdbc.SQLServerDataSource");
    loggerExternal.exiting(getClassNameLogging(), "getReference", reference);
    return reference;
  }

  
  Reference getReferenceInternal(String paramString) {
    if (dsLogger.isLoggable(Level.FINER)) {
      dsLogger.finer(toString() + " creating reference for " + paramString + ".");
    }
    Reference reference = new Reference(getClass().getName(), "com.microsoft.sqlserver.jdbc.SQLServerDataSourceObjectFactory", null);
    
    if (null != paramString) {
      reference.add(new StringRefAddr("class", paramString));
    }
    if (this.trustStorePasswordStripped) {
      reference.add(new StringRefAddr("trustStorePasswordStripped", "true"));
    }
    
    Enumeration<String> enumeration = this.connectionProps.keys();
    while (enumeration.hasMoreElements()) {
      
      String str = enumeration.nextElement();
      
      if (str.equals(SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString())) {

        
        assert !this.trustStorePasswordStripped;
        reference.add(new StringRefAddr("trustStorePasswordStripped", "true"));
        
        continue;
      } 
      
      if (!str.contains(SQLServerDriverStringProperty.PASSWORD.toString())) {
        reference.add(new StringRefAddr(str, this.connectionProps.getProperty(str)));
      }
    } 

    
    if (null != this.dataSourceURL) {
      reference.add(new StringRefAddr("dataSourceURL", this.dataSourceURL));
    }
    if (null != this.dataSourceDescription) {
      reference.add(new StringRefAddr("dataSourceDescription", this.dataSourceDescription));
    }
    return reference;
  }




  
  void initializeFromReference(Reference paramReference) {
    Enumeration<RefAddr> enumeration = paramReference.getAll();
    while (enumeration.hasMoreElements()) {
      
      StringRefAddr stringRefAddr = (StringRefAddr)enumeration.nextElement();
      String str1 = stringRefAddr.getType();
      String str2 = (String)stringRefAddr.getContent();

      
      if (str1.equals("dataSourceURL")) {
        
        this.dataSourceURL = str2; continue;
      } 
      if (str1.equals("dataSourceDescription")) {
        
        this.dataSourceDescription = str2; continue;
      } 
      if (str1.equals("trustStorePasswordStripped")) {
        
        this.trustStorePasswordStripped = true;
        continue;
      } 
      if (false == str1.equals("class"))
      {
        
        this.connectionProps.setProperty(str1, str2);
      }
    } 
  }

  
  public boolean isWrapperFor(Class<?> paramClass) throws SQLException {
    loggerExternal.entering(getClassNameLogging(), "isWrapperFor", paramClass);
    DriverJDBCVersion.checkSupportsJDBC4();
    boolean bool = paramClass.isInstance(this);
    loggerExternal.exiting(getClassNameLogging(), "isWrapperFor", Boolean.valueOf(bool));
    return bool;
  }
  
  public <T> T unwrap(Class<T> paramClass) throws SQLException {
    T t;
    loggerExternal.entering(getClassNameLogging(), "unwrap", paramClass);
    DriverJDBCVersion.checkSupportsJDBC4();


    
    try {
      t = paramClass.cast(this);
    }
    catch (ClassCastException classCastException) {
      
      throw new SQLServerException(classCastException.getMessage(), classCastException);
    } 
    loggerExternal.exiting(getClassNameLogging(), "unwrap", t);
    return t;
  }


  
  private static synchronized int nextDataSourceID() {
    baseDataSourceID++;
    return baseDataSourceID;
  }
  
  private Object writeReplace() throws ObjectStreamException {
    return new SerializationProxy(this);
  }






  
  private void readObject(ObjectInputStream paramObjectInputStream) throws InvalidObjectException {
    throw new InvalidObjectException("");
  }


  
  private static class SerializationProxy
    implements Serializable
  {
    private final Reference ref;
    
    private static final long serialVersionUID = 654661379542314226L;

    
    SerializationProxy(SQLServerDataSource param1SQLServerDataSource) {
      this.ref = param1SQLServerDataSource.getReferenceInternal(null);
    }
    
    private Object readResolve() {
      SQLServerDataSource sQLServerDataSource = new SQLServerDataSource();
      sQLServerDataSource.initializeFromReference(this.ref);
      return sQLServerDataSource;
    }
  }
}
