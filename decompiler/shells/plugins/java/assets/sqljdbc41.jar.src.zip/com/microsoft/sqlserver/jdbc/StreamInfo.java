package com.microsoft.sqlserver.jdbc;

final class StreamInfo
  extends StreamPacket {
  final StreamError msg = new StreamError();

  
  StreamInfo() {
    super(171);
  }

  
  void setFromTDS(TDSReader paramTDSReader) throws SQLServerException {
    if (171 != paramTDSReader.readUnsignedByte() && !$assertionsDisabled) throw new AssertionError(); 
    this.msg.setContentsFromTDS(paramTDSReader);
  }
}
