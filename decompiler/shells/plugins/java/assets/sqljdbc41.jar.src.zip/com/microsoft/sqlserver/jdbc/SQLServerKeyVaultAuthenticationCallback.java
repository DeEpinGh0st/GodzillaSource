package com.microsoft.sqlserver.jdbc;

public interface SQLServerKeyVaultAuthenticationCallback {
  String getAccessToken(String paramString1, String paramString2, String paramString3);
}
