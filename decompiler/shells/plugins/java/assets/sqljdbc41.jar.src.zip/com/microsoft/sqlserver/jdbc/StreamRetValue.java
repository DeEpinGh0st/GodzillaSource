package com.microsoft.sqlserver.jdbc;







final class StreamRetValue
  extends StreamPacket
{
  private String paramName;
  private int ordinalOrLength;
  private int status;
  
  final int getOrdinalOrLength() {
    return this.ordinalOrLength;
  }







  
  StreamRetValue() {
    super(172);
  }

  
  void setFromTDS(TDSReader paramTDSReader) throws SQLServerException {
    if (172 != paramTDSReader.readUnsignedByte() && !$assertionsDisabled) throw new AssertionError(); 
    this.ordinalOrLength = paramTDSReader.readUnsignedShort();
    this.paramName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
    this.status = paramTDSReader.readUnsignedByte();
  }

  
  CryptoMetadata getCryptoMetadata(TDSReader paramTDSReader) throws SQLServerException {
    return (new StreamColumns()).readCryptoMetadata(paramTDSReader);
  }
}
