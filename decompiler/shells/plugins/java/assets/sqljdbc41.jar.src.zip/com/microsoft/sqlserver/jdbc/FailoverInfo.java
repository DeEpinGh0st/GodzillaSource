package com.microsoft.sqlserver.jdbc;

import java.text.MessageFormat;
import java.util.logging.Level;









final class FailoverInfo
{
  private String failoverPartner;
  private int portNumber;
  private String failoverInstance;
  private boolean setUpInfocalled;
  private boolean useFailoverPartner;
  
  boolean getUseFailoverPartner() {
    return this.useFailoverPartner;
  }

  
  FailoverInfo(String paramString, SQLServerConnection paramSQLServerConnection, boolean paramBoolean) {
    this.failoverPartner = paramString;
    this.useFailoverPartner = paramBoolean;
    this.portNumber = -1;
  }


  
  void log(SQLServerConnection paramSQLServerConnection) {
    if (paramSQLServerConnection.getConnectionLogger().isLoggable(Level.FINE)) {
      paramSQLServerConnection.getConnectionLogger().fine(paramSQLServerConnection.toString() + " Failover server :" + this.failoverPartner + " Failover partner is primary : " + this.useFailoverPartner);
    }
  }



  
  private void setupInfo(SQLServerConnection paramSQLServerConnection) throws SQLServerException {
    if (this.setUpInfocalled) {
      return;
    }
    if (0 == this.failoverPartner.length()) {
      
      this.portNumber = SQLServerConnection.DEFAULTPORT;
    
    }
    else {
      
      int i = this.failoverPartner.indexOf('\\');
      String str1 = null;
      String str2 = null;

      
      if (i >= 0) {
        
        if (paramSQLServerConnection.getConnectionLogger().isLoggable(Level.FINE))
          paramSQLServerConnection.getConnectionLogger().fine(paramSQLServerConnection.toString() + " Failover server :" + this.failoverPartner); 
        str2 = this.failoverPartner.substring(i + 1, this.failoverPartner.length());
        this.failoverPartner = this.failoverPartner.substring(0, i);
        paramSQLServerConnection.ValidateMaxSQLLoginName(SQLServerDriverStringProperty.INSTANCE_NAME.toString(), str2);
        this.failoverInstance = str2;
        str1 = paramSQLServerConnection.getInstancePort(this.failoverPartner, str2);

        
        try {
          this.portNumber = (new Integer(str1)).intValue();
        }
        catch (NumberFormatException numberFormatException) {

          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPortNumber"));
          Object[] arrayOfObject = { str1 };
          SQLServerException.makeFromDriverError(paramSQLServerConnection, null, messageFormat.format(arrayOfObject), null, false);
        } 
      } else {
        
        this.portNumber = SQLServerConnection.DEFAULTPORT;
      } 
    }  this.setUpInfocalled = true;
  }

  
  synchronized ServerPortPlaceHolder failoverPermissionCheck(SQLServerConnection paramSQLServerConnection, boolean paramBoolean) throws SQLServerException {
    setupInfo(paramSQLServerConnection);
    return new ServerPortPlaceHolder(this.failoverPartner, this.portNumber, this.failoverInstance, paramBoolean);
  }


  
  synchronized void failoverAdd(SQLServerConnection paramSQLServerConnection, boolean paramBoolean, String paramString) throws SQLServerException {
    if (this.useFailoverPartner != paramBoolean) {
      
      if (paramSQLServerConnection.getConnectionLogger().isLoggable(Level.FINE))
        paramSQLServerConnection.getConnectionLogger().fine(paramSQLServerConnection.toString() + " Failover detected. failover partner=" + paramString); 
      this.useFailoverPartner = paramBoolean;
    } 



    
    if (!paramBoolean && !this.failoverPartner.equals(paramString)) {
      
      this.failoverPartner = paramString;
      
      this.setUpInfocalled = false;
    } 
  }
}
