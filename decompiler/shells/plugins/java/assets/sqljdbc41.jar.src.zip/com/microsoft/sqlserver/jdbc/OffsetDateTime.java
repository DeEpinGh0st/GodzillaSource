package com.microsoft.sqlserver.jdbc;


























































































final class OffsetDateTime
  extends TemporalCompatibility
{
  public static OffsetDateTime parse(String paramString, DateTimeFormatter paramDateTimeFormatter) throws SQLServerException {
    SQLServerException.makeFromDriverError(null, null, null, null, false);
    return null;
  }
  
  public static OffsetDateTime parse(String paramString) throws SQLServerException {
    SQLServerException.makeFromDriverError(null, null, null, null, false);
    return null;
  }
}
