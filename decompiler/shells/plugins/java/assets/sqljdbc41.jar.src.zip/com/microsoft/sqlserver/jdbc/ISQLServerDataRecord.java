package com.microsoft.sqlserver.jdbc;

public interface ISQLServerDataRecord {
  SQLServerMetaData getColumnMetaData(int paramInt);
  
  int getColumnCount();
  
  Object[] getRowData();
  
  boolean next();
}
