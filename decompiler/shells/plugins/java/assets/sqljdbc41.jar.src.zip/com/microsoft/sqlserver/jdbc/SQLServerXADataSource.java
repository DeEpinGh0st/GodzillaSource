package com.microsoft.sqlserver.jdbc;

import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Reference;
import javax.sql.XAConnection;
import javax.sql.XADataSource;



























public final class SQLServerXADataSource
  extends SQLServerConnectionPoolDataSource
  implements XADataSource
{
  static Logger xaLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.XA");

  
  public XAConnection getXAConnection(String paramString1, String paramString2) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getXAConnection", new Object[] { paramString1, "Password not traced" }); 
    SQLServerXAConnection sQLServerXAConnection = new SQLServerXAConnection(this, paramString1, paramString2);
    
    if (xaLogger.isLoggable(Level.FINER)) {
      xaLogger.finer(toString() + " user:" + paramString1 + sQLServerXAConnection.toString());
    }




    
    if (xaLogger.isLoggable(Level.FINER))
      xaLogger.finer(toString() + " Start get physical connection."); 
    SQLServerConnection sQLServerConnection = sQLServerXAConnection.getPhysicalConnection();
    if (xaLogger.isLoggable(Level.FINE))
      xaLogger.fine(toString() + " End get physical connection, " + sQLServerConnection.toString()); 
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.exiting(getClassNameLogging(), "getXAConnection", sQLServerXAConnection); 
    return sQLServerXAConnection;
  }










  
  public XAConnection getXAConnection() throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getXAConnection"); 
    return getXAConnection(getUser(), getPassword());
  }



  
  public Reference getReference() {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getReference"); 
    Reference reference = getReferenceInternal("com.microsoft.sqlserver.jdbc.SQLServerXADataSource");
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.exiting(getClassNameLogging(), "getReference", reference); 
    return reference;
  }
  
  private Object writeReplace() throws ObjectStreamException {
    return new SerializationProxy(this);
  }






  
  private void readObject(ObjectInputStream paramObjectInputStream) throws InvalidObjectException {
    throw new InvalidObjectException("");
  }


  
  private static class SerializationProxy
    implements Serializable
  {
    private final Reference ref;
    
    private static final long serialVersionUID = 454661379842314126L;

    
    SerializationProxy(SQLServerXADataSource param1SQLServerXADataSource) {
      this.ref = param1SQLServerXADataSource.getReferenceInternal(null);
    }
    
    private Object readResolve() {
      SQLServerXADataSource sQLServerXADataSource = new SQLServerXADataSource();
      sQLServerXADataSource.initializeFromReference(this.ref);
      return sQLServerXADataSource;
    }
  }
}
