package com.microsoft.sqlserver.jdbc;

import java.text.MessageFormat;
import java.util.EnumMap;
import java.util.EnumSet;
































































































































































































































































































































































































































































































































































































































































































































































































































enum JDBCType
{
  UNKNOWN(Category.UNKNOWN, 999, "java.lang.Object"),
  ARRAY(Category.UNKNOWN, 2003, "java.lang.Object"),
  BIGINT(Category.NUMERIC, -5, "java.lang.Long"),
  BINARY(Category.BINARY, -2, "[B"),
  BIT(Category.NUMERIC, -7, "java.lang.Boolean"),
  BLOB(Category.BLOB, 2004, "java.sql.Blob"),
  BOOLEAN(Category.NUMERIC, 16, "java.lang.Boolean"),
  CHAR(Category.CHARACTER, 1, "java.lang.String"),
  CLOB(Category.CLOB, 2005, "java.sql.Clob"),
  DATALINK(Category.UNKNOWN, 70, "java.lang.Object"),
  DATE(Category.DATE, 91, "java.sql.Date"),
  DATETIMEOFFSET(Category.DATETIMEOFFSET, -155, "microsoft.sql.DateTimeOffset"),
  DECIMAL(Category.NUMERIC, 3, "java.math.BigDecimal"),
  DISTINCT(Category.UNKNOWN, 2001, "java.lang.Object"),
  DOUBLE(Category.NUMERIC, 8, "java.lang.Double"),
  FLOAT(Category.NUMERIC, 6, "java.lang.Double"),
  INTEGER(Category.NUMERIC, 4, "java.lang.Integer"),
  JAVA_OBJECT(Category.UNKNOWN, 2000, "java.lang.Object"),
  LONGNVARCHAR(Category.LONG_NCHARACTER, -16, "java.lang.String"),
  LONGVARBINARY(Category.LONG_BINARY, -4, "[B"),
  LONGVARCHAR(Category.LONG_CHARACTER, -1, "java.lang.String"),
  NCHAR(Category.NCHARACTER, -15, "java.lang.String"),
  NCLOB(Category.NCLOB, 2011, "java.sql.NClob"),
  NULL(Category.UNKNOWN, 0, "java.lang.Object"),
  NUMERIC(Category.NUMERIC, 2, "java.math.BigDecimal"),
  NVARCHAR(Category.NCHARACTER, -9, "java.lang.String"),
  OTHER(Category.UNKNOWN, 1111, "java.lang.Object"),
  REAL(Category.NUMERIC, 7, "java.lang.Float"),
  REF(Category.UNKNOWN, 2006, "java.lang.Object"),
  ROWID(Category.UNKNOWN, -8, "java.lang.Object"),
  SMALLINT(Category.NUMERIC, 5, "java.lang.Short"),
  SQLXML(Category.SQLXML, 2009, "java.lang.Object"),
  STRUCT(Category.UNKNOWN, 2002, "java.lang.Object"),
  TIME(Category.TIME, 92, "java.sql.Time"),
  TIME_WITH_TIMEZONE(Category.TIME_WITH_TIMEZONE, 2013, "java.time.OffsetTime"),
  
  TIMESTAMP(Category.TIMESTAMP, 93, "java.sql.Timestamp"),
  TIMESTAMP_WITH_TIMEZONE(Category.TIMESTAMP_WITH_TIMEZONE, 2014, "java.time.OffsetDateTime"),
  
  TINYINT(Category.NUMERIC, -6, "java.lang.Short"),
  VARBINARY(Category.BINARY, -3, "[B"),
  VARCHAR(Category.CHARACTER, 12, "java.lang.String"),
  MONEY(Category.NUMERIC, -148, "java.math.BigDecimal"),
  SMALLMONEY(Category.NUMERIC, -146, "java.math.BigDecimal"),
  TVP(Category.TVP, -153, "java.lang.Object"),
  DATETIME(Category.TIMESTAMP, -151, "java.sql.Timestamp"),
  SMALLDATETIME(Category.TIMESTAMP, -150, "java.sql.Timestamp"),
  GUID(Category.CHARACTER, -145, "java.lang.String"); final Category category;
  private final int intValue;
  private final String className;
  
  final String className() {
    return this.className;
  }
  private static final EnumSet<JDBCType> signedTypes; private static final EnumSet<JDBCType> binaryTypes; private static final EnumSet<Category> textualCategories;
  JDBCType(Category paramCategory, int paramInt1, String paramString1) {
    this.category = paramCategory;
    this.intValue = paramInt1;
    this.className = paramString1;
  }

  
  public int getIntValue() {
    return this.intValue;
  }
  
  enum Category
  {
    CHARACTER,
    LONG_CHARACTER,
    CLOB,
    NCHARACTER,
    LONG_NCHARACTER,
    NCLOB,
    BINARY,
    LONG_BINARY,
    BLOB,
    NUMERIC,
    DATE,
    TIME,
    TIMESTAMP,
    TIME_WITH_TIMEZONE,
    TIMESTAMP_WITH_TIMEZONE,
    DATETIMEOFFSET,
    SQLXML,
    UNKNOWN,
    TVP,
    GUID;
  }

  
  enum SetterConversion
  {
    CHARACTER((String)JDBCType.Category.CHARACTER, EnumSet.of(JDBCType.Category.NUMERIC, new JDBCType.Category[] { JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.DATETIMEOFFSET, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY, JDBCType.Category.GUID













        
        })),
    LONG_CHARACTER((String)JDBCType.Category.LONG_CHARACTER, EnumSet.of(JDBCType.Category.CHARACTER, new JDBCType.Category[] { JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY







        
        })),
    CLOB((String)JDBCType.Category.CLOB, EnumSet.of(JDBCType.Category.CLOB, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.LONG_NCHARACTER)),





    
    NCHARACTER((String)JDBCType.Category.NCHARACTER, EnumSet.of(JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.NCLOB)),





    
    LONG_NCHARACTER((String)JDBCType.Category.LONG_NCHARACTER, EnumSet.of(JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER)),




    
    NCLOB((String)JDBCType.Category.NCLOB, EnumSet.of(JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.NCLOB)),




    
    BINARY((String)JDBCType.Category.BINARY, EnumSet.of(JDBCType.Category.NUMERIC, new JDBCType.Category[] { JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY, JDBCType.Category.BLOB, JDBCType.Category.GUID













        
        })),
    LONG_BINARY((String)JDBCType.Category.LONG_BINARY, EnumSet.of(JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY)),




    
    BLOB((String)JDBCType.Category.BLOB, EnumSet.of(JDBCType.Category.LONG_BINARY, JDBCType.Category.BLOB)),




    
    NUMERIC((String)JDBCType.Category.NUMERIC, EnumSet.of(JDBCType.Category.NUMERIC, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER)),







    
    DATE((String)JDBCType.Category.DATE, EnumSet.of(JDBCType.Category.DATE, new JDBCType.Category[] { JDBCType.Category.TIMESTAMP, JDBCType.Category.DATETIMEOFFSET, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER








        
        })),
    TIME((String)JDBCType.Category.TIME, EnumSet.of(JDBCType.Category.TIME, new JDBCType.Category[] { JDBCType.Category.TIMESTAMP, JDBCType.Category.DATETIMEOFFSET, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER








        
        })),
    TIMESTAMP((String)JDBCType.Category.TIMESTAMP, EnumSet.of(JDBCType.Category.DATE, new JDBCType.Category[] { JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.DATETIMEOFFSET, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER









        
        })),
    TIME_WITH_TIMEZONE((String)JDBCType.Category.TIME_WITH_TIMEZONE, EnumSet.of(JDBCType.Category.TIME_WITH_TIMEZONE, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER)),







    
    TIMESTAMP_WITH_TIMEZONE((String)JDBCType.Category.TIMESTAMP_WITH_TIMEZONE, EnumSet.of(JDBCType.Category.TIMESTAMP_WITH_TIMEZONE, new JDBCType.Category[] { JDBCType.Category.TIME_WITH_TIMEZONE, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER







        
        })),
    DATETIMEOFFSET((String)JDBCType.Category.DATETIMEOFFSET, EnumSet.of(JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.DATETIMEOFFSET)),






    
    SQLXML((String)JDBCType.Category.SQLXML, EnumSet.of(JDBCType.Category.SQLXML)),



    
    TVP((String)JDBCType.Category.TVP, EnumSet.of(JDBCType.Category.TVP));




    
    private final JDBCType.Category from;



    
    private final EnumSet<JDBCType.Category> to;



    
    private static final EnumMap<JDBCType.Category, EnumSet<JDBCType.Category>> conversionMap = new EnumMap<>(JDBCType.Category.class); SetterConversion(JDBCType.Category param1Category, EnumSet<JDBCType.Category> param1EnumSet) {
      this.from = param1Category;
      this.to = param1EnumSet;
    }
    static {
      for (JDBCType.Category category : JDBCType.Category.values()) {
        conversionMap.put(category, EnumSet.noneOf(JDBCType.Category.class));
      }
      for (SetterConversion setterConversion : values()) {
        ((EnumSet<JDBCType.Category>)conversionMap.get(setterConversion.from)).addAll(setterConversion.to);
      }
    }
    
    static boolean converts(JDBCType param1JDBCType1, JDBCType param1JDBCType2) {
      return ((EnumSet)conversionMap.get(param1JDBCType1.category)).contains(param1JDBCType2.category);
    }
  }

  
  boolean convertsTo(JDBCType paramJDBCType) {
    return SetterConversion.converts(this, paramJDBCType);
  }
  
  enum UpdaterConversion
  {
    CHARACTER((String)JDBCType.Category.CHARACTER, EnumSet.of(SSType.Category.NUMERIC, new SSType.Category[] { SSType.Category.DATE, SSType.Category.TIME, SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.XML, SSType.Category.BINARY, SSType.Category.LONG_BINARY, SSType.Category.UDT, SSType.Category.GUID, SSType.Category.TIMESTAMP

















        
        })),
    LONG_CHARACTER((String)JDBCType.Category.LONG_CHARACTER, EnumSet.of(SSType.Category.CHARACTER, new SSType.Category[] { SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.XML, SSType.Category.BINARY, SSType.Category.LONG_BINARY








        
        })),
    CLOB((String)JDBCType.Category.CLOB, EnumSet.of(SSType.Category.LONG_CHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.XML)),





    
    NCHARACTER((String)JDBCType.Category.NCHARACTER, EnumSet.of(SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.XML)),





    
    LONG_NCHARACTER((String)JDBCType.Category.LONG_NCHARACTER, EnumSet.of(SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.XML)),





    
    NCLOB((String)JDBCType.Category.NCLOB, EnumSet.of(SSType.Category.LONG_NCHARACTER, SSType.Category.XML)),




    
    BINARY((String)JDBCType.Category.BINARY, EnumSet.of(SSType.Category.NUMERIC, new SSType.Category[] { SSType.Category.DATETIME, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.XML, SSType.Category.BINARY, SSType.Category.LONG_BINARY, SSType.Category.UDT, SSType.Category.TIMESTAMP, SSType.Category.GUID













        
        })),
    LONG_BINARY((String)JDBCType.Category.LONG_BINARY, EnumSet.of(SSType.Category.XML, SSType.Category.BINARY, SSType.Category.LONG_BINARY, SSType.Category.UDT)),






    
    BLOB((String)JDBCType.Category.BLOB, EnumSet.of(SSType.Category.LONG_BINARY, SSType.Category.XML)),



    
    SQLXML((String)JDBCType.Category.SQLXML, EnumSet.of(SSType.Category.XML)),



    
    NUMERIC((String)JDBCType.Category.NUMERIC, EnumSet.of(SSType.Category.NUMERIC, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER)),







    
    DATE((String)JDBCType.Category.DATE, EnumSet.of(SSType.Category.DATE, new SSType.Category[] { SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER









        
        })),
    TIME((String)JDBCType.Category.TIME, EnumSet.of(SSType.Category.TIME, new SSType.Category[] { SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER









        
        })),
    TIMESTAMP((String)JDBCType.Category.TIMESTAMP, EnumSet.of(SSType.Category.DATE, new SSType.Category[] { SSType.Category.TIME, SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER










        
        })),
    DATETIMEOFFSET((String)JDBCType.Category.DATETIMEOFFSET, EnumSet.of(SSType.Category.DATE, new SSType.Category[] { SSType.Category.TIME, SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER










        
        })),
    TIME_WITH_TIMEZONE((String)JDBCType.Category.TIME_WITH_TIMEZONE, EnumSet.of(SSType.Category.TIME, new SSType.Category[] { SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER









        
        })),
    TIMESTAMP_WITH_TIMEZONE((String)JDBCType.Category.TIMESTAMP_WITH_TIMEZONE, EnumSet.of(SSType.Category.DATE, new SSType.Category[] { SSType.Category.TIME, SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER }));






    
    private final JDBCType.Category from;






    
    private final EnumSet<SSType.Category> to;






    
    private static final EnumMap<JDBCType.Category, EnumSet<SSType.Category>> conversionMap = new EnumMap<>(JDBCType.Category.class); UpdaterConversion(JDBCType.Category param1Category, EnumSet<SSType.Category> param1EnumSet) {
      this.from = param1Category;
      this.to = param1EnumSet;
    }
    static {
      for (JDBCType.Category category : JDBCType.Category.values()) {
        conversionMap.put(category, EnumSet.noneOf(SSType.Category.class));
      }
      for (UpdaterConversion updaterConversion : values()) {
        ((EnumSet<SSType.Category>)conversionMap.get(updaterConversion.from)).addAll(updaterConversion.to);
      }
    }
    
    static boolean converts(JDBCType param1JDBCType, SSType param1SSType) {
      return ((EnumSet)conversionMap.get(param1JDBCType.category)).contains(param1SSType.category);
    }
  }

  
  boolean convertsTo(SSType paramSSType) {
    return UpdaterConversion.converts(this, paramSSType);
  }

  
  static JDBCType of(int paramInt) throws SQLServerException {
    for (JDBCType jDBCType : values()) {
      if (jDBCType.intValue == paramInt)
        return jDBCType; 
    } 
    MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unknownJDBCType"));
    Object[] arrayOfObject = { Integer.valueOf(paramInt) };
    SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), null, true);
    return UNKNOWN;
  }



  
  static {
    signedTypes = EnumSet.of(SMALLINT, new JDBCType[] { INTEGER, BIGINT, REAL, FLOAT, DOUBLE, DECIMAL, NUMERIC, MONEY, SMALLMONEY });




















    
    binaryTypes = EnumSet.of(BINARY, VARBINARY, LONGVARBINARY, BLOB);



















    
    textualCategories = EnumSet.of(Category.CHARACTER, new Category[] { Category.LONG_CHARACTER, Category.CLOB, Category.NCHARACTER, Category.LONG_NCHARACTER, Category.NCLOB });
  }
  boolean isSigned() {
    return signedTypes.contains(this);
  }
  
  boolean isBinary() {
    return binaryTypes.contains(this);
  }
  
  boolean isTextual() {
    return textualCategories.contains(this.category);
  }






  
  boolean isUnsupported() {
    return (Category.UNKNOWN == this.category);
  }







  
  int asJavaSqlType() {
    if (Util.SYSTEM_SPEC_VERSION.equals("1.5")) {
      
      switch (this) {
        case NCHAR:
          return 1;
        case NVARCHAR: return 12;
        case LONGNVARCHAR: return -1;
        case NCLOB: return 2005;
        case ROWID: return 1111;
        case SQLXML: return 12;
      }  return this.intValue;
    } 


    
    return this.intValue;
  }




  
  enum NormalizationAE
  {
    CHARACTER_NORMALIZED_TO((String)JDBCType.CHAR, EnumSet.of(SSType.CHAR, SSType.VARCHAR, SSType.VARCHARMAX)),





    
    VARCHARACTER_NORMALIZED_TO((String)JDBCType.VARCHAR, EnumSet.of(SSType.CHAR, SSType.VARCHAR, SSType.VARCHARMAX)),





    
    LONGVARCHARACTER_NORMALIZED_TO((String)JDBCType.LONGVARCHAR, EnumSet.of(SSType.CHAR, SSType.VARCHAR, SSType.VARCHARMAX)),





    
    NCHAR_NORMALIZED_TO((String)JDBCType.NCHAR, EnumSet.of(SSType.NCHAR, SSType.NVARCHAR, SSType.NVARCHARMAX)),





    
    NVARCHAR_NORMALIZED_TO((String)JDBCType.NVARCHAR, EnumSet.of(SSType.NCHAR, SSType.NVARCHAR, SSType.NVARCHARMAX)),





    
    LONGNVARCHAR_NORMALIZED_TO((String)JDBCType.LONGNVARCHAR, EnumSet.of(SSType.NCHAR, SSType.NVARCHAR, SSType.NVARCHARMAX)),





    
    BIT_NORMALIZED_TO((String)JDBCType.BIT, EnumSet.of(SSType.BIT, SSType.TINYINT, SSType.SMALLINT, SSType.INTEGER, SSType.BIGINT)),







    
    TINYINT_NORMALIZED_TO((String)JDBCType.TINYINT, EnumSet.of(SSType.TINYINT, SSType.SMALLINT, SSType.INTEGER, SSType.BIGINT)),






    
    SMALLINT_NORMALIZED_TO((String)JDBCType.SMALLINT, EnumSet.of(SSType.SMALLINT, SSType.INTEGER, SSType.BIGINT)),





    
    INTEGER_NORMALIZED_TO((String)JDBCType.INTEGER, EnumSet.of(SSType.INTEGER, SSType.BIGINT)),




    
    BIGINT_NORMALIZED_TO((String)JDBCType.BIGINT, EnumSet.of(SSType.BIGINT)),



    
    BINARY_NORMALIZED_TO((String)JDBCType.BINARY, EnumSet.of(SSType.BINARY, SSType.VARBINARY, SSType.VARBINARYMAX)),





    
    VARBINARY_NORMALIZED_TO((String)JDBCType.VARBINARY, EnumSet.of(SSType.BINARY, SSType.VARBINARY, SSType.VARBINARYMAX)),





    
    LONGVARBINARY_NORMALIZED_TO((String)JDBCType.LONGVARBINARY, EnumSet.of(SSType.BINARY, SSType.VARBINARY, SSType.VARBINARYMAX)),





    
    FLOAT_NORMALIZED_TO((String)JDBCType.DOUBLE, EnumSet.of(SSType.FLOAT)),



    
    REAL_NORMALIZED_TO((String)JDBCType.REAL, EnumSet.of(SSType.REAL)),



    
    DECIMAL_NORMALIZED_TO((String)JDBCType.DECIMAL, EnumSet.of(SSType.DECIMAL, SSType.NUMERIC)),




    
    SMALLMONEY_NORMALIZED_TO((String)JDBCType.SMALLMONEY, EnumSet.of(SSType.SMALLMONEY, SSType.MONEY)),




    
    MONEY_NORMALIZED_TO((String)JDBCType.MONEY, EnumSet.of(SSType.MONEY)),



    
    NUMERIC_NORMALIZED_TO((String)JDBCType.NUMERIC, EnumSet.of(SSType.DECIMAL, SSType.NUMERIC)),




    
    DATE_NORMALIZED_TO((String)JDBCType.DATE, EnumSet.of(SSType.DATE)),



    
    TIME_NORMALIZED_TO((String)JDBCType.TIME, EnumSet.of(SSType.TIME)),



    
    DATETIME2_NORMALIZED_TO((String)JDBCType.TIMESTAMP, EnumSet.of(SSType.DATETIME2)),



    
    DATETIMEOFFSET_NORMALIZED_TO((String)JDBCType.DATETIMEOFFSET, EnumSet.of(SSType.DATETIMEOFFSET)),



    
    DATETIME_NORMALIZED_TO((String)JDBCType.DATETIME, EnumSet.of(SSType.DATETIME)),



    
    SMALLDATETIME_NORMALIZED_TO((String)JDBCType.SMALLDATETIME, EnumSet.of(SSType.SMALLDATETIME)),



    
    GUID_NORMALIZED_TO((String)JDBCType.GUID, EnumSet.of(SSType.GUID));




    
    private final JDBCType from;




    
    private final EnumSet<SSType> to;



    
    private static final EnumMap<JDBCType, EnumSet<SSType>> normalizationMapAE = new EnumMap<>(JDBCType.class); NormalizationAE(JDBCType param1JDBCType, EnumSet<SSType> param1EnumSet) {
      this.from = param1JDBCType;
      this.to = param1EnumSet;
    }
    static {
      for (JDBCType jDBCType : JDBCType.values()) {
        normalizationMapAE.put(jDBCType, EnumSet.noneOf(SSType.class));
      }
      for (NormalizationAE normalizationAE : values()) {
        ((EnumSet<SSType>)normalizationMapAE.get(normalizationAE.from)).addAll(normalizationAE.to);
      }
    }
    
    static boolean converts(JDBCType param1JDBCType, SSType param1SSType) {
      return ((EnumSet)normalizationMapAE.get(param1JDBCType)).contains(param1SSType);
    }
  }

  
  boolean normalizationCheck(SSType paramSSType) {
    return NormalizationAE.converts(this, paramSSType);
  }
}
