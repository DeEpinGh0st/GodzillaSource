package com.microsoft.sqlserver.jdbc;

import java.util.logging.Level;
import java.util.logging.Logger;










class CacheClear
  implements Runnable
{
  private String keylookupValue;
  private static Logger aeLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.CacheClear");


  
  CacheClear(String paramString) {
    this.keylookupValue = paramString;
  }



  
  public void run() {
    synchronized (SQLServerSymmetricKeyCache.lock) {
      
      SQLServerSymmetricKeyCache sQLServerSymmetricKeyCache = SQLServerSymmetricKeyCache.getInstance();
      if (sQLServerSymmetricKeyCache.getCache().containsKey(this.keylookupValue)) {
        
        ((SQLServerSymmetricKey)sQLServerSymmetricKeyCache.getCache().get(this.keylookupValue)).zeroOutKey();
        sQLServerSymmetricKeyCache.getCache().remove(this.keylookupValue);
        if (aeLogger.isLoggable(Level.FINE))
        {
          aeLogger.fine("Removed encryption key from cache...");
        }
      } 
    } 
  }
}
