package com.microsoft.sqlserver.jdbc;

abstract class ColumnFilter {
  abstract Object apply(Object paramObject, JDBCType paramJDBCType) throws SQLServerException;
}
