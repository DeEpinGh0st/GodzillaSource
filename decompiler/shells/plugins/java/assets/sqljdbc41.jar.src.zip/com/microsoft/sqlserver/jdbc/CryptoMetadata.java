package com.microsoft.sqlserver.jdbc;





























































































































































class CryptoMetadata
{
  TypeInfo baseTypeInfo;
  CekTableEntry cekTableEntry;
  byte cipherAlgorithmId;
  String cipherAlgorithmName;
  SQLServerEncryptionType encryptionType;
  byte normalizationRuleVersion;
  SQLServerEncryptionAlgorithm cipherAlgorithm = null;
  EncryptionKeyInfo encryptionKeyInfo;
  short ordinal;
  
  CekTableEntry getCekTableEntry() {
    return this.cekTableEntry;
  }
  
  void setCekTableEntry(CekTableEntry paramCekTableEntry) {
    this.cekTableEntry = paramCekTableEntry;
  }
  
  TypeInfo getBaseTypeInfo() {
    return this.baseTypeInfo;
  }
  
  void setBaseTypeInfo(TypeInfo paramTypeInfo) {
    this.baseTypeInfo = paramTypeInfo;
  }
  
  SQLServerEncryptionAlgorithm getEncryptionAlgorithm() {
    return this.cipherAlgorithm;
  }
  
  void setEncryptionAlgorithm(SQLServerEncryptionAlgorithm paramSQLServerEncryptionAlgorithm) {
    this.cipherAlgorithm = paramSQLServerEncryptionAlgorithm;
  }
  
  EncryptionKeyInfo getEncryptionKeyInfo() {
    return this.encryptionKeyInfo;
  }
  
  void setEncryptionKeyInfo(EncryptionKeyInfo paramEncryptionKeyInfo) {
    this.encryptionKeyInfo = paramEncryptionKeyInfo;
  }
  
  byte getEncryptionAlgorithmId() {
    return this.cipherAlgorithmId;
  }
  
  String getEncryptionAlgorithmName() {
    return this.cipherAlgorithmName;
  }
  
  SQLServerEncryptionType getEncryptionType() {
    return this.encryptionType;
  }
  
  byte getNormalizationRuleVersion() {
    return this.normalizationRuleVersion;
  }
  
  short getOrdinal() {
    return this.ordinal;
  }






  
  CryptoMetadata(CekTableEntry paramCekTableEntry, short paramShort, byte paramByte1, String paramString, byte paramByte2, byte paramByte3) throws SQLServerException {
    this.cekTableEntry = paramCekTableEntry;
    this.ordinal = paramShort;
    this.cipherAlgorithmId = paramByte1;
    this.cipherAlgorithmName = paramString;
    this.encryptionType = SQLServerEncryptionType.of(paramByte2);
    this.normalizationRuleVersion = paramByte3;
    this.encryptionKeyInfo = null;
  }
  
  boolean IsAlgorithmInitialized() {
    return (null != this.cipherAlgorithm);
  }
}
