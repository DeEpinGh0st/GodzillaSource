package com.microsoft.sqlserver.jdbc;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.MessageFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;
import microsoft.sql.DateTimeOffset;








final class DDC
{
  static final Object convertIntegerToObject(int paramInt1, int paramInt2, JDBCType paramJDBCType, StreamType paramStreamType) {
    switch (paramJDBCType) {
      
      case BINARY:
        return new Integer(paramInt1);
      case DATE:
      case TIME:
        return new Short((short)paramInt1);
      case TIMESTAMP:
      case DATETIMEOFFSET:
        return new Boolean((0 != paramInt1));
      case CHARACTER:
        return new Long(paramInt1);
      case null:
      case null:
      case null:
      case null:
        return new BigDecimal(Integer.toString(paramInt1));
      case null:
      case null:
        return new Double(paramInt1);
      case null:
        return new Float(paramInt1);
      case null:
        return convertIntToBytes(paramInt1, paramInt2);
    } 
    return Integer.toString(paramInt1);
  }





  
  static final Object convertLongToObject(long paramLong, JDBCType paramJDBCType, SSType paramSSType, StreamType paramStreamType) {
    byte[] arrayOfByte1;
    byte b;
    byte[] arrayOfByte2;
    switch (paramJDBCType) {
      
      case CHARACTER:
        return new Long(paramLong);
      case BINARY:
        return new Integer((int)paramLong);
      case DATE:
      case TIME:
        return new Short((short)(int)paramLong);
      case TIMESTAMP:
      case DATETIMEOFFSET:
        return new Boolean((0L != paramLong));
      case null:
      case null:
      case null:
      case null:
        return new BigDecimal(Long.toString(paramLong));
      case null:
      case null:
        return new Double(paramLong);
      case null:
        return new Float((float)paramLong);
      case null:
        arrayOfByte1 = convertLongToBytes(paramLong);
        b = 0;

        
        switch (paramSSType) {
          case BINARY:
          case DATE:
            b = 1;
            arrayOfByte2 = new byte[b];
            System.arraycopy(arrayOfByte1, arrayOfByte1.length - b, arrayOfByte2, 0, b);
            return arrayOfByte2;
          case TIME:
            b = 2;
            arrayOfByte2 = new byte[b];
            System.arraycopy(arrayOfByte1, arrayOfByte1.length - b, arrayOfByte2, 0, b);
            return arrayOfByte2;
          case TIMESTAMP:
            b = 4;
            arrayOfByte2 = new byte[b];
            System.arraycopy(arrayOfByte1, arrayOfByte1.length - b, arrayOfByte2, 0, b);
            return arrayOfByte2;
          case DATETIMEOFFSET:
            b = 8;
            arrayOfByte2 = new byte[b];
            System.arraycopy(arrayOfByte1, arrayOfByte1.length - b, arrayOfByte2, 0, b);
            return arrayOfByte2;
        } 
        return arrayOfByte1;

      
      case null:
        switch (paramSSType) {
          
          case DATETIMEOFFSET:
            return new Long(paramLong);
          case TIMESTAMP:
            return new Integer((int)paramLong);
          case DATE:
          case TIME:
            return new Short((short)(int)paramLong);
          case BINARY:
            return new Boolean((0L != paramLong));
          case CHARACTER:
          case null:
          case null:
          case null:
            return new BigDecimal(Long.toString(paramLong));
          case null:
            return new Double(paramLong);
          case null:
            return new Float((float)paramLong);
          case null:
            return convertLongToBytes(paramLong);
        } 
        return Long.toString(paramLong);
    } 
    
    return Long.toString(paramLong);
  }








  
  static final byte[] convertIntToBytes(int paramInt1, int paramInt2) {
    byte[] arrayOfByte = new byte[paramInt2];
    for (int i = paramInt2; i-- > 0; ) {
      
      arrayOfByte[i] = (byte)(paramInt1 & 0xFF);
      paramInt1 >>= 8;
    } 
    return arrayOfByte;
  }







  
  static final Object convertFloatToObject(float paramFloat, JDBCType paramJDBCType, StreamType paramStreamType) {
    switch (paramJDBCType) {
      
      case null:
        return new Float(paramFloat);
      case BINARY:
        return new Integer((int)paramFloat);
      case DATE:
      case TIME:
        return new Short((short)(int)paramFloat);
      case TIMESTAMP:
      case DATETIMEOFFSET:
        return new Boolean((0 != Float.compare(0.0F, paramFloat)));
      case CHARACTER:
        return new Long((long)paramFloat);
      case null:
      case null:
      case null:
      case null:
        return new BigDecimal(Float.toString(paramFloat));
      case null:
      case null:
        return new Double((new Float(paramFloat)).doubleValue());
      case null:
        return convertIntToBytes(Float.floatToRawIntBits(paramFloat), 4);
    } 
    return Float.toString(paramFloat);
  }







  
  static final byte[] convertLongToBytes(long paramLong) {
    byte[] arrayOfByte = new byte[8];
    for (byte b = 8; b-- > 0; ) {
      
      arrayOfByte[b] = (byte)(int)(paramLong & 0xFFL);
      paramLong >>= 8L;
    } 
    return arrayOfByte;
  }







  
  static final Object convertDoubleToObject(double paramDouble, JDBCType paramJDBCType, StreamType paramStreamType) {
    switch (paramJDBCType) {
      
      case null:
      case null:
        return new Double(paramDouble);
      case null:
        return new Float((new Double(paramDouble)).floatValue());
      case BINARY:
        return new Integer((int)paramDouble);
      case DATE:
      case TIME:
        return new Short((short)(int)paramDouble);
      case TIMESTAMP:
      case DATETIMEOFFSET:
        return new Boolean((0 != Double.compare(0.0D, paramDouble)));
      case CHARACTER:
        return new Long((long)paramDouble);
      case null:
      case null:
      case null:
      case null:
        return new BigDecimal(Double.toString(paramDouble));
      case null:
        return convertLongToBytes(Double.doubleToRawLongBits(paramDouble));
    } 
    return Double.toString(paramDouble);
  }



  
  static final byte[] convertBigDecimalToBytes(BigDecimal paramBigDecimal, int paramInt) {
    byte[] arrayOfByte;
    if (paramBigDecimal == null) {
      
      arrayOfByte = new byte[2];
      arrayOfByte[0] = (byte)paramInt;
      arrayOfByte[1] = 0;
    }
    else {
      
      boolean bool = (paramBigDecimal.signum() < 0) ? true : false;

      
      if (paramBigDecimal.scale() < 0) {
        paramBigDecimal = paramBigDecimal.setScale(0);
      }
      BigInteger bigInteger = paramBigDecimal.unscaledValue();
      
      if (bool) {
        bigInteger = bigInteger.negate();
      }
      byte[] arrayOfByte1 = bigInteger.toByteArray();
      
      arrayOfByte = new byte[arrayOfByte1.length + 3];
      byte b = 0;
      arrayOfByte[b++] = (byte)paramBigDecimal.scale();
      arrayOfByte[b++] = (byte)(arrayOfByte1.length + 1);
      arrayOfByte[b++] = (byte)(bool ? 0 : 1);
      for (int i = arrayOfByte1.length - 1; i >= 0; i--) {
        arrayOfByte[b++] = arrayOfByte1[i];
      }
    } 
    return arrayOfByte;
  }







  
  static final Object convertBigDecimalToObject(BigDecimal paramBigDecimal, JDBCType paramJDBCType, StreamType paramStreamType) {
    switch (paramJDBCType) {
      
      case null:
      case null:
      case null:
      case null:
        return paramBigDecimal;
      case null:
      case null:
        return new Double(paramBigDecimal.doubleValue());
      case null:
        return new Float(paramBigDecimal.floatValue());
      case BINARY:
        return new Integer(paramBigDecimal.intValue());
      case DATE:
      case TIME:
        return new Short(paramBigDecimal.shortValue());
      case TIMESTAMP:
      case DATETIMEOFFSET:
        return new Boolean((0 != paramBigDecimal.compareTo(BigDecimal.valueOf(0L))));
      case CHARACTER:
        return new Long(paramBigDecimal.longValue());
      case null:
        return convertBigDecimalToBytes(paramBigDecimal, paramBigDecimal.scale());
    } 
    return paramBigDecimal.toString();
  }


  
  static final Object convertMoneyToObject(BigDecimal paramBigDecimal, JDBCType paramJDBCType, StreamType paramStreamType, int paramInt) {
    switch (paramJDBCType) {
      
      case null:
      case null:
      case null:
      case null:
        return paramBigDecimal;
      case null:
      case null:
        return new Double(paramBigDecimal.doubleValue());
      case null:
        return new Float(paramBigDecimal.floatValue());
      case BINARY:
        return new Integer(paramBigDecimal.intValue());
      case DATE:
      case TIME:
        return new Short(paramBigDecimal.shortValue());
      case TIMESTAMP:
      case DATETIMEOFFSET:
        return new Boolean((0 != paramBigDecimal.compareTo(BigDecimal.valueOf(0L))));
      case CHARACTER:
        return new Long(paramBigDecimal.longValue());
      case null:
        return convertToBytes(paramBigDecimal, paramBigDecimal.scale(), paramInt);
    } 
    return paramBigDecimal.toString();
  }



  
  private static byte[] convertToBytes(BigDecimal paramBigDecimal, int paramInt1, int paramInt2) {
    boolean bool = (paramBigDecimal.signum() < 0) ? true : false;
    
    paramBigDecimal = paramBigDecimal.setScale(paramInt1, RoundingMode.DOWN);
    
    BigInteger bigInteger = paramBigDecimal.unscaledValue();
    
    byte[] arrayOfByte1 = bigInteger.toByteArray();
    
    byte[] arrayOfByte2 = new byte[paramInt2];
    if (arrayOfByte1.length < paramInt2)
    {
      for (byte b = 0; b < paramInt2 - arrayOfByte1.length; b++)
      {
        arrayOfByte2[b] = (byte)(bool ? -1 : 0);
      }
    }
    int i = paramInt2 - arrayOfByte1.length;
    for (int j = i; j < paramInt2; j++)
    {
      arrayOfByte2[j] = arrayOfByte1[j - i];
    }
    return arrayOfByte2;
  }








  
  static final Object convertBytesToObject(byte[] paramArrayOfbyte, JDBCType paramJDBCType, TypeInfo paramTypeInfo) throws SQLServerException {
    String str;
    switch (paramJDBCType) {
      
      case null:
        str = Util.bytesToHexString(paramArrayOfbyte, paramArrayOfbyte.length);
        
        if (SSType.BINARY == paramTypeInfo.getSSType() && str.length() < paramTypeInfo.getPrecision() * 2) {

          
          StringBuffer stringBuffer = new StringBuffer(str);
          
          while (stringBuffer.length() < paramTypeInfo.getPrecision() * 2) {
            stringBuffer.append('0');
          }
          return stringBuffer.toString();
        } 
        return str;
      
      case null:
      case null:
      case null:
        if (SSType.BINARY == paramTypeInfo.getSSType() && paramArrayOfbyte.length < paramTypeInfo.getPrecision()) {

          
          byte[] arrayOfByte = new byte[paramTypeInfo.getPrecision()];
          System.arraycopy(paramArrayOfbyte, 0, arrayOfByte, 0, paramArrayOfbyte.length);
          return arrayOfByte;
        } 
        
        return paramArrayOfbyte;
    } 
    
    MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedConversionFromTo"));
    throw new SQLServerException(messageFormat.format(new Object[] { paramTypeInfo.getSSType().name(), paramJDBCType }, ), null, 0, null);
  }









  
  static final Object convertStringToObject(String paramString1, String paramString2, JDBCType paramJDBCType, StreamType paramStreamType) throws UnsupportedEncodingException, IllegalArgumentException {
    String str;
    Timestamp timestamp;
    GregorianCalendar gregorianCalendar;
    switch (paramJDBCType) {

      
      case null:
      case null:
      case null:
      case null:
        return new BigDecimal(paramString1.trim());
      case null:
      case null:
        return Double.valueOf(paramString1.trim());
      case null:
        return Float.valueOf(paramString1.trim());
      case BINARY:
        return Integer.valueOf(paramString1.trim());
      case DATE:
      case TIME:
        return Short.valueOf(paramString1.trim());
      case TIMESTAMP:
      case DATETIMEOFFSET:
        str = paramString1.trim();
        return (1 == str.length()) ? Boolean.valueOf(('1' == str.charAt(0))) : Boolean.valueOf(str);

      
      case CHARACTER:
        return Long.valueOf(paramString1.trim());

      
      case null:
        return Timestamp.valueOf(paramString1.trim());
      case null:
        return Date.valueOf(getDatePart(paramString1.trim()));








      
      case null:
        timestamp = Timestamp.valueOf("1970-01-01 " + getTimePart(paramString1.trim()));
        gregorianCalendar = new GregorianCalendar(Locale.US);
        gregorianCalendar.clear();
        gregorianCalendar.setTimeInMillis(timestamp.getTime());
        if (timestamp.getNanos() % 1000000 >= 500000)
          gregorianCalendar.add(14, 1); 
        gregorianCalendar.set(1970, 0, 1);
        return new Time(gregorianCalendar.getTimeInMillis());

      
      case null:
        return paramString1.getBytes(paramString2);
    } 

    
    switch (paramStreamType) {
      
      case BINARY:
        return new StringReader(paramString1);
      case DATE:
        return new ByteArrayInputStream(paramString1.getBytes("US-ASCII"));
      case TIME:
        return new ByteArrayInputStream(paramString1.getBytes());
    } 
    
    return paramString1;
  }









  
  static final Object convertStreamToObject(BaseInputStream paramBaseInputStream, TypeInfo paramTypeInfo, JDBCType paramJDBCType, InputStreamGetterArgs paramInputStreamGetterArgs) throws SQLServerException {
    if (null == paramBaseInputStream) {
      return null;
    }
    assert null != paramTypeInfo;
    assert null != paramInputStreamGetterArgs;
    
    SSType sSType = paramTypeInfo.getSSType();

    
    try {
      switch (paramJDBCType) {










        
        default:
          if (SSType.BINARY == sSType || SSType.VARBINARY == sSType || SSType.VARBINARYMAX == sSType || SSType.TIMESTAMP == sSType || SSType.IMAGE == sSType || SSType.UDT == sSType) {





            
            if (StreamType.ASCII == paramInputStreamGetterArgs.streamType)
            {
              return paramBaseInputStream;
            }

            
            assert StreamType.CHARACTER == paramInputStreamGetterArgs.streamType || StreamType.NONE == paramInputStreamGetterArgs.streamType;

            
            byte[] arrayOfByte = paramBaseInputStream.getBytes();
            if (JDBCType.GUID == paramJDBCType)
            {
              return Util.readGUID(arrayOfByte);
            }

            
            String str = Util.bytesToHexString(arrayOfByte, arrayOfByte.length);
            
            if (StreamType.NONE == paramInputStreamGetterArgs.streamType) {
              return str;
            }
            return new StringReader(str);
          } 



          
          if (StreamType.ASCII == paramInputStreamGetterArgs.streamType) {

            
            if (paramTypeInfo.supportsFastAsciiConversion()) {
              return new AsciiFilteredInputStream(paramBaseInputStream);
            }
            
            if (paramInputStreamGetterArgs.isAdaptive)
            {
              return AsciiFilteredUnicodeInputStream.MakeAsciiFilteredUnicodeInputStream(paramBaseInputStream, new BufferedReader(new InputStreamReader(paramBaseInputStream, paramTypeInfo.getCharset())));
            }



            
            return new ByteArrayInputStream((new String(paramBaseInputStream.getBytes(), paramTypeInfo.getCharset())).getBytes("US-ASCII"));
          } 
          
          if (StreamType.CHARACTER == paramInputStreamGetterArgs.streamType || StreamType.NCHARACTER == paramInputStreamGetterArgs.streamType) {

            
            if (paramInputStreamGetterArgs.isAdaptive) {
              return new BufferedReader(new InputStreamReader(paramBaseInputStream, paramTypeInfo.getCharset()));
            }
            return new StringReader(new String(paramBaseInputStream.getBytes(), paramTypeInfo.getCharset()));
          } 

          
          return convertStringToObject(new String(paramBaseInputStream.getBytes(), paramTypeInfo.getCharset()), paramTypeInfo.getCharset(), paramJDBCType, paramInputStreamGetterArgs.streamType);
        
        case null:
          return new SQLServerClob(paramBaseInputStream, paramTypeInfo);
        
        case null:
          return new SQLServerNClob(paramBaseInputStream, paramTypeInfo);
        case null:
          return new SQLServerSQLXML(paramBaseInputStream, paramInputStreamGetterArgs, paramTypeInfo);
        
        case null:
        case null:
        case null:
        case null:
          break;
      } 
      
      if (StreamType.BINARY == paramInputStreamGetterArgs.streamType) {
        return paramBaseInputStream;
      }
      if (JDBCType.BLOB == paramJDBCType) {
        return new SQLServerBlob(paramBaseInputStream);
      }
      return paramBaseInputStream.getBytes();








    
    }
    catch (IllegalArgumentException illegalArgumentException) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorConvertingValue"));
      throw new SQLServerException(messageFormat.format(new Object[] { paramTypeInfo.getSSType(), paramJDBCType }, ), null, 0, illegalArgumentException);
    }
    catch (UnsupportedEncodingException unsupportedEncodingException) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorConvertingValue"));
      throw new SQLServerException(messageFormat.format(new Object[] { paramTypeInfo.getSSType(), paramJDBCType }, ), null, 0, unsupportedEncodingException);
    } 
  }



  
  private static final String getDatePart(String paramString) {
    int i = paramString.indexOf(' ');
    if (-1 == i) return paramString; 
    return paramString.substring(0, i);
  }


  
  private static final String getTimePart(String paramString) {
    int i = paramString.indexOf(' ');
    if (-1 == i) return paramString; 
    return paramString.substring(i + 1);
  }



  
  private static String fractionalSecondsString(long paramLong, int paramInt) {
    assert 0L <= paramLong && paramLong < 1000000000L;
    assert 0 <= paramInt && paramInt <= 7;


    
    if (0 == paramInt) {
      return "";
    }
    return BigDecimal.valueOf(paramLong % 1000000000L, 9).setScale(paramInt).toPlainString().substring(1);
  }


























































  
  static final Object convertTemporalToObject(JDBCType paramJDBCType, SSType paramSSType, Calendar paramCalendar, int paramInt1, long paramLong, int paramInt2) {
    Timestamp timestamp2;
    int k;
    Timestamp timestamp1;
    int j;
    Timestamp timestamp3;
    int m;
    TimeZone timeZone1 = (null != paramCalendar) ? paramCalendar.getTimeZone() : TimeZone.getDefault();







    
    TimeZone timeZone2 = (SSType.DATETIMEOFFSET == paramSSType) ? UTC.timeZone : timeZone1;
    
    int i = 0;



    
    GregorianCalendar gregorianCalendar = new GregorianCalendar(timeZone2, Locale.US);


    
    gregorianCalendar.setLenient(true);


    
    gregorianCalendar.clear();


    
    switch (paramSSType) {











      
      case null:
        gregorianCalendar.set(1900, 0, 1, 0, 0, 0);
        gregorianCalendar.set(14, (int)(paramLong / 1000000L));
        
        i = (int)(paramLong % 1000000000L);
        break;








      
      case null:
      case null:
      case null:
        if (paramInt1 >= GregorianChange.DAYS_SINCE_BASE_DATE_HINT) {





          
          gregorianCalendar.set(1, 0, 1 + paramInt1 + GregorianChange.EXTRA_DAYS_TO_BE_ADDED, 0, 0, 0);
          gregorianCalendar.set(14, (int)(paramLong / 1000000L));




        
        }
        else {





          
          gregorianCalendar.setGregorianChange(GregorianChange.PURE_CHANGE_DATE);




          
          gregorianCalendar.set(1, 0, 1 + paramInt1, 0, 0, 0);
          gregorianCalendar.set(14, (int)(paramLong / 1000000L));



          
          int n = gregorianCalendar.get(1);
          int i1 = gregorianCalendar.get(2);
          int i2 = gregorianCalendar.get(5);
          int i3 = gregorianCalendar.get(11);
          int i4 = gregorianCalendar.get(12);
          int i5 = gregorianCalendar.get(13);
          int i6 = gregorianCalendar.get(14);
          
          gregorianCalendar.setGregorianChange(GregorianChange.STANDARD_CHANGE_DATE);
          gregorianCalendar.set(n, i1, i2, i3, i4, i5);
          gregorianCalendar.set(14, i6);
        } 






        
        if (SSType.DATETIMEOFFSET == paramSSType && !timeZone2.hasSameRules(timeZone1)) {
          
          GregorianCalendar gregorianCalendar1 = new GregorianCalendar(timeZone1, Locale.US);
          gregorianCalendar1.clear();
          gregorianCalendar1.setTimeInMillis(gregorianCalendar.getTimeInMillis());
          gregorianCalendar = gregorianCalendar1;
        } 
        
        i = (int)(paramLong % 1000000000L);
        break;











      
      case null:
        gregorianCalendar.set(1900, 0, 1 + paramInt1, 0, 0, 0);
        gregorianCalendar.set(14, (int)paramLong);
        
        i = (int)(paramLong * 1000000L % 1000000000L);
        break;


      
      default:
        throw new AssertionError("Unexpected SSType: " + paramSSType);
    } 

    
    switch (paramJDBCType.category) {

      
      case BINARY:
        switch (paramSSType) {



          
          case null:
            gregorianCalendar.set(11, 0);
            gregorianCalendar.set(12, 0);
            gregorianCalendar.set(13, 0);
            gregorianCalendar.set(14, 0);
            return new Date(gregorianCalendar.getTimeInMillis());


          
          case null:
          case null:
            timestamp2 = new Timestamp(gregorianCalendar.getTimeInMillis());
            timestamp2.setNanos(i);
            return timestamp2;




          
          case null:
            assert SSType.DATETIMEOFFSET == paramSSType;





            
            k = paramCalendar.get(15);
            assert 0 == k % 60000;
            
            timestamp3 = new Timestamp(gregorianCalendar.getTimeInMillis());
            timestamp3.setNanos(i);
            return DateTimeOffset.valueOf(timestamp3, k / 60000);






          
          case null:
            if (i % 1000000 >= 500000) {
              gregorianCalendar.add(14, 1);
            }



            
            gregorianCalendar.set(1970, 0, 1);
            
            return new Time(gregorianCalendar.getTimeInMillis());
        } 

        
        throw new AssertionError("Unexpected SSType: " + paramSSType);





      
      case DATE:
        gregorianCalendar.set(11, 0);
        gregorianCalendar.set(12, 0);
        gregorianCalendar.set(13, 0);
        gregorianCalendar.set(14, 0);
        return new Date(gregorianCalendar.getTimeInMillis());







      
      case TIME:
        if (i % 1000000 >= 500000) {
          gregorianCalendar.add(14, 1);
        }



        
        gregorianCalendar.set(1970, 0, 1);
        
        return new Time(gregorianCalendar.getTimeInMillis());


      
      case TIMESTAMP:
        timestamp1 = new Timestamp(gregorianCalendar.getTimeInMillis());
        timestamp1.setNanos(i);
        return timestamp1;




      
      case DATETIMEOFFSET:
        assert SSType.DATETIMEOFFSET == paramSSType;





        
        j = paramCalendar.get(15);
        assert 0 == j % 60000;
        
        timestamp3 = new Timestamp(gregorianCalendar.getTimeInMillis());
        timestamp3.setNanos(i);
        return DateTimeOffset.valueOf(timestamp3, j / 60000);


      
      case CHARACTER:
        switch (paramSSType) {

          
          case null:
            return String.format(Locale.US, "%1$tF", new Object[] { gregorianCalendar });





          
          case null:
            return String.format(Locale.US, "%1$tT%2$s", new Object[] { gregorianCalendar, fractionalSecondsString(i, paramInt2) });








          
          case null:
            return String.format(Locale.US, "%1$tF %1$tT%2$s", new Object[] { gregorianCalendar, fractionalSecondsString(i, paramInt2) });










          
          case null:
            j = paramCalendar.get(15);
            assert 0 == j % 60000;
            
            m = Math.abs(j / 60000);
            return String.format(Locale.US, "%1$tF %1$tT%2$s %3$c%4$02d:%5$02d", new Object[] { gregorianCalendar, fractionalSecondsString(i, paramInt2), Character.valueOf((j >= 0) ? 43 : 45), Integer.valueOf(m / 60), Integer.valueOf(m % 60) });











          
          case null:
            return (new Timestamp(gregorianCalendar.getTimeInMillis())).toString();
        } 

        
        throw new AssertionError("Unexpected SSType: " + paramSSType);
    } 


    
    throw new AssertionError("Unexpected JDBCType: " + paramJDBCType);
  }










  
  static int daysSinceBaseDate(int paramInt1, int paramInt2, int paramInt3) {
    assert paramInt1 >= 1;
    assert paramInt3 >= 1;
    assert paramInt2 >= 1;
    
    return paramInt2 - 1 + (paramInt1 - paramInt3) * 365 + leapDaysBeforeYear(paramInt1) - leapDaysBeforeYear(paramInt3);
  }









  
  private static int leapDaysBeforeYear(int paramInt) {
    assert paramInt >= 1;









    
    return (paramInt - 1) / 4 - (paramInt - 1) / 100 + (paramInt - 1) / 400;
  }


  
  private static final BigInteger maxRPCDecimalValue = new BigInteger("99999999999999999999999999999999999999");



  
  static final boolean exceedsMaxRPCDecimalPrecisionOrScale(BigDecimal paramBigDecimal) {
    if (null == paramBigDecimal) return false;

    
    if (paramBigDecimal.scale() > 38) return true;


    
    BigInteger bigInteger = (paramBigDecimal.scale() < 0) ? paramBigDecimal.setScale(0).unscaledValue() : paramBigDecimal.unscaledValue();
    
    if (paramBigDecimal.signum() < 0) bigInteger = bigInteger.negate(); 
    return (bigInteger.compareTo(maxRPCDecimalValue) > 0);
  }


  
  static String convertReaderToString(Reader paramReader, int paramInt) throws SQLServerException {
    assert -1 == paramInt || paramInt >= 0;

    
    if (null == paramReader) return null; 
    if (0 == paramInt) return "";




    
    try {
      StringBuilder stringBuilder = new StringBuilder((-1 != paramInt) ? paramInt : 4000);



      
      char[] arrayOfChar = new char[(-1 != paramInt && paramInt < 4000) ? paramInt : 4000];

      
      int i;
      
      while ((i = paramReader.read(arrayOfChar, 0, arrayOfChar.length)) > 0) {

        
        if (i > arrayOfChar.length) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
          Object[] arrayOfObject = { SQLServerException.getErrString("R_streamReadReturnedInvalidValue") };
          SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), "", true);
        } 
        
        stringBuilder.append(arrayOfChar, 0, i);
      } 
      
      return stringBuilder.toString();
    }
    catch (IOException iOException) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
      Object[] arrayOfObject = { iOException.toString() };
      SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), "", true);


      
      return null;
    } 
  }
}
