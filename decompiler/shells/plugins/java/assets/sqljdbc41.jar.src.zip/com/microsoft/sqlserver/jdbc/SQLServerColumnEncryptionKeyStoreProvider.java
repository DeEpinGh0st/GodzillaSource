package com.microsoft.sqlserver.jdbc;

public abstract class SQLServerColumnEncryptionKeyStoreProvider {
  public abstract void setName(String paramString);
  
  public abstract String getName();
  
  public abstract byte[] decryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException;
  
  public abstract byte[] encryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException;
}
