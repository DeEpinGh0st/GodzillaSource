package com.microsoft.sqlserver.jdbc;

import java.text.MessageFormat;

public class SQLServerMetaData
{
  String columnName = null;
  int javaSqlType;
  int precision = 0;
  int scale = 0;
  boolean useServerDefault = false;
  boolean isUniqueKey = false;
  SQLServerSortOrder sortOrder = SQLServerSortOrder.Unspecified;

  
  int sortOrdinal;
  
  static final int defaultSortOrdinal = -1;

  
  public SQLServerMetaData(String paramString, int paramInt) {
    this.columnName = paramString;
    this.javaSqlType = paramInt;
  }





  
  public SQLServerMetaData(String paramString, int paramInt1, int paramInt2, int paramInt3) {
    this.columnName = paramString;
    this.javaSqlType = paramInt1;
    this.precision = paramInt2;
    this.scale = paramInt3;
  }









  
  public SQLServerMetaData(String paramString, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2, SQLServerSortOrder paramSQLServerSortOrder, int paramInt4) throws SQLServerException {
    this.columnName = paramString;
    this.javaSqlType = paramInt1;
    this.precision = paramInt2;
    this.scale = paramInt3;
    this.useServerDefault = paramBoolean1;
    this.isUniqueKey = paramBoolean2;
    this.sortOrder = paramSQLServerSortOrder;
    this.sortOrdinal = paramInt4;
    validateSortOrder();
  }

  
  public SQLServerMetaData(SQLServerMetaData paramSQLServerMetaData) {
    this.columnName = paramSQLServerMetaData.columnName;
    this.javaSqlType = paramSQLServerMetaData.javaSqlType;
    this.precision = paramSQLServerMetaData.precision;
    this.scale = paramSQLServerMetaData.scale;
    this.useServerDefault = paramSQLServerMetaData.useServerDefault;
    this.isUniqueKey = paramSQLServerMetaData.isUniqueKey;
    this.sortOrder = paramSQLServerMetaData.sortOrder;
    this.sortOrdinal = paramSQLServerMetaData.sortOrdinal;
  }

  
  public String getColumName() {
    return this.columnName;
  }

  
  public int getSqlType() {
    return this.javaSqlType;
  }

  
  public int getPrecision() {
    return this.precision;
  }

  
  public int getScale() {
    return this.scale;
  }

  
  public boolean useServerDefault() {
    return this.useServerDefault;
  }

  
  public boolean isUniqueKey() {
    return this.isUniqueKey;
  }

  
  public SQLServerSortOrder getSortOrder() {
    return this.sortOrder;
  }

  
  public int getSortOrdinal() {
    return this.sortOrdinal;
  }


  
  void validateSortOrder() throws SQLServerException {
    if (((SQLServerSortOrder.Unspecified == this.sortOrder) ? true : false) != ((-1 == this.sortOrdinal) ? true : false)) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_TVPMissingSortOrderOrOrdinal"));
      throw new SQLServerException(messageFormat.format(new Object[] { this.sortOrder, Integer.valueOf(this.sortOrdinal) }, ), null, 0, null);
    } 
  }
}
