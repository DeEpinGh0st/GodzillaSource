package com.microsoft.sqlserver.jdbc;






























enum DriverError
{
  NOT_SET(0);
  
  final int getErrorCode() {
    return this.errorCode;
  }
  private final int errorCode;
  DriverError(int paramInt1) {
    this.errorCode = paramInt1;
  }
}
