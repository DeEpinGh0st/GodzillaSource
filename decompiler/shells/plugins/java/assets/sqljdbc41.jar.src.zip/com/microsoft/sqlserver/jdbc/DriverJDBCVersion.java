package com.microsoft.sqlserver.jdbc;










final class DriverJDBCVersion
{
  static final int major = 4;
  static final int minor = 1;
  
  static final void checkSupportsJDBC4() {}
  
  static final void checkSupportsJDBC41() {}
  
  static final void checkSupportsJDBC42() {
    throw new UnsupportedOperationException(SQLServerException.getErrString("R_notSupported"));
  }


  
  static final void throwBatchUpdateException(SQLServerException paramSQLServerException, long[] paramArrayOflong) {
    throw new UnsupportedOperationException(SQLServerException.getErrString("R_notSupported"));
  }
}
