package com.microsoft.sqlserver.jdbc;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.sql.Clob;
import java.sql.SQLException;
import java.util.logging.Logger;


public class SQLServerClob
  extends SQLServerClobBase
  implements Clob
{
  private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerClob");






  
  @Deprecated
  public SQLServerClob(SQLServerConnection paramSQLServerConnection, String paramString) {
    super(paramSQLServerConnection, paramString, (null == paramSQLServerConnection) ? null : paramSQLServerConnection.getDatabaseCollation(), logger);
    
    if (null == paramString) {
      throw new NullPointerException(SQLServerException.getErrString("R_cantSetNull"));
    }
  }
  
  SQLServerClob(SQLServerConnection paramSQLServerConnection) {
    super(paramSQLServerConnection, "", paramSQLServerConnection.getDatabaseCollation(), logger);
  }

  
  SQLServerClob(BaseInputStream paramBaseInputStream, TypeInfo paramTypeInfo) throws SQLServerException, UnsupportedEncodingException {
    super(null, new String(paramBaseInputStream.getBytes(), paramTypeInfo.getCharset()), paramTypeInfo.getSQLCollation(), logger);
  }
  final JDBCType getJdbcType() {
    return JDBCType.CLOB;
  }
}
