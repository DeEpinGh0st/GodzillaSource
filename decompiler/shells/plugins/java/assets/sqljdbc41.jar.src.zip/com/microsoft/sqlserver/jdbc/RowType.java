package com.microsoft.sqlserver.jdbc;














enum RowType
{
  ROW,
  NBCROW,
  UNKNOWN;
}
