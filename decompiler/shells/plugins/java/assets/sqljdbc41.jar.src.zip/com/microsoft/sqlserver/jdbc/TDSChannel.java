package com.microsoft.sqlserver.jdbc;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.nio.channels.SocketChannel;
import java.security.KeyStore;
import java.security.Provider;
import java.security.Security;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
















































































































































































































































































































































































































































final class TDSChannel
{
  private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.TDS.Channel"); private final String traceID; private final SQLServerConnection con; private final TDSWriter tdsWriter; private Socket tcpSocket; private SSLSocket sslSocket; private Socket channelSocket; final Logger getLogger() {
    return logger;
  } public final String toString() {
    return this.traceID;
  }
  
  final TDSWriter getWriter()
  {
    return this.tdsWriter; } final TDSReader getReader(TDSCommand paramTDSCommand) {
    return new TDSReader(this, this.con, paramTDSCommand);
  }














  
  ProxySocket proxySocket = null;

  
  private InputStream tcpInputStream;

  
  private OutputStream tcpOutputStream;

  
  private InputStream inputStream;

  
  private OutputStream outputStream;
  
  private static Logger packetLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.TDS.DATA");
  private final boolean isLoggingPackets = packetLogger.isLoggable(Level.FINEST); final boolean isLoggingPackets() {
    return this.isLoggingPackets;
  }
  
  int numMsgsSent = 0;
  int numMsgsRcvd = 0;


  
  private int spid = 0;
  void setSPID(int paramInt) { this.spid = paramInt; }
  int getSPID() { return this.spid; } void resetPooledConnection() {
    this.tdsWriter.resetPooledConnection();
  }
  
  TDSChannel(SQLServerConnection paramSQLServerConnection) {
    this.con = paramSQLServerConnection;
    this.traceID = "TDSChannel (" + paramSQLServerConnection.toString() + ")";
    this.tcpSocket = null;
    this.sslSocket = null;
    this.channelSocket = null;
    this.tcpInputStream = null;
    this.tcpOutputStream = null;
    this.inputStream = null;
    this.outputStream = null;
    this.tdsWriter = new TDSWriter(this, paramSQLServerConnection);
  }











  
  final void open(String paramString, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt3) throws SQLServerException {
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + ": Opening TCP socket...");
    }
    SocketFinder socketFinder = new SocketFinder(this.traceID, this.con);
    this.channelSocket = this.tcpSocket = socketFinder.findSocket(paramString, paramInt1, paramInt2, paramBoolean1, paramBoolean2, paramBoolean3, paramInt3);



    
    try {
      this.tcpSocket.setTcpNoDelay(true);
      this.tcpSocket.setKeepAlive(true);
      
      this.inputStream = this.tcpInputStream = this.tcpSocket.getInputStream();
      this.outputStream = this.tcpOutputStream = this.tcpSocket.getOutputStream();
    }
    catch (IOException iOException) {
      
      SQLServerException.ConvertConnectExceptionToSQLServerException(paramString, paramInt1, this.con, iOException);
    } 
  }




  
  void disableSSL() {
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + " Disabling SSL...");
    }
















    
    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(new byte[0]);
    
    try {
      byteArrayInputStream.close();
    }
    catch (IOException iOException) {


      
      logger.fine("Ignored error closing InputStream: " + iOException.getMessage());
    } 
    
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    
    try {
      byteArrayOutputStream.close();
    }
    catch (IOException iOException) {


      
      logger.fine("Ignored error closing OutputStream: " + iOException.getMessage());
    } 

    
    if (logger.isLoggable(Level.FINEST))
      logger.finest(toString() + " Rewiring proxy streams for SSL socket close"); 
    this.proxySocket.setStreams(byteArrayInputStream, byteArrayOutputStream);



    
    try {
      if (logger.isLoggable(Level.FINER)) {
        logger.finer(toString() + " Closing SSL socket");
      }
      this.sslSocket.close();
    }
    catch (IOException iOException) {

      
      logger.fine("Ignored error closing SSLSocket: " + iOException.getMessage());
    } 



    
    this.proxySocket = null;


    
    this.inputStream = this.tcpInputStream;
    this.outputStream = this.tcpOutputStream;
    this.channelSocket = this.tcpSocket;
    this.sslSocket = null;
    
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + " SSL disabled");
    }
  }








  
  private class SSLHandshakeInputStream
    extends InputStream
  {
    private final TDSReader tdsReader;







    
    private final TDSChannel.SSLHandshakeOutputStream sslHandshakeOutputStream;







    
    private final Logger logger;






    
    private final String logContext;






    
    private final byte[] oneByte;







    
    private final void ensureSSLPayload() throws IOException {
      if (0 == this.tdsReader.available()) {
        if (this.logger.isLoggable(Level.FINEST)) {
          this.logger.finest(this.logContext + " No handshake response bytes available. Flushing SSL handshake output stream.");
        }
        try {
          this.sslHandshakeOutputStream.endMessage();
        } catch (SQLServerException sQLServerException) {
          this.logger.finer(this.logContext + " Ending TDS message threw exception:" + sQLServerException.getMessage());
          throw new IOException(sQLServerException.getMessage());
        } 
        if (this.logger.isLoggable(Level.FINEST)) {
          this.logger.finest(this.logContext + " Reading first packet of SSL handshake response");
        }
        try {
          this.tdsReader.readPacket();
        } catch (SQLServerException sQLServerException) {
          this.logger.finer(this.logContext + " Reading response packet threw exception:" + sQLServerException.getMessage());
          throw new IOException(sQLServerException.getMessage());
        } 
      } 
    }







    
    SSLHandshakeInputStream(TDSChannel param1TDSChannel1, TDSChannel.SSLHandshakeOutputStream param1SSLHandshakeOutputStream)
    {
      this.oneByte = new byte[1];
      this.tdsReader = param1TDSChannel1.getReader(null);
      this.sslHandshakeOutputStream = param1SSLHandshakeOutputStream;
      this.logger = param1TDSChannel1.getLogger();
      this.logContext = param1TDSChannel1.toString() + " (SSLHandshakeInputStream):"; } public int read() throws IOException { int i;
      while (0 == (i = readInternal(this.oneByte, 0, this.oneByte.length)));

      
      assert 1 == i || -1 == i;
      return (1 == i) ? this.oneByte[0] : -1; }


    
    public int read(byte[] param1ArrayOfbyte) throws IOException {
      return readInternal(param1ArrayOfbyte, 0, param1ArrayOfbyte.length); }
    public long skip(long param1Long) throws IOException { if (this.logger.isLoggable(Level.FINEST))
        this.logger.finest(this.logContext + " Skipping " + param1Long + " bytes...");  if (param1Long <= 0L)
        return 0L;  if (param1Long > 2147483647L)
        param1Long = 2147483647L;  ensureSSLPayload(); try { this.tdsReader.skip((int)param1Long); } catch (SQLServerException sQLServerException) { this.logger.finer(this.logContext + " Skipping bytes threw exception:" + sQLServerException.getMessage()); throw new IOException(sQLServerException.getMessage()); }
       return param1Long; } public int read(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException { return readInternal(param1ArrayOfbyte, param1Int1, param1Int2); }


    
    private int readInternal(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
      if (this.logger.isLoggable(Level.FINEST)) {
        this.logger.finest(this.logContext + " Reading " + param1Int2 + " bytes...");
      }
      ensureSSLPayload();

      
      try {
        this.tdsReader.readBytes(param1ArrayOfbyte, param1Int1, param1Int2);
      }
      catch (SQLServerException sQLServerException) {
        
        this.logger.finer(this.logContext + " Reading bytes threw exception:" + sQLServerException.getMessage());
        throw new IOException(sQLServerException.getMessage());
      } 
      
      return param1Int2;
    }
  }







  
  private class SSLHandshakeOutputStream
    extends OutputStream
  {
    private final TDSWriter tdsWriter;






    
    private boolean messageStarted;






    
    private final Logger logger;






    
    private final String logContext;





    
    private final byte[] singleByte;






    
    SSLHandshakeOutputStream(TDSChannel param1TDSChannel1) {
      this.singleByte = new byte[1]; this.tdsWriter = param1TDSChannel1.getWriter(); this.messageStarted = false; this.logger = param1TDSChannel1.getLogger();
      this.logContext = param1TDSChannel1.toString() + " (SSLHandshakeOutputStream):";
    } public void flush() throws IOException { if (this.logger.isLoggable(Level.FINEST))
        this.logger.finest(this.logContext + " Ignored a request to flush the stream");  } public void write(int param1Int) throws IOException { this.singleByte[0] = (byte)(param1Int & 0xFF);
      writeInternal(this.singleByte, 0, this.singleByte.length); } void endMessage() throws SQLServerException { assert this.messageStarted;
      if (this.logger.isLoggable(Level.FINEST))
        this.logger.finest(this.logContext + " Finishing TDS message"); 
      this.tdsWriter.endMessage();
      this.messageStarted = false; }
    public void write(byte[] param1ArrayOfbyte) throws IOException { writeInternal(param1ArrayOfbyte, 0, param1ArrayOfbyte.length); }


    
    public void write(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
      writeInternal(param1ArrayOfbyte, param1Int1, param1Int2);
    }




    
    private void writeInternal(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
      try {
        if (!this.messageStarted) {
          
          if (this.logger.isLoggable(Level.FINEST)) {
            this.logger.finest(this.logContext + " Starting new TDS packet...");
          }
          this.tdsWriter.startMessage(null, (byte)18);
          this.messageStarted = true;
        } 
        
        if (this.logger.isLoggable(Level.FINEST)) {
          this.logger.finest(this.logContext + " Writing " + param1Int2 + " bytes...");
        }
        this.tdsWriter.writeBytes(param1ArrayOfbyte, param1Int1, param1Int2);
      }
      catch (SQLServerException sQLServerException) {
        
        this.logger.finer(this.logContext + " Writing bytes threw exception:" + sQLServerException.getMessage());
        throw new IOException(sQLServerException.getMessage());
      } 
    }
  }













  
  private final class ProxyInputStream
    extends InputStream
  {
    private InputStream filteredStream;












    
    private final byte[] oneByte;












    
    ProxyInputStream(InputStream param1InputStream) {
      this.oneByte = new byte[1];
      this.filteredStream = param1InputStream;
    } final void setFilteredStream(InputStream param1InputStream) {
      this.filteredStream = param1InputStream;
    } public int read() throws IOException { int i;
      while (0 == (i = readInternal(this.oneByte, 0, this.oneByte.length)));

      
      assert 1 == i || -1 == i;
      return (1 == i) ? this.oneByte[0] : -1; } public long skip(long param1Long) throws IOException { if (TDSChannel.logger.isLoggable(Level.FINEST))
        TDSChannel.logger.finest(toString() + " Skipping " + param1Long + " bytes");  long l = this.filteredStream.skip(param1Long); if (TDSChannel.logger.isLoggable(Level.FINEST))
        TDSChannel.logger.finest(toString() + " Skipped " + param1Long + " bytes");  return l; }
    public int available() throws IOException { int i = this.filteredStream.available(); if (TDSChannel.logger.isLoggable(Level.FINEST))
        TDSChannel.logger.finest(toString() + " " + i + " bytes available");  return i; }
    public int read(byte[] param1ArrayOfbyte) throws IOException { return readInternal(param1ArrayOfbyte, 0, param1ArrayOfbyte.length); }


    
    public int read(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
      return readInternal(param1ArrayOfbyte, param1Int1, param1Int2);
    }


    
    private int readInternal(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
      int i;
      if (TDSChannel.logger.isLoggable(Level.FINEST)) {
        TDSChannel.logger.finest(toString() + " Reading " + param1Int2 + " bytes");
      }
      
      try {
        i = this.filteredStream.read(param1ArrayOfbyte, param1Int1, param1Int2);
      }
      catch (IOException iOException) {
        
        if (TDSChannel.logger.isLoggable(Level.FINER)) {
          TDSChannel.logger.finer(toString() + " " + iOException.getMessage());
        }
        TDSChannel.logger.finer(toString() + " Reading bytes threw exception:" + iOException.getMessage());
        throw iOException;
      } 
      
      if (TDSChannel.logger.isLoggable(Level.FINEST)) {
        TDSChannel.logger.finest(toString() + " Read " + i + " bytes");
      }
      return i;
    }

    
    public boolean markSupported() {
      boolean bool = this.filteredStream.markSupported();
      
      if (TDSChannel.logger.isLoggable(Level.FINEST)) {
        TDSChannel.logger.finest(toString() + " Returning markSupported: " + bool);
      }
      return bool;
    }

    
    public void mark(int param1Int) {
      if (TDSChannel.logger.isLoggable(Level.FINEST)) {
        TDSChannel.logger.finest(toString() + " Marking next " + param1Int + " bytes");
      }
      this.filteredStream.mark(param1Int);
    }

    
    public void reset() throws IOException {
      if (TDSChannel.logger.isLoggable(Level.FINEST)) {
        TDSChannel.logger.finest(toString() + " Resetting to previous mark");
      }
      this.filteredStream.reset();
    }

    
    public void close() throws IOException {
      if (TDSChannel.logger.isLoggable(Level.FINEST)) {
        TDSChannel.logger.finest(toString() + " Closing");
      }
      this.filteredStream.close();
    }
  }










  
  final class ProxyOutputStream
    extends OutputStream
  {
    private OutputStream filteredStream;









    
    private final byte[] singleByte;









    
    ProxyOutputStream(OutputStream param1OutputStream) {
      this.singleByte = new byte[1];
      this.filteredStream = param1OutputStream;
    } final void setFilteredStream(OutputStream param1OutputStream) { this.filteredStream = param1OutputStream; }
    public void write(int param1Int) throws IOException { this.singleByte[0] = (byte)(param1Int & 0xFF);
      writeInternal(this.singleByte, 0, this.singleByte.length); } public void close() throws IOException { if (TDSChannel.logger.isLoggable(Level.FINEST))
        TDSChannel.logger.finest(toString() + " Closing");  this.filteredStream.close(); }
    public void flush() throws IOException { if (TDSChannel.logger.isLoggable(Level.FINEST))
        TDSChannel.logger.finest(toString() + " Flushing"); 
      this.filteredStream.flush(); }
    public void write(byte[] param1ArrayOfbyte) throws IOException { writeInternal(param1ArrayOfbyte, 0, param1ArrayOfbyte.length); }


    
    public void write(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
      writeInternal(param1ArrayOfbyte, param1Int1, param1Int2);
    }

    
    private void writeInternal(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
      if (TDSChannel.logger.isLoggable(Level.FINEST)) {
        TDSChannel.logger.finest(toString() + " Writing " + param1Int2 + " bytes");
      }
      this.filteredStream.write(param1ArrayOfbyte, param1Int1, param1Int2);
    }
  }



  
  private class ProxySocket
    extends Socket
  {
    private final TDSChannel tdsChannel;

    
    private final Logger logger;

    
    private final String logContext;

    
    private final TDSChannel.ProxyInputStream proxyInputStream;

    
    private final TDSChannel.ProxyOutputStream proxyOutputStream;


    
    ProxySocket(TDSChannel param1TDSChannel1) {
      this.tdsChannel = param1TDSChannel1;
      this.logger = param1TDSChannel1.getLogger();
      this.logContext = param1TDSChannel1.toString() + " (ProxySocket):";

      
      TDSChannel.SSLHandshakeOutputStream sSLHandshakeOutputStream = new TDSChannel.SSLHandshakeOutputStream(param1TDSChannel1);
      TDSChannel.SSLHandshakeInputStream sSLHandshakeInputStream = new TDSChannel.SSLHandshakeInputStream(param1TDSChannel1, sSLHandshakeOutputStream);
      this.proxyOutputStream = new TDSChannel.ProxyOutputStream(sSLHandshakeOutputStream);
      this.proxyInputStream = new TDSChannel.ProxyInputStream(sSLHandshakeInputStream);
    }

    
    void setStreams(InputStream param1InputStream, OutputStream param1OutputStream) {
      this.proxyInputStream.setFilteredStream(param1InputStream);
      this.proxyOutputStream.setFilteredStream(param1OutputStream);
    }

    
    public InputStream getInputStream() throws IOException {
      if (this.logger.isLoggable(Level.FINEST)) {
        this.logger.finest(this.logContext + " Getting input stream");
      }
      return this.proxyInputStream;
    }

    
    public OutputStream getOutputStream() throws IOException {
      if (this.logger.isLoggable(Level.FINEST)) {
        this.logger.finest(this.logContext + " Getting output stream");
      }
      return this.proxyOutputStream;
    }
    
    public InetAddress getInetAddress() {
      return this.tdsChannel.tcpSocket.getInetAddress();
    } public boolean getKeepAlive() throws SocketException { return this.tdsChannel.tcpSocket.getKeepAlive(); }
    public InetAddress getLocalAddress() { return this.tdsChannel.tcpSocket.getLocalAddress(); }
    public int getLocalPort() { return this.tdsChannel.tcpSocket.getLocalPort(); }
    public SocketAddress getLocalSocketAddress() { return this.tdsChannel.tcpSocket.getLocalSocketAddress(); }
    public boolean getOOBInline() throws SocketException { return this.tdsChannel.tcpSocket.getOOBInline(); }
    public int getPort() { return this.tdsChannel.tcpSocket.getPort(); }
    public int getReceiveBufferSize() throws SocketException { return this.tdsChannel.tcpSocket.getReceiveBufferSize(); }
    public SocketAddress getRemoteSocketAddress() { return this.tdsChannel.tcpSocket.getRemoteSocketAddress(); }
    public boolean getReuseAddress() throws SocketException { return this.tdsChannel.tcpSocket.getReuseAddress(); }
    public int getSendBufferSize() throws SocketException { return this.tdsChannel.tcpSocket.getSendBufferSize(); }
    public int getSoLinger() throws SocketException { return this.tdsChannel.tcpSocket.getSoLinger(); }
    public int getSoTimeout() throws SocketException { return this.tdsChannel.tcpSocket.getSoTimeout(); }
    public boolean getTcpNoDelay() throws SocketException { return this.tdsChannel.tcpSocket.getTcpNoDelay(); }
    public int getTrafficClass() throws SocketException { return this.tdsChannel.tcpSocket.getTrafficClass(); }
    public boolean isBound() { return true; }
    public boolean isClosed() { return false; }
    public boolean isConnected() { return true; }
    public boolean isInputShutdown() { return false; }
    public boolean isOutputShutdown() { return false; }
    public String toString() { return this.tdsChannel.tcpSocket.toString(); } public SocketChannel getChannel() {
      return null;
    }

    
    public void bind(SocketAddress param1SocketAddress) throws IOException {
      this.logger.finer(this.logContext + " Disallowed call to bind.  Throwing IOException.");
      throw new IOException();
    }

    
    public void connect(SocketAddress param1SocketAddress) throws IOException {
      this.logger.finer(this.logContext + " Disallowed call to connect (without timeout).  Throwing IOException.");
      throw new IOException();
    }

    
    public void connect(SocketAddress param1SocketAddress, int param1Int) throws IOException {
      this.logger.finer(this.logContext + " Disallowed call to connect (with timeout).  Throwing IOException.");
      throw new IOException();
    }



    
    public void close() throws IOException {
      if (this.logger.isLoggable(Level.FINER)) {
        this.logger.finer(this.logContext + " Ignoring close");
      }
    }
    
    public void setReceiveBufferSize(int param1Int) throws SocketException {
      if (this.logger.isLoggable(Level.FINER)) {
        this.logger.finer(toString() + " Ignoring setReceiveBufferSize size:" + param1Int);
      }
    }
    
    public void setSendBufferSize(int param1Int) throws SocketException {
      if (this.logger.isLoggable(Level.FINER)) {
        this.logger.finer(toString() + " Ignoring setSendBufferSize size:" + param1Int);
      }
    }
    
    public void setReuseAddress(boolean param1Boolean) throws SocketException {
      if (this.logger.isLoggable(Level.FINER)) {
        this.logger.finer(toString() + " Ignoring setReuseAddress");
      }
    }
    
    public void setSoLinger(boolean param1Boolean, int param1Int) throws SocketException {
      if (this.logger.isLoggable(Level.FINER)) {
        this.logger.finer(toString() + " Ignoring setSoLinger");
      }
    }
    
    public void setSoTimeout(int param1Int) throws SocketException {
      if (this.logger.isLoggable(Level.FINER)) {
        this.logger.finer(toString() + " Ignoring setSoTimeout");
      }
    }
    
    public void setTcpNoDelay(boolean param1Boolean) throws SocketException {
      if (this.logger.isLoggable(Level.FINER)) {
        this.logger.finer(toString() + " Ignoring setTcpNoDelay");
      }
    }
    
    public void setTrafficClass(int param1Int) throws SocketException {
      if (this.logger.isLoggable(Level.FINER)) {
        this.logger.finer(toString() + " Ignoring setTrafficClass");
      }
    }
    
    public void shutdownInput() throws IOException {
      if (this.logger.isLoggable(Level.FINER)) {
        this.logger.finer(toString() + " Ignoring shutdownInput");
      }
    }
    
    public void shutdownOutput() throws IOException {
      if (this.logger.isLoggable(Level.FINER)) {
        this.logger.finer(toString() + " Ignoring shutdownOutput");
      }
    }
    
    public void sendUrgentData(int param1Int) throws IOException {
      if (this.logger.isLoggable(Level.FINER)) {
        this.logger.finer(toString() + " Ignoring sendUrgentData");
      }
    }
    
    public void setKeepAlive(boolean param1Boolean) throws SocketException {
      if (this.logger.isLoggable(Level.FINER)) {
        this.logger.finer(toString() + " Ignoring setKeepAlive");
      }
    }
    
    public void setOOBInline(boolean param1Boolean) throws SocketException {
      if (this.logger.isLoggable(Level.FINER)) {
        this.logger.finer(toString() + " Ignoring setOOBInline");
      }
    }
  }


  
  private final class PermissiveX509TrustManager
    implements X509TrustManager
  {
    private final TDSChannel tdsChannel;
    
    private final Logger logger;
    
    private final String logContext;

    
    PermissiveX509TrustManager(TDSChannel param1TDSChannel1) {
      this.tdsChannel = param1TDSChannel1;
      this.logger = param1TDSChannel1.getLogger();
      this.logContext = param1TDSChannel1.toString() + " (PermissiveX509TrustManager):";
    }

    
    public void checkClientTrusted(X509Certificate[] param1ArrayOfX509Certificate, String param1String) throws CertificateException {
      if (this.logger.isLoggable(Level.FINER)) {
        this.logger.finer(this.logContext + " Trusting client certificate (!)");
      }
    }
    
    public void checkServerTrusted(X509Certificate[] param1ArrayOfX509Certificate, String param1String) throws CertificateException {
      if (this.logger.isLoggable(Level.FINER)) {
        this.logger.finer(this.logContext + " Trusting server certificate");
      }
    }
    
    public X509Certificate[] getAcceptedIssuers() {
      return new X509Certificate[0];
    }
  }

  
  private final class HostNameOverrideX509TrustManager
    implements X509TrustManager
  {
    private final Logger logger;
    
    private final String logContext;
    
    private final X509TrustManager defaultTrustManager;
    
    private String hostName;
    
    HostNameOverrideX509TrustManager(TDSChannel param1TDSChannel1, X509TrustManager param1X509TrustManager, String param1String) {
      this.logger = param1TDSChannel1.getLogger();
      this.logContext = param1TDSChannel1.toString() + " (HostNameOverrideX509TrustManager):";
      this.defaultTrustManager = param1X509TrustManager;
      
      this.hostName = param1String.toLowerCase();
    }







    
    private String parseCommonName(String param1String) {
      int i = param1String.indexOf("cn=");
      if (i == -1)
      {
        return null;
      }
      param1String = param1String.substring(i + 3);


      
      for (i = 0; i < param1String.length(); i++) {
        
        if (param1String.charAt(i) == ',') {
          break;
        }
      } 
      
      String str = param1String.substring(0, i);
      
      if (str.length() > 1 && '"' == str.charAt(0))
      {
        if ('"' == str.charAt(str.length() - 1)) {
          str = str.substring(1, str.length() - 1);
        }
        else {
          
          str = null;
        } 
      }
      return str;
    }


    
    private boolean validateServerName(String param1String) throws CertificateException {
      if (null == param1String) {
        
        if (this.logger.isLoggable(Level.FINER))
          this.logger.finer(this.logContext + " Failed to parse the name from the certificate or name is empty."); 
        return false;
      } 

      
      if (!param1String.equals(this.hostName)) {
        
        if (this.logger.isLoggable(Level.FINER))
          this.logger.finer(this.logContext + " The name in certificate " + param1String + " does not match with the server name " + this.hostName + "."); 
        return false;
      } 
      
      if (this.logger.isLoggable(Level.FINER)) {
        this.logger.finer(this.logContext + " The name in certificate:" + param1String + " validated against server name " + this.hostName + ".");
      }
      return true;
    }

    
    public void checkClientTrusted(X509Certificate[] param1ArrayOfX509Certificate, String param1String) throws CertificateException {
      if (this.logger.isLoggable(Level.FINEST))
        this.logger.finest(this.logContext + " Forwarding ClientTrusted."); 
      this.defaultTrustManager.checkClientTrusted(param1ArrayOfX509Certificate, param1String);
    }

    
    public void checkServerTrusted(X509Certificate[] param1ArrayOfX509Certificate, String param1String) throws CertificateException {
      if (this.logger.isLoggable(Level.FINEST))
        this.logger.finest(this.logContext + " Forwarding Trusting server certificate"); 
      this.defaultTrustManager.checkServerTrusted(param1ArrayOfX509Certificate, param1String);
      if (this.logger.isLoggable(Level.FINEST)) {
        this.logger.finest(this.logContext + " default serverTrusted succeeded proceeding with server name validation");
      }
      validateServerNameInCertificate(param1ArrayOfX509Certificate[0]);
    }

    
    private void validateServerNameInCertificate(X509Certificate param1X509Certificate) throws CertificateException {
      String str1 = param1X509Certificate.getSubjectX500Principal().getName("canonical");
      if (this.logger.isLoggable(Level.FINER)) {
        
        this.logger.finer(this.logContext + " Validating the server name:" + this.hostName);
        this.logger.finer(this.logContext + " The DN name in certificate:" + str1);
      } 
      
      boolean bool = false;

      
      String str2 = parseCommonName(str1);
      
      bool = validateServerName(str2);
      
      if (!bool) {

        
        Collection<List<?>> collection = param1X509Certificate.getSubjectAlternativeNames();
        
        if (collection != null)
        {
          
          for (List<Object> list : collection) {

            
            if (list != null && list.size() >= 2) {
              
              String str3 = (String)list.get(0);
              String str4 = (String)list.get(1);
              
              if (this.logger.isLoggable(Level.FINER))
              {
                this.logger.finer(this.logContext + "Key: " + str3 + "; KeyClass:" + ((str3 != null) ? (String)str3.getClass() : null) + ";value: " + str4 + "; valueClass:" + ((str4 != null) ? (String)str4.getClass() : null));
              }











              
              if (str3 != null && str3 instanceof Integer && ((Integer)str3).intValue() == 2) {






                
                if (str4 != null && str4 instanceof String) {
                  
                  String str = str4;





                  
                  str = str.toUpperCase(Locale.US);
                  str = str.toLowerCase(Locale.US);
                  
                  bool = validateServerName(str);
                  
                  if (bool) {
                    
                    if (this.logger.isLoggable(Level.FINER))
                    {
                      this.logger.finer(this.logContext + " found a valid name in certificate: " + str);
                    }
                    
                    break;
                  } 
                } 
                
                if (this.logger.isLoggable(Level.FINER))
                {
                  this.logger.finer(this.logContext + " the following name in certificate does not match the serverName: " + str4);
                }
              } 

              
              continue;
            } 
            
            if (this.logger.isLoggable(Level.FINER))
            {
              this.logger.finer(this.logContext + " found an invalid san entry: " + list);
            }
          } 
        }
      } 


      
      if (!bool) {
        
        String str = SQLServerException.getErrString("R_certNameFailed");
        throw new CertificateException(str);
      } 
    }

    
    public X509Certificate[] getAcceptedIssuers() {
      return this.defaultTrustManager.getAcceptedIssuers();
    }
  }
  
  enum SSLHandhsakeState
  {
    SSL_HANDHSAKE_NOT_STARTED,
    SSL_HANDHSAKE_STARTED,
    SSL_HANDHSAKE_COMPLETE;
  }



  
  void enableSSL(String paramString, int paramInt) throws SQLServerException {
    Provider provider1 = null;
    Provider provider2 = null;
    Provider provider3 = null;
    String str = null;
    SSLHandhsakeState sSLHandhsakeState = SSLHandhsakeState.SSL_HANDHSAKE_NOT_STARTED;


    
    try {
      if (logger.isLoggable(Level.FINER)) {
        logger.finer(toString() + " Enabling SSL...");
      }
      String str1 = this.con.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.TRUST_STORE.toString());
      String str2 = this.con.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString());
      String str3 = this.con.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.HOSTNAME_IN_CERTIFICATE.toString());
      
      assert 0 == this.con.getRequestedEncryptionLevel() || 1 == this.con.getRequestedEncryptionLevel();


      
      assert 0 == this.con.getNegotiatedEncryptionLevel() || 1 == this.con.getNegotiatedEncryptionLevel() || 3 == this.con.getNegotiatedEncryptionLevel();






      
      TrustManager[] arrayOfTrustManager = null;
      if (0 == this.con.getRequestedEncryptionLevel() || (1 == this.con.getRequestedEncryptionLevel() && this.con.trustServerCertificate())) {

        
        if (logger.isLoggable(Level.FINER)) {
          logger.finer(toString() + " SSL handshake will trust any certificate");
        }
        arrayOfTrustManager = new TrustManager[] { new PermissiveX509TrustManager(this) };

      
      }
      else {

        
        if (logger.isLoggable(Level.FINER)) {
          logger.finer(toString() + " SSL handshake will validate server certificate");
        }
        KeyStore keyStore = null;



        
        if (null == str1 && null == str2) {
          
          if (logger.isLoggable(Level.FINER)) {
            logger.finer(toString() + " Using system default trust store and password");

          
          }
        
        }
        else {

          
          if (logger.isLoggable(Level.FINEST)) {
            logger.finest(toString() + " Finding key store interface");
          }
          keyStore = KeyStore.getInstance("JKS");
          provider3 = keyStore.getProvider();




          
          InputStream inputStream = loadTrustStore(str1);


          
          if (logger.isLoggable(Level.FINEST)) {
            logger.finest(toString() + " Loading key store");
          }
          
          try {
            keyStore.load(inputStream, (null == str2) ? null : str2.toCharArray());
          
          }
          finally {
            
            this.con.activeConnectionProperties.remove(SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString());

            
            if (null != inputStream) {
              
              try {
                
                inputStream.close();
              }
              catch (IOException iOException) {
                
                if (logger.isLoggable(Level.FINE)) {
                  logger.fine(toString() + " Ignoring error closing trust material InputStream...");
                }
              } 
            }
          } 
        } 






        
        TrustManagerFactory trustManagerFactory = null;
        
        if (logger.isLoggable(Level.FINEST)) {
          logger.finest(toString() + " Locating X.509 trust manager factory");
        }
        str = TrustManagerFactory.getDefaultAlgorithm();
        trustManagerFactory = TrustManagerFactory.getInstance(str);
        provider1 = trustManagerFactory.getProvider();


        
        if (logger.isLoggable(Level.FINEST)) {
          logger.finest(toString() + " Getting trust manager");
        }
        trustManagerFactory.init(keyStore);
        arrayOfTrustManager = trustManagerFactory.getTrustManagers();

        
        if (null != str3) {
          
          arrayOfTrustManager = new TrustManager[] { new HostNameOverrideX509TrustManager(this, (X509TrustManager)arrayOfTrustManager[0], str3) };
        }
        else {
          
          arrayOfTrustManager = new TrustManager[] { new HostNameOverrideX509TrustManager(this, (X509TrustManager)arrayOfTrustManager[0], paramString) };
        } 
      } 


      
      SSLContext sSLContext = null;
      
      if (logger.isLoggable(Level.FINEST)) {
        logger.finest(toString() + " Getting TLS or better SSL context");
      }
      sSLContext = SSLContext.getInstance("TLS");
      provider2 = sSLContext.getProvider();
      
      if (logger.isLoggable(Level.FINEST)) {
        logger.finest(toString() + " Initializing SSL context");
      }
      sSLContext.init(null, arrayOfTrustManager, null);



      
      this.proxySocket = new ProxySocket(this);
      
      if (logger.isLoggable(Level.FINEST)) {
        logger.finest(toString() + " Creating SSL socket");
      }
      this.sslSocket = (SSLSocket)sSLContext.getSocketFactory().createSocket(this.proxySocket, paramString, paramInt, false);







      
      if (logger.isLoggable(Level.FINER)) {
        logger.finer(toString() + " Starting SSL handshake");
      }
      
      sSLHandhsakeState = SSLHandhsakeState.SSL_HANDHSAKE_STARTED;
      this.sslSocket.startHandshake();
      sSLHandhsakeState = SSLHandhsakeState.SSL_HANDHSAKE_COMPLETE;

      
      if (logger.isLoggable(Level.FINEST)) {
        logger.finest(toString() + " Rewiring proxy streams after handshake");
      }
      this.proxySocket.setStreams(this.inputStream, this.outputStream);

      
      if (logger.isLoggable(Level.FINEST)) {
        logger.finest(toString() + " Getting SSL InputStream");
      }
      this.inputStream = this.sslSocket.getInputStream();
      
      if (logger.isLoggable(Level.FINEST)) {
        logger.finest(toString() + " Getting SSL OutputStream");
      }
      this.outputStream = this.sslSocket.getOutputStream();

      
      this.channelSocket = this.sslSocket;
      
      if (logger.isLoggable(Level.FINER)) {
        logger.finer(toString() + " SSL enabled");
      }
    } catch (Exception exception) {

      
      if (logger.isLoggable(Level.FINER)) {
        logger.log(Level.FINER, exception.getMessage(), exception);
      }



      
      if (logger.isLoggable(Level.FINER)) {
        logger.log(Level.FINER, "java.security path: " + JAVA_SECURITY + "\n" + "Security providers: " + Arrays.<Provider>asList(Security.getProviders()) + "\n" + ((null != provider2) ? ("SSLContext provider info: " + provider2.getInfo() + "\n" + "SSLContext provider services:\n" + provider2.getServices() + "\n") : "") + ((null != provider1) ? ("TrustManagerFactory provider info: " + provider1.getInfo() + "\n") : "") + ((null != str) ? ("TrustManagerFactory default algorithm: " + str + "\n") : "") + ((null != provider3) ? ("KeyStore provider info: " + provider3.getInfo() + "\n") : "") + "java.ext.dirs: " + System.getProperty("java.ext.dirs"));
      }












      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_sslFailed"));
      Object[] arrayOfObject = { exception.getMessage() };

      
      String str1 = exception.getLocalizedMessage();


      
      if (-1 != str1.indexOf(" ClientConnectionId:"))
      {
        str1 = str1.substring(0, str1.indexOf(" ClientConnectionId:"));
      }

      
      if (exception instanceof IOException && SSLHandhsakeState.SSL_HANDHSAKE_STARTED == sSLHandhsakeState && str1.equals(SQLServerException.getErrString("R_truncatedServerResponse"))) {


        
        this.con.terminate(7, messageFormat.format(arrayOfObject), exception);
      }
      else {
        
        this.con.terminate(5, messageFormat.format(arrayOfObject), exception);
      } 
    } 
  }















  
  private static final String SEPARATOR = System.getProperty("file.separator");
  private static final String JAVA_HOME = System.getProperty("java.home");
  private static final String JAVA_SECURITY = JAVA_HOME + SEPARATOR + "lib" + SEPARATOR + "security";
  private static final String JSSECACERTS = JAVA_SECURITY + SEPARATOR + "jssecacerts";
  private static final String CACERTS = JAVA_SECURITY + SEPARATOR + "cacerts";
  
  final InputStream loadTrustStore(String paramString) {
    FileInputStream fileInputStream = null;

    
    if (null != paramString) {
      
      try
      {
        if (logger.isLoggable(Level.FINEST)) {
          logger.finest(toString() + " Opening specified trust store: " + paramString);
        }
        fileInputStream = new FileInputStream(paramString);
      }
      catch (FileNotFoundException fileNotFoundException)
      {
        if (logger.isLoggable(Level.FINE)) {
          logger.fine(toString() + " Trust store not found: " + fileNotFoundException.getMessage());

        
        }
      
      }

    
    }
    else if (null != (paramString = System.getProperty("javax.net.ssl.trustStore"))) {

      
      try {
        if (logger.isLoggable(Level.FINEST)) {
          logger.finest(toString() + " Opening default trust store (from javax.net.ssl.trustStore): " + paramString);
        }
        fileInputStream = new FileInputStream(paramString);
      }
      catch (FileNotFoundException fileNotFoundException) {
        
        if (logger.isLoggable(Level.FINE)) {
          logger.fine(toString() + " Trust store not found: " + fileNotFoundException.getMessage());
        }
      } 
    } else {

      
      try {





        
        if (logger.isLoggable(Level.FINEST)) {
          logger.finest(toString() + " Opening default trust store: " + JSSECACERTS);
        }
        fileInputStream = new FileInputStream(JSSECACERTS);
      }
      catch (FileNotFoundException fileNotFoundException) {
        
        if (logger.isLoggable(Level.FINE)) {
          logger.fine(toString() + " Trust store not found: " + fileNotFoundException.getMessage());
        }
      } 
      
      if (null == fileInputStream) {
        
        try {
          
          if (logger.isLoggable(Level.FINEST)) {
            logger.finest(toString() + " Opening default trust store: " + CACERTS);
          }
          fileInputStream = new FileInputStream(CACERTS);
        }
        catch (FileNotFoundException fileNotFoundException) {
          
          if (logger.isLoggable(Level.FINE)) {
            logger.fine(toString() + " Trust store not found: " + fileNotFoundException.getMessage());
          }
        } 
      }
    } 


    
    return fileInputStream;
  }


  
  final int read(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLServerException {
    try {
      return this.inputStream.read(paramArrayOfbyte, paramInt1, paramInt2);
    }
    catch (IOException iOException) {
      
      if (logger.isLoggable(Level.FINE)) {
        logger.fine(toString() + " read failed:" + iOException.getMessage());
      }
      this.con.terminate(3, iOException.getMessage());
      return 0;
    } 
  }


  
  final void write(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLServerException {
    try {
      this.outputStream.write(paramArrayOfbyte, paramInt1, paramInt2);
    }
    catch (IOException iOException) {
      
      if (logger.isLoggable(Level.FINER)) {
        logger.finer(toString() + " write failed:" + iOException.getMessage());
      }
      this.con.terminate(3, iOException.getMessage());
    } 
  }


  
  final void flush() throws SQLServerException {
    try {
      this.outputStream.flush();
    }
    catch (IOException iOException) {
      
      if (logger.isLoggable(Level.FINER)) {
        logger.finer(toString() + " flush failed:" + iOException.getMessage());
      }
      this.con.terminate(3, iOException.getMessage());
    } 
  }

  
  final void close() {
    if (null != this.sslSocket) {
      disableSSL();
    }
    if (null != this.inputStream) {
      
      if (logger.isLoggable(Level.FINEST)) {
        logger.finest(toString() + ": Closing inputStream...");
      }
      
      try {
        this.inputStream.close();
      }
      catch (IOException iOException) {
        
        if (logger.isLoggable(Level.FINE)) {
          logger.log(Level.FINE, toString() + ": Ignored error closing inputStream", iOException);
        }
      } 
    } 
    if (null != this.outputStream) {
      
      if (logger.isLoggable(Level.FINEST)) {
        logger.finest(toString() + ": Closing outputStream...");
      }
      
      try {
        this.outputStream.close();
      }
      catch (IOException iOException) {
        
        if (logger.isLoggable(Level.FINE)) {
          logger.log(Level.FINE, toString() + ": Ignored error closing outputStream", iOException);
        }
      } 
    } 
    if (null != this.tcpSocket) {
      
      if (logger.isLoggable(Level.FINER)) {
        logger.finer(toString() + ": Closing TCP socket...");
      }
      
      try {
        this.tcpSocket.close();
      }
      catch (IOException iOException) {
        
        if (logger.isLoggable(Level.FINE)) {
          logger.log(Level.FINE, toString() + ": Ignored error closing socket", iOException);
        }
      } 
    } 
  }








  
  void logPacket(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, String paramString) {
    assert 0 <= paramInt2 && paramInt2 <= paramArrayOfbyte.length;
    assert 0 <= paramInt1 && paramInt1 <= paramArrayOfbyte.length;
    
    char[] arrayOfChar1 = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };




    
    char[] arrayOfChar2 = { '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', ' ', '!', '"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?', '@', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\', ']', '^', '_', '`', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.' };
























    
    char[] arrayOfChar3 = { ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.' };











    
    char[] arrayOfChar4 = new char[arrayOfChar3.length];
    System.arraycopy(arrayOfChar3, 0, arrayOfChar4, 0, arrayOfChar3.length);



    
    StringBuilder stringBuilder = new StringBuilder(paramString.length() + 4 * paramInt2 + 4 * (1 + paramInt2 / 16) + 80);









    
    stringBuilder.append(this.tcpSocket.getLocalAddress().toString() + ":" + this.tcpSocket.getLocalPort() + " SPID:" + this.spid + " " + paramString + "\r\n");

    
    byte b = 0;


    
    while (true) {
      byte b1 = 0;
      for (; b1 < 16 && b < paramInt2; 
        b1++, b++) {
        
        int i = (paramArrayOfbyte[paramInt1 + b] + 256) % 256;
        arrayOfChar4[3 * b1] = arrayOfChar1[i / 16];
        arrayOfChar4[3 * b1 + 1] = arrayOfChar1[i % 16];
        arrayOfChar4[50 + b1] = arrayOfChar2[i];
      } 

      
      byte b2 = b1;
      for (; b2 < 16; b2++) {
        
        arrayOfChar4[3 * b2] = ' ';
        arrayOfChar4[3 * b2 + 1] = ' ';
      } 
      
      stringBuilder.append(arrayOfChar4, 0, 50 + b1);
      if (b == paramInt2) {
        break;
      }
      stringBuilder.append("\r\n");
    } 
    
    packetLogger.finest(stringBuilder.toString());
  }
}
