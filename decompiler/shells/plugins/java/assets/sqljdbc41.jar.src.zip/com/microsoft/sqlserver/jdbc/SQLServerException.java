package com.microsoft.sqlserver.jdbc;

import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;






































public final class SQLServerException
  extends SQLException
{
  static final String EXCEPTION_XOPEN_CONNECTION_CANT_ESTABLISH = "08001";
  static final String EXCEPTION_XOPEN_CONNECTION_DOES_NOT_EXIST = "08003";
  static final String EXCEPTION_XOPEN_CONNECTION_FAILURE = "08006";
  static final String LOG_CLIENT_CONNECTION_ID_PREFIX = " ClientConnectionId:";
  static final int LOGON_FAILED = 18456;
  static final int PASSWORD_EXPIRED = 18488;
  static Logger exLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerException");
  
  static final int DRIVER_ERROR_NONE = 0;
  
  static final int DRIVER_ERROR_FROM_DATABASE = 2;
  static final int DRIVER_ERROR_IO_FAILED = 3;
  static final int DRIVER_ERROR_INVALID_TDS = 4;
  static final int DRIVER_ERROR_SSL_FAILED = 5;
  static final int DRIVER_ERROR_UNSUPPORTED_CONFIG = 6;
  static final int DRIVER_ERROR_INTERMITTENT_TLS_FAILED = 7;
  private int driverErrorCode = 0;
  final int getDriverErrorCode() { return this.driverErrorCode; } final void setDriverErrorCode(int paramInt) {
    this.driverErrorCode = paramInt;
  }







  
  private void logException(Object paramObject, String paramString, boolean paramBoolean) {
    String str = "";
    if (paramObject != null) {
      str = paramObject.toString();
    }
    if (exLogger.isLoggable(Level.FINE))
      exLogger.fine("*** SQLException:" + str + " " + toString() + " " + paramString); 
    if (paramBoolean)
    {
      if (exLogger.isLoggable(Level.FINE)) {
        
        StringBuilder stringBuilder = new StringBuilder(100);
        StackTraceElement[] arrayOfStackTraceElement = getStackTrace();
        for (byte b = 0; b < arrayOfStackTraceElement.length; b++)
          stringBuilder.append(arrayOfStackTraceElement[b].toString()); 
        Throwable throwable = getCause();
        if (throwable != null) {
          
          stringBuilder.append("\n caused by " + throwable + "\n");
          StackTraceElement[] arrayOfStackTraceElement1 = throwable.getStackTrace();
          for (byte b1 = 0; b1 < arrayOfStackTraceElement1.length; b1++)
            stringBuilder.append(arrayOfStackTraceElement1[b1].toString()); 
        } 
        exLogger.fine(stringBuilder.toString());
      } 
    }
  }

  
  static String getErrString(String paramString) {
    return SQLServerResource.getResource(paramString);
  }










  
  SQLServerException(String paramString, SQLState paramSQLState, DriverError paramDriverError, Throwable paramThrowable) {
    this(paramString, paramSQLState.getSQLStateCode(), paramDriverError.getErrorCode(), paramThrowable);
  }

  
  SQLServerException(String paramString1, String paramString2, int paramInt, Throwable paramThrowable) {
    super(paramString1, paramString2, paramInt);
    initCause(paramThrowable);
    logException((Object)null, paramString1, true);
    ActivityCorrelator.setCurrentActivityIdSentFlag();
  }

  
  SQLServerException(String paramString, Throwable paramThrowable) {
    super(paramString);
    initCause(paramThrowable);
    logException((Object)null, paramString, true);
    ActivityCorrelator.setCurrentActivityIdSentFlag();
  }


  
  SQLServerException(Object paramObject, String paramString1, String paramString2, int paramInt, boolean paramBoolean) {
    super(paramString1, paramString2, paramInt);
    logException(paramObject, paramString1, paramBoolean);
    ActivityCorrelator.setCurrentActivityIdSentFlag();
  }










  
  SQLServerException(Object paramObject, String paramString1, String paramString2, StreamError paramStreamError, boolean paramBoolean) {
    super(paramString1, paramString2, paramStreamError.getErrorNumber());


    
    paramString1 = "Msg " + paramStreamError.getErrorNumber() + ", Level " + paramStreamError.getErrorSeverity() + ", State " + paramStreamError.getErrorState() + ", " + paramString1;
    logException(paramObject, paramString1, paramBoolean);
  }















  
  static void makeFromDriverError(SQLServerConnection paramSQLServerConnection, Object paramObject, String paramString1, String paramString2, boolean paramBoolean) throws SQLServerException {
    String str = "";

    
    if (paramString2 != null)
      str = paramString2; 
    if (paramSQLServerConnection == null || !paramSQLServerConnection.xopenStates) {
      str = mapFromXopen(paramString2);
    }
    SQLServerException sQLServerException = new SQLServerException(paramObject, checkAndAppendClientConnId(paramString1, paramSQLServerConnection), str, 0, paramBoolean);
    if (null != paramString2 && paramString2.equals("08006") && null != paramSQLServerConnection) {
      
      paramSQLServerConnection.notifyPooledConnection(sQLServerException);
      
      paramSQLServerConnection.close();
    } 
    
    throw sQLServerException;
  }












  
  static void makeFromDatabaseError(SQLServerConnection paramSQLServerConnection, Object paramObject, String paramString, StreamError paramStreamError, boolean paramBoolean) throws SQLServerException {
    String str = generateStateCode(paramSQLServerConnection, paramStreamError.getErrorNumber(), paramStreamError.getErrorState());
    
    SQLServerException sQLServerException = new SQLServerException(paramObject, checkAndAppendClientConnId(paramString, paramSQLServerConnection), str, paramStreamError, paramBoolean);
    sQLServerException.setDriverErrorCode(2);

    
    if (paramStreamError.getErrorSeverity() >= 20 && null != paramSQLServerConnection) {
      
      paramSQLServerConnection.notifyPooledConnection(sQLServerException);
      paramSQLServerConnection.close();
    } 
    
    throw sQLServerException;
  }


  
  static void ConvertConnectExceptionToSQLServerException(String paramString, int paramInt, SQLServerConnection paramSQLServerConnection, Exception paramException) throws SQLServerException {
    Exception exception = paramException;
    
    if (exception != null) {
      
      MessageFormat messageFormat1 = new MessageFormat(getErrString("R_tcpOpenFailed"));
      Object[] arrayOfObject1 = { exception.getMessage() };
      MessageFormat messageFormat2 = new MessageFormat(getErrString("R_tcpipConnectionFailed"));
      Object[] arrayOfObject2 = { paramString, Integer.toString(paramInt), messageFormat1.format(arrayOfObject1) };
      String str = messageFormat2.format(arrayOfObject2);
      makeFromDriverError(paramSQLServerConnection, paramSQLServerConnection, str, "08001", false);
    } 
  }













  
  static String mapFromXopen(String paramString) {
    if (paramString == null)
      return null; 
    if (paramString.equals("07009")) {
      return "S1093";
    }
    
    if (paramString.equals("08001"))
      return "08S01"; 
    if (paramString.equals("08006")) {
      return "08S01";
    }


    
    return "";
  }









  
  static String generateStateCode(SQLServerConnection paramSQLServerConnection, int paramInt1, int paramInt2) {
    boolean bool = (paramSQLServerConnection != null && paramSQLServerConnection.xopenStates) ? true : false;
    if (bool) {
      
      switch (paramInt1) {
        case 4060:
          return "08001";
        case 18456: return "08001";
        case 2714: return "42S01";
        case 208: return "42S02";
        case 207: return "42S22";
      } 
      
      return "42000";
    } 


    
    switch (paramInt1) {
      
      case 8152:
        return "22001";
      case 515: case 547:
        return "23000";
      case 2601: return "23000";
      case 2714: return "S0001";
      case 208: return "S0002";
      case 1205: return "40001";
      case 2627: return "23000";
    } 
    return "S000" + paramInt2;
  }









  
  static String checkAndAppendClientConnId(String paramString, SQLServerConnection paramSQLServerConnection) throws SQLServerException {
    if (null != paramSQLServerConnection && paramSQLServerConnection.attachConnId()) {
      
      UUID uUID = paramSQLServerConnection.getClientConIdInternal();
      assert null != uUID;
      StringBuilder stringBuilder = new StringBuilder(paramString);

      
      stringBuilder.append(" ClientConnectionId:");
      stringBuilder.append(uUID.toString());
      return stringBuilder.toString();
    } 
    
    return paramString;
  }
}
