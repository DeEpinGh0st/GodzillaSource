package com.microsoft.sqlserver.jdbc;

abstract class SSPIAuthentication {
  abstract byte[] GenerateClientContext(byte[] paramArrayOfbyte, boolean[] paramArrayOfboolean) throws SQLServerException;
  
  abstract int ReleaseClientContext() throws SQLServerException;
}
