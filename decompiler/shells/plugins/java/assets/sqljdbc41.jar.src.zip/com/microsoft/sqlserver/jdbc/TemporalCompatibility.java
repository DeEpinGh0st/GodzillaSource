package com.microsoft.sqlserver.jdbc;















class TemporalCompatibility
{
  public int getYear() throws SQLServerException {
    SQLServerException.makeFromDriverError(null, null, null, null, false);
    return 0;
  }

  
  public int getMonthValue() throws SQLServerException {
    SQLServerException.makeFromDriverError(null, null, null, null, false);
    return 0;
  }

  
  public int getDayOfMonth() throws SQLServerException {
    SQLServerException.makeFromDriverError(null, null, null, null, false);
    return 0;
  }

  
  public int getHour() throws SQLServerException {
    SQLServerException.makeFromDriverError(null, null, null, null, false);
    return 0;
  }

  
  public int getMinute() throws SQLServerException {
    SQLServerException.makeFromDriverError(null, null, null, null, false);
    return 0;
  }

  
  public int getSecond() throws SQLServerException {
    SQLServerException.makeFromDriverError(null, null, null, null, false);
    return 0;
  }

  
  public int getNano() throws SQLServerException {
    SQLServerException.makeFromDriverError(null, null, null, null, false);
    return 0;
  }

  
  public ZoneOffset getOffset() throws SQLServerException {
    SQLServerException.makeFromDriverError(null, null, null, null, false);
    return null;
  }
}
