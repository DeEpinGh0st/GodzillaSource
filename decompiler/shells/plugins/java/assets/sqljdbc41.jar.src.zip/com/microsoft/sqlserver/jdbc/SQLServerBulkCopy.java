package com.microsoft.sqlserver.jdbc;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.MessageFormat;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.SimpleTimeZone;
import java.util.TimeZone;
import java.util.UUID;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.RowSet;
import microsoft.sql.DateTimeOffset;















public class SQLServerBulkCopy
  implements AutoCloseable
{
  private static final String loggerClassName = "com.microsoft.sqlserver.jdbc.SQLServerBulkCopy";
  private static final int SQL_SERVER_2016_VERSION = 13;
  
  private class ColumnMapping
  {
    String sourceColumnName = null;
    int sourceColumnOrdinal = -1;
    String destinationColumnName = null;
    int destinationColumnOrdinal = -1;

    
    ColumnMapping(String param1String1, String param1String2) {
      this.sourceColumnName = param1String1;
      this.destinationColumnName = param1String2;
    }

    
    ColumnMapping(String param1String, int param1Int) {
      this.sourceColumnName = param1String;
      this.destinationColumnOrdinal = param1Int;
    }

    
    ColumnMapping(int param1Int, String param1String) {
      this.sourceColumnOrdinal = param1Int;
      this.destinationColumnName = param1String;
    }

    
    ColumnMapping(int param1Int1, int param1Int2) {
      this.sourceColumnOrdinal = param1Int1;
      this.destinationColumnOrdinal = param1Int2;
    }
  }











  
  private static final Logger loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy");




  
  private SQLServerConnection connection;




  
  private SQLServerBulkCopyOptions copyOptions;




  
  private List<ColumnMapping> columnMappings;




  
  private boolean ownsConnection;




  
  private String destinationTableName;




  
  private ISQLServerBulkRecord sourceBulkRecord;




  
  private ResultSet sourceResultSet;




  
  private ResultSetMetaData sourceResultSetMetaData;




  
  private CekTable destCekTable = null;
  private Map<Integer, BulkColumnMetaData> destColumnMetadata;
  private Map<Integer, BulkColumnMetaData> srcColumnMetadata;
  private int destColumnCount;
  private int srcColumnCount;
  
  class BulkColumnMetaData {
    String columnName;
    SSType ssType = null; int jdbcType;
    int precision;
    int scale;
    SQLCollation collation;
    byte[] flags = new byte[2];
    boolean isIdentity = false;
    boolean isNullable;
    String collationName;
    CryptoMetadata cryptoMeta = null;
    DateTimeFormatter dateTimeFormatter = null;

    
    String encryptionType = null;

    
    BulkColumnMetaData(Column param1Column) throws SQLServerException {
      this.cryptoMeta = param1Column.getCryptoMetadata();
      TypeInfo typeInfo = param1Column.getTypeInfo();
      this.columnName = param1Column.getColumnName();
      this.ssType = typeInfo.getSSType();
      this.flags = typeInfo.getFlags();
      this.isIdentity = typeInfo.isIdentity();
      this.isNullable = typeInfo.isNullable();
      this.precision = typeInfo.getPrecision();
      this.scale = typeInfo.getScale();
      this.collation = typeInfo.getSQLCollation();
      this.jdbcType = this.ssType.getJDBCType().getIntValue();
    }



    
    BulkColumnMetaData(String param1String, boolean param1Boolean, int param1Int1, int param1Int2, int param1Int3, DateTimeFormatter param1DateTimeFormatter) throws SQLServerException {
      this.columnName = param1String;
      this.isNullable = param1Boolean;
      this.precision = param1Int1;
      this.scale = param1Int2;
      this.jdbcType = param1Int3;
      this.dateTimeFormatter = param1DateTimeFormatter;
    }

    
    BulkColumnMetaData(Column param1Column, String param1String1, String param1String2) throws SQLServerException {
      this(param1Column);
      this.collationName = param1String1;
      this.encryptionType = param1String2;
    }


    
    BulkColumnMetaData(BulkColumnMetaData param1BulkColumnMetaData, CryptoMetadata param1CryptoMetadata) {
      this.columnName = param1BulkColumnMetaData.columnName;
      this.isNullable = param1BulkColumnMetaData.isNullable;
      this.precision = param1BulkColumnMetaData.precision;
      this.scale = param1BulkColumnMetaData.scale;
      this.jdbcType = param1BulkColumnMetaData.jdbcType;
      this.cryptoMeta = param1CryptoMetadata;
    }
  }




  
  private final class BulkTimeoutTimer
    implements Runnable
  {
    private final int timeoutSeconds;



    
    private int secondsRemaining;



    
    private final TDSCommand command;



    
    private Thread timerThread;



    
    private volatile boolean canceled = false;




    
    BulkTimeoutTimer(int param1Int, TDSCommand param1TDSCommand) {
      assert param1Int > 0;
      assert null != param1TDSCommand;
      
      this.timeoutSeconds = param1Int;
      this.secondsRemaining = param1Int;
      this.command = param1TDSCommand;
    }

    
    final void start() {
      this.timerThread = new Thread(this);
      this.timerThread.setDaemon(true);
      this.timerThread.start();
    }

    
    final void stop() {
      this.canceled = true;
      this.timerThread.interrupt();
    }

    
    final boolean expired() {
      return (this.secondsRemaining <= 0);
    }





    
    public void run() {
      try {
        do {
          if (this.canceled) {
            return;
          }
          Thread.sleep(1000L);
        }
        while (--this.secondsRemaining > 0);
      }
      catch (InterruptedException interruptedException) {
        return;
      } 




      
      try {
        this.command.interrupt(SQLServerException.getErrString("R_queryTimedOut"));
      }
      catch (SQLServerException sQLServerException) {



        
        this.command.log(Level.FINE, "Command could not be timed out. Reason: " + sQLServerException.getMessage());
      } 
    }
  }
  
  private BulkTimeoutTimer timeoutTimer = null;







  
  public SQLServerBulkCopy(Connection paramConnection) throws SQLServerException {
    loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "SQLServerBulkCopy", paramConnection);
    
    if (null == paramConnection || !paramConnection.getClass().equals(SQLServerConnection.class))
    {
      SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, SQLServerException.getErrString("R_invalidDestConnection"), (String)null, false);
    }
    
    if (paramConnection instanceof SQLServerConnection) {
      
      this.connection = (SQLServerConnection)paramConnection;
    }
    else {
      
      SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, SQLServerException.getErrString("R_invalidDestConnection"), (String)null, false);
    } 
    this.ownsConnection = false;


    
    this.copyOptions = new SQLServerBulkCopyOptions();
    
    initializeDefaults();
    
    loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "SQLServerBulkCopy");
  }







  
  public SQLServerBulkCopy(String paramString) throws SQLException {
    loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "SQLServerBulkCopy", "connectionUrl not traced.");
    if (paramString == null || paramString.trim().equals(""))
    {
      throw new SQLServerException(null, SQLServerException.getErrString("R_nullConnection"), null, 0, false);
    }
    
    this.ownsConnection = true;
    SQLServerDriver sQLServerDriver = new SQLServerDriver();
    this.connection = (SQLServerConnection)sQLServerDriver.connect(paramString, null);
    if (null == this.connection)
    {
      throw new SQLServerException(null, SQLServerException.getErrString("R_invalidConnection"), null, 0, false);
    }
    
    this.copyOptions = new SQLServerBulkCopyOptions();
    
    initializeDefaults();
    
    loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "SQLServerBulkCopy");
  }








  
  public void addColumnMapping(int paramInt1, int paramInt2) throws SQLServerException {
    loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "addColumnMapping", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) });
    
    if (0 >= paramInt1) {
      throwInvalidArgument("sourceColumn");
    } else if (0 >= paramInt2) {
      throwInvalidArgument("destinationColumn");
    } 
    this.columnMappings.add(new ColumnMapping(paramInt1, paramInt2));
    
    loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "addColumnMapping");
  }








  
  public void addColumnMapping(int paramInt, String paramString) throws SQLServerException {
    loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "addColumnMapping", new Object[] { Integer.valueOf(paramInt), paramString });
    
    if (0 >= paramInt) {
      throwInvalidArgument("sourceColumn");
    } else if (null == paramString || paramString.isEmpty()) {
      throwInvalidArgument("destinationColumn");
    } 
    this.columnMappings.add(new ColumnMapping(paramInt, paramString.trim()));
    
    loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "addColumnMapping");
  }








  
  public void addColumnMapping(String paramString, int paramInt) throws SQLServerException {
    loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "addColumnMapping", new Object[] { paramString, Integer.valueOf(paramInt) });
    
    if (0 >= paramInt) {
      throwInvalidArgument("destinationColumn");
    } else if (null == paramString || paramString.isEmpty()) {
      throwInvalidArgument("sourceColumn");
    } 
    this.columnMappings.add(new ColumnMapping(paramString.trim(), paramInt));
    
    loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "addColumnMapping");
  }








  
  public void addColumnMapping(String paramString1, String paramString2) throws SQLServerException {
    loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "addColumnMapping", new Object[] { paramString1, paramString2 });
    
    if (null == paramString1 || paramString1.isEmpty()) {
      throwInvalidArgument("sourceColumn");
    } else if (null == paramString2 || paramString2.isEmpty()) {
      throwInvalidArgument("destinationColumn");
    } 
    this.columnMappings.add(new ColumnMapping(paramString1.trim(), paramString2.trim()));
    
    loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "addColumnMapping");
  }




  
  public void clearColumnMappings() {
    loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "clearColumnMappings");
    
    this.columnMappings.clear();
    
    loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "clearColumnMappings");
  }




  
  public void close() {
    loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "close");
    
    if (this.ownsConnection) {
      
      try {
        this.connection.close();
      } catch (SQLException sQLException) {}
    }


    
    loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "close");
  }






  
  public String getDestinationTableName() {
    return this.destinationTableName;
  }







  
  public void setDestinationTableName(String paramString) throws SQLServerException {
    loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "setDestinationTableName", paramString);
    
    if (null == paramString || 0 == paramString.trim().length())
    {
      throwInvalidArgument("tableName");
    }
    
    this.destinationTableName = paramString.trim();
    
    loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "setDestinationTableName");
  }






  
  public SQLServerBulkCopyOptions getBulkCopyOptions() {
    return this.copyOptions;
  }








  
  public void setBulkCopyOptions(SQLServerBulkCopyOptions paramSQLServerBulkCopyOptions) throws SQLServerException {
    loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "updateBulkCopyOptions", paramSQLServerBulkCopyOptions);


    
    if (!this.ownsConnection && paramSQLServerBulkCopyOptions.isUseInternalTransaction())
    {
      SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, SQLServerException.getErrString("R_invalidTransactionOption"), (String)null, false);
    }
    
    this.copyOptions = paramSQLServerBulkCopyOptions;
    
    loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "updateBulkCopyOptions");
  }







  
  public void writeToServer(ResultSet paramResultSet) throws SQLServerException {
    writeResultSet(paramResultSet, false);
  }







  
  public void writeToServer(RowSet paramRowSet) throws SQLServerException {
    writeResultSet(paramRowSet, true);
  }







  
  private void writeResultSet(ResultSet paramResultSet, boolean paramBoolean) throws SQLServerException {
    loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "writeToServer");
    
    if (null == paramResultSet)
    {
      throwInvalidArgument("sourceData");
    }
    
    try {
      if (paramBoolean)
      {
        if (!paramResultSet.isBeforeFirst())
        {
          paramResultSet.beforeFirst();
        
        }
      
      }
      else if (paramResultSet.isClosed())
      {
        SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, SQLServerException.getErrString("R_resultsetClosed"), (String)null, false);
      }
    
    } catch (SQLException sQLException) {
      
      throw new SQLServerException(null, sQLException.getMessage(), null, 0, false);
    } 
    
    this.sourceResultSet = paramResultSet;
    
    this.sourceBulkRecord = null;


    
    try {
      this.sourceResultSetMetaData = this.sourceResultSet.getMetaData();
    }
    catch (SQLException sQLException) {
      
      throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveColMeta"), sQLException);
    } 
    
    writeToServer();
    
    loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "writeToServer");
  }







  
  public void writeToServer(ISQLServerBulkRecord paramISQLServerBulkRecord) throws SQLServerException {
    loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "writeToServer");
    
    if (null == paramISQLServerBulkRecord)
    {
      throwInvalidArgument("sourceData");
    }
    
    this.sourceBulkRecord = paramISQLServerBulkRecord;
    this.sourceResultSet = null;
    
    writeToServer();
    
    loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "writeToServer");
  }




  
  private void initializeDefaults() {
    this.columnMappings = new LinkedList<>();
    this.destinationTableName = null;
    this.sourceBulkRecord = null;
    this.sourceResultSet = null;
    this.sourceResultSetMetaData = null;
    this.srcColumnCount = 0;
    this.srcColumnMetadata = null;
    this.destColumnMetadata = null;
    this.destColumnCount = 0;
  }




  
  private void sendBulkLoadBCP() throws SQLServerException {
    final class InsertBulk
      extends TDSCommand
    {
      InsertBulk() {
        super("InsertBulk", 0);
        int i = SQLServerBulkCopy.this.copyOptions.getBulkCopyTimeout();
        SQLServerBulkCopy.this.timeoutTimer = (i > 0) ? new SQLServerBulkCopy.BulkTimeoutTimer(i, this) : null;
      }

      
      final boolean doExecute() throws SQLServerException {
        if (null != SQLServerBulkCopy.this.timeoutTimer) {
          
          if (logger.isLoggable(Level.FINEST)) {
            logger.finest(toString() + ": Starting bulk timer...");
          }
          SQLServerBulkCopy.this.timeoutTimer.start();
        } 




        
        try {
          while (SQLServerBulkCopy.this.doInsertBulk(this));
        }
        catch (SQLServerException sQLServerException) {

          
          Throwable throwable = sQLServerException;
          while (null != throwable.getCause())
          {
            throwable = throwable.getCause();
          }

          
          if (throwable instanceof SQLException)
          {
            SQLServerBulkCopy.this.checkForTimeoutException((SQLException)throwable, SQLServerBulkCopy.this.timeoutTimer);
          }

          
          throw sQLServerException;
        } 
        
        if (null != SQLServerBulkCopy.this.timeoutTimer) {
          
          if (logger.isLoggable(Level.FINEST)) {
            logger.finest(toString() + ": Stopping bulk timer...");
          }
          SQLServerBulkCopy.this.timeoutTimer.stop();
        } 
        
        return true;
      }
    };
    
    this.connection.executeCommand(new InsertBulk());
  }



  
  private final void writeColumnMetaDataColumnData(TDSWriter paramTDSWriter, int paramInt) throws SQLServerException {
    boolean bool;
    int i = 0, j = 0;
    int k = 0, m = 0, n = 0;
    SQLCollation sQLCollation = null;
    SSType sSType = null;







    
    byte[] arrayOfByte1 = new byte[4];
    arrayOfByte1[0] = 0;
    arrayOfByte1[1] = 0;
    arrayOfByte1[2] = 0;
    
    arrayOfByte1[3] = 0;
    paramTDSWriter.writeBytes(arrayOfByte1);







    
    int i1 = ((ColumnMapping)this.columnMappings.get(paramInt)).destinationColumnOrdinal;
    byte[] arrayOfByte2 = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(i1))).flags;
    paramTDSWriter.writeBytes(arrayOfByte2);







    
    i = ((ColumnMapping)this.columnMappings.get(paramInt)).sourceColumnOrdinal;
    
    k = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(i))).jdbcType;
    m = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(i))).precision;
    n = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(i))).scale;
    boolean bool1 = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(i))).isNullable;

    
    sSType = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(i1))).ssType;
    j = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(i1))).precision;
    
    m = validateSourcePrecision(m, k, j);
    
    sQLCollation = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(i1))).collation;
    if (null == sQLCollation) {
      sQLCollation = this.connection.getDatabaseCollation();
    }
    if (-15 == k || -9 == k || -16 == k) {


      
      bool = (4000 < m || 4000 < j) ? true : false;
    
    }
    else {
      
      bool = (8000 < m || 8000 < j) ? true : false;
    } 






    
    if (this.sourceResultSet instanceof SQLServerResultSet && this.connection.isColumnEncryptionSettingEnabled()) {

      
      k = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(i1))).jdbcType;
      m = j;
      n = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(i1))).scale;
    } 

    
    if ((null != ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(i1))).encryptionType && this.copyOptions.isAllowEncryptedValueModifications()) || null != ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(i1))).cryptoMeta) {


      
      paramTDSWriter.writeByte((byte)-91);
      
      if (bool)
      {
        paramTDSWriter.writeShort((short)-1);
      }
      else
      {
        paramTDSWriter.writeShort((short)m);
      
      }
    
    }
    else if ((1 == k || 12 == k || -1 == k) && (SSType.BINARY == sSType || SSType.VARBINARY == sSType || SSType.VARBINARYMAX == sSType || SSType.IMAGE == sSType)) {

      
      if (bool) {

        
        paramTDSWriter.writeByte((byte)-91);
      }
      else {
        
        paramTDSWriter.writeByte((byte)((SSType.BINARY == sSType) ? 173 : 165));
      } 



      
      paramTDSWriter.writeShort((short)m);
    }
    else {
      
      writeTypeInfo(paramTDSWriter, k, n, m, sSType, sQLCollation, bool, bool1, false);
    } 







    
    CryptoMetadata cryptoMetadata = null;
    if (null != (cryptoMetadata = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(i1))).cryptoMeta)) {
      
      int i3 = cryptoMetadata.baseTypeInfo.getSSType().getJDBCType().asJavaSqlType();
      int i4 = cryptoMetadata.baseTypeInfo.getPrecision();
      
      if (-15 == i3 || -9 == i3 || -16 == i3) {

        
        bool = (4000 < i4) ? true : false;
      } else {
        bool = (8000 < i4) ? true : false;
      } 
      
      paramTDSWriter.writeShort(cryptoMetadata.getOrdinal());
      paramTDSWriter.writeBytes(arrayOfByte1);
      
      writeTypeInfo(paramTDSWriter, i3, cryptoMetadata.baseTypeInfo.getScale(), i4, cryptoMetadata.baseTypeInfo.getSSType(), sQLCollation, bool, bool1, true);







      
      paramTDSWriter.writeByte(cryptoMetadata.cipherAlgorithmId);
      paramTDSWriter.writeByte(cryptoMetadata.encryptionType.getValue());
      paramTDSWriter.writeByte(cryptoMetadata.normalizationRuleVersion);
    } 




    
    int i2 = ((ColumnMapping)this.columnMappings.get(paramInt)).destinationColumnName.length();
    String str = ((ColumnMapping)this.columnMappings.get(paramInt)).destinationColumnName;
    byte[] arrayOfByte3 = new byte[2 * i2];
    
    for (byte b = 0; b < i2; b++) {
      char c = str.charAt(b);
      arrayOfByte3[2 * b] = (byte)(c & 0xFF);
      arrayOfByte3[2 * b + 1] = (byte)(c >> 8 & 0xFF);
    } 
    
    paramTDSWriter.writeByte((byte)i2);
    paramTDSWriter.writeBytes(arrayOfByte3);
  }



  
  private final void writeTypeInfo(TDSWriter paramTDSWriter, int paramInt1, int paramInt2, int paramInt3, SSType paramSSType, SQLCollation paramSQLCollation, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) throws SQLServerException {
    switch (paramInt1) {
      
      case 4:
        if (!paramBoolean2) {
          
          paramTDSWriter.writeByte(TDSType.INT4.byteValue());
        }
        else {
          
          paramTDSWriter.writeByte(TDSType.INTN.byteValue());
          paramTDSWriter.writeByte((byte)4);
        } 
        return;
      
      case -5:
        if (!paramBoolean2) {
          
          paramTDSWriter.writeByte(TDSType.INT8.byteValue());
        }
        else {
          
          paramTDSWriter.writeByte(TDSType.INTN.byteValue());
          paramTDSWriter.writeByte((byte)8);
        } 
        return;
      
      case -7:
        if (!paramBoolean2) {
          
          paramTDSWriter.writeByte(TDSType.BIT1.byteValue());
        }
        else {
          
          paramTDSWriter.writeByte(TDSType.BITN.byteValue());
          paramTDSWriter.writeByte((byte)1);
        } 
        return;
      
      case 5:
        if (!paramBoolean2) {
          
          paramTDSWriter.writeByte(TDSType.INT2.byteValue());
        }
        else {
          
          paramTDSWriter.writeByte(TDSType.INTN.byteValue());
          paramTDSWriter.writeByte((byte)2);
        } 
        return;
      
      case -6:
        if (!paramBoolean2) {
          
          paramTDSWriter.writeByte(TDSType.INT1.byteValue());
        }
        else {
          
          paramTDSWriter.writeByte(TDSType.INTN.byteValue());
          paramTDSWriter.writeByte((byte)1);
        } 
        return;
      
      case 8:
        if (!paramBoolean2) {
          
          paramTDSWriter.writeByte(TDSType.FLOAT8.byteValue());
        }
        else {
          
          paramTDSWriter.writeByte(TDSType.FLOATN.byteValue());
          paramTDSWriter.writeByte((byte)8);
        } 
        return;
      
      case 7:
        if (!paramBoolean2) {
          
          paramTDSWriter.writeByte(TDSType.FLOAT4.byteValue());
        }
        else {
          
          paramTDSWriter.writeByte(TDSType.FLOATN.byteValue());
          paramTDSWriter.writeByte((byte)4);
        } 
        return;
      
      case -148:
      case -146:
      case 2:
      case 3:
        if (paramBoolean3 && (SSType.MONEY == paramSSType || SSType.SMALLMONEY == paramSSType)) {
          
          paramTDSWriter.writeByte(TDSType.MONEYN.byteValue());
          if (SSType.MONEY == paramSSType) {
            paramTDSWriter.writeByte((byte)8);
          } else {
            paramTDSWriter.writeByte((byte)4);
          } 
        } else {
          
          if (3 == paramInt1) {
            paramTDSWriter.writeByte(TDSType.DECIMALN.byteValue());
          } else {
            paramTDSWriter.writeByte(TDSType.NUMERICN.byteValue());
          }  paramTDSWriter.writeByte((byte)17);
          paramTDSWriter.writeByte((byte)paramInt3);
          paramTDSWriter.writeByte((byte)paramInt2);
        } 
        return;
      
      case -145:
      case 1:
        if (paramBoolean3 && SSType.GUID == paramSSType) {
          
          paramTDSWriter.writeByte(TDSType.GUID.byteValue());
          paramTDSWriter.writeByte((byte)16);
        
        }
        else {
          
          paramTDSWriter.writeByte(TDSType.BIGCHAR.byteValue());
          
          paramTDSWriter.writeShort((short)paramInt3);
          
          paramSQLCollation.writeCollation(paramTDSWriter);
        } 
        return;
      
      case -15:
        paramTDSWriter.writeByte(TDSType.NCHAR.byteValue());
        paramTDSWriter.writeShort(paramBoolean3 ? (short)paramInt3 : (short)(2 * paramInt3));
        paramSQLCollation.writeCollation(paramTDSWriter);
        return;

      
      case -1:
      case 12:
        paramTDSWriter.writeByte(TDSType.BIGVARCHAR.byteValue());
        if (paramBoolean1) {
          
          paramTDSWriter.writeShort((short)-1);
        }
        else {
          
          paramTDSWriter.writeShort((short)paramInt3);
        } 
        paramSQLCollation.writeCollation(paramTDSWriter);
        return;
      
      case -16:
      case -9:
        paramTDSWriter.writeByte(TDSType.NVARCHAR.byteValue());
        if (paramBoolean1) {
          
          paramTDSWriter.writeShort((short)-1);
        }
        else {
          
          paramTDSWriter.writeShort(paramBoolean3 ? (short)paramInt3 : (short)(2 * paramInt3));
        } 
        paramSQLCollation.writeCollation(paramTDSWriter);
        return;
      
      case -2:
        paramTDSWriter.writeByte(TDSType.BIGBINARY.byteValue());
        paramTDSWriter.writeShort((short)paramInt3);
        return;

      
      case -4:
      case -3:
        paramTDSWriter.writeByte(TDSType.BIGVARBINARY.byteValue());
        if (paramBoolean1) {
          
          paramTDSWriter.writeShort((short)-1);
        }
        else {
          
          paramTDSWriter.writeShort((short)paramInt3);
        } 
        return;
      
      case -151:
      case -150:
      case 93:
        if (!paramBoolean3 && null != this.sourceBulkRecord) {
          
          paramTDSWriter.writeByte(TDSType.BIGVARCHAR.byteValue());
          paramTDSWriter.writeShort((short)paramInt3);
          paramSQLCollation.writeCollation(paramTDSWriter);
        }
        else {
          
          switch (paramSSType) {
            
            case DATE:
              if (!paramBoolean2) {
                paramTDSWriter.writeByte(TDSType.DATETIME4.byteValue());
              } else {
                
                paramTDSWriter.writeByte(TDSType.DATETIMEN.byteValue());
                paramTDSWriter.writeByte((byte)4);
              } 
              return;
            case TIME:
              if (!paramBoolean2) {
                paramTDSWriter.writeByte(TDSType.DATETIME8.byteValue());
              } else {
                
                paramTDSWriter.writeByte(TDSType.DATETIMEN.byteValue());
                paramTDSWriter.writeByte((byte)8);
              } 
              return;
          } 
          
          paramTDSWriter.writeByte(TDSType.DATETIME2N.byteValue());
          paramTDSWriter.writeByte((byte)paramInt2);
        } 
        return;







      
      case 91:
        if (!paramBoolean3 && null != this.sourceBulkRecord) {
          
          paramTDSWriter.writeByte(TDSType.BIGVARCHAR.byteValue());
          paramTDSWriter.writeShort((short)paramInt3);
          paramSQLCollation.writeCollation(paramTDSWriter);
        }
        else {
          
          paramTDSWriter.writeByte(TDSType.DATEN.byteValue());
        } 
        return;
      
      case 92:
        if (!paramBoolean3 && null != this.sourceBulkRecord) {
          
          paramTDSWriter.writeByte(TDSType.BIGVARCHAR.byteValue());
          paramTDSWriter.writeShort((short)paramInt3);
          paramSQLCollation.writeCollation(paramTDSWriter);
        }
        else {
          
          paramTDSWriter.writeByte(TDSType.TIMEN.byteValue());
          paramTDSWriter.writeByte((byte)paramInt2);
        } 
        return;

      
      case 2013:
      case 2014:
        paramTDSWriter.writeByte(TDSType.DATETIMEOFFSETN.byteValue());
        paramTDSWriter.writeByte((byte)paramInt2);
        return;
      
      case -155:
        if (!paramBoolean3 && null != this.sourceBulkRecord) {
          
          paramTDSWriter.writeByte(TDSType.BIGVARCHAR.byteValue());
          paramTDSWriter.writeShort((short)paramInt3);
          paramSQLCollation.writeCollation(paramTDSWriter);
        }
        else {
          
          paramTDSWriter.writeByte(TDSType.DATETIMEOFFSETN.byteValue());
          paramTDSWriter.writeByte((byte)paramInt2);
        } 
        return;
    } 
    
    MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_BulkTypeNotSupported"));
    String str = JDBCType.of(paramInt1).toString().toLowerCase(Locale.ENGLISH);
    throw new SQLServerException(messageFormat.format(new Object[] { str }, ), null, 0, null);
  }








  
  private void writeCekTable(TDSWriter paramTDSWriter) throws SQLServerException {
    if (this.connection.getServerSupportsColumnEncryption())
    {
      if (null != this.destCekTable && 0 < this.destCekTable.getSize()) {
        
        paramTDSWriter.writeShort((short)this.destCekTable.getSize());
        for (byte b = 0; b < this.destCekTable.getSize(); b++)
        {
          paramTDSWriter.writeInt(((EncryptionKeyInfo)this.destCekTable.getCekTableEntry(b).getColumnEncryptionKeyValues().get(0)).databaseId);
          paramTDSWriter.writeInt(((EncryptionKeyInfo)this.destCekTable.getCekTableEntry(b).getColumnEncryptionKeyValues().get(0)).cekId);
          paramTDSWriter.writeInt(((EncryptionKeyInfo)this.destCekTable.getCekTableEntry(b).getColumnEncryptionKeyValues().get(0)).cekVersion);
          paramTDSWriter.writeBytes(((EncryptionKeyInfo)this.destCekTable.getCekTableEntry(b).getColumnEncryptionKeyValues().get(0)).cekMdVersion);

          
          paramTDSWriter.writeByte((byte)0);
        }
      
      }
      else {
        
        paramTDSWriter.writeShort((short)0);
      } 
    }
  }


























  
  private final void writeColumnMetaData(TDSWriter paramTDSWriter) throws SQLServerException {
    paramTDSWriter.writeByte((byte)-127);








    
    byte[] arrayOfByte = new byte[2];
    arrayOfByte[0] = (byte)(this.columnMappings.size() & 0xFF);
    arrayOfByte[1] = (byte)(this.columnMappings.size() >> 8 & 0xFF);
    paramTDSWriter.writeBytes(arrayOfByte);
    
    writeCekTable(paramTDSWriter);




    
    for (byte b = 0; b < this.columnMappings.size(); b++)
    {
      writeColumnMetaDataColumnData(paramTDSWriter, b);
    }
  }




  
  private void checkForTimeoutException(SQLException paramSQLException, BulkTimeoutTimer paramBulkTimeoutTimer) throws SQLServerException {
    if (null != paramSQLException.getSQLState() && paramSQLException.getSQLState().equals(SQLState.STATEMENT_CANCELED.getSQLStateCode()) && paramBulkTimeoutTimer.expired()) {



      
      if (this.copyOptions.isUseInternalTransaction())
      {
        this.connection.rollback();
      }
      
      throw new SQLServerException(SQLServerException.getErrString("R_queryTimedOut"), SQLState.STATEMENT_CANCELED, DriverError.NOT_SET, null);
    } 
  }













  
  private void validateDataTypeConversions(int paramInt1, int paramInt2) throws SQLServerException {
    CryptoMetadata cryptoMetadata1 = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt1))).cryptoMeta;
    CryptoMetadata cryptoMetadata2 = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).cryptoMeta;
    
    JDBCType jDBCType = (null != cryptoMetadata1) ? cryptoMetadata1.baseTypeInfo.getSSType().getJDBCType() : JDBCType.of(((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt1))).jdbcType);


    
    SSType sSType = (null != cryptoMetadata2) ? cryptoMetadata2.baseTypeInfo.getSSType() : ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).ssType;



    
    if (!jDBCType.convertsTo(sSType))
    {
      DataTypes.throwConversionError(jDBCType.toString(), sSType.toString());
    }
  }






  
  private String getDestTypeFromSrcType(int paramInt1, int paramInt2, TDSWriter paramTDSWriter) throws SQLServerException {
    boolean bool;
    SSType sSType = (null != ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).cryptoMeta) ? ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).cryptoMeta.baseTypeInfo.getSSType() : ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).ssType;


    
    int i = 0, j = 0, k = 0;
    int m = 0;
    
    i = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt1))).jdbcType;
    
    j = m = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt1))).precision;
    int n = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).precision;
    k = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt1))).scale;
    
    CryptoMetadata cryptoMetadata = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).cryptoMeta;
    if (null != cryptoMetadata) {

      
      paramTDSWriter.setCryptoMetaData(((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).cryptoMeta);

      
      if (8000 < n)
      {
        return "varbinary(max)";
      }

      
      return "varbinary(" + ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).precision + ")";
    } 


    
    if (null != this.sourceResultSet && null != ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).encryptionType && this.copyOptions.isAllowEncryptedValueModifications())
    {

      
      return "varbinary(" + j + ")";
    }
    j = validateSourcePrecision(m, i, n);

    
    if (this.sourceResultSet instanceof SQLServerResultSet && this.connection.isColumnEncryptionSettingEnabled()) {

      
      i = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).jdbcType;
      j = n;
      k = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).scale;
    } 
    
    if (-15 == i || -9 == i || -16 == i) {


      
      bool = (4000 < m || 4000 < n) ? true : false;
    
    }
    else {
      
      bool = (8000 < m || 8000 < n) ? true : false;
    } 


    
    if (Util.isCharType(i).booleanValue() && Util.isBinaryType(sSType).booleanValue()) {
      
      if (bool) {
        return "varbinary(max)";
      }
      
      return sSType.toString() + "(" + ((8000 < n) ? "max" : (String)Integer.valueOf(n)) + ")";
    } 



    
    switch (i) {

      
      case 4:
        return "int";
      
      case 5:
        return "smallint";
      
      case -5:
        return "bigint";
      
      case -7:
        return "bit";
      
      case -6:
        return "tinyint";
      
      case 8:
        return "float";
      
      case 7:
        return "real";
      
      case -148:
      case -146:
      case 3:
        return "decimal(" + j + ", " + k + ")";
      
      case 2:
        return "numeric(" + j + ", " + k + ")";

      
      case -145:
      case 1:
        return "char(" + j + ")";
      
      case -15:
        return "NCHAR(" + j + ")";


      
      case -1:
      case 12:
        if (bool)
        {
          return "varchar(max)";
        }

        
        return "varchar(" + j + ")";



      
      case -16:
      case -9:
        if (bool)
        {
          return "NVARCHAR(MAX)";
        }

        
        return "NVARCHAR(" + j + ")";


      
      case -2:
        return "binary(" + j + ")";
      
      case -4:
      case -3:
        if (bool) {
          return "varbinary(max)";
        }
        return "varbinary(" + j + ")";
      
      case -151:
      case -150:
      case 93:
        switch (sSType) {
          
          case DATE:
            if (null != this.sourceBulkRecord)
            {
              return "varchar(" + ((0 == j) ? n : j) + ")";
            }

            
            return "smalldatetime";
          
          case TIME:
            if (null != this.sourceBulkRecord)
            {
              return "varchar(" + ((0 == j) ? n : j) + ")";
            }

            
            return "datetime";
        } 







        
        if (null != this.sourceBulkRecord)
        {
          return "varchar(" + ((0 == j) ? n : j) + ")";
        }

        
        return "datetime2(" + k + ")";








      
      case 91:
        if (null != this.sourceBulkRecord)
        {
          return "varchar(" + ((0 == j) ? n : j) + ")";
        }

        
        return "date";







      
      case 92:
        if (null != this.sourceBulkRecord)
        {
          return "varchar(" + ((0 == j) ? n : j) + ")";
        }

        
        return "time(" + k + ")";


      
      case 2013:
      case 2014:
        return "datetimeoffset(" + k + ")";






      
      case -155:
        if (null != this.sourceBulkRecord)
        {
          return "varchar(" + ((0 == j) ? n : j) + ")";
        }

        
        return "datetimeoffset(" + k + ")";
    } 


    
    MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_BulkTypeNotSupported"));
    Object[] arrayOfObject = { JDBCType.of(i).toString().toLowerCase(Locale.ENGLISH) };
    SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, messageFormat.format(arrayOfObject), (String)null, true);

    
    return null;
  }




  
  private final String createInsertBulkCommand(TDSWriter paramTDSWriter) throws SQLServerException {
    StringBuilder stringBuilder = new StringBuilder();
    Vector<String> vector = new Vector();
    String str = " , ";
    stringBuilder.append("INSERT BULK " + this.destinationTableName + " (");
    
    for (byte b = 0; b < this.columnMappings.size(); b++) {
      
      if (b == this.columnMappings.size() - 1)
      {
        str = " ) ";
      }
      ColumnMapping columnMapping = this.columnMappings.get(b);
      String str1 = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(((ColumnMapping)this.columnMappings.get(b)).destinationColumnOrdinal))).collationName;
      
      String str2 = "";

      
      String str3 = getDestTypeFromSrcType(columnMapping.sourceColumnOrdinal, columnMapping.destinationColumnOrdinal, paramTDSWriter).toUpperCase(Locale.ENGLISH);


      
      if (null != str1 && str1.trim().length() > 0)
      {
        
        if (null != str3 && (str3.toLowerCase().trim().startsWith("char") || str3.toLowerCase().trim().startsWith("varchar")))
        {
          
          str2 = " COLLATE " + str1; } 
      }
      stringBuilder.append("[" + columnMapping.destinationColumnName + "] " + str3 + str2 + str);
    } 





    
    if (true == this.copyOptions.isCheckConstraints())
    {
      vector.add("CHECK_CONSTRAINTS");
    }
    
    if (true == this.copyOptions.isFireTriggers())
    {
      vector.add("FIRE_TRIGGERS");
    }
    
    if (true == this.copyOptions.isKeepNulls())
    {
      vector.add("KEEP_NULLS");
    }
    
    if (this.copyOptions.getBatchSize() > 0)
    {
      vector.add("ROWS_PER_BATCH = " + this.copyOptions.getBatchSize());
    }
    
    if (true == this.copyOptions.isTableLock())
    {
      vector.add("TABLOCK");
    }
    
    if (true == this.copyOptions.isAllowEncryptedValueModifications())
    {
      vector.add("ALLOW_ENCRYPTED_VALUE_MODIFICATIONS");
    }
    
    Iterator<String> iterator = vector.iterator();
    if (iterator.hasNext()) {
      
      stringBuilder.append(" with (");
      while (iterator.hasNext()) {
        
        stringBuilder.append(((String)iterator.next()).toString());
        if (iterator.hasNext())
        {
          stringBuilder.append(", ");
        }
      } 
      stringBuilder.append(")");
    } 
    
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.finer(toString() + " TDSCommand: " + stringBuilder);
    }
    return stringBuilder.toString();
  }




  
  private final boolean doInsertBulk(TDSCommand paramTDSCommand) throws SQLServerException {
    if (this.copyOptions.isUseInternalTransaction())
    {
      
      this.connection.setAutoCommit(false);
    }

    
    TDSWriter tDSWriter = paramTDSCommand.startRequest((byte)1);
    String str = createInsertBulkCommand(tDSWriter);
    tDSWriter.writeString(str);
    TDSParser.parse(paramTDSCommand.startResponse(), paramTDSCommand.getLogContext());

    
    tDSWriter = paramTDSCommand.startRequest((byte)7);
    
    boolean bool = false;

    
    try {
      writeColumnMetaData(tDSWriter);

      
      bool = writeBatchData(tDSWriter);
    }
    catch (SQLServerException sQLServerException) {

      
      writePacketDataDone(tDSWriter);

      
      paramTDSCommand.startRequest((byte)6);
      
      TDSParser.parse(paramTDSCommand.startResponse(), paramTDSCommand.getLogContext());
      paramTDSCommand.interrupt(sQLServerException.getMessage());
      paramTDSCommand.onRequestComplete();
      
      throw sQLServerException;
    
    }
    finally {
      
      tDSWriter.setCryptoMetaData(null);
    } 




    
    writePacketDataDone(tDSWriter);

    
    TDSParser.parse(paramTDSCommand.startResponse(), paramTDSCommand.getLogContext());
    
    if (this.copyOptions.isUseInternalTransaction())
    {
      
      this.connection.commit();
    }
    
    return bool;
  }





  
  private final void writePacketDataDone(TDSWriter paramTDSWriter) throws SQLServerException {
    paramTDSWriter.writeByte((byte)-3);
    paramTDSWriter.writeLong(0L);
    paramTDSWriter.writeInt(0);
  }




  
  private void throwInvalidArgument(String paramString) throws SQLServerException {
    MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
    Object[] arrayOfObject = { paramString };
    SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, messageFormat.format(arrayOfObject), (String)null, false);
  }





  
  private void throwInvalidJavaToJDBC(String paramString, int paramInt) throws SQLServerException {
    MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorConvertingValue"));
    throw new SQLServerException(messageFormat.format(new Object[] { paramString, Integer.valueOf(paramInt) }, ), null, 0, null);
  }




  
  private void writeToServer() throws SQLServerException {
    if (this.connection.isClosed())
    {
      SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, SQLServerException.getErrString("R_connectionIsClosed"), "08003", false);
    }





    
    long l1 = System.currentTimeMillis();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.finer(toString() + " Start writeToServer: " + l1);
    }
    getDestinationMetadata();


    
    getSourceMetadata();
    
    validateColumnMappings();
    
    sendBulkLoadBCP();
    
    long l2 = System.currentTimeMillis();
    if (loggerExternal.isLoggable(Level.FINER)) {
      
      loggerExternal.finer(toString() + " End writeToServer: " + l2);
      int i = (int)((l2 - l1) / 1000L);
      loggerExternal.finer(toString() + "Time elapsed: " + i + " seconds");
    } 
  }



  
  private void validateStringBinaryLengths(Object paramObject, int paramInt1, int paramInt2) throws SQLServerException {
    int i = 0;
    int j = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).precision;
    int k = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt1))).jdbcType;
    SSType sSType = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).ssType;
    
    if ((Util.isCharType(k).booleanValue() && Util.isCharType(sSType).booleanValue()) || (Util.isBinaryType(k).booleanValue() && Util.isBinaryType(sSType).booleanValue())) {

      
      if (paramObject instanceof String) {
        
        i = ((String)paramObject).length();
      }
      else if (paramObject instanceof byte[]) {
        
        i = ((byte[])paramObject).length;
      } else {
        return;
      } 


      
      if (i > j) {
        
        String str1 = JDBCType.of(k) + "(" + i + ")";
        String str2 = sSType.toString() + "(" + j + ")";
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
        Object[] arrayOfObject = { str1, str2 };
        throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
      } 
    } 
  }




  
  private void getDestinationMetadata() throws SQLServerException {
    if (null == this.destinationTableName)
    {
      SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, SQLServerException.getErrString("R_invalidDestinationTable"), (String)null, false);
    }
    
    SQLServerResultSet sQLServerResultSet1 = null;
    SQLServerResultSet sQLServerResultSet2 = null;

    
    try {
      sQLServerResultSet1 = ((SQLServerStatement)this.connection.createStatement()).executeQueryInternal("SET FMTONLY ON SELECT * FROM " + this.destinationTableName + " SET FMTONLY OFF ");




      
      this.destColumnCount = sQLServerResultSet1.getMetaData().getColumnCount();
      this.destColumnMetadata = new HashMap<>();
      this.destCekTable = sQLServerResultSet1.getCekTable();
      
      if (!this.connection.getServerSupportsColumnEncryption()) {
        
        sQLServerResultSet2 = ((SQLServerStatement)this.connection.createStatement()).executeQueryInternal("select collation_name from sys.columns where object_id=OBJECT_ID('" + this.destinationTableName + "') " + "order by column_id ASC");

      
      }
      else {

        
        sQLServerResultSet2 = ((SQLServerStatement)this.connection.createStatement()).executeQueryInternal("select collation_name, encryption_type from sys.columns where object_id=OBJECT_ID('" + this.destinationTableName + "') " + "order by column_id ASC");
      } 



      
      for (byte b = 1; b <= this.destColumnCount; b++) {
        if (sQLServerResultSet2.next())
        {
          if (!this.connection.getServerSupportsColumnEncryption()) {
            this.destColumnMetadata.put(Integer.valueOf(b), new BulkColumnMetaData(sQLServerResultSet1.getColumn(b), sQLServerResultSet2.getString("collation_name"), null));
          
          }
          else {
            
            this.destColumnMetadata.put(Integer.valueOf(b), new BulkColumnMetaData(sQLServerResultSet1.getColumn(b), sQLServerResultSet2.getString("collation_name"), sQLServerResultSet2.getString("encryption_type")));
          
          }

        
        }
        else
        {
          
          this.destColumnMetadata.put(Integer.valueOf(b), new BulkColumnMetaData(sQLServerResultSet1.getColumn(b)));
        }
      
      } 
    } catch (SQLException sQLException) {
      
      throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveColMeta"), sQLException);
    }
    finally {
      
      if (null != sQLServerResultSet1) sQLServerResultSet1.close(); 
      if (null != sQLServerResultSet2) sQLServerResultSet2.close();
    
    } 
  }





  
  private void getSourceMetadata() throws SQLServerException {
    this.srcColumnMetadata = new HashMap<>();
    
    if (null != this.sourceResultSet) {
      
      try {
        this.srcColumnCount = this.sourceResultSetMetaData.getColumnCount();
        for (byte b = 1; b <= this.srcColumnCount; b++)
        {
          this.srcColumnMetadata.put(Integer.valueOf(b), new BulkColumnMetaData(this.sourceResultSetMetaData.getColumnName(b), !(0 == this.sourceResultSetMetaData.isNullable(b)), this.sourceResultSetMetaData.getPrecision(b), this.sourceResultSetMetaData.getScale(b), this.sourceResultSetMetaData.getColumnType(b), null));



        
        }


      
      }
      catch (SQLException sQLException) {
        
        throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveColMeta"), sQLException);
      }
    
    } else if (null != this.sourceBulkRecord) {
      
      Set<Integer> set = this.sourceBulkRecord.getColumnOrdinals();
      this.srcColumnCount = set.size();
      if (0 == this.srcColumnCount)
      {
        
        throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveColMeta"), null);
      }

      
      Iterator<Integer> iterator = set.iterator();
      while (iterator.hasNext())
      {
        int i = ((Integer)iterator.next()).intValue();
        this.srcColumnMetadata.put(Integer.valueOf(i), new BulkColumnMetaData(this.sourceBulkRecord.getColumnName(i), true, this.sourceBulkRecord.getPrecision(i), this.sourceBulkRecord.getScale(i), this.sourceBulkRecord.getColumnType(i), (this.sourceBulkRecord instanceof SQLServerBulkCSVFileRecord) ? ((SQLServerBulkCSVFileRecord)this.sourceBulkRecord).getColumnDateTimeFormatter(i) : null));



      
      }




    
    }
    else {



      
      throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveColMeta"), null);
    } 
  }




  
  private int validateSourcePrecision(int paramInt1, int paramInt2, int paramInt3) {
    if (1 > paramInt1 && Util.isCharType(paramInt2).booleanValue())
    {
      paramInt1 = paramInt3;
    }
    return paramInt1;
  }





  
  private void validateColumnMappings() throws SQLServerException {
    try {
      if (this.columnMappings.isEmpty()) {


        
        if (this.destColumnCount != this.srcColumnCount)
        {
          throw new SQLServerException(SQLServerException.getErrString("R_schemaMismatch"), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
        }




        
        for (byte b = 1; b <= this.srcColumnCount; b++) {

          
          if (!((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(b))).isIdentity || this.copyOptions.isKeepIdentity()) {
            
            ColumnMapping columnMapping = new ColumnMapping(b, b);
            
            columnMapping.destinationColumnName = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(b))).columnName;
            this.columnMappings.add(columnMapping);
          } 
        } 
        
        if (null != this.sourceBulkRecord) {
          
          Set<Integer> set = this.sourceBulkRecord.getColumnOrdinals();
          Iterator<Integer> iterator = set.iterator();
          int i = 1;
          while (iterator.hasNext())
          {
            int j = ((Integer)iterator.next()).intValue();
            if (i != j) {
              
              MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidColumn"));
              Object[] arrayOfObject = { Integer.valueOf(j) };
              throw new SQLServerException(messageFormat.format(arrayOfObject), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
            } 
            i++;
          }
        
        } 
      } else {
        
        int i = this.columnMappings.size();
        
        byte b;
        
        for (b = 0; b < i; b++) {
          
          ColumnMapping columnMapping = this.columnMappings.get(b);

          
          if (-1 == columnMapping.destinationColumnOrdinal) {
            
            boolean bool = false;
            
            for (byte b1 = 1; b1 <= this.destColumnCount; b1++) {
              
              if (((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(b1))).columnName.equals(columnMapping.destinationColumnName)) {
                
                bool = true;
                columnMapping.destinationColumnOrdinal = b1;
                
                break;
              } 
            } 
            if (!bool) {
              
              MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidColumn"));
              Object[] arrayOfObject = { columnMapping.destinationColumnName };
              throw new SQLServerException(messageFormat.format(arrayOfObject), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
            } 
          } else {
            if (0 > columnMapping.destinationColumnOrdinal || this.destColumnCount < columnMapping.destinationColumnOrdinal) {
              
              MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidColumn"));
              Object[] arrayOfObject = { Integer.valueOf(columnMapping.destinationColumnOrdinal) };
              throw new SQLServerException(messageFormat.format(arrayOfObject), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
            } 

            
            columnMapping.destinationColumnName = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(columnMapping.destinationColumnOrdinal))).columnName;
          } 
        } 

        
        for (b = 0; b < i; b++) {
          
          ColumnMapping columnMapping = this.columnMappings.get(b);

          
          if (-1 == columnMapping.sourceColumnOrdinal) {
            
            boolean bool = false;
            if (null != this.sourceResultSet) {
              
              int j = this.sourceResultSetMetaData.getColumnCount();
              for (byte b1 = 1; b1 <= j; b1++) {
                
                if (this.sourceResultSetMetaData.getColumnName(b1).equals(columnMapping.sourceColumnName)) {
                  
                  bool = true;
                  columnMapping.sourceColumnOrdinal = b1;

                  
                  break;
                } 
              } 
            } else {
              Set<Integer> set = this.sourceBulkRecord.getColumnOrdinals();
              Iterator<Integer> iterator = set.iterator();
              while (iterator.hasNext()) {
                
                int j = ((Integer)iterator.next()).intValue();
                if (this.sourceBulkRecord.getColumnName(j).equals(columnMapping.sourceColumnName)) {
                  
                  bool = true;
                  columnMapping.sourceColumnOrdinal = j;
                  
                  break;
                } 
              } 
            } 
            if (!bool)
            {
              MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidColumn"));
              Object[] arrayOfObject = { columnMapping.sourceColumnName };
              throw new SQLServerException(messageFormat.format(arrayOfObject), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
            }
          
          } else {
            
            boolean bool = true;
            if (null != this.sourceResultSet) {
              
              int j = this.sourceResultSetMetaData.getColumnCount();
              if (0 < columnMapping.sourceColumnOrdinal && j >= columnMapping.sourceColumnOrdinal)
              {
                bool = false;

              
              }
            
            }
            else if (this.srcColumnMetadata.containsKey(Integer.valueOf(columnMapping.sourceColumnOrdinal))) {
              
              bool = false;
            } 

            
            if (bool) {
              
              MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidColumn"));
              Object[] arrayOfObject = { Integer.valueOf(columnMapping.sourceColumnOrdinal) };
              throw new SQLServerException(messageFormat.format(arrayOfObject), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
            } 
          } 

          
          if (((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(columnMapping.destinationColumnOrdinal))).isIdentity && !this.copyOptions.isKeepIdentity())
          {
            this.columnMappings.remove(b);
            i--;
            b--;
          }
        
        } 
      } 
    } catch (SQLException sQLException) {

      
      if (sQLException instanceof SQLServerException && null != sQLException.getSQLState() && sQLException.getSQLState().equals(SQLState.COL_NOT_FOUND.getSQLStateCode()))
      {
        throw (SQLServerException)sQLException;
      }

      
      throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveColMeta"), sQLException);
    } 


    
    if (this.columnMappings.isEmpty())
    {
      throw new SQLServerException(null, SQLServerException.getErrString("R_BulkColumnMappingsIsEmpty"), null, 0, false);
    }
  }




  
  private void writeNullToTdsWriter(TDSWriter paramTDSWriter, int paramInt, boolean paramBoolean) throws SQLServerException {
    switch (paramInt) {
      
      case -16:
      case -15:
      case -9:
      case -4:
      case -3:
      case -2:
      case -1:
      case 1:
      case 12:
        if (paramBoolean) {
          
          paramTDSWriter.writeLong(-1L);
        }
        else {
          
          paramTDSWriter.writeByte((byte)-1);
          paramTDSWriter.writeByte((byte)-1);
        } 
        return;
      case -155:
      case -7:
      case -6:
      case -5:
      case 2:
      case 3:
      case 4:
      case 5:
      case 7:
      case 8:
      case 91:
      case 92:
      case 93:
      case 2013:
      case 2014:
        paramTDSWriter.writeByte((byte)0);
        return;
    } 
    MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_BulkTypeNotSupported"));
    Object[] arrayOfObject = { JDBCType.of(paramInt).toString().toLowerCase(Locale.ENGLISH) };
    SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, messageFormat.format(arrayOfObject), (String)null, true);
  }















  
  private void writeColumnToTdsWriter(TDSWriter paramTDSWriter, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, int paramInt4, int paramInt5, boolean paramBoolean2, Object paramObject) throws SQLServerException {
    SSType sSType = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt5))).ssType;
    
    paramInt1 = validateSourcePrecision(paramInt1, paramInt3, ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt5))).precision);
    
    CryptoMetadata cryptoMetadata = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt4))).cryptoMeta;
    if ((null != ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt5))).encryptionType && this.copyOptions.isAllowEncryptedValueModifications()) || null != ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt5))).cryptoMeta) {



      
      paramInt3 = -3;




    
    }
    else if (null != cryptoMetadata) {
      
      paramInt3 = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt5))).jdbcType;
      paramInt2 = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt5))).scale;
    }
    else if (null != this.sourceBulkRecord) {


      
      switch (paramInt3) {
        
        case -155:
        case 91:
        case 92:
        case 93:
          paramInt3 = 12;
          break;
      } 



    
    } 
    switch (paramInt3) {
      
      case 4:
        if (null == paramObject) {
          
          writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
        }
        else {
          
          if (paramBoolean1)
          {
            paramTDSWriter.writeByte((byte)4);
          }
          paramTDSWriter.writeInt(((Integer)paramObject).intValue());
        } 
        return;
      
      case 5:
        if (null == paramObject) {
          
          writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
        }
        else {
          
          if (paramBoolean1)
          {
            paramTDSWriter.writeByte((byte)2);
          }
          paramTDSWriter.writeShort(((Number)paramObject).shortValue());
        } 
        return;
      
      case -5:
        if (null == paramObject) {
          
          writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
        }
        else {
          
          if (paramBoolean1)
          {
            paramTDSWriter.writeByte((byte)8);
          }
          paramTDSWriter.writeLong(((Long)paramObject).longValue());
        } 
        return;
      
      case -7:
        if (null == paramObject) {
          
          writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
        }
        else {
          
          if (paramBoolean1)
          {
            paramTDSWriter.writeByte((byte)1);
          }
          paramTDSWriter.writeByte((byte)(((Boolean)paramObject).booleanValue() ? 1 : 0));
        } 
        return;
      
      case -6:
        if (null == paramObject) {
          
          writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
        }
        else {
          
          if (paramBoolean1)
          {
            paramTDSWriter.writeByte((byte)1);
          }

          
          paramTDSWriter.writeByte((byte)(((Number)paramObject).shortValue() & 0xFF));
        } 
        return;

      
      case 8:
        if (null == paramObject) {
          
          writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
        }
        else {
          
          if (paramBoolean1)
          {
            paramTDSWriter.writeByte((byte)8);
          }
          paramTDSWriter.writeDouble(((Double)paramObject).doubleValue());
        } 
        return;
      
      case 7:
        if (null == paramObject) {
          
          writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
        }
        else {
          
          if (paramBoolean1)
          {
            paramTDSWriter.writeByte((byte)4);
          }
          paramTDSWriter.writeReal(Float.valueOf(((Float)paramObject).floatValue()));
        } 
        return;
      
      case -148:
      case -146:
      case 2:
      case 3:
        if (null == paramObject) {
          
          writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
        }
        else {
          
          paramTDSWriter.writeBigDecimal((BigDecimal)paramObject, paramInt3, paramInt1);
        } 
        return;

      
      case -145:
      case -1:
      case 1:
      case 12:
        if (paramBoolean2) {



          
          if (null == paramObject)
          {
            writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
          
          }
          else
          {
            paramTDSWriter.writeLong(-2L);


            
            try {
              Reader reader = null;
              if (paramObject instanceof Reader) {
                
                reader = (Reader)paramObject;
              }
              else {
                
                reader = new StringReader(paramObject.toString());
              } 
              
              if (SSType.BINARY == sSType || SSType.VARBINARY == sSType || SSType.VARBINARYMAX == sSType || SSType.IMAGE == sSType) {
                
                paramTDSWriter.writeNonUnicodeReader(reader, -1L, true, null);

              
              }
              else {


                
                SQLCollation sQLCollation = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt5))).collation;
                
                if (null != sQLCollation) {
                  
                  paramTDSWriter.writeNonUnicodeReader(reader, -1L, false, sQLCollation.getCharset());

                
                }
                else {


                  
                  paramTDSWriter.writeNonUnicodeReader(reader, -1L, false, null);
                } 
              } 



              
              reader.close();
            }
            catch (IOException iOException) {
              
              throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), iOException);
            }
          
          }
        
        }
        else if (null == paramObject) {
          
          writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
        }
        else {
          
          String str = paramObject.toString();
          if (SSType.BINARY == sSType || SSType.VARBINARY == sSType) {
            
            byte[] arrayOfByte = null;
            
            try {
              arrayOfByte = ParameterUtils.HexToBin(str);
            }
            catch (SQLServerException sQLServerException) {
              
              throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), sQLServerException);
            } 
            paramTDSWriter.writeShort((short)arrayOfByte.length);
            paramTDSWriter.writeBytes(arrayOfByte);
          } else {

            
            try {
              
              paramTDSWriter.writeShort((short)str.length());

              
              SQLCollation sQLCollation = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt5))).collation;
              
              if (null != sQLCollation)
              {
                paramTDSWriter.writeBytes(str.getBytes(((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt5))).collation.getCharset()));

              
              }
              else
              {
                
                paramTDSWriter.writeBytes(str.getBytes());
              }
            
            } catch (UnsupportedEncodingException unsupportedEncodingException) {
              
              throw new SQLServerException(SQLServerException.getErrString("R_encodingErrorWritingTDS"), unsupportedEncodingException);
            } 
          } 
        } 
        return;










      
      case -16:
      case -15:
      case -9:
        if (paramBoolean2) {



          
          if (null == paramObject)
          {
            writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
          
          }
          else
          {
            paramTDSWriter.writeLong(-2L);

            
            try {
              Reader reader = null;
              if (paramObject instanceof Reader) {
                
                reader = (Reader)paramObject;
              }
              else {
                
                reader = new StringReader(paramObject.toString());
              } 

              
              paramTDSWriter.writeReader(reader, -1L, true);
              reader.close();
            }
            catch (IOException iOException) {
              
              throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), iOException);
            }
          
          }
        
        }
        else if (null == paramObject) {
          
          writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
        }
        else {
          
          int i = paramObject.toString().length();
          byte[] arrayOfByte = new byte[2];
          arrayOfByte[0] = (byte)(2 * i & 0xFF);
          arrayOfByte[1] = (byte)(2 * i >> 8 & 0xFF);
          paramTDSWriter.writeBytes(arrayOfByte);
          paramTDSWriter.writeString(paramObject.toString());
        } 
        return;

      
      case -4:
      case -3:
      case -2:
        if (paramBoolean2) {


          
          if (null == paramObject)
          {
            writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
          
          }
          else
          {
            paramTDSWriter.writeLong(-2L);

            
            try {
              InputStream inputStream = null;
              if (paramObject instanceof InputStream) {
                
                inputStream = (InputStream)paramObject;

              
              }
              else if (paramObject instanceof byte[]) {
                
                inputStream = new ByteArrayInputStream((byte[])paramObject);
              } else {
                
                inputStream = new ByteArrayInputStream(ParameterUtils.HexToBin(paramObject.toString()));
              } 
              
              paramTDSWriter.writeStream(inputStream, -1L, true);
              inputStream.close();
            }
            catch (IOException iOException) {
              
              throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), iOException);
            }
          
          }
        
        }
        else if (null == paramObject) {
          
          writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
        } else {
          byte[] arrayOfByte;

          
          if (paramObject instanceof byte[]) {
            
            arrayOfByte = (byte[])paramObject;
          } else {

            
            try {
              
              arrayOfByte = ParameterUtils.HexToBin(paramObject.toString());
            }
            catch (SQLServerException sQLServerException) {
              
              throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), sQLServerException);
            } 
          } 
          paramTDSWriter.writeShort((short)arrayOfByte.length);
          paramTDSWriter.writeBytes(arrayOfByte);
        } 
        return;

      
      case -151:
      case -150:
      case 93:
        if (null == paramObject) {
          
          writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
        }
        else {
          
          switch (sSType) {
            
            case DATE:
              if (paramBoolean1)
                paramTDSWriter.writeByte((byte)4); 
              paramTDSWriter.writeSmalldatetime(paramObject.toString());
              return;
            case TIME:
              if (paramBoolean1)
                paramTDSWriter.writeByte((byte)8); 
              paramTDSWriter.writeDatetime(paramObject.toString());
              return;
          } 
          if (paramBoolean1)
          {
            if (2 >= paramInt2) {
              paramTDSWriter.writeByte((byte)6);
            } else if (4 >= paramInt2) {
              paramTDSWriter.writeByte((byte)7);
            } else {
              paramTDSWriter.writeByte((byte)8);
            }  } 
          String str = paramObject.toString();
          paramTDSWriter.writeTime(Timestamp.valueOf(str), paramInt2);
          
          paramTDSWriter.writeDate(str.substring(0, str.lastIndexOf(' ')));
        } 
        return;

      
      case 91:
        if (null == paramObject) {
          
          writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
        }
        else {
          
          paramTDSWriter.writeByte((byte)3);
          paramTDSWriter.writeDate(paramObject.toString());
        } 
        return;



      
      case 92:
        if (null == paramObject) {
          
          writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
        }
        else {
          
          if (2 >= paramInt2) {
            paramTDSWriter.writeByte((byte)3);
          } else if (4 >= paramInt2) {
            paramTDSWriter.writeByte((byte)4);
          } else {
            paramTDSWriter.writeByte((byte)5);
          } 
          paramTDSWriter.writeTime((Timestamp)paramObject, paramInt2);
        } 
        return;
      
      case 2013:
        if (null == paramObject) {
          
          writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
        }
        else {
          
          if (2 >= paramInt2) {
            paramTDSWriter.writeByte((byte)8);
          } else if (4 >= paramInt2) {
            paramTDSWriter.writeByte((byte)9);
          } else {
            paramTDSWriter.writeByte((byte)10);
          } 
          paramTDSWriter.writeOffsetTimeWithTimezone((OffsetTime)paramObject, paramInt2);
        } 
        return;
      
      case 2014:
        if (null == paramObject) {
          
          writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
        }
        else {
          
          if (2 >= paramInt2) {
            paramTDSWriter.writeByte((byte)8);
          } else if (4 >= paramInt2) {
            paramTDSWriter.writeByte((byte)9);
          } else {
            paramTDSWriter.writeByte((byte)10);
          } 
          paramTDSWriter.writeOffsetDateTimeWithTimezone((OffsetDateTime)paramObject, paramInt2);
        } 
        return;

      
      case -155:
        if (null == paramObject) {
          
          writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
        }
        else {
          
          if (2 >= paramInt2) {
            paramTDSWriter.writeByte((byte)8);
          } else if (4 >= paramInt2) {
            paramTDSWriter.writeByte((byte)9);
          } else {
            paramTDSWriter.writeByte((byte)10);
          } 
          paramTDSWriter.writeDateTimeOffset(paramObject, paramInt2, sSType);
        } 
        return;
    } 
    
    MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_BulkTypeNotSupported"));
    Object[] arrayOfObject = { JDBCType.of(paramInt3).toString().toLowerCase(Locale.ENGLISH) };
    SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, messageFormat.format(arrayOfObject), (String)null, true);
  }










  
  private Object readColumnFromResultSet(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) throws SQLServerException {
    CryptoMetadata cryptoMetadata = null;

    
    if (this.sourceResultSet instanceof SQLServerResultSet && null != (cryptoMetadata = ((SQLServerResultSet)this.sourceResultSet).getterGetColumn(paramInt1).getCryptoMetadata())) {

      
      paramInt2 = cryptoMetadata.baseTypeInfo.getSSType().getJDBCType().asJavaSqlType();
      BulkColumnMetaData bulkColumnMetaData = this.srcColumnMetadata.get(Integer.valueOf(paramInt1));
      this.srcColumnMetadata.put(Integer.valueOf(paramInt1), new BulkColumnMetaData(bulkColumnMetaData, cryptoMetadata));
    } 

    
    try {
      switch (paramInt2) {



        
        case -7:
        case -6:
        case -5:
        case 4:
        case 5:
        case 7:
        case 8:
          return this.sourceResultSet.getObject(paramInt1);
        
        case -148:
        case -146:
        case 2:
        case 3:
          return this.sourceResultSet.getBigDecimal(paramInt1);

        
        case -145:
        case -1:
        case 1:
        case 12:
          if (paramBoolean1 && !paramBoolean2)
          {

            
            return this.sourceResultSet.getCharacterStream(paramInt1);
          }

          
          return this.sourceResultSet.getString(paramInt1);

        
        case -16:
        case -15:
        case -9:
          if (paramBoolean1 && !paramBoolean2)
          {

            
            return this.sourceResultSet.getNCharacterStream(paramInt1);
          }


          
          return this.sourceResultSet.getObject(paramInt1);

        
        case -4:
        case -3:
        case -2:
          if (paramBoolean1 && !paramBoolean2)
          {
            return this.sourceResultSet.getBinaryStream(paramInt1);
          }

          
          return this.sourceResultSet.getBytes(paramInt1);

        
        case -151:
        case -150:
        case 93:
          return this.sourceResultSet.getTimestamp(paramInt1);
        
        case 91:
          return this.sourceResultSet.getDate(paramInt1);



        
        case 92:
          return this.sourceResultSet.getTimestamp(paramInt1);

        
        case -155:
          return ((SQLServerResultSet)this.sourceResultSet).getDateTimeOffset(paramInt1);
      } 
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_BulkTypeNotSupported"));
      Object[] arrayOfObject = { JDBCType.of(paramInt2).toString().toLowerCase(Locale.ENGLISH) };
      SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, messageFormat.format(arrayOfObject), (String)null, true);
      
      return null;
    
    }
    catch (SQLException sQLException) {
      
      throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), sQLException);
    } 
  }









  
  private final void writeColumn(TDSWriter paramTDSWriter, int paramInt1, int paramInt2, Object paramObject) throws SQLServerException {
    int i = 0, j = 0, k = 0, m = 0;
    SSType sSType = null;
    boolean bool = false;
    i = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt1))).precision;
    j = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt1))).scale;
    m = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt1))).jdbcType;
    boolean bool1 = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt1))).isNullable;
    
    k = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).precision;


    
    if (-15 == m || -9 == m || -16 == m) {


      
      bool = (4000 < i || 4000 < k) ? true : false;
    
    }
    else {
      
      bool = (8000 < i || 8000 < k) ? true : false;
    } 

    
    CryptoMetadata cryptoMetadata1 = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).cryptoMeta;
    if (null != cryptoMetadata1)
    {
      sSType = cryptoMetadata1.baseTypeInfo.getSSType();
    }


    
    if (null != this.sourceResultSet) {
      
      paramObject = readColumnFromResultSet(paramInt1, m, bool, (null != cryptoMetadata1));
      validateStringBinaryLengths(paramObject, paramInt1, paramInt2);

      
      if (!this.copyOptions.isAllowEncryptedValueModifications() && (null == cryptoMetadata1 || null == paramObject))
      {

        
        validateDataTypeConversions(paramInt1, paramInt2);
      }
    }
    else if (null != this.sourceBulkRecord && null != cryptoMetadata1) {

      
      if (91 == m || 92 == m || 93 == m || -155 == m || 2013 == m || 2014 == m) {





        
        paramObject = getTemporalObjectFromCSV(paramObject, m, paramInt1);
      }
      else if (2 == m || 3 == m) {
        
        int n = cryptoMetadata1.baseTypeInfo.getPrecision();
        int i1 = cryptoMetadata1.baseTypeInfo.getScale();
        if (j != i1 || i != n) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
          String str1 = JDBCType.of(m) + "(" + i + "," + j + ")";
          String str2 = sSType + "(" + n + "," + i1 + ")";
          Object[] arrayOfObject = { str1, str2 };
          throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
        } 
      } 
    } 
    
    CryptoMetadata cryptoMetadata2 = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt1))).cryptoMeta;
    
    if (null != cryptoMetadata1 && null != paramObject) {
      
      JDBCType jDBCType = (null != cryptoMetadata2) ? ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt1))).cryptoMeta.baseTypeInfo.getSSType().getJDBCType() : JDBCType.of(m);

      
      if (JDBCType.TIMESTAMP == jDBCType) {
        if (SSType.DATETIME == sSType) {
          
          jDBCType = JDBCType.DATETIME;
        }
        else if (SSType.SMALLDATETIME == sSType) {
          
          jDBCType = JDBCType.SMALLDATETIME;
        } 
      }
      
      if ((SSType.MONEY != sSType || JDBCType.DECIMAL != jDBCType) && (SSType.SMALLMONEY != sSType || JDBCType.DECIMAL != jDBCType) && (SSType.GUID != sSType || JDBCType.CHAR != jDBCType))
      {

        
        if ((!Util.isCharType(sSType).booleanValue() || !Util.isCharType(m).booleanValue()) && !(this.sourceResultSet instanceof SQLServerResultSet))
        {
          if (!jDBCType.normalizationCheck(sSType)) {
            
            MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedConversionAE"));
            Object[] arrayOfObject = { jDBCType, sSType };
            throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
          } 
        }
      }
      if (jDBCType == JDBCType.DATE || jDBCType == JDBCType.TIMESTAMP || jDBCType == JDBCType.TIME || jDBCType == JDBCType.DATETIMEOFFSET || jDBCType == JDBCType.DATETIME || jDBCType == JDBCType.SMALLDATETIME) {





        
        paramObject = getEncryptedTemporalBytes(paramTDSWriter, jDBCType, paramObject, paramInt1, cryptoMetadata1.baseTypeInfo.getScale());
      }
      else {
        
        TypeInfo typeInfo = cryptoMetadata1.getBaseTypeInfo();
        
        paramObject = SQLServerSecurityUtility.encryptWithKey(normalizedValue(typeInfo.getSSType().getJDBCType(), paramObject, jDBCType, typeInfo.getPrecision(), typeInfo.getScale()), cryptoMetadata1, this.connection);
      } 
    } 

    
    writeColumnToTdsWriter(paramTDSWriter, i, j, m, bool1, paramInt1, paramInt2, bool, paramObject);
  }











  
  private Object getTemporalObjectFromCSVWithFormatter(String paramString, int paramInt1, int paramInt2, DateTimeFormatter paramDateTimeFormatter) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    try {
      TemporalAccessor temporalAccessor = DateTimeFormatter.parse(paramString);

      
      int i3 = 0, i2 = i3, i1 = i2, n = i1, m = n, k = m, j = k, i = j;
      if (temporalAccessor.isSupported(ChronoField.NANO_OF_SECOND))
        i2 = temporalAccessor.get(ChronoField.NANO_OF_SECOND); 
      if (temporalAccessor.isSupported(ChronoField.OFFSET_SECONDS))
        i3 = temporalAccessor.get(ChronoField.OFFSET_SECONDS); 
      if (temporalAccessor.isSupported(ChronoField.HOUR_OF_DAY))
        i = temporalAccessor.get(ChronoField.HOUR_OF_DAY); 
      if (temporalAccessor.isSupported(ChronoField.MINUTE_OF_HOUR))
        j = temporalAccessor.get(ChronoField.MINUTE_OF_HOUR); 
      if (temporalAccessor.isSupported(ChronoField.SECOND_OF_MINUTE))
        k = temporalAccessor.get(ChronoField.SECOND_OF_MINUTE); 
      if (temporalAccessor.isSupported(ChronoField.DAY_OF_MONTH))
        i1 = temporalAccessor.get(ChronoField.DAY_OF_MONTH); 
      if (temporalAccessor.isSupported(ChronoField.MONTH_OF_YEAR))
        n = temporalAccessor.get(ChronoField.MONTH_OF_YEAR); 
      if (temporalAccessor.isSupported(ChronoField.YEAR)) {
        m = temporalAccessor.get(ChronoField.YEAR);
      }
      GregorianCalendar gregorianCalendar = null;
      gregorianCalendar = new GregorianCalendar(new SimpleTimeZone(i3 * 1000, ""));
      gregorianCalendar.clear();
      gregorianCalendar.set(11, i);
      gregorianCalendar.set(12, j);
      gregorianCalendar.set(13, k);
      gregorianCalendar.set(5, i1);
      gregorianCalendar.set(2, n - 1);
      gregorianCalendar.set(1, m);
      int i4 = Integer.toString(i2).length();
      for (byte b = 0; b < 9 - i4; b++)
        i2 *= 10; 
      Timestamp timestamp = new Timestamp(gregorianCalendar.getTimeInMillis());
      timestamp.setNanos(i2);
      
      switch (paramInt1) {
        
        case 93:
          return timestamp;
        
        case 92:
          gregorianCalendar.set(this.connection.baseYear(), 0, 1);
          timestamp = new Timestamp(gregorianCalendar.getTimeInMillis());
          timestamp.setNanos(i2);
          return new Timestamp(timestamp.getTime());
        case 91:
          return new Date(timestamp.getTime());
        case -155:
          return DateTimeOffset.valueOf(timestamp, i3 / 60);
      } 
    
    } catch (DateTimeException|ArithmeticException dateTimeException) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_ParsingError"));
      Object[] arrayOfObject = { JDBCType.of(paramInt1) };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    } 
    
    return paramString;
  }


  
  private Object getTemporalObjectFromCSV(Object paramObject, int paramInt1, int paramInt2) throws SQLServerException {
    if (2013 == paramInt1) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_UnsupportedDataTypeAE"));
      Object[] arrayOfObject = { "TIME_WITH_TIMEZONE" };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    } 
    if (2014 == paramInt1) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_UnsupportedDataTypeAE"));
      Object[] arrayOfObject = { "TIMESTAMP_WITH_TIMEZONE" };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    } 
    
    String str1 = null;
    String str2 = null;
    
    if (null != paramObject && paramObject instanceof String) {
      
      str2 = (String)paramObject;
      str1 = str2.trim();
    } 

    
    if (null == str1)
    {
      switch (paramInt1) {
        
        case 92:
        case 93:
          return null;
        case 91:
          return null;
        case -155:
          return null;
      } 

    
    }
    GregorianCalendar gregorianCalendar = null;

    
    DateTimeFormatter dateTimeFormatter = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt2))).dateTimeFormatter;
    if (null != dateTimeFormatter)
    {
      return getTemporalObjectFromCSVWithFormatter(str2, paramInt1, paramInt2, dateTimeFormatter); }  try {
      String str; int i; Timestamp timestamp1; int j; int k; int m; int n; int i1; int i2; int i3; int i4; int i5; boolean bool1;
      boolean bool2;
      int i6;
      byte b;
      Timestamp timestamp2;
      switch (paramInt1) {

        
        case 93:
          return Timestamp.valueOf(str1);

        
        case 92:
          str = this.connection.baseYear() + "-01-01 " + str1;
          return Timestamp.valueOf(str);

        
        case 91:
          return Date.valueOf(str1);
        
        case -155:
          i = str1.indexOf('-', 0);
          j = Integer.parseInt(str1.substring(0, i));
          
          k = ++i;
          i = str1.indexOf('-', k);
          m = Integer.parseInt(str1.substring(k, i));
          
          k = ++i;
          i = str1.indexOf(' ', k);
          n = Integer.parseInt(str1.substring(k, i));
          
          k = ++i;
          i = str1.indexOf(':', k);
          i1 = Integer.parseInt(str1.substring(k, i));
          
          k = ++i;
          i = str1.indexOf(':', k);
          i2 = Integer.parseInt(str1.substring(k, i));
          
          k = ++i;
          i = str1.indexOf('.', k);
          i3 = 0; i4 = 0; i5 = 0;
          bool1 = false;
          bool2 = false;
          i6 = 0;
          if (-1 != i) {
            
            i3 = Integer.parseInt(str1.substring(k, i));
            
            k = ++i;
            i = str1.indexOf(' ', k);
            if (-1 != i)
            {
              i5 = Integer.parseInt(str1.substring(k, i));
              i6 = i - k;
              bool2 = true;
            }
            else
            {
              i5 = Integer.parseInt(str1.substring(k));
              i6 = str1.length() - k;
            }
          
          } else {
            
            i = str1.indexOf(' ', k);
            if (-1 != i) {
              bool2 = true;
              i3 = Integer.parseInt(str1.substring(k, i));
            }
            else {
              
              i3 = Integer.parseInt(str1.substring(k));
              k = ++i;
            } 
          } 
          if (bool2) {
            
            k = ++i;
            if ('+' == str1.charAt(k)) {
              k++;
            } else if ('-' == str1.charAt(k)) {
              
              bool1 = true;
              k++;
            } 
            i = str1.indexOf(':', k);
            
            int i7 = Integer.parseInt(str1.substring(k, i));
            k = ++i;
            int i8 = Integer.parseInt(str1.substring(k));
            i4 = i7 * 60 + i8;
            if (bool1)
              i4 = -i4; 
          } 
          gregorianCalendar = new GregorianCalendar(new SimpleTimeZone(i4 * 60 * 1000, ""), Locale.US);
          gregorianCalendar.clear();
          gregorianCalendar.set(11, i1);
          gregorianCalendar.set(12, i2);
          gregorianCalendar.set(13, i3);
          gregorianCalendar.set(5, n);
          gregorianCalendar.set(2, m - 1);
          gregorianCalendar.set(1, j);
          for (b = 0; b < 9 - i6; b++) {
            i5 *= 10;
          }
          timestamp2 = new Timestamp(gregorianCalendar.getTimeInMillis());
          timestamp2.setNanos(i5);
          return DateTimeOffset.valueOf(timestamp2, i4);
      } 
    
    } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_ParsingError"));
      Object[] arrayOfObject = { JDBCType.of(paramInt1) };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    }
    catch (NumberFormatException numberFormatException) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_ParsingError"));
      Object[] arrayOfObject = { JDBCType.of(paramInt1) };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    }
    catch (IllegalArgumentException illegalArgumentException) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_ParsingError"));
      Object[] arrayOfObject = { JDBCType.of(paramInt1) };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    } 
    
    return paramObject;
  }



  
  private byte[] getEncryptedTemporalBytes(TDSWriter paramTDSWriter, JDBCType paramJDBCType, Object paramObject, int paramInt1, int paramInt2) throws SQLServerException {
    int i;
    DateTimeOffset dateTimeOffset;
    int j;
    long l = 0L;
    GregorianCalendar gregorianCalendar = null;
    
    switch (paramJDBCType) {
      
      case DATE:
        gregorianCalendar = new GregorianCalendar(TimeZone.getDefault(), Locale.US);
        gregorianCalendar.setLenient(true);
        gregorianCalendar.clear();
        gregorianCalendar.setTimeInMillis(((Date)paramObject).getTime());
        return paramTDSWriter.writeEncryptedScaledTemporal(gregorianCalendar, 0, 0, SSType.DATE, (short)0);





      
      case TIME:
        gregorianCalendar = new GregorianCalendar(TimeZone.getDefault(), Locale.US);
        gregorianCalendar.setLenient(true);
        gregorianCalendar.clear();
        l = ((Timestamp)paramObject).getTime();
        gregorianCalendar.setTimeInMillis(l);
        i = 0;
        if (paramObject instanceof Timestamp) {
          
          i = ((Timestamp)paramObject).getNanos();
        }
        else {
          
          i = 1000000 * (int)(l % 1000L);
          if (i < 0)
            i += 1000000000; 
        } 
        return paramTDSWriter.writeEncryptedScaledTemporal(gregorianCalendar, i, paramInt2, SSType.TIME, (short)0);





      
      case TIMESTAMP:
        gregorianCalendar = new GregorianCalendar(TimeZone.getDefault(), Locale.US);
        gregorianCalendar.setLenient(true);
        gregorianCalendar.clear();
        l = ((Timestamp)paramObject).getTime();
        gregorianCalendar.setTimeInMillis(l);
        i = ((Timestamp)paramObject).getNanos();
        return paramTDSWriter.writeEncryptedScaledTemporal(gregorianCalendar, i, paramInt2, SSType.DATETIME2, (short)0);





      
      case DATETIME:
      case SMALLDATETIME:
        gregorianCalendar = new GregorianCalendar(TimeZone.getDefault(), Locale.US);
        gregorianCalendar.setLenient(true);
        gregorianCalendar.clear();
        l = ((Timestamp)paramObject).getTime();
        gregorianCalendar.setTimeInMillis(l);
        i = ((Timestamp)paramObject).getNanos();
        return paramTDSWriter.getEncryptedDateTimeAsBytes(gregorianCalendar, i, paramJDBCType);



      
      case DATETIMEOFFSET:
        dateTimeOffset = (DateTimeOffset)paramObject;
        l = dateTimeOffset.getTimestamp().getTime();
        i = dateTimeOffset.getTimestamp().getNanos();
        j = dateTimeOffset.getMinutesOffset();
        gregorianCalendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        gregorianCalendar.setLenient(true);
        gregorianCalendar.clear();
        gregorianCalendar.setTimeInMillis(l);
        return paramTDSWriter.writeEncryptedScaledTemporal(gregorianCalendar, i, paramInt2, SSType.DATETIMEOFFSET, (short)j);
    } 






    
    MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_UnsupportedDataTypeAE"));
    
    Object[] arrayOfObject = { paramJDBCType };
    throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
  }


  
  private byte[] normalizedValue(JDBCType paramJDBCType1, Object paramObject, JDBCType paramJDBCType2, int paramInt1, int paramInt2) throws SQLServerException {
    Long long_ = null;
    byte[] arrayOfByte = null; try {
      int i, j; byte[] arrayOfByte1; Float float_; Double double_; BigDecimal bigDecimal1; byte[] arrayOfByte2; BigDecimal bigDecimal2;
      int k;
      long l;
      ByteBuffer byteBuffer;
      switch (paramJDBCType1) {
        
        case BIT:
          long_ = Long.valueOf(((Boolean)paramObject).booleanValue() ? 1L : 0L);
          return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(long_.longValue()).array();
        
        case TINYINT:
        case SMALLINT:
          switch (paramJDBCType2)
          
          { case BIT:
              long_ = new Long(((Boolean)paramObject).booleanValue() ? 1L : 0L);










              
              return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(long_.longValue()).array(); }  if (paramObject instanceof Integer) { int m = ((Integer)paramObject).intValue(); short s = (short)m; long_ = new Long(s); } else { long_ = new Long(((Short)paramObject).shortValue()); }  return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(long_.longValue()).array();
        
        case INTEGER:
          switch (paramJDBCType2)
          
          { case BIT:
              long_ = new Long(((Boolean)paramObject).booleanValue() ? 1L : 0L);







              
              return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(long_.longValue()).array();case TINYINT: case SMALLINT: long_ = new Long(((Short)paramObject).shortValue()); return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(long_.longValue()).array(); }  long_ = new Long(((Integer)paramObject).intValue()); return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(long_.longValue()).array();
        
        case BIGINT:
          switch (paramJDBCType2)
          
          { case BIT:
              long_ = new Long(((Boolean)paramObject).booleanValue() ? 1L : 0L);










              
              return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(long_.longValue()).array();case TINYINT: case SMALLINT: long_ = new Long(((Short)paramObject).shortValue()); return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(long_.longValue()).array();case INTEGER: long_ = new Long(((Integer)paramObject).intValue()); return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(long_.longValue()).array(); }  long_ = new Long(((Long)paramObject).longValue()); return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(long_.longValue()).array();
        
        case BINARY:
        case VARBINARY:
        case LONGVARBINARY:
          arrayOfByte1 = null;
          if (paramObject instanceof String) {
            
            arrayOfByte1 = ParameterUtils.HexToBin((String)paramObject);
          }
          else {
            
            arrayOfByte1 = (byte[])paramObject;
          } 
          if (arrayOfByte1.length > paramInt1) {
            
            MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
            Object[] arrayOfObject1 = { paramJDBCType2, paramJDBCType1 };
            throw new SQLServerException(this, messageFormat1.format(arrayOfObject1), null, 0, false);
          } 
          return arrayOfByte1;
        case GUID:
          return Util.asGuidByteArray(UUID.fromString((String)paramObject));


        
        case CHAR:
        case VARCHAR:
        case LONGVARCHAR:
          if (((String)paramObject).length() > paramInt1) {
            
            MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
            Object[] arrayOfObject1 = { paramJDBCType2, paramJDBCType1 };
            throw new SQLServerException(this, messageFormat1.format(arrayOfObject1), null, 0, false);
          } 
          return ((String)paramObject).getBytes(Charset.forName("UTF-8"));

        
        case NCHAR:
        case NVARCHAR:
        case LONGNVARCHAR:
          if (((String)paramObject).length() > paramInt1) {
            
            MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
            Object[] arrayOfObject1 = { paramJDBCType2, paramJDBCType1 };
            throw new SQLServerException(this, messageFormat1.format(arrayOfObject1), null, 0, false);
          } 
          return ((String)paramObject).getBytes(Charset.forName("UTF-16LE"));

        
        case REAL:
        case FLOAT:
          float_ = Float.valueOf((paramObject instanceof String) ? Float.parseFloat((String)paramObject) : ((Float)paramObject).floatValue());
          return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat(float_.floatValue()).array();
        
        case DOUBLE:
          double_ = Double.valueOf((paramObject instanceof String) ? Double.parseDouble((String)paramObject) : ((Double)paramObject).doubleValue());
          return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putDouble(double_.doubleValue()).array();
        
        case NUMERIC:
        case DECIMAL:
          j = ((BigDecimal)paramObject).scale();
          i = ((BigDecimal)paramObject).precision();
          bigDecimal1 = (BigDecimal)paramObject;
          if (i > paramInt1 || j > paramInt2) {
            
            MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
            Object[] arrayOfObject1 = { paramJDBCType2, paramJDBCType1 };
            throw new SQLServerException(this, messageFormat1.format(arrayOfObject1), null, 0, false);
          } 
          if (j < paramInt2)
          {
            bigDecimal1 = bigDecimal1.setScale(paramInt2);
          }
          arrayOfByte = DDC.convertBigDecimalToBytes(bigDecimal1, bigDecimal1.scale());
          arrayOfByte2 = new byte[16];
          
          System.arraycopy(arrayOfByte, 2, arrayOfByte2, 0, arrayOfByte.length - 2);
          return arrayOfByte2;



        
        case SMALLMONEY:
        case MONEY:
          bigDecimal2 = (BigDecimal)paramObject;
          
          Util.validateMoneyRange(bigDecimal2, paramJDBCType1);

          
          k = bigDecimal2.precision() - bigDecimal2.scale() + 4;
          
          l = ((BigDecimal)paramObject).multiply(new BigDecimal(10000), new MathContext(k, RoundingMode.HALF_UP)).longValue();
          byteBuffer = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);
          byteBuffer.putInt((int)(l >> 32L)).array();
          byteBuffer.putInt((int)l).array();
          return byteBuffer.array();
      } 
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_UnsupportedDataTypeAE"));
      Object[] arrayOfObject = { paramJDBCType1 };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);

    
    }
    catch (NumberFormatException numberFormatException) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
      Object[] arrayOfObject = { paramJDBCType2, paramJDBCType1 };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    }
    catch (IllegalArgumentException illegalArgumentException) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
      Object[] arrayOfObject = { paramJDBCType2, paramJDBCType1 };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    } 
  }

  
  private boolean goToNextRow() throws SQLServerException {
    try {
      if (null != this.sourceResultSet)
      {
        return this.sourceResultSet.next();
      }

      
      return this.sourceBulkRecord.next();
    
    }
    catch (SQLException sQLException) {
      
      throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), sQLException);
    } 
  }








  
  private final boolean writeBatchData(TDSWriter paramTDSWriter) throws SQLServerException {
    int i = this.copyOptions.getBatchSize();
    byte b = 0;


    
    while (true) {
      if (0 != i && b >= i) {
        return true;
      }
      
      if (!goToNextRow()) {
        return false;
      }
      
      paramTDSWriter.writeByte((byte)-47);
      int j = this.columnMappings.size();

      
      if (null != this.sourceResultSet) {


        
        for (byte b1 = 0; b1 < j; b1++)
        {
          writeColumn(paramTDSWriter, ((ColumnMapping)this.columnMappings.get(b1)).sourceColumnOrdinal, ((ColumnMapping)this.columnMappings.get(b1)).destinationColumnOrdinal, null);


        
        }

      
      }
      else {


        
        Object[] arrayOfObject = this.sourceBulkRecord.getRowData();
        
        for (byte b1 = 0; b1 < j; b1++)
        {

          
          writeColumn(paramTDSWriter, ((ColumnMapping)this.columnMappings.get(b1)).sourceColumnOrdinal, ((ColumnMapping)this.columnMappings.get(b1)).destinationColumnOrdinal, arrayOfObject[((ColumnMapping)this.columnMappings.get(b1)).sourceColumnOrdinal - 1]);
        }
      } 



      
      b++;
    } 
  }
}
