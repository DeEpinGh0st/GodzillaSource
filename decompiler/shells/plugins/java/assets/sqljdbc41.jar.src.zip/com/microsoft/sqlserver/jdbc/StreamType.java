package com.microsoft.sqlserver.jdbc;




































































































































































































































































































































































































enum StreamType
{
  NONE(JDBCType.UNKNOWN, "None"),
  ASCII(JDBCType.LONGVARCHAR, "AsciiStream"),
  BINARY(JDBCType.LONGVARBINARY, "BinaryStream"),
  CHARACTER(JDBCType.LONGVARCHAR, "CharacterStream"),
  NCHARACTER(JDBCType.LONGNVARCHAR, "NCharacterStream"),
  SQLXML(JDBCType.SQLXML, "SQLXML");
  private final JDBCType jdbcType;
  
  JDBCType getJDBCType() {
    return this.jdbcType;
  }

  
  private final String name;
  
  StreamType(JDBCType paramJDBCType, String paramString1) {
    this.jdbcType = paramJDBCType;
    this.name = paramString1;
  }
  public String toString() {
    return this.name;
  }

  
  boolean convertsFrom(TypeInfo paramTypeInfo) {
    if (ASCII == this) {

      
      if (SSType.XML == paramTypeInfo.getSSType()) {
        return false;
      }
      
      if (null != paramTypeInfo.getSQLCollation() && !paramTypeInfo.getSQLCollation().supportsAsciiConversion()) {
        return false;
      }
    } 
    return paramTypeInfo.getSSType().convertsTo(this.jdbcType);
  }


  
  boolean convertsTo(TypeInfo paramTypeInfo) {
    if (ASCII == this) {

      
      if (SSType.XML == paramTypeInfo.getSSType()) {
        return false;
      }
      
      if (null != paramTypeInfo.getSQLCollation() && !paramTypeInfo.getSQLCollation().supportsAsciiConversion()) {
        return false;
      }
    } 
    return this.jdbcType.convertsTo(paramTypeInfo.getSSType());
  }
}
