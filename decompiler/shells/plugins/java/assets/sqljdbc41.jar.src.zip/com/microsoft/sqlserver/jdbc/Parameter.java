package com.microsoft.sqlserver.jdbc;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.MessageFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import microsoft.sql.DateTimeOffset;




final class Parameter
{
  private TypeInfo typeInfo;
  CryptoMetadata cryptoMeta = null;
  TypeInfo getTypeInfo() { return this.typeInfo; } final CryptoMetadata getCryptoMetadata() {
    return this.cryptoMeta;
  }

  
  private boolean shouldHonorAEForParameter = false;
  private boolean userProvidesPrecision = false;
  private boolean userProvidesScale = false;
  private String typeDefinition = null;
  
  boolean renewDefinition = false;
  
  private JDBCType jdbcTypeSetByUser = null;

  
  private int valueLength = 0;
  private boolean forceEncryption = false;
  int scale;
  private int outScale;
  private String name;
  private DTV getterDTV;
  private DTV registeredOutDTV;
  private DTV setterDTV;
  private DTV inputDTV;
  
  boolean isOutput() {
    return (null != this.registeredOutDTV);
  }



  
  JDBCType getJdbcType() throws SQLServerException {
    return (null != this.inputDTV) ? this.inputDTV.getJdbcType() : JDBCType.UNKNOWN;
  }





  
  private static JDBCType getSSPAUJDBCType(JDBCType paramJDBCType) {
    switch (paramJDBCType) {
      case CHAR:
        return JDBCType.NCHAR;
      case VARCHAR: return JDBCType.NVARCHAR;
      case LONGVARCHAR: return JDBCType.LONGNVARCHAR;
      case CLOB: return JDBCType.NCLOB;
    }  return paramJDBCType;
  }






  
  void registerForOutput(JDBCType paramJDBCType, SQLServerConnection paramSQLServerConnection) throws SQLServerException {
    if (JDBCType.DATETIMEOFFSET == paramJDBCType && !paramSQLServerConnection.isKatmaiOrLater())
    {
      throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
    }








    
    if (paramSQLServerConnection.sendStringParametersAsUnicode()) {

      
      if (this.shouldHonorAEForParameter)
      {
        setJdbcTypeSetByUser(paramJDBCType);
      }
      
      paramJDBCType = getSSPAUJDBCType(paramJDBCType);
    } 
    
    this.registeredOutDTV = new DTV();
    this.registeredOutDTV.setJdbcType(paramJDBCType);
    
    if (null == this.setterDTV) {
      this.inputDTV = this.registeredOutDTV;
    }
    resetOutputValue();
  }
  Parameter(boolean paramBoolean) {
    this.scale = 0;



    
    this.outScale = 4;








































    
    this.registeredOutDTV = null;
    this.setterDTV = null;
    this.inputDTV = null;
    this.shouldHonorAEForParameter = paramBoolean;
  }
  
  int getOutScale() {
    return this.outScale;
  }
  
  void setOutScale(int paramInt) {
    this.outScale = paramInt;
    this.userProvidesScale = true;
  }
  
  final Parameter cloneForBatch() {
    Parameter parameter = new Parameter(this.shouldHonorAEForParameter);
    parameter.typeInfo = this.typeInfo;
    parameter.typeDefinition = this.typeDefinition;
    parameter.outScale = this.outScale;
    parameter.name = this.name;
    parameter.getterDTV = this.getterDTV;
    parameter.registeredOutDTV = this.registeredOutDTV;
    parameter.setterDTV = this.setterDTV;
    parameter.inputDTV = this.inputDTV;
    parameter.cryptoMeta = this.cryptoMeta;
    parameter.jdbcTypeSetByUser = this.jdbcTypeSetByUser;
    parameter.valueLength = this.valueLength;
    parameter.userProvidesPrecision = this.userProvidesPrecision;
    parameter.userProvidesScale = this.userProvidesScale;
    return parameter;
  }




  
  final void skipValue(TDSReader paramTDSReader, boolean paramBoolean) throws SQLServerException {
    if (null == this.getterDTV) {
      this.getterDTV = new DTV();
    }
    deriveTypeInfo(paramTDSReader);
    
    this.getterDTV.skipValue(this.typeInfo, paramTDSReader, paramBoolean);
  }





  
  final void skipRetValStatus(TDSReader paramTDSReader) throws SQLServerException {
    StreamRetValue streamRetValue = new StreamRetValue();
    streamRetValue.setFromTDS(paramTDSReader);
  }


  
  void clearInputValue() {
    this.setterDTV = null;
    this.inputDTV = this.registeredOutDTV;
  }



  
  void resetOutputValue() {
    this.getterDTV = null;
    this.typeInfo = null;
  }

  
  void deriveTypeInfo(TDSReader paramTDSReader) throws SQLServerException {
    if (null == this.typeInfo) {
      
      this.typeInfo = TypeInfo.getInstance(paramTDSReader, true);
      
      if (this.shouldHonorAEForParameter && this.typeInfo.isEncrypted()) {


        
        CekTableEntry cekTableEntry = this.cryptoMeta.getCekTableEntry();
        this.cryptoMeta = (new StreamRetValue()).getCryptoMetadata(paramTDSReader);
        this.cryptoMeta.setCekTableEntry(cekTableEntry);
      } 
    } 
  }

  
  void setFromReturnStatus(int paramInt, SQLServerConnection paramSQLServerConnection) throws SQLServerException {
    if (null == this.getterDTV) {
      this.getterDTV = new DTV();
    }
    this.getterDTV.setValue(null, JDBCType.INTEGER, new Integer(paramInt), JavaType.INTEGER, null, null, null, paramSQLServerConnection, getForceEncryption());
  }














  
  void setValue(JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, StreamSetterArgs paramStreamSetterArgs, Calendar paramCalendar, Integer paramInteger1, Integer paramInteger2, SQLServerConnection paramSQLServerConnection, boolean paramBoolean, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting, int paramInt, String paramString1, String paramString2) throws SQLServerException {
    if (this.shouldHonorAEForParameter) {
      
      this.userProvidesPrecision = false;
      this.userProvidesScale = false;
      
      if (null != paramInteger1) {
        this.userProvidesPrecision = true;
      }
      
      if (null != paramInteger2) {
        this.userProvidesScale = true;
      }




      
      if (!isOutput() && 
        JavaType.SHORT == paramJavaType && (JDBCType.TINYINT == paramJDBCType || JDBCType.SMALLINT == paramJDBCType))
      {
        
        if (((Short)paramObject).shortValue() >= 0 && ((Short)paramObject).shortValue() <= 255) {
          paramObject = Byte.valueOf(((Short)paramObject).byteValue());
          paramJavaType = JavaType.of(paramObject);
          paramJDBCType = paramJavaType.getJDBCType(SSType.UNKNOWN, paramJDBCType);



        
        }
        else if (JDBCType.TINYINT == paramJDBCType) {

          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
          Object[] arrayOfObject = { paramJavaType.toString().toLowerCase(Locale.ENGLISH), paramJDBCType.toString().toLowerCase(Locale.ENGLISH) };
          throw new SQLServerException(messageFormat.format(arrayOfObject), null);
        } 
      }
    } 



    
    if (true == paramBoolean && false == Util.shouldHonorAEForParameters(paramSQLServerStatementColumnEncryptionSetting, paramSQLServerConnection)) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_ForceEncryptionTrue_HonorAEFalse"));
      Object[] arrayOfObject = { Integer.valueOf(paramInt), paramString1 };
      SQLServerException.makeFromDriverError(paramSQLServerConnection, this, messageFormat.format(arrayOfObject), null, true);
    } 


    
    if ((JDBCType.DATETIMEOFFSET == paramJDBCType || JavaType.DATETIMEOFFSET == paramJavaType) && !paramSQLServerConnection.isKatmaiOrLater())
    {
      
      throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
    }




    
    if (JavaType.TVP == paramJavaType) {
      
      TVP tVP = null;
      if (null == paramObject) {
        
        tVP = new TVP(paramString2);
      }
      else if (paramObject instanceof SQLServerDataTable) {
        
        tVP = new TVP(paramString2, (SQLServerDataTable)paramObject);
      }
      else if (paramObject instanceof ResultSet) {


        
        if (paramSQLServerConnection.getSelectMethod().equalsIgnoreCase("cursor") && paramObject instanceof SQLServerResultSet) {
          
          SQLServerStatement sQLServerStatement = (SQLServerStatement)((SQLServerResultSet)paramObject).getStatement();
          
          if (paramSQLServerConnection.equals(sQLServerStatement.connection)) {
            
            if (Locale.getDefault().getLanguage() == Locale.ENGLISH.getLanguage())
            {
              throw new SQLServerException(SQLServerException.getErrString("R_invalidServerCursorForTVP"), null);
            }


            
            throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), null, 0, null);
          } 
        } 
        
        tVP = new TVP(paramString2, (ResultSet)paramObject);
      }
      else if (paramObject instanceof ISQLServerDataRecord) {
        
        tVP = new TVP(paramString2, (ISQLServerDataRecord)paramObject);
      }
      else {
        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_TVPInvalidValue"));
        Object[] arrayOfObject = { Integer.valueOf(paramInt) };
        throw new SQLServerException(messageFormat.format(arrayOfObject), null);
      } 

      
      if (!tVP.isNull() && 0 == tVP.getTVPColumnCount())
      {
        throw new SQLServerException(SQLServerException.getErrString("R_TVPEmptyMetadata"), null);
      }

      
      this.name = tVP.getTVPName();
      
      paramObject = tVP;
    } 

    
    if (this.shouldHonorAEForParameter) {
      
      setForceEncryption(paramBoolean);

      
      if (!isOutput() || this.jdbcTypeSetByUser == null) {
        setJdbcTypeSetByUser(paramJDBCType);
      }

      
      if ((!paramJDBCType.isTextual() && !paramJDBCType.isBinary()) || !isOutput() || this.valueLength == 0) {
        this.valueLength = Util.getValueLengthBaseOnJavaType(paramObject, paramJavaType, paramInteger1, paramInteger2, paramJDBCType);
      }
      
      if (null != paramInteger2) {
        this.outScale = paramInteger2.intValue();
      }
    } 




    
    if (paramSQLServerConnection.sendStringParametersAsUnicode() && (JavaType.STRING == paramJavaType || JavaType.READER == paramJavaType || JavaType.CLOB == paramJavaType))
    {


      
      paramJDBCType = getSSPAUJDBCType(paramJDBCType);
    }
    
    DTV dTV = new DTV();
    dTV.setValue(paramSQLServerConnection.getDatabaseCollation(), paramJDBCType, paramObject, paramJavaType, paramStreamSetterArgs, paramCalendar, paramInteger2, paramSQLServerConnection, paramBoolean);
    this.inputDTV = this.setterDTV = dTV;
  }

  
  boolean isNull() {
    if (null != this.getterDTV) {
      return this.getterDTV.isNull();
    }
    return false;
  }

  
  boolean isValueGotten() {
    return (null != this.getterDTV);
  }


  
  Object getValue(JDBCType paramJDBCType, InputStreamGetterArgs paramInputStreamGetterArgs, Calendar paramCalendar, TDSReader paramTDSReader) throws SQLServerException {
    if (null == this.getterDTV) {
      this.getterDTV = new DTV();
    }
    deriveTypeInfo(paramTDSReader);

    
    return this.getterDTV.getValue(paramJDBCType, this.outScale, paramInputStreamGetterArgs, paramCalendar, this.typeInfo, this.cryptoMeta, paramTDSReader);
  }

  
  int getInt(TDSReader paramTDSReader) throws SQLServerException {
    Integer integer = (Integer)getValue(JDBCType.INTEGER, null, null, paramTDSReader);
    return (null != integer) ? integer.intValue() : 0;
  }

  
  final class GetTypeDefinitionOp
    extends DTVExecuteOp
  {
    private static final String NVARCHAR_MAX = "nvarchar(max)";
    
    private static final String NVARCHAR_4K = "nvarchar(4000)";
    
    private static final String NTEXT = "ntext";
    
    private static final String VARCHAR_MAX = "varchar(max)";
    
    private static final String VARCHAR_8K = "varchar(8000)";
    
    private static final String TEXT = "text";
    
    private static final String VARBINARY_MAX = "varbinary(max)";
    
    private static final String VARBINARY_8K = "varbinary(8000)";
    private static final String IMAGE = "image";
    private final Parameter param;
    private final SQLServerConnection con;
    
    GetTypeDefinitionOp(Parameter param1Parameter1, SQLServerConnection param1SQLServerConnection) {
      this.param = param1Parameter1;
      this.con = param1SQLServerConnection;
    }
    
    private void setTypeDefinition(DTV param1DTV) {
      Integer integer;
      switch (param1DTV.getJdbcType()) {
        
        case TINYINT:
          this.param.typeDefinition = SSType.TINYINT.toString();
          return;
        
        case SMALLINT:
          this.param.typeDefinition = SSType.SMALLINT.toString();
          return;
        
        case INTEGER:
          this.param.typeDefinition = SSType.INTEGER.toString();
          return;
        
        case BIGINT:
          this.param.typeDefinition = SSType.BIGINT.toString();
          return;

        
        case REAL:
          if (this.param.shouldHonorAEForParameter && null != Parameter.this.jdbcTypeSetByUser && (null != this.param.getCryptoMetadata() || !this.param.renewDefinition)) {








            
            this.param.typeDefinition = SSType.REAL.toString();
            return;
          } 
        case FLOAT:
        case DOUBLE:
          this.param.typeDefinition = SSType.FLOAT.toString();
          return;

        
        case DECIMAL:
        case NUMERIC:
          if (Parameter.this.scale > 38) {
            Parameter.this.scale = 38;
          }



          
          integer = param1DTV.getScale();
          if (null != integer && Parameter.this.scale < integer.intValue()) {
            Parameter.this.scale = integer.intValue();
          }
          if (this.param.isOutput() && Parameter.this.scale < this.param.getOutScale()) {
            Parameter.this.scale = this.param.getOutScale();
          }
          if (this.param.shouldHonorAEForParameter && null != Parameter.this.jdbcTypeSetByUser && (null != this.param.getCryptoMetadata() || !this.param.renewDefinition)) {








            
            if (0 == Parameter.this.valueLength) {





              
              if (!Parameter.this.isOutput()) {
                this.param.typeDefinition = "decimal(18, " + Parameter.this.scale + ")";
              
              }
            }
            else if (18 >= Parameter.this.valueLength) {
              this.param.typeDefinition = "decimal(18," + Parameter.this.scale + ")";
              
              if (18 < Parameter.this.valueLength + Parameter.this.scale) {
                this.param.typeDefinition = "decimal(" + (18 + Parameter.this.scale) + "," + Parameter.this.scale + ")";
              }
            } else {
              
              this.param.typeDefinition = "decimal(38," + Parameter.this.scale + ")";
            } 

            
            if (Parameter.this.isOutput()) {
              this.param.typeDefinition = "decimal(38, " + Parameter.this.scale + ")";
            }
            
            if (Parameter.this.userProvidesPrecision) {
              this.param.typeDefinition = "decimal(" + Parameter.this.valueLength + "," + Parameter.this.scale + ")";
            }
          } else {
            
            this.param.typeDefinition = "decimal(38," + Parameter.this.scale + ")";
          } 
          return;
        
        case MONEY:
          this.param.typeDefinition = SSType.MONEY.toString();
          return;
        case SMALLMONEY:
          this.param.typeDefinition = SSType.SMALLMONEY.toString();
          return;
        case BIT:
        case BOOLEAN:
          this.param.typeDefinition = SSType.BIT.toString();
          return;
        
        case LONGVARBINARY:
        case BLOB:
          this.param.typeDefinition = "varbinary(max)";
          return;

        
        case BINARY:
        case VARBINARY:
          if ("varbinary(max)" != this.param.typeDefinition && "image" != this.param.typeDefinition)
          {
            if (this.param.shouldHonorAEForParameter && null != Parameter.this.jdbcTypeSetByUser && (null != this.param.getCryptoMetadata() || !this.param.renewDefinition)) {








              
              if (0 == Parameter.this.valueLength) {
                this.param.typeDefinition = "varbinary";
              } else {
                
                this.param.typeDefinition = "varbinary(" + Parameter.this.valueLength + ")";
              } 
              
              if (JDBCType.LONGVARBINARY == Parameter.this.jdbcTypeSetByUser) {
                this.param.typeDefinition = "varbinary(max)";
              }
            } else {
              
              this.param.typeDefinition = "varbinary(8000)";
            } 
          }
          return;
        case DATE:
          this.param.typeDefinition = this.con.isKatmaiOrLater() ? SSType.DATE.toString() : SSType.DATETIME.toString();
          return;
        
        case TIME:
          if (this.param.shouldHonorAEForParameter && (null != this.param.getCryptoMetadata() || !this.param.renewDefinition)) {









            
            if (Parameter.this.userProvidesScale) {
              this.param.typeDefinition = SSType.TIME.toString() + "(" + Parameter.this.outScale + ")";
            } else {
              
              this.param.typeDefinition = this.param.typeDefinition = SSType.TIME.toString() + "(" + Parameter.this.valueLength + ")";
            }
          
          } else {
            
            this.param.typeDefinition = this.con.getSendTimeAsDatetime() ? SSType.DATETIME.toString() : SSType.TIME.toString();
          } 
          return;





        
        case TIMESTAMP:
          if (this.param.shouldHonorAEForParameter && (null != this.param.getCryptoMetadata() || !this.param.renewDefinition)) {







            
            if (Parameter.this.userProvidesScale) {
              this.param.typeDefinition = this.con.isKatmaiOrLater() ? (SSType.DATETIME2.toString() + "(" + Parameter.this.outScale + ")") : SSType.DATETIME.toString();
            }
            else {
              
              this.param.typeDefinition = this.con.isKatmaiOrLater() ? (SSType.DATETIME2.toString() + "(" + Parameter.this.valueLength + ")") : SSType.DATETIME.toString();
            }
          
          } else {
            
            this.param.typeDefinition = this.con.isKatmaiOrLater() ? SSType.DATETIME2.toString() : SSType.DATETIME.toString();
          } 
          return;


        
        case DATETIME:
          this.param.typeDefinition = SSType.DATETIME.toString();
          
          if (!this.param.shouldHonorAEForParameter) {

            
            if (this.param.isOutput()) {
              this.param.typeDefinition = SSType.DATETIME2.toString() + "(" + Parameter.this.outScale + ")";

            
            }

          
          }
          else if (null == this.param.getCryptoMetadata() && this.param.renewDefinition && 
            this.param.isOutput()) {
            this.param.typeDefinition = SSType.DATETIME2.toString() + "(" + Parameter.this.outScale + ")";
          } 
          return;



        
        case SMALLDATETIME:
          this.param.typeDefinition = SSType.SMALLDATETIME.toString();
          return;
        
        case TIME_WITH_TIMEZONE:
        case TIMESTAMP_WITH_TIMEZONE:
        case DATETIMEOFFSET:
          if (this.param.shouldHonorAEForParameter && (null != this.param.getCryptoMetadata() || !this.param.renewDefinition)) {







            
            if (Parameter.this.userProvidesScale) {
              this.param.typeDefinition = SSType.DATETIMEOFFSET.toString() + "(" + Parameter.this.outScale + ")";
            } else {
              
              this.param.typeDefinition = SSType.DATETIMEOFFSET.toString() + "(" + Parameter.this.valueLength + ")";
            } 
          } else {
            
            this.param.typeDefinition = SSType.DATETIMEOFFSET.toString();
          } 
          return;
        
        case LONGVARCHAR:
        case CLOB:
          this.param.typeDefinition = "varchar(max)";
          return;

        
        case CHAR:
        case VARCHAR:
          if ("varchar(max)" != this.param.typeDefinition && "text" != this.param.typeDefinition)
          {

            
            if (this.param.shouldHonorAEForParameter && null != Parameter.this.jdbcTypeSetByUser && (null != this.param.getCryptoMetadata() || !this.param.renewDefinition)) {








              
              if (0 == Parameter.this.valueLength) {
                this.param.typeDefinition = "varchar";
              } else {
                
                this.param.typeDefinition = "varchar(" + Parameter.this.valueLength + ")";
                
                if (8000 <= Parameter.this.valueLength) {
                  this.param.typeDefinition = "varchar(max)";
                }
              } 
            } else {
              
              this.param.typeDefinition = "varchar(8000)";
            }  } 
          return;
        case LONGNVARCHAR:
          if (this.param.shouldHonorAEForParameter && (null != this.param.getCryptoMetadata() || !this.param.renewDefinition)) {







            
            if (null != Parameter.this.jdbcTypeSetByUser && (Parameter.this.jdbcTypeSetByUser == JDBCType.VARCHAR || Parameter.this.jdbcTypeSetByUser == JDBCType.CHAR || Parameter.this.jdbcTypeSetByUser == JDBCType.LONGVARCHAR)) {
              
              if (0 == Parameter.this.valueLength) {
                this.param.typeDefinition = "varchar";
              }
              else if (8000 < Parameter.this.valueLength) {
                this.param.typeDefinition = "varchar(max)";
              } else {
                
                this.param.typeDefinition = "varchar(" + Parameter.this.valueLength + ")";
              } 
              
              if (Parameter.this.jdbcTypeSetByUser == JDBCType.LONGVARCHAR) {
                this.param.typeDefinition = "varchar(max)";
              }
            }
            else if (null != Parameter.this.jdbcTypeSetByUser && (Parameter.this.jdbcTypeSetByUser == JDBCType.NVARCHAR || Parameter.this.jdbcTypeSetByUser == JDBCType.LONGNVARCHAR)) {
              
              if (0 == Parameter.this.valueLength) {
                this.param.typeDefinition = "nvarchar";
              }
              else if (4000 < Parameter.this.valueLength) {
                this.param.typeDefinition = "nvarchar(max)";
              } else {
                
                this.param.typeDefinition = "nvarchar(" + Parameter.this.valueLength + ")";
              } 
              
              if (Parameter.this.jdbcTypeSetByUser == JDBCType.LONGNVARCHAR) {
                this.param.typeDefinition = "nvarchar(max)";
              
              }
            }
            else if (0 == Parameter.this.valueLength) {
              this.param.typeDefinition = "nvarchar";
            } else {
              
              this.param.typeDefinition = "nvarchar(" + Parameter.this.valueLength + ")";
              
              if (8000 <= Parameter.this.valueLength) {
                this.param.typeDefinition = "nvarchar(max)";
              }
            }
          
          }
          else {
            
            this.param.typeDefinition = "nvarchar(max)";
          } 
          return;

        
        case NCLOB:
          this.param.typeDefinition = "nvarchar(max)";
          return;

        
        case NCHAR:
        case NVARCHAR:
          if ("nvarchar(max)" != this.param.typeDefinition && "ntext" != this.param.typeDefinition)
          {
            
            if (this.param.shouldHonorAEForParameter && (null != this.param.getCryptoMetadata() || !this.param.renewDefinition)) {







              
              if (null != Parameter.this.jdbcTypeSetByUser && (Parameter.this.jdbcTypeSetByUser == JDBCType.VARCHAR || Parameter.this.jdbcTypeSetByUser == JDBCType.CHAR || JDBCType.LONGVARCHAR == Parameter.this.jdbcTypeSetByUser)) {

                
                if (0 == Parameter.this.valueLength) {
                  this.param.typeDefinition = "varchar";
                } else {
                  
                  this.param.typeDefinition = "varchar(" + Parameter.this.valueLength + ")";
                  
                  if (8000 <= Parameter.this.valueLength) {
                    this.param.typeDefinition = "varchar(max)";
                  }
                } 
                
                if (JDBCType.LONGVARCHAR == Parameter.this.jdbcTypeSetByUser) {
                  this.param.typeDefinition = "varchar(max)";
                }
              }
              else if (null != Parameter.this.jdbcTypeSetByUser && (Parameter.this.jdbcTypeSetByUser == JDBCType.NVARCHAR || Parameter.this.jdbcTypeSetByUser == JDBCType.NCHAR || JDBCType.LONGNVARCHAR == Parameter.this.jdbcTypeSetByUser)) {

                
                if (0 == Parameter.this.valueLength) {
                  this.param.typeDefinition = "nvarchar";
                } else {
                  
                  this.param.typeDefinition = "nvarchar(" + Parameter.this.valueLength + ")";
                  
                  if (8000 <= Parameter.this.valueLength) {
                    this.param.typeDefinition = "nvarchar(max)";
                  }
                } 
                
                if (JDBCType.LONGNVARCHAR == Parameter.this.jdbcTypeSetByUser) {
                  this.param.typeDefinition = "nvarchar(max)";
                
                }
              }
              else if (0 == Parameter.this.valueLength) {
                this.param.typeDefinition = "nvarchar";
              } else {
                
                this.param.typeDefinition = "nvarchar(" + Parameter.this.valueLength + ")";
                
                if (8000 <= Parameter.this.valueLength) {
                  this.param.typeDefinition = "nvarchar(max)";
                }
              }
            
            }
            else {
              
              this.param.typeDefinition = "nvarchar(4000)";
            }  }  return;
        case SQLXML:
          this.param.typeDefinition = SSType.XML.toString();
          return;

        
        case TVP:
          this.param.typeDefinition = "[" + this.param.name + "] READONLY";
          return;

        
        case GUID:
          this.param.typeDefinition = SSType.GUID.toString();
          return;
      } 
      
      assert false : "Unexpected JDBC type " + param1DTV.getJdbcType();
    }



    
    void execute(DTV param1DTV, String param1String) throws SQLServerException {
      if (null != param1String && param1String.length() > 4000) {
        param1DTV.setJdbcType(JDBCType.LONGNVARCHAR);
      }
      setTypeDefinition(param1DTV);
    }

    
    void execute(DTV param1DTV, Clob param1Clob) throws SQLServerException {
      setTypeDefinition(param1DTV);
    }

    
    void execute(DTV param1DTV, Byte param1Byte) throws SQLServerException {
      setTypeDefinition(param1DTV);
    }

    
    void execute(DTV param1DTV, Integer param1Integer) throws SQLServerException {
      setTypeDefinition(param1DTV);
    }

    
    void execute(DTV param1DTV, Time param1Time) throws SQLServerException {
      setTypeDefinition(param1DTV);
    }

    
    void execute(DTV param1DTV, Date param1Date) throws SQLServerException {
      setTypeDefinition(param1DTV);
    }

    
    void execute(DTV param1DTV, Timestamp param1Timestamp) throws SQLServerException {
      setTypeDefinition(param1DTV);
    }

    
    void execute(DTV param1DTV, Date param1Date) throws SQLServerException {
      setTypeDefinition(param1DTV);
    }

    
    void execute(DTV param1DTV, Calendar param1Calendar) throws SQLServerException {
      setTypeDefinition(param1DTV);
    }

    
    void execute(DTV param1DTV, LocalDate param1LocalDate) throws SQLServerException {
      setTypeDefinition(param1DTV);
    }

    
    void execute(DTV param1DTV, LocalTime param1LocalTime) throws SQLServerException {
      setTypeDefinition(param1DTV);
    }

    
    void execute(DTV param1DTV, LocalDateTime param1LocalDateTime) throws SQLServerException {
      setTypeDefinition(param1DTV);
    }

    
    void execute(DTV param1DTV, OffsetTime param1OffsetTime) throws SQLServerException {
      setTypeDefinition(param1DTV);
    }

    
    void execute(DTV param1DTV, OffsetDateTime param1OffsetDateTime) throws SQLServerException {
      setTypeDefinition(param1DTV);
    }

    
    void execute(DTV param1DTV, DateTimeOffset param1DateTimeOffset) throws SQLServerException {
      setTypeDefinition(param1DTV);
    }

    
    void execute(DTV param1DTV, Float param1Float) throws SQLServerException {
      Parameter.this.scale = 4;
      setTypeDefinition(param1DTV);
    }

    
    void execute(DTV param1DTV, Double param1Double) throws SQLServerException {
      Parameter.this.scale = 4;
      setTypeDefinition(param1DTV);
    }

    
    void execute(DTV param1DTV, BigDecimal param1BigDecimal) throws SQLServerException {
      if (null != param1BigDecimal) {
        
        Parameter.this.scale = param1BigDecimal.scale();





        
        if (Parameter.this.scale < 0) {
          Parameter.this.scale = 0;
        }
      } 
      setTypeDefinition(param1DTV);
    }

    
    void execute(DTV param1DTV, Long param1Long) throws SQLServerException {
      setTypeDefinition(param1DTV);
    }

    
    void execute(DTV param1DTV, BigInteger param1BigInteger) throws SQLServerException {
      setTypeDefinition(param1DTV);
    }

    
    void execute(DTV param1DTV, Short param1Short) throws SQLServerException {
      setTypeDefinition(param1DTV);
    }

    
    void execute(DTV param1DTV, Boolean param1Boolean) throws SQLServerException {
      setTypeDefinition(param1DTV);
    }

    
    void execute(DTV param1DTV, byte[] param1ArrayOfbyte) throws SQLServerException {
      if (null != param1ArrayOfbyte && param1ArrayOfbyte.length > 8000) {
        param1DTV.setJdbcType(param1DTV.getJdbcType().isBinary() ? JDBCType.LONGVARBINARY : JDBCType.LONGVARCHAR);
      }
      setTypeDefinition(param1DTV);
    }

    
    void execute(DTV param1DTV, Blob param1Blob) throws SQLServerException {
      setTypeDefinition(param1DTV);
    }

    
    void execute(DTV param1DTV, InputStream param1InputStream) throws SQLServerException {
      StreamSetterArgs streamSetterArgs = param1DTV.getStreamSetterArgs();
      
      JDBCType jDBCType = param1DTV.getJdbcType();

      
      if (JDBCType.CHAR == jDBCType || JDBCType.VARCHAR == jDBCType || JDBCType.BINARY == jDBCType || JDBCType.VARBINARY == jDBCType)
      {



        
        if (streamSetterArgs.getLength() > 8000L) {
          param1DTV.setJdbcType(jDBCType.isBinary() ? JDBCType.LONGVARBINARY : JDBCType.LONGVARCHAR);

        
        }
        else if (-1L == streamSetterArgs.getLength()) {
          
          byte[] arrayOfByte = new byte[8001];
          BufferedInputStream bufferedInputStream = new BufferedInputStream(param1InputStream, arrayOfByte.length);
          
          int i = 0;

          
          try {
            bufferedInputStream.mark(arrayOfByte.length);
            
            i = bufferedInputStream.read(arrayOfByte, 0, arrayOfByte.length);
            
            if (-1 == i) {
              i = 0;
            }
            bufferedInputStream.reset();
          }
          catch (IOException iOException) {
            
            MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
            Object[] arrayOfObject = { iOException.toString() };
            SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), "", true);
          } 
          
          param1DTV.setValue(bufferedInputStream, JavaType.INPUTSTREAM);




          
          if (i > 8000) {
            param1DTV.setJdbcType(jDBCType.isBinary() ? JDBCType.LONGVARBINARY : JDBCType.LONGVARCHAR);
          } else {
            streamSetterArgs.setLength(i);
          } 
        } 
      }
      setTypeDefinition(param1DTV);
    }


    
    void execute(DTV param1DTV, Reader param1Reader) throws SQLServerException {
      if (JDBCType.NCHAR == param1DTV.getJdbcType() || JDBCType.NVARCHAR == param1DTV.getJdbcType()) {
        
        StreamSetterArgs streamSetterArgs = param1DTV.getStreamSetterArgs();

        
        if (streamSetterArgs.getLength() > 4000L) {
          param1DTV.setJdbcType(JDBCType.LONGNVARCHAR);

        
        }
        else if (-1L == streamSetterArgs.getLength()) {
          
          char[] arrayOfChar = new char[4001];
          BufferedReader bufferedReader = new BufferedReader(param1Reader, arrayOfChar.length);
          
          int i = 0;

          
          try {
            bufferedReader.mark(arrayOfChar.length);
            
            i = bufferedReader.read(arrayOfChar, 0, arrayOfChar.length);
            
            if (-1 == i) {
              i = 0;
            }
            bufferedReader.reset();
          }
          catch (IOException iOException) {
            
            MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
            Object[] arrayOfObject = { iOException.toString() };
            SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), "", true);
          } 
          
          param1DTV.setValue(bufferedReader, JavaType.READER);
          
          if (i > 4000) {
            param1DTV.setJdbcType(JDBCType.LONGNVARCHAR);
          } else {
            streamSetterArgs.setLength(i);
          } 
        } 
      } 
      setTypeDefinition(param1DTV);
    }
    
    void execute(DTV param1DTV, SQLServerSQLXML param1SQLServerSQLXML) throws SQLServerException {
      setTypeDefinition(param1DTV);
    }

    
    void execute(DTV param1DTV, TVP param1TVP) throws SQLServerException {
      setTypeDefinition(param1DTV);
    }
  }






  
  String getTypeDefinition(SQLServerConnection paramSQLServerConnection, TDSReader paramTDSReader) throws SQLServerException {
    if (null == this.inputDTV) {
      return null;
    }
    this.inputDTV.executeOp(new GetTypeDefinitionOp(this, paramSQLServerConnection));
    return this.typeDefinition;
  }



  
  void sendByRPC(TDSWriter paramTDSWriter, SQLServerConnection paramSQLServerConnection) throws SQLServerException {
    assert null != this.inputDTV : "Parameter was neither set nor registered";

    
    try {
      this.inputDTV.sendCryptoMetaData(this.cryptoMeta, paramTDSWriter);
      this.inputDTV.jdbcTypeSetByUser(getJdbcTypeSetByUser(), getValueLength());
      this.inputDTV.sendByRPC(this.name, null, paramSQLServerConnection.getDatabaseCollation(), this.valueLength, isOutput() ? this.outScale : this.scale, isOutput(), paramTDSWriter, paramSQLServerConnection);




    
    }
    finally {




      
      this.inputDTV.sendCryptoMetaData(null, paramTDSWriter);
    } 








    
    if (JavaType.INPUTSTREAM == this.inputDTV.getJavaType() || JavaType.READER == this.inputDTV.getJavaType())
    {
      
      this.inputDTV = this.setterDTV = null; } 
  }
  
  JDBCType getJdbcTypeSetByUser() {
    return this.jdbcTypeSetByUser;
  }
  void setJdbcTypeSetByUser(JDBCType paramJDBCType) {
    this.jdbcTypeSetByUser = paramJDBCType;
  }
  int getValueLength() {
    return this.valueLength;
  }
  void setValueLength(int paramInt) {
    this.valueLength = paramInt;
    this.userProvidesPrecision = true;
  }
  boolean getForceEncryption() {
    return this.forceEncryption;
  }
  void setForceEncryption(boolean paramBoolean) {
    this.forceEncryption = paramBoolean;
  }
}
