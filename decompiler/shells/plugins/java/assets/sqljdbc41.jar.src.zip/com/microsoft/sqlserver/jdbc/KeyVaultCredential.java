package com.microsoft.sqlserver.jdbc;

import com.microsoft.azure.keyvault.authentication.KeyVaultCredentials;
import com.microsoft.windowsazure.core.pipeline.filter.ServiceRequestContext;
import java.util.Map;
import org.apache.http.Header;
import org.apache.http.message.BasicHeader;


class KeyVaultCredential
  extends KeyVaultCredentials
{
  private final String accessTokenType = "Bearer";
  
  SQLServerKeyVaultAuthenticationCallback authenticationCallback = null;
  String clientId = null;
  String clientKey = null;
  String accessToken = null;
  
  KeyVaultCredential(SQLServerKeyVaultAuthenticationCallback paramSQLServerKeyVaultAuthenticationCallback) {
    this.authenticationCallback = paramSQLServerKeyVaultAuthenticationCallback;
  }

  
  public Header doAuthenticate(ServiceRequestContext paramServiceRequestContext, Map<String, String> paramMap) {
    assert null != paramMap;
    
    String str1 = paramMap.get("authorization");
    String str2 = paramMap.get("resource");
    
    this.accessToken = this.authenticationCallback.getAccessToken(str1, str2, "");
    return (Header)new BasicHeader("Authorization", "Bearer " + this.accessToken);
  }
  
  void setAccessToken(String paramString) {
    this.accessToken = paramString;
  }
}
