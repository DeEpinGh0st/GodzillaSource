package com.microsoft.sqlserver.jdbc;








final class StreamSSPI
  extends StreamPacket
{
  byte[] sspiBlob;
  
  StreamSSPI() {
    super(237);
  }

  
  void setFromTDS(TDSReader paramTDSReader) throws SQLServerException {
    if (237 != paramTDSReader.readUnsignedByte() && !$assertionsDisabled) throw new AssertionError(); 
    int i = paramTDSReader.readUnsignedShort();
    this.sspiBlob = new byte[i];
    paramTDSReader.readBytes(this.sspiBlob, 0, i);
  }
}
