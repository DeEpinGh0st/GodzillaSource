package com.microsoft.sqlserver.jdbc;

import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.sql.Blob;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;






public final class SQLServerBlob
  implements Blob, Serializable
{
  private byte[] value;
  private SQLServerConnection con;
  private boolean isClosed = false;
  ArrayList<Closeable> activeStreams = new ArrayList<>(1);
  
  private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerBlob");
  
  private static int baseID = 0;
  private final String traceID;
  
  public final String toString() {
    return this.traceID;
  }


  
  private static synchronized int nextInstanceID() {
    baseID++;
    return baseID;
  }






  
  @Deprecated
  public SQLServerBlob(SQLServerConnection paramSQLServerConnection, byte[] paramArrayOfbyte) {
    this.traceID = " SQLServerBlob:" + nextInstanceID();
    this.con = paramSQLServerConnection;



    
    if (null == paramArrayOfbyte) {
      throw new NullPointerException(SQLServerException.getErrString("R_cantSetNull"));
    }
    this.value = paramArrayOfbyte;
    
    if (logger.isLoggable(Level.FINE)) {
      
      String str = (null != paramSQLServerConnection) ? paramSQLServerConnection.toString() : "null connection";
      logger.fine(toString() + " created by (" + str + ")");
    } 
  }

  
  SQLServerBlob(SQLServerConnection paramSQLServerConnection) {
    this.traceID = " SQLServerBlob:" + nextInstanceID();
    this.con = paramSQLServerConnection;
    this.value = new byte[0];
    if (logger.isLoggable(Level.FINE)) {
      logger.fine(toString() + " created by (" + paramSQLServerConnection.toString() + ")");
    }
  }
  
  SQLServerBlob(BaseInputStream paramBaseInputStream) throws SQLServerException {
    this.traceID = " SQLServerBlob:" + nextInstanceID();
    this.value = paramBaseInputStream.getBytes();
    if (logger.isLoggable(Level.FINE)) {
      logger.fine(toString() + " created by (null connection)");
    }
  }







  
  public void free() throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    
    if (!this.isClosed) {

      
      if (null != this.activeStreams) {
        
        for (Closeable closeable : this.activeStreams) {

          
          try {
            closeable.close();
          }
          catch (IOException iOException) {
            
            logger.fine(toString() + " ignored IOException closing stream " + closeable + ": " + iOException.getMessage());
          } 
        } 
        this.activeStreams = null;
      } 

      
      this.value = null;
      
      this.isClosed = true;
    } 
  }




  
  private final void checkClosed() throws SQLServerException {
    if (this.isClosed) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_isFreed"));
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(new Object[] { "Blob" }, ), null, true);
    } 
  }






  
  public InputStream getBinaryStream() throws SQLException {
    checkClosed();
    
    return getBinaryStreamInternal(0, this.value.length);
  }

  
  public InputStream getBinaryStream(long paramLong1, long paramLong2) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();

    
    throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
  }

  
  private InputStream getBinaryStreamInternal(int paramInt1, int paramInt2) {
    assert null != this.value;
    assert paramInt1 >= 0;
    assert 0 <= paramInt2 && paramInt2 <= this.value.length - paramInt1;
    assert null != this.activeStreams;
    
    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(this.value, paramInt1, paramInt2);
    this.activeStreams.add(byteArrayInputStream);
    return byteArrayInputStream;
  }











  
  public byte[] getBytes(long paramLong, int paramInt) throws SQLException {
    checkClosed();
    
    if (paramLong < 1L) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
      Object[] arrayOfObject = { new Long(paramLong) };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
    } 
    
    if (paramInt < 0) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
      Object[] arrayOfObject = { new Integer(paramInt) };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
    } 

    
    paramLong--;

    
    if (paramLong > this.value.length) {
      paramLong = this.value.length;
    }
    
    if (paramInt > this.value.length - paramLong) {
      paramInt = (int)(this.value.length - paramLong);
    }
    byte[] arrayOfByte = new byte[paramInt];
    System.arraycopy(this.value, (int)paramLong, arrayOfByte, 0, paramInt);
    return arrayOfByte;
  }






  
  public long length() throws SQLException {
    checkClosed();
    
    return this.value.length;
  }










  
  public long position(Blob paramBlob, long paramLong) throws SQLException {
    checkClosed();
    
    if (paramLong < 1L) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
      Object[] arrayOfObject = { new Long(paramLong) };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
    } 
    
    if (null == paramBlob) {
      return -1L;
    }
    return position(paramBlob.getBytes(1L, (int)paramBlob.length()), paramLong);
  }










  
  public long position(byte[] paramArrayOfbyte, long paramLong) throws SQLException {
    checkClosed();
    
    if (paramLong < 1L) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
      Object[] arrayOfObject = { new Long(paramLong) };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
    } 


    
    if (null == paramArrayOfbyte) {
      return -1L;
    }
    
    paramLong--;

    
    for (int i = (int)paramLong; i <= this.value.length - paramArrayOfbyte.length; i++) {
      
      boolean bool = true;
      for (byte b = 0; b < paramArrayOfbyte.length; b++) {
        
        if (this.value[i + b] != paramArrayOfbyte[b]) {
          
          bool = false;
          
          break;
        } 
      } 
      if (bool) {
        return (i + 1);
      }
    } 
    return -1L;
  }








  
  public void truncate(long paramLong) throws SQLException {
    checkClosed();
    
    if (paramLong < 0L) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
      Object[] arrayOfObject = { new Long(paramLong) };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
    } 
    
    if (this.value.length > paramLong) {
      
      byte[] arrayOfByte = new byte[(int)paramLong];
      System.arraycopy(this.value, 0, arrayOfByte, 0, (int)paramLong);
      this.value = arrayOfByte;
    } 
  }







  
  public OutputStream setBinaryStream(long paramLong) throws SQLException {
    checkClosed();
    
    if (paramLong < 1L) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(new Object[] { Long.valueOf(paramLong) }, ), null, true);
    } 
    
    return new SQLServerBlobOutputStream(this, paramLong);
  }









  
  public int setBytes(long paramLong, byte[] paramArrayOfbyte) throws SQLException {
    checkClosed();
    
    if (null == paramArrayOfbyte) {
      SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_cantSetNull"), null, true);
    }
    return setBytes(paramLong, paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }




















  
  public int setBytes(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
    checkClosed();
    
    if (null == paramArrayOfbyte) {
      SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_cantSetNull"), null, true);
    }
    
    if (paramInt1 < 0 || paramInt1 > paramArrayOfbyte.length) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidOffset"));
      Object[] arrayOfObject = { new Integer(paramInt1) };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
    } 

    
    if (paramInt2 < 0 || paramInt2 > paramArrayOfbyte.length - paramInt1) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
      Object[] arrayOfObject = { new Integer(paramInt2) };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
    } 



    
    if (paramLong <= 0L || paramLong > (this.value.length + 1)) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
      Object[] arrayOfObject = { new Long(paramLong) };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
    } 

    
    paramLong--;

    
    if (paramInt2 >= this.value.length - paramLong) {

      
      DataTypes.getCheckedLength(this.con, JDBCType.BLOB, paramLong + paramInt2, false);
      assert paramLong + paramInt2 <= 2147483647L;

      
      byte[] arrayOfByte = new byte[(int)paramLong + paramInt2];
      System.arraycopy(this.value, 0, arrayOfByte, 0, (int)paramLong);

      
      System.arraycopy(paramArrayOfbyte, paramInt1, arrayOfByte, (int)paramLong, paramInt2);
      this.value = arrayOfByte;
    
    }
    else {
      
      System.arraycopy(paramArrayOfbyte, paramInt1, this.value, (int)paramLong, paramInt2);
    } 
    
    return paramInt2;
  }
}
