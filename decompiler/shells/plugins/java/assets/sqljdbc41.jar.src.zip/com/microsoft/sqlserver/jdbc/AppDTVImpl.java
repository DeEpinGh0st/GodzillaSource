package com.microsoft.sqlserver.jdbc;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.MessageFormat;
import java.util.Calendar;
import java.util.Date;
import microsoft.sql.DateTimeOffset;
















































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































final class AppDTVImpl
  extends DTVImpl
{
  private JDBCType jdbcType = JDBCType.UNKNOWN;
  
  private Object value;
  private JavaType javaType;
  private StreamSetterArgs streamSetterArgs;
  private Calendar cal;
  private Integer scale;
  private boolean forceEncrypt;
  
  final void skipValue(TypeInfo paramTypeInfo, TDSReader paramTDSReader, boolean paramBoolean) throws SQLServerException {
    assert false;
  }
  
  final void initFromCompressedNull() {
    assert false;
  }
  
  final class SetValueOp
    extends DTVExecuteOp
  {
    private final SQLCollation collation;
    private final SQLServerConnection con;
    
    SetValueOp(SQLCollation param1SQLCollation, SQLServerConnection param1SQLServerConnection) {
      this.collation = param1SQLCollation;
      this.con = param1SQLServerConnection;
    }

    
    void execute(DTV param1DTV, String param1String) throws SQLServerException {
      JDBCType jDBCType = param1DTV.getJdbcType();







      
      if (JDBCType.DECIMAL == jDBCType || JDBCType.NUMERIC == jDBCType || JDBCType.MONEY == jDBCType || JDBCType.SMALLMONEY == jDBCType) {



        
        assert null != param1String;

        
        try {
          param1DTV.setValue(new BigDecimal(param1String), JavaType.BIGDECIMAL);
        }
        catch (NumberFormatException numberFormatException) {
          
          DataTypes.throwConversionError("String", jDBCType.toString());

        
        }


      
      }
      else if (jDBCType.isBinary()) {
        
        assert null != param1String;
        param1DTV.setValue(ParameterUtils.HexToBin(param1String), JavaType.BYTEARRAY);




      
      }
      else if (null != this.collation && (JDBCType.CHAR == jDBCType || JDBCType.VARCHAR == jDBCType || JDBCType.LONGVARCHAR == jDBCType || JDBCType.CLOB == jDBCType)) {




        
        byte[] arrayOfByte = null;
        
        if (null != param1String) {
          
          try {
            
            arrayOfByte = param1String.getBytes(this.collation.getCharset());
          }
          catch (UnsupportedEncodingException unsupportedEncodingException) {
            
            MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_encodingErrorWritingTDS"));
            Object[] arrayOfObject = { new String(unsupportedEncodingException.getMessage()) };
            SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
          } 
        }





        
        param1DTV.setValue(arrayOfByte, JavaType.BYTEARRAY);
      } 
    }


    
    void execute(DTV param1DTV, Clob param1Clob) throws SQLServerException {
      assert null != param1Clob;






      
      try {
        DataTypes.getCheckedLength(this.con, param1DTV.getJdbcType(), param1Clob.length(), false);
      }
      catch (SQLException sQLException) {
        
        SQLServerException.makeFromDriverError(this.con, null, sQLException.getMessage(), null, false);
      } 
    }


    
    void execute(DTV param1DTV, SQLServerSQLXML param1SQLServerSQLXML) throws SQLServerException {}


    
    void execute(DTV param1DTV, Byte param1Byte) throws SQLServerException {}


    
    void execute(DTV param1DTV, Integer param1Integer) throws SQLServerException {}


    
    void execute(DTV param1DTV, Time param1Time) throws SQLServerException {
      if (param1DTV.getJdbcType().isTextual()) {
        
        assert param1Time != null : "value is null";
        param1DTV.setValue(param1Time.toString(), JavaType.STRING);
      } 
    }

    
    void execute(DTV param1DTV, Date param1Date) throws SQLServerException {
      if (param1DTV.getJdbcType().isTextual()) {
        
        assert param1Date != null : "value is null";
        param1DTV.setValue(param1Date.toString(), JavaType.STRING);
      } 
    }

    
    void execute(DTV param1DTV, Timestamp param1Timestamp) throws SQLServerException {
      if (param1DTV.getJdbcType().isTextual()) {
        
        assert param1Timestamp != null : "value is null";
        param1DTV.setValue(param1Timestamp.toString(), JavaType.STRING);
      } 
    }

    
    void execute(DTV param1DTV, Date param1Date) throws SQLServerException {
      if (param1DTV.getJdbcType().isTextual()) {
        
        assert param1Date != null : "value is null";
        param1DTV.setValue(param1Date.toString(), JavaType.STRING);
      } 
    }

    
    void execute(DTV param1DTV, LocalDate param1LocalDate) throws SQLServerException {
      if (param1DTV.getJdbcType().isTextual()) {
        
        assert param1LocalDate != null : "value is null";
        param1DTV.setValue(param1LocalDate.toString(), JavaType.STRING);
      } 
    }

    
    void execute(DTV param1DTV, LocalTime param1LocalTime) throws SQLServerException {
      if (param1DTV.getJdbcType().isTextual()) {
        
        assert param1LocalTime != null : "value is null";
        param1DTV.setValue(param1LocalTime.toString(), JavaType.STRING);
      } 
    }

    
    void execute(DTV param1DTV, LocalDateTime param1LocalDateTime) throws SQLServerException {
      if (param1DTV.getJdbcType().isTextual()) {
        
        assert param1LocalDateTime != null : "value is null";
        param1DTV.setValue(param1LocalDateTime.toString(), JavaType.STRING);
      } 
    }

    
    void execute(DTV param1DTV, OffsetTime param1OffsetTime) throws SQLServerException {
      if (param1DTV.getJdbcType().isTextual()) {
        
        assert param1OffsetTime != null : "value is null";
        param1DTV.setValue(param1OffsetTime.toString(), JavaType.STRING);
      } 
    }

    
    void execute(DTV param1DTV, OffsetDateTime param1OffsetDateTime) throws SQLServerException {
      if (param1DTV.getJdbcType().isTextual()) {
        
        assert param1OffsetDateTime != null : "value is null";
        param1DTV.setValue(param1OffsetDateTime.toString(), JavaType.STRING);
      } 
    }

    
    void execute(DTV param1DTV, Calendar param1Calendar) throws SQLServerException {
      if (param1DTV.getJdbcType().isTextual()) {
        
        assert param1Calendar != null : "value is null";
        param1DTV.setValue(param1Calendar.toString(), JavaType.STRING);
      } 
    }

    
    void execute(DTV param1DTV, DateTimeOffset param1DateTimeOffset) throws SQLServerException {
      if (param1DTV.getJdbcType().isTextual()) {
        
        assert param1DateTimeOffset != null : "value is null";
        param1DTV.setValue(param1DateTimeOffset.toString(), JavaType.STRING);
      } 
    }


    
    void execute(DTV param1DTV, TVP param1TVP) throws SQLServerException {}


    
    void execute(DTV param1DTV, Float param1Float) throws SQLServerException {}


    
    void execute(DTV param1DTV, Double param1Double) throws SQLServerException {}


    
    void execute(DTV param1DTV, BigDecimal param1BigDecimal) throws SQLServerException {
      if (null != param1BigDecimal) {
        
        Integer integer = param1DTV.getScale();
        if (null != integer && integer.intValue() != param1BigDecimal.scale()) {
          param1BigDecimal = param1BigDecimal.setScale(integer.intValue(), 1);
        }
      } 
      param1DTV.setValue(param1BigDecimal, JavaType.BIGDECIMAL);
    }


    
    void execute(DTV param1DTV, Long param1Long) throws SQLServerException {}


    
    void execute(DTV param1DTV, BigInteger param1BigInteger) throws SQLServerException {}


    
    void execute(DTV param1DTV, Short param1Short) throws SQLServerException {}


    
    void execute(DTV param1DTV, Boolean param1Boolean) throws SQLServerException {}


    
    void execute(DTV param1DTV, byte[] param1ArrayOfbyte) throws SQLServerException {}

    
    void execute(DTV param1DTV, Blob param1Blob) throws SQLServerException {
      assert null != param1Blob;






      
      try {
        DataTypes.getCheckedLength(this.con, param1DTV.getJdbcType(), param1Blob.length(), false);
      }
      catch (SQLException sQLException) {
        
        SQLServerException.makeFromDriverError(this.con, null, sQLException.getMessage(), null, false);
      } 
    }

    
    void execute(DTV param1DTV, InputStream param1InputStream) throws SQLServerException {
      DataTypes.getCheckedLength(this.con, param1DTV.getJdbcType(), param1DTV.getStreamSetterArgs().getLength(), true);

      
      if (JDBCType.NCHAR == AppDTVImpl.this.jdbcType || JDBCType.NVARCHAR == AppDTVImpl.this.jdbcType || JDBCType.LONGNVARCHAR == AppDTVImpl.this.jdbcType) {


        
        InputStreamReader inputStreamReader = null;
        
        try {
          inputStreamReader = new InputStreamReader(param1InputStream, "US-ASCII");
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
          
          throw new SQLServerException(null, unsupportedEncodingException.getMessage(), null, 0, true);
        } 
        
        param1DTV.setValue(inputStreamReader, JavaType.READER);





        
        execute(param1DTV, inputStreamReader);
      } 
    }


    
    void execute(DTV param1DTV, Reader param1Reader) throws SQLServerException {
      assert null != param1Reader;
      
      JDBCType jDBCType = param1DTV.getJdbcType();
      long l = DataTypes.getCheckedLength(this.con, param1DTV.getJdbcType(), param1DTV.getStreamSetterArgs().getLength(), true);
      
      if (jDBCType.isBinary()) {





        
        String str = DDC.convertReaderToString(param1Reader, (int)l);


        
        if (-1L != l && str.length() != l) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_mismatchedStreamLength"));
          Object[] arrayOfObject = { Long.valueOf(l), Integer.valueOf(str.length()) };
          SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), "", true);
        } 
        
        param1DTV.setValue(str, JavaType.STRING);
        execute(param1DTV, str);

      
      }
      else if (null != this.collation && (JDBCType.CHAR == jDBCType || JDBCType.VARCHAR == jDBCType || JDBCType.LONGVARCHAR == jDBCType || JDBCType.CLOB == jDBCType)) {




        
        ReaderInputStream readerInputStream = null;

        
        try {
          readerInputStream = new ReaderInputStream(param1Reader, this.collation.getCharset(), l);


        
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_encodingErrorWritingTDS"));
          Object[] arrayOfObject = { new String(unsupportedEncodingException.getMessage()) };
          SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
        } 





        
        param1DTV.setValue(readerInputStream, JavaType.INPUTSTREAM);

        
        param1DTV.setStreamSetterArgs(new StreamSetterArgs(StreamType.CHARACTER, -1L));
        execute(param1DTV, readerInputStream);
      } 
    }
  }













  
  void setValue(DTV paramDTV, SQLCollation paramSQLCollation, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, StreamSetterArgs paramStreamSetterArgs, Calendar paramCalendar, Integer paramInteger, SQLServerConnection paramSQLServerConnection, boolean paramBoolean) throws SQLServerException {
    paramDTV.setValue(paramObject, paramJavaType);
    paramDTV.setJdbcType(paramJDBCType);
    paramDTV.setStreamSetterArgs(paramStreamSetterArgs);
    paramDTV.setCalendar(paramCalendar);
    paramDTV.setScale(paramInteger);
    paramDTV.setForceEncrypt(paramBoolean);
    paramDTV.executeOp(new SetValueOp(paramSQLCollation, paramSQLServerConnection));
  }

  
  void setValue(Object paramObject, JavaType paramJavaType) {
    this.value = paramObject;
    this.javaType = paramJavaType;
  }

  
  void setStreamSetterArgs(StreamSetterArgs paramStreamSetterArgs) {
    this.streamSetterArgs = paramStreamSetterArgs;
  }

  
  void setCalendar(Calendar paramCalendar) {
    this.cal = paramCalendar;
  }

  
  void setScale(Integer paramInteger) {
    this.scale = paramInteger;
  }

  
  void setForceEncrypt(boolean paramBoolean) {
    this.forceEncrypt = paramBoolean;
  }
  
  StreamSetterArgs getStreamSetterArgs() { return this.streamSetterArgs; }
  Calendar getCalendar() { return this.cal; } Integer getScale() {
    return this.scale;
  }
  
  boolean isNull() {
    return (null == this.value);
  }

  
  void setJdbcType(JDBCType paramJDBCType) {
    this.jdbcType = paramJDBCType;
  }

  
  JDBCType getJdbcType() {
    return this.jdbcType;
  }

  
  JavaType getJavaType() {
    return this.javaType;
  }









  
  Object getValue(DTV paramDTV, JDBCType paramJDBCType, int paramInt, InputStreamGetterArgs paramInputStreamGetterArgs, Calendar paramCalendar, TypeInfo paramTypeInfo, CryptoMetadata paramCryptoMetadata, TDSReader paramTDSReader) throws SQLServerException {
    if (this.jdbcType != paramJDBCType) {
      DataTypes.throwConversionError(this.jdbcType.toString(), paramJDBCType.toString());
    }
    return this.value;
  }

  
  Object getSetterValue() {
    return this.value;
  }
}
