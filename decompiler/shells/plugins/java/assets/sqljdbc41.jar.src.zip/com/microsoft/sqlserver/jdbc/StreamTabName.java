package com.microsoft.sqlserver.jdbc;








final class StreamTabName
  extends StreamPacket
{
  private TDSReader tdsReader;
  private TDSReaderMark tableNamesMark;
  
  StreamTabName() {
    super(164);
  }

  
  void setFromTDS(TDSReader paramTDSReader) throws SQLServerException {
    if (164 != paramTDSReader.readUnsignedByte() && 
      !$assertionsDisabled) throw new AssertionError("Not a TABNAME token");
    
    this.tdsReader = paramTDSReader;
    int i = paramTDSReader.readUnsignedShort();
    this.tableNamesMark = paramTDSReader.mark();
    paramTDSReader.skip(i);
  }

  
  void applyTo(Column[] paramArrayOfColumn, int paramInt) throws SQLServerException {
    TDSReaderMark tDSReaderMark = this.tdsReader.mark();
    this.tdsReader.reset(this.tableNamesMark);



    
    SQLIdentifier[] arrayOfSQLIdentifier = new SQLIdentifier[paramInt]; byte b;
    for (b = 0; b < paramInt; b++) {
      arrayOfSQLIdentifier[b] = this.tdsReader.readSQLIdentifier();
    }
    
    for (b = 0; b < paramArrayOfColumn.length; b++) {
      
      Column column = paramArrayOfColumn[b];
      
      if (column.getTableNum() > 0) {
        column.setTableName(arrayOfSQLIdentifier[column.getTableNum() - 1]);
      }
    } 
    this.tdsReader.reset(tDSReaderMark);
  }
}
