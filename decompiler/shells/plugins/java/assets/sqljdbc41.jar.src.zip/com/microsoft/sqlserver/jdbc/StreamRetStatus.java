package com.microsoft.sqlserver.jdbc;




final class StreamRetStatus
  extends StreamPacket
{
  private int status;
  
  final int getStatus() {
    return this.status;
  }
  
  StreamRetStatus() {
    super(121);
  }

  
  void setFromTDS(TDSReader paramTDSReader) throws SQLServerException {
    if (121 != paramTDSReader.readUnsignedByte() && !$assertionsDisabled) throw new AssertionError(); 
    this.status = paramTDSReader.readInt();
  }
}
