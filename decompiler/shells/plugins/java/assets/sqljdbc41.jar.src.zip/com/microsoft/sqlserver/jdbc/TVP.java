package com.microsoft.sqlserver.jdbc;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;











class TVP
{
  String TVPName;
  String TVP_owningSchema;
  String TVP_dbName;
  ResultSet sourceResultSet = null;
  SQLServerDataTable sourceDataTable = null;
  Map<Integer, SQLServerMetaData> columnMetadata = null;
  Iterator<Map.Entry<Integer, Object[]>> sourceDataTableRowIterator = null;
  ISQLServerDataRecord sourceRecord = null;
  
  TVPType tvpType = null;
  
  enum MPIState
  {
    MPI_Value,
    MPI_ParseNonQuote,
    MPI_LookForSeparator,
    MPI_LookForNextCharOrSeparator,
    MPI_ParseQuote,
    MPI_RightQuote;
  }

  
  void initTVP(TVPType paramTVPType, String paramString) throws SQLServerException {
    this.tvpType = paramTVPType;
    this.columnMetadata = new LinkedHashMap<>();
    parseTypeName(paramString);
  }

  
  TVP(String paramString) throws SQLServerException {
    initTVP(TVPType.Null, paramString);
  }


  
  TVP(String paramString, SQLServerDataTable paramSQLServerDataTable) throws SQLServerException {
    initTVP(TVPType.SQLServerDataTable, paramString);
    this.sourceDataTable = paramSQLServerDataTable;
    this.sourceDataTableRowIterator = this.sourceDataTable.getIterator();
    populateMetadataFromDataTable();
  }

  
  TVP(String paramString, ResultSet paramResultSet) throws SQLServerException {
    initTVP(TVPType.ResultSet, paramString);
    this.sourceResultSet = paramResultSet;
    
    populateMetadataFromResultSet();
  }

  
  TVP(String paramString, ISQLServerDataRecord paramISQLServerDataRecord) throws SQLServerException {
    initTVP(TVPType.ISQLServerDataRecord, paramString);
    this.sourceRecord = paramISQLServerDataRecord;
    
    populateMetadataFromDataRecord();

    
    validateOrderProperty();
  }

  
  boolean isNull() {
    return (TVPType.Null == this.tvpType);
  }


  
  Object[] getRowData() throws SQLServerException {
    if (TVPType.ResultSet == this.tvpType) {
      
      int i = this.columnMetadata.size();
      Object[] arrayOfObject = new Object[i];
      for (byte b = 0; b < i; b++) {

        
        try {
          arrayOfObject[b] = this.sourceResultSet.getObject(b + 1);
        }
        catch (SQLException sQLException) {
          
          throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), sQLException);
        } 
      } 
      return arrayOfObject;
    } 
    if (TVPType.SQLServerDataTable == this.tvpType) {
      
      Map.Entry entry = this.sourceDataTableRowIterator.next();
      return (Object[])entry.getValue();
    } 
    
    return this.sourceRecord.getRowData();
  }

  
  boolean next() throws SQLServerException {
    if (TVPType.ResultSet == this.tvpType) {
      
      try {
        
        return this.sourceResultSet.next();
      }
      catch (SQLException sQLException) {
        
        throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), sQLException);
      } 
    }
    if (TVPType.SQLServerDataTable == this.tvpType)
    {
      return this.sourceDataTableRowIterator.hasNext();
    }
    
    return this.sourceRecord.next();
  }

  
  void populateMetadataFromDataTable() throws SQLServerException {
    assert null != this.sourceDataTable;
    
    Map<Integer, SQLServerDataColumn> map = this.sourceDataTable.getColumnMetadata();
    if (null == map || map.isEmpty())
    {
      throw new SQLServerException(SQLServerException.getErrString("R_TVPEmptyMetadata"), null);
    }

    
    Iterator<Map.Entry> iterator = map.entrySet().iterator();
    while (iterator.hasNext()) {
      
      Map.Entry entry = iterator.next();
      
      this.columnMetadata.put((Integer)entry.getKey(), new SQLServerMetaData(((SQLServerDataColumn)entry.getValue()).columnName, ((SQLServerDataColumn)entry.getValue()).javaSqlType, ((SQLServerDataColumn)entry.getValue()).precision, ((SQLServerDataColumn)entry.getValue()).scale));
    } 
  }







  
  void populateMetadataFromResultSet() throws SQLServerException {
    assert null != this.sourceResultSet;
    
    try {
      ResultSetMetaData resultSetMetaData = this.sourceResultSet.getMetaData();
      for (byte b = 0; b < resultSetMetaData.getColumnCount(); b++)
      {
        SQLServerMetaData sQLServerMetaData = new SQLServerMetaData(resultSetMetaData.getColumnName(b + 1), resultSetMetaData.getColumnType(b + 1), resultSetMetaData.getPrecision(b + 1), resultSetMetaData.getScale(b + 1));



        
        this.columnMetadata.put(Integer.valueOf(b), sQLServerMetaData);
      }
    
    } catch (SQLException sQLException) {
      
      throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveColMeta"), sQLException);
    } 
  }

  
  void populateMetadataFromDataRecord() throws SQLServerException {
    assert null != this.sourceRecord;
    if (0 >= this.sourceRecord.getColumnCount())
    {
      throw new SQLServerException(SQLServerException.getErrString("R_TVPEmptyMetadata"), null);
    }

    
    for (byte b = 0; b < this.sourceRecord.getColumnCount(); b++) {

      
      Util.checkDuplicateColumnName((this.sourceRecord.getColumnMetaData(b + 1)).columnName, this.columnMetadata);
      SQLServerMetaData sQLServerMetaData = new SQLServerMetaData(this.sourceRecord.getColumnMetaData(b + 1));
      this.columnMetadata.put(Integer.valueOf(b), sQLServerMetaData);
    } 
  }

  
  void validateOrderProperty() throws SQLServerException {
    int i = this.columnMetadata.size();
    boolean[] arrayOfBoolean = new boolean[i];
    
    int j = -1;
    byte b = 0;
    Iterator<Map.Entry> iterator = this.columnMetadata.entrySet().iterator();
    while (iterator.hasNext()) {
      
      Map.Entry entry = iterator.next();
      SQLServerSortOrder sQLServerSortOrder = ((SQLServerMetaData)entry.getValue()).sortOrder;
      int k = ((SQLServerMetaData)entry.getValue()).sortOrdinal;
      
      if (SQLServerSortOrder.Unspecified != sQLServerSortOrder) {

        
        if (i <= k) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_TVPSortOrdinalGreaterThanFieldCount"));
          throw new SQLServerException(messageFormat.format(new Object[] { Integer.valueOf(k), entry.getKey() }, ), null, 0, null);
        } 

        
        if (arrayOfBoolean[k]) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_TVPDuplicateSortOrdinal"));
          throw new SQLServerException(messageFormat.format(new Object[] { Integer.valueOf(k) }, ), null, 0, null);
        } 
        
        arrayOfBoolean[k] = true;
        if (k > j) {
          j = k;
        }
        b++;
      } 
    } 
    
    if (0 < b)
    {
      
      if (j >= b) {
        byte b1;

        
        for (b1 = 0; b1 < b; b1++) {
          
          if (!arrayOfBoolean[b1])
            break; 
        } 
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_TVPMissingSortOrdinal"));
        throw new SQLServerException(messageFormat.format(new Object[] { Integer.valueOf(b1) }, ), null, 0, null);
      } 
    }
  }
  
  void parseTypeName(String paramString) throws SQLServerException {
    MessageFormat messageFormat;
    String str1 = "[\"";
    String str2 = "]\"";
    byte b1 = 46;
    byte b2 = 3;
    String[] arrayOfString = new String[b2];
    int i = 0;
    
    if (null == paramString || 0 == paramString.length()) {
      
      MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_invalidTVPName"));
      Object[] arrayOfObject = new Object[0];
      throw new SQLServerException(null, messageFormat1.format(arrayOfObject), null, 0, false);
    } 
    
    StringBuilder stringBuilder1 = new StringBuilder(paramString.length());

    
    StringBuilder stringBuilder2 = null;

    
    char c = ' ';
    MPIState mPIState = MPIState.MPI_Value;
    
    for (byte b3 = 0; b3 < paramString.length(); b3++) {
      int k;
      char c1 = paramString.charAt(b3);
      switch (mPIState) {

        
        case MPI_Value:
          if (Character.isWhitespace(c1))
            break; 
          if (c1 == b1) {

            
            arrayOfString[i] = "";
            i++; break;
          } 
          if (-1 != (k = str1.indexOf(c1))) {

            
            c = str2.charAt(k);
            stringBuilder1.setLength(0);
            mPIState = MPIState.MPI_ParseQuote; break;
          } 
          if (-1 != str2.indexOf(c1)) {

            
            MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
            throw new SQLServerException(null, messageFormat1.format(new Object[0]), null, 0, false);
          } 

          
          stringBuilder1.setLength(0);
          stringBuilder1.append(c1);
          mPIState = MPIState.MPI_ParseNonQuote;
          break;

        
        case MPI_ParseNonQuote:
          if (c1 == b1) {
            
            arrayOfString[i] = stringBuilder1.toString();
            i = incrementStringCount(arrayOfString, i);
            mPIState = MPIState.MPI_Value;
            break;
          } 
          if (-1 != str2.indexOf(c1) || -1 != str1.indexOf(c1)) {

            
            MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
            throw new SQLServerException(null, messageFormat1.format(new Object[0]), null, 0, false);
          } 
          if (Character.isWhitespace(c1)) {

            
            arrayOfString[i] = stringBuilder1.toString();
            if (null == stringBuilder2)
              stringBuilder2 = new StringBuilder(); 
            stringBuilder2.setLength(0);
            
            stringBuilder2.append(c1);
            mPIState = MPIState.MPI_LookForNextCharOrSeparator;
            break;
          } 
          stringBuilder1.append(c1);
          break;

        
        case MPI_LookForNextCharOrSeparator:
          if (!Character.isWhitespace(c1)) {

            
            if (c1 == b1) {
              
              i = incrementStringCount(arrayOfString, i);
              mPIState = MPIState.MPI_Value;
              
              break;
            } 
            
            stringBuilder1.append(stringBuilder2);
            stringBuilder1.append(c1);
            arrayOfString[i] = stringBuilder1.toString();
            mPIState = MPIState.MPI_ParseNonQuote;
            
            break;
          } 
          stringBuilder2.append(c1);
          break;

        
        case MPI_ParseQuote:
          if (c1 == c) {
            mPIState = MPIState.MPI_RightQuote; break;
          } 
          stringBuilder1.append(c1);
          break;
        
        case MPI_RightQuote:
          if (c1 == c) {

            
            stringBuilder1.append(c1);
            mPIState = MPIState.MPI_ParseQuote; break;
          } 
          if (c1 == b1) {

            
            arrayOfString[i] = stringBuilder1.toString();
            i = incrementStringCount(arrayOfString, i);
            mPIState = MPIState.MPI_Value; break;
          } 
          if (!Character.isWhitespace(c1)) {

            
            MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
            throw new SQLServerException(null, messageFormat1.format(new Object[0]), null, 0, false);
          } 



          
          arrayOfString[i] = stringBuilder1.toString();
          mPIState = MPIState.MPI_LookForSeparator;
          break;

        
        case MPI_LookForSeparator:
          if (!Character.isWhitespace(c1)) {

            
            if (c1 == b1) {

              
              i = incrementStringCount(arrayOfString, i);
              mPIState = MPIState.MPI_Value;
              
              break;
            } 
            
            MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
            throw new SQLServerException(null, messageFormat1.format(new Object[0]), null, 0, false);
          } 
          break;
      } 

    
    } 
    if (i > b2 - 1) {
      
      MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
      throw new SQLServerException(null, messageFormat1.format(new Object[0]), null, 0, false);
    } 

    
    switch (mPIState) {
      case MPI_Value:
      case MPI_LookForNextCharOrSeparator:
      case MPI_LookForSeparator:
        break;
      
      case MPI_ParseNonQuote:
      case MPI_RightQuote:
        arrayOfString[i] = stringBuilder1.toString();
        break;

      
      default:
        messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
        throw new SQLServerException(null, messageFormat.format(new Object[0]), null, 0, false);
    } 
    
    if (arrayOfString[0] == null) {
      
      messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
      throw new SQLServerException(null, messageFormat.format(new Object[0]), null, 0, false);
    } 


    
    int j = b2 - i - 1;
    if (j > 0) {
      for (int k = b2 - 1; k >= j; k--) {
        
        arrayOfString[k] = arrayOfString[k - j];
        arrayOfString[k - j] = null;
      } 
    }
    
    this.TVPName = arrayOfString[2];
    this.TVP_owningSchema = arrayOfString[1];
    this.TVP_dbName = arrayOfString[0];
  }









  
  private int incrementStringCount(String[] paramArrayOfString, int paramInt) throws SQLServerException {
    paramInt++;
    int i = paramArrayOfString.length;
    if (paramInt >= i) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
      throw new SQLServerException(null, messageFormat.format(new Object[0]), null, 0, false);
    } 
    paramArrayOfString[paramInt] = new String();
    return paramInt;
  }

  
  String getTVPName() {
    return this.TVPName;
  }

  
  String getDbNameTVP() {
    return this.TVP_dbName;
  }

  
  String getOwningSchemaNameTVP() {
    return this.TVP_owningSchema;
  }

  
  int getTVPColumnCount() {
    return this.columnMetadata.size();
  }

  
  Map<Integer, SQLServerMetaData> getColumnMetadata() {
    return this.columnMetadata;
  }
}
