package com.microsoft.sqlserver.jdbc;

final class LocalDate extends TemporalCompatibility {}
