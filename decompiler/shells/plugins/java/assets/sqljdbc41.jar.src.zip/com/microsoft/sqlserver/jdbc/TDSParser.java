package com.microsoft.sqlserver.jdbc;

import java.util.logging.Level;
import java.util.logging.Logger;


















final class TDSParser
{
  private static Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.TDS.TOKEN");








  
  static void parse(TDSReader paramTDSReader, String paramString) throws SQLServerException {
    parse(paramTDSReader, new TDSTokenHandler(paramString));
  }

  
  static void parse(TDSReader paramTDSReader, TDSTokenHandler paramTDSTokenHandler) throws SQLServerException {
    boolean bool1 = logger.isLoggable(Level.FINEST);

    
    boolean bool2 = true;

    
    boolean bool3 = false;
    boolean bool4 = false;
    while (bool2) {
      
      int i = paramTDSReader.peekTokenType();
      if (bool1)
      {
        logger.finest(paramTDSReader.toString() + ": " + paramTDSTokenHandler.logContext + ": Processing " + ((-1 == i) ? "EOF" : TDS.getTokenName(i)));
      }



      
      switch (i) {
        case 237:
          bool2 = paramTDSTokenHandler.onSSPI(paramTDSReader); continue;
        case 173:
          bool3 = true;
          bool2 = paramTDSTokenHandler.onLoginAck(paramTDSReader);
          continue;
        case 174:
          bool4 = true;
          paramTDSReader.getConnection().processFeatureExtAck(paramTDSReader);
          bool2 = true; continue;
        case 227:
          bool2 = paramTDSTokenHandler.onEnvChange(paramTDSReader); continue;
        case 121: bool2 = paramTDSTokenHandler.onRetStatus(paramTDSReader); continue;
        case 172: bool2 = paramTDSTokenHandler.onRetValue(paramTDSReader); continue;
        case 253:
        case 254:
        case 255:
          paramTDSReader.getCommand().checkForInterrupt();
          bool2 = paramTDSTokenHandler.onDone(paramTDSReader);
          continue;
        
        case 170:
          bool2 = paramTDSTokenHandler.onError(paramTDSReader); continue;
        case 171:
          bool2 = paramTDSTokenHandler.onInfo(paramTDSReader); continue;
        case 169: bool2 = paramTDSTokenHandler.onOrder(paramTDSReader); continue;
        case 129: bool2 = paramTDSTokenHandler.onColMetaData(paramTDSReader); continue;
        case 209: bool2 = paramTDSTokenHandler.onRow(paramTDSReader); continue;
        case 210: bool2 = paramTDSTokenHandler.onNBCRow(paramTDSReader); continue;
        case 165: bool2 = paramTDSTokenHandler.onColInfo(paramTDSReader); continue;
        case 164: bool2 = paramTDSTokenHandler.onTabName(paramTDSReader);
          continue;
        case 238:
          bool2 = paramTDSTokenHandler.onFedAuthInfo(paramTDSReader);
          continue;
        
        case -1:
          paramTDSReader.getCommand().onTokenEOF();
          paramTDSTokenHandler.onEOF(paramTDSReader);
          bool2 = false;
          continue;
      } 
      
      throwUnexpectedTokenException(paramTDSReader, paramTDSTokenHandler.logContext);
    } 



    
    if (bool3 && !bool4) {
      paramTDSReader.TryProcessFeatureExtAck(bool4);
    }
  }

  
  static void throwUnexpectedTokenException(TDSReader paramTDSReader, String paramString) throws SQLServerException {
    if (logger.isLoggable(Level.SEVERE))
      logger.severe(paramTDSReader.toString() + ": " + paramString + ": Encountered unexpected " + TDS.getTokenName(paramTDSReader.peekTokenType())); 
    paramTDSReader.throwInvalidTDSToken(TDS.getTokenName(paramTDSReader.peekTokenType()));
  }


  
  static void ignoreLengthPrefixedToken(TDSReader paramTDSReader) throws SQLServerException {
    paramTDSReader.readUnsignedByte();
    int i = paramTDSReader.readUnsignedShort();
    byte[] arrayOfByte = new byte[i];
    paramTDSReader.readBytes(arrayOfByte, 0, i);
  }
}
