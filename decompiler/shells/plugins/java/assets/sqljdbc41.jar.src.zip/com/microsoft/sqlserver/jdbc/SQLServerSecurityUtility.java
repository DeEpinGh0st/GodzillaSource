package com.microsoft.sqlserver.jdbc;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Iterator;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
















class SQLServerSecurityUtility
{
  static byte[] getHMACWithSHA256(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt) throws NoSuchAlgorithmException, InvalidKeyException {
    byte[] arrayOfByte2 = new byte[paramInt];
    Mac mac = Mac.getInstance("HmacSHA256");
    SecretKeySpec secretKeySpec = new SecretKeySpec(paramArrayOfbyte2, "HmacSHA256");
    mac.init(secretKeySpec);
    byte[] arrayOfByte1 = mac.doFinal(paramArrayOfbyte1);
    
    System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, arrayOfByte2.length);
    return arrayOfByte2;
  }








  
  static boolean compareBytes(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt1, int paramInt2) {
    if (null == paramArrayOfbyte1 || null == paramArrayOfbyte2) {
      return false;
    }
    
    if (paramArrayOfbyte2.length - paramInt1 < paramInt2) {
      return false;
    }
    
    for (byte b = 0; b < paramArrayOfbyte1.length && b < paramInt2; b++) {
      if (paramArrayOfbyte1[b] != paramArrayOfbyte2[paramInt1 + b]) {
        return false;
      }
    } 
    return true;
  }






  
  static byte[] encryptWithKey(byte[] paramArrayOfbyte, CryptoMetadata paramCryptoMetadata, SQLServerConnection paramSQLServerConnection) throws SQLServerException {
    String str = paramSQLServerConnection.getTrustedServerNameAE();
    assert str != null : "Server name should npt be null in EncryptWithKey";

    
    if (!paramCryptoMetadata.IsAlgorithmInitialized()) {
      decryptSymmetricKey(paramCryptoMetadata, paramSQLServerConnection);
    }
    
    assert paramCryptoMetadata.IsAlgorithmInitialized();
    byte[] arrayOfByte = paramCryptoMetadata.cipherAlgorithm.encryptData(paramArrayOfbyte);
    if (null == arrayOfByte || 0 == arrayOfByte.length) {
      throw new SQLServerException(null, SQLServerException.getErrString("R_NullCipherTextAE"), null, 0, false);
    }
    return arrayOfByte;
  }








  
  private static String ValidateAndGetEncryptionAlgorithmName(byte paramByte, String paramString) throws SQLServerException {
    if (2 != paramByte) {
      throw new SQLServerException(null, SQLServerException.getErrString("R_CustomCipherAlgorithmNotSupportedAE"), null, 0, false);
    }
    return "AEAD_AES_256_CBC_HMAC_SHA256";
  }







  
  static void decryptSymmetricKey(CryptoMetadata paramCryptoMetadata, SQLServerConnection paramSQLServerConnection) throws SQLServerException {
    assert null != paramCryptoMetadata : "md should not be null in DecryptSymmetricKey.";
    assert null != paramCryptoMetadata.cekTableEntry : "md.EncryptionInfo should not be null in DecryptSymmetricKey.";
    assert null != paramCryptoMetadata.cekTableEntry.columnEncryptionKeyValues : "md.EncryptionInfo.ColumnEncryptionKeyValues should not be null in DecryptSymmetricKey.";
    
    SQLServerSymmetricKey sQLServerSymmetricKey = null;
    EncryptionKeyInfo encryptionKeyInfo = null;
    SQLServerSymmetricKeyCache sQLServerSymmetricKeyCache = SQLServerSymmetricKeyCache.getInstance();
    Iterator<EncryptionKeyInfo> iterator = paramCryptoMetadata.cekTableEntry.columnEncryptionKeyValues.iterator();
    SQLServerException sQLServerException = null;
    while (iterator.hasNext()) {
      
      EncryptionKeyInfo encryptionKeyInfo1 = iterator.next();
      try {
        sQLServerSymmetricKey = sQLServerSymmetricKeyCache.getKey(encryptionKeyInfo1, paramSQLServerConnection);
        if (null != sQLServerSymmetricKey) {
          encryptionKeyInfo = encryptionKeyInfo1;
          
          break;
        } 
      } catch (SQLServerException sQLServerException1) {
        
        sQLServerException = sQLServerException1;
      } 
    } 
    
    if (null == sQLServerSymmetricKey) {
      assert null != sQLServerException : "CEK decryption failed without raising exceptions";
      throw sQLServerException;
    } 

    
    paramCryptoMetadata.cipherAlgorithm = null;
    SQLServerEncryptionAlgorithm sQLServerEncryptionAlgorithm = null;
    String str = ValidateAndGetEncryptionAlgorithmName(paramCryptoMetadata.cipherAlgorithmId, paramCryptoMetadata.cipherAlgorithmName);
    sQLServerEncryptionAlgorithm = SQLServerEncryptionAlgorithmFactoryList.getInstance().getAlgorithm(sQLServerSymmetricKey, paramCryptoMetadata.encryptionType, str);
    assert null != sQLServerEncryptionAlgorithm : "Cipher algorithm cannot be null in DecryptSymmetricKey";
    paramCryptoMetadata.cipherAlgorithm = sQLServerEncryptionAlgorithm;
    paramCryptoMetadata.encryptionKeyInfo = encryptionKeyInfo;
  }





  
  static byte[] decryptWithKey(byte[] paramArrayOfbyte, CryptoMetadata paramCryptoMetadata, SQLServerConnection paramSQLServerConnection) throws SQLServerException {
    String str = paramSQLServerConnection.getTrustedServerNameAE();
    assert null != str : "serverName should not be null in DecryptWithKey.";

    
    if (!paramCryptoMetadata.IsAlgorithmInitialized()) {
      decryptSymmetricKey(paramCryptoMetadata, paramSQLServerConnection);
    }
    
    assert paramCryptoMetadata.IsAlgorithmInitialized() : "Decryption Algorithm is not initialized";
    byte[] arrayOfByte = paramCryptoMetadata.cipherAlgorithm.decryptData(paramArrayOfbyte);
    if (null == arrayOfByte) {
      throw new SQLServerException(null, SQLServerException.getErrString("R_PlainTextNullAE"), null, 0, false);
    }
    
    return arrayOfByte;
  }
}
