package com.microsoft.sqlserver.jdbc;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.sql.Clob;
import java.sql.NClob;
import java.sql.SQLException;
import java.util.logging.Logger;

public final class SQLServerNClob
  extends SQLServerClobBase implements NClob {
  private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerNClob");

  
  SQLServerNClob(SQLServerConnection paramSQLServerConnection) {
    super(paramSQLServerConnection, "", paramSQLServerConnection.getDatabaseCollation(), logger);
  }

  
  SQLServerNClob(BaseInputStream paramBaseInputStream, TypeInfo paramTypeInfo) throws SQLServerException, UnsupportedEncodingException {
    super(null, new String(paramBaseInputStream.getBytes(), paramTypeInfo.getCharset()), paramTypeInfo.getSQLCollation(), logger);
  }
  final JDBCType getJdbcType() {
    return JDBCType.NCLOB;
  }
}
