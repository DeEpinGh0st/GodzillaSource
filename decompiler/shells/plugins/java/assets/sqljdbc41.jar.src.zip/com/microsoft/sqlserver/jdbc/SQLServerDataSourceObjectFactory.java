package com.microsoft.sqlserver.jdbc;

import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.Name;
import javax.naming.RefAddr;
import javax.naming.Reference;
import javax.naming.spi.ObjectFactory;















public final class SQLServerDataSourceObjectFactory
  implements ObjectFactory
{
  public Object getObjectInstance(Object paramObject, Name paramName, Context paramContext, Hashtable<?, ?> paramHashtable) throws SQLServerException {
    try {
      Reference reference = (Reference)paramObject;
      
      RefAddr refAddr = reference.get("class");

      
      if (null == refAddr)
      {
        SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_invalidDataSourceReference"), null, true);
      }

      
      String str = (String)refAddr.getContent();
      
      if (null == str) {
        SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_invalidDataSourceReference"), null, true);
      }

      
      if (str.equals("com.microsoft.sqlserver.jdbc.SQLServerDataSource") || str.equals("com.microsoft.sqlserver.jdbc.SQLServerConnectionPoolDataSource") || str.equals("com.microsoft.sqlserver.jdbc.SQLServerXADataSource")) {




        
        Class<?> clazz = Class.forName(str);
        Object object = clazz.newInstance();


        
        SQLServerDataSource sQLServerDataSource = (SQLServerDataSource)object;
        sQLServerDataSource.initializeFromReference(reference);
        return object;
      } 
      
      SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_invalidDataSourceReference"), null, true);
    
    }
    catch (ClassNotFoundException classNotFoundException) {
      
      SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_invalidDataSourceReference"), null, true);
    
    }
    catch (InstantiationException instantiationException) {
      
      SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_invalidDataSourceReference"), null, true);
    
    }
    catch (IllegalAccessException illegalAccessException) {
      
      SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_invalidDataSourceReference"), null, true);
    } 

    
    return null;
  }
}
