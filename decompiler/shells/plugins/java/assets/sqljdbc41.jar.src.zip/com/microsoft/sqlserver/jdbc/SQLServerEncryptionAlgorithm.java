package com.microsoft.sqlserver.jdbc;

abstract class SQLServerEncryptionAlgorithm {
  abstract byte[] encryptData(byte[] paramArrayOfbyte) throws SQLServerException;
  
  abstract byte[] decryptData(byte[] paramArrayOfbyte) throws SQLServerException;
}
