package com.microsoft.sqlserver.jdbc;

import java.text.MessageFormat;
















































































public class SQLServerBulkCopyOptions
{
  private int batchSize = 0;
  private int bulkCopyTimeout = 60;
  
  private boolean checkConstraints = false;
  
  private boolean fireTriggers = false;
  
  private boolean keepIdentity = false;
  
  private boolean keepNulls = false;
  
  private boolean tableLock = false;
  
  private boolean useInternalTransaction = false;
  
  private boolean allowEncryptedValueModifications = false;
  
  public int getBatchSize() {
    return this.batchSize;
  }







  
  public void setBatchSize(int paramInt) throws SQLServerException {
    if (paramInt >= 0) {
      
      this.batchSize = paramInt;
    }
    else {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidNegativeArg"));
      Object[] arrayOfObject = { "batchSize" };
      SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), null, false);
    } 
  }






  
  public int getBulkCopyTimeout() {
    return this.bulkCopyTimeout;
  }







  
  public void setBulkCopyTimeout(int paramInt) throws SQLServerException {
    if (paramInt >= 0) {
      
      this.bulkCopyTimeout = paramInt;
    }
    else {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidNegativeArg"));
      Object[] arrayOfObject = { "timeout" };
      SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), null, false);
    } 
  }






  
  public boolean isKeepIdentity() {
    return this.keepIdentity;
  }






  
  public void setKeepIdentity(boolean paramBoolean) {
    this.keepIdentity = paramBoolean;
  }







  
  public boolean isKeepNulls() {
    return this.keepNulls;
  }







  
  public void setKeepNulls(boolean paramBoolean) {
    this.keepNulls = paramBoolean;
  }






  
  public boolean isTableLock() {
    return this.tableLock;
  }






  
  public void setTableLock(boolean paramBoolean) {
    this.tableLock = paramBoolean;
  }






  
  public boolean isUseInternalTransaction() {
    return this.useInternalTransaction;
  }






  
  public void setUseInternalTransaction(boolean paramBoolean) {
    this.useInternalTransaction = paramBoolean;
  }






  
  public boolean isCheckConstraints() {
    return this.checkConstraints;
  }






  
  public void setCheckConstraints(boolean paramBoolean) {
    this.checkConstraints = paramBoolean;
  }






  
  public boolean isFireTriggers() {
    return this.fireTriggers;
  }






  
  public void setFireTriggers(boolean paramBoolean) {
    this.fireTriggers = paramBoolean;
  }

  
  public boolean isAllowEncryptedValueModifications() {
    return this.allowEncryptedValueModifications;
  }

  
  public void setAllowEncryptedValueModifications(boolean paramBoolean) {
    this.allowEncryptedValueModifications = paramBoolean;
  }
}
