package com.microsoft.sqlserver.jdbc;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.MessageFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.SimpleTimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;


















































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































final class ServerDTVImpl
  extends DTVImpl
{
  private int valueLength;
  private TDSReaderMark valueMark;
  private boolean isNull;
  private static final int STREAMCONSUMED = -2;
  
  void setValue(DTV paramDTV, SQLCollation paramSQLCollation, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, StreamSetterArgs paramStreamSetterArgs, Calendar paramCalendar, Integer paramInteger, SQLServerConnection paramSQLServerConnection, boolean paramBoolean) throws SQLServerException {
    paramDTV.setImpl(new AppDTVImpl());
    paramDTV.setValue(paramSQLCollation, paramJDBCType, paramObject, paramJavaType, paramStreamSetterArgs, paramCalendar, paramInteger, paramSQLServerConnection, paramBoolean);
  }




  
  void setValue(Object paramObject, JavaType paramJavaType) {
    assert false;
  }




  
  void setPositionAfterStreamed(TDSReader paramTDSReader) {
    this.valueMark = paramTDSReader.mark();
    this.valueLength = -2;
  }


  
  void setStreamSetterArgs(StreamSetterArgs paramStreamSetterArgs) {
    assert false;
  }


  
  void setCalendar(Calendar paramCalendar) {
    assert false;
  }


  
  void setScale(Integer paramInteger) {
    assert false;
  }


  
  void setForceEncrypt(boolean paramBoolean) {
    assert false;
  }


  
  StreamSetterArgs getStreamSetterArgs() {
    assert false;
    return null;
  }


  
  Calendar getCalendar() {
    assert false;
    return null;
  }


  
  Integer getScale() {
    assert false;
    return null;
  }

  
  boolean isNull() {
    return this.isNull;
  }


  
  void setJdbcType(JDBCType paramJDBCType) {
    assert false;
  }


  
  JDBCType getJdbcType() {
    assert false;
    return JDBCType.UNKNOWN;
  }


  
  JavaType getJavaType() {
    assert false;
    return JavaType.OBJECT;
  }




  
  final void initFromCompressedNull() {
    assert this.valueMark == null;
    this.isNull = true;
  }



  
  final void skipValue(TypeInfo paramTypeInfo, TDSReader paramTDSReader, boolean paramBoolean) throws SQLServerException {
    if (null == this.valueMark && this.isNull) {
      return;
    }

    
    if (null == this.valueMark)
      getValuePrep(paramTypeInfo, paramTDSReader); 
    paramTDSReader.reset(this.valueMark);
    
    if (this.valueLength != -2)
    {
      if (this.valueLength == -1) {
        
        assert SSLenType.PARTLENTYPE == paramTypeInfo.getSSLenType();

        
        PLPInputStream pLPInputStream = PLPInputStream.makeTempStream(paramTDSReader, paramBoolean, this);
        
        try {
          if (null != pLPInputStream) {
            pLPInputStream.close();
          }
        } catch (IOException iOException) {
          
          paramTDSReader.getConnection().terminate(3, iOException.getMessage());
        }
      
      } else {
        
        assert this.valueLength >= 0;
        paramTDSReader.skip(this.valueLength);
      } 
    }
  }

  
  private static final Logger aeLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.DTV");



  
  private final void getValuePrep(TypeInfo paramTypeInfo, TDSReader paramTDSReader) throws SQLServerException {
    assert null == this.valueMark;

    
    switch (paramTypeInfo.getSSLenType()) {
      
      case CHAR:
        this.valueLength = -1;
        this.isNull = PLPInputStream.isNull(paramTDSReader);
        break;
      
      case VARCHAR:
        this.valueLength = paramTypeInfo.getMaxLength();
        this.isNull = (0 == this.valueLength);
        break;
      
      case NCHAR:
        this.valueLength = paramTDSReader.readUnsignedByte();
        this.isNull = (0 == this.valueLength);
        break;
      
      case NVARCHAR:
        this.valueLength = paramTDSReader.readUnsignedShort();
        this.isNull = (65535 == this.valueLength);
        if (this.isNull) {
          this.valueLength = 0;
        }
        break;
      case VARCHARMAX:
        if (SSType.TEXT == paramTypeInfo.getSSType() || SSType.IMAGE == paramTypeInfo.getSSType() || SSType.NTEXT == paramTypeInfo.getSSType()) {


          
          this.isNull = (0 == paramTDSReader.readUnsignedByte());
          if (this.isNull) {
            
            this.valueLength = 0;
            
            break;
          } 
          
          paramTDSReader.skip(24);
          this.valueLength = paramTDSReader.readInt();
          
          break;
        } 
        
        this.valueLength = paramTDSReader.readInt();
        this.isNull = (0 == this.valueLength);
        break;
    } 

    
    if (this.valueLength > paramTypeInfo.getMaxLength()) {
      paramTDSReader.throwInvalidTDS();
    }
    this.valueMark = paramTDSReader.mark(); } Object denormalizedValue(byte[] paramArrayOfbyte, JDBCType paramJDBCType, TypeInfo paramTypeInfo, SQLServerConnection paramSQLServerConnection, InputStreamGetterArgs paramInputStreamGetterArgs, byte paramByte, Calendar paramCalendar) throws SQLServerException {
    MessageFormat messageFormat2;
    BigInteger bigInteger;
    int j;
    long l1;
    int i;
    byte[] arrayOfByte1, arrayOfByte2;
    long l2;
    byte[] arrayOfByte3;
    long l3;
    int k, m;
    short s;
    if (1 != paramByte) {
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_UnsupportedNormalizationVersionAE"));
      throw new SQLServerException(messageFormat.format(new Object[] { Byte.valueOf(paramByte), Integer.valueOf(1) }, ), null, 0, null);
    } 
    
    if (aeLogger.isLoggable(Level.FINE))
    {
      aeLogger.fine("Denormalizing decrypted data based on its SQL Server type(" + paramTypeInfo.getSSType() + ") and JDBC type(" + paramJDBCType + ").");
    }

    
    SSType sSType = paramTypeInfo.getSSType();
    switch (sSType) {
      
      case CHAR:
      case VARCHAR:
      case NCHAR:
      case NVARCHAR:
      case VARCHARMAX:
      case NVARCHARMAX:
        
        try {
          
          String str = new String(paramArrayOfbyte, 0, paramArrayOfbyte.length, (null == paramTypeInfo.getCharset()) ? paramSQLServerConnection.getDatabaseCollation().getCharset() : paramTypeInfo.getCharset());





          
          if (SSType.CHAR == sSType || SSType.NCHAR == sSType) {

            
            StringBuffer stringBuffer = new StringBuffer(str);
            int n = paramTypeInfo.getPrecision() - str.length();
            for (byte b = 0; b < n; b++)
            {
              stringBuffer.append(' ');
            }
            str = stringBuffer.toString();
          } 
          return DDC.convertStringToObject(str, paramTypeInfo.getCharset(), paramJDBCType, paramInputStreamGetterArgs.streamType);
        }
        catch (IllegalArgumentException illegalArgumentException) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorConvertingValue"));
          throw new SQLServerException(messageFormat.format(new Object[] { sSType, paramJDBCType }, ), null, 0, illegalArgumentException);
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {

          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
          throw new SQLServerException(messageFormat.format(new Object[] { paramTypeInfo.getCharset() }, ), null, 0, null);
        } 



      
      case BIT:
      case TINYINT:
      case SMALLINT:
      case INTEGER:
      case BIGINT:
        if (8 != paramArrayOfbyte.length) {

          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_NormalizationErrorAE"));
          throw new SQLServerException(messageFormat.format(new Object[] { sSType }, ), null, 0, null);
        } 
        return DDC.convertLongToObject(Util.readLong(paramArrayOfbyte, 0), paramJDBCType, sSType, paramInputStreamGetterArgs.streamType);









      
      case REAL:
      case FLOAT:
        if (8 == paramArrayOfbyte.length)
        {
          return DDC.convertDoubleToObject(ByteBuffer.wrap(paramArrayOfbyte).order(ByteOrder.LITTLE_ENDIAN).getDouble(), (JDBCType.VARBINARY == paramJDBCType) ? sSType.getJDBCType() : paramJDBCType, paramInputStreamGetterArgs.streamType);
        }


        
        if (4 == paramArrayOfbyte.length)
        {
          return DDC.convertFloatToObject(ByteBuffer.wrap(paramArrayOfbyte).order(ByteOrder.LITTLE_ENDIAN).getFloat(), (JDBCType.VARBINARY == paramJDBCType) ? sSType.getJDBCType() : paramJDBCType, paramInputStreamGetterArgs.streamType);
        }




        
        messageFormat2 = new MessageFormat(SQLServerException.getErrString("R_NormalizationErrorAE"));
        throw new SQLServerException(messageFormat2.format(new Object[] { sSType }, ), null, 0, null);


      
      case SMALLMONEY:
        return DDC.convertMoneyToObject(new BigDecimal(BigInteger.valueOf(Util.readInt(paramArrayOfbyte, 4)), 4), (JDBCType.VARBINARY == paramJDBCType) ? sSType.getJDBCType() : paramJDBCType, paramInputStreamGetterArgs.streamType, 4);






      
      case MONEY:
        bigInteger = BigInteger.valueOf(Util.readInt(paramArrayOfbyte, 0) << 32L | Util.readInt(paramArrayOfbyte, 4) & 0xFFFFFFFFL);


        
        return DDC.convertMoneyToObject(new BigDecimal(bigInteger, 4), (JDBCType.VARBINARY == paramJDBCType) ? sSType.getJDBCType() : paramJDBCType, paramInputStreamGetterArgs.streamType, 8);






      
      case NUMERIC:
      case DECIMAL:
        return DDC.convertBigDecimalToObject(Util.readBigDecimal(paramArrayOfbyte, paramArrayOfbyte.length, paramTypeInfo.getScale()), (JDBCType.VARBINARY == paramJDBCType) ? sSType.getJDBCType() : paramJDBCType, paramInputStreamGetterArgs.streamType);





      
      case BINARY:
      case VARBINARY:
      case VARBINARYMAX:
        return DDC.convertBytesToObject(paramArrayOfbyte, paramJDBCType, paramTypeInfo);







      
      case DATE:
        if (3 != paramArrayOfbyte.length) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_NormalizationErrorAE"));
          throw new SQLServerException(messageFormat.format(new Object[] { sSType }, ), null, 0, null);
        } 



        
        j = getDaysIntoCE(paramArrayOfbyte, sSType);
        
        return DDC.convertTemporalToObject(paramJDBCType, sSType, paramCalendar, j, 0L, 0);



      
      case TIME:
        l1 = readNanosSinceMidnightAE(paramArrayOfbyte, paramTypeInfo.getScale(), sSType);
        
        return DDC.convertTemporalToObject(paramJDBCType, SSType.TIME, paramCalendar, 0, l1, paramTypeInfo.getScale());








      
      case DATETIME2:
        if (8 != paramArrayOfbyte.length) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_NormalizationErrorAE"));
          throw new SQLServerException(messageFormat.format(new Object[] { sSType }, ), null, 0, null);
        } 

        
        i = paramArrayOfbyte.length - 3;
        arrayOfByte1 = new byte[i];
        arrayOfByte2 = new byte[3];
        System.arraycopy(paramArrayOfbyte, 0, arrayOfByte1, 0, i);
        System.arraycopy(paramArrayOfbyte, i, arrayOfByte2, 0, 3);
        l2 = readNanosSinceMidnightAE(arrayOfByte1, paramTypeInfo.getScale(), sSType);
        
        k = getDaysIntoCE(arrayOfByte2, sSType);

        
        return DDC.convertTemporalToObject(paramJDBCType, SSType.DATETIME2, paramCalendar, k, l2, paramTypeInfo.getScale());









      
      case SMALLDATETIME:
        if (4 != paramArrayOfbyte.length) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_NormalizationErrorAE"));
          throw new SQLServerException(messageFormat.format(new Object[] { sSType }, ), null, 0, null);
        } 



        
        return DDC.convertTemporalToObject(paramJDBCType, SSType.DATETIME, paramCalendar, Util.readUnsignedShort(paramArrayOfbyte, 0), Util.readUnsignedShort(paramArrayOfbyte, 2) * 60L * 1000L, 0);








      
      case DATETIME:
        if (8 != paramArrayOfbyte.length) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_NormalizationErrorAE"));
          throw new SQLServerException(messageFormat.format(new Object[] { sSType }, ), null, 0, null);
        } 



        
        return DDC.convertTemporalToObject(paramJDBCType, SSType.DATETIME, paramCalendar, Util.readInt(paramArrayOfbyte, 0), ((Util.readInt(paramArrayOfbyte, 4) * 10 + 1) / 3), 0);









      
      case DATETIMEOFFSET:
        i = paramArrayOfbyte.length - 5;
        arrayOfByte1 = new byte[i];
        arrayOfByte2 = new byte[3];
        arrayOfByte3 = new byte[2];
        System.arraycopy(paramArrayOfbyte, 0, arrayOfByte1, 0, i);
        System.arraycopy(paramArrayOfbyte, i, arrayOfByte2, 0, 3);
        System.arraycopy(paramArrayOfbyte, i + 3, arrayOfByte3, 0, 2);
        l3 = readNanosSinceMidnightAE(arrayOfByte1, paramTypeInfo.getScale(), sSType);

        
        m = getDaysIntoCE(arrayOfByte2, sSType);
        
        s = ByteBuffer.wrap(arrayOfByte3).order(ByteOrder.LITTLE_ENDIAN).getShort();
        
        return DDC.convertTemporalToObject(paramJDBCType, SSType.DATETIMEOFFSET, new GregorianCalendar(new SimpleTimeZone(s * 60 * 1000, ""), Locale.US), m, l3, paramTypeInfo.getScale());









      
      case GUID:
        return Util.readGUID(paramArrayOfbyte);
    } 

    
    MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_UnsupportedDataTypeAE"));
    throw new SQLServerException(messageFormat1.format(new Object[] { sSType }, ), null, 0, null);
  }










  
  Object getValue(DTV paramDTV, JDBCType paramJDBCType, int paramInt, InputStreamGetterArgs paramInputStreamGetterArgs, Calendar paramCalendar, TypeInfo paramTypeInfo, CryptoMetadata paramCryptoMetadata, TDSReader paramTDSReader) throws SQLServerException {
    SQLServerConnection sQLServerConnection = paramTDSReader.getConnection();
    Object object = null;
    byte[] arrayOfByte = null;
    boolean bool1 = false;
    SSType sSType = paramTypeInfo.getSSType();


    
    if (null != paramCryptoMetadata) {
      
      assert SSType.VARBINARY == paramTypeInfo.getSSType() || SSType.VARBINARYMAX == paramTypeInfo.getSSType();
      
      sSType = paramCryptoMetadata.baseTypeInfo.getSSType();
      bool1 = true;
      
      if (aeLogger.isLoggable(Level.FINE))
      {
        aeLogger.fine("Data is encrypted, SQL Server Data Type: " + sSType + ", Encryption Type: " + paramCryptoMetadata.getEncryptionType());
      }
    } 






    
    if (null == this.valueMark && !this.isNull) {
      getValuePrep(paramTypeInfo, paramTDSReader);
    }

    
    assert this.valueMark != null || (this.valueMark == null && this.isNull);
    
    boolean bool2 = false;
    
    if (null != paramInputStreamGetterArgs) {
      
      if (!paramInputStreamGetterArgs.streamType.convertsFrom(paramTypeInfo)) {
        DataTypes.throwConversionError(paramTypeInfo.getSSType().toString(), paramInputStreamGetterArgs.streamType.toString());
      }
    } else {
      
      if (!sSType.convertsTo(paramJDBCType))
      {
        
        if (bool1) {
          
          if (!Util.isBinaryType(paramJDBCType.getIntValue()).booleanValue())
          {
            DataTypes.throwConversionError(sSType.toString(), paramJDBCType.toString());
          }
        }
        else {
          
          DataTypes.throwConversionError(sSType.toString(), paramJDBCType.toString());
        } 
      }
      
      paramInputStreamGetterArgs = InputStreamGetterArgs.getDefaultArgs();
    } 
    
    if (-2 == this.valueLength)
    {
      throw new SQLServerException(null, SQLServerException.getErrString("R_dataAlreadyAccessed"), null, 0, false);
    }
    
    if (!this.isNull) {
      
      paramTDSReader.reset(this.valueMark);
      
      if (bool1) {
        
        if (-1 == this.valueLength) {
          object = DDC.convertStreamToObject(PLPInputStream.makeStream(paramTDSReader, paramInputStreamGetterArgs, this), paramTypeInfo, JDBCType.VARBINARY, paramInputStreamGetterArgs);

        
        }
        else {

          
          object = DDC.convertStreamToObject(new SimpleInputStream(paramTDSReader, this.valueLength, paramInputStreamGetterArgs, this), paramTypeInfo, JDBCType.VARBINARY, paramInputStreamGetterArgs);
        } 




        
        if (aeLogger.isLoggable(Level.FINE))
        {
          aeLogger.fine("Encrypted data is retrieved.");
        }

        
        if (object instanceof SimpleInputStream) {
          throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), null);
        }


        
        arrayOfByte = SQLServerSecurityUtility.decryptWithKey((byte[])object, paramCryptoMetadata, sQLServerConnection);
        return denormalizedValue(arrayOfByte, paramJDBCType, paramCryptoMetadata.baseTypeInfo, sQLServerConnection, paramInputStreamGetterArgs, paramCryptoMetadata.normalizationRuleVersion, paramCalendar);
      } 
      
      switch (sSType) {


        
        case VARCHARMAX:
        case NVARCHARMAX:
        case VARBINARYMAX:
        case UDT:
          object = DDC.convertStreamToObject(PLPInputStream.makeStream(paramTDSReader, paramInputStreamGetterArgs, this), paramTypeInfo, paramJDBCType, paramInputStreamGetterArgs);
          break;






        
        case XML:
          object = DDC.convertStreamToObject((paramJDBCType.isBinary() || paramJDBCType == JDBCType.SQLXML) ? PLPXMLInputStream.makeXMLStream(paramTDSReader, paramInputStreamGetterArgs, this) : PLPInputStream.makeStream(paramTDSReader, paramInputStreamGetterArgs, this), paramTypeInfo, paramJDBCType, paramInputStreamGetterArgs);
          break;










        
        case CHAR:
        case VARCHAR:
        case NCHAR:
        case NVARCHAR:
        case BINARY:
        case VARBINARY:
        case TEXT:
        case NTEXT:
        case IMAGE:
        case TIMESTAMP:
          object = DDC.convertStreamToObject(new SimpleInputStream(paramTDSReader, this.valueLength, paramInputStreamGetterArgs, this), paramTypeInfo, paramJDBCType, paramInputStreamGetterArgs);
          break;







        
        case BIT:
        case TINYINT:
        case SMALLINT:
        case INTEGER:
        case BIGINT:
          switch (this.valueLength) {
            
            case 8:
              object = DDC.convertLongToObject(paramTDSReader.readLong(), paramJDBCType, sSType, paramInputStreamGetterArgs.streamType);
              break;




            
            case 4:
              object = DDC.convertIntegerToObject(paramTDSReader.readInt(), this.valueLength, paramJDBCType, paramInputStreamGetterArgs.streamType);
              break;




            
            case 2:
              object = DDC.convertIntegerToObject(paramTDSReader.readShort(), this.valueLength, paramJDBCType, paramInputStreamGetterArgs.streamType);
              break;




            
            case 1:
              object = DDC.convertIntegerToObject(paramTDSReader.readUnsignedByte(), this.valueLength, paramJDBCType, paramInputStreamGetterArgs.streamType);
              break;
          } 




          
          assert false : "Unexpected valueLength" + this.valueLength;
          break;




        
        case NUMERIC:
        case DECIMAL:
          object = paramTDSReader.readDecimal(this.valueLength, paramTypeInfo, paramJDBCType, paramInputStreamGetterArgs.streamType);
          break;





        
        case SMALLMONEY:
        case MONEY:
          object = paramTDSReader.readMoney(this.valueLength, paramJDBCType, paramInputStreamGetterArgs.streamType);
          break;




        
        case FLOAT:
          object = paramTDSReader.readFloat(this.valueLength, paramJDBCType, paramInputStreamGetterArgs.streamType);
          break;




        
        case REAL:
          object = paramTDSReader.readReal(this.valueLength, paramJDBCType, paramInputStreamGetterArgs.streamType);
          break;




        
        case SMALLDATETIME:
        case DATETIME:
          object = paramTDSReader.readDateTime(this.valueLength, paramCalendar, paramJDBCType, paramInputStreamGetterArgs.streamType);
          break;





        
        case DATE:
          object = paramTDSReader.readDate(this.valueLength, paramCalendar, paramJDBCType);
          break;




        
        case TIME:
          object = paramTDSReader.readTime(this.valueLength, paramTypeInfo, paramCalendar, paramJDBCType);
          break;





        
        case DATETIME2:
          object = paramTDSReader.readDateTime2(this.valueLength, paramTypeInfo, paramCalendar, paramJDBCType);
          break;





        
        case DATETIMEOFFSET:
          object = paramTDSReader.readDateTimeOffset(this.valueLength, paramTypeInfo, paramJDBCType);
          break;




        
        case GUID:
          object = paramTDSReader.readGUID(this.valueLength, paramJDBCType, paramInputStreamGetterArgs.streamType);
          break;




        
        default:
          assert false : "Unexpected SSType " + paramTypeInfo.getSSType();
          break;
      } 

    
    } 
    assert this.isNull || null != object;
    return object;
  }


  
  Object getSetterValue() {
    assert false;
    return null;
  }



  
  private long readNanosSinceMidnightAE(byte[] paramArrayOfbyte, int paramInt, SSType paramSSType) throws SQLServerException {
    long l = 0L;
    for (byte b = 0; b < paramArrayOfbyte.length; b++) {
      l |= (paramArrayOfbyte[b] & 0xFFL) << 8 * b;
    }
    if (0L > l || l >= 864000000000L) {
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_NormalizationErrorAE"));
      throw new SQLServerException(messageFormat.format(new Object[] { paramSSType }, ), null, 0, null);
    } 
    
    return 100L * l;
  }
  
  private int getDaysIntoCE(byte[] paramArrayOfbyte, SSType paramSSType) throws SQLServerException {
    int i = 0;
    for (byte b = 0; b < paramArrayOfbyte.length; b++) {
      i |= (paramArrayOfbyte[b] & 0xFF) << 8 * b;
    }
    
    if (i < 0) {
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_NormalizationErrorAE"));
      
      throw new SQLServerException(messageFormat.format(new Object[] { paramSSType }, ), null, 0, null);
    } 

    
    return i;
  }
}
