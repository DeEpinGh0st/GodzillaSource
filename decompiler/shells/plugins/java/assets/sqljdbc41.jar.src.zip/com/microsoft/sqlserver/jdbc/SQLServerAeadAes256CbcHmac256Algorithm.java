package com.microsoft.sqlserver.jdbc;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.MessageFormat;
import java.util.logging.Logger;
import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;













class SQLServerAeadAes256CbcHmac256Algorithm
  extends SQLServerEncryptionAlgorithm
{
  private static final Logger aeLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.SQLServerAeadAes256CbcHmac256Algorithm");

  
  static final String algorithmName = "AEAD_AES_256_CBC_HMAC_SHA256";
  
  private SQLServerAeadAes256CbcHmac256EncryptionKey columnEncryptionkey;
  
  private byte algorithmVersion;
  
  private boolean isDeterministic = false;
  
  private int blockSizeInBytes = 16;
  private int keySizeInBytes = 32;
  private byte[] version = new byte[] { 1 };
  
  private byte[] versionSize = new byte[] { 1 };




  
  private int minimumCipherTextLengthInBytesNoAuthenticationTag = 1 + this.blockSizeInBytes + this.blockSizeInBytes;




  
  private int minimumCipherTextLengthInBytesWithAuthenticationTag = this.minimumCipherTextLengthInBytesNoAuthenticationTag + this.keySizeInBytes;

















  
  SQLServerAeadAes256CbcHmac256Algorithm(SQLServerAeadAes256CbcHmac256EncryptionKey paramSQLServerAeadAes256CbcHmac256EncryptionKey, SQLServerEncryptionType paramSQLServerEncryptionType, byte paramByte) {
    this.columnEncryptionkey = paramSQLServerAeadAes256CbcHmac256EncryptionKey;
    
    if (paramSQLServerEncryptionType == SQLServerEncryptionType.Deterministic)
    {
      this.isDeterministic = true;
    }
    this.algorithmVersion = paramByte;
    this.version[0] = paramByte;
  }


  
  byte[] encryptData(byte[] paramArrayOfbyte) throws SQLServerException {
    return encryptData(paramArrayOfbyte, true);
  }







  
  protected byte[] encryptData(byte[] paramArrayOfbyte, boolean paramBoolean) throws SQLServerException {
    aeLogger.entering(SQLServerAeadAes256CbcHmac256Algorithm.class.getName(), Thread.currentThread().getStackTrace()[1].getMethodName(), "Encrypting data.");

    
    assert paramArrayOfbyte != null;
    byte[] arrayOfByte1 = new byte[this.blockSizeInBytes];
    
    SecretKeySpec secretKeySpec = new SecretKeySpec(this.columnEncryptionkey.getEncryptionKey(), "AES");

    
    if (this.isDeterministic) {

      
      try {
        
        arrayOfByte1 = SQLServerSecurityUtility.getHMACWithSHA256(paramArrayOfbyte, this.columnEncryptionkey.getIVKey(), this.blockSizeInBytes);


      
      }
      catch (InvalidKeyException|NoSuchAlgorithmException invalidKeyException) {
        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_EncryptionFailed"));
        
        Object[] arrayOfObject = { invalidKeyException.getMessage() };
        throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
      } 
    } else {
      SecureRandom secureRandom = new SecureRandom();
      secureRandom.nextBytes(arrayOfByte1);
    } 

    
    int i = paramArrayOfbyte.length / this.blockSizeInBytes + 1;
    
    byte b1 = 1;
    byte b2 = paramBoolean ? this.keySizeInBytes : 0;
    int j = b1 + b2;
    int k = j + this.blockSizeInBytes;

    
    int m = 1 + b2 + arrayOfByte1.length + i * this.blockSizeInBytes;
    byte[] arrayOfByte2 = new byte[m];

    
    arrayOfByte2[0] = this.algorithmVersion;
    
    System.arraycopy(arrayOfByte1, 0, arrayOfByte2, j, arrayOfByte1.length);



    
    try {
      IvParameterSpec ivParameterSpec = new IvParameterSpec(arrayOfByte1);
      Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
      cipher.init(1, secretKeySpec, ivParameterSpec);
      
      int n = 0;
      int i1 = k;
      
      if (i > 1) {
        n = (i - 1) * this.blockSizeInBytes;
        i1 += cipher.update(paramArrayOfbyte, 0, n, arrayOfByte2, i1);
      } 
      
      byte[] arrayOfByte = cipher.doFinal(paramArrayOfbyte, n, paramArrayOfbyte.length - n);
      
      System.arraycopy(arrayOfByte, 0, arrayOfByte2, i1, arrayOfByte.length);
      
      if (paramBoolean)
      {
        Mac mac = Mac.getInstance("HmacSHA256");
        SecretKeySpec secretKeySpec1 = new SecretKeySpec(this.columnEncryptionkey.getMacKey(), "HmacSHA256");
        mac.init(secretKeySpec1);
        mac.update(this.version, 0, this.version.length);
        mac.update(arrayOfByte1, 0, arrayOfByte1.length);
        mac.update(arrayOfByte2, k, i * this.blockSizeInBytes);
        mac.update(this.versionSize, 0, this.version.length);
        byte[] arrayOfByte3 = mac.doFinal();
        
        System.arraycopy(arrayOfByte3, 0, arrayOfByte2, b1, b2);
      }
    
    } catch (NoSuchAlgorithmException|java.security.InvalidAlgorithmParameterException|InvalidKeyException|javax.crypto.NoSuchPaddingException|javax.crypto.IllegalBlockSizeException|javax.crypto.BadPaddingException|javax.crypto.ShortBufferException noSuchAlgorithmException) {







      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_EncryptionFailed"));
      
      Object[] arrayOfObject = { noSuchAlgorithmException.getMessage() };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    } 
    
    aeLogger.exiting(SQLServerAeadAes256CbcHmac256Algorithm.class.getName(), Thread.currentThread().getStackTrace()[1].getMethodName(), "Data encrypted.");
    return arrayOfByte2;
  }



  
  byte[] decryptData(byte[] paramArrayOfbyte) throws SQLServerException {
    return decryptData(paramArrayOfbyte, true);
  }








  
  private byte[] decryptData(byte[] paramArrayOfbyte, boolean paramBoolean) throws SQLServerException {
    assert paramArrayOfbyte != null;
    
    byte[] arrayOfByte = new byte[this.blockSizeInBytes];
    
    int i = paramBoolean ? this.minimumCipherTextLengthInBytesWithAuthenticationTag : this.minimumCipherTextLengthInBytesNoAuthenticationTag;


    
    if (paramArrayOfbyte.length < i) {
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidCipherTextSize"));
      Object[] arrayOfObject = { Integer.valueOf(paramArrayOfbyte.length), Integer.valueOf(i) };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    } 


    
    int j = 0;
    if (paramArrayOfbyte[j] != this.algorithmVersion) {
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidAlgorithmVersion"));
      
      Object[] arrayOfObject = { String.format("%02X ", new Object[] { Byte.valueOf(paramArrayOfbyte[j]) }), String.format("%02X ", new Object[] { Byte.valueOf(this.algorithmVersion) }) };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    } 

    
    j++;
    int k = 0;

    
    if (paramBoolean) {
      k = j;
      
      j += this.keySizeInBytes;
    } 

    
    System.arraycopy(paramArrayOfbyte, j, arrayOfByte, 0, arrayOfByte.length);
    j += arrayOfByte.length;

    
    int m = j;
    
    int n = paramArrayOfbyte.length - j;
    
    if (paramBoolean) {
      byte[] arrayOfByte1;
      
      try {
        arrayOfByte1 = prepareAuthenticationTag(arrayOfByte, paramArrayOfbyte, m, n);
      }
      catch (InvalidKeyException|NoSuchAlgorithmException invalidKeyException) {
        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_DecryptionFailed"));
        
        Object[] arrayOfObject = { invalidKeyException.getMessage() };
        throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
      } 
      
      if (!SQLServerSecurityUtility.compareBytes(arrayOfByte1, paramArrayOfbyte, k, n))
      {
        throw new SQLServerException(this, SQLServerException.getErrString("R_InvalidAuthenticationTag"), null, 0, false);
      }
    } 



    
    return decryptData(arrayOfByte, paramArrayOfbyte, m, n);
  }









  
  private byte[] decryptData(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt1, int paramInt2) throws SQLServerException {
    aeLogger.entering(SQLServerAeadAes256CbcHmac256Algorithm.class.getName(), Thread.currentThread().getStackTrace()[1].getMethodName(), "Decrypting data.");
    assert paramArrayOfbyte2 != null;
    assert paramArrayOfbyte1 != null;
    byte[] arrayOfByte = null;
    
    SecretKeySpec secretKeySpec = new SecretKeySpec(this.columnEncryptionkey.getEncryptionKey(), "AES");
    
    IvParameterSpec ivParameterSpec = new IvParameterSpec(paramArrayOfbyte1);


    
    try {
      Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
      cipher.init(2, secretKeySpec, ivParameterSpec);
      arrayOfByte = cipher.doFinal(paramArrayOfbyte2, paramInt1, paramInt2);
    }
    catch (NoSuchAlgorithmException|java.security.InvalidAlgorithmParameterException|InvalidKeyException|javax.crypto.NoSuchPaddingException|javax.crypto.IllegalBlockSizeException|javax.crypto.BadPaddingException noSuchAlgorithmException) {







      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_DecryptionFailed"));
      
      Object[] arrayOfObject = { noSuchAlgorithmException.getMessage() };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    } 
    
    aeLogger.exiting(SQLServerAeadAes256CbcHmac256Algorithm.class.getName(), Thread.currentThread().getStackTrace()[1].getMethodName(), "Data decrypted.");
    return arrayOfByte;
  }












  
  private byte[] prepareAuthenticationTag(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt1, int paramInt2) throws NoSuchAlgorithmException, InvalidKeyException {
    assert paramArrayOfbyte2 != null;
    
    byte[] arrayOfByte2 = new byte[this.keySizeInBytes];
    
    Mac mac = Mac.getInstance("HmacSHA256");
    SecretKeySpec secretKeySpec = new SecretKeySpec(this.columnEncryptionkey.getMacKey(), "HmacSHA256");
    
    mac.init(secretKeySpec);
    mac.update(this.version, 0, this.version.length);
    mac.update(paramArrayOfbyte1, 0, paramArrayOfbyte1.length);
    mac.update(paramArrayOfbyte2, paramInt1, paramInt2);
    mac.update(this.versionSize, 0, this.version.length);
    byte[] arrayOfByte1 = mac.doFinal();
    System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, arrayOfByte2.length);


    
    return arrayOfByte2;
  }
}
