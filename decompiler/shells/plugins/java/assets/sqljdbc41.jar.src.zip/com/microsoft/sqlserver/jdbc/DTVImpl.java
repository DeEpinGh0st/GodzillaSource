package com.microsoft.sqlserver.jdbc;

import java.util.Calendar;

abstract class DTVImpl {
  abstract void setValue(DTV paramDTV, SQLCollation paramSQLCollation, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, StreamSetterArgs paramStreamSetterArgs, Calendar paramCalendar, Integer paramInteger, SQLServerConnection paramSQLServerConnection, boolean paramBoolean) throws SQLServerException;
  
  abstract void setValue(Object paramObject, JavaType paramJavaType);
  
  abstract void setStreamSetterArgs(StreamSetterArgs paramStreamSetterArgs);
  
  abstract void setCalendar(Calendar paramCalendar);
  
  abstract void setScale(Integer paramInteger);
  
  abstract void setForceEncrypt(boolean paramBoolean);
  
  abstract StreamSetterArgs getStreamSetterArgs();
  
  abstract Calendar getCalendar();
  
  abstract Integer getScale();
  
  abstract boolean isNull();
  
  abstract void setJdbcType(JDBCType paramJDBCType);
  
  abstract JDBCType getJdbcType();
  
  abstract JavaType getJavaType();
  
  abstract Object getValue(DTV paramDTV, JDBCType paramJDBCType, int paramInt, InputStreamGetterArgs paramInputStreamGetterArgs, Calendar paramCalendar, TypeInfo paramTypeInfo, CryptoMetadata paramCryptoMetadata, TDSReader paramTDSReader) throws SQLServerException;
  
  abstract Object getSetterValue();
  
  abstract void skipValue(TypeInfo paramTypeInfo, TDSReader paramTDSReader, boolean paramBoolean) throws SQLServerException;
  
  abstract void initFromCompressedNull();
}
