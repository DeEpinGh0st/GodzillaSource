package com.microsoft.sqlserver.jdbc;

import java.util.HashMap;
import java.util.logging.Level;








final class FailoverMapSingleton
{
  private static int INITIALHASHMAPSIZE = 5;
  private static HashMap<String, FailoverInfo> failoverMap = new HashMap<>(INITIALHASHMAPSIZE);

  
  private static String concatPrimaryDatabase(String paramString1, String paramString2, String paramString3) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString1);
    if (null != paramString2) {
      
      stringBuilder.append("\\");
      stringBuilder.append(paramString2);
    } 
    stringBuilder.append(";");
    stringBuilder.append(paramString3);
    return stringBuilder.toString();
  }
  
  static FailoverInfo getFailoverInfo(SQLServerConnection paramSQLServerConnection, String paramString1, String paramString2, String paramString3) {
    synchronized (FailoverMapSingleton.class) {
      
      if (true == failoverMap.isEmpty())
      {
        return null;
      }

      
      String str = concatPrimaryDatabase(paramString1, paramString2, paramString3);
      if (paramSQLServerConnection.getConnectionLogger().isLoggable(Level.FINER))
        paramSQLServerConnection.getConnectionLogger().finer(paramSQLServerConnection.toString() + " Looking up info in the map using key: " + str); 
      FailoverInfo failoverInfo = failoverMap.get(str);
      if (null != failoverInfo)
        failoverInfo.log(paramSQLServerConnection); 
      return failoverInfo;
    } 
  }







  
  static void putFailoverInfo(SQLServerConnection paramSQLServerConnection, String paramString1, String paramString2, String paramString3, FailoverInfo paramFailoverInfo, boolean paramBoolean, String paramString4) throws SQLServerException {
    synchronized (FailoverMapSingleton.class) {
      FailoverInfo failoverInfo;
      
      if (null == (failoverInfo = getFailoverInfo(paramSQLServerConnection, paramString1, paramString2, paramString3))) {
        
        if (paramSQLServerConnection.getConnectionLogger().isLoggable(Level.FINE)) {
          paramSQLServerConnection.getConnectionLogger().fine(paramSQLServerConnection.toString() + " Failover map add server: " + paramString1 + "; database:" + paramString3 + "; Mirror:" + paramString4);
        }
        failoverMap.put(concatPrimaryDatabase(paramString1, paramString2, paramString3), paramFailoverInfo);
      }
      else {
        
        failoverInfo.failoverAdd(paramSQLServerConnection, paramBoolean, paramString4);
      } 
    } 
  }
}
