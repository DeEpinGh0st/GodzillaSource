package com.microsoft.sqlserver.jdbc;






class FedAuthDllInfo
{
  byte[] accessTokenBytes = null;
  long expiresIn = 0L;
  
  FedAuthDllInfo(byte[] paramArrayOfbyte, long paramLong) {
    this.accessTokenBytes = paramArrayOfbyte;
    this.expiresIn = paramLong;
  }
}
