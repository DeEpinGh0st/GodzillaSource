package com.microsoft.sqlserver.jdbc;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.text.MessageFormat;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;






































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































final class SocketFinder
{
  enum Result
  {
    UNKNOWN,
    SUCCESS,
    FAILURE;
  }


  
  private static final ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 2147483647, 5L, TimeUnit.SECONDS, new SynchronousQueue<>());


  
  private static final int minTimeoutForParallelConnections = 1500;

  
  private final Object socketFinderlock = new Object();


  
  private final Object parentThreadLock = new Object();


  
  private volatile Result result = Result.UNKNOWN;


  
  private int noOfSpawnedThreads = 0;


  
  private volatile int noOfThreadsThatNotified = 0;


  
  private volatile Socket selectedSocket = null;


  
  private volatile IOException selectedException = null;

  
  private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SocketFinder");


  
  private final String traceID;

  
  private static final int ipAddressLimit = 64;

  
  private final SQLServerConnection conn;


  
  SocketFinder(String paramString, SQLServerConnection paramSQLServerConnection) {
    this.traceID = "SocketFinder(" + paramString + ")";
    this.conn = paramSQLServerConnection;
  }

















  
  Socket findSocket(String paramString, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt3) throws SQLServerException {
    assert paramInt2 != 0 : "The driver does not allow a time out of 0";

    
    try {
      InetAddress[] arrayOfInetAddress = null;

      
      if (paramBoolean1 || paramBoolean2) {

        
        arrayOfInetAddress = InetAddress.getAllByName(paramString);
        
        if (paramBoolean2 && arrayOfInetAddress.length > 64) {
          
          paramBoolean2 = false;
          paramInt2 = paramInt3;
        } 
      } 
      
      if (!paramBoolean1) {


        
        if (paramBoolean2 && paramBoolean3)
        {
          return getDefaultSocket(paramString, paramInt1, 500);
        }
        if (!paramBoolean2)
        {
          return getDefaultSocket(paramString, paramInt1, paramInt2);
        }
      } 


      
      if (logger.isLoggable(Level.FINER)) {
        
        String str = toString() + " Total no of InetAddresses: " + arrayOfInetAddress.length + ". They are: ";
        for (InetAddress inetAddress : arrayOfInetAddress)
        {
          str = str + inetAddress.toString() + ";";
        }
        
        logger.finer(str);
      } 
      
      if (arrayOfInetAddress.length > 64) {
        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_ipAddressLimitWithMultiSubnetFailover"));
        Object[] arrayOfObject = { Integer.toString(64) };
        String str = messageFormat.format(arrayOfObject);

        
        this.conn.terminate(6, str);
      } 
      
      if (Util.isIBM()) {
        
        paramInt2 = Math.max(paramInt2, 1500);
        if (logger.isLoggable(Level.FINER))
        {
          logger.finer(toString() + "Using Java NIO with timeout:" + paramInt2);
        }
        findSocketUsingJavaNIO(arrayOfInetAddress, paramInt1, paramInt2);
      } else {
        int i;
        
        LinkedList<Inet4Address> linkedList = new LinkedList();
        LinkedList<Inet6Address> linkedList1 = new LinkedList();
        
        for (InetAddress inetAddress : arrayOfInetAddress) {
          
          if (inetAddress instanceof Inet4Address) {
            
            linkedList.add((Inet4Address)inetAddress);
          }
          else {
            
            assert inetAddress instanceof Inet6Address : "Unexpected IP address " + inetAddress.toString();
            linkedList1.add((Inet6Address)inetAddress);
          } 
        } 


        
        if (!linkedList.isEmpty() && !linkedList1.isEmpty()) {
          
          i = Math.max(paramInt2 / 2, 1500);
        } else {
          
          i = Math.max(paramInt2, 1500);
        } 
        if (!linkedList.isEmpty()) {
          
          if (logger.isLoggable(Level.FINER))
          {
            logger.finer(toString() + "Using Java NIO with timeout:" + i);
          }

          
          findSocketUsingJavaNIO(linkedList.<InetAddress>toArray(new InetAddress[0]), paramInt1, i);
        } 
        
        if (!this.result.equals(Result.SUCCESS))
        {
          
          if (!linkedList1.isEmpty()) {

            
            if (linkedList1.size() == 1)
            {
              return getConnectedSocket(linkedList1.get(0), paramInt1, i);
            }
            
            if (logger.isLoggable(Level.FINER))
            {
              logger.finer(toString() + "Using Threading with timeout:" + i);
            }
            
            findSocketUsingThreading(linkedList1, paramInt1, i);
          } 
        }
      } 




      
      if (this.result.equals(Result.UNKNOWN))
      {
        synchronized (this.socketFinderlock) {
          
          if (this.result.equals(Result.UNKNOWN)) {
            
            this.result = Result.FAILURE;
            if (logger.isLoggable(Level.FINER))
            {
              logger.finer(toString() + " The parent thread updated the result to failure");
            }
          } 
        } 
      }




      
      if (this.result.equals(Result.FAILURE))
      {
        if (this.selectedException == null) {
          
          if (logger.isLoggable(Level.FINER))
          {
            logger.finer(toString() + " There is no selectedException. The wait calls timed out before any connect call returned or timed out.");
          }
          String str = SQLServerException.getErrString("R_connectionTimedOut");
          this.selectedException = new IOException(str);
        } 
        throw this.selectedException;
      }
    
    }
    catch (InterruptedException interruptedException) {
      
      close(this.selectedSocket);
      SQLServerException.ConvertConnectExceptionToSQLServerException(paramString, paramInt1, this.conn, interruptedException);
    }
    catch (IOException iOException) {
      
      close(this.selectedSocket);








      
      SQLServerException.ConvertConnectExceptionToSQLServerException(paramString, paramInt1, this.conn, iOException);
    } 

    
    assert this.result.equals(Result.SUCCESS) == true;
    assert this.selectedSocket != null : "Bug in code. Selected Socket cannot be null here.";
    
    return this.selectedSocket;
  }














  
  private void findSocketUsingJavaNIO(InetAddress[] paramArrayOfInetAddress, int paramInt1, int paramInt2) throws IOException {
    assert paramInt2 != 0 : "The timeout cannot be zero";
    assert paramArrayOfInetAddress.length != 0 : "Number of inetAddresses should not be zero in this function";
    
    Selector selector = null;
    LinkedList<SocketChannel> linkedList = new LinkedList();
    SocketChannel socketChannel = null;

    
    try {
      selector = Selector.open();
      
      for (byte b = 0; b < paramArrayOfInetAddress.length; b++) {
        
        SocketChannel socketChannel1 = SocketChannel.open();
        linkedList.add(socketChannel1);

        
        socketChannel1.configureBlocking(false);

        
        byte b1 = 8;
        SelectionKey selectionKey = socketChannel1.register(selector, b1);
        
        socketChannel1.connect(new InetSocketAddress(paramArrayOfInetAddress[b], paramInt1));
        
        if (logger.isLoggable(Level.FINER)) {
          logger.finer(toString() + " initiated connection to address: " + paramArrayOfInetAddress[b] + ", portNumber: " + paramInt1);
        }
      } 
      long l1 = System.currentTimeMillis();
      long l2 = l1 + paramInt2;

      
      int i = paramArrayOfInetAddress.length;

      
      while (true) {
        long l = l2 - l1;
        
        if (l <= 0L || socketChannel != null || i <= 0) {
          break;
        }

        
        int j = selector.select(l);
        
        if (logger.isLoggable(Level.FINER)) {
          logger.finer(toString() + " no of channels ready: " + j);
        }



        
        if (j != 0) {
          
          Set<SelectionKey> set = selector.selectedKeys();
          Iterator<SelectionKey> iterator = set.iterator();
          
          while (iterator.hasNext()) {

            
            SelectionKey selectionKey = iterator.next();
            SocketChannel socketChannel1 = (SocketChannel)selectionKey.channel();
            
            if (logger.isLoggable(Level.FINER)) {
              logger.finer(toString() + " processing the channel :" + socketChannel1);
            }
            boolean bool = false;
            
            try {
              bool = socketChannel1.finishConnect();


              
              assert bool == true : "finishConnect on channel:" + socketChannel1 + " cannot be false";
              
              socketChannel = socketChannel1;
              
              if (logger.isLoggable(Level.FINER)) {
                logger.finer(toString() + " selected the channel :" + socketChannel);
              }
              
              break;
            } catch (IOException iOException) {
              
              if (logger.isLoggable(Level.FINER)) {
                logger.finer(toString() + " the exception: " + iOException.getClass() + " with message: " + iOException.getMessage() + " occured while processing the channel: " + socketChannel1);
              }
              
              updateSelectedException(iOException, toString());

              
              socketChannel1.close();


              
              selectionKey.cancel();
              iterator.remove();
              i--;
            } 
          } 
        } 
        l1 = System.currentTimeMillis();
      }
    
    } catch (IOException iOException) {



      
      close(socketChannel);
      throw iOException;


    
    }
    finally {



      
      close(selector);






      
      for (SocketChannel socketChannel1 : linkedList) {
        
        if (socketChannel1 != socketChannel)
        {
          close(socketChannel1);
        }
      } 
    } 

    
    if (socketChannel != null) {


      
      socketChannel.configureBlocking(true);
      this.selectedSocket = socketChannel.socket();
      this.result = Result.SUCCESS;
    } 
  }












  
  private Socket getDefaultSocket(String paramString, int paramInt1, int paramInt2) throws IOException {
    InetSocketAddress inetSocketAddress = new InetSocketAddress(paramString, paramInt1);
    return getConnectedSocket(inetSocketAddress, paramInt2);
  }

  
  private Socket getConnectedSocket(InetAddress paramInetAddress, int paramInt1, int paramInt2) throws IOException {
    InetSocketAddress inetSocketAddress = new InetSocketAddress(paramInetAddress, paramInt1);
    return getConnectedSocket(inetSocketAddress, paramInt2);
  }

  
  private Socket getConnectedSocket(InetSocketAddress paramInetSocketAddress, int paramInt) throws IOException {
    assert paramInt != 0 : "timeout cannot be zero";
    if (paramInetSocketAddress.isUnresolved())
      throw new UnknownHostException(); 
    this.selectedSocket = new Socket();
    this.selectedSocket.connect(paramInetSocketAddress, paramInt);
    return this.selectedSocket;
  }

  
  private void findSocketUsingThreading(LinkedList<Inet6Address> paramLinkedList, int paramInt1, int paramInt2) throws IOException, InterruptedException {
    assert paramInt2 != 0 : "The timeout cannot be zero";
    assert !paramLinkedList.isEmpty() : "Number of inetAddresses should not be zero in this function";
    
    LinkedList<Socket> linkedList = new LinkedList();
    LinkedList<SocketConnector> linkedList1 = new LinkedList();



    
    try {
      this.noOfSpawnedThreads = paramLinkedList.size();
      for (InetAddress inetAddress : paramLinkedList) {
        
        Socket socket = new Socket();
        linkedList.add(socket);
        
        InetSocketAddress inetSocketAddress = new InetSocketAddress(inetAddress, paramInt1);
        
        SocketConnector socketConnector = new SocketConnector(socket, inetSocketAddress, paramInt2, this);
        linkedList1.add(socketConnector);
      } 

      
      synchronized (this.parentThreadLock)
      {
        for (SocketConnector socketConnector : linkedList1)
        {
          threadPoolExecutor.execute(socketConnector);
        }
        
        long l1 = System.currentTimeMillis();
        long l2 = l1 + paramInt2;


        
        while (true) {
          long l = l2 - l1;
          
          if (logger.isLoggable(Level.FINER))
          {
            logger.finer(toString() + " TimeRemaining:" + l + "; Result:" + this.result + "; Max. open thread count: " + threadPoolExecutor.getLargestPoolSize() + "; Current open thread count:" + threadPoolExecutor.getActiveCount());
          }











          
          if (l <= 0L || !this.result.equals(Result.UNKNOWN)) {
            break;
          }
          this.parentThreadLock.wait(l);
          
          if (logger.isLoggable(Level.FINER))
          {
            logger.finer(toString() + " The parent thread wokeup.");
          }

          
          l1 = System.currentTimeMillis();


        
        }


      
      }


    
    }
    finally {


      
      for (Socket socket : linkedList) {
        
        if (socket != this.selectedSocket)
        {
          close(socket);
        }
      } 
    } 
  }






  
  Result getResult() {
    return this.result;
  }

  
  void close(Selector paramSelector) {
    if (null != paramSelector) {
      
      if (logger.isLoggable(Level.FINER)) {
        logger.finer(toString() + ": Closing Selector");
      }
      
      try {
        paramSelector.close();
      }
      catch (IOException iOException) {
        
        if (logger.isLoggable(Level.FINE)) {
          logger.log(Level.FINE, toString() + ": Ignored the following error while closing Selector", iOException);
        }
      } 
    } 
  }
  
  void close(Socket paramSocket) {
    if (null != paramSocket) {
      
      if (logger.isLoggable(Level.FINER)) {
        logger.finer(toString() + ": Closing TCP socket:" + paramSocket);
      }
      
      try {
        paramSocket.close();
      }
      catch (IOException iOException) {
        
        if (logger.isLoggable(Level.FINE)) {
          logger.log(Level.FINE, toString() + ": Ignored the following error while closing socket", iOException);
        }
      } 
    } 
  }
  
  void close(SocketChannel paramSocketChannel) {
    if (null != paramSocketChannel) {
      
      if (logger.isLoggable(Level.FINER)) {
        logger.finer(toString() + ": Closing TCP socket channel:" + paramSocketChannel);
      }
      
      try {
        paramSocketChannel.close();
      }
      catch (IOException iOException) {
        
        if (logger.isLoggable(Level.FINE)) {
          logger.log(Level.FINE, toString() + "Ignored the following error while closing socketChannel", iOException);
        }
      } 
    } 
  }














  
  void updateResult(Socket paramSocket, IOException paramIOException, String paramString) {
    if (this.result.equals(Result.UNKNOWN)) {
      
      if (logger.isLoggable(Level.FINER))
      {
        logger.finer("The following child thread is waiting for socketFinderLock:" + paramString);
      }
      
      synchronized (this.socketFinderlock) {
        
        if (logger.isLoggable(Level.FINER))
        {
          logger.finer("The following child thread acquired socketFinderLock:" + paramString);
        }
        
        if (this.result.equals(Result.UNKNOWN)) {


          
          if (paramIOException == null && this.selectedSocket == null) {
            
            this.selectedSocket = paramSocket;
            this.result = Result.SUCCESS;
            if (logger.isLoggable(Level.FINER))
            {
              logger.finer("The socket of the following thread has been chosen:" + paramString);
            }
          } 

          
          if (paramIOException != null)
          {
            updateSelectedException(paramIOException, paramString);
          }
        } 
        
        this.noOfThreadsThatNotified++;


        
        if (this.noOfThreadsThatNotified >= this.noOfSpawnedThreads && this.result.equals(Result.UNKNOWN))
        {
          
          this.result = Result.FAILURE;
        }
        
        if (!this.result.equals(Result.UNKNOWN)) {






















          
          if (logger.isLoggable(Level.FINER))
          {
            logger.finer("The following child thread is waiting for parentThreadLock:" + paramString);
          }
          
          synchronized (this.parentThreadLock) {
            
            if (logger.isLoggable(Level.FINER))
            {
              logger.finer("The following child thread acquired parentThreadLock:" + paramString);
            }
            
            this.parentThreadLock.notify();
          } 
          
          if (logger.isLoggable(Level.FINER))
          {
            logger.finer("The following child thread released parentThreadLock and notified the parent thread:" + paramString);
          }
        } 
      } 
      
      if (logger.isLoggable(Level.FINER))
      {
        logger.finer("The following child thread released socketFinderLock:" + paramString);
      }
    } 
  }









  
  public void updateSelectedException(IOException paramIOException, String paramString) {
    boolean bool = false;
    if (this.selectedException == null) {
      
      this.selectedException = paramIOException;
      bool = true;
    }
    else if (!(paramIOException instanceof java.net.SocketTimeoutException) && this.selectedException instanceof java.net.SocketTimeoutException) {
      
      this.selectedException = paramIOException;
      bool = true;
    } 
    
    if (bool)
    {
      if (logger.isLoggable(Level.FINER))
      {
        logger.finer("The selected exception is updated to the following: ExceptionType:" + paramIOException.getClass() + "; ExceptionMessage:" + paramIOException.getMessage() + "; by the following thread:" + paramString);
      }
    }
  }






  
  public String toString() {
    return this.traceID;
  }
}
