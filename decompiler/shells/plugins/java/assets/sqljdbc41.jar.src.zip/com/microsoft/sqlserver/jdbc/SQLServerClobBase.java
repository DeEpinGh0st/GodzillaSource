package com.microsoft.sqlserver.jdbc;

import java.io.BufferedInputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.sql.Clob;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;



































abstract class SQLServerClobBase
  implements Serializable
{
  private String value;
  private final SQLCollation sqlCollation;
  private boolean isClosed = false;
  private ArrayList<Closeable> activeStreams = new ArrayList<>(1);
  
  SQLServerConnection con;
  private final Logger logger;
  private final String traceID = getClass().getName().substring(1 + getClass().getName().lastIndexOf('.')) + ":" + nextInstanceID();
  
  public final String toString() {
    return this.traceID;
  }
  private static int baseID = 0;

  
  private static synchronized int nextInstanceID() {
    baseID++;
    return baseID;
  }

  
  abstract JDBCType getJdbcType();
  
  private String getDisplayClassName() {
    String str = getJdbcType().className();
    return str.substring(1 + str.lastIndexOf('.'));
  }






  
  SQLServerClobBase(SQLServerConnection paramSQLServerConnection, String paramString, SQLCollation paramSQLCollation, Logger paramLogger) {
    this.con = paramSQLServerConnection;
    this.value = paramString;
    this.sqlCollation = paramSQLCollation;
    this.logger = paramLogger;
    
    if (paramLogger.isLoggable(Level.FINE)) {
      
      String str = (null != paramSQLServerConnection) ? paramSQLServerConnection.toString() : "null connection";
      paramLogger.fine(toString() + " created by (" + str + ")");
    } 
  }








  
  public void free() throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    
    if (!this.isClosed) {

      
      if (null != this.activeStreams) {
        
        for (Closeable closeable : this.activeStreams) {

          
          try {
            closeable.close();
          }
          catch (IOException iOException) {
            
            this.logger.fine(toString() + " ignored IOException closing stream " + closeable + ": " + iOException.getMessage());
          } 
        } 
        this.activeStreams = null;
      } 

      
      this.value = null;
      
      this.isClosed = true;
    } 
  }




  
  private final void checkClosed() throws SQLServerException {
    if (this.isClosed) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_isFreed"));
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(new Object[] { getDisplayClassName() }, ), null, true);
    } 
  }





  
  public InputStream getAsciiStream() throws SQLException {
    BufferedInputStream bufferedInputStream;
    checkClosed();
    
    if (null != this.sqlCollation && !this.sqlCollation.supportsAsciiConversion()) {
      DataTypes.throwConversionError(getDisplayClassName(), "AsciiStream");
    }


    
    try {
      bufferedInputStream = new BufferedInputStream(new ReaderInputStream(new StringReader(this.value), "US-ASCII", this.value.length()));
    }
    catch (UnsupportedEncodingException unsupportedEncodingException) {
      
      throw new SQLServerException(unsupportedEncodingException.getMessage(), null, 0, unsupportedEncodingException);
    } 
    
    this.activeStreams.add(bufferedInputStream);
    return bufferedInputStream;
  }







  
  public Reader getCharacterStream() throws SQLException {
    checkClosed();
    
    StringReader stringReader = new StringReader(this.value);
    this.activeStreams.add(stringReader);
    return stringReader;
  }

  
  public Reader getCharacterStream(long paramLong1, long paramLong2) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();

    
    throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
  }










  
  public String getSubString(long paramLong, int paramInt) throws SQLException {
    checkClosed();
    
    if (paramLong < 1L) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
      Object[] arrayOfObject = { new Long(paramLong) };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
    } 
    
    if (paramInt < 0) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
      Object[] arrayOfObject = { new Integer(paramInt) };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
    } 

    
    paramLong--;

    
    if (paramLong > this.value.length()) {
      paramLong = this.value.length();
    }

    
    if (paramInt > this.value.length() - paramLong) {
      paramInt = (int)(this.value.length() - paramLong);
    }
    
    return this.value.substring((int)paramLong, (int)paramLong + paramInt);
  }






  
  public long length() throws SQLException {
    checkClosed();
    
    return this.value.length();
  }










  
  public long position(Clob paramClob, long paramLong) throws SQLException {
    checkClosed();
    
    if (paramLong < 1L) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
      Object[] arrayOfObject = { new Long(paramLong) };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
    } 
    
    if (null == paramClob) {
      return -1L;
    }
    return position(paramClob.getSubString(1L, (int)paramClob.length()), paramLong);
  }











  
  public long position(String paramString, long paramLong) throws SQLException {
    checkClosed();
    
    if (paramLong < 1L) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
      Object[] arrayOfObject = { new Long(paramLong) };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
    } 


    
    if (null == paramString) {
      return -1L;
    }
    int i = this.value.indexOf(paramString, (int)(paramLong - 1L));
    if (-1 != i) {
      return (i + 1);
    }
    return -1L;
  }








  
  public void truncate(long paramLong) throws SQLException {
    checkClosed();
    
    if (paramLong < 0L) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
      Object[] arrayOfObject = { new Long(paramLong) };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
    } 
    
    if (paramLong <= 2147483647L && this.value.length() > paramLong) {
      this.value = this.value.substring(0, (int)paramLong);
    }
  }







  
  public OutputStream setAsciiStream(long paramLong) throws SQLException {
    checkClosed();
    
    if (paramLong < 1L) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
      Object[] arrayOfObject = { new Long(paramLong) };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
    } 
    
    return new SQLServerClobAsciiOutputStream(this, paramLong);
  }








  
  public Writer setCharacterStream(long paramLong) throws SQLException {
    checkClosed();
    
    if (paramLong < 1L) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
      Object[] arrayOfObject = { new Long(paramLong) };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
    } 
    
    return new SQLServerClobWriter(this, paramLong);
  }









  
  public int setString(long paramLong, String paramString) throws SQLException {
    checkClosed();
    
    if (null == paramString) {
      SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_cantSetNull"), null, true);
    }
    return setString(paramLong, paramString, 0, paramString.length());
  }


















  
  public int setString(long paramLong, String paramString, int paramInt1, int paramInt2) throws SQLException {
    checkClosed();
    
    if (null == paramString) {
      SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_cantSetNull"), null, true);
    }
    
    if (paramInt1 < 0 || paramInt1 > paramString.length()) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidOffset"));
      Object[] arrayOfObject = { new Integer(paramInt1) };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
    } 

    
    if (paramInt2 < 0 || paramInt2 > paramString.length() - paramInt1) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
      Object[] arrayOfObject = { new Integer(paramInt2) };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
    } 



    
    if (paramLong < 1L || paramLong > (this.value.length() + 1)) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
      Object[] arrayOfObject = { new Long(paramLong) };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
    } 

    
    paramLong--;

    
    if (paramInt2 >= this.value.length() - paramLong) {

      
      DataTypes.getCheckedLength(this.con, getJdbcType(), paramLong + paramInt2, false);
      assert paramLong + paramInt2 <= 2147483647L;

      
      StringBuilder stringBuilder = new StringBuilder((int)paramLong + paramInt2);
      stringBuilder.append(this.value.substring(0, (int)paramLong));

      
      stringBuilder.append(paramString.substring(paramInt1, paramInt1 + paramInt2));

      
      this.value = stringBuilder.toString();

    
    }
    else {

      
      StringBuilder stringBuilder = new StringBuilder(this.value.length());
      stringBuilder.append(this.value.substring(0, (int)paramLong));

      
      stringBuilder.append(paramString.substring(paramInt1, paramInt1 + paramInt2));


      
      stringBuilder.append(this.value.substring((int)paramLong + paramInt2));

      
      this.value = stringBuilder.toString();
    } 
    
    return paramInt2;
  }
}
