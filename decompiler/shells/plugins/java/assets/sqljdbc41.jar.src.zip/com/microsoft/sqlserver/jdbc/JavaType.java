package com.microsoft.sqlserver.jdbc;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.NClob;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.EnumMap;
import java.util.EnumSet;
import microsoft.sql.DateTimeOffset;






















































































































































































































































































































































































































































































enum JavaType
{
  INTEGER(Integer.class, JDBCType.INTEGER),
  STRING(String.class, JDBCType.CHAR),
  DATE(Date.class, JDBCType.DATE),
  TIME(Time.class, JDBCType.TIME),
  TIMESTAMP(Timestamp.class, JDBCType.TIMESTAMP),
  UTILDATE(Date.class, JDBCType.TIMESTAMP),
  CALENDAR(Calendar.class, JDBCType.TIMESTAMP),
  LOCALDATE(getJavaClass("LocalDate"), JDBCType.DATE),
  LOCALTIME(getJavaClass("LocalTime"), JDBCType.TIME),
  LOCALDATETIME(getJavaClass("LocalDateTime"), JDBCType.TIMESTAMP),
  OFFSETTIME(getJavaClass("OffsetTime"), JDBCType.TIME_WITH_TIMEZONE),
  OFFSETDATETIME(getJavaClass("OffsetDateTime"), JDBCType.TIMESTAMP_WITH_TIMEZONE),
  DATETIMEOFFSET(DateTimeOffset.class, JDBCType.DATETIMEOFFSET),
  BOOLEAN(Boolean.class, JDBCType.BIT),
  BIGDECIMAL(BigDecimal.class, JDBCType.DECIMAL),
  DOUBLE(Double.class, JDBCType.DOUBLE),
  FLOAT(Float.class, JDBCType.REAL),
  SHORT(Short.class, JDBCType.SMALLINT),
  LONG(Long.class, JDBCType.BIGINT),
  BIGINTEGER(BigInteger.class, JDBCType.BIGINT),
  BYTE(Byte.class, JDBCType.TINYINT),
  BYTEARRAY(byte[].class, JDBCType.BINARY),
  
  NCLOB(NClob.class, JDBCType.NCLOB),
  CLOB(Clob.class, JDBCType.CLOB),
  BLOB(Blob.class, JDBCType.BLOB),
  TVP(TVP.class, JDBCType.TVP),
  
  INPUTSTREAM(InputStream.class, JDBCType.UNKNOWN)
  {
    JDBCType getJDBCType(SSType param1SSType, JDBCType param1JDBCType)
    {
      JDBCType jDBCType;





      
      if (SSType.UNKNOWN != param1SSType) {






        
        switch (param1SSType) {
          
          case CHAR:
          case VARCHAR:
          case VARCHARMAX:
          case TEXT:
          case NCHAR:
          case NVARCHAR:
          case NVARCHARMAX:
          case NTEXT:
            jDBCType = JDBCType.LONGVARCHAR;
            break;

          
          default:
            jDBCType = JDBCType.LONGVARBINARY;
            break;
        } 






      
      } else {
        jDBCType = param1JDBCType.isTextual() ? JDBCType.LONGVARCHAR : JDBCType.LONGVARBINARY;
      } 
      
      assert null != jDBCType;
      return jDBCType;
    }
  },
  
  READER(Reader.class, JDBCType.LONGVARCHAR),
  
  SQLXML(SQLServerSQLXML.class, JDBCType.SQLXML),
  OBJECT(Object.class, JDBCType.UNKNOWN);
  private final Class<?> javaClass;
  
  static {
    jvmVersion = 0.0D;
  }
  private final JDBCType jdbcTypeFromJavaType; private static double jvmVersion;
  JavaType(Class<?> paramClass, JDBCType paramJDBCType) {
    this.javaClass = paramClass;
    this.jdbcTypeFromJavaType = paramJDBCType;
  }

  
  static Class<?> getJavaClass(String paramString) {
    if (0.0D == jvmVersion) {
      
      try {




        
        String str = System.getProperty("java.specification.version");
        if (str != null)
        {
          jvmVersion = Double.parseDouble(str);
        }
      } catch (NumberFormatException numberFormatException) {
        
        jvmVersion = 0.1D;
      } 
    }

    
    if (jvmVersion < 1.8D)
    {
      return TemporalCompatibility.class;
    }
    
    if (paramString.equals("LocalDate"))
    {
      return LocalDate.class;
    }
    if (paramString.equals("LocalTime"))
    {
      return LocalTime.class;
    }
    if (paramString.equals("LocalDateTime"))
    {
      return LocalDateTime.class;
    }
    if (paramString.equals("OffsetTime"))
    {
      return OffsetTime.class;
    }
    if (paramString.equals("OffsetDateTime"))
    {
      return OffsetDateTime.class;
    }
    return TemporalCompatibility.class;
  }

  
  static JavaType of(Object paramObject) {
    if (paramObject instanceof SQLServerDataTable || paramObject instanceof java.sql.ResultSet || paramObject instanceof ISQLServerDataRecord)
      return TVP; 
    if (null != paramObject)
    {
      for (JavaType javaType : values()) {
        if (javaType.javaClass.isInstance(paramObject))
          return javaType; 
      } 
    }
    return OBJECT;
  }






  
  JDBCType getJDBCType(SSType paramSSType, JDBCType paramJDBCType) {
    return this.jdbcTypeFromJavaType;
  }
  
  enum SetterConversionAE
  {
    BIT((String)JavaType.BOOLEAN, EnumSet.of(JDBCType.BIT, JDBCType.TINYINT, JDBCType.SMALLINT, JDBCType.INTEGER, JDBCType.BIGINT)),








    
    SHORT((String)JavaType.SHORT, EnumSet.of(JDBCType.TINYINT, JDBCType.SMALLINT, JDBCType.INTEGER, JDBCType.BIGINT)),







    
    INTEGER((String)JavaType.INTEGER, EnumSet.of(JDBCType.INTEGER, JDBCType.BIGINT)),




    
    LONG((String)JavaType.LONG, EnumSet.of(JDBCType.BIGINT)),




    
    BIGDECIMAL((String)JavaType.BIGDECIMAL, EnumSet.of(JDBCType.MONEY, JDBCType.SMALLMONEY, JDBCType.DECIMAL, JDBCType.NUMERIC)),







    
    BYTE((String)JavaType.BYTE, EnumSet.of(JDBCType.BINARY, JDBCType.VARBINARY, JDBCType.LONGVARBINARY, JDBCType.TINYINT)),







    
    BYTEARRAY((String)JavaType.BYTEARRAY, EnumSet.of(JDBCType.BINARY, JDBCType.VARBINARY, JDBCType.LONGVARBINARY)),






    
    DATE((String)JavaType.DATE, EnumSet.of(JDBCType.DATE)),




    
    DATETIMEOFFSET((String)JavaType.DATETIMEOFFSET, EnumSet.of(JDBCType.DATETIMEOFFSET)),




    
    DOUBLE((String)JavaType.DOUBLE, EnumSet.of(JDBCType.DOUBLE)),




    
    FLOAT((String)JavaType.FLOAT, EnumSet.of(JDBCType.REAL, JDBCType.DOUBLE)),





    
    STRING((String)JavaType.STRING, EnumSet.of(JDBCType.CHAR, new JDBCType[] { JDBCType.VARCHAR, JDBCType.LONGVARCHAR, JDBCType.NCHAR, JDBCType.NVARCHAR, JDBCType.LONGNVARCHAR, JDBCType.GUID









        
        })),
    TIME((String)JavaType.TIME, EnumSet.of(JDBCType.TIME)),




    
    TIMESTAMP((String)JavaType.TIMESTAMP, EnumSet.of(JDBCType.TIME, JDBCType.TIMESTAMP, JDBCType.DATETIME, JDBCType.SMALLDATETIME));





    
    private final EnumSet<JDBCType> to;





    
    private final JavaType from;




    
    private static final EnumMap<JavaType, EnumSet<JDBCType>> setterConversionAEMap = new EnumMap<>(JavaType.class); SetterConversionAE(JavaType param1JavaType, EnumSet<JDBCType> param1EnumSet) {
      this.from = param1JavaType;
      this.to = param1EnumSet;
    }
    static {
      for (JavaType javaType : JavaType.values()) {
        setterConversionAEMap.put(javaType, EnumSet.noneOf(JDBCType.class));
      }
      for (SetterConversionAE setterConversionAE : values()) {
        ((EnumSet<JDBCType>)setterConversionAEMap.get(setterConversionAE.from)).addAll(setterConversionAE.to);
      }
    }
    
    static boolean converts(JavaType param1JavaType, JDBCType param1JDBCType) {
      if (null == param1JavaType || JavaType.OBJECT == param1JavaType)
        return true; 
      if (!setterConversionAEMap.containsKey(param1JavaType))
        return false; 
      return ((EnumSet)setterConversionAEMap.get(param1JavaType)).contains(param1JDBCType);
    }
  }
}
