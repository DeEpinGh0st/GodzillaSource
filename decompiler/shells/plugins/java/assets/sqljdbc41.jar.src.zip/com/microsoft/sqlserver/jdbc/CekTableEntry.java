package com.microsoft.sqlserver.jdbc;

import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;






































class CekTableEntry
{
  private static final Logger aeLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.AE");
  
  Vector<EncryptionKeyInfo> columnEncryptionKeyValues;
  
  int ordinal;
  int databaseId;
  int cekId;
  int cekVersion;
  byte[] cekMdVersion;
  
  Vector<EncryptionKeyInfo> getColumnEncryptionKeyValues() {
    return this.columnEncryptionKeyValues;
  }
  
  int getOrdinal() {
    return this.ordinal;
  }
  
  int getDatabaseId() {
    return this.databaseId;
  }
  
  int getCekId() {
    return this.cekId;
  }
  
  int getCekVersion() {
    return this.cekVersion;
  }
  
  byte[] getCekMdVersion() {
    return this.cekMdVersion;
  }

  
  CekTableEntry(int paramInt) {
    this.ordinal = paramInt;
    this.databaseId = 0;
    this.cekId = 0;
    this.cekVersion = 0;
    this.cekMdVersion = null;
    this.columnEncryptionKeyValues = new Vector<>();
  }
  
  int getSize() {
    return this.columnEncryptionKeyValues.size();
  }

  
  void add(byte[] paramArrayOfbyte1, int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfbyte2, String paramString1, String paramString2, String paramString3) {
    assert null != this.columnEncryptionKeyValues : "columnEncryptionKeyValues should already be initialized.";
    
    if (aeLogger.isLoggable(Level.FINE)) {
      aeLogger.fine("Retrieving CEK values");
    }
    
    EncryptionKeyInfo encryptionKeyInfo = new EncryptionKeyInfo(paramArrayOfbyte1, paramInt1, paramInt2, paramInt3, paramArrayOfbyte2, paramString1, paramString2, paramString3);







    
    this.columnEncryptionKeyValues.add(encryptionKeyInfo);
    
    if (0 == this.databaseId) {
      this.databaseId = paramInt1;
      this.cekId = paramInt2;
      this.cekVersion = paramInt3;
      this.cekMdVersion = paramArrayOfbyte2;
    } else {
      
      assert this.databaseId == paramInt1;
      assert this.cekId == paramInt2;
      assert this.cekVersion == paramInt3;
      assert null != this.cekMdVersion && null != paramArrayOfbyte2 && this.cekMdVersion.length == paramArrayOfbyte2.length;
    } 
  }
}
