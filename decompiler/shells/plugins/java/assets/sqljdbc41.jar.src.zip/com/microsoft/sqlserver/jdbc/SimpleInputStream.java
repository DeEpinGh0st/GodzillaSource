package com.microsoft.sqlserver.jdbc;

import java.io.IOException;
import java.util.logging.Level;
































































































































final class SimpleInputStream
  extends BaseInputStream
{
  private final int payloadLength;
  private byte[] bSingleByte;
  
  SimpleInputStream(TDSReader paramTDSReader, int paramInt, InputStreamGetterArgs paramInputStreamGetterArgs, ServerDTVImpl paramServerDTVImpl) throws SQLServerException {
    super(paramTDSReader, paramInputStreamGetterArgs.isAdaptive, paramInputStreamGetterArgs.isStreaming, paramServerDTVImpl);
    setLoggingInfo(paramInputStreamGetterArgs.logContext);
    this.payloadLength = paramInt;
  }





  
  public void close() throws IOException {
    if (null == this.tdsReader)
      return; 
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + "Enter Closing SimpleInputStream.");
    }


    
    skip((this.payloadLength - this.streamPos));
    
    closeHelper();
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + "Exit Closing SimpleInputStream.");
    }
  }



  
  private final boolean isEOS() throws IOException {
    assert this.streamPos <= this.payloadLength;
    return (this.streamPos == this.payloadLength);
  }








  
  public long skip(long paramLong) throws IOException {
    int i;
    checkClosed();
    if (logger.isLoggable(Level.FINER))
      logger.finer(toString() + " Skipping :" + paramLong); 
    if (paramLong < 0L) return 0L; 
    if (isEOS()) return 0L;

    
    if (this.streamPos + paramLong > this.payloadLength) {
      
      i = this.payloadLength - this.streamPos;
    }
    else {
      
      i = (int)paramLong;
    } 
    
    try {
      this.tdsReader.skip(i);
    }
    catch (SQLServerException sQLServerException) {
      
      throw new IOException(sQLServerException.getMessage());
    } 
    this.streamPos += i;
    if (this.isReadLimitSet && this.streamPos - this.markedStreamPos > this.readLimit) {
      clearCurrentMark();
    }
    return i;
  }








  
  public int available() throws IOException {
    checkClosed();
    assert this.streamPos <= this.payloadLength;
    
    int i = this.payloadLength - this.streamPos;
    if (this.tdsReader.available() < i)
      i = this.tdsReader.available(); 
    return i;
  }







  
  public int read() throws IOException {
    checkClosed();
    if (null == this.bSingleByte)
      this.bSingleByte = new byte[1]; 
    if (isEOS()) return -1; 
    int i = read(this.bSingleByte, 0, 1);
    return (0 == i) ? -1 : (this.bSingleByte[0] & 0xFF);
  }







  
  public int read(byte[] paramArrayOfbyte) throws IOException {
    checkClosed();
    return read(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }









  
  public int read(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
    checkClosed();
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + " Reading " + paramInt2 + " from stream offset " + this.streamPos + " payload length " + this.payloadLength);
    }
    if (paramInt1 < 0 || paramInt2 < 0 || paramInt1 + paramInt2 > paramArrayOfbyte.length) {
      throw new IndexOutOfBoundsException();
    }
    if (0 == paramInt2) return 0; 
    if (isEOS()) return -1;
    
    int i = 0;
    if (this.streamPos + paramInt2 > this.payloadLength) {
      
      i = this.payloadLength - this.streamPos;
    }
    else {
      
      i = paramInt2;
    } 

    
    try {
      this.tdsReader.readBytes(paramArrayOfbyte, paramInt1, i);
    }
    catch (SQLServerException sQLServerException) {
      
      throw new IOException(sQLServerException.getMessage());
    } 
    this.streamPos += i;
    
    if (this.isReadLimitSet && this.streamPos - this.markedStreamPos > this.readLimit) {
      clearCurrentMark();
    }
    return i;
  }





  
  public void mark(int paramInt) {
    if (null != this.tdsReader && paramInt > 0) {
      
      this.currentMark = this.tdsReader.mark();
      this.markedStreamPos = this.streamPos;
      setReadLimit(paramInt);
    } 
  }





  
  public void reset() throws IOException {
    resetHelper();
    this.streamPos = this.markedStreamPos;
  }







  
  final byte[] getBytes() throws SQLServerException {
    assert 0 == this.streamPos;
    
    byte[] arrayOfByte = new byte[this.payloadLength];
    
    try {
      read(arrayOfByte);
      close();
    }
    catch (IOException iOException) {
      
      SQLServerException.makeFromDriverError(null, null, iOException.getMessage(), null, true);
    } 






    
    return arrayOfByte;
  }
}
