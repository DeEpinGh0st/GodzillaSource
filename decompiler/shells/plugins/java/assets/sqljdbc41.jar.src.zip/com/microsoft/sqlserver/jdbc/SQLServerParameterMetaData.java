package com.microsoft.sqlserver.jdbc;

import java.sql.ParameterMetaData;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;












public final class SQLServerParameterMetaData
  implements ParameterMetaData
{
  private static final int SQL_SERVER_2012_VERSION = 11;
  private final SQLServerStatement stmtParent;
  private SQLServerConnection con;
  private Statement stmtCall;
  private SQLServerResultSet rsProcedureMeta;
  private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerParameterMetaData");

  
  private static int baseID = 0;
  private final String traceID = " SQLServerParameterMetaData:" + nextInstanceID();

  
  private static synchronized int nextInstanceID() {
    baseID++;
    return baseID;
  }
  
  public final String toString() {
    return this.traceID;
  }






  
  private String parseColumns(String paramString1, String paramString2) {
    StringTokenizer stringTokenizer = new StringTokenizer(paramString1, " =?<>!", true);




    
    byte b = 0;
    String str = null;
    StringBuilder stringBuilder = new StringBuilder();
    
    while (stringTokenizer.hasMoreTokens()) {

      
      String str1 = stringTokenizer.nextToken();
      if (str1.equalsIgnoreCase(paramString2)) {
        
        b = 1;
        continue;
      } 
      if (!b)
        continue; 
      if (str1.charAt(0) == '=' || str1.equalsIgnoreCase("is") || str1.charAt(0) == '<' || str1.charAt(0) == '>' || str1.equalsIgnoreCase("like") || str1.equalsIgnoreCase("not") || str1.equalsIgnoreCase("in") || str1.charAt(0) == '!') {


        
        b = 2;
        continue;
      } 
      if (str1.charAt(0) == '?' && str != null) {
        
        if (stringBuilder.length() != 0)
        {
          stringBuilder.append(", ");
        }
        stringBuilder.append(str);
        b = 1;
        str = null;
        continue;
      } 
      if (b == 1) {

        
        if (str1.equals(" "))
          continue; 
        String str2 = escapeParse(stringTokenizer, str1);
        if (str2.length() > 0)
        {
          str = str2;
        }
      } 
    } 
    
    return stringBuilder.toString();
  }





  
  private String parseInsertColumns(String paramString1, String paramString2) {
    StringTokenizer stringTokenizer = new StringTokenizer(paramString1, " (),", true);
    byte b = 0;
    String str = null;
    StringBuilder stringBuilder = new StringBuilder();
    
    while (stringTokenizer.hasMoreTokens()) {
      String str1 = stringTokenizer.nextToken();
      if (str1.equalsIgnoreCase(paramString2)) {
        b = 1;
        continue;
      } 
      if (!b)
        continue; 
      if (str1.charAt(0) == '=') {
        b = 2;
        continue;
      } 
      if ((str1.charAt(0) == ',' || str1.charAt(0) == ')' || str1.charAt(0) == ' ') && str != null) {

        
        if (stringBuilder.length() != 0)
          stringBuilder.append(", "); 
        stringBuilder.append(str);
        b = 1;
        str = null;
      } 
      if (str1.charAt(0) == ')') {
        b = 0;
        break;
      } 
      if (b == 1 && 
        str1.trim().length() > 0 && 
        str1.charAt(0) != ',') {
        str = escapeParse(stringTokenizer, str1);
      }
    } 

    
    return stringBuilder.toString();
  }

  
  class QueryMeta
  {
    String parameterClassName = null;
    int parameterType = 0;
    String parameterTypeName = null;
    int precision = 0;
    int scale = 0;
    int isNullable = 2;
    boolean isSigned = false;
  }
  Map<Integer, QueryMeta> queryMetaMap = null;




  
  private void parseQueryMeta(ResultSet paramResultSet) throws SQLServerException {
    Pattern pattern = Pattern.compile("(.*)\\((.*)(\\)|,(.*)\\))");
    try {
      while (paramResultSet.next())
      {
        QueryMeta queryMeta = new QueryMeta();
        SSType sSType = null;
        
        int i = paramResultSet.getInt("parameter_ordinal");
        String str = paramResultSet.getString("suggested_system_type_name");
        
        if (null == str) {
          str = paramResultSet.getString("suggested_user_type_name");
          SQLServerPreparedStatement sQLServerPreparedStatement = (SQLServerPreparedStatement)this.con.prepareCall("select max_length, precision, scale, is_nullable from sys.assembly_types where name = ?");
          sQLServerPreparedStatement.setNString(1, str);
          ResultSet resultSet = sQLServerPreparedStatement.executeQuery();
          if (resultSet.next()) {
            queryMeta.parameterTypeName = str;
            queryMeta.precision = resultSet.getInt("max_length");
            queryMeta.scale = resultSet.getInt("scale");
            sSType = SSType.UDT;
          } 
        } else {
          
          queryMeta.precision = paramResultSet.getInt("suggested_precision");
          queryMeta.scale = paramResultSet.getInt("suggested_scale");

          
          Matcher matcher = pattern.matcher(str);
          if (matcher.matches()) {

            
            sSType = SSType.of(matcher.group(1));
            if (str.equalsIgnoreCase("varchar(max)") || str.equalsIgnoreCase("varbinary(max)")) {

              
              queryMeta.precision = Integer.MAX_VALUE;
            }
            else if (str.equalsIgnoreCase("nvarchar(max)")) {
              
              queryMeta.precision = 1073741823;
            }
            else if (SSType.Category.CHARACTER == sSType.category || SSType.Category.BINARY == sSType.category || SSType.Category.NCHARACTER == sSType.category) {
              
              try
              {


                
                queryMeta.precision = Integer.parseInt(matcher.group(2));
              }
              catch (NumberFormatException numberFormatException)
              {
                MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_metaDataErrorForParameter"));
                Object[] arrayOfObject = { new Integer(i) };
                SQLServerException.makeFromDriverError(this.con, this.stmtParent, messageFormat.format(arrayOfObject) + " " + numberFormatException.toString(), null, false);
              }
            
            } 
          } else {
            
            sSType = SSType.of(str);
          } 
          
          if (SSType.FLOAT == sSType) {


            
            queryMeta.precision = 15;
          }
          else if (SSType.REAL == sSType) {
            
            queryMeta.precision = 7;
          }
          else if (SSType.TEXT == sSType) {
            
            queryMeta.precision = Integer.MAX_VALUE;
          }
          else if (SSType.NTEXT == sSType) {
            
            queryMeta.precision = 1073741823;
          }
          else if (SSType.IMAGE == sSType) {
            
            queryMeta.precision = Integer.MAX_VALUE;
          }
          else if (SSType.GUID == sSType) {
            
            queryMeta.precision = 36;
          }
          else if (SSType.TIMESTAMP == sSType) {
            
            queryMeta.precision = 8;
          }
          else if (SSType.XML == sSType) {
            
            queryMeta.precision = 1073741823;
          } 
          
          queryMeta.parameterTypeName = sSType.toString();
        } 

        
        if (null == sSType)
        {
          throw new SQLServerException(SQLServerException.getErrString("R_metaDataErrorForParameter"), null);
        }
        
        JDBCType jDBCType = sSType.getJDBCType();
        queryMeta.parameterClassName = jDBCType.className();
        queryMeta.parameterType = jDBCType.getIntValue();
        
        queryMeta.isSigned = (SSType.Category.NUMERIC == sSType.category && SSType.BIT != sSType && SSType.TINYINT != sSType);
        this.queryMetaMap.put(Integer.valueOf(i), queryMeta);
      }
    
    } catch (SQLException sQLException) {
      
      throw new SQLServerException(SQLServerException.getErrString("R_metaDataErrorForParameter"), sQLException);
    } 
  }



  
  private void parseQueryMetaFor2008(ResultSet paramResultSet) throws SQLServerException {
    try {
      ResultSetMetaData resultSetMetaData = paramResultSet.getMetaData();
      
      for (byte b = 1; b <= resultSetMetaData.getColumnCount(); b++) {
        QueryMeta queryMeta = new QueryMeta();
        
        queryMeta.parameterClassName = resultSetMetaData.getColumnClassName(b);
        queryMeta.parameterType = resultSetMetaData.getColumnType(b);
        queryMeta.parameterTypeName = resultSetMetaData.getColumnTypeName(b);
        queryMeta.precision = resultSetMetaData.getPrecision(b);
        queryMeta.scale = resultSetMetaData.getScale(b);
        queryMeta.isNullable = resultSetMetaData.isNullable(b);
        queryMeta.isSigned = resultSetMetaData.isSigned(b);
        
        this.queryMetaMap.put(Integer.valueOf(b), queryMeta);
      }
    
    } catch (SQLException sQLException) {
      throw new SQLServerException(SQLServerException.getErrString("R_metaDataErrorForParameter"), sQLException);
    } 
  }









  
  private String escapeParse(StringTokenizer paramStringTokenizer, String paramString) {
    String str1 = paramString;
    
    while (str1.equals(" ") && paramStringTokenizer.hasMoreTokens())
    {
      str1 = paramStringTokenizer.nextToken();
    }
    String str2 = str1;
    if (str1.charAt(0) == '[' && str1.charAt(str1.length() - 1) != ']')
    {
      while (paramStringTokenizer.hasMoreTokens()) {
        
        str1 = paramStringTokenizer.nextToken();
        str2 = str2.concat(str1);
        if (str1.charAt(str1.length() - 1) == ']') {
          break;
        }
      } 
    }

    
    str2 = str2.trim();
    return str2;
  }

  
  private class MetaInfo
  {
    String table;
    String fields;
    
    MetaInfo(String param1String1, String param1String2) {
      this.table = param1String1;
      this.fields = param1String2;
    }
  }






  
  private MetaInfo parseStatement(String paramString1, String paramString2) {
    StringTokenizer stringTokenizer = new StringTokenizer(paramString1, " ,", true);


    
    String str1 = null;
    String str2 = "";
    while (stringTokenizer.hasMoreTokens()) {
      
      String str = stringTokenizer.nextToken().trim();
      
      if (str.equalsIgnoreCase(paramString2))
      {
        if (stringTokenizer.hasMoreTokens()) {
          
          str1 = escapeParse(stringTokenizer, stringTokenizer.nextToken());
          
          break;
        } 
      }
    } 
    if (null != str1) {
      
      if (paramString2.equalsIgnoreCase("UPDATE")) {
        str2 = parseColumns(paramString1, "SET");
      } else if (paramString2.equalsIgnoreCase("INTO")) {
        str2 = parseInsertColumns(paramString1, "(");
      } else {
        str2 = parseColumns(paramString1, "WHERE");
      } 
      return new MetaInfo(str1, str2);
    } 
    
    return null;
  }






  
  private MetaInfo parseStatement(String paramString) throws SQLServerException {
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, " ");
    if (stringTokenizer.hasMoreTokens()) {
      
      String str = stringTokenizer.nextToken().trim();
      
      if (str.equalsIgnoreCase("INSERT")) {
        return parseStatement(paramString, "INTO");
      }
      if (str.equalsIgnoreCase("UPDATE")) {
        return parseStatement(paramString, "UPDATE");
      }
      if (str.equalsIgnoreCase("SELECT")) {
        return parseStatement(paramString, "FROM");
      }
      if (str.equalsIgnoreCase("DELETE")) {
        return parseStatement(paramString, "FROM");
      }
    } 
    return null;
  }

  
  String parseThreePartNames(String paramString) throws SQLServerException {
    byte b = 0;
    String str1 = null;
    String str2 = null;
    String str3 = null;
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, ".", true);


    
    while (stringTokenizer.hasMoreTokens()) {
      
      String str4 = stringTokenizer.nextToken();
      String str5 = escapeParse(stringTokenizer, str4);
      if (!str5.equals(".")) {
        
        switch (b) {
          
          case true:
            str3 = str2;
            str2 = str1;
            str1 = str5;
            b++;
            continue;
          case true:
            str2 = str1;
            str1 = str5;
            b++;
            continue;
          case false:
            str1 = str5;
            b++;
            continue;
        } 
        b++;
      } 
    } 

    
    StringBuilder stringBuilder = new StringBuilder(100);
    
    if (b > 3 && 1 < b) {
      SQLServerException.makeFromDriverError(this.con, this.stmtParent, SQLServerException.getErrString("R_noMetadata"), null, false);
    }
    switch (b) {
      
      case 3:
        stringBuilder.append("@procedure_qualifier =");
        stringBuilder.append(str3);
        stringBuilder.append(", ");
        stringBuilder.append("@procedure_owner =");
        stringBuilder.append(str2);
        stringBuilder.append(", ");
        stringBuilder.append("@procedure_name =");
        stringBuilder.append(str1);
        stringBuilder.append(", ");
        break;
      
      case 2:
        stringBuilder.append("@procedure_owner =");
        stringBuilder.append(str2);
        stringBuilder.append(", ");
        stringBuilder.append("@procedure_name =");
        stringBuilder.append(str1);
        stringBuilder.append(", ");
        break;
      case 1:
        stringBuilder.append("@procedure_name =");
        stringBuilder.append(str1);
        stringBuilder.append(", ");
        break;
    } 

    
    return stringBuilder.toString();
  }


  
  private void checkClosed() throws SQLServerException {
    this.stmtParent.checkClosed();
  }








  
  SQLServerParameterMetaData(SQLServerStatement paramSQLServerStatement, String paramString) throws SQLServerException {
    assert null != paramSQLServerStatement;
    this.stmtParent = paramSQLServerStatement;
    this.con = paramSQLServerStatement.connection;
    if (logger.isLoggable(Level.FINE))
    {
      logger.fine(toString() + " created by (" + paramSQLServerStatement.toString() + ")");
    }



    
    try {
      if (null != paramSQLServerStatement.procedureName) {
        
        SQLServerStatement sQLServerStatement = (SQLServerStatement)this.con.createStatement(1004, 1007);
        String str = parseThreePartNames(paramSQLServerStatement.procedureName);
        if (this.con.isKatmaiOrLater()) {
          this.rsProcedureMeta = sQLServerStatement.executeQueryInternal("exec sp_sproc_columns_100 " + str + " @ODBCVer=3");
        } else {
          this.rsProcedureMeta = sQLServerStatement.executeQueryInternal("exec sp_sproc_columns " + str + " @ODBCVer=3");
        } 
        this.rsProcedureMeta.getColumn(6).setFilter(new DataTypeFilter());
        if (this.con.isKatmaiOrLater())
        {
          this.rsProcedureMeta.getColumn(8).setFilter(new ZeroFixupFilter());
          this.rsProcedureMeta.getColumn(9).setFilter(new ZeroFixupFilter());
          this.rsProcedureMeta.getColumn(17).setFilter(new ZeroFixupFilter());

        
        }

      
      }
      else {

        
        this.queryMetaMap = new HashMap<>();
        
        if (this.con.getServerMajorVersion() >= 11)
        {
          String str = this.con.replaceParameterMarkers(((SQLServerPreparedStatement)this.stmtParent).userSQL, ((SQLServerPreparedStatement)this.stmtParent).inOutParam, ((SQLServerPreparedStatement)this.stmtParent).bReturnValueSyntax);



          
          SQLServerCallableStatement sQLServerCallableStatement = (SQLServerCallableStatement)this.con.prepareCall("exec sp_describe_undeclared_parameters ?");
          sQLServerCallableStatement.setNString(1, str);
          parseQueryMeta(sQLServerCallableStatement.executeQueryInternal());
          sQLServerCallableStatement.close();
        }
        else
        {
          MetaInfo metaInfo = parseStatement(paramString);
          if (null == metaInfo) {
            
            MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_cantIdentifyTableMetadata"));
            Object[] arrayOfObject = { new String(paramString) };
            SQLServerException.makeFromDriverError(this.con, this.stmtParent, messageFormat.format(arrayOfObject), null, false);
          } 
          
          if (metaInfo.fields.length() <= 0) {
            return;
          }
          Statement statement = this.con.createStatement();
          String str = "sp_executesql N'SET FMTONLY ON SELECT " + metaInfo.fields + " FROM " + metaInfo.table + " WHERE 1 = 2'";
          ResultSet resultSet = statement.executeQuery(str);
          parseQueryMetaFor2008(resultSet);
          statement.close();
          resultSet.close();
        }
      
      } 
    } catch (SQLException sQLException) {
      
      SQLServerException.makeFromDriverError(this.con, this.stmtParent, sQLException.toString(), null, false);
    } 
  }

  
  public boolean isWrapperFor(Class<?> paramClass) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    
    return false;
  }

  
  public <T> T unwrap(Class<T> paramClass) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
  }

  
  private void verifyParameterPosition(int paramInt) throws SQLServerException {
    boolean bool = false;
    try {
      bool = this.rsProcedureMeta.absolute(paramInt + 1);
    }
    catch (SQLException sQLException) {
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_metaDataErrorForParameter"));
      Object[] arrayOfObject = { new Integer(paramInt) };
      SQLServerException.makeFromDriverError(this.con, this.stmtParent, messageFormat.format(arrayOfObject) + " " + sQLException.toString(), null, false);
    } 
    
    if (!bool) {
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidParameterNumber"));
      Object[] arrayOfObject = { new Integer(paramInt) };
      SQLServerException.makeFromDriverError(this.con, this.stmtParent, messageFormat.format(arrayOfObject), null, false);
    } 
  }

  
  private void checkParam(int paramInt) throws SQLServerException {
    if (!this.queryMetaMap.containsKey(Integer.valueOf(paramInt)))
    {
      SQLServerException.makeFromDriverError(this.con, this.stmtParent, SQLServerException.getErrString("R_noMetadata"), null, false);
    }
  }
  
  public String getParameterClassName(int paramInt) throws SQLServerException {
    checkClosed();
    try {
      if (this.rsProcedureMeta == null) {
        
        checkParam(paramInt);
        return ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(paramInt))).parameterClassName;
      } 
      
      verifyParameterPosition(paramInt);
      JDBCType jDBCType = JDBCType.of(this.rsProcedureMeta.getShort("DATA_TYPE"));
      return jDBCType.className();
    
    }
    catch (SQLException sQLException) {
      SQLServerException.makeFromDriverError(this.con, this.stmtParent, sQLException.toString(), null, false);
      return null;
    } 
  }
  
  public int getParameterCount() throws SQLServerException {
    checkClosed();
    try {
      if (this.rsProcedureMeta == null)
      {
        return this.queryMetaMap.size();
      }
      
      this.rsProcedureMeta.last();
      int i = this.rsProcedureMeta.getRow() - 1;
      if (i < 0)
        i = 0; 
      return i;
    
    }
    catch (SQLException sQLException) {
      SQLServerException.makeFromDriverError(this.con, this.stmtParent, sQLException.toString(), null, false);
      return 0;
    } 
  }
  
  public int getParameterMode(int paramInt) throws SQLServerException {
    checkClosed();
    try {
      if (this.rsProcedureMeta == null) {
        checkParam(paramInt);
        
        return 1;
      } 
      
      verifyParameterPosition(paramInt);
      int i = this.rsProcedureMeta.getInt("COLUMN_TYPE");
      switch (i) {
        case 1:
          return 1;
        case 2:
          return 4;
      } 
      return 0;

    
    }
    catch (SQLException sQLException) {
      SQLServerException.makeFromDriverError(this.con, this.stmtParent, sQLException.toString(), null, false);
      return 0;
    } 
  }
  
  public int getParameterType(int paramInt) throws SQLServerException {
    checkClosed();
    
    try {
      int i;
      if (this.rsProcedureMeta == null) {
        
        checkParam(paramInt);
        i = ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(paramInt))).parameterType;
      } else {
        
        verifyParameterPosition(paramInt);
        i = this.rsProcedureMeta.getShort("DATA_TYPE");
      } 
      
      switch (i) {
        
        case -151:
        case -150:
          i = SSType.DATETIME2.getJDBCType().asJavaSqlType();
          break;
        case -148:
        case -146:
          i = SSType.DECIMAL.getJDBCType().asJavaSqlType();
          break;
        case -145:
          i = SSType.CHAR.getJDBCType().asJavaSqlType();
          break;
      } 
      
      return i;
    }
    catch (SQLException sQLException) {
      SQLServerException.makeFromDriverError(this.con, this.stmtParent, sQLException.toString(), null, false);
      return 0;
    } 
  }
  
  public String getParameterTypeName(int paramInt) throws SQLServerException {
    checkClosed();
    try {
      if (this.rsProcedureMeta == null) {
        
        checkParam(paramInt);
        return ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(paramInt))).parameterTypeName;
      } 
      
      verifyParameterPosition(paramInt);
      return this.rsProcedureMeta.getString("TYPE_NAME");
    
    }
    catch (SQLException sQLException) {
      SQLServerException.makeFromDriverError(this.con, this.stmtParent, sQLException.toString(), null, false);
      return null;
    } 
  }
  
  public int getPrecision(int paramInt) throws SQLServerException {
    checkClosed();
    try {
      if (this.rsProcedureMeta == null) {
        
        checkParam(paramInt);
        return ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(paramInt))).precision;
      } 
      
      verifyParameterPosition(paramInt);
      return this.rsProcedureMeta.getInt("PRECISION");

    
    }
    catch (SQLException sQLException) {
      SQLServerException.makeFromDriverError(this.con, this.stmtParent, sQLException.toString(), null, false);
      return 0;
    } 
  }
  
  public int getScale(int paramInt) throws SQLServerException {
    checkClosed();
    try {
      if (this.rsProcedureMeta == null) {
        
        checkParam(paramInt);
        return ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(paramInt))).scale;
      } 
      
      verifyParameterPosition(paramInt);
      return this.rsProcedureMeta.getInt("SCALE");

    
    }
    catch (SQLException sQLException) {
      SQLServerException.makeFromDriverError(this.con, this.stmtParent, sQLException.toString(), null, false);
      return 0;
    } 
  }
  
  public int isNullable(int paramInt) throws SQLServerException {
    checkClosed();
    try {
      if (this.rsProcedureMeta == null) {
        
        checkParam(paramInt);
        return ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(paramInt))).isNullable;
      } 
      
      verifyParameterPosition(paramInt);
      int i = this.rsProcedureMeta.getInt("NULLABLE");
      if (i == 1)
        return 1; 
      if (i == 0)
        return 0; 
      return 2;
    
    }
    catch (SQLException sQLException) {
      SQLServerException.makeFromDriverError(this.con, this.stmtParent, sQLException.toString(), null, false);
      return 0;
    } 
  }






  
  public boolean isSigned(int paramInt) throws SQLServerException {
    checkClosed();
    try {
      if (this.rsProcedureMeta == null) {
        
        checkParam(paramInt);
        return ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(paramInt))).isSigned;
      } 
      
      verifyParameterPosition(paramInt);
      return JDBCType.of(this.rsProcedureMeta.getShort("DATA_TYPE")).isSigned();
    
    }
    catch (SQLException sQLException) {
      SQLServerException.makeFromDriverError(this.con, this.stmtParent, sQLException.toString(), null, false);
      return false;
    } 
  }
}
