package com.microsoft.sqlserver.jdbc;











final class StreamColumns
  extends StreamPacket
{
  private Column[] columns;
  private CekTable cekTable = null;

  
  private boolean shouldHonorAEForRead = false;

  
  CekTable getCekTable() {
    return this.cekTable;
  }



  
  StreamColumns() {
    super(129);
  }



  
  StreamColumns(boolean paramBoolean) {
    super(129);
    this.shouldHonorAEForRead = paramBoolean;
  }







  
  CekTableEntry readCEKTableEntry(TDSReader paramTDSReader) throws SQLServerException {
    int i = paramTDSReader.readInt();

    
    int j = paramTDSReader.readInt();

    
    int k = paramTDSReader.readInt();

    
    byte[] arrayOfByte = new byte[8];
    paramTDSReader.readBytes(arrayOfByte, 0, 8);

    
    int m = paramTDSReader.readUnsignedByte();
    
    CekTableEntry cekTableEntry = new CekTableEntry(m);
    
    for (byte b = 0; b < m; b++) {
      
      short s1 = paramTDSReader.readShort();
      
      byte[] arrayOfByte1 = new byte[s1];

      
      paramTDSReader.readBytes(arrayOfByte1, 0, s1);

      
      int n = paramTDSReader.readUnsignedByte();

      
      String str1 = paramTDSReader.readUnicodeString(n);

      
      short s2 = paramTDSReader.readShort();

      
      String str2 = paramTDSReader.readUnicodeString(s2);

      
      int i1 = paramTDSReader.readUnsignedByte();

      
      String str3 = paramTDSReader.readUnicodeString(i1);

      
      cekTableEntry.add(arrayOfByte1, i, j, k, arrayOfByte, str2, str1, str3);
    } 







    
    return cekTableEntry;
  }







  
  void readCEKTable(TDSReader paramTDSReader) throws SQLServerException {
    short s = paramTDSReader.readShort();


    
    if (0 != s) {
      this.cekTable = new CekTable(s);

      
      for (byte b = 0; b < s; b++)
      {
        this.cekTable.setCekTableEntry(b, readCEKTableEntry(paramTDSReader));
      }
    } 
  }







  
  CryptoMetadata readCryptoMetadata(TDSReader paramTDSReader) throws SQLServerException {
    short s = 0;
    
    if (null != this.cekTable)
    {
      s = paramTDSReader.readShort();
    }
    
    TypeInfo typeInfo = TypeInfo.getInstance(paramTDSReader, false);

    
    byte b1 = (byte)paramTDSReader.readUnsignedByte();
    
    String str = null;
    if (0 == b1) {
      
      int i = paramTDSReader.readUnsignedByte();
      str = paramTDSReader.readUnicodeString(i);
    } 

    
    byte b2 = (byte)paramTDSReader.readUnsignedByte();

    
    byte b3 = (byte)paramTDSReader.readUnsignedByte();
    
    CryptoMetadata cryptoMetadata = new CryptoMetadata((this.cekTable == null) ? null : this.cekTable.getCekTableEntry(s), s, b1, str, b2, b3);





    
    cryptoMetadata.setBaseTypeInfo(typeInfo);
    
    return cryptoMetadata;
  }






  
  void setFromTDS(TDSReader paramTDSReader) throws SQLServerException {
    if (129 != paramTDSReader.readUnsignedByte() && !$assertionsDisabled) throw new AssertionError();
    
    int i = paramTDSReader.readUnsignedShort();

    
    if (65535 == i) {
      return;
    }
    if (paramTDSReader.getServerSupportsColumnEncryption())
    {
      readCEKTable(paramTDSReader);
    }
    
    this.columns = new Column[i];
    
    for (byte b = 0; b < i; b++) {

      
      TypeInfo typeInfo = TypeInfo.getInstance(paramTDSReader, true);




      
      SQLIdentifier sQLIdentifier = new SQLIdentifier();
      if (SSType.TEXT == typeInfo.getSSType() || SSType.NTEXT == typeInfo.getSSType() || SSType.IMAGE == typeInfo.getSSType())
      {


        
        sQLIdentifier = paramTDSReader.readSQLIdentifier();
      }
      
      CryptoMetadata cryptoMetadata = null;
      if (paramTDSReader.getServerSupportsColumnEncryption() && typeInfo.isEncrypted()) {
        
        cryptoMetadata = readCryptoMetadata(paramTDSReader);
        cryptoMetadata.baseTypeInfo.setFlags(Short.valueOf(typeInfo.getFlagsAsShort()));
        typeInfo.setSQLCollation(cryptoMetadata.baseTypeInfo.getSQLCollation());
      } 

      
      String str = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
      
      if (this.shouldHonorAEForRead) {
        
        this.columns[b] = new Column(typeInfo, str, sQLIdentifier, cryptoMetadata);
      
      }
      else {
        
        this.columns[b] = new Column(typeInfo, str, sQLIdentifier, null);
      } 
    } 
  }






  
  Column[] buildColumns(StreamColInfo paramStreamColInfo, StreamTabName paramStreamTabName) throws SQLServerException {
    if (null != paramStreamColInfo && null != paramStreamTabName) {
      paramStreamTabName.applyTo(this.columns, paramStreamColInfo.applyTo(this.columns));
    }
    return this.columns;
  }
}
