package com.microsoft.sqlserver.jdbc;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import microsoft.sql.DateTimeOffset;

abstract class DTVExecuteOp {
  abstract void execute(DTV paramDTV, String paramString) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, Clob paramClob) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, Byte paramByte) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, Integer paramInteger) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, Time paramTime) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, Date paramDate) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, Timestamp paramTimestamp) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, Date paramDate) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, Calendar paramCalendar) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, LocalDate paramLocalDate) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, LocalTime paramLocalTime) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, LocalDateTime paramLocalDateTime) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, OffsetTime paramOffsetTime) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, OffsetDateTime paramOffsetDateTime) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, DateTimeOffset paramDateTimeOffset) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, Float paramFloat) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, Double paramDouble) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, BigDecimal paramBigDecimal) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, Long paramLong) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, BigInteger paramBigInteger) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, Short paramShort) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, Boolean paramBoolean) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, byte[] paramArrayOfbyte) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, Blob paramBlob) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, InputStream paramInputStream) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, Reader paramReader) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, SQLServerSQLXML paramSQLServerSQLXML) throws SQLServerException;
  
  abstract void execute(DTV paramDTV, TVP paramTVP) throws SQLServerException;
}
