package com.microsoft.sqlserver.jdbc;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;




public class SQLServerBulkCSVFileRecord
  implements ISQLServerBulkRecord, AutoCloseable
{
  private BufferedReader fileReader;
  private InputStreamReader sr;
  private FileInputStream fis;
  private Map<Integer, ColumnMetadata> columnMetadata;
  
  private class ColumnMetadata
  {
    String columnName;
    int columnType;
    int precision;
    int scale;
    DateTimeFormatter dateTimeFormatter = null;

    
    ColumnMetadata(String param1String, int param1Int1, int param1Int2, int param1Int3, DateTimeFormatter param1DateTimeFormatter) {
      this.columnName = param1String;
      this.columnType = param1Int1;
      this.precision = param1Int2;
      this.scale = param1Int3;
      this.dateTimeFormatter = param1DateTimeFormatter;
    }
  }
















  
  private String currentLine = null;



  
  private final String delimiter;



  
  private String[] columnNames = null;



  
  private DateTimeFormatter dateTimeFormatter = null;



  
  private DateTimeFormatter timeFormatter = null;



  
  private static final String loggerClassName = "com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord";



  
  private static final Logger loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord");











  
  public SQLServerBulkCSVFileRecord(String paramString1, String paramString2, String paramString3, boolean paramBoolean) throws SQLServerException {
    loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "SQLServerBulkCSVFileRecord", new Object[] { paramString1, paramString2, paramString3, Boolean.valueOf(paramBoolean) });


    
    if (null == paramString1) {
      throwInvalidArgument("fileToParse");
    } else if (null == paramString3) {
      throwInvalidArgument("delimiter");
    } 
    
    this.delimiter = paramString3;

    
    try {
      this.fis = new FileInputStream(paramString1);
      if (null == paramString2 || 0 == paramString2.length()) {
        
        this.sr = new InputStreamReader(this.fis);
      }
      else {
        
        this.sr = new InputStreamReader(this.fis, paramString2);
      } 
      
      this.fileReader = new BufferedReader(this.sr);
      
      if (paramBoolean)
      {
        this.currentLine = this.fileReader.readLine();
        if (null != this.currentLine)
        {
          this.columnNames = this.currentLine.split(paramString3, -1);
        }
      }
    
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
      throw new SQLServerException(messageFormat.format(new Object[] { paramString2 }, ), null, 0, null);
    }
    catch (Exception exception) {
      
      throw new SQLServerException(null, exception.getMessage(), null, 0, false);
    } 
    this.columnMetadata = new HashMap<>();
    
    loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "SQLServerBulkCSVFileRecord");
  }









  
  public SQLServerBulkCSVFileRecord(String paramString1, String paramString2, boolean paramBoolean) throws SQLServerException {
    this(paramString1, paramString2, ",", paramBoolean);
  }








  
  public SQLServerBulkCSVFileRecord(String paramString, boolean paramBoolean) throws SQLServerException {
    this(paramString, null, ",", paramBoolean);
  }


  
  public void addColumnMetadata(int paramInt1, String paramString, int paramInt2, int paramInt3, int paramInt4, DateTimeFormatter paramDateTimeFormatter) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    addColumnMetadataInternal(paramInt1, paramString, paramInt2, paramInt3, paramInt4, paramDateTimeFormatter);
  }

  
  public void addColumnMetadata(int paramInt1, String paramString, int paramInt2, int paramInt3, int paramInt4) throws SQLServerException {
    addColumnMetadataInternal(paramInt1, paramString, paramInt2, paramInt3, paramInt4, null);
  }











  
  void addColumnMetadataInternal(int paramInt1, String paramString, int paramInt2, int paramInt3, int paramInt4, DateTimeFormatter paramDateTimeFormatter) throws SQLServerException {
    loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "addColumnMetadata", new Object[] { Integer.valueOf(paramInt1), paramString, Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), Integer.valueOf(paramInt4) });

    
    String str = "";
    
    if (0 >= paramInt1) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidColumnOrdinal"));
      Object[] arrayOfObject = { Integer.valueOf(paramInt1) };
      throw new SQLServerException(messageFormat.format(arrayOfObject), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
    } 
    
    if (null != paramString) {
      str = paramString.trim();
    } else if (this.columnNames != null && this.columnNames.length >= paramInt1) {
      str = this.columnNames[paramInt1 - 1];
    } 
    
    if (this.columnNames != null && paramInt1 > this.columnNames.length) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidColumn"));
      Object[] arrayOfObject = { Integer.valueOf(paramInt1) };
      throw new SQLServerException(messageFormat.format(arrayOfObject), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
    } 
    
    checkDuplicateColumnName(paramInt1, paramString);
    switch (paramInt2) {






      
      case -155:
      case 91:
      case 92:
      case 93:
        this.columnMetadata.put(Integer.valueOf(paramInt1), new ColumnMetadata(str, paramInt2, 50, paramInt4, paramDateTimeFormatter));
        break;


      
      case 2009:
        this.columnMetadata.put(Integer.valueOf(paramInt1), new ColumnMetadata(str, -16, paramInt3, paramInt4, paramDateTimeFormatter));
        break;


      
      case 6:
        this.columnMetadata.put(Integer.valueOf(paramInt1), new ColumnMetadata(str, 8, paramInt3, paramInt4, paramDateTimeFormatter));
        break;

      
      case 16:
        this.columnMetadata.put(Integer.valueOf(paramInt1), new ColumnMetadata(str, -7, paramInt3, paramInt4, paramDateTimeFormatter));
        break;
      
      default:
        this.columnMetadata.put(Integer.valueOf(paramInt1), new ColumnMetadata(str, paramInt2, paramInt3, paramInt4, paramDateTimeFormatter));
        break;
    } 
    loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "addColumnMetadata");
  }





  
  public void setTimestampWithTimezoneFormat(String paramString) {
    loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "setTimestampWithTimezoneFormat", paramString);
    
    this.dateTimeFormatter = DateTimeFormatter.ofPattern(paramString);
    
    loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "setTimestampWithTimezoneFormat");
  }





  
  public void setTimestampWithTimezoneFormat(DateTimeFormatter paramDateTimeFormatter) {
    loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "setTimestampWithTimezoneFormat", new Object[] { paramDateTimeFormatter });


    
    this.dateTimeFormatter = paramDateTimeFormatter;
    
    loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "setTimestampWithTimezoneFormat");
  }





  
  public void setTimeWithTimezoneFormat(String paramString) {
    loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "setTimeWithTimezoneFormat", paramString);
    
    this.timeFormatter = DateTimeFormatter.ofPattern(paramString);
    
    loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "setTimeWithTimezoneFormat");
  }





  
  public void setTimeWithTimezoneFormat(DateTimeFormatter paramDateTimeFormatter) {
    loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "setTimeWithTimezoneFormat", new Object[] { paramDateTimeFormatter });

    
    this.timeFormatter = paramDateTimeFormatter;
    
    loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "setTimeWithTimezoneFormat");
  }




  
  public void close() throws SQLServerException {
    loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "close");

    
    if (this.fileReader != null) try { this.fileReader.close(); } catch (Exception exception) {} 
    if (this.sr != null) try { this.sr.close(); } catch (Exception exception) {} 
    if (this.fis != null) try { this.fis.close(); } catch (Exception exception) {}
    
    loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "close");
  }
  
  public DateTimeFormatter getColumnDateTimeFormatter(int paramInt) {
    DriverJDBCVersion.checkSupportsJDBC42();
    return ((ColumnMetadata)this.columnMetadata.get(Integer.valueOf(paramInt))).dateTimeFormatter;
  }

  
  public Set<Integer> getColumnOrdinals() {
    return this.columnMetadata.keySet();
  }

  
  public String getColumnName(int paramInt) {
    return ((ColumnMetadata)this.columnMetadata.get(Integer.valueOf(paramInt))).columnName;
  }

  
  public int getColumnType(int paramInt) {
    return ((ColumnMetadata)this.columnMetadata.get(Integer.valueOf(paramInt))).columnType;
  }

  
  public int getPrecision(int paramInt) {
    return ((ColumnMetadata)this.columnMetadata.get(Integer.valueOf(paramInt))).precision;
  }

  
  public int getScale(int paramInt) {
    return ((ColumnMetadata)this.columnMetadata.get(Integer.valueOf(paramInt))).scale;
  }

  
  public boolean isAutoIncrement(int paramInt) {
    return false;
  }



  
  public Object[] getRowData() throws SQLServerException {
    if (null == this.currentLine) {
      return null;
    }




    
    String[] arrayOfString = this.currentLine.split(this.delimiter, -1);

    
    Object[] arrayOfObject = new Object[arrayOfString.length];
    
    Iterator<Map.Entry> iterator = this.columnMetadata.entrySet().iterator();
    while (iterator.hasNext()) {
      
      Map.Entry entry = iterator.next();
      ColumnMetadata columnMetadata = (ColumnMetadata)entry.getValue();


      
      if (arrayOfString.length < ((Integer)entry.getKey()).intValue() - 1) {
        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidColumn"));
        Object[] arrayOfObject1 = { entry.getKey() };
        throw new SQLServerException(messageFormat.format(arrayOfObject1), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
      } 

      
      if (this.columnNames != null && this.columnNames.length > arrayOfString.length) {
        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_BulkCSVDataSchemaMismatch"));
        Object[] arrayOfObject1 = new Object[0];
        throw new SQLServerException(messageFormat.format(arrayOfObject1), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
      }  try {
        DecimalFormat decimalFormat; BigDecimal bigDecimal; String str1; OffsetTime offsetTime;
        OffsetDateTime offsetDateTime;
        String str2;
        if (0 == arrayOfString[((Integer)entry.getKey()).intValue() - 1].length()) {
          
          arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = null;
          
          continue;
        } 
        
        switch (columnMetadata.columnType) {






          
          case 4:
            decimalFormat = new DecimalFormat("#");
            str2 = decimalFormat.format(Double.parseDouble(arrayOfString[((Integer)entry.getKey()).intValue() - 1]));
            arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = Integer.valueOf(str2);
            continue;



          
          case -6:
          case 5:
            decimalFormat = new DecimalFormat("#");
            str2 = decimalFormat.format(Double.parseDouble(arrayOfString[((Integer)entry.getKey()).intValue() - 1]));
            arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = Short.valueOf(str2);
            continue;


          
          case -5:
            bigDecimal = new BigDecimal(arrayOfString[((Integer)entry.getKey()).intValue() - 1].trim());
            
            try {
              arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = Long.valueOf(bigDecimal.setScale(0, 1).longValueExact());
            }
            catch (ArithmeticException arithmeticException) {
              
              String str = "'" + arrayOfString[((Integer)entry.getKey()).intValue() - 1] + "'";
              MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorConvertingValue"));
              throw new SQLServerException(messageFormat.format(new Object[] { str, JDBCType.of(columnMetadata.columnType) }, ), null, 0, null);
            } 
            continue;


          
          case 2:
          case 3:
            bigDecimal = new BigDecimal(arrayOfString[((Integer)entry.getKey()).intValue() - 1].trim());
            
            arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = bigDecimal.setScale(columnMetadata.scale, RoundingMode.HALF_UP);
            continue;





          
          case -7:
            try {
              arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = (0.0D == Double.parseDouble(arrayOfString[((Integer)entry.getKey()).intValue() - 1])) ? Boolean.FALSE : Boolean.TRUE;

            
            }
            catch (NumberFormatException numberFormatException) {
              
              arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = Boolean.valueOf(Boolean.parseBoolean(arrayOfString[((Integer)entry.getKey()).intValue() - 1]));
            } 
            continue;


          
          case 7:
            arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = Float.valueOf(Float.parseFloat(arrayOfString[((Integer)entry.getKey()).intValue() - 1]));
            continue;


          
          case 8:
            arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = Double.valueOf(Double.parseDouble(arrayOfString[((Integer)entry.getKey()).intValue() - 1]));
            continue;














          
          case -4:
          case -3:
          case -2:
          case 2004:
            str1 = arrayOfString[((Integer)entry.getKey()).intValue() - 1].trim();
            if (str1.startsWith("0x") || str1.startsWith("0X")) {

              
              arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = str1.substring(2);
              
              continue;
            } 
            arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = str1;
            continue;



          
          case 2013:
            DriverJDBCVersion.checkSupportsJDBC42();
            str1 = null;

            
            if (null != columnMetadata.dateTimeFormatter) {
              offsetTime = OffsetTime.parse(arrayOfString[((Integer)entry.getKey()).intValue() - 1], columnMetadata.dateTimeFormatter);
            } else if (this.timeFormatter != null) {
              offsetTime = OffsetTime.parse(arrayOfString[((Integer)entry.getKey()).intValue() - 1], this.timeFormatter);
            } else {
              offsetTime = OffsetTime.parse(arrayOfString[((Integer)entry.getKey()).intValue() - 1]);
            } 
            arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = offsetTime;
            continue;


          
          case 2014:
            DriverJDBCVersion.checkSupportsJDBC42();
            offsetTime = null;

            
            if (null != columnMetadata.dateTimeFormatter) {
              offsetDateTime = OffsetDateTime.parse(arrayOfString[((Integer)entry.getKey()).intValue() - 1], columnMetadata.dateTimeFormatter);
            } else if (this.dateTimeFormatter != null) {
              offsetDateTime = OffsetDateTime.parse(arrayOfString[((Integer)entry.getKey()).intValue() - 1], this.dateTimeFormatter);
            } else {
              offsetDateTime = OffsetDateTime.parse(arrayOfString[((Integer)entry.getKey()).intValue() - 1]);
            } 
            arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = offsetDateTime;
            continue;


          
          case 0:
            arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = null;
            continue;
        } 




































        
        arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = arrayOfString[((Integer)entry.getKey()).intValue() - 1];


      
      }
      catch (IllegalArgumentException illegalArgumentException) {
        
        String str = "'" + arrayOfString[((Integer)entry.getKey()).intValue() - 1] + "'";
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorConvertingValue"));
        throw new SQLServerException(messageFormat.format(new Object[] { str, JDBCType.of(columnMetadata.columnType) }, ), null, 0, null);
      }
      catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
        
        throw new SQLServerException(SQLServerException.getErrString("R_BulkCSVDataSchemaMismatch"), null);
      } 
    } 
    
    return arrayOfObject;
  }


  
  public boolean next() throws SQLServerException {
    try {
      this.currentLine = this.fileReader.readLine();
    } catch (IOException iOException) {
      throw new SQLServerException(null, iOException.getMessage(), null, 0, false);
    } 
    return (null != this.currentLine);
  }




  
  private void throwInvalidArgument(String paramString) throws SQLServerException {
    MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
    Object[] arrayOfObject = { paramString };
    SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), null, false);
  }






  
  private void checkDuplicateColumnName(int paramInt, String paramString) throws SQLServerException {
    if (null != paramString && paramString.trim().length() != 0)
    {
      for (Map.Entry<Integer, ColumnMetadata> entry : this.columnMetadata.entrySet()) {

        
        if (null != entry && ((Integer)entry.getKey()).intValue() != paramInt)
        {
          if (null != entry.getValue() && paramString.trim().equalsIgnoreCase(((ColumnMetadata)entry.getValue()).columnName))
          {
            
            throw new SQLServerException(SQLServerException.getErrString("R_BulkCSVDataDuplicateColumn"), null);
          }
        }
      } 
    }
  }
}
