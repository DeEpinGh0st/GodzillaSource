package com.microsoft.sqlserver.jdbc;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.InvalidKeyException;
import java.security.Signature;
import java.security.cert.X509Certificate;
import java.text.MessageFormat;
import javax.crypto.Cipher;



























class KeyStoreProviderCommon
{
  static final String rsaEncryptionAlgorithmWithOAEP = "RSA_OAEP";
  static byte[] version = new byte[] { 1 };

  
  static void validateEncryptionAlgorithm(String paramString, boolean paramBoolean) throws SQLServerException {
    String str = paramBoolean ? "R_NullKeyEncryptionAlgorithm" : "R_NullKeyEncryptionAlgorithmInternal";
    if (null == paramString)
    {
      
      throw new SQLServerException(null, SQLServerException.getErrString(str), null, 0, false);
    }






    
    str = paramBoolean ? "R_InvalidKeyEncryptionAlgorithm" : "R_InvalidKeyEncryptionAlgorithmInternal";
    if (!"RSA_OAEP".equalsIgnoreCase(paramString.trim())) {

      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString(str));
      
      Object[] arrayOfObject = { paramString, "RSA_OAEP" };
      throw new SQLServerException(messageFormat.format(arrayOfObject), null);
    } 
  }


  
  static void validateNonEmptyMasterKeyPath(String paramString) throws SQLServerException {
    if (null == paramString || paramString.trim().length() == 0)
    {
      throw new SQLServerException(null, SQLServerException.getErrString("R_InvalidMasterKeyDetails"), null, 0, false);
    }
  }










  
  static byte[] decryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfbyte, CertificateDetails paramCertificateDetails) throws SQLServerException {
    if (null == paramArrayOfbyte)
    {
      throw new SQLServerException(null, SQLServerException.getErrString("R_NullEncryptedColumnEncryptionKey"), null, 0, false);
    }





    
    if (0 == paramArrayOfbyte.length)
    {
      throw new SQLServerException(null, SQLServerException.getErrString("R_EmptyEncryptedColumnEncryptionKey"), null, 0, false);
    }






    
    validateEncryptionAlgorithm(paramString2, false);
    
    int i = version.length;
    short s1 = convertTwoBytesToShort(paramArrayOfbyte, i);
    
    i += 2;

    
    short s2 = convertTwoBytesToShort(paramArrayOfbyte, i);

    
    i += 2;
    
    i += s1;
    
    int j = paramArrayOfbyte.length - i - s2;


    
    byte[] arrayOfByte1 = new byte[s2];
    System.arraycopy(paramArrayOfbyte, i, arrayOfByte1, 0, s2);




    
    i += s2;
    
    byte[] arrayOfByte2 = new byte[j];
    System.arraycopy(paramArrayOfbyte, i, arrayOfByte2, 0, j);







    
    byte[] arrayOfByte3 = new byte[paramArrayOfbyte.length - arrayOfByte2.length];
    
    System.arraycopy(paramArrayOfbyte, 0, arrayOfByte3, 0, paramArrayOfbyte.length - arrayOfByte2.length);





    
    if (!verifyRSASignature(arrayOfByte3, arrayOfByte2, paramCertificateDetails.certificate, paramString1)) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidCertificateSignature"));
      
      Object[] arrayOfObject = { paramString1 };
      throw new SQLServerException(messageFormat.format(arrayOfObject), null);
    } 
    
    return decryptRSAOAEP(arrayOfByte1, paramCertificateDetails);
  }




  
  private static byte[] decryptRSAOAEP(byte[] paramArrayOfbyte, CertificateDetails paramCertificateDetails) throws SQLServerException {
    byte[] arrayOfByte = null;
    
    try {
      Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-1AndMGF1Padding");
      cipher.init(2, paramCertificateDetails.privateKey);
      cipher.update(paramArrayOfbyte);
      arrayOfByte = cipher.doFinal();
    }
    catch (InvalidKeyException|java.security.NoSuchAlgorithmException|javax.crypto.NoSuchPaddingException|javax.crypto.IllegalBlockSizeException|javax.crypto.BadPaddingException invalidKeyException) {




      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_CEKDecryptionFailed"));
      
      Object[] arrayOfObject = { invalidKeyException.getMessage() };
      throw new SQLServerException(messageFormat.format(arrayOfObject), null);
    } 
    
    return arrayOfByte;
  }



  
  private static boolean verifyRSASignature(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, X509Certificate paramX509Certificate, String paramString) throws SQLServerException {
    boolean bool = false;
    
    try {
      Signature signature = Signature.getInstance("SHA256withRSA");
      signature.initVerify(paramX509Certificate.getPublicKey());
      signature.update(paramArrayOfbyte1);
      bool = signature.verify(paramArrayOfbyte2);
    }
    catch (InvalidKeyException|java.security.NoSuchAlgorithmException|java.security.SignatureException invalidKeyException) {


      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidCertificateSignature"));
      Object[] arrayOfObject = { paramString };
      throw new SQLServerException(messageFormat.format(arrayOfObject), null);
    } 
    
    return bool;
  }



  
  private static short convertTwoBytesToShort(byte[] paramArrayOfbyte, int paramInt) throws SQLServerException {
    short s = -1;
    if (paramInt + 1 >= paramArrayOfbyte.length)
    {
      throw new SQLServerException(null, SQLServerException.getErrString("R_ByteToShortConversion"), null, 0, false);
    }




    
    ByteBuffer byteBuffer = ByteBuffer.allocate(2);
    byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
    byteBuffer.put(paramArrayOfbyte[paramInt]);
    byteBuffer.put(paramArrayOfbyte[paramInt + 1]);
    s = byteBuffer.getShort(0);
    return s;
  }
}
