package com.microsoft.sqlserver.jdbc;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.IllegalCharsetNameException;
import java.nio.charset.UnsupportedCharsetException;
import java.text.MessageFormat;
















class ReaderInputStream
  extends InputStream
{
  private final Reader reader;
  private final Charset charset;
  private final long readerLength;
  private long readerCharsRead = 0L;


  
  private boolean atEndOfStream = false;

  
  private CharBuffer rawChars = null;

  
  private static final int MAX_CHAR_BUFFER_SIZE = 4000;
  
  private static final ByteBuffer EMPTY_BUFFER = ByteBuffer.allocate(0);
  private ByteBuffer encodedChars = EMPTY_BUFFER;














  
  private final byte[] oneByte;















  
  public int available() throws IOException {
    assert null != this.reader;
    assert null != this.encodedChars;

    
    if (0L == this.readerLength) {
      return 0;
    }
    
    if (this.encodedChars.remaining() > 0) {
      return this.encodedChars.remaining();
    }


    
    if (this.reader.ready()) {
      return 1;
    }

    
    return 0;
  }
  
  ReaderInputStream(Reader paramReader, String paramString, long paramLong) throws UnsupportedEncodingException { this.oneByte = new byte[1]; assert paramReader != null; assert paramString != null; assert -1L == paramLong || paramLong >= 0L; this.reader = paramReader; try { this.charset = Charset.forName(paramString); }
    catch (IllegalCharsetNameException illegalCharsetNameException) { throw new UnsupportedEncodingException(illegalCharsetNameException.getMessage()); }
    catch (UnsupportedCharsetException unsupportedCharsetException) { throw new UnsupportedEncodingException(unsupportedCharsetException.getMessage()); }
     this.readerLength = paramLong; } public int read() throws IOException { return (-1 == readInternal(this.oneByte, 0, this.oneByte.length)) ? -1 : this.oneByte[0]; }


  
  public int read(byte[] paramArrayOfbyte) throws IOException {
    return readInternal(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }

  
  public int read(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
    return readInternal(paramArrayOfbyte, paramInt1, paramInt2);
  }

  
  private int readInternal(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
    assert null != paramArrayOfbyte;
    assert 0 <= paramInt1 && paramInt1 <= paramArrayOfbyte.length;
    assert 0 <= paramInt2 && paramInt2 <= paramArrayOfbyte.length;
    assert paramInt1 <= paramArrayOfbyte.length - paramInt2;
    
    if (0 == paramInt2) {
      return 0;
    }
    int i = 0;
    while (i < paramInt2 && encodeChars()) {



      
      int j = this.encodedChars.remaining();
      if (j > paramInt2 - i) {
        j = paramInt2 - i;
      }

      
      assert j > 0;
      
      this.encodedChars.get(paramArrayOfbyte, paramInt1 + i, j);
      i += j;
    } 


    
    return (0 == i && this.atEndOfStream) ? -1 : i;
  }










  
  private boolean encodeChars() throws IOException {
    if (this.atEndOfStream) {
      return false;
    }


    
    if (this.encodedChars.hasRemaining()) {
      return true;
    }







    
    if (null == this.rawChars || !this.rawChars.hasRemaining()) {
      
      if (null == this.rawChars) {

        
        this.rawChars = CharBuffer.allocate((-1L == this.readerLength || this.readerLength > 4000L) ? 4000 : Math.max((int)this.readerLength, 1));

      
      }
      else {

        
        this.rawChars.clear();
      } 








      
      while (this.rawChars.hasRemaining()) {
        
        int i = this.rawChars.position();
        int j = 0;


        
        try {
          j = this.reader.read(this.rawChars);


        
        }
        catch (Exception exception) {
          
          String str = exception.getMessage();
          if (null == str)
            str = SQLServerException.getErrString("R_streamReadReturnedInvalidValue"); 
          IOException iOException = new IOException(str);
          iOException.initCause(exception);
          throw iOException;
        } 
        
        if (j < -1 || 0 == j) {
          throw new IOException(SQLServerException.getErrString("R_streamReadReturnedInvalidValue"));
        }
        if (-1 == j) {

          
          if (this.rawChars.position() != i) {
            throw new IOException(SQLServerException.getErrString("R_streamReadReturnedInvalidValue"));
          }
          
          if (-1L != this.readerLength && 0L != this.readerLength - this.readerCharsRead) {
            
            MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_mismatchedStreamLength"));
            throw new IOException(messageFormat.format(new Object[] { Long.valueOf(this.readerLength), Long.valueOf(this.readerCharsRead) }));
          } 

          
          if (0 == this.rawChars.position()) {
            
            this.rawChars = null;
            this.atEndOfStream = true;
            return false;
          } 

          
          break;
        } 
        
        assert j > 0;

        
        if (j != this.rawChars.position() - i) {
          throw new IOException(SQLServerException.getErrString("R_streamReadReturnedInvalidValue"));
        }
        
        if (-1L != this.readerLength && j > this.readerLength - this.readerCharsRead) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_mismatchedStreamLength"));
          throw new IOException(messageFormat.format(new Object[] { Long.valueOf(this.readerLength), Long.valueOf(this.readerCharsRead) }));
        } 
        
        this.readerCharsRead += j;
      } 


      
      this.rawChars.flip();
    } 



    
    if (!this.rawChars.hasRemaining()) {
      return false;
    }
    
    this.encodedChars = this.charset.encode(this.rawChars);
    return true;
  }
}
