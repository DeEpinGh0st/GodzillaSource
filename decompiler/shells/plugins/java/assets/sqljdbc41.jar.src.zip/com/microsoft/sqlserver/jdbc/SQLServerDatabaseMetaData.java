package com.microsoft.sqlserver.jdbc;

import java.io.Serializable;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverPropertyInfo;
import java.sql.ResultSet;
import java.sql.RowIdLifetime;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.text.MessageFormat;
import java.util.EnumMap;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class SQLServerDatabaseMetaData
  implements DatabaseMetaData, Serializable {
  private SQLServerConnection connection;
  static final String urlprefix = "jdbc:sqlserver://";
  private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerDatabaseMetaData");

  
  private static final Logger loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.DatabaseMetaData");

  
  private static int baseID = 0;
  
  private final String traceID;
  
  static final int MAXLOBSIZE = 2147483647;
  
  static final int uniqueidentifierSize = 36;

  
  enum CallableHandles
  {
    SP_COLUMNS("{ call sp_columns(?, ?, ?, ?, ?) }", "{ call sp_columns_100(?, ?, ?, ?, ?, ?) }"),
    SP_COLUMN_PRIVILEGES("{ call sp_column_privileges(?, ?, ?, ?)}", "{ call sp_column_privileges(?, ?, ?, ?)}"),
    SP_TABLES("{ call sp_tables(?, ?, ?, ?) }", "{ call sp_tables(?, ?, ?, ?) }"),
    SP_SPECIAL_COLUMNS("{ call sp_special_columns (?, ?, ?, ?, ?, ?, ?)}", "{ call sp_special_columns_100 (?, ?, ?, ?, ?, ?, ?)}"),
    SP_FKEYS("{ call sp_fkeys (?, ?, ?, ? , ? ,?)}", "{ call sp_fkeys (?, ?, ?, ? , ? ,?)}"),
    SP_STATISTICS("{ call sp_statistics(?,?,?,?,?, ?) }", "{ call sp_statistics_100(?,?,?,?,?, ?) }"),
    SP_SPROC_COLUMNS("{ call sp_sproc_columns(?, ?, ?,?,?) }", "{ call sp_sproc_columns_100(?, ?, ?,?,?) }"),
    SP_STORED_PROCEDURES("{call sp_stored_procedures(?, ?, ?) }", "{call sp_stored_procedures(?, ?, ?) }"),
    SP_TABLE_PRIVILEGES("{call sp_table_privileges(?,?,?) }", "{call sp_table_privileges(?,?,?) }"),
    SP_PKEYS("{ call sp_pkeys (?, ?, ?)}", "{ call sp_pkeys (?, ?, ?)}");
    
    private final String preKatProc;
    
    private final String katProc;

    
    CallableHandles(String param1String1, String param1String2) {
      this.preKatProc = param1String1;
      this.katProc = param1String2;
    }
    
    CallableStatement prepare(SQLServerConnection param1SQLServerConnection) throws SQLServerException {
      return param1SQLServerConnection.prepareCall(param1SQLServerConnection.isKatmaiOrLater() ? this.katProc : this.preKatProc);
    }
  }
  
  final class HandleAssociation
  {
    final String databaseName;
    final CallableStatement stmt;
    
    HandleAssociation(String param1String, CallableStatement param1CallableStatement) {
      this.databaseName = param1String;
      this.stmt = param1CallableStatement;
    }
    
    final void close() throws SQLServerException {
      ((SQLServerCallableStatement)this.stmt).close();
    }
  }
  EnumMap<CallableHandles, HandleAssociation> handleMap = new EnumMap<>(CallableHandles.class); private static final String ASC_OR_DESC = "ASC_OR_DESC"; private static final String ATTR_NAME = "ATTR_NAME"; private static final String ATTR_TYPE_NAME = "ATTR_TYPE_NAME"; private static final String ATTR_SIZE = "ATTR_SIZE"; private static final String ATTR_DEF = "ATTR_DEF"; private static final String BASE_TYPE = "BASE_TYPE"; private static final String BUFFER_LENGTH = "BUFFER_LENGTH"; private static final String CARDINALITY = "CARDINALITY"; private static final String CHAR_OCTET_LENGTH = "CHAR_OCTET_LENGTH"; private static final String CLASS_NAME = "CLASS_NAME"; private static final String COLUMN_DEF = "COLUMN_DEF"; private static final String COLUMN_NAME = "COLUMN_NAME"; private static final String COLUMN_SIZE = "COLUMN_SIZE"; private static final String COLUMN_TYPE = "COLUMN_TYPE"; private static final String DATA_TYPE = "DATA_TYPE"; private static final String DECIMAL_DIGITS = "DECIMAL_DIGITS"; private static final String DEFERRABILITY = "DEFERRABILITY"; private static final String DELETE_RULE = "DELETE_RULE"; private static final String FILTER_CONDITION = "FILTER_CONDITION"; private static final String FK_NAME = "FK_NAME"; private static final String FKCOLUMN_NAME = "FKCOLUMN_NAME"; private static final String FKTABLE_CAT = "FKTABLE_CAT"; private static final String FKTABLE_NAME = "FKTABLE_NAME"; private static final String FKTABLE_SCHEM = "FKTABLE_SCHEM"; private static final String GRANTEE = "GRANTEE"; private static final String GRANTOR = "GRANTOR"; private static final String INDEX_NAME = "INDEX_NAME"; private static final String INDEX_QUALIFIER = "INDEX_QUALIFIER"; private static final String IS_GRANTABLE = "IS_GRANTABLE"; private static final String IS_NULLABLE = "IS_NULLABLE"; private static final String KEY_SEQ = "KEY_SEQ"; private static final String LENGTH = "LENGTH"; private static final String NON_UNIQUE = "NON_UNIQUE"; private static final String NULLABLE = "NULLABLE"; private static final String NUM_INPUT_PARAMS = "NUM_INPUT_PARAMS"; private static final String NUM_OUTPUT_PARAMS = "NUM_OUTPUT_PARAMS"; private static final String NUM_PREC_RADIX = "NUM_PREC_RADIX";
  private static final String NUM_RESULT_SETS = "NUM_RESULT_SETS";
  private static final String ORDINAL_POSITION = "ORDINAL_POSITION";
  private static final String PAGES = "PAGES";
  private static final String PK_NAME = "PK_NAME";
  private static final String PKCOLUMN_NAME = "PKCOLUMN_NAME";
  
  private static synchronized int nextInstanceID() {
    baseID++;
    return baseID;
  }
  private static final String PKTABLE_CAT = "PKTABLE_CAT"; private static final String PKTABLE_NAME = "PKTABLE_NAME"; private static final String PKTABLE_SCHEM = "PKTABLE_SCHEM"; private static final String PRECISION = "PRECISION"; private static final String PRIVILEGE = "PRIVILEGE"; private static final String PROCEDURE_CAT = "PROCEDURE_CAT"; private static final String PROCEDURE_NAME = "PROCEDURE_NAME"; private static final String PROCEDURE_SCHEM = "PROCEDURE_SCHEM"; private static final String PROCEDURE_TYPE = "PROCEDURE_TYPE"; private static final String PSEUDO_COLUMN = "PSEUDO_COLUMN"; private static final String RADIX = "RADIX"; private static final String REMARKS = "REMARKS"; private static final String SCALE = "SCALE"; private static final String SCOPE = "SCOPE"; private static final String SCOPE_CATALOG = "SCOPE_CATALOG"; private static final String SCOPE_SCHEMA = "SCOPE_SCHEMA"; private static final String SCOPE_TABLE = "SCOPE_TABLE"; private static final String SOURCE_DATA_TYPE = "SOURCE_DATA_TYPE"; private static final String SQL_DATA_TYPE = "SQL_DATA_TYPE"; private static final String SQL_DATETIME_SUB = "SQL_DATETIME_SUB"; private static final String SS_DATA_TYPE = "SS_DATA_TYPE"; private static final String SUPERTABLE_NAME = "SUPERTABLE_NAME"; private static final String SUPERTYPE_CAT = "SUPERTYPE_CAT"; private static final String SUPERTYPE_NAME = "SUPERTYPE_NAME"; private static final String SUPERTYPE_SCHEM = "SUPERTYPE_SCHEM"; private static final String TABLE_CAT = "TABLE_CAT"; private static final String TABLE_NAME = "TABLE_NAME"; private static final String TABLE_SCHEM = "TABLE_SCHEM"; private static final String TABLE_TYPE = "TABLE_TYPE"; private static final String TYPE = "TYPE"; private static final String TYPE_CAT = "TYPE_CAT"; private static final String TYPE_NAME = "TYPE_NAME"; private static final String TYPE_SCHEM = "TYPE_SCHEM"; private static final String UPDATE_RULE = "UPDATE_RULE"; private static final String FUNCTION_CAT = "FUNCTION_CAT"; private static final String FUNCTION_NAME = "FUNCTION_NAME"; private static final String FUNCTION_SCHEM = "FUNCTION_SCHEM"; private static final String FUNCTION_TYPE = "FUNCTION_TYPE"; private static final String SS_IS_SPARSE = "SS_IS_SPARSE"; private static final String SS_IS_COLUMN_SET = "SS_IS_COLUMN_SET"; private static final String SS_IS_COMPUTED = "SS_IS_COMPUTED"; private static final String IS_AUTOINCREMENT = "IS_AUTOINCREMENT";
  public final String toString() {
    return this.traceID;
  }





  
  public SQLServerDatabaseMetaData(SQLServerConnection paramSQLServerConnection) {
    this.traceID = " SQLServerDatabaseMetaData:" + nextInstanceID();
    this.connection = paramSQLServerConnection;
    if (logger.isLoggable(Level.FINE))
    {
      logger.fine(toString() + " created by (" + this.connection.toString() + ")");
    }
  }

  
  public boolean isWrapperFor(Class<?> paramClass) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    
    return false;
  }

  
  public <T> T unwrap(Class<T> paramClass) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
  }

  
  private void checkClosed() throws SQLServerException {
    if (this.connection.isClosed())
    {
      SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_connectionIsClosed"), "08003", false);
    }
  }


































































































  
  private final SQLServerResultSet getResultSetFromInternalQueries(String paramString1, String paramString2) throws SQLServerException {
    checkClosed();
    String str = null;
    str = switchCatalogs(paramString1);
    SQLServerResultSet sQLServerResultSet = null;
    
    try {
      sQLServerResultSet = ((SQLServerStatement)this.connection.createStatement()).executeQueryInternal(paramString2);
    
    }
    finally {
      
      if (null != str)
      {
        this.connection.setCatalog(str);
      }
    } 
    return sQLServerResultSet;
  }





  
  private CallableStatement getCallableStatementHandle(CallableHandles paramCallableHandles, String paramString) throws SQLServerException {
    CallableStatement callableStatement = null;
    HandleAssociation handleAssociation = this.handleMap.get(paramCallableHandles);
    if (null == handleAssociation || null == handleAssociation.databaseName || !handleAssociation.databaseName.equals(paramString)) {


      
      callableStatement = paramCallableHandles.prepare(this.connection);
      handleAssociation = new HandleAssociation(paramString, callableStatement);
      HandleAssociation handleAssociation1 = this.handleMap.put(paramCallableHandles, handleAssociation);
      if (null != handleAssociation1)
      {
        handleAssociation1.close();
      }
    } 
    return handleAssociation.stmt;
  }









  
  private final SQLServerResultSet getResultSetFromStoredProc(String paramString, CallableHandles paramCallableHandles, String[] paramArrayOfString) throws SQLServerException {
    checkClosed();
    assert null != paramArrayOfString;
    String str = null;
    str = switchCatalogs(paramString);
    SQLServerResultSet sQLServerResultSet = null;
    
    try {
      SQLServerCallableStatement sQLServerCallableStatement = (SQLServerCallableStatement)getCallableStatementHandle(paramCallableHandles, paramString);
      
      for (byte b = 1; b <= paramArrayOfString.length; b++)
      {
        
        sQLServerCallableStatement.setString(b, paramArrayOfString[b - 1]);
      }
      sQLServerResultSet = (SQLServerResultSet)sQLServerCallableStatement.executeQueryInternal();
    }
    finally {
      
      if (null != str)
      {
        this.connection.setCatalog(str);
      }
    } 
    return sQLServerResultSet;
  }



  
  private final SQLServerResultSet getResultSetWithProvidedColumnNames(String paramString, CallableHandles paramCallableHandles, String[] paramArrayOfString1, String[] paramArrayOfString2) throws SQLServerException {
    SQLServerResultSet sQLServerResultSet = getResultSetFromStoredProc(paramString, paramCallableHandles, paramArrayOfString1);

    
    for (byte b = 0; b < paramArrayOfString2.length; b++)
      sQLServerResultSet.setColumnName(1 + b, paramArrayOfString2[b]); 
    return sQLServerResultSet;
  }






  
  private String switchCatalogs(String paramString) throws SQLServerException {
    if (paramString == null)
      return null; 
    String str1 = null;
    str1 = this.connection.getCatalog().trim();
    String str2 = paramString.trim();
    if (str1.equals(str2))
      return null; 
    this.connection.setCatalog(str2);
    if (str1 == null || str1.length() == 0)
      return null; 
    return str1;
  }


  
  public boolean allProceduresAreCallable() throws SQLServerException {
    checkClosed();
    return true;
  }
  
  public boolean allTablesAreSelectable() throws SQLServerException {
    checkClosed();
    return true;
  }

  
  public boolean autoCommitFailureClosesAllResultSets() throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    checkClosed();
    return false;
  }
  
  public boolean dataDefinitionCausesTransactionCommit() throws SQLServerException {
    checkClosed();
    return false;
  }
  
  public boolean dataDefinitionIgnoredInTransactions() throws SQLServerException {
    checkClosed();
    return false;
  }
  
  public boolean doesMaxRowSizeIncludeBlobs() throws SQLServerException {
    checkClosed();
    return false;
  }

  
  public boolean generatedKeyAlwaysReturned() throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC41();
    checkClosed();

    
    return true;
  }

  
  public long getMaxLogicalLobSize() throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC42();
    checkClosed();
    
    return 2147483647L;
  }

  
  public boolean supportsRefCursors() throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC42();
    checkClosed();
    
    return false;
  }
  
  public ResultSet getCatalogs() throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();
    
    String str = "SELECT name AS TABLE_CAT FROM sys.databases order by name";
    return getResultSetFromInternalQueries(null, str);
  }
  
  public String getCatalogSeparator() throws SQLServerException {
    checkClosed();
    return ".";
  }
  
  public String getCatalogTerm() throws SQLServerException {
    checkClosed();
    return "database";
  }
  
  private static final String[] getColumnPrivilegesColumnNames = new String[] { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "COLUMN_NAME", "GRANTOR", "GRANTEE", "PRIVILEGE", "IS_GRANTABLE" };












  
  public ResultSet getColumnPrivileges(String paramString1, String paramString2, String paramString3, String paramString4) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();
    
    paramString4 = EscapeIDName(paramString4);





    
    String[] arrayOfString = new String[4];
    arrayOfString[0] = paramString3;
    arrayOfString[1] = paramString2;
    arrayOfString[2] = paramString1;
    arrayOfString[3] = paramString4;
    return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_COLUMN_PRIVILEGES, arrayOfString, getColumnPrivilegesColumnNames);
  }
  
  private static final String[] getTablesColumnNames = new String[] { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "TABLE_TYPE", "REMARKS" };
  
  static final char LEFT_BRACKET = '[';
  
  static final char RIGHT_BRACKET = ']';
  
  static final char ESCAPE = '\\';
  static final char PERCENT = '%';
  static final char UNDERSCORE = '_';
  
  public ResultSet getTables(String paramString1, String paramString2, String paramString3, String[] paramArrayOfString) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();

    
    paramString3 = EscapeIDName(paramString3);
    paramString2 = EscapeIDName(paramString2);




    
    String[] arrayOfString = new String[4];
    arrayOfString[0] = paramString3;
    arrayOfString[1] = paramString2;
    arrayOfString[2] = paramString1;
    
    String str = null;
    if (paramArrayOfString != null) {
      
      str = "'";
      for (byte b = 0; b < paramArrayOfString.length; b++) {
        
        if (b > 0)
          str = str + ","; 
        str = str + "''" + paramArrayOfString[b] + "''";
      } 
      str = str + "'";
    } 
    arrayOfString[3] = str;
    return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_TABLES, arrayOfString, getTablesColumnNames);
  }













  
  static final char[] DOUBLE_RIGHT_BRACKET = new char[] { ']', ']' };
  
  private static String EscapeIDName(String paramString) throws SQLServerException {
    if (null == paramString) {
      return paramString;
    }










    
    StringBuilder stringBuilder = new StringBuilder(paramString.length() + 2);
    
    for (byte b = 0; b < paramString.length(); b++) {
      
      char c = paramString.charAt(b);
      if ('\\' == c && ++b < paramString.length()) {
        
        c = paramString.charAt(b);
        switch (c) {
          
          case '%':
          case '[':
          case '_':
            stringBuilder.append('[');
            stringBuilder.append(c);
            stringBuilder.append(']');
            break;
          case '\\':
          case ']':
            stringBuilder.append(c);
            break;
          default:
            stringBuilder.append('\\');
            stringBuilder.append(c);
            break;
        } 


      
      } else {
        stringBuilder.append(c);
      } 
    } 
    return stringBuilder.toString();
  }
  
  private static final String[] getColumnsColumnNames = new String[] { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "COLUMN_NAME", "DATA_TYPE", "TYPE_NAME", "COLUMN_SIZE", "BUFFER_LENGTH", "DECIMAL_DIGITS", "NUM_PREC_RADIX", "NULLABLE", "REMARKS", "COLUMN_DEF", "SQL_DATA_TYPE", "SQL_DATETIME_SUB", "CHAR_OCTET_LENGTH", "ORDINAL_POSITION", "IS_NULLABLE" };






















  
  private static final String[] getColumnsColumnNamesKatmai = new String[] { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "COLUMN_NAME", "DATA_TYPE", "TYPE_NAME", "COLUMN_SIZE", "BUFFER_LENGTH", "DECIMAL_DIGITS", "NUM_PREC_RADIX", "NULLABLE", "REMARKS", "COLUMN_DEF", "SQL_DATA_TYPE", "SQL_DATETIME_SUB", "CHAR_OCTET_LENGTH", "ORDINAL_POSITION", "IS_NULLABLE", "SS_IS_SPARSE", "SS_IS_COLUMN_SET", "SS_IS_COMPUTED", "IS_AUTOINCREMENT" };
























  
  public ResultSet getColumns(String paramString1, String paramString2, String paramString3, String paramString4) throws SQLServerException {
    String[] arrayOfString;
    SQLServerResultSet sQLServerResultSet;
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();

    
    String str = EscapeIDName(paramString4);
    paramString3 = EscapeIDName(paramString3);
    paramString2 = EscapeIDName(paramString2);







    
    if (this.connection.isKatmaiOrLater()) {
      arrayOfString = new String[6];
    } else {
      arrayOfString = new String[5];
    }  arrayOfString[0] = paramString3;
    arrayOfString[1] = paramString2;
    arrayOfString[2] = paramString1;
    arrayOfString[3] = str;
    if (this.connection.isKatmaiOrLater()) {
      
      arrayOfString[4] = "2";
      arrayOfString[5] = "3";
    } else {
      
      arrayOfString[4] = "3";
    } 
    if (this.connection.isKatmaiOrLater()) {
      sQLServerResultSet = getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_COLUMNS, arrayOfString, getColumnsColumnNamesKatmai);
    } else {
      sQLServerResultSet = getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_COLUMNS, arrayOfString, getColumnsColumnNames);
    } 

    
    sQLServerResultSet.getColumn(5).setFilter(new DataTypeFilter());
    
    if (this.connection.isKatmaiOrLater()) {
      
      sQLServerResultSet.getColumn(22).setFilter(new IntColumnIdentityFilter());
      sQLServerResultSet.getColumn(7).setFilter(new ZeroFixupFilter());
      sQLServerResultSet.getColumn(8).setFilter(new ZeroFixupFilter());
      sQLServerResultSet.getColumn(16).setFilter(new ZeroFixupFilter());
    } 
    return sQLServerResultSet;
  }
  
  private static final String[] getFunctionsColumnNames = new String[] { "FUNCTION_CAT", "FUNCTION_SCHEM", "FUNCTION_NAME", "NUM_INPUT_PARAMS", "NUM_OUTPUT_PARAMS", "NUM_RESULT_SETS", "REMARKS", "FUNCTION_TYPE" };












  
  public ResultSet getFunctions(String paramString1, String paramString2, String paramString3) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    checkClosed();






    
    if (paramString1 != null && paramString1.length() == 0) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
      Object[] arrayOfObject = { "catalog" };
      SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), null, false);
    } 
    
    String[] arrayOfString = new String[3];
    arrayOfString[0] = EscapeIDName(paramString3);
    arrayOfString[1] = EscapeIDName(paramString2);
    arrayOfString[2] = paramString1;
    return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_STORED_PROCEDURES, arrayOfString, getFunctionsColumnNames);
  }
  
  private static final String[] getFunctionsColumnsColumnNames = new String[] { "FUNCTION_CAT", "FUNCTION_SCHEM", "FUNCTION_NAME", "COLUMN_NAME", "COLUMN_TYPE", "DATA_TYPE", "TYPE_NAME", "PRECISION", "LENGTH", "SCALE", "RADIX", "NULLABLE", "REMARKS", "COLUMN_DEF", "SQL_DATA_TYPE", "SQL_DATETIME_SUB", "CHAR_OCTET_LENGTH", "ORDINAL_POSITION", "IS_NULLABLE" };























  
  public ResultSet getFunctionColumns(String paramString1, String paramString2, String paramString3, String paramString4) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    checkClosed();







    
    if (paramString1 != null && paramString1.length() == 0) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
      Object[] arrayOfObject = { "catalog" };
      SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), null, false);
    } 
    
    String[] arrayOfString = new String[5];

    
    arrayOfString[0] = EscapeIDName(paramString3);
    
    arrayOfString[1] = EscapeIDName(paramString2);
    arrayOfString[2] = paramString1;
    
    arrayOfString[3] = EscapeIDName(paramString4);
    arrayOfString[4] = "3";
    SQLServerResultSet sQLServerResultSet = getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_SPROC_COLUMNS, arrayOfString, getFunctionsColumnsColumnNames);



    
    sQLServerResultSet.getColumn(6).setFilter(new DataTypeFilter());
    
    if (this.connection.isKatmaiOrLater()) {
      
      sQLServerResultSet.getColumn(8).setFilter(new ZeroFixupFilter());
      sQLServerResultSet.getColumn(9).setFilter(new ZeroFixupFilter());
      sQLServerResultSet.getColumn(17).setFilter(new ZeroFixupFilter());
    } 
    return sQLServerResultSet;
  }


  
  public ResultSet getClientInfoProperties() throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    checkClosed();
    return getResultSetFromInternalQueries(null, "SELECT cast(NULL as char(1)) as NAME, cast(0 as int) as MAX_LEN, cast(NULL as char(1)) as DEFAULT_VALUE, cast(NULL as char(1)) as DESCRIPTION  where 0 = 1");
  }






  
  private static final String[] getBestRowIdentifierColumnNames = new String[] { "SCOPE", "COLUMN_NAME", "DATA_TYPE", "TYPE_NAME", "COLUMN_SIZE", "BUFFER_LENGTH", "DECIMAL_DIGITS", "PSEUDO_COLUMN" };












  
  public ResultSet getBestRowIdentifier(String paramString1, String paramString2, String paramString3, int paramInt, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();








    
    String[] arrayOfString = new String[7];
    arrayOfString[0] = paramString3;
    arrayOfString[1] = paramString2;
    arrayOfString[2] = paramString1;
    arrayOfString[3] = "R";
    if (0 == paramInt) {
      arrayOfString[4] = "C";
    } else {
      arrayOfString[4] = "T";
    }  if (paramBoolean) {
      arrayOfString[5] = "U";
    } else {
      arrayOfString[5] = "O";
    }  arrayOfString[6] = "3";
    SQLServerResultSet sQLServerResultSet = getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_SPECIAL_COLUMNS, arrayOfString, getBestRowIdentifierColumnNames);



    
    sQLServerResultSet.getColumn(3).setFilter(new DataTypeFilter());
    return sQLServerResultSet;
  }
  
  private static final String[] pkfkColumnNames = new String[] { "PKTABLE_CAT", "PKTABLE_SCHEM", "PKTABLE_NAME", "PKCOLUMN_NAME", "FKTABLE_CAT", "FKTABLE_SCHEM", "FKTABLE_NAME", "FKCOLUMN_NAME", "KEY_SEQ", "UPDATE_RULE", "DELETE_RULE", "FK_NAME", "PK_NAME", "DEFERRABILITY" };



















  
  public ResultSet getCrossReference(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();






    
    String[] arrayOfString = new String[6];
    arrayOfString[0] = paramString3;
    arrayOfString[1] = paramString2;
    arrayOfString[2] = paramString1;
    arrayOfString[3] = paramString6;
    arrayOfString[4] = paramString5;
    arrayOfString[5] = paramString4;
    
    return getResultSetWithProvidedColumnNames(null, CallableHandles.SP_FKEYS, arrayOfString, pkfkColumnNames);
  }
  
  public String getDatabaseProductName() throws SQLServerException {
    checkClosed();
    return "Microsoft SQL Server";
  }
  
  public String getDatabaseProductVersion() throws SQLServerException {
    checkClosed();
    return this.connection.sqlServerVersion;
  }

  
  public int getDefaultTransactionIsolation() throws SQLServerException {
    checkClosed();
    return 2;
  }

  
  public int getDriverMajorVersion() {
    return 6;
  }

  
  public int getDriverMinorVersion() {
    return 0;
  }
  
  public String getDriverName() throws SQLServerException {
    checkClosed();
    return "Microsoft JDBC Driver 6.0 for SQL Server";
  }




  
  public String getDriverVersion() throws SQLServerException {
    int i = getDriverMinorVersion();
    String str = getDriverMajorVersion() + ".";
    str = str + "" + i;
    str = str + ".";
    str = str + 'ᾰ';
    str = str + ".";
    str = str + 'È';
    return str;
  }


  
  public ResultSet getExportedKeys(String paramString1, String paramString2, String paramString3) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();






    
    String[] arrayOfString = new String[6];
    arrayOfString[0] = paramString3;
    arrayOfString[1] = paramString2;
    arrayOfString[2] = paramString1;
    arrayOfString[3] = null;
    arrayOfString[4] = null;
    arrayOfString[5] = null;
    return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_FKEYS, arrayOfString, pkfkColumnNames);
  }
  
  public String getExtraNameCharacters() throws SQLServerException {
    checkClosed();
    return "$#@";
  }

  
  public String getIdentifierQuoteString() throws SQLServerException {
    checkClosed();
    return "\"";
  }

  
  public ResultSet getImportedKeys(String paramString1, String paramString2, String paramString3) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();






    
    String[] arrayOfString = new String[6];
    arrayOfString[0] = null;
    arrayOfString[1] = null;
    arrayOfString[2] = null;
    arrayOfString[3] = paramString3;
    arrayOfString[4] = paramString2;
    arrayOfString[5] = paramString1;
    return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_FKEYS, arrayOfString, pkfkColumnNames);
  }
  
  private static final String[] getIndexInfoColumnNames = new String[] { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "NON_UNIQUE", "INDEX_QUALIFIER", "INDEX_NAME", "TYPE", "ORDINAL_POSITION", "COLUMN_NAME", "ASC_OR_DESC", "CARDINALITY", "PAGES", "FILTER_CONDITION" };

















  
  public ResultSet getIndexInfo(String paramString1, String paramString2, String paramString3, boolean paramBoolean1, boolean paramBoolean2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();





    
    String[] arrayOfString = new String[6];
    arrayOfString[0] = paramString3;
    arrayOfString[1] = paramString2;
    arrayOfString[2] = paramString1;
    
    arrayOfString[3] = "%";
    if (paramBoolean1) {
      arrayOfString[4] = "Y";
    } else {
      arrayOfString[4] = "N";
    }  if (paramBoolean2) {
      arrayOfString[5] = "Q";
    } else {
      arrayOfString[5] = "E";
    }  return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_STATISTICS, arrayOfString, getIndexInfoColumnNames);
  }
  
  public int getMaxBinaryLiteralLength() throws SQLServerException {
    checkClosed();
    return 0;
  }
  
  public int getMaxCatalogNameLength() throws SQLServerException {
    checkClosed();
    return 128;
  }
  
  public int getMaxCharLiteralLength() throws SQLServerException {
    checkClosed();
    return 0;
  }
  
  public int getMaxColumnNameLength() throws SQLServerException {
    checkClosed();
    return 128;
  }
  
  public int getMaxColumnsInGroupBy() throws SQLServerException {
    checkClosed();
    return 0;
  }
  
  public int getMaxColumnsInIndex() throws SQLServerException {
    checkClosed();
    return 16;
  }
  
  public int getMaxColumnsInOrderBy() throws SQLServerException {
    checkClosed();
    return 0;
  }
  
  public int getMaxColumnsInSelect() throws SQLServerException {
    checkClosed();
    return 4096;
  }
  
  public int getMaxColumnsInTable() throws SQLServerException {
    checkClosed();
    return 1024;
  }

  
  public int getMaxConnections() throws SQLServerException {
    checkClosed();
    
    try {
      String str = "sp_configure 'user connections'";
      SQLServerResultSet sQLServerResultSet = getResultSetFromInternalQueries(null, str);
      if (!sQLServerResultSet.next())
        return 0; 
      return sQLServerResultSet.getInt("maximum");
    }
    catch (SQLServerException sQLServerException) {
      
      return 0;
    } 
  }


  
  public int getMaxCursorNameLength() throws SQLServerException {
    checkClosed();
    return 0;
  }
  
  public int getMaxIndexLength() throws SQLServerException {
    checkClosed();
    return 900;
  }
  
  public int getMaxProcedureNameLength() throws SQLServerException {
    checkClosed();
    return 128;
  }
  
  public int getMaxRowSize() throws SQLServerException {
    checkClosed();
    return 8060;
  }
  
  public int getMaxSchemaNameLength() throws SQLServerException {
    checkClosed();
    return 128;
  }
  
  public int getMaxStatementLength() throws SQLServerException {
    checkClosed();




    
    return 65536 * this.connection.getTDSPacketSize();
  }
  
  public int getMaxStatements() throws SQLServerException {
    checkClosed();
    return 0;
  }
  
  public int getMaxTableNameLength() throws SQLServerException {
    checkClosed();
    return 128;
  }
  
  public int getMaxTablesInSelect() throws SQLServerException {
    checkClosed();
    return 256;
  }
  
  public int getMaxUserNameLength() throws SQLServerException {
    checkClosed();
    return 128;
  }
  
  public String getNumericFunctions() throws SQLServerException {
    checkClosed();
    return "ABS,ACOS,ASIN,ATAN,ATAN2,CEILING,COS,COT,DEGREES,EXP, FLOOR,LOG,LOG10,MOD,PI,POWER,RADIANS,RAND,ROUND,SIGN,SIN,SQRT,TAN,TRUNCATE";
  }
  
  private static final String[] getPrimaryKeysColumnNames = new String[] { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "COLUMN_NAME", "KEY_SEQ", "PK_NAME" };










  
  public ResultSet getPrimaryKeys(String paramString1, String paramString2, String paramString3) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();




    
    String[] arrayOfString = new String[3];
    arrayOfString[0] = paramString3;
    arrayOfString[1] = paramString2;
    arrayOfString[2] = paramString1;
    return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_PKEYS, arrayOfString, getPrimaryKeysColumnNames);
  }
  
  private static final String[] getProcedureColumnsColumnNames = new String[] { "PROCEDURE_CAT", "PROCEDURE_SCHEM", "PROCEDURE_NAME", "COLUMN_NAME", "COLUMN_TYPE", "DATA_TYPE", "TYPE_NAME", "PRECISION", "LENGTH", "SCALE", "RADIX", "NULLABLE", "REMARKS", "COLUMN_DEF", "SQL_DATA_TYPE", "SQL_DATETIME_SUB", "CHAR_OCTET_LENGTH", "ORDINAL_POSITION", "IS_NULLABLE" };























  
  public ResultSet getProcedureColumns(String paramString1, String paramString2, String paramString3, String paramString4) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();






    
    String[] arrayOfString = new String[5];

    
    paramString3 = EscapeIDName(paramString3);
    arrayOfString[0] = paramString3;
    arrayOfString[1] = paramString2;
    arrayOfString[2] = paramString1;
    
    paramString4 = EscapeIDName(paramString4);
    arrayOfString[3] = paramString4;
    arrayOfString[4] = "3";
    SQLServerResultSet sQLServerResultSet = getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_SPROC_COLUMNS, arrayOfString, getProcedureColumnsColumnNames);



    
    sQLServerResultSet.getColumn(6).setFilter(new DataTypeFilter());
    if (this.connection.isKatmaiOrLater()) {
      
      sQLServerResultSet.getColumn(8).setFilter(new ZeroFixupFilter());
      sQLServerResultSet.getColumn(9).setFilter(new ZeroFixupFilter());
      sQLServerResultSet.getColumn(17).setFilter(new ZeroFixupFilter());
    } 
    
    return sQLServerResultSet;
  }
  
  private static final String[] getProceduresColumnNames = new String[] { "PROCEDURE_CAT", "PROCEDURE_SCHEM", "PROCEDURE_NAME", "NUM_INPUT_PARAMS", "NUM_OUTPUT_PARAMS", "NUM_RESULT_SETS", "REMARKS", "PROCEDURE_TYPE" };












  
  public ResultSet getProcedures(String paramString1, String paramString2, String paramString3) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    
    checkClosed();




    
    String[] arrayOfString = new String[3];
    arrayOfString[0] = EscapeIDName(paramString3);
    arrayOfString[1] = paramString2;
    arrayOfString[2] = paramString1;
    return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_STORED_PROCEDURES, arrayOfString, getProceduresColumnNames);
  }
  
  public String getProcedureTerm() throws SQLServerException {
    checkClosed();
    return "stored procedure";
  }


  
  public ResultSet getPseudoColumns(String paramString1, String paramString2, String paramString3, String paramString4) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC41();
    
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    
    checkClosed();



    
    return getResultSetFromInternalQueries(paramString1, "SELECT cast(NULL as char(1)) as TABLE_CAT, cast(NULL as char(1)) as TABLE_SCHEM, cast(NULL as char(1)) as TABLE_NAME, cast(NULL as char(1)) as COLUMN_NAME, cast(0 as int) as DATA_TYPE, cast(0 as int) as COLUMN_SIZE, cast(0 as int) as DECIMAL_DIGITS, cast(0 as int) as NUM_PREC_RADIX, cast(NULL as char(1)) as COLUMN_USAGE, cast(NULL as char(1)) as REMARKS, cast(0 as int) as CHAR_OCTET_LENGTH, cast(NULL as char(1)) as IS_NULLABLE where 0 = 1");
  }















  
  public ResultSet getSchemas() throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();
    return getSchemasInternal(null, null);
  }




  
  private ResultSet getSchemasInternal(String paramString1, String paramString2) throws SQLServerException {
    SQLServerResultSet sQLServerResultSet;
    String str2 = " ('dbo', 'guest','INFORMATION_SCHEMA','sys','db_owner', 'db_accessadmin', 'db_securityadmin', 'db_ddladmin'  ,'db_backupoperator','db_datareader','db_datawriter','db_denydatareader','db_denydatawriter') ";

    
    String str3 = "sys.schemas";
    String str4 = "sys.schemas.name";
    if (null != paramString1 && paramString1.length() != 0) {
      
      str3 = paramString1 + "." + str3;
      str4 = paramString1 + "." + str4;
    } 


    
    String str1 = "select " + str4 + " 'TABLE_SCHEM',";
    if (null != paramString1 && paramString1.length() == 0) {
      
      str1 = str1 + "null 'TABLE_CATALOG' ";
    }
    else {
      
      str1 = str1 + " CASE WHEN " + str4 + "  IN " + str2 + " THEN null ELSE ";
      
      if (null != paramString1 && paramString1.length() != 0) {
        
        str1 = str1 + "'" + paramString1 + "' ";
      } else {
        
        str1 = str1 + " DB_NAME() ";
      } 
      str1 = str1 + " END 'TABLE_CATALOG' ";
    } 
    str1 = str1 + "   from " + str3;


    
    if (null != paramString1 && paramString1.length() == 0) {
      
      if (null != paramString2) {
        str1 = str1 + " where " + str4 + " like ?  and ";
      } else {
        str1 = str1 + " where ";
      }  str1 = str1 + str4 + " in " + str2;
    
    }
    else if (null != paramString2) {
      str1 = str1 + " where " + str4 + " like ?  ";
    } 
    str1 = str1 + " order by 2, 1";
    if (logger.isLoggable(Level.FINE))
    {
      logger.fine(toString() + " schema query (" + str1 + ")");
    }
    
    if (null == paramString2) {
      
      paramString1 = null;
      sQLServerResultSet = getResultSetFromInternalQueries(paramString1, str1);

    
    }
    else {


      
      SQLServerPreparedStatement sQLServerPreparedStatement = (SQLServerPreparedStatement)this.connection.prepareStatement(str1);
      sQLServerPreparedStatement.setString(1, paramString2);
      sQLServerResultSet = (SQLServerResultSet)sQLServerPreparedStatement.executeQueryInternal();
    } 
    return sQLServerResultSet;
  }

  
  public ResultSet getSchemas(String paramString1, String paramString2) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    DriverJDBCVersion.checkSupportsJDBC4();
    return getSchemasInternal(paramString1, paramString2);
  }
  
  public String getSchemaTerm() throws SQLServerException {
    checkClosed();
    return "schema";
  }
  
  public String getSearchStringEscape() throws SQLServerException {
    checkClosed();
    return "\\";
  }
  
  public String getSQLKeywords() throws SQLServerException {
    checkClosed();
    return "BACKUP,BREAK,BROWSE,BULK,CHECKPOINT,CLUSTERED,COMPUTE,CONTAINS,CONTAINSTABLE,DATABASE,DBCC,DENY,DISK,DISTRIBUTED,DUMMY,DUMP,ERRLVL,EXIT,FILE,FILLFACTOR,FREETEXT,FREETEXTTABLE,FUNCTION,HOLDLOCK,IDENTITY_INSERT,IDENTITYCOL,IF,KILL,LINENO,LOAD,NOCHECK,NONCLUSTERED,OFF,OFFSETS,OPENDATASOURCE,OPENQUERY,OPENROWSET,OPENXML,OVER,PERCENT,PLAN,PRINT,PROC,RAISERROR,READTEXT,RECONFIGURE,REPLICATION,RESTORE,RETURN,ROWCOUNT,ROWGUIDCOL,RULE,SAVE,SETUSER,SHUTDOWN,STATISTICS,TEXTSIZE,TOP,TRAN,TRIGGER,TRUNCATE,TSEQUAL,UPDATETEXT,USE,WAITFOR,WHILE,WRITETEXT";
  }
  
  public String getStringFunctions() throws SQLServerException {
    checkClosed();
    return "ASCII,CHAR,CONCAT, DIFFERENCE,INSERT,LCASE,LEFT,LENGTH,LOCATE,LTRIM,REPEAT,REPLACE,RIGHT,RTRIM,SOUNDEX,SPACE,SUBSTRING,UCASE";
  }
  
  public String getSystemFunctions() throws SQLServerException {
    checkClosed();
    return "DATABASE,IFNULL,USER";
  }
  
  private static final String[] getTablePrivilegesColumnNames = new String[] { "TABLE_CAT", "TABLE_SCHEM", "TABLE_NAME", "GRANTOR", "GRANTEE", "PRIVILEGE", "IS_GRANTABLE" };










  
  public ResultSet getTablePrivileges(String paramString1, String paramString2, String paramString3) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();
    paramString3 = EscapeIDName(paramString3);
    paramString2 = EscapeIDName(paramString2);




    
    String[] arrayOfString = new String[3];
    arrayOfString[0] = paramString3;
    arrayOfString[1] = paramString2;
    arrayOfString[2] = paramString1;
    
    return getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_TABLE_PRIVILEGES, arrayOfString, getTablePrivilegesColumnNames);
  }

  
  public ResultSet getTableTypes() throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();
    String str = "SELECT 'VIEW' 'TABLE_TYPE' UNION SELECT 'TABLE' UNION SELECT 'SYSTEM TABLE'";
    return getResultSetFromInternalQueries(null, str);
  }

  
  public String getTimeDateFunctions() throws SQLServerException {
    checkClosed();
    return "CURDATE,CURTIME,DAYNAME,DAYOFMONTH,DAYOFWEEK,DAYOFYEAR,HOUR,MINUTE,MONTH,MONTHNAME,NOW,QUARTER,SECOND,TIMESTAMPADD,TIMESTAMPDIFF,WEEK,YEAR";
  }
  
  public ResultSet getTypeInfo() throws SQLServerException {
    SQLServerResultSet sQLServerResultSet;
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();


    
    if (this.connection.isKatmaiOrLater()) {
      sQLServerResultSet = getResultSetFromInternalQueries(null, "sp_datatype_info_100 @ODBCVer=3");
    } else {
      sQLServerResultSet = getResultSetFromInternalQueries(null, "sp_datatype_info @ODBCVer=3");
    } 
    sQLServerResultSet.setColumnName(11, "FIXED_PREC_SCALE");


    
    sQLServerResultSet.getColumn(2).setFilter(new DataTypeFilter());
    return sQLServerResultSet;
  }

  
  public String getURL() throws SQLServerException {
    checkClosed();
    
    StringBuilder stringBuilder = new StringBuilder();
    
    Properties properties = this.connection.activeConnectionProperties;
    DriverPropertyInfo[] arrayOfDriverPropertyInfo = SQLServerDriver.getPropertyInfoFromProperties(properties);
    String str1 = null;
    String str2 = null;
    String str3 = null;


    
    int i = arrayOfDriverPropertyInfo.length;
    while (--i >= 0) {
      
      String str = (arrayOfDriverPropertyInfo[i]).name;

      
      if (!str.equals(SQLServerDriverBooleanProperty.INTEGRATED_SECURITY.toString()) && !str.equals(SQLServerDriverStringProperty.USER.toString()) && !str.equals(SQLServerDriverStringProperty.PASSWORD.toString()) && !str.equals(SQLServerDriverStringProperty.KEY_STORE_SECRET.toString())) {




        
        String str4 = (arrayOfDriverPropertyInfo[i]).value;
        
        if (0 != str4.length()) {

          
          if (str.equals(SQLServerDriverStringProperty.SERVER_NAME.toString())) {
            
            str1 = str4; continue;
          } 
          if (str.equals(SQLServerDriverStringProperty.INSTANCE_NAME.toString())) {
            
            str3 = str4; continue;
          } 
          if (str.equals(SQLServerDriverIntProperty.PORT_NUMBER.toString())) {
            
            str2 = str4;
            
            continue;
          } 
          
          stringBuilder.append(str);
          stringBuilder.append("=");
          stringBuilder.append(str4);
          stringBuilder.append(";");
        } 
      } 
    } 





    
    stringBuilder.insert(0, ";");
    stringBuilder.insert(0, str2);
    stringBuilder.insert(0, ":");
    if (null != str3) {
      
      stringBuilder.insert(0, str3);
      stringBuilder.insert(0, "\\");
    } 
    stringBuilder.insert(0, str1);
    
    stringBuilder.insert(0, "jdbc:sqlserver://");
    return stringBuilder.toString();
  }
  
  public String getUserName() throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();
    SQLServerStatement sQLServerStatement = null;
    SQLServerResultSet sQLServerResultSet = null;
    String str = "";
    
    try {
      sQLServerStatement = (SQLServerStatement)this.connection.createStatement();
      sQLServerResultSet = sQLServerStatement.executeQueryInternal("select system_user");
      
      boolean bool = sQLServerResultSet.next();
      assert bool;
      
      str = sQLServerResultSet.getString(1);
    } finally {
      
      if (sQLServerResultSet != null) {
        sQLServerResultSet.close();
      }
      if (sQLServerStatement != null) {
        sQLServerStatement.close();
      }
    } 
    return str;
  }
  
  private static final String[] getVersionColumnsColumnNames = new String[] { "SCOPE", "COLUMN_NAME", "DATA_TYPE", "TYPE_NAME", "COLUMN_SIZE", "BUFFER_LENGTH", "DECIMAL_DIGITS", "PSEUDO_COLUMN" };












  
  public ResultSet getVersionColumns(String paramString1, String paramString2, String paramString3) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();






    
    String[] arrayOfString = new String[7];
    arrayOfString[0] = paramString3;
    arrayOfString[1] = paramString2;
    arrayOfString[2] = paramString1;
    arrayOfString[3] = "V";
    arrayOfString[4] = "T";
    arrayOfString[5] = "U";
    arrayOfString[6] = "3";
    SQLServerResultSet sQLServerResultSet = getResultSetWithProvidedColumnNames(paramString1, CallableHandles.SP_SPECIAL_COLUMNS, arrayOfString, getVersionColumnsColumnNames);



    
    sQLServerResultSet.getColumn(3).setFilter(new DataTypeFilter());
    return sQLServerResultSet;
  }
  
  public boolean isCatalogAtStart() throws SQLServerException {
    checkClosed();
    return true;
  }
  
  public boolean isReadOnly() throws SQLServerException {
    checkClosed();
    return false;
  }
  
  public boolean nullPlusNonNullIsNull() throws SQLServerException {
    checkClosed();
    return true;
  }
  
  public boolean nullsAreSortedAtEnd() throws SQLServerException {
    checkClosed();
    return false;
  }
  
  public boolean nullsAreSortedAtStart() throws SQLServerException {
    checkClosed();
    return false;
  }
  
  public boolean nullsAreSortedHigh() throws SQLServerException {
    checkClosed();
    return false;
  }
  
  public boolean nullsAreSortedLow() throws SQLServerException {
    checkClosed();
    return true;
  }
  public boolean storesLowerCaseIdentifiers() throws SQLServerException {
    checkClosed();
    return false;
  }
  
  public boolean storesLowerCaseQuotedIdentifiers() throws SQLServerException {
    checkClosed();
    return false;
  }
  
  public boolean storesMixedCaseIdentifiers() throws SQLServerException {
    checkClosed();
    return true;
  }
  
  public boolean storesMixedCaseQuotedIdentifiers() throws SQLServerException {
    checkClosed();
    return true;
  }
  
  public boolean storesUpperCaseIdentifiers() throws SQLServerException {
    checkClosed();
    return false;
  }
  
  public boolean storesUpperCaseQuotedIdentifiers() throws SQLServerException {
    checkClosed();
    return false;
  }
  
  public boolean supportsAlterTableWithAddColumn() throws SQLServerException {
    checkClosed();
    return true;
  }
  
  public boolean supportsAlterTableWithDropColumn() throws SQLServerException {
    checkClosed();
    return true;
  }
  
  public boolean supportsANSI92EntryLevelSQL() throws SQLServerException {
    checkClosed();
    return true;
  }
  
  public boolean supportsANSI92FullSQL() throws SQLServerException {
    checkClosed(); return false;
  }
  
  public boolean supportsANSI92IntermediateSQL() throws SQLServerException {
    checkClosed(); return false;
  }
  
  public boolean supportsCatalogsInDataManipulation() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsCatalogsInIndexDefinitions() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsCatalogsInPrivilegeDefinitions() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsCatalogsInProcedureCalls() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsCatalogsInTableDefinitions() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsColumnAliasing() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsConvert() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsConvert(int paramInt1, int paramInt2) throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsCoreSQLGrammar() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsCorrelatedSubqueries() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsDataDefinitionAndDataManipulationTransactions() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsDataManipulationTransactionsOnly() throws SQLServerException {
    checkClosed(); return false;
  }
  
  public boolean supportsDifferentTableCorrelationNames() throws SQLServerException {
    checkClosed(); return false;
  }
  
  public boolean supportsExpressionsInOrderBy() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsExtendedSQLGrammar() throws SQLServerException {
    checkClosed(); return false;
  }
  
  public boolean supportsFullOuterJoins() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsGroupBy() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsGroupByBeyondSelect() throws SQLServerException {
    checkClosed();
    return true;
  }
  
  public boolean supportsGroupByUnrelated() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsIntegrityEnhancementFacility() throws SQLServerException {
    checkClosed();
    return false;
  }

  
  public boolean supportsLikeEscapeClause() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsLimitedOuterJoins() throws SQLServerException {
    checkClosed();
    return true;
  }
  
  public boolean supportsMinimumSQLGrammar() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsMixedCaseIdentifiers() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsMixedCaseQuotedIdentifiers() throws SQLServerException {
    checkClosed();
    return true;
  }
  
  public boolean supportsMultipleResultSets() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsMultipleTransactions() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsNonNullableColumns() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsOpenCursorsAcrossCommit() throws SQLServerException {
    checkClosed();
    return false;
  }
  
  public boolean supportsOpenCursorsAcrossRollback() throws SQLServerException {
    checkClosed();
    return false;
  }
  public boolean supportsOpenStatementsAcrossCommit() throws SQLServerException {
    checkClosed();
    return true;
  }
  
  public boolean supportsOpenStatementsAcrossRollback() throws SQLServerException {
    checkClosed();
    return true;
  }
  
  public boolean supportsOrderByUnrelated() throws SQLServerException {
    checkClosed();
    return true;
  }
  
  public boolean supportsOuterJoins() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsPositionedDelete() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsPositionedUpdate() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsSchemasInDataManipulation() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsSchemasInIndexDefinitions() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsSchemasInPrivilegeDefinitions() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsSchemasInProcedureCalls() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsSchemasInTableDefinitions() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsSelectForUpdate() throws SQLServerException {
    checkClosed();
    return false;
  }
  
  public boolean supportsStoredProcedures() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsSubqueriesInComparisons() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsSubqueriesInExists() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsSubqueriesInIns() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsSubqueriesInQuantifieds() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsTableCorrelationNames() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsTransactionIsolationLevel(int paramInt) throws SQLServerException {
    checkClosed();
    switch (paramInt) {
      
      case 1:
      case 2:
      case 4:
      case 8:
      case 4096:
        return true;
    } 
    return false;
  }
  
  public boolean supportsTransactions() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsUnion() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsUnionAll() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean usesLocalFilePerTable() throws SQLServerException {
    checkClosed(); return false;
  }
  
  public boolean usesLocalFiles() throws SQLServerException {
    checkClosed(); return false;
  }
  
  public boolean supportsResultSetType(int paramInt) throws SQLServerException {
    checkClosed();
    checkResultType(paramInt);
    switch (paramInt) {


      
      case 1003:
      case 1004:
      case 1005:
      case 1006:
      case 2003:
      case 2004:
        return true;
    } 
    return false;
  }

  
  public boolean supportsResultSetConcurrency(int paramInt1, int paramInt2) throws SQLServerException {
    checkClosed();
    checkResultType(paramInt1);
    checkConcurrencyType(paramInt2);
    switch (paramInt1) {

      
      case 1003:
      case 1005:
      case 1006:
      case 2004:
        return true;
      
      case 1004:
      case 2003:
        if (1007 == paramInt2) {
          return true;
        }
        return false;
    } 
    
    return false;
  }
  
  public boolean ownUpdatesAreVisible(int paramInt) throws SQLServerException {
    checkClosed();
    checkResultType(paramInt);
    if (paramInt == 1006 || 1003 == paramInt || 1005 == paramInt || 1005 == paramInt || 2004 == paramInt)
    {
      
      return true; } 
    return false;
  }
  
  public boolean ownDeletesAreVisible(int paramInt) throws SQLServerException {
    checkClosed();
    checkResultType(paramInt);
    if (paramInt == 1006 || 1003 == paramInt || 1005 == paramInt || 1005 == paramInt || 2004 == paramInt)
    {
      
      return true; } 
    return false;
  }
  
  public boolean ownInsertsAreVisible(int paramInt) throws SQLServerException {
    checkClosed();
    checkResultType(paramInt);
    if (paramInt == 1006 || 1003 == paramInt || 1005 == paramInt || 1005 == paramInt || 2004 == paramInt)
    {
      
      return true; } 
    return false;
  }
  
  public boolean othersUpdatesAreVisible(int paramInt) throws SQLServerException {
    checkClosed();
    checkResultType(paramInt);
    if (paramInt == 1006 || 1003 == paramInt || 1005 == paramInt || 1005 == paramInt || 2004 == paramInt)
    {
      
      return true; } 
    return false;
  }
  
  public boolean othersDeletesAreVisible(int paramInt) throws SQLServerException {
    checkClosed();
    checkResultType(paramInt);
    if (paramInt == 1006 || 1003 == paramInt || 1005 == paramInt || 1005 == paramInt || 2004 == paramInt)
    {
      
      return true; } 
    return false;
  }
  
  public boolean othersInsertsAreVisible(int paramInt) throws SQLServerException {
    checkClosed();
    checkResultType(paramInt);
    if (paramInt == 1006 || 1003 == paramInt || 2004 == paramInt)
    {
      return true; } 
    return false;
  }
  
  public boolean updatesAreDetected(int paramInt) throws SQLServerException {
    checkClosed();
    checkResultType(paramInt);
    return false;
  }

  
  public boolean deletesAreDetected(int paramInt) throws SQLServerException {
    checkClosed();
    checkResultType(paramInt);
    if (1005 == paramInt) {
      return true;
    }
    return false;
  }


  
  private void checkResultType(int paramInt) throws SQLServerException {
    switch (paramInt) {
      case 1003:
      case 1004:
      case 1005:
      case 1006:
      case 2003:
      case 2004:
        return;
    } 



    
    MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
    Object[] arrayOfObject = { new Integer(paramInt) };
    throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, true);
  }


  
  private void checkConcurrencyType(int paramInt) throws SQLServerException {
    switch (paramInt) {
      case 1007:
      case 1008:
      case 1009:
      case 1010:
        return;
    } 


    
    MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
    Object[] arrayOfObject = { new Integer(paramInt) };
    throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, true);
  }


  
  public boolean insertsAreDetected(int paramInt) throws SQLServerException {
    checkClosed();
    checkResultType(paramInt);
    return false;
  }
  
  public boolean supportsBatchUpdates() throws SQLServerException {
    checkClosed();
    return true;
  }

  
  public ResultSet getUDTs(String paramString1, String paramString2, String paramString3, int[] paramArrayOfint) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();
    return getResultSetFromInternalQueries(paramString1, "SELECT cast(NULL as char(1)) as TYPE_CAT, cast(NULL as char(1)) as TYPE_SCHEM, cast(NULL as char(1)) as TYPE_NAME, cast(NULL as char(1)) as CLASS_NAME, cast(0 as int) as DATA_TYPE, cast(NULL as char(1)) as REMARKS, cast(0 as smallint) as BASE_TYPE where 0 = 1");
  }









  
  public Connection getConnection() throws SQLServerException {
    checkClosed();
    return this.connection.getConnection();
  }



  
  public int getSQLStateType() throws SQLServerException {
    checkClosed();
    if (this.connection != null && this.connection.xopenStates) {
      return 1;
    }
    return 2;
  }
  
  public int getDatabaseMajorVersion() throws SQLServerException {
    checkClosed();
    String str = this.connection.sqlServerVersion;
    int i = str.indexOf('.');
    if (i > 0)
      str = str.substring(0, i); 
    try {
      return (new Integer(str)).intValue();
    }
    catch (NumberFormatException numberFormatException) {
      return 0;
    } 
  }
  
  public int getDatabaseMinorVersion() throws SQLServerException {
    checkClosed();
    String str = this.connection.sqlServerVersion;
    int i = str.indexOf('.');
    int j = str.indexOf('.', i + 1);
    if (i > 0 && j > 0)
      str = str.substring(i + 1, j); 
    try {
      return (new Integer(str)).intValue();
    }
    catch (NumberFormatException numberFormatException) {
      return 0;
    } 
  }
  
  public int getJDBCMajorVersion() throws SQLServerException {
    checkClosed();
    return 4;
  }
  public int getJDBCMinorVersion() throws SQLServerException {
    checkClosed();
    return 1;
  }
  
  public int getResultSetHoldability() throws SQLServerException {
    checkClosed(); return 1;
  }

  
  public RowIdLifetime getRowIdLifetime() throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    checkClosed();
    return RowIdLifetime.ROWID_UNSUPPORTED;
  }

  
  public boolean supportsResultSetHoldability(int paramInt) throws SQLServerException {
    checkClosed();
    if (1 == paramInt || 2 == paramInt)
    {
      return true;
    }

    
    MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
    Object[] arrayOfObject = { new Integer(paramInt) };
    throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, true);
  }

  
  public ResultSet getAttributes(String paramString1, String paramString2, String paramString3, String paramString4) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();
    return getResultSetFromInternalQueries(paramString1, "SELECT cast(NULL as char(1)) as TYPE_CAT, cast(NULL as char(1)) as TYPE_SCHEM, cast(NULL as char(1)) as TYPE_NAME, cast(NULL as char(1)) as ATTR_NAME, cast(0 as int) as DATA_TYPE, cast(NULL as char(1)) as ATTR_TYPE_NAME, cast(0 as int) as ATTR_SIZE, cast(0 as int) as DECIMAL_DIGITS, cast(0 as int) as NUM_PREC_RADIX, cast(0 as int) as NULLABLE, cast(NULL as char(1)) as REMARKS, cast(NULL as char(1)) as ATTR_DEF, cast(0 as int) as SQL_DATA_TYPE, cast(0 as int) as SQL_DATETIME_SUB, cast(0 as int) as CHAR_OCTET_LENGTH, cast(0 as int) as ORDINAL_POSITION, cast(NULL as char(1)) as IS_NULLABLE, cast(NULL as char(1)) as SCOPE_CATALOG, cast(NULL as char(1)) as SCOPE_SCHEMA, cast(NULL as char(1)) as SCOPE_TABLE, cast(0 as smallint) as SOURCE_DATA_TYPE where 0 = 1");
  }























  
  public ResultSet getSuperTables(String paramString1, String paramString2, String paramString3) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();
    return getResultSetFromInternalQueries(paramString1, "SELECT cast(NULL as char(1)) as TYPE_CAT, cast(NULL as char(1)) as TYPE_SCHEM, cast(NULL as char(1)) as TYPE_NAME, cast(NULL as char(1)) as SUPERTABLE_NAME where 0 = 1");
  }






  
  public ResultSet getSuperTypes(String paramString1, String paramString2, String paramString3) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();
    return getResultSetFromInternalQueries(paramString1, "SELECT cast(NULL as char(1)) as TYPE_CAT, cast(NULL as char(1)) as TYPE_SCHEM, cast(NULL as char(1)) as TYPE_NAME, cast(NULL as char(1)) as SUPERTYPE_CAT, cast(NULL as char(1)) as SUPERTYPE_SCHEM, cast(NULL as char(1)) as SUPERTYPE_NAME where 0 = 1");
  }








  
  public boolean supportsGetGeneratedKeys() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsMultipleOpenResults() throws SQLServerException {
    checkClosed(); return false;
  }
  
  public boolean supportsNamedParameters() throws SQLServerException {
    checkClosed(); return true;
  }
  
  public boolean supportsSavepoints() throws SQLServerException {
    checkClosed(); return true;
  }
  public boolean supportsStatementPooling() throws SQLException {
    checkClosed();
    return false;
  }

  
  public boolean supportsStoredFunctionsUsingCallSyntax() throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    checkClosed();
    return true;
  }
  
  public boolean locatorsUpdateCopy() throws SQLException {
    checkClosed(); return true;
  }
}
