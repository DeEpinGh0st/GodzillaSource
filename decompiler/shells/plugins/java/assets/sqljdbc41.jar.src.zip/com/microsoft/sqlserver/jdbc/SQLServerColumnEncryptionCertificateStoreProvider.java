package com.microsoft.sqlserver.jdbc;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.MessageFormat;
import java.util.Enumeration;
import java.util.Locale;
import java.util.logging.Logger;
import javax.xml.bind.DatatypeConverter;





public final class SQLServerColumnEncryptionCertificateStoreProvider
  extends SQLServerColumnEncryptionKeyStoreProvider
{
  private static final Logger windowsCertificateStoreLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.SQLServerColumnEncryptionCertificateStoreProvider");

  
  static boolean isWindows;
  
  String name = "MSSQL_CERTIFICATE_STORE";
  
  static final String localMachineDirectory = "LocalMachine";
  
  static final String currentUserDirectory = "CurrentUser";
  static final String myCertificateStore = "My";
  
  static {
    if (System.getProperty("os.name").toLowerCase(Locale.ENGLISH).startsWith("windows")) {
      
      isWindows = true;
    }
    else {
      
      isWindows = false;
    } 
  }
  private Path keyStoreDirectoryPath = null;

  
  public SQLServerColumnEncryptionCertificateStoreProvider() {
    windowsCertificateStoreLogger.entering(SQLServerColumnEncryptionCertificateStoreProvider.class.getName(), "SQLServerColumnEncryptionCertificateStoreProvider");
  }

  
  public void setName(String paramString) {
    this.name = paramString;
  }

  
  public String getName() {
    return this.name;
  }


















  
  public byte[] encryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException {
    throw new SQLServerException(null, SQLServerException.getErrString("R_InvalidWindowsCertificateStoreEncryption"), null, 0, false);
  }








  
  private byte[] decryptColumnEncryptionKeyWindows(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException {
    try {
      return AuthenticationJNI.DecryptColumnEncryptionKey(paramString1, paramString2, paramArrayOfbyte);
    
    }
    catch (DLLException dLLException) {
      
      DLLException.buildException(dLLException.GetErrCode(), dLLException.GetParam1(), dLLException.GetParam2(), dLLException.GetParam3());
      return null;
    } 
  }



  
  private CertificateDetails getCertificateDetails(String paramString) throws SQLServerException {
    String str1 = null;
    
    String[] arrayOfString = paramString.split("/");


    
    if (arrayOfString.length > 3) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_AECertpathBad"));
      Object[] arrayOfObject = { paramString };
      throw new SQLServerException(messageFormat.format(arrayOfObject), null);
    } 

    
    if (arrayOfString.length > 2)
    {
      if (arrayOfString[0].equalsIgnoreCase("LocalMachine")) {
        
        str1 = "LocalMachine";
      }
      else if (arrayOfString[0].equalsIgnoreCase("CurrentUser")) {
        
        str1 = "CurrentUser";
      }
      else {
        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_AECertLocBad"));
        Object[] arrayOfObject = { arrayOfString[0], paramString };
        throw new SQLServerException(messageFormat.format(arrayOfObject), null);
      } 
    }

    
    if (arrayOfString.length > 1)
    {
      if (!arrayOfString[arrayOfString.length - 2].equalsIgnoreCase("My")) {
        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_AECertStoreBad"));
        Object[] arrayOfObject = { arrayOfString[arrayOfString.length - 2], paramString };
        throw new SQLServerException(messageFormat.format(arrayOfObject), null);
      } 
    }

    
    String str2 = arrayOfString[arrayOfString.length - 1];
    if (null == str2 || 0 == str2.length()) {

      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_AECertHashEmpty"));
      Object[] arrayOfObject = { paramString };
      throw new SQLServerException(messageFormat.format(arrayOfObject), null);
    } 

    
    return getCertificateByThumbprint(str1, str2, paramString);
  }

  
  private String getThumbPrint(X509Certificate paramX509Certificate) throws NoSuchAlgorithmException, CertificateEncodingException {
    MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
    byte[] arrayOfByte1 = paramX509Certificate.getEncoded();
    messageDigest.update(arrayOfByte1);
    byte[] arrayOfByte2 = messageDigest.digest();
    return DatatypeConverter.printHexBinary(arrayOfByte2);
  }


  
  private CertificateDetails getCertificateByThumbprint(String paramString1, String paramString2, String paramString3) throws SQLServerException {
    FileInputStream fileInputStream = null;
    
    if (null == this.keyStoreDirectoryPath) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_AEKeyPathEmptyOrReserved"));
      Object[] arrayOfObject = { this.keyStoreDirectoryPath };
      throw new SQLServerException(messageFormat.format(arrayOfObject), null);
    } 
    
    Path path = this.keyStoreDirectoryPath.resolve(paramString1);

    
    KeyStore keyStore = null;
    
    try {
      keyStore = KeyStore.getInstance("PKCS12");
    }
    catch (KeyStoreException keyStoreException) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_CertificateError"));
      Object[] arrayOfObject = { paramString3, this.name };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    } 
    
    File file = path.toFile();
    File[] arrayOfFile = file.listFiles();
    
    if (null == arrayOfFile || (null != arrayOfFile && 0 == arrayOfFile.length))
    {
      
      throw new SQLServerException(SQLServerException.getErrString("R_KeyStoreNotFound"), null);
    }
    
    for (File file1 : arrayOfFile) {
      
      if (!file1.isDirectory()) {




        
        char[] arrayOfChar = "".toCharArray();
        
        try {
          fileInputStream = new FileInputStream(file1);
          keyStore.load(fileInputStream, arrayOfChar);
        }
        catch (IOException|CertificateException|NoSuchAlgorithmException iOException) {}








        
        try {
          for (Enumeration<String> enumeration = keyStore.aliases(); enumeration.hasMoreElements(); ) {

            
            String str = enumeration.nextElement();
            
            X509Certificate x509Certificate = (X509Certificate)keyStore.getCertificate(str);
            
            if (paramString2.matches(getThumbPrint(x509Certificate)))
            {
              
              Key key = null;
              
              try {
                key = keyStore.getKey(str, "".toCharArray());

                
                if (null == key)
                {
                  MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_UnrecoverableKeyAE"));
                  Object[] arrayOfObject = { paramString3 };
                  throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
                }
              
              } catch (UnrecoverableKeyException|NoSuchAlgorithmException|KeyStoreException unrecoverableKeyException) {
                
                MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_UnrecoverableKeyAE"));
                Object[] arrayOfObject = { paramString3 };
                throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
              } 
              return new CertificateDetails(x509Certificate, key);
            }
          
          } 
        } catch (CertificateException|NoSuchAlgorithmException|KeyStoreException certificateException) {


          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_CertificateError"));
          
          Object[] arrayOfObject = { paramString3, this.name };
          throw new SQLServerException(messageFormat.format(arrayOfObject), certificateException);
        } 
      } 
    } 
    throw new SQLServerException(SQLServerException.getErrString("R_KeyStoreNotFound"), null);
  }


  
  private byte[] decryptColumnEncryptionKeyLinux(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException {
    KeyStoreProviderCommon.validateNonEmptyMasterKeyPath(paramString1);
    CertificateDetails certificateDetails = getCertificateDetails(paramString1);
    return KeyStoreProviderCommon.decryptColumnEncryptionKey(paramString1, paramString2, paramArrayOfbyte, certificateDetails);
  }


  
  public byte[] decryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException {
    windowsCertificateStoreLogger.entering(SQLServerColumnEncryptionCertificateStoreProvider.class.getName(), "decryptColumnEncryptionKey", "Decrypting Column Encryption Key.");
    byte[] arrayOfByte = null;
    if (isWindows) {
      
      arrayOfByte = decryptColumnEncryptionKeyWindows(paramString1, paramString2, paramArrayOfbyte);
    
    }
    else {

      
      throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), null);
    } 
    windowsCertificateStoreLogger.exiting(SQLServerColumnEncryptionCertificateStoreProvider.class.getName(), "decryptColumnEncryptionKey", "Finished decrypting Column Encryption Key.");
    return arrayOfByte;
  }
}
