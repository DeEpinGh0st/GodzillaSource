package com.microsoft.sqlserver.jdbc;

final class DateTimeFormatter extends format {}
