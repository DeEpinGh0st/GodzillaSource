package com.microsoft.sqlserver.jdbc;









public final class SQLServerDataColumn
{
  String columnName;
  int javaSqlType;
  int precision = 0;
  int scale = 0;

  
  public SQLServerDataColumn(String paramString, int paramInt) {
    this.columnName = paramString;
    this.javaSqlType = paramInt;
  }

  
  public String getColumnName() {
    return this.columnName;
  }

  
  public int getColumnType() {
    return this.javaSqlType;
  }
}
