package com.microsoft.sqlserver.jdbc;























final class UDTTDSHeader
{
  private final int maxLen;
  private final String databaseName;
  private final String schemaName;
  private final String typeName;
  private final String assemblyQualifiedName;
  
  UDTTDSHeader(TDSReader paramTDSReader) throws SQLServerException {
    this.maxLen = paramTDSReader.readUnsignedShort();
    this.databaseName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
    this.schemaName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
    this.typeName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
    this.assemblyQualifiedName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedShort());
  }
  int getMaxLen() {
    return this.maxLen;
  }
  String getTypeName() {
    return this.typeName;
  }
}
