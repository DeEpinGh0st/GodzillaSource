package com.microsoft.sqlserver.jdbc;

final class LocalDateTime extends TemporalCompatibility {}
