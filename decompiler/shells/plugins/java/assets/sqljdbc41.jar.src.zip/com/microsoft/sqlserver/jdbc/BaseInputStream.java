package com.microsoft.sqlserver.jdbc;

import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;













abstract class BaseInputStream
  extends InputStream
{
  final boolean isAdaptive;
  final boolean isStreaming;
  private String parentLoggingInfo = ""; abstract byte[] getBytes() throws SQLServerException;
  private static int lastLoggingID = 0; private static synchronized int nextLoggingID() {
    return ++lastLoggingID;
  } static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.InputStream");
  private String traceID;
  
  public final String toString() {
    if (this.traceID == null)
      this.traceID = getClass().getName() + "ID:" + nextLoggingID(); 
    return this.traceID;
  }
  
  final void setLoggingInfo(String paramString) {
    this.parentLoggingInfo = paramString;
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString());
    }
  }
  
  int streamPos = 0;
  int markedStreamPos = 0;
  TDSReaderMark currentMark;
  private ServerDTVImpl dtv;
  TDSReader tdsReader;
  int readLimit = 0;
  
  boolean isReadLimitSet = false;
  
  BaseInputStream(TDSReader paramTDSReader, boolean paramBoolean1, boolean paramBoolean2, ServerDTVImpl paramServerDTVImpl) {
    this.tdsReader = paramTDSReader;
    this.isAdaptive = paramBoolean1;
    this.isStreaming = paramBoolean2;
    
    if (paramBoolean1) {
      clearCurrentMark();
    } else {
      this.currentMark = paramTDSReader.mark();
    }  this.dtv = paramServerDTVImpl;
  }

  
  final void clearCurrentMark() {
    this.currentMark = null;
    this.isReadLimitSet = false;
    if (this.isAdaptive && this.isStreaming) {
      this.tdsReader.stream();
    }
  }
  
  void closeHelper() throws IOException {
    if (this.isAdaptive && null != this.dtv) {
      
      if (logger.isLoggable(Level.FINER))
        logger.finer(toString() + " closing the adaptive stream."); 
      this.dtv.setPositionAfterStreamed(this.tdsReader);
    } 
    this.currentMark = null;
    this.tdsReader = null;
    this.dtv = null;
  }




  
  final void checkClosed() throws IOException {
    if (null == this.tdsReader) {
      throw new IOException(SQLServerException.getErrString("R_streamIsClosed"));
    }
  }




  
  public boolean markSupported() {
    return true;
  }



  
  void setReadLimit(int paramInt) {
    if (this.isAdaptive && paramInt > 0) {
      
      this.readLimit = paramInt;
      this.isReadLimitSet = true;
    } 
  }




  
  void resetHelper() throws IOException {
    checkClosed();
    
    if (null == this.currentMark)
      throw new IOException(SQLServerException.getErrString("R_streamWasNotMarkedBefore")); 
    this.tdsReader.reset(this.currentMark);
  }
}
