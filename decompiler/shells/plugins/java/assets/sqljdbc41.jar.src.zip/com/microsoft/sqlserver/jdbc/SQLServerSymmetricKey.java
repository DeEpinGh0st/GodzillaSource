package com.microsoft.sqlserver.jdbc;






class SQLServerSymmetricKey
{
  private byte[] rootKey;
  
  SQLServerSymmetricKey(byte[] paramArrayOfbyte) throws SQLServerException {
    if (null == paramArrayOfbyte)
    {
      throw new SQLServerException(this, SQLServerException.getErrString("R_NullColumnEncryptionKey"), null, 0, false);
    }
    if (0 == paramArrayOfbyte.length)
    {
      throw new SQLServerException(this, SQLServerException.getErrString("R_EmptyColumnEncryptionKey"), null, 0, false);
    }
    this.rootKey = paramArrayOfbyte;
  }
  
  byte[] getRootKey() {
    return this.rootKey;
  }
  
  int length() {
    return this.rootKey.length;
  }

  
  void zeroOutKey() {
    for (byte b = 0; b < this.rootKey.length; b++)
    {
      this.rootKey[b] = 0;
    }
  }
}
