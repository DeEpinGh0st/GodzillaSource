package com.microsoft.sqlserver.jdbc;











enum TVPType
{
  ResultSet,
  ISQLServerDataRecord,
  SQLServerDataTable,
  Null;
}
