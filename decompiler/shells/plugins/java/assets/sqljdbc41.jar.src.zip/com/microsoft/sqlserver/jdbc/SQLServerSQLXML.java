package com.microsoft.sqlserver.jdbc;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.sax.TransformerHandler;
import javax.xml.transform.stax.StAXResult;
import javax.xml.transform.stax.StAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

final class SQLServerSQLXML implements SQLXML {
  private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerSQLXML");
  private final SQLServerConnection con;
  private final PLPXMLInputStream contents;
  private final InputStreamGetterArgs getterArgs;
  private final TypeInfo typeInfo;
  private boolean isUsed = false;
  private boolean isFreed = false;
  private ByteArrayOutputStreamToInputStream outputStreamValue;
  private Document docValue;
  private String strValue;
  private static int baseID = 0;
  private final String traceID;
  
  public final String toString() {
    return this.traceID;
  }

  
  private static synchronized int nextInstanceID() {
    baseID++;
    return baseID;
  }




  
  InputStream getValue() throws SQLServerException {
    checkClosed();

    
    if (!this.isUsed)
      SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_noDataXML"), null, true); 
    assert null == this.contents;
    ByteArrayInputStream byteArrayInputStream = null;
    if (null != this.outputStreamValue) {
      
      byteArrayInputStream = this.outputStreamValue.getInputStream();
      assert null == this.docValue;
      assert null == this.strValue;
    
    }
    else if (null != this.docValue) {
      
      assert null == this.outputStreamValue;
      assert null == this.strValue;
      ByteArrayOutputStreamToInputStream byteArrayOutputStreamToInputStream = new ByteArrayOutputStreamToInputStream();

      
      Object object = null;
      
      try {
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        transformerFactory.newTransformer().transform(new DOMSource(this.docValue), new StreamResult(byteArrayOutputStreamToInputStream));
      }
      catch (TransformerException transformerException) {
        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
        Object[] arrayOfObject = { transformerException.toString() };
        SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
      } 
      byteArrayInputStream = byteArrayOutputStreamToInputStream.getInputStream();
    }
    else {
      
      assert null == this.outputStreamValue;
      assert null == this.docValue;
      assert null != this.strValue;
      
      try {
        byteArrayInputStream = new ByteArrayInputStream(this.strValue.getBytes(Encoding.UNICODE.charsetName()));
      }
      catch (UnsupportedEncodingException unsupportedEncodingException) {
        
        throw new SQLServerException(null, unsupportedEncodingException.getMessage(), null, 0, true);
      } 
    } 
    assert null != byteArrayInputStream;
    this.isFreed = true;
    return byteArrayInputStream;
  }


  
  SQLServerSQLXML(SQLServerConnection paramSQLServerConnection) {
    this.contents = null;
    this.traceID = " SQLServerSQLXML:" + nextInstanceID();
    this.con = paramSQLServerConnection;
    
    if (logger.isLoggable(Level.FINE))
      logger.fine(toString() + " created by (" + paramSQLServerConnection.toString() + ")"); 
    this.getterArgs = null;
    this.typeInfo = null;
  }

  
  SQLServerSQLXML(InputStream paramInputStream, InputStreamGetterArgs paramInputStreamGetterArgs, TypeInfo paramTypeInfo) throws SQLServerException {
    this.traceID = " SQLServerSQLXML:" + nextInstanceID();
    this.contents = (PLPXMLInputStream)paramInputStream;
    this.con = null;
    this.getterArgs = paramInputStreamGetterArgs;
    this.typeInfo = paramTypeInfo;
    if (logger.isLoggable(Level.FINE))
      logger.fine(toString() + " created by (null connection)"); 
  }
  
  InputStream getStream() {
    return this.contents;
  }
  
  public void free() throws SQLException {
    if (!this.isFreed) {
      
      this.isFreed = true;
      if (null != this.contents) {
        
        try {
          
          this.contents.close();
        }
        catch (IOException iOException) {
          
          SQLServerException.makeFromDriverError(null, null, iOException.getMessage(), null, true);
        } 
      }
    } 
  }
  
  private void checkClosed() throws SQLServerException {
    if (this.isFreed || (null != this.con && this.con.isClosed())) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_isFreed"));
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(new Object[] { "SQLXML" }, ), null, true);
    } 
  }
  
  private void checkReadXML() throws SQLException {
    if (null == this.contents)
      SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_writeOnlyXML"), null, true); 
    if (this.isUsed) {
      SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_dataHasBeenReadXML"), null, true);
    }
    try {
      this.contents.checkClosed();
    }
    catch (IOException iOException) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_isFreed"));
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(new Object[] { "SQLXML" }, ), null, true);
    } 
  }
  
  void checkWriteXML() throws SQLException {
    if (null != this.contents)
      SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_readOnlyXML"), null, true); 
    if (this.isUsed) {
      SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_dataHasBeenSetXML"), null, true);
    }
  }






  
  public InputStream getBinaryStream() throws SQLException {
    checkClosed();
    checkReadXML();
    this.isUsed = true;
    return this.contents;
  }








  
  public OutputStream setBinaryStream() throws SQLException {
    checkClosed();
    checkWriteXML();
    this.isUsed = true;
    this.outputStreamValue = new ByteArrayOutputStreamToInputStream();
    return this.outputStreamValue;
  }
  
  public Writer setCharacterStream() throws SQLException {
    checkClosed();
    checkWriteXML();
    this.isUsed = true;
    this.outputStreamValue = new ByteArrayOutputStreamToInputStream();
    OutputStreamWriter outputStreamWriter = null;
    
    try {
      outputStreamWriter = new OutputStreamWriter(this.outputStreamValue, Encoding.UNICODE.charsetName());
    }
    catch (UnsupportedEncodingException unsupportedEncodingException) {
      
      throw new SQLServerException(null, unsupportedEncodingException.getMessage(), null, 0, true);
    } 
    return outputStreamWriter;
  }
  
  public Reader getCharacterStream() throws SQLException {
    checkClosed();
    checkReadXML();
    this.isUsed = true;
    StreamType streamType = StreamType.CHARACTER;
    InputStreamGetterArgs inputStreamGetterArgs = new InputStreamGetterArgs(streamType, this.getterArgs.isAdaptive, this.getterArgs.isStreaming, this.getterArgs.logContext);




    
    assert null != this.contents;

    
    try {
      this.contents.read();
      this.contents.read();
    }
    catch (IOException iOException) {
      
      SQLServerException.makeFromDriverError(null, null, iOException.getMessage(), null, true);
    } 
    
    return (Reader)DDC.convertStreamToObject(this.contents, this.typeInfo, streamType.getJDBCType(), inputStreamGetterArgs);
  }


  
  public String getString() throws SQLException {
    checkClosed();
    checkReadXML();
    this.isUsed = true;
    assert null != this.contents;

    
    try {
      this.contents.read();
      this.contents.read();
    }
    catch (IOException iOException) {
      
      SQLServerException.makeFromDriverError(null, null, iOException.getMessage(), null, true);
    } 
    
    byte[] arrayOfByte = this.contents.getBytes();
    String str = null;
    
    try {
      str = new String(arrayOfByte, 0, arrayOfByte.length, Encoding.UNICODE.charsetName());
    }
    catch (UnsupportedEncodingException unsupportedEncodingException) {
      
      throw new SQLServerException(null, unsupportedEncodingException.getMessage(), null, 0, true);
    } 
    return str;
  }
  
  public void setString(String paramString) throws SQLException {
    checkClosed();
    checkWriteXML();
    this.isUsed = true;
    if (null == paramString)
      SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_cantSetNull"), null, true); 
    this.strValue = paramString;
  }



  
  public <T extends Source> T getSource(Class<T> paramClass) throws SQLException {
    checkClosed();
    checkReadXML();
    if (null == paramClass)
    {

      
      return (T)getSourceInternal((Class)StreamSource.class);
    }

    
    return getSourceInternal(paramClass);
  }
  
  <T extends Source> T getSourceInternal(Class<T> paramClass) throws SQLException {
    this.isUsed = true;
    Source source = null;
    if (DOMSource.class == paramClass) {
      
      source = (Source)paramClass.cast(getDOMSource());
    }
    else if (SAXSource.class == paramClass) {
      
      source = (Source)paramClass.cast(getSAXSource());
    
    }
    else if (StAXSource.class == paramClass) {
      
      source = (Source)paramClass.cast(getStAXSource());
    
    }
    else if (StreamSource.class == paramClass) {
      
      source = (Source)paramClass.cast(new StreamSource(this.contents));
    }
    else {
      
      SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_notSupported"), null, true);
    }  return (T)source;
  }
  
  public <T extends Result> T setResult(Class<T> paramClass) throws SQLException {
    checkClosed();
    checkWriteXML();
    if (null == paramClass)
    {

      
      return (T)setResultInternal((Class)StreamResult.class);
    }

    
    return setResultInternal(paramClass);
  }


  
  <T extends Result> T setResultInternal(Class<T> paramClass) throws SQLException {
    this.isUsed = true;
    Result result = null;
    if (DOMResult.class == paramClass) {
      
      result = (Result)paramClass.cast(getDOMResult());
    
    }
    else if (SAXResult.class == paramClass) {
      
      result = (Result)paramClass.cast(getSAXResult());
    
    }
    else if (StAXResult.class == paramClass) {
      
      result = (Result)paramClass.cast(getStAXResult());
    }
    else if (StreamResult.class == paramClass) {
      
      this.outputStreamValue = new ByteArrayOutputStreamToInputStream();
      result = (Result)paramClass.cast(new StreamResult(this.outputStreamValue));
    } else {
      
      SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_notSupported"), null, true);
    }  return (T)result;
  }

  
  private final DOMSource getDOMSource() throws SQLException {
    Document document = null;
    DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();







    
    try {
      documentBuilderFactory.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", true);
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();

      
      documentBuilder.setEntityResolver(new SQLServerEntityResolver());
      
      try {
        document = documentBuilder.parse(this.contents);
      }
      catch (IOException iOException) {
        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
        Object[] arrayOfObject = { iOException.toString() };
        SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), "", true);
      } 
      return new DOMSource(document);
    
    }
    catch (ParserConfigurationException parserConfigurationException) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
      Object[] arrayOfObject = { parserConfigurationException.toString() };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
    }
    catch (SAXException sAXException) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_failedToParseXML"));
      Object[] arrayOfObject = { sAXException.toString() };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
    } 
    return null;
  }

  
  private final SAXSource getSAXSource() throws SQLException {
    try {
      InputSource inputSource = new InputSource(this.contents);
      XMLReader xMLReader = XMLReaderFactory.createXMLReader();
      return new SAXSource(xMLReader, inputSource);

    
    }
    catch (SAXException sAXException) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_failedToParseXML"));
      Object[] arrayOfObject = { sAXException.toString() };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
      
      return null;
    } 
  }
  private final StAXSource getStAXSource() throws SQLException {
    XMLInputFactory xMLInputFactory = XMLInputFactory.newInstance();
    
    try {
      XMLStreamReader xMLStreamReader = xMLInputFactory.createXMLStreamReader(this.contents);
      return new StAXSource(xMLStreamReader);
    
    }
    catch (XMLStreamException xMLStreamException) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
      Object[] arrayOfObject = { xMLStreamException.toString() };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
      
      return null;
    } 
  }
  
  private final StAXResult getStAXResult() throws SQLException {
    XMLOutputFactory xMLOutputFactory = XMLOutputFactory.newInstance();
    this.outputStreamValue = new ByteArrayOutputStreamToInputStream();
    
    try {
      XMLStreamWriter xMLStreamWriter = xMLOutputFactory.createXMLStreamWriter(this.outputStreamValue);
      return new StAXResult(xMLStreamWriter);
    
    }
    catch (XMLStreamException xMLStreamException) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
      Object[] arrayOfObject = { xMLStreamException.toString() };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
      
      return null;
    } 
  }
  private final SAXResult getSAXResult() throws SQLException {
    TransformerHandler transformerHandler = null;
    
    try {
      SAXTransformerFactory sAXTransformerFactory = (SAXTransformerFactory)TransformerFactory.newInstance();
      
      transformerHandler = sAXTransformerFactory.newTransformerHandler();
    }
    catch (TransformerConfigurationException transformerConfigurationException) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
      Object[] arrayOfObject = { transformerConfigurationException.toString() };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
    }
    catch (ClassCastException classCastException) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
      Object[] arrayOfObject = { classCastException.toString() };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
    } 
    this.outputStreamValue = new ByteArrayOutputStreamToInputStream();
    transformerHandler.setResult(new StreamResult(this.outputStreamValue));
    return new SAXResult(transformerHandler);
  }

  
  private final DOMResult getDOMResult() throws SQLException {
    DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
    
    assert null == this.outputStreamValue;
    
    try {
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      this.docValue = documentBuilder.newDocument();
      return new DOMResult(this.docValue);
    
    }
    catch (ParserConfigurationException parserConfigurationException) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
      Object[] arrayOfObject = { parserConfigurationException.toString() };
      SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
      
      return null;
    } 
  }
}
