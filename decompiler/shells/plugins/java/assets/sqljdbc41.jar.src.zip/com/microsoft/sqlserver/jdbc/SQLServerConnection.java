package com.microsoft.sqlserver.jdbc;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.IDN;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.NClob;
import java.sql.PreparedStatement;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.sql.SQLPermission;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Savepoint;
import java.sql.Statement;
import java.sql.Struct;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.DatatypeConverter;

public class SQLServerConnection
  implements ISQLServerConnection {
  long timerExpire;
  boolean attemptRefreshTokenLocked = false;
  private boolean fedAuthRequiredByUser = false;
  private boolean fedAuthRequiredPreLoginResponse = false;
  private boolean federatedAuthenticationAcknowledged = false;
  private boolean federatedAuthenticationRequested = false;
  private boolean federatedAuthenticationInfoRequested = false;
  private FederatedAuthenticationFeatureExtensionData fedAuthFeatureExtensionData = null;
  private String authenticationString = null;
  private byte[] accessTokenInByte = null;
  
  private SqlFedAuthToken fedAuthToken = null; private static final float TIMEOUTSTEP = 0.08F; static final int TnirFirstAttemptTimeoutMs = 500; private static final int INTERMITTENT_TLS_MAX_RETRY = 5;
  
  SqlFedAuthToken getAuthenticationResult() {
    return this.fedAuthToken;
  }


  
  class FederatedAuthenticationFeatureExtensionData
  {
    boolean fedAuthRequiredPreLoginResponse;
    
    int libraryType = -1;
    byte[] accessToken = null;
    SqlAuthentication authentication = null;
    
    FederatedAuthenticationFeatureExtensionData(int param1Int, String param1String, boolean param1Boolean) throws SQLServerException {
      this.libraryType = param1Int;
      this.fedAuthRequiredPreLoginResponse = param1Boolean;
      
      switch (param1String.toUpperCase(Locale.ENGLISH).trim()) {
        case "ACTIVEDIRECTORYPASSWORD":
          this.authentication = SqlAuthentication.ActiveDirectoryPassword;
          return;
        case "ACTIVEDIRECTORYINTEGRATED":
          this.authentication = SqlAuthentication.ActiveDirectoryIntegrated;
          return;
      } 
      assert false;
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidConnectionSetting"));
      Object[] arrayOfObject = { "authentication", param1String };
      throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
    }

    
    FederatedAuthenticationFeatureExtensionData(int param1Int, boolean param1Boolean, byte[] param1ArrayOfbyte) {
      this.libraryType = param1Int;
      this.fedAuthRequiredPreLoginResponse = param1Boolean;
      this.accessToken = param1ArrayOfbyte;
    }
  }
  
  class SqlFedAuthInfo
  {
    private String spn;
    private String stsurl;
    
    public String toString() {
      return "STSURL: " + this.stsurl + ", SPN: " + this.spn;
    }
  }
  
  final class SqlFedAuthToken {
    private final Date expiresOn;
    private final String accessToken;
    
    SqlFedAuthToken(String param1String, long param1Long) {
      this.accessToken = param1String;
      
      Date date = new Date();
      date.setTime(date.getTime() + param1Long * 1000L);
      this.expiresOn = date;
    }
    
    Date getExpiresOnDate() {
      return this.expiresOn;
    }
  }

  
  private class ActiveDirectoryAuthentication
  {
    private static final String jdbcFedauthClientId = "7f98cb04-cd1e-40df-9140-3bf7e2cea4db";
    
    private static final String AdalGetAccessTokenFunctionName = "ADALGetAccessToken";
    
    private static final int GetAccessTokenSuccess = 0;
    
    private static final int GetAccessTokenInvalidGrant = 1;
    
    private static final int GetAccessTokenTansisentError = 2;
    private static final int GetAccessTokenOtherError = 3;
  }
  
  private enum State
  {
    Initialized,
    Connected,
    Opened,
    Closed;
  }







  
  private boolean isRoutedInCurrentAttempt = false;






  
  private ServerPortPlaceHolder routingInfo = null;

  
  private static final String callAbortPerm = "callAbort";

  
  private boolean sendStringParametersAsUnicode = SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.getDefaultValue(); private boolean lastUpdateCount; boolean sendStringParametersAsUnicode() {
    return this.sendStringParametersAsUnicode;
  } final boolean useLastUpdateCount() {
    return this.lastUpdateCount;
  }
  
  private boolean serverNameAsACE = SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE.getDefaultValue(); private boolean multiSubnetFailover; private boolean transparentNetworkIPResolution; boolean serverNameAsACE() {
    return this.serverNameAsACE;
  }


  
  final boolean getMultiSubnetFailover() {
    return this.multiSubnetFailover;
  }


  
  final boolean getTransparentNetworkIPResolution() {
    return this.transparentNetworkIPResolution;
  }

  
  private ApplicationIntent applicationIntent = null; private int nLockTimeout; private String selectMethod; private String responseBuffering;
  
  final ApplicationIntent getApplicationIntent() {
    return this.applicationIntent;
  }

  
  final String getSelectMethod() {
    return this.selectMethod;
  } final String getResponseBuffering() {
    return this.responseBuffering;
  }
  private boolean sendTimeAsDatetime = SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.getDefaultValue();

  
  public final synchronized boolean getSendTimeAsDatetime() {
    return (!isKatmaiOrLater() || this.sendTimeAsDatetime);
  }

  
  final int baseYear() {
    return getSendTimeAsDatetime() ? 1970 : 1900;
  }
  
  private byte requestedEncryptionLevel = -1; private boolean trustServerCertificate;
  
  final byte getRequestedEncryptionLevel() {
    assert -1 != this.requestedEncryptionLevel;
    return this.requestedEncryptionLevel;
  }

  
  final boolean trustServerCertificate() {
    return this.trustServerCertificate;
  }
  private byte negotiatedEncryptionLevel = -1; static final String RESERVED_PROVIDER_NAME_PREFIX = "MSSQL_";
  
  final byte getNegotiatedEncryptionLevel() {
    assert -1 != this.negotiatedEncryptionLevel;
    return this.negotiatedEncryptionLevel;
  }


  
  String columnEncryptionSetting = null;
  boolean isColumnEncryptionSettingEnabled() {
    return this.columnEncryptionSetting.equalsIgnoreCase(ColumnEncryptionSetting.Enabled.toString());
  }
  
  String keyStoreAuthentication = null;
  String keyStoreSecret = null;
  String keyStoreLocation = null;
  private boolean serverSupportsColumnEncryption = false;
  static boolean isWindows;
  
  boolean getServerSupportsColumnEncryption() {
    return this.serverSupportsColumnEncryption;
  }
  
  static Map<String, SQLServerColumnEncryptionKeyStoreProvider> globalSystemColumnEncryptionKeyStoreProviders = new HashMap<>();

  
  static {
    if (System.getProperty("os.name").toLowerCase(Locale.ENGLISH).startsWith("windows")) {
      
      isWindows = true;
      SQLServerColumnEncryptionCertificateStoreProvider sQLServerColumnEncryptionCertificateStoreProvider = new SQLServerColumnEncryptionCertificateStoreProvider();
      globalSystemColumnEncryptionKeyStoreProviders.put(sQLServerColumnEncryptionCertificateStoreProvider.getName(), sQLServerColumnEncryptionCertificateStoreProvider);
    
    }
    else {

      
      isWindows = false;
    } 
  }
  static Map<String, SQLServerColumnEncryptionKeyStoreProvider> globalCustomColumnEncryptionKeyStoreProviders = null;
  
  Map<String, SQLServerColumnEncryptionKeyStoreProvider> systemColumnEncryptionKeyStoreProvider = new HashMap<>();



  
  public static synchronized void registerColumnEncryptionKeyStoreProviders(Map<String, SQLServerColumnEncryptionKeyStoreProvider> paramMap) throws SQLServerException {
    loggerExternal.entering(SQLServerConnection.class.getName(), "registerColumnEncryptionKeyStoreProviders", "Registering Column Encryption Key Store Providers");
    
    if (null == paramMap)
    {
      throw new SQLServerException(null, SQLServerException.getErrString("R_CustomKeyStoreProviderMapNull"), null, 0, false);
    }
    
    if (null != globalCustomColumnEncryptionKeyStoreProviders)
    {
      throw new SQLServerException(null, SQLServerException.getErrString("R_CustomKeyStoreProviderSetOnce"), null, 0, false);
    }
    
    globalCustomColumnEncryptionKeyStoreProviders = new HashMap<>();
    
    for (Map.Entry<String, SQLServerColumnEncryptionKeyStoreProvider> entry : paramMap.entrySet()) {
      
      String str = (String)entry.getKey();
      if (null == str || 0 == str.length())
      {
        throw new SQLServerException(null, SQLServerException.getErrString("R_EmptyCustomKeyStoreProviderName"), null, 0, false);
      }
      if (str.substring(0, 6).equalsIgnoreCase("MSSQL_")) {
        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidCustomKeyStoreProviderName"));
        Object[] arrayOfObject = { str, "MSSQL_" };
        throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
      } 
      if (null == entry.getValue()) {
        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_CustomKeyStoreProviderValueNull"));
        Object[] arrayOfObject = { str, "MSSQL_" };
        throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
      } 
      globalCustomColumnEncryptionKeyStoreProviders.put((String)entry.getKey(), (SQLServerColumnEncryptionKeyStoreProvider)entry.getValue());
    } 
    
    loggerExternal.exiting(SQLServerConnection.class.getName(), "registerColumnEncryptionKeyStoreProviders", "Number of Key store providers that are registered:" + globalCustomColumnEncryptionKeyStoreProviders.size());
  }





  
  static synchronized SQLServerColumnEncryptionKeyStoreProvider getGlobalSystemColumnEncryptionKeyStoreProvider(String paramString) {
    if (null != globalSystemColumnEncryptionKeyStoreProviders && globalSystemColumnEncryptionKeyStoreProviders.containsKey(paramString))
    {
      
      return globalSystemColumnEncryptionKeyStoreProviders.get(paramString);
    }
    return null;
  }

  
  static synchronized String getAllGlobalCustomSystemColumnEncryptionKeyStoreProviders() {
    if (null != globalCustomColumnEncryptionKeyStoreProviders) {
      return globalCustomColumnEncryptionKeyStoreProviders.keySet().toString();
    }
    return null;
  }

  
  synchronized String getAllSystemColumnEncryptionKeyStoreProviders() {
    String str = "";
    if (0 != this.systemColumnEncryptionKeyStoreProvider.size())
      str = this.systemColumnEncryptionKeyStoreProvider.keySet().toString(); 
    if (0 != globalSystemColumnEncryptionKeyStoreProviders.size())
      str = str + "," + globalSystemColumnEncryptionKeyStoreProviders.keySet().toString(); 
    return str;
  }

  
  static synchronized SQLServerColumnEncryptionKeyStoreProvider getGlobalCustomColumnEncryptionKeyStoreProvider(String paramString) {
    if (null != globalCustomColumnEncryptionKeyStoreProviders && globalCustomColumnEncryptionKeyStoreProviders.containsKey(paramString))
    {
      
      return globalCustomColumnEncryptionKeyStoreProviders.get(paramString);
    }
    return null;
  }

  
  synchronized SQLServerColumnEncryptionKeyStoreProvider getSystemColumnEncryptionKeyStoreProvider(String paramString) {
    if (null != this.systemColumnEncryptionKeyStoreProvider && this.systemColumnEncryptionKeyStoreProvider.containsKey(paramString))
    {
      
      return this.systemColumnEncryptionKeyStoreProvider.get(paramString);
    }

    
    return null;
  }

  
  private String trustedServerNameAE = null;
  private static Map<String, List<String>> columnEncryptionTrustedMasterKeyPaths = new HashMap<>();
  Properties activeConnectionProperties;
  
  public static synchronized void setColumnEncryptionTrustedMasterKeyPaths(Map<String, List<String>> paramMap) {
    loggerExternal.entering(SQLServerConnection.class.getName(), "setColumnEncryptionTrustedMasterKeyPaths", "Setting Trusted Master Key Paths");

    
    columnEncryptionTrustedMasterKeyPaths.clear();
    for (Map.Entry<String, List<String>> entry : paramMap.entrySet())
    {
      columnEncryptionTrustedMasterKeyPaths.put(((String)entry.getKey()).toUpperCase(), (List<String>)entry.getValue());
    }
    
    loggerExternal.exiting(SQLServerConnection.class.getName(), "setColumnEncryptionTrustedMasterKeyPaths", "Number of Trusted Master Key Paths: " + columnEncryptionTrustedMasterKeyPaths.size());
  }

  
  public static synchronized void updateColumnEncryptionTrustedMasterKeyPaths(String paramString, List<String> paramList) {
    loggerExternal.entering(SQLServerConnection.class.getName(), "updateColumnEncryptionTrustedMasterKeyPaths", "Updating Trusted Master Key Paths");

    
    columnEncryptionTrustedMasterKeyPaths.put(paramString.toUpperCase(), paramList);
    
    loggerExternal.exiting(SQLServerConnection.class.getName(), "updateColumnEncryptionTrustedMasterKeyPaths", "Number of Trusted Master Key Paths: " + columnEncryptionTrustedMasterKeyPaths.size());
  }

  
  public static synchronized void removeColumnEncryptionTrustedMasterKeyPaths(String paramString) {
    loggerExternal.entering(SQLServerConnection.class.getName(), "removeColumnEncryptionTrustedMasterKeyPaths", "Removing Trusted Master Key Paths");

    
    columnEncryptionTrustedMasterKeyPaths.remove(paramString.toUpperCase());
    
    loggerExternal.exiting(SQLServerConnection.class.getName(), "removeColumnEncryptionTrustedMasterKeyPaths", "Number of Trusted Master Key Paths: " + columnEncryptionTrustedMasterKeyPaths.size());
  }

  
  public static synchronized Map<String, List<String>> getColumnEncryptionTrustedMasterKeyPaths() {
    loggerExternal.entering(SQLServerConnection.class.getName(), "getColumnEncryptionTrustedMasterKeyPaths", "Getting Trusted Master Key Paths");
    
    HashMap<Object, Object> hashMap = new HashMap<>();
    
    for (Map.Entry<String, List<String>> entry : columnEncryptionTrustedMasterKeyPaths.entrySet()) {
      hashMap.put(entry.getKey(), entry.getValue());
    }
    
    loggerExternal.exiting(SQLServerConnection.class.getName(), "getColumnEncryptionTrustedMasterKeyPaths", "Number of Trusted Master Key Paths: " + hashMap.size());
    
    return (Map)hashMap;
  }

  
  static synchronized List<String> getColumnEncryptionTrustedMasterKeyPaths(String paramString, Boolean[] paramArrayOfBoolean) {
    if (columnEncryptionTrustedMasterKeyPaths.containsKey(paramString)) {
      
      paramArrayOfBoolean[0] = Boolean.valueOf(true);
      return columnEncryptionTrustedMasterKeyPaths.get(paramString);
    } 

    
    paramArrayOfBoolean[0] = Boolean.valueOf(false);
    return null;
  }


  
  private boolean integratedSecurity = SQLServerDriverBooleanProperty.INTEGRATED_SECURITY.getDefaultValue();
  private AuthenticationScheme intAuthScheme = AuthenticationScheme.nativeAuthentication;
  
  ServerPortPlaceHolder currentConnectPlaceHolder = null;
  
  String sqlServerVersion;
  boolean xopenStates;
  private boolean databaseAutoCommitMode;
  private boolean inXATransaction = false;
  private byte[] transactionDescriptor = new byte[8];
  
  private boolean rolledBackTransaction;
  
  final boolean rolledBackTransaction() {
    return this.rolledBackTransaction;
  }
  private State state = State.Initialized; static final int maxDecimalPrecision = 38; static final int defaultDecimalPrecision = 18; final String traceID; private int maxFieldSize; private int maxRows;
  private SQLCollation databaseCollation;
  
  private void setState(State paramState) {
    this.state = paramState;
  }


  
  final boolean isSessionUnAvailable() {
    return !this.state.equals(State.Opened);
  }








  
  final void setMaxFieldSize(int paramInt) throws SQLServerException {
    if (this.maxFieldSize != paramInt) {
      
      if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
      {
        loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
      }
      
      connectionCommand("SET TEXTSIZE " + ((0 == paramInt) ? Integer.MAX_VALUE : paramInt), "setMaxFieldSize");
      this.maxFieldSize = paramInt;
    } 
  }






  
  final void initResettableValues() {
    this.rolledBackTransaction = false;
    this.transactionIsolationLevel = 2;
    this.maxFieldSize = 0;
    this.maxRows = 0;
    this.nLockTimeout = -1;
    this.databaseAutoCommitMode = true;
    this.holdability = 1;
    this.sqlWarnings = null;
    this.sCatalog = this.originalCatalog;
    this.databaseMetaData = null;
  }




  
  final void setMaxRows(int paramInt) throws SQLServerException {
    if (this.maxRows != paramInt) {
      
      if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
      {
        loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
      }
      connectionCommand("SET ROWCOUNT " + paramInt, "setMaxRows");
      this.maxRows = paramInt;
    } 
  }
  
  final SQLCollation getDatabaseCollation() {
    return this.databaseCollation;
  }
  private static int baseConnectionID = 0;
  
  private String sCatalog = "master";
  
  private String originalCatalog = "master";
  
  private int transactionIsolationLevel;
  private SQLServerPooledConnection pooledConnectionParent;
  private DatabaseMetaData databaseMetaData;
  private int nNextSavePointId = 10000;
  
  private static final Logger connectionlogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerConnection");
  
  private static final Logger loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.Connection");


  
  private final String loggingClassName;

  
  private String failoverPartnerServerProvided = null; private int holdability;
  
  final int getHoldabilityInternal() {
    return this.holdability;
  }


  
  private int tdsPacketSize = 4096;
  private int requestedPacketSize = 8000; private TDSChannel tdsChannel; final int getTDSPacketSize() {
    return this.tdsPacketSize;
  }

  
  private TDSCommand currentCommand = null;
  
  private int tdsVersion = 0; private int serverMajorVersion;
  private SQLServerConnectionPoolProxy proxy;
  
  final boolean isKatmaiOrLater() {
    assert 0 != this.tdsVersion;
    assert this.tdsVersion >= 1913192450;
    return (this.tdsVersion >= 1930100739);
  }

  
  final boolean isDenaliOrLater() {
    return (this.tdsVersion >= 1946157060);
  }


  
  int getServerMajorVersion() {
    return this.serverMajorVersion;
  }


  
  private UUID clientConnectionId = null;
  
  static final int MAX_SQL_LOGIN_NAME_WCHARS = 128;

  
  public UUID getClientConnectionId() throws SQLServerException {
    checkClosed();
    return this.clientConnectionId;
  }



  
  final UUID getClientConIdInternal() {
    return this.clientConnectionId;
  }

  
  final boolean attachConnId() {
    return this.state.equals(State.Connected);
  }























  
  void setFailoverPartnerServerProvided(String paramString) {
    this.failoverPartnerServerProvided = paramString;
  }


  
  final void setAssociatedProxy(SQLServerConnectionPoolProxy paramSQLServerConnectionPoolProxy) {
    this.proxy = paramSQLServerConnectionPoolProxy;
  }







  
  final Connection getConnection() {
    if (null != this.proxy) {
      return this.proxy;
    }
    return this;
  }

  
  final void resetPooledConnection() {
    this.tdsChannel.resetPooledConnection();
    initResettableValues();
  }





  
  private static synchronized int nextConnectionID() {
    baseConnectionID++;
    return baseConnectionID;
  }
  
  Logger getConnectionLogger() {
    return connectionlogger;
  }

  
  String getClassNameLogging() {
    return this.loggingClassName;
  }





  
  public String toString() {
    if (null != this.clientConnectionId) {
      return this.traceID + " ClientConnectionId: " + this.clientConnectionId.toString();
    }
    return this.traceID;
  }






  
  void NotImplemented() throws SQLServerException {
    SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_notSupported"), (String)null, false);
  }






  
  void checkClosed() throws SQLServerException {
    if (isSessionUnAvailable())
    {
      SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, SQLServerException.getErrString("R_connectionIsClosed"), (String)null, false);
    }
    
    if (null != this.fedAuthToken && 
      Util.checkIfNeedNewAccessToken(this))
    {
      connect(this.activeConnectionProperties, null);
    }
  }










  
  private boolean booleanPropertyOn(String paramString1, String paramString2) throws SQLServerException {
    if (null == paramString2) return false; 
    String str = paramString2.toLowerCase(Locale.US);
    
    if (str.equals("true")) return true; 
    if (str.equals("false")) return false; 
    MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidBooleanValue"));
    Object[] arrayOfObject = { new String(paramString1) };
    SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
    
    return false;
  }












  
  void ValidateMaxSQLLoginName(String paramString1, String paramString2) throws SQLServerException {
    if (paramString2 != null && paramString2.length() > 128) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_propertyMaximumExceedsChars"));
      Object[] arrayOfObject = { paramString1, Integer.toString(128) };
      SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
    } 
  }

  
  Connection connect(Properties paramProperties, SQLServerPooledConnection paramSQLServerPooledConnection) throws SQLServerException {
    int i = 0;
    long l = System.currentTimeMillis();
    
    byte b = 0;
    
    while (true) {
      try {
        return connectInternal(paramProperties, paramSQLServerPooledConnection);
      }
      catch (SQLServerException sQLServerException) {

        
        if (7 != sQLServerException.getDriverErrorCode())
        {
          
          throw sQLServerException;
        }




        
        if (0 == b) {



          
          i = SQLServerDriverIntProperty.LOGIN_TIMEOUT.getDefaultValue();
          String str = paramProperties.getProperty(SQLServerDriverIntProperty.LOGIN_TIMEOUT.toString());
          if (null != str && str.length() > 0)
          {
            i = Integer.parseInt(str);
          }
        } 
        
        b++;
        long l1 = (System.currentTimeMillis() - l) / 1000L;
        
        if (5 < b) {

          
          if (connectionlogger.isLoggable(Level.FINE))
          {
            connectionlogger.fine("Connection failed during SSL handshake. Maximum retry attempt (5) reached.  ");
          }
          throw sQLServerException;
        } 
        if (l1 >= i) {

          
          if (connectionlogger.isLoggable(Level.FINE))
          {
            connectionlogger.fine("Connection failed during SSL handshake. Not retrying as timeout expired.");
          }
          throw sQLServerException;
        } 


        
        if (connectionlogger.isLoggable(Level.FINE))
        {
          connectionlogger.fine("Connection failed during SSL handshake. Retrying due to an intermittent TLS 1.2 failure issue. Retry attempt = " + b + ".");
        }
      } 
    } 
  }



  
  private void registerKeyStoreProviderOnConnection(String paramString1, String paramString2, String paramString3) throws SQLServerException {
    if (null == paramString1) {

      
      if (null != paramString2) {
        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_keyStoreAuthenticationNotSet"));
        Object[] arrayOfObject = { "keyStoreSecret" };
        throw new SQLServerException(messageFormat.format(arrayOfObject), null);
      } 
      if (null != paramString3) {
        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_keyStoreAuthenticationNotSet"));
        Object[] arrayOfObject = { "keyStoreLocation" };
        throw new SQLServerException(messageFormat.format(arrayOfObject), null);
      } 
    } else {
      SQLServerColumnEncryptionJavaKeyStoreProvider sQLServerColumnEncryptionJavaKeyStoreProvider;
      
      KeyStoreAuthentication keyStoreAuthentication = KeyStoreAuthentication.valueOfString(paramString1);
      switch (keyStoreAuthentication) {

        
        case ActiveDirectoryPassword:
          if (null == paramString2 || null == paramString3)
          {
            throw new SQLServerException(SQLServerException.getErrString("R_keyStoreSecretOrLocationNotSet"), null);
          }

          
          sQLServerColumnEncryptionJavaKeyStoreProvider = new SQLServerColumnEncryptionJavaKeyStoreProvider(paramString3, paramString2.toCharArray());
          this.systemColumnEncryptionKeyStoreProvider.put(sQLServerColumnEncryptionJavaKeyStoreProvider.getName(), sQLServerColumnEncryptionJavaKeyStoreProvider);
          break;
      } 
    } 
  }













































  
  Connection connectInternal(Properties paramProperties, SQLServerPooledConnection paramSQLServerPooledConnection) throws SQLServerException {
    try {
      this.activeConnectionProperties = (Properties)paramProperties.clone();
      
      this.pooledConnectionParent = paramSQLServerPooledConnection;
      
      String str1 = null;
      String str2 = null;
      
      str1 = SQLServerDriverStringProperty.USER.toString();
      str2 = this.activeConnectionProperties.getProperty(str1);
      if (str2 == null) {
        
        str2 = SQLServerDriverStringProperty.USER.getDefaultValue();
        this.activeConnectionProperties.setProperty(str1, str2);
      } 
      ValidateMaxSQLLoginName(str1, str2);

      
      str1 = SQLServerDriverStringProperty.PASSWORD.toString();
      str2 = this.activeConnectionProperties.getProperty(str1);
      if (str2 == null) {
        
        str2 = SQLServerDriverStringProperty.PASSWORD.getDefaultValue();
        this.activeConnectionProperties.setProperty(str1, str2);
      } 
      ValidateMaxSQLLoginName(str1, str2);
      
      str1 = SQLServerDriverStringProperty.DATABASE_NAME.toString();
      str2 = this.activeConnectionProperties.getProperty(str1);
      ValidateMaxSQLLoginName(str1, str2);

      
      int i = SQLServerDriverIntProperty.LOGIN_TIMEOUT.getDefaultValue();
      str2 = this.activeConnectionProperties.getProperty(SQLServerDriverIntProperty.LOGIN_TIMEOUT.toString());
      if (null != str2 && str2.length() > 0) {

        
        try {
          i = Integer.parseInt(str2);
        }
        catch (NumberFormatException numberFormatException) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidTimeOut"));
          Object[] arrayOfObject = { str2 };
          SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
        } 
        
        if (i < 0 || i > 65535) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidTimeOut"));
          Object[] arrayOfObject = { str2 };
          SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
        } 
      } 

      
      str1 = SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE.toString();
      str2 = this.activeConnectionProperties.getProperty(str1);
      if (str2 == null) {
        
        str2 = Boolean.toString(SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE.getDefaultValue());
        this.activeConnectionProperties.setProperty(str1, str2);
      } 
      this.serverNameAsACE = booleanPropertyOn(str1, str2);



      
      str1 = SQLServerDriverStringProperty.SERVER_NAME.toString();
      str2 = this.activeConnectionProperties.getProperty(str1);
      
      if (str2 == null)
      {
        str2 = "localhost";
      }
      
      String str3 = SQLServerDriverIntProperty.PORT_NUMBER.toString();
      String str4 = this.activeConnectionProperties.getProperty(str3);
      
      int j = str2.indexOf('\\');
      
      Object object = null;
      String str5 = null;
      
      String str6 = SQLServerDriverStringProperty.INSTANCE_NAME.toString();
      
      if (j >= 0) {
        
        str5 = str2.substring(j + 1, str2.length());
        ValidateMaxSQLLoginName(str6, str5);
        str2 = str2.substring(0, j);
      } 
      this.trustedServerNameAE = str2;
      
      if (true == this.serverNameAsACE) {
        
        try {
          
          str2 = IDN.toASCII(str2);
        }
        catch (IllegalArgumentException illegalArgumentException) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidConnectionSetting"));
          Object[] arrayOfObject = { "serverNameAsACE", str2 };
          throw new SQLServerException(messageFormat.format(arrayOfObject), illegalArgumentException);
        } 
      }
      this.activeConnectionProperties.setProperty(str1, str2);
      
      String str7 = this.activeConnectionProperties.getProperty(str6);
      
      if (null != str7) {
        str5 = str7;
      }
      if (str5 != null) {
        
        ValidateMaxSQLLoginName(str6, str5);
        
        this.activeConnectionProperties.setProperty(str6, str5);
        this.trustedServerNameAE += "\\" + str5;
      } 
      
      if (null != str4)
      {
        this.trustedServerNameAE += ":" + str4;
      }
      
      str1 = SQLServerDriverStringProperty.APPLICATION_NAME.toString();
      str2 = this.activeConnectionProperties.getProperty(str1);
      if (str2 != null) {
        ValidateMaxSQLLoginName(str1, str2);
      } else {
        this.activeConnectionProperties.setProperty(str1, "Microsoft JDBC Driver for SQL Server");
      } 
      str1 = SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.toString();
      str2 = this.activeConnectionProperties.getProperty(str1);
      if (str2 == null) {
        
        str2 = Boolean.toString(SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.getDefaultValue());
        this.activeConnectionProperties.setProperty(str1, str2);
      } 
      
      str1 = SQLServerDriverStringProperty.COLUMN_ENCRYPTION.toString();
      str2 = this.activeConnectionProperties.getProperty(str1);
      if (null == str2) {
        
        str2 = SQLServerDriverStringProperty.COLUMN_ENCRYPTION.getDefaultValue();
        this.activeConnectionProperties.setProperty(str1, str2);
      } 
      this.columnEncryptionSetting = ColumnEncryptionSetting.valueOfString(str2).toString();
      
      str1 = SQLServerDriverStringProperty.KEY_STORE_AUTHENTICATION.toString();
      str2 = this.activeConnectionProperties.getProperty(str1);
      if (null != str2)
      {
        this.keyStoreAuthentication = KeyStoreAuthentication.valueOfString(str2).toString();
      }
      
      str1 = SQLServerDriverStringProperty.KEY_STORE_SECRET.toString();
      str2 = this.activeConnectionProperties.getProperty(str1);
      if (null != str2)
      {
        this.keyStoreSecret = str2;
      }
      
      str1 = SQLServerDriverStringProperty.KEY_STORE_LOCATION.toString();
      str2 = this.activeConnectionProperties.getProperty(str1);
      if (null != str2)
      {
        this.keyStoreLocation = str2;
      }
      
      registerKeyStoreProviderOnConnection(this.keyStoreAuthentication, this.keyStoreSecret, this.keyStoreLocation);

      
      str1 = SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.toString();
      str2 = this.activeConnectionProperties.getProperty(str1);
      if (str2 == null) {
        
        str2 = Boolean.toString(SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.getDefaultValue());
        this.activeConnectionProperties.setProperty(str1, str2);
      } 
      this.multiSubnetFailover = booleanPropertyOn(str1, str2);
      
      str1 = SQLServerDriverBooleanProperty.TRANSPARENT_NETWORK_IP_RESOLUTION.toString();
      str2 = this.activeConnectionProperties.getProperty(str1);
      if (str2 == null) {
        
        str2 = Boolean.toString(SQLServerDriverBooleanProperty.TRANSPARENT_NETWORK_IP_RESOLUTION.getDefaultValue());
        this.activeConnectionProperties.setProperty(str1, str2);
      } 
      this.transparentNetworkIPResolution = booleanPropertyOn(str1, str2);
      
      str1 = SQLServerDriverBooleanProperty.ENCRYPT.toString();
      str2 = this.activeConnectionProperties.getProperty(str1);
      if (str2 == null) {
        
        str2 = Boolean.toString(SQLServerDriverBooleanProperty.ENCRYPT.getDefaultValue());
        this.activeConnectionProperties.setProperty(str1, str2);
      } 

      
      this.requestedEncryptionLevel = booleanPropertyOn(str1, str2) ? 1 : 0;
      
      str1 = SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.toString();
      str2 = this.activeConnectionProperties.getProperty(str1);
      if (str2 == null) {
        
        str2 = Boolean.toString(SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.getDefaultValue());
        this.activeConnectionProperties.setProperty(str1, str2);
      } 
      
      this.trustServerCertificate = booleanPropertyOn(str1, str2);
      
      str1 = SQLServerDriverStringProperty.SELECT_METHOD.toString();
      str2 = this.activeConnectionProperties.getProperty(str1);
      if (str2 == null) str2 = SQLServerDriverStringProperty.SELECT_METHOD.getDefaultValue(); 
      if (str2.equalsIgnoreCase("cursor") || str2.equalsIgnoreCase("direct")) {
        
        this.activeConnectionProperties.setProperty(str1, str2.toLowerCase());
      }
      else {
        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidselectMethod"));
        Object[] arrayOfObject = { new String(str2) };
        SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
      } 
      
      str1 = SQLServerDriverStringProperty.RESPONSE_BUFFERING.toString();
      str2 = this.activeConnectionProperties.getProperty(str1);
      if (str2 == null) str2 = SQLServerDriverStringProperty.RESPONSE_BUFFERING.getDefaultValue(); 
      if (str2.equalsIgnoreCase("full") || str2.equalsIgnoreCase("adaptive")) {
        
        this.activeConnectionProperties.setProperty(str1, str2.toLowerCase());
      }
      else {
        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidresponseBuffering"));
        Object[] arrayOfObject = { new String(str2) };
        SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
      } 

      
      str1 = SQLServerDriverStringProperty.APPLICATION_INTENT.toString();
      str2 = this.activeConnectionProperties.getProperty(str1);
      if (str2 == null) str2 = SQLServerDriverStringProperty.APPLICATION_INTENT.getDefaultValue(); 
      this.applicationIntent = ApplicationIntent.valueOfString(str2);
      this.activeConnectionProperties.setProperty(str1, this.applicationIntent.toString());
      
      str1 = SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.toString();
      str2 = this.activeConnectionProperties.getProperty(str1);
      if (str2 == null) {
        
        str2 = Boolean.toString(SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.getDefaultValue());
        this.activeConnectionProperties.setProperty(str1, str2);
      } 
      
      this.sendTimeAsDatetime = booleanPropertyOn(str1, str2);
      
      str1 = SQLServerDriverBooleanProperty.DISABLE_STATEMENT_POOLING.toString();
      str2 = this.activeConnectionProperties.getProperty(str1);
      if (str2 != null && false == 
        booleanPropertyOn(str1, str2)) {
        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invaliddisableStatementPooling"));
        Object[] arrayOfObject = { new String(str2) };
        SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
      } 
      
      str1 = SQLServerDriverBooleanProperty.INTEGRATED_SECURITY.toString();
      str2 = this.activeConnectionProperties.getProperty(str1);
      if (str2 != null)
      {
        this.integratedSecurity = booleanPropertyOn(str1, str2);
      }

      
      if (this.integratedSecurity) {
        
        str1 = SQLServerDriverStringProperty.AUTHENTICATION_SCHEME.toString();
        str2 = this.activeConnectionProperties.getProperty(str1);
        if (str2 != null)
        {
          this.intAuthScheme = AuthenticationScheme.valueOfString(str2);
        }
      } 
      
      str1 = SQLServerDriverStringProperty.AUTHENTICATION.toString();
      str2 = this.activeConnectionProperties.getProperty(str1);
      if (str2 == null)
      {
        str2 = SQLServerDriverStringProperty.AUTHENTICATION.getDefaultValue();
      }
      this.authenticationString = SqlAuthentication.valueOfString(str2).toString();
      
      if (true == this.integratedSecurity && !this.authenticationString.equalsIgnoreCase(SqlAuthentication.NotSpecified.toString())) {
        
        connectionlogger.severe(toString() + " " + SQLServerException.getErrString("R_SetAuthenticationWhenIntegratedSecurityTrue"));
        throw new SQLServerException(SQLServerException.getErrString("R_SetAuthenticationWhenIntegratedSecurityTrue"), null);
      } 
      
      if (this.authenticationString.equalsIgnoreCase(SqlAuthentication.ActiveDirectoryIntegrated.toString()) && (!this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString()).isEmpty() || !this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString()).isEmpty())) {



        
        connectionlogger.severe(toString() + " " + SQLServerException.getErrString("R_IntegratedAuthenticationWithUserPassword"));
        throw new SQLServerException(SQLServerException.getErrString("R_IntegratedAuthenticationWithUserPassword"), null);
      } 
      
      if (this.authenticationString.equalsIgnoreCase(SqlAuthentication.ActiveDirectoryPassword.toString()) && (this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString()).isEmpty() || this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString()).isEmpty())) {


        
        connectionlogger.severe(toString() + " " + SQLServerException.getErrString("R_NoUserPasswordForActivePassword"));
        throw new SQLServerException(SQLServerException.getErrString("R_NoUserPasswordForActivePassword"), null);
      } 
      
      if (this.authenticationString.equalsIgnoreCase(SqlAuthentication.SqlPassword.toString()) && (this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString()).isEmpty() || this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString()).isEmpty())) {


        
        connectionlogger.severe(toString() + " " + SQLServerException.getErrString("R_NoUserPasswordForSqlPassword"));
        throw new SQLServerException(SQLServerException.getErrString("R_NoUserPasswordForSqlPassword"), null);
      } 
      
      str1 = SQLServerDriverStringProperty.ACCESS_TOKEN.toString();
      str2 = this.activeConnectionProperties.getProperty(str1);
      if (null != str2) {
        
        try {
          this.accessTokenInByte = str2.getBytes("UTF-16LE");
        } catch (UnsupportedEncodingException unsupportedEncodingException) {
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
          
          Object[] arrayOfObject = { "UTF-16LE" };
          throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
        } 
      }
      
      if (null != this.accessTokenInByte && 0 == this.accessTokenInByte.length) {
        
        connectionlogger.severe(toString() + " " + SQLServerException.getErrString("R_AccessTokenCannotBeEmpty"));
        throw new SQLServerException(SQLServerException.getErrString("R_AccessTokenCannotBeEmpty"), null);
      } 
      
      if (true == this.integratedSecurity && null != this.accessTokenInByte) {
        
        connectionlogger.severe(toString() + " " + SQLServerException.getErrString("R_SetAccesstokenWhenIntegratedSecurityTrue"));
        throw new SQLServerException(SQLServerException.getErrString("R_SetAccesstokenWhenIntegratedSecurityTrue"), null);
      } 
      
      if (!this.authenticationString.equalsIgnoreCase(SqlAuthentication.NotSpecified.toString()) && null != this.accessTokenInByte) {

        
        connectionlogger.severe(toString() + " " + SQLServerException.getErrString("R_SetBothAuthenticationAndAccessToken"));
        throw new SQLServerException(SQLServerException.getErrString("R_SetBothAuthenticationAndAccessToken"), null);
      } 
      
      if (null != this.accessTokenInByte && (!this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString()).isEmpty() || !this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString()).isEmpty())) {



        
        connectionlogger.severe(toString() + " " + SQLServerException.getErrString("R_AccessTokenWithUserPassword"));
        throw new SQLServerException(SQLServerException.getErrString("R_AccessTokenWithUserPassword"), null);
      } 
      
      if (!System.getProperty("os.name").toLowerCase().startsWith("windows") && (null != this.accessTokenInByte || !this.authenticationString.equalsIgnoreCase(SqlAuthentication.NotSpecified.toString())))
      {
        throw new SQLServerException(SQLServerException.getErrString("R_FedAuthOnNonWindows"), null);
      }
      
      str1 = SQLServerDriverStringProperty.WORKSTATION_ID.toString();
      str2 = this.activeConnectionProperties.getProperty(str1);
      ValidateMaxSQLLoginName(str1, str2);
      
      int k = 0;
      str1 = SQLServerDriverIntProperty.PORT_NUMBER.toString();
      
      try {
        String str = this.activeConnectionProperties.getProperty(str1);
        if (null != str) {
          
          k = (new Integer(str)).intValue();
          
          if (k < 0 || k > 65535)
          {
            MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPortNumber"));
            Object[] arrayOfObject = { Integer.toString(k) };
            SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
          }
        
        } 
      } catch (NumberFormatException numberFormatException) {
        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPortNumber"));
        Object[] arrayOfObject = { this.activeConnectionProperties.getProperty(str1) };
        SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
      } 

      
      str1 = SQLServerDriverIntProperty.PACKET_SIZE.toString();
      str2 = this.activeConnectionProperties.getProperty(str1);
      if (null != str2 && str2.length() > 0) {

        
        try {
          this.requestedPacketSize = Integer.parseInt(str2);

          
          if (-1 == this.requestedPacketSize) {
            this.requestedPacketSize = 0;
          
          }
          else if (0 == this.requestedPacketSize) {
            this.requestedPacketSize = 32767;
          } 
        } catch (NumberFormatException numberFormatException) {


          
          this.requestedPacketSize = -1;
        } 
        
        if (0 != this.requestedPacketSize)
        {
          
          if (this.requestedPacketSize < 512 || this.requestedPacketSize > 32767) {
            
            MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPacketSize"));
            Object[] arrayOfObject = { str2 };
            SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
          } 
        }
      } 




      
      str1 = SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.toString();
      if (null == this.activeConnectionProperties.getProperty(str1)) {
        
        this.sendStringParametersAsUnicode = SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.getDefaultValue();
      }
      else {
        
        this.sendStringParametersAsUnicode = booleanPropertyOn(str1, this.activeConnectionProperties.getProperty(str1));
      } 
      
      str1 = SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.toString();
      this.lastUpdateCount = booleanPropertyOn(str1, this.activeConnectionProperties.getProperty(str1));
      str1 = SQLServerDriverBooleanProperty.XOPEN_STATES.toString();
      this.xopenStates = booleanPropertyOn(str1, this.activeConnectionProperties.getProperty(str1));
      
      str1 = SQLServerDriverStringProperty.SELECT_METHOD.toString();
      this.selectMethod = null;
      if (this.activeConnectionProperties.getProperty(str1) != null && this.activeConnectionProperties.getProperty(str1).length() > 0)
      {
        
        this.selectMethod = this.activeConnectionProperties.getProperty(str1);
      }
      
      str1 = SQLServerDriverStringProperty.RESPONSE_BUFFERING.toString();
      this.responseBuffering = null;
      if (this.activeConnectionProperties.getProperty(str1) != null && this.activeConnectionProperties.getProperty(str1).length() > 0)
      {
        
        this.responseBuffering = this.activeConnectionProperties.getProperty(str1);
      }
      
      str1 = SQLServerDriverIntProperty.LOCK_TIMEOUT.toString();
      int m = SQLServerDriverIntProperty.LOCK_TIMEOUT.getDefaultValue();
      this.nLockTimeout = m;
      if (this.activeConnectionProperties.getProperty(str1) != null && this.activeConnectionProperties.getProperty(str1).length() > 0) {
        
        try {

          
          int n = (new Integer(this.activeConnectionProperties.getProperty(str1))).intValue();
          if (n >= m) {
            this.nLockTimeout = n;
          } else {
            
            MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidLockTimeOut"));
            Object[] arrayOfObject = { this.activeConnectionProperties.getProperty(str1) };
            SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
          }
        
        } catch (NumberFormatException numberFormatException) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidLockTimeOut"));
          Object[] arrayOfObject = { this.activeConnectionProperties.getProperty(str1) };
          SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
        } 
      }
      FailoverInfo failoverInfo = null;
      String str8 = SQLServerDriverStringProperty.DATABASE_NAME.toString();
      String str9 = SQLServerDriverStringProperty.SERVER_NAME.toString();
      String str10 = SQLServerDriverStringProperty.FAILOVER_PARTNER.toString();
      String str11 = this.activeConnectionProperties.getProperty(str10);

      
      if (this.multiSubnetFailover && str11 != null)
      {
        SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_dbMirroringWithMultiSubnetFailover"), (String)null, false);
      }

      
      if (this.multiSubnetFailover || null != str11)
      {
        this.transparentNetworkIPResolution = false;
      }

      
      if (this.applicationIntent != null && this.applicationIntent.equals(ApplicationIntent.READ_ONLY) && str11 != null)
      {
        SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_dbMirroringWithReadOnlyIntent"), (String)null, false);
      }

      
      if (null != this.activeConnectionProperties.getProperty(str8)) {

        
        failoverInfo = FailoverMapSingleton.getFailoverInfo(this, this.activeConnectionProperties.getProperty(str9), this.activeConnectionProperties.getProperty(str6), this.activeConnectionProperties.getProperty(str8));



      
      }
      else if (null != str11) {
        SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_failoverPartnerWithoutDB"), (String)null, true);
      } 
      
      String str12 = null;
      if (null == failoverInfo) {
        str12 = str11;
      }
      long l = System.currentTimeMillis();
      login(this.activeConnectionProperties.getProperty(str9), str5, k, str12, failoverInfo, i, l);


      
      if (1 == this.negotiatedEncryptionLevel || 3 == this.negotiatedEncryptionLevel) {

        
        char c = Util.isIBM() ? ' ' : '䀀';
        
        if (this.tdsPacketSize > c) {
          
          connectionlogger.finer(toString() + " Negotiated tdsPacketSize " + this.tdsPacketSize + " is too large for SSL with JRE " + Util.SYSTEM_JRE + " (max size is " + c + ")");
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_packetSizeTooBigForSSL"));
          Object[] arrayOfObject = { Integer.toString(c) };
          terminate(6, messageFormat.format(arrayOfObject));
        } 
      } 

      
      this.state = State.Opened;

      
      if (connectionlogger.isLoggable(Level.FINER))
      {
        connectionlogger.finer(toString() + " End of connect");
      
      }
    
    }
    finally {
      
      if (!this.state.equals(State.Opened))
      {
        
        if (!this.state.equals(State.Closed)) {
          close();
        }
      }
    } 
    return this;
  }









  
  private void login(String paramString1, String paramString2, int paramInt1, String paramString3, FailoverInfo paramFailoverInfo, int paramInt2, long paramLong) throws SQLServerException {
    long l1;
    boolean bool = (null == paramString3 && null == paramFailoverInfo) ? false : true;
    byte b1 = 100;

    
    boolean bool1 = false;
    FailoverInfo failoverInfo = null;
    
    ServerPortPlaceHolder serverPortPlaceHolder1 = null;
    
    ServerPortPlaceHolder serverPortPlaceHolder2 = null;
    
    if (null != paramFailoverInfo) {
      
      failoverInfo = paramFailoverInfo;
      bool1 = paramFailoverInfo.getUseFailoverPartner();

    
    }
    else if (bool) {
      
      failoverInfo = new FailoverInfo(paramString3, this, false);
    } 



    
    boolean bool2 = getMultiSubnetFailover();
    boolean bool3 = getTransparentNetworkIPResolution();


    
    if (0 == paramInt2)
    {
      paramInt2 = SQLServerDriverIntProperty.LOGIN_TIMEOUT.getDefaultValue();
    }
    long l3 = (paramInt2 * 1000);
    this.timerExpire = paramLong + l3;

    
    if (bool || bool2 || bool3) {
      
      l1 = (long)(0.08F * (float)l3);
    }
    else {
      
      l1 = l3;
    } 
    long l2 = paramLong + l1;

    
    long l4 = paramLong + l3;
    
    if (connectionlogger.isLoggable(Level.FINER))
    {
      connectionlogger.finer(toString() + " Start time: " + paramLong + " Time out time: " + this.timerExpire + " Timeout Unit Interval: " + l1);
    }

    
    byte b2 = 0;

    
    byte b3 = 0;








    
    while (true) {
      this.clientConnectionId = null;
      this.state = State.Initialized;

      
      try {
        if (bool && bool1) {

          
          if (null == serverPortPlaceHolder1)
          {
            
            serverPortPlaceHolder1 = failoverInfo.failoverPermissionCheck(this, this.integratedSecurity);
          }
          this.currentConnectPlaceHolder = serverPortPlaceHolder1;
        }
        else {
          
          if (this.routingInfo != null) {
            
            serverPortPlaceHolder2 = this.routingInfo;
            this.routingInfo = null;
          }
          else if (null == serverPortPlaceHolder2) {
            
            serverPortPlaceHolder2 = primaryPermissionCheck(paramString1, paramString2, paramInt1);
          } 
          this.currentConnectPlaceHolder = serverPortPlaceHolder2;
        } 

        
        if (connectionlogger.isLoggable(Level.FINE)) {
          
          connectionlogger.fine(toString() + " This attempt server name: " + this.currentConnectPlaceHolder.getServerName() + " port: " + this.currentConnectPlaceHolder.getPortNumber() + " InstanceName: " + this.currentConnectPlaceHolder.getInstanceName() + " useParallel: " + bool2);


          
          connectionlogger.fine(toString() + " This attempt endtime: " + l2);
          connectionlogger.fine(toString() + " This attempt No: " + b2);
        } 




        
        connectHelper(this.currentConnectPlaceHolder, TimerRemaining(l2), paramInt2, bool2, bool3, (0 == b2), TimerRemaining(l4));








        
        if (this.isRoutedInCurrentAttempt) {


          
          if (bool) {
            
            String str = SQLServerException.getErrString("R_invalidRoutingInfo");
            terminate(6, str);
          } 
          
          b3++;
          
          if (b3 > 1) {
            
            String str = SQLServerException.getErrString("R_multipleRedirections");
            terminate(6, str);
          } 

          
          if (this.tdsChannel != null) {
            this.tdsChannel.close();
          }
          initResettableValues();


          
          resetNonRoutingEnvchangeValues();




          
          b2++;

          
          this.isRoutedInCurrentAttempt = false;

          
          bool2 = false;
          bool3 = false;

          
          l2 = this.timerExpire;

          
          if (timerHasExpired(this.timerExpire)) {
            
            MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_tcpipConnectionFailed"));
            Object[] arrayOfObject = { this.currentConnectPlaceHolder.getServerName(), Integer.toString(this.currentConnectPlaceHolder.getPortNumber()), SQLServerException.getErrString("R_timedOutBeforeRouting") };
            String str = messageFormat.format(arrayOfObject);
            terminate(6, str);
          }
          else {
            
            continue;
          } 
        } else {
          
          break;
        } 
      } catch (SQLServerException sQLServerException) {
        
        if (18456 == sQLServerException.getErrorCode() || 18488 == sQLServerException.getErrorCode() || 4 == sQLServerException.getDriverErrorCode() || 5 == sQLServerException.getDriverErrorCode() || 7 == sQLServerException.getDriverErrorCode() || 6 == sQLServerException.getDriverErrorCode() || timerHasExpired(this.timerExpire) || (this.state.equals(State.Connected) && !bool)) {











          
          close();
          throw sQLServerException;
        } 



        
        if (null != this.tdsChannel) {
          this.tdsChannel.close();
        }


        
        if (!bool || 1 == b2 % 2) {


          
          long l = TimerRemaining(this.timerExpire);
          if (l <= b1)
          {
            throw sQLServerException;
          }
        } 
      } 





      
      if (!bool || 1 == b2 % 2) {
        
        if (connectionlogger.isLoggable(Level.FINE))
        {
          connectionlogger.fine(toString() + " sleeping milisec: " + b1);
        }
        
        try {
          Thread.sleep(b1);
        } catch (InterruptedException interruptedException) {}


        
        b1 = (b1 < 'Ǵ') ? (b1 * 2) : 1000;
      } 

      
      b2++;
      
      if (bool2 || bool3) {
        
        l2 = System.currentTimeMillis() + l1 * (b2 + 1);
      }
      else if (bool) {
        
        l2 = System.currentTimeMillis() + l1 * (b2 / 2 + 1);
      } else {
        
        l2 = this.timerExpire;
      } 
      
      if (l2 > this.timerExpire)
      {
        l2 = this.timerExpire;
      }
      
      if (bool) {
        bool1 = !bool1;
      }
    } 

    
    if (bool1 && null == this.failoverPartnerServerProvided) {
      
      String str = this.currentConnectPlaceHolder.getServerName();
      if (null != serverPortPlaceHolder1.getInstanceName()) {
        
        str = str + "\\";
        str = str + serverPortPlaceHolder1.getInstanceName();
      } 
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPartnerConfiguration"));
      Object[] arrayOfObject = { new String(this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.DATABASE_NAME.toString())), str };
      
      terminate(6, messageFormat.format(arrayOfObject));
    } 
    
    if (null != this.failoverPartnerServerProvided) {

      
      if (this.multiSubnetFailover) {
        
        String str = SQLServerException.getErrString("R_dbMirroringWithMultiSubnetFailover");
        terminate(6, str);
      } 

      
      if (this.applicationIntent != null && this.applicationIntent.equals(ApplicationIntent.READ_ONLY)) {
        
        String str = SQLServerException.getErrString("R_dbMirroringWithReadOnlyIntent");
        terminate(6, str);
      } 

      
      if (null == failoverInfo) {
        failoverInfo = new FailoverInfo(this.failoverPartnerServerProvided, this, false);
      }
      if (null != paramFailoverInfo) {



        
        paramFailoverInfo.failoverAdd(this, bool1, this.failoverPartnerServerProvided);
      }
      else {
        
        String str1 = SQLServerDriverStringProperty.DATABASE_NAME.toString();
        String str2 = SQLServerDriverStringProperty.INSTANCE_NAME.toString();
        String str3 = SQLServerDriverStringProperty.SERVER_NAME.toString();
        
        if (connectionlogger.isLoggable(Level.FINE))
        {
          connectionlogger.fine(toString() + " adding new failover info server: " + this.activeConnectionProperties.getProperty(str3) + " instance: " + this.activeConnectionProperties.getProperty(str2) + " database: " + this.activeConnectionProperties.getProperty(str1) + " server provided failover: " + this.failoverPartnerServerProvided);
        }



        
        failoverInfo.failoverAdd(this, bool1, this.failoverPartnerServerProvided);
        FailoverMapSingleton.putFailoverInfo(this, paramString1, this.activeConnectionProperties.getProperty(str2), this.activeConnectionProperties.getProperty(str1), failoverInfo, bool1, this.failoverPartnerServerProvided);
      } 
    } 
  }




  
  void resetNonRoutingEnvchangeValues() {
    this.tdsPacketSize = 4096;
    this.databaseCollation = null;
    this.rolledBackTransaction = false;
    Arrays.fill(getTransactionDescriptor(), (byte)0);
    this.sCatalog = this.originalCatalog;
    this.failoverPartnerServerProvided = null;
  }
  
  static final int DEFAULTPORT = SQLServerDriverIntProperty.PORT_NUMBER.getDefaultValue(); private final Object schedulerLock; volatile SQLWarning sqlWarnings; Integer warningSynchronization; private static final int ENVCHANGE_DATABASE = 1; private static final int ENVCHANGE_LANGUAGE = 2; private static final int ENVCHANGE_CHARSET = 3; private static final int ENVCHANGE_PACKETSIZE = 4; private static final int ENVCHANGE_SORTLOCALEID = 5; private static final int ENVCHANGE_SORTFLAGS = 6; private static final int ENVCHANGE_SQLCOLLATION = 7; private static final int ENVCHANGE_XACT_BEGIN = 8; private static final int ENVCHANGE_XACT_COMMIT = 9; private static final int ENVCHANGE_XACT_ROLLBACK = 10; private static final int ENVCHANGE_DTC_ENLIST = 11; private static final int ENVCHANGE_DTC_DEFECT = 12; private static final int ENVCHANGE_CHANGE_MIRROR = 13; private static final int ENVCHANGE_UNUSED_14 = 14; private static final int ENVCHANGE_DTC_PROMOTE = 15;
  private static final int ENVCHANGE_DTC_MGR_ADDR = 16;
  private static final int ENVCHANGE_XACT_ENDED = 17;
  private static final int ENVCHANGE_RESET_COMPLETE = 18;
  private static final int ENVCHANGE_USER_INFO = 19;
  private static final int ENVCHANGE_ROUTING = 20;
  
  ServerPortPlaceHolder primaryPermissionCheck(String paramString1, String paramString2, int paramInt) throws SQLServerException {
    if (0 == paramInt)
    {
      if (null != paramString2) {
        
        String str = getInstancePort(paramString1, paramString2);
        if (connectionlogger.isLoggable(Level.FINER)) {
          connectionlogger.fine(toString() + " SQL Server port returned by SQL Browser: " + str);
        }
        try {
          if (null != str) {
            
            paramInt = (new Integer(str)).intValue();
            
            if (paramInt < 0 || paramInt > 65535) {
              
              MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPortNumber"));
              Object[] arrayOfObject = { Integer.toString(paramInt) };
              SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
            } 
          } else {
            
            paramInt = DEFAULTPORT;
          }
        
        } catch (NumberFormatException numberFormatException) {
          
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPortNumber"));
          Object[] arrayOfObject = { Integer.valueOf(paramInt) };
          SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
        } 
      } else {
        
        paramInt = DEFAULTPORT;
      } 
    }
    
    this.activeConnectionProperties.setProperty(SQLServerDriverIntProperty.PORT_NUMBER.toString(), String.valueOf(paramInt));
    return new ServerPortPlaceHolder(paramString1, paramInt, paramString2, this.integratedSecurity);
  }

  
  static boolean timerHasExpired(long paramLong) {
    return (System.currentTimeMillis() > paramLong);
  }


  
  static int TimerRemaining(long paramLong) {
    long l1 = System.currentTimeMillis();
    long l2 = paramLong - l1;
    
    if (l2 > 2147483647L) {
      l2 = 2147483647L;
    }
    
    if (l2 <= 0L)
      l2 = 1L; 
    return (int)l2;
  }
























  
  private void connectHelper(ServerPortPlaceHolder paramServerPortPlaceHolder, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt3) throws SQLServerException {
    if (connectionlogger.isLoggable(Level.FINE))
    {
      connectionlogger.fine(toString() + " Connecting with server: " + paramServerPortPlaceHolder.getServerName() + " port: " + paramServerPortPlaceHolder.getPortNumber() + " Timeout slice: " + paramInt1 + " Timeout Full: " + paramInt2);
    }


    
    this.tdsChannel = new TDSChannel(this);
    if (0 == paramInt2) {
      this.tdsChannel.open(paramServerPortPlaceHolder.getServerName(), paramServerPortPlaceHolder.getPortNumber(), 0, paramBoolean1, paramBoolean2, paramBoolean3, paramInt3);
    } else {
      this.tdsChannel.open(paramServerPortPlaceHolder.getServerName(), paramServerPortPlaceHolder.getPortNumber(), paramInt1, paramBoolean1, paramBoolean2, paramBoolean3, paramInt3);
    } 
    
    setState(State.Connected);

    
    this.clientConnectionId = UUID.randomUUID();
    assert null != this.clientConnectionId;

    
    Prelogin(paramServerPortPlaceHolder.getServerName(), paramServerPortPlaceHolder.getPortNumber());

    
    if (2 != this.negotiatedEncryptionLevel) {
      this.tdsChannel.enableSSL(paramServerPortPlaceHolder.getServerName(), paramServerPortPlaceHolder.getPortNumber());
    }

    
    executeCommand(new LogonCommand());
  }



  
  void Prelogin(String paramString, int paramInt) throws SQLServerException {
    byte b1, b2;
    int j;
    if (!this.authenticationString.trim().equalsIgnoreCase(SqlAuthentication.NotSpecified.toString()) || null != this.accessTokenInByte)
    {
      
      this.fedAuthRequiredByUser = true;
    }



    
    if (this.fedAuthRequiredByUser) {
      
      b1 = 73;
      this.requestedEncryptionLevel = 1;



      
      b2 = 5;
    }
    else {
      
      b1 = 67;
      b2 = 0;
    } 
    
    byte[] arrayOfByte1 = new byte[b1];
    
    int i = 0;
    
    byte[] arrayOfByte2 = { 18, 1, 0, b1, 0, 0, 0, 0 };








    
    System.arraycopy(arrayOfByte2, 0, arrayOfByte1, i, arrayOfByte2.length);
    i += arrayOfByte2.length;
    
    byte[] arrayOfByte3 = { 0, 0, (byte)(16 + b2), 0, 6, 1, 0, (byte)(22 + b2), 0, 1, 5, 0, (byte)(23 + b2), 0, 36 };




    
    System.arraycopy(arrayOfByte3, 0, arrayOfByte1, i, arrayOfByte3.length);
    i += arrayOfByte3.length;
    
    if (this.fedAuthRequiredByUser) {
      byte[] arrayOfByte = { 6, 0, 64, 0, 1 };

      
      System.arraycopy(arrayOfByte, 0, arrayOfByte1, i, arrayOfByte.length);
      i += arrayOfByte.length;
    } 
    
    arrayOfByte1[i] = -1;
    i++;

    
    byte[] arrayOfByte4 = { 0, 0, 0, 0, 0, 0, this.requestedEncryptionLevel, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };










    
    System.arraycopy(arrayOfByte4, 0, arrayOfByte1, i, arrayOfByte4.length);
    i += arrayOfByte4.length;


    
    if (this.fedAuthRequiredByUser) {
      arrayOfByte1[i] = 1;
      i++;
    } 
    
    byte[] arrayOfByte5 = new byte[4096];
    String str = " Prelogin error: host " + paramString + " port " + paramInt;
    
    ActivityId activityId = ActivityCorrelator.getNext();
    byte[] arrayOfByte6 = Util.asGuidByteArray(activityId.getId());
    byte[] arrayOfByte7 = Util.asGuidByteArray(this.clientConnectionId);


    
    if (this.fedAuthRequiredByUser) {
      j = arrayOfByte1.length - 36 - 1;
    }
    else {
      
      j = arrayOfByte1.length - 36;
    } 

    
    System.arraycopy(arrayOfByte7, 0, arrayOfByte1, j, arrayOfByte7.length);
    j += arrayOfByte7.length;

    
    System.arraycopy(arrayOfByte6, 0, arrayOfByte1, j, arrayOfByte6.length);
    j += arrayOfByte6.length;
    
    long l = activityId.getSequence();
    Util.writeInt((int)l, arrayOfByte1, j);
    j += 4;
    
    if (connectionlogger.isLoggable(Level.FINER)) {
      
      connectionlogger.finer(toString() + " Requesting encryption level:" + TDS.getEncryptionLevel(this.requestedEncryptionLevel));
      connectionlogger.finer(toString() + " ActivityId " + activityId.toString());
    } 

    
    if (this.tdsChannel.isLoggingPackets()) {
      this.tdsChannel.logPacket(arrayOfByte1, 0, arrayOfByte1.length, toString() + " Prelogin request");
    }
    
    try {
      this.tdsChannel.write(arrayOfByte1, 0, arrayOfByte1.length);
      this.tdsChannel.flush();
    }
    catch (SQLServerException sQLServerException) {
      
      connectionlogger.warning(toString() + str + " Error sending prelogin request: " + sQLServerException.getMessage());
      throw sQLServerException;
    } 
    
    ActivityCorrelator.setCurrentActivityIdSentFlag();

    
    int k = arrayOfByte5.length;
    int m = 0;
    boolean bool1 = false;
    while (m < k) {
      int n;


      
      try {
        n = this.tdsChannel.read(arrayOfByte5, m, k - m);
      }
      catch (SQLServerException sQLServerException) {
        
        connectionlogger.warning(toString() + str + " Error reading prelogin response: " + sQLServerException.getMessage());
        throw sQLServerException;
      } 





      
      if (-1 == n) {
        
        connectionlogger.warning(toString() + str + " Unexpected end of prelogin response after " + m + " bytes read");
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_tcpipConnectionFailed"));
        Object[] arrayOfObject = { paramString, Integer.toString(paramInt), SQLServerException.getErrString("R_notSQLServer") };
        terminate(3, messageFormat.format(arrayOfObject));
      } 

      
      assert n >= 0;
      assert n <= k - m;
      
      if (this.tdsChannel.isLoggingPackets()) {
        this.tdsChannel.logPacket(arrayOfByte5, m, n, toString() + " Prelogin response");
      }
      m += n;


      
      if (!bool1 && m >= 8) {

        
        if (4 != arrayOfByte5[0]) {
          
          connectionlogger.warning(toString() + str + " Unexpected response type:" + arrayOfByte5[0]);
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_tcpipConnectionFailed"));
          Object[] arrayOfObject = { paramString, Integer.toString(paramInt), SQLServerException.getErrString("R_notSQLServer") };
          terminate(3, messageFormat.format(arrayOfObject));
        } 



        
        if (1 != (0x1 & arrayOfByte5[1])) {
          
          connectionlogger.warning(toString() + str + " Unexpected response status:" + arrayOfByte5[1]);
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_tcpipConnectionFailed"));
          Object[] arrayOfObject = { paramString, Integer.toString(paramInt), SQLServerException.getErrString("R_notSQLServer") };
          terminate(3, messageFormat.format(arrayOfObject));
        } 

        
        k = Util.readUnsignedShortBigEndian(arrayOfByte5, 2);
        assert k >= 0;
        
        if (k >= arrayOfByte5.length) {
          
          connectionlogger.warning(toString() + str + " Response length:" + k + " is greater than allowed length:" + arrayOfByte5.length);
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_tcpipConnectionFailed"));
          Object[] arrayOfObject = { paramString, Integer.toString(paramInt), SQLServerException.getErrString("R_notSQLServer") };
          terminate(3, messageFormat.format(arrayOfObject));
        } 
        
        bool1 = true;
      } 
    } 


    
    boolean bool2 = false;
    this.negotiatedEncryptionLevel = -1;
    
    byte b3 = 8;

    
    while (true) {
      if (b3 >= k) {
        
        connectionlogger.warning(toString() + " Option token not found");
        throwInvalidTDS();
      } 
      byte b = arrayOfByte5[b3++];

      
      if (-1 == b) {
        break;
      }
      
      if (b3 + 4 >= k) {
        
        connectionlogger.warning(toString() + " Offset/Length not found for option:" + b);
        throwInvalidTDS();
      } 
      
      int n = Util.readUnsignedShortBigEndian(arrayOfByte5, b3) + 8;
      b3 += 2;
      assert n >= 0;
      
      int i1 = Util.readUnsignedShortBigEndian(arrayOfByte5, b3);
      b3 += 2;
      assert i1 >= 0;
      
      if (n + i1 > k) {
        
        connectionlogger.warning(toString() + " Offset:" + n + " and length:" + i1 + " exceed response length:" + k);
        throwInvalidTDS();
      } 
      
      switch (b) {
        
        case 0:
          if (bool2) {
            
            connectionlogger.warning(toString() + " Version option already received");
            throwInvalidTDS();
          } 
          
          if (6 != i1) {
            
            connectionlogger.warning(toString() + " Version option length:" + i1 + " is incorrect.  Correct value is 6.");
            throwInvalidTDS();
          } 
          
          this.serverMajorVersion = arrayOfByte5[n];
          if (this.serverMajorVersion < 9) {
            
            connectionlogger.warning(toString() + " Server major version:" + this.serverMajorVersion + " is not supported by this driver.");
            MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedServerVersion"));
            Object[] arrayOfObject = { Integer.toString(arrayOfByte5[n]) };
            terminate(6, messageFormat.format(arrayOfObject));
          } 
          
          if (connectionlogger.isLoggable(Level.FINE)) {
            connectionlogger.fine(toString() + " Server returned major version:" + arrayOfByte5[n]);
          }
          bool2 = true;
          continue;
        
        case 1:
          if (-1 != this.negotiatedEncryptionLevel) {
            
            connectionlogger.warning(toString() + " Encryption option already received");
            throwInvalidTDS();
          } 
          
          if (1 != i1) {
            
            connectionlogger.warning(toString() + " Encryption option length:" + i1 + " is incorrect.  Correct value is 1.");
            throwInvalidTDS();
          } 
          
          this.negotiatedEncryptionLevel = arrayOfByte5[n];

          
          if (0 != this.negotiatedEncryptionLevel && 1 != this.negotiatedEncryptionLevel && 3 != this.negotiatedEncryptionLevel && 2 != this.negotiatedEncryptionLevel) {



            
            connectionlogger.warning(toString() + " Server returned " + TDS.getEncryptionLevel(this.negotiatedEncryptionLevel));
            throwInvalidTDS();
          } 
          
          if (connectionlogger.isLoggable(Level.FINER)) {
            connectionlogger.finer(toString() + " Negotiated encryption level:" + TDS.getEncryptionLevel(this.negotiatedEncryptionLevel));
          }
          
          if (1 == this.requestedEncryptionLevel && 1 != this.negotiatedEncryptionLevel && 3 != this.negotiatedEncryptionLevel)
          {

            
            terminate(5, SQLServerException.getErrString("R_sslRequiredNoServerSupport"));
          }


          
          if (2 == this.requestedEncryptionLevel && 2 != this.negotiatedEncryptionLevel) {


            
            if (3 == this.negotiatedEncryptionLevel) {
              terminate(5, SQLServerException.getErrString("R_sslRequiredByServer"));
            }
            connectionlogger.warning(toString() + " Client requested encryption level: " + TDS.getEncryptionLevel(this.requestedEncryptionLevel) + " Server returned unexpected encryption level: " + TDS.getEncryptionLevel(this.negotiatedEncryptionLevel));

            
            throwInvalidTDS();
          } 
          continue;

        
        case 6:
          if (0 != arrayOfByte5[n] && 1 != arrayOfByte5[n]) {
            connectionlogger.severe(toString() + " Server sent an unexpected value for FedAuthRequired PreLogin Option. Value was " + arrayOfByte5[n]);
            MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_FedAuthRequiredPreLoginResponseInvalidValue"));
            throw new SQLServerException(messageFormat.format(new Object[] { Byte.valueOf(arrayOfByte5[n]) }, ), null);
          } 



          
          if ((null != this.authenticationString && !this.authenticationString.equalsIgnoreCase(SqlAuthentication.NotSpecified.toString())) || null != this.accessTokenInByte)
          {

            
            this.fedAuthRequiredPreLoginResponse = (arrayOfByte5[n] == 1);
          }
          continue;
      } 
      
      if (connectionlogger.isLoggable(Level.FINER)) {
        connectionlogger.finer(toString() + " Ignoring prelogin response option:" + b);
      }
    } 

    
    if (!bool2 || -1 == this.negotiatedEncryptionLevel) {
      
      connectionlogger.warning(toString() + " Prelogin response is missing version and/or encryption option.");
      throwInvalidTDS();
    } 
  }

  
  final void throwInvalidTDS() throws SQLServerException {
    terminate(4, SQLServerException.getErrString("R_invalidTDS"));
  }

  
  final void throwInvalidTDSToken(String paramString) throws SQLServerException {
    MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unexpectedToken"));
    Object[] arrayOfObject = { paramString };
    String str = SQLServerException.getErrString("R_invalidTDS") + messageFormat.format(arrayOfObject);
    terminate(4, str);
  }







  
  final void terminate(int paramInt, String paramString) throws SQLServerException {
    terminate(paramInt, paramString, null);
  } boolean executeCommand(TDSCommand paramTDSCommand) throws SQLServerException { synchronized (this.schedulerLock) { if (null != this.currentCommand) { this.currentCommand.detach(); this.currentCommand = null; }  boolean bool = false; try { bool = paramTDSCommand.execute(this.tdsChannel.getWriter(), this.tdsChannel.getReader(paramTDSCommand)); } finally { if (!bool && !isSessionUnAvailable()) this.currentCommand = paramTDSCommand;  }  return bool; }  } void resetCurrentCommand() throws SQLServerException { if (null != this.currentCommand) { this.currentCommand.detach(); this.currentCommand = null; }  } private final void connectionCommand(String paramString1, String paramString2) throws SQLServerException { final class ConnectionCommand extends UninterruptableTDSCommand {
      final String sql; ConnectionCommand(String param1String1, String param1String2) { super(param1String2); this.sql = param1String1; }
      final boolean doExecute() throws SQLServerException { startRequest((byte)1).writeString(this.sql); TDSParser.parse(startResponse(), getLogContext()); return true; } }; executeCommand(new ConnectionCommand(paramString1, paramString2)); }
  private String sqlStatementToInitialize() { String str = null; if (this.nLockTimeout > -1) str = " set lock_timeout " + this.nLockTimeout;  return str; }
  final void terminate(int paramInt, String paramString, Throwable paramThrowable) throws SQLServerException { String str = this.state.equals(State.Opened) ? "08006" : "08001";



    
    if (!this.xopenStates) {
      str = SQLServerException.mapFromXopen(str);
    }
    SQLServerException sQLServerException = new SQLServerException(this, SQLServerException.checkAndAppendClientConnId(paramString, this), str, 0, true);






    
    if (null != paramThrowable) {
      sQLServerException.initCause(paramThrowable);
    }
    sQLServerException.setDriverErrorCode(paramInt);
    
    notifyPooledConnection(sQLServerException);
    
    close();
    
    throw sQLServerException; } void setCatalogName(String paramString) { if (paramString != null)
      if (paramString.length() > 0)
        this.sCatalog = paramString;   }
  String sqlStatementToSetTransactionIsolationLevel() throws SQLServerException { String str = "set transaction isolation level "; switch (this.transactionIsolationLevel) { case 1: str = str + " read uncommitted "; return str;case 2: str = str + " read committed "; return str;
      case 4: str = str + " repeatable read "; return str;
      case 8: str = str + " serializable "; return str;
      case 4096: str = str + " snapshot "; return str; }  MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidTransactionLevel")); Object[] arrayOfObject = { Integer.toString(this.transactionIsolationLevel) }; SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false); return str; }
  static String sqlStatementToSetCommit(boolean paramBoolean) { return (true == paramBoolean) ? "set implicit_transactions off " : "set implicit_transactions on "; }
  SQLServerConnection(String paramString) throws SQLServerException { this.schedulerLock = new Object();
























































































































































































































































































































































































































































































    
    this.warningSynchronization = new Integer(1); int i = nextConnectionID(); this.traceID = "ConnectionID:" + i; this.loggingClassName = "com.microsoft.sqlserver.jdbc.SQLServerConnection:" + i; if (connectionlogger.isLoggable(Level.FINE)) connectionlogger.fine(toString() + " created by (" + paramString + ")");  initResettableValues(); }
  public Statement createStatement() throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "createStatement"); Statement statement = createStatement(1003, 1007); loggerExternal.exiting(getClassNameLogging(), "createStatement", statement); return statement; }
  public PreparedStatement prepareStatement(String paramString) throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "prepareStatement", paramString); PreparedStatement preparedStatement = prepareStatement(paramString, 1003, 1007); loggerExternal.exiting(getClassNameLogging(), "prepareStatement", preparedStatement); return preparedStatement; }
  public CallableStatement prepareCall(String paramString) throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "prepareCall", paramString); CallableStatement callableStatement = prepareCall(paramString, 1003, 1007); loggerExternal.exiting(getClassNameLogging(), "prepareCall", callableStatement); return callableStatement; } public String nativeSQL(String paramString) throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "nativeSQL", paramString); checkClosed(); loggerExternal.exiting(getClassNameLogging(), "nativeSQL", paramString); return paramString; } public void setAutoCommit(boolean paramBoolean) throws SQLServerException { if (loggerExternal.isLoggable(Level.FINER)) { loggerExternal.entering(getClassNameLogging(), "setAutoCommit", Boolean.valueOf(paramBoolean)); if (Util.IsActivityTraceOn()) loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());  }  String str = ""; checkClosed(); if (paramBoolean == this.databaseAutoCommitMode) return;  if (paramBoolean == true) str = "IF @@TRANCOUNT > 0 COMMIT TRAN ";  if (connectionlogger.isLoggable(Level.FINER)) connectionlogger.finer(toString() + " Autocommitmode current :" + this.databaseAutoCommitMode + " new: " + paramBoolean);  this.rolledBackTransaction = false; connectionCommand(str + sqlStatementToSetCommit(paramBoolean), "setAutoCommit"); this.databaseAutoCommitMode = paramBoolean; loggerExternal.exiting(getClassNameLogging(), "setAutoCommit"); } public boolean getAutoCommit() throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "getAutoCommit"); checkClosed(); boolean bool = (!this.inXATransaction && this.databaseAutoCommitMode) ? true : false; if (loggerExternal.isLoggable(Level.FINER)) loggerExternal.exiting(getClassNameLogging(), "getAutoCommit", Boolean.valueOf(bool));  return bool; } final byte[] getTransactionDescriptor() { return this.transactionDescriptor; } public void commit() throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "commit"); if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn()) loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());  checkClosed(); if (!this.databaseAutoCommitMode) connectionCommand("IF @@TRANCOUNT > 0 COMMIT TRAN", "Connection.commit");  loggerExternal.exiting(getClassNameLogging(), "commit"); } public void rollback() throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "rollback"); if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn()) loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());  checkClosed(); if (this.databaseAutoCommitMode) { SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_cantInvokeRollback"), (String)null, true); } else { connectionCommand("IF @@TRANCOUNT > 0 ROLLBACK TRAN", "Connection.rollback"); }  loggerExternal.exiting(getClassNameLogging(), "rollback"); } public void abort(Executor paramExecutor) throws SQLException { loggerExternal.entering(getClassNameLogging(), "abort", paramExecutor); DriverJDBCVersion.checkSupportsJDBC41(); if (isClosed()) return;  if (null == paramExecutor) { MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidArgument")); Object[] arrayOfObject = { "executor" }; SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, messageFormat.format(arrayOfObject), (String)null, false); }  SecurityManager securityManager = System.getSecurityManager(); if (securityManager != null) try { SQLPermission sQLPermission = new SQLPermission("callAbort"); securityManager.checkPermission(sQLPermission); } catch (SecurityException securityException) { MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_permissionDenied")); Object[] arrayOfObject = { "callAbort" }; SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, true); }   setState(State.Closed); paramExecutor.execute(new Runnable() {
          public void run() { if (null != SQLServerConnection.this.tdsChannel) SQLServerConnection.this.tdsChannel.close();  }
        }); loggerExternal.exiting(getClassNameLogging(), "abort"); } public SQLWarning getWarnings() throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "getWarnings");
    checkClosed();
    
    loggerExternal.exiting(getClassNameLogging(), "getWarnings", this.sqlWarnings);
    return this.sqlWarnings; }
  public void close() throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "close"); setState(State.Closed); if (null != this.tdsChannel)
      this.tdsChannel.close();  loggerExternal.exiting(getClassNameLogging(), "close"); }
  final void poolCloseEventNotify() throws SQLServerException { if (this.state.equals(State.Opened) && null != this.pooledConnectionParent) { if (!this.databaseAutoCommitMode && !(this.pooledConnectionParent instanceof javax.sql.XAConnection))
        connectionCommand("IF @@TRANCOUNT > 0 ROLLBACK TRAN", "close connection");  notifyPooledConnection(null); if (connectionlogger.isLoggable(Level.FINER))
        connectionlogger.finer(toString() + " Connection closed and returned to connection pool");  }  }
  public boolean isClosed() throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "isClosed"); loggerExternal.exiting(getClassNameLogging(), "isClosed", Boolean.valueOf(isSessionUnAvailable())); return isSessionUnAvailable(); } private void addWarning(String paramString) { synchronized (this.warningSynchronization)
    
    { SQLWarning sQLWarning = new SQLWarning(paramString);

      
      if (null == this.sqlWarnings)
      
      { this.sqlWarnings = sQLWarning; }
      
      else
      
      { this.sqlWarnings.setNextWarning(sQLWarning); }  }  } public DatabaseMetaData getMetaData() throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "getMetaData"); checkClosed(); if (this.databaseMetaData == null) this.databaseMetaData = new SQLServerDatabaseMetaData(this);  loggerExternal.exiting(getClassNameLogging(), "getMetaData", this.databaseMetaData); return this.databaseMetaData; }
  public void setReadOnly(boolean paramBoolean) throws SQLServerException { if (loggerExternal.isLoggable(Level.FINER)) loggerExternal.entering(getClassNameLogging(), "setReadOnly", Boolean.valueOf(paramBoolean));  checkClosed(); loggerExternal.exiting(getClassNameLogging(), "setReadOnly"); }
  public boolean isReadOnly() throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "isReadOnly"); checkClosed(); if (loggerExternal.isLoggable(Level.FINER)) loggerExternal.exiting(getClassNameLogging(), "isReadOnly", Boolean.valueOf(false));  return false; }
  public void setCatalog(String paramString) throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "setCatalog", paramString); if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn()) loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());  checkClosed(); if (paramString != null) { connectionCommand("use " + Util.escapeSQLId(paramString), "setCatalog"); this.sCatalog = paramString; }  loggerExternal.exiting(getClassNameLogging(), "setCatalog"); }
  public String getCatalog() throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "getCatalog"); checkClosed(); loggerExternal.exiting(getClassNameLogging(), "getCatalog", this.sCatalog); return this.sCatalog; }
  public void setTransactionIsolation(int paramInt) throws SQLServerException { if (loggerExternal.isLoggable(Level.FINER)) { loggerExternal.entering(getClassNameLogging(), "setTransactionIsolation", new Integer(paramInt)); if (Util.IsActivityTraceOn()) loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());  }  checkClosed(); if (paramInt == 0) return;  this.transactionIsolationLevel = paramInt; String str = sqlStatementToSetTransactionIsolationLevel(); connectionCommand(str, "setTransactionIsolation"); loggerExternal.exiting(getClassNameLogging(), "setTransactionIsolation"); }
  public int getTransactionIsolation() throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "getTransactionIsolation"); checkClosed(); if (loggerExternal.isLoggable(Level.FINER)) loggerExternal.exiting(getClassNameLogging(), "getTransactionIsolation", new Integer(this.transactionIsolationLevel));  return this.transactionIsolationLevel; }
  public void clearWarnings() throws SQLServerException { synchronized (this.warningSynchronization) {
      
      loggerExternal.entering(getClassNameLogging(), "clearWarnings");
      checkClosed();
      this.sqlWarnings = null;
      loggerExternal.exiting(getClassNameLogging(), "clearWarnings");
    }  }



  
  public Statement createStatement(int paramInt1, int paramInt2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "createStatement", new Object[] { new Integer(paramInt1), new Integer(paramInt2) }); 
    checkClosed();
    SQLServerStatement sQLServerStatement = new SQLServerStatement(this, paramInt1, paramInt2, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
    loggerExternal.exiting(getClassNameLogging(), "createStatement", sQLServerStatement);
    return sQLServerStatement;
  }

  
  public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, new Integer(paramInt1), new Integer(paramInt2) }); 
    checkClosed();
    SQLServerPreparedStatement sQLServerPreparedStatement = new SQLServerPreparedStatement(this, paramString, paramInt1, paramInt2, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);

    
    loggerExternal.exiting(getClassNameLogging(), "prepareStatement", sQLServerPreparedStatement);
    return sQLServerPreparedStatement;
  }

  
  private PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, new Integer(paramInt1), new Integer(paramInt2), paramSQLServerStatementColumnEncryptionSetting }); 
    checkClosed();
    SQLServerPreparedStatement sQLServerPreparedStatement = new SQLServerPreparedStatement(this, paramString, paramInt1, paramInt2, paramSQLServerStatementColumnEncryptionSetting);
    
    loggerExternal.exiting(getClassNameLogging(), "prepareStatement", sQLServerPreparedStatement);
    return sQLServerPreparedStatement;
  }

  
  public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "prepareCall", new Object[] { paramString, new Integer(paramInt1), new Integer(paramInt2) }); 
    checkClosed();
    SQLServerCallableStatement sQLServerCallableStatement = new SQLServerCallableStatement(this, paramString, paramInt1, paramInt2, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);




    
    loggerExternal.exiting(getClassNameLogging(), "prepareCall", sQLServerCallableStatement);
    return sQLServerCallableStatement;
  }

  
  public void setTypeMap(Map<String, Class<?>> paramMap) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "setTypeMap", paramMap);
    checkClosed();
    if (paramMap != null && paramMap instanceof HashMap)
    {
      
      if (paramMap.isEmpty()) {
        
        loggerExternal.exiting(getClassNameLogging(), "setTypeMap");
        
        return;
      } 
    }
    NotImplemented();
  }

  
  public Map<String, Class<?>> getTypeMap() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getTypeMap");
    checkClosed();
    HashMap<Object, Object> hashMap = new HashMap<>();
    loggerExternal.exiting(getClassNameLogging(), "getTypeMap", hashMap);
    return (Map)hashMap;
  }




  
  int writeAEFeatureRequest(boolean paramBoolean, TDSWriter paramTDSWriter) throws SQLServerException {
    byte b = 6;
    
    if (paramBoolean) {
      
      paramTDSWriter.writeByte((byte)4);
      paramTDSWriter.writeInt(1);
      paramTDSWriter.writeByte((byte)1);
    } 
    return b;
  }

  
  int writeFedAuthFeatureRequest(boolean paramBoolean, TDSWriter paramTDSWriter, FederatedAuthenticationFeatureExtensionData paramFederatedAuthenticationFeatureExtensionData) throws SQLServerException {
    assert paramFederatedAuthenticationFeatureExtensionData.libraryType == 2 || paramFederatedAuthenticationFeatureExtensionData.libraryType == 1;
    
    int i = 0;
    int j = 0;

    
    switch (paramFederatedAuthenticationFeatureExtensionData.libraryType) {
      case 2:
        i = 2;
        break;
      case 1:
        assert null != paramFederatedAuthenticationFeatureExtensionData.accessToken;
        i = 5 + paramFederatedAuthenticationFeatureExtensionData.accessToken.length;
        break;
      
      default:
        assert false;
        break;
    } 
    j = i + 5;

    
    if (paramBoolean)
    { byte b1; paramTDSWriter.writeByte((byte)2);

      
      byte b = 0;

      
      switch (paramFederatedAuthenticationFeatureExtensionData.libraryType) {
        case 2:
          assert this.federatedAuthenticationInfoRequested == true;
          b = (byte)(b | 0x4);
          break;
        case 1:
          assert this.federatedAuthenticationRequested == true;
          b = (byte)(b | 0x2);
          break;
        
        default:
          assert false;
          break;
      } 
      b = (byte)(b | (byte)((paramFederatedAuthenticationFeatureExtensionData.fedAuthRequiredPreLoginResponse == true) ? 1 : 0));

      
      paramTDSWriter.writeInt(i);


      
      paramTDSWriter.writeByte(b);


      
      switch (paramFederatedAuthenticationFeatureExtensionData.libraryType)
      { case 2:
          b1 = 0;
          switch (paramFederatedAuthenticationFeatureExtensionData.authentication) {
            case ActiveDirectoryPassword:
              b1 = 1;
              break;
            case ActiveDirectoryIntegrated:
              b1 = 2;
              break;
            
            default:
              assert false;
              break;
          } 
          paramTDSWriter.writeByte(b1);









          
          return j;case 1: paramTDSWriter.writeInt(paramFederatedAuthenticationFeatureExtensionData.accessToken.length); paramTDSWriter.writeBytes(paramFederatedAuthenticationFeatureExtensionData.accessToken, 0, paramFederatedAuthenticationFeatureExtensionData.accessToken.length); return j; }  assert false; }  return j;
  }
  
  private final class LogonCommand
    extends UninterruptableTDSCommand
  {
    LogonCommand() {
      super("logon");
    }

    
    final boolean doExecute() throws SQLServerException {
      SQLServerConnection.this.logon(this);
      return true;
    }
  }
  
  private final void logon(LogonCommand paramLogonCommand) throws SQLServerException {
    KerbAuthentication kerbAuthentication;
    AuthenticationJNI authenticationJNI = null;
    if (this.integratedSecurity && AuthenticationScheme.nativeAuthentication == this.intAuthScheme)
      authenticationJNI = new AuthenticationJNI(this, this.currentConnectPlaceHolder.getServerName(), this.currentConnectPlaceHolder.getPortNumber()); 
    if (this.integratedSecurity && AuthenticationScheme.javaKerberos == this.intAuthScheme) {
      kerbAuthentication = new KerbAuthentication(this, this.currentConnectPlaceHolder.getServerName(), this.currentConnectPlaceHolder.getPortNumber());
    }


    
    if (this.authenticationString.trim().equalsIgnoreCase(SqlAuthentication.ActiveDirectoryPassword.toString()) || (this.authenticationString.trim().equalsIgnoreCase(SqlAuthentication.ActiveDirectoryIntegrated.toString()) && this.fedAuthRequiredPreLoginResponse)) {
      
      this.federatedAuthenticationInfoRequested = true;
      this.fedAuthFeatureExtensionData = new FederatedAuthenticationFeatureExtensionData(2, this.authenticationString, this.fedAuthRequiredPreLoginResponse);
    } 



    
    if (null != this.accessTokenInByte) {
      this.fedAuthFeatureExtensionData = new FederatedAuthenticationFeatureExtensionData(1, this.fedAuthRequiredPreLoginResponse, this.accessTokenInByte);




      
      this.federatedAuthenticationRequested = true;
    } 

    
    try {
      sendLogon(paramLogonCommand, kerbAuthentication, this.fedAuthFeatureExtensionData);



      
      if (!this.isRoutedInCurrentAttempt)
      {
        this.originalCatalog = this.sCatalog;
        String str = sqlStatementToInitialize();
        if (str != null)
        {
          connectionCommand(str, "Change Settings");
        }
      }
    
    } finally {
      
      if (this.integratedSecurity) {
        
        if (null != kerbAuthentication)
          kerbAuthentication.ReleaseClientContext(); 
        kerbAuthentication = null;
      } 
    } 
  }




















  
  final void processEnvChange(TDSReader paramTDSReader) throws SQLServerException {
    byte[] arrayOfByte;
    int k, m, n, i1;
    String str1, str2;
    paramTDSReader.readUnsignedByte();
    int i = paramTDSReader.readUnsignedShort();
    
    TDSReaderMark tDSReaderMark = paramTDSReader.mark();
    int j = paramTDSReader.readUnsignedByte();
    switch (j) {
      
      case 4:
        
        try {
          
          this.tdsPacketSize = Integer.parseInt(paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte()));
        }
        catch (NumberFormatException numberFormatException) {
          
          paramTDSReader.throwInvalidTDS();
        } 
        if (connectionlogger.isLoggable(Level.FINER)) {
          connectionlogger.finer(toString() + " Network packet size is " + this.tdsPacketSize + " bytes");
        }
        break;
      case 7:
        if (SQLCollation.tdsLength() != paramTDSReader.readUnsignedByte()) {
          paramTDSReader.throwInvalidTDS();
        }
        
        try {
          this.databaseCollation = new SQLCollation(paramTDSReader);
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
          
          terminate(4, unsupportedEncodingException.getMessage(), unsupportedEncodingException);
        } 
        break;

      
      case 8:
      case 11:
        this.rolledBackTransaction = false;
        arrayOfByte = getTransactionDescriptor();
        
        if (arrayOfByte.length != paramTDSReader.readUnsignedByte()) {
          paramTDSReader.throwInvalidTDS();
        }
        paramTDSReader.readBytes(arrayOfByte, 0, arrayOfByte.length);
        
        if (connectionlogger.isLoggable(Level.FINER)) {
          String str;
          
          if (8 == j) {
            str = " started";
          } else {
            str = " enlisted";
          } 
          connectionlogger.finer(toString() + str);
        } 
        break;

      
      case 10:
        this.rolledBackTransaction = true;
        
        if (this.inXATransaction) {
          
          if (connectionlogger.isLoggable(Level.FINER)) {
            connectionlogger.finer(toString() + " rolled back. (DTC)");
          }


          
          break;
        } 

        
        if (connectionlogger.isLoggable(Level.FINER)) {
          connectionlogger.finer(toString() + " rolled back");
        }
        
        Arrays.fill(getTransactionDescriptor(), (byte)0);
        break;


      
      case 9:
        if (connectionlogger.isLoggable(Level.FINER)) {
          connectionlogger.finer(toString() + " committed");
        }
        Arrays.fill(getTransactionDescriptor(), (byte)0);
        break;

      
      case 12:
        if (connectionlogger.isLoggable(Level.FINER)) {
          connectionlogger.finer(toString() + " defected");
        }
        Arrays.fill(getTransactionDescriptor(), (byte)0);
        break;

      
      case 1:
        setCatalogName(paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte()));
        break;
      
      case 13:
        setFailoverPartnerServerProvided(paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte()));
        break;
      
      case 2:
      case 3:
      case 5:
      case 6:
      case 15:
      case 16:
      case 17:
      case 18:
      case 19:
        if (connectionlogger.isLoggable(Level.FINER)) {
          connectionlogger.finer(toString() + " Ignored env change: " + j);
        }
        break;

      
      case 20:
        k = m = n = i1 = -1;
        
        str1 = null;

        
        try {
          k = paramTDSReader.readUnsignedShort();
          if (k <= 5)
          {
            throwInvalidTDS();
          }
          
          m = paramTDSReader.readUnsignedByte();
          if (m != 0)
          {
            throwInvalidTDS();
          }
          
          n = paramTDSReader.readUnsignedShort();
          if (n <= 0 || n > 65535)
          {
            throwInvalidTDS();
          }
          
          i1 = paramTDSReader.readUnsignedShort();
          if (i1 <= 0 || i1 > 1024)
          {
            throwInvalidTDS();
          }
          
          str1 = paramTDSReader.readUnicodeString(i1);
          assert str1 != null;
        
        }
        finally {
          
          if (connectionlogger.isLoggable(Level.FINER))
          {
            connectionlogger.finer(toString() + " Received routing ENVCHANGE with the following values." + " routingDataValueLength:" + k + " protocol:" + m + " portNumber:" + n + " serverNameLength:" + i1 + " serverName:" + ((str1 != null) ? str1 : "null"));
          }
        } 







        
        str2 = this.activeConnectionProperties.getProperty("hostNameInCertificate");
        if (null != str2 && str2.startsWith("*") && str1.indexOf('.') != -1) {
          
          char[] arrayOfChar1 = str2.toCharArray();
          char[] arrayOfChar2 = str1.toCharArray();
          boolean bool = true;





          
          for (int i2 = str2.length() - 1, i3 = str1.length() - 1; i2 > 0 && i3 > 0; i2--, i3--) {
            
            if (arrayOfChar2[i3] != arrayOfChar1[i2]) {
              
              bool = false;
              
              break;
            } 
          } 
          if (bool) {
            
            String str = "*" + str1.substring(str1.indexOf('.'));
            this.activeConnectionProperties.setProperty("hostNameInCertificate", str);
            
            if (connectionlogger.isLoggable(Level.FINER))
            {
              connectionlogger.finer(toString() + "Using new host to validate the SSL certificate");
            }
          } 
        } 
        
        this.isRoutedInCurrentAttempt = true;
        this.routingInfo = new ServerPortPlaceHolder(str1, n, null, this.integratedSecurity);
        break;


      
      default:
        connectionlogger.warning(toString() + " Unknown environment change: " + j);
        throwInvalidTDS();
        break;
    } 


    
    paramTDSReader.reset(tDSReaderMark);
    paramTDSReader.readBytes(new byte[i], 0, i);
  }
  
  final void processFedAuthInfo(TDSReader paramTDSReader, TDSTokenHandler paramTDSTokenHandler) throws SQLServerException {
    SqlFedAuthInfo sqlFedAuthInfo = new SqlFedAuthInfo();
    
    paramTDSReader.readUnsignedByte();

    
    int i = paramTDSReader.readInt();
    
    if (connectionlogger.isLoggable(Level.FINER))
    {
      connectionlogger.fine(toString() + " FEDAUTHINFO token stream length = " + i);
    }
    
    if (i < 4) {

      
      connectionlogger.severe(toString() + "FEDAUTHINFO token stream length too short for CountOfInfoIDs.");
      throw new SQLServerException(SQLServerException.getErrString("R_FedAuthInfoLengthTooShortForCountOfInfoIds"), null);
    } 

    
    int j = paramTDSReader.readInt();
    
    i -= 4;
    
    if (connectionlogger.isLoggable(Level.FINER))
    {
      connectionlogger.fine(toString() + " CountOfInfoIDs = " + j);
    }
    
    if (i > 0) {
      
      byte[] arrayOfByte = new byte[i];
      
      paramTDSReader.readBytes(arrayOfByte, 0, i);
      
      if (connectionlogger.isLoggable(Level.FINER))
      {
        connectionlogger.fine(toString() + " Read rest of FEDAUTHINFO token stream: " + Arrays.toString(arrayOfByte));
      }








      
      int k = j * 9;
      
      for (byte b = 0; b < j; b++) {
        int m = b * 9;
        
        byte b1 = arrayOfByte[m];
        byte[] arrayOfByte1 = new byte[4];
        arrayOfByte1[3] = arrayOfByte[m + 1];
        arrayOfByte1[2] = arrayOfByte[m + 2];
        arrayOfByte1[1] = arrayOfByte[m + 3];
        arrayOfByte1[0] = arrayOfByte[m + 4];
        ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte1);
        int n = byteBuffer.getInt();
        
        arrayOfByte1 = new byte[4];
        arrayOfByte1[3] = arrayOfByte[m + 5];
        arrayOfByte1[2] = arrayOfByte[m + 6];
        arrayOfByte1[1] = arrayOfByte[m + 7];
        arrayOfByte1[0] = arrayOfByte[m + 8];
        byteBuffer = ByteBuffer.wrap(arrayOfByte1);
        int i1 = byteBuffer.getInt();
        
        if (connectionlogger.isLoggable(Level.FINER))
        {
          connectionlogger.fine(toString() + " FedAuthInfoOpt: ID=" + b1 + ", DataLen=" + n + ", Offset=" + i1);
        }


        
        i1 -= 4;

        
        if (i1 < k || i1 >= i) {
          connectionlogger.severe(toString() + "FedAuthInfoDataOffset points to an invalid location.");
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_FedAuthInfoInvalidOffset"));
          throw new SQLServerException(messageFormat.format(new Object[] { Integer.valueOf(i1) }, ), null);
        } 

        
        String str = null;
        try {
          byte[] arrayOfByte2 = new byte[n];
          System.arraycopy(arrayOfByte, i1, arrayOfByte2, 0, n);
          str = new String(arrayOfByte2, "UTF-16LE");
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
          
          Object[] arrayOfObject = { "UTF-16LE" };
          throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
        }
        catch (Exception exception) {
          connectionlogger.severe(toString() + "Failed to read FedAuthInfoData.");
          throw new SQLServerException(SQLServerException.getErrString("R_FedAuthInfoFailedToReadData"), null);
        } 
        
        if (connectionlogger.isLoggable(Level.FINER))
        {
          connectionlogger.fine(toString() + " FedAuthInfoData: " + str);
        }

        
        switch (b1) {
          case 2:
            sqlFedAuthInfo.spn = str;
            break;
          case 1:
            sqlFedAuthInfo.stsurl = str;
            break;
          default:
            if (connectionlogger.isLoggable(Level.FINER))
            {
              connectionlogger.fine(toString() + " Ignoring unknown federated authentication info option: " + b1);
            }
            break;
        } 
      
      } 
    } else {
      connectionlogger.severe(toString() + "FEDAUTHINFO token stream is not long enough to contain the data it claims to.");
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_FedAuthInfoLengthTooShortForData"));
      throw new SQLServerException(messageFormat.format(new Object[] { Integer.valueOf(i) }, ), null);
    } 
    
    if (null == sqlFedAuthInfo.spn || null == sqlFedAuthInfo.stsurl || sqlFedAuthInfo.spn.trim().isEmpty() || sqlFedAuthInfo.stsurl.trim().isEmpty()) {
      
      connectionlogger.severe(toString() + "FEDAUTHINFO token stream does not contain both STSURL and SPN.");
      throw new SQLServerException(SQLServerException.getErrString("R_FedAuthInfoDoesNotContainStsurlAndSpn"), null);
    } 
    
    onFedAuthInfo(sqlFedAuthInfo, paramTDSTokenHandler);
  }
  
  final class FedAuthTokenCommand
    extends UninterruptableTDSCommand
  {
    TDSTokenHandler tdsTokenHandler = null;
    SQLServerConnection.SqlFedAuthToken fedAuthToken = null;
    
    FedAuthTokenCommand(SQLServerConnection.SqlFedAuthToken param1SqlFedAuthToken, TDSTokenHandler param1TDSTokenHandler) {
      super("FedAuth");
      this.tdsTokenHandler = param1TDSTokenHandler;
      this.fedAuthToken = param1SqlFedAuthToken;
    }

    
    final boolean doExecute() throws SQLServerException {
      SQLServerConnection.this.sendFedAuthToken(this, this.fedAuthToken, this.tdsTokenHandler);
      return true;
    }
  }




  
  void onFedAuthInfo(SqlFedAuthInfo paramSqlFedAuthInfo, TDSTokenHandler paramTDSTokenHandler) throws SQLServerException {
    assert this.authenticationString.trim().equalsIgnoreCase(SqlAuthentication.ActiveDirectoryIntegrated.toString()) && this.fedAuthRequiredPreLoginResponse;

    
    assert null != paramSqlFedAuthInfo;
    
    this.attemptRefreshTokenLocked = true;
    this.fedAuthToken = getFedAuthToken(paramSqlFedAuthInfo);
    this.attemptRefreshTokenLocked = false;

    
    assert null != this.fedAuthToken;
    
    FedAuthTokenCommand fedAuthTokenCommand = new FedAuthTokenCommand(this.fedAuthToken, paramTDSTokenHandler);
    fedAuthTokenCommand.execute(this.tdsChannel.getWriter(), this.tdsChannel.getReader(fedAuthTokenCommand));
  }

  
  private SqlFedAuthToken getFedAuthToken(SqlFedAuthInfo paramSqlFedAuthInfo) throws SQLServerException {
    assert null != paramSqlFedAuthInfo;

    
    int i = 100;

    
    byte b = 0;
    
    FedAuthDllInfo fedAuthDllInfo = null;
    
    String str1 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString());
    String str2 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString());
    
    long l = 0L;
    
    while (true) {
      b++;
      
      try {
        if (this.authenticationString.trim().equalsIgnoreCase(SqlAuthentication.ActiveDirectoryPassword.toString())) {
          fedAuthDllInfo = AuthenticationJNI.getAccessToken(str1, str2, paramSqlFedAuthInfo.stsurl, paramSqlFedAuthInfo.spn, this.clientConnectionId.toString(), "7f98cb04-cd1e-40df-9140-3bf7e2cea4db", l);
        }
        else if (this.authenticationString.trim().equalsIgnoreCase(SqlAuthentication.ActiveDirectoryIntegrated.toString())) {
          fedAuthDllInfo = AuthenticationJNI.getAccessTokenForWindowsIntegrated(paramSqlFedAuthInfo.stsurl, paramSqlFedAuthInfo.spn, this.clientConnectionId.toString(), "7f98cb04-cd1e-40df-9140-3bf7e2cea4db", l);
        } 

        
        assert null != fedAuthDllInfo.accessTokenBytes;


        
        break;
      } catch (DLLException dLLException) {

        
        int j = dLLException.GetCategory();
        if (-1 == j) {
          MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_UnableLoadADALSqlDll"));
          Object[] arrayOfObject = { Integer.toHexString(dLLException.GetState()) };
          throw new SQLServerException(messageFormat.format(arrayOfObject), null);
        } 
        
        int k = TimerRemaining(this.timerExpire);
        if (2 != j || timerHasExpired(this.timerExpire) || i >= k) {

          
          String str4 = Integer.toHexString(dLLException.GetStatus());
          
          if (connectionlogger.isLoggable(Level.FINER))
          {
            connectionlogger.fine(toString() + " SQLServerConnection.getFedAuthToken.AdalException category:" + j + " error: " + str4);
          }
          
          MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_ADALAuthenticationMiddleErrorMessage"));
          String str5 = Integer.toHexString(dLLException.GetStatus()).toUpperCase();
          Object[] arrayOfObject1 = { str5, Integer.valueOf(dLLException.GetState()) };
          SQLServerException sQLServerException = new SQLServerException(messageFormat1.format(arrayOfObject1), dLLException);
          
          MessageFormat messageFormat2 = new MessageFormat(SQLServerException.getErrString("R_ADALExecution"));
          Object[] arrayOfObject2 = { str1, this.authenticationString };
          throw new SQLServerException(messageFormat2.format(arrayOfObject2), null, 0, sQLServerException);
        } 
        
        if (connectionlogger.isLoggable(Level.FINER)) {
          
          connectionlogger.fine(toString() + " SQLServerConnection.getFedAuthToken sleeping: " + i + " milliseconds.");
          connectionlogger.fine(toString() + " SQLServerConnection.getFedAuthToken remaining: " + k + " milliseconds.");
        } 
        
        try {
          Thread.sleep(i);
        } catch (InterruptedException interruptedException) {}

        
        i *= 2;
      } 
    } 
    
    byte[] arrayOfByte = fedAuthDllInfo.accessTokenBytes;
    
    String str3 = null;
    try {
      str3 = new String(arrayOfByte, "UTF-16LE");
    }
    catch (UnsupportedEncodingException unsupportedEncodingException) {
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
      
      Object[] arrayOfObject = { "UTF-16LE" };
      throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
    } 
    
    return new SqlFedAuthToken(str3, fedAuthDllInfo.expiresIn);
  }





  
  private void sendFedAuthToken(FedAuthTokenCommand paramFedAuthTokenCommand, SqlFedAuthToken paramSqlFedAuthToken, TDSTokenHandler paramTDSTokenHandler) throws SQLServerException {
    assert null != paramSqlFedAuthToken;
    assert null != paramSqlFedAuthToken.accessToken;
    
    if (connectionlogger.isLoggable(Level.FINER))
    {
      connectionlogger.fine(toString() + " Sending federated authentication token.");
    }
    
    TDSWriter tDSWriter = paramFedAuthTokenCommand.startRequest((byte)8);
    
    byte[] arrayOfByte = null;
    try {
      arrayOfByte = paramSqlFedAuthToken.accessToken.getBytes("UTF-16LE");
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
      
      Object[] arrayOfObject = { "UTF-16LE" };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    } 


    
    tDSWriter.writeInt(arrayOfByte.length + 4);

    
    tDSWriter.writeInt(arrayOfByte.length);

    
    tDSWriter.writeBytes(arrayOfByte, 0, arrayOfByte.length);

    
    TDSReader tDSReader = paramFedAuthTokenCommand.startResponse();
    
    this.federatedAuthenticationRequested = true;
    
    TDSParser.parse(tDSReader, paramTDSTokenHandler);
  }
  
  final void processFeatureExtAck(TDSReader paramTDSReader) throws SQLServerException {
    byte b;
    paramTDSReader.readUnsignedByte();


    
    do {
      b = (byte)paramTDSReader.readUnsignedByte();
      
      if (b == -1)
        continue; 
      int i = paramTDSReader.readInt();
      
      byte[] arrayOfByte = new byte[i];
      if (i > 0) {
        paramTDSReader.readBytes(arrayOfByte, 0, i);
      }
      onFeatureExtAck(b, arrayOfByte);
    }
    while (b != -1); } private void onFeatureExtAck(int paramInt, byte[] paramArrayOfbyte) throws SQLServerException {
    MessageFormat messageFormat;
    byte b;
    Object[] arrayOfObject;
    if (null != this.routingInfo) {
      return;
    }
    
    switch (paramInt) {
      case 2:
        if (connectionlogger.isLoggable(Level.FINER))
        {
          connectionlogger.fine(toString() + " Received feature extension acknowledgement for federated authentication.");
        }
        
        if (!this.federatedAuthenticationRequested) {
          connectionlogger.severe(toString() + " Did not request federated authentication.");
          MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_UnrequestedFeatureAckReceived"));
          Object[] arrayOfObject1 = { Integer.valueOf(paramInt) };
          throw new SQLServerException(messageFormat1.format(arrayOfObject1), null);
        } 

        
        assert null != this.fedAuthFeatureExtensionData;
        
        switch (this.fedAuthFeatureExtensionData.libraryType) {
          
          case 1:
          case 2:
            if (0 != paramArrayOfbyte.length) {
              connectionlogger.severe(toString() + " Federated authentication feature extension ack for ADAL and Security Token includes extra data.");
              throw new SQLServerException(SQLServerException.getErrString("R_FedAuthFeatureAckContainsExtraData"), null);
            } 
            break;
          
          default:
            assert false;
            connectionlogger.severe(toString() + " Attempting to use unknown federated authentication library.");
            messageFormat = new MessageFormat(SQLServerException.getErrString("R_FedAuthFeatureAckUnknownLibraryType"));
            arrayOfObject = new Object[] { Integer.valueOf(this.fedAuthFeatureExtensionData.libraryType) };
            throw new SQLServerException(messageFormat.format(arrayOfObject), null);
        } 
        this.federatedAuthenticationAcknowledged = true;
        return;

      
      case 4:
        if (connectionlogger.isLoggable(Level.FINER))
        {
          connectionlogger.fine(toString() + " Received feature extension acknowledgement for AE.");
        }
        
        if (1 > paramArrayOfbyte.length) {
          connectionlogger.severe(toString() + " Unknown version number for AE.");
          throw new SQLServerException(SQLServerException.getErrString("R_InvalidAEVersionNumber"), null);
        } 
        
        b = paramArrayOfbyte[0];
        if (0 == b || b > 1) {
          connectionlogger.severe(toString() + " Invalid version number for AE.");
          throw new SQLServerException(SQLServerException.getErrString("R_InvalidAEVersionNumber"), null);
        } 
        
        assert b == 1;
        this.serverSupportsColumnEncryption = true;
        return;
    } 


    
    connectionlogger.severe(toString() + " Unknown feature ack.");
    throw new SQLServerException(SQLServerException.getErrString("R_UnknownFeatureAck"), null);
  }



  
  private final void executeDTCCommand(int paramInt, byte[] paramArrayOfbyte, String paramString) throws SQLServerException {
    final class DTCCommand
      extends UninterruptableTDSCommand
    {
      private final int requestType;


      
      private final byte[] payload;



      
      DTCCommand(int param1Int, byte[] param1ArrayOfbyte, String param1String) {
        super(param1String);
        this.requestType = param1Int;
        this.payload = param1ArrayOfbyte;
      }

      
      final boolean doExecute() throws SQLServerException {
        TDSWriter tDSWriter = startRequest((byte)14);
        
        tDSWriter.writeShort((short)this.requestType);
        if (null == this.payload) {
          
          tDSWriter.writeShort((short)0);
        }
        else {
          
          assert this.payload.length <= 32767;
          tDSWriter.writeShort((short)this.payload.length);
          tDSWriter.writeBytes(this.payload);
        } 
        
        TDSParser.parse(startResponse(), getLogContext());
        return true;
      }
    };
    
    executeCommand(new DTCCommand(paramInt, paramArrayOfbyte, paramString));
  }






  
  final void JTAUnenlistConnection() throws SQLServerException {
    executeDTCCommand(1, null, "MS_DTC unenlist connection");
    this.inXATransaction = false;
  }







  
  final void JTAEnlistConnection(byte[] paramArrayOfbyte) throws SQLServerException {
    executeDTCCommand(1, paramArrayOfbyte, "MS_DTC enlist connection");


    
    connectionCommand(sqlStatementToSetTransactionIsolationLevel(), "JTAEnlistConnection");
    this.inXATransaction = true;
  }









  
  private byte[] toUCS16(String paramString) throws SQLServerException {
    if (paramString == null)
      return new byte[0]; 
    int i = paramString.length();
    byte[] arrayOfByte = new byte[i * 2];
    byte b1 = 0;
    for (byte b2 = 0; b2 < i; b2++) {
      char c = paramString.charAt(b2);
      byte b = (byte)(c & 0xFF);
      arrayOfByte[b1++] = b;
      arrayOfByte[b1++] = (byte)(c >> 8 & 0xFF);
    } 
    return arrayOfByte;
  }






  
  private byte[] encryptPassword(String paramString) {
    if (paramString == null) paramString = ""; 
    int i = paramString.length();
    byte[] arrayOfByte = new byte[i * 2];
    for (byte b = 0; b < i; b++) {
      int j = paramString.charAt(b) ^ 0x5A5A;
      j = (j & 0xF) << 4 | (j & 0xF0) >> 4 | (j & 0xF00) << 4 | (j & 0xF000) >> 4;
      byte b1 = (byte)((j & 0xFF00) >> 8);
      arrayOfByte[b * 2 + 1] = b1;
      byte b2 = (byte)(j & 0xFF);
      arrayOfByte[b * 2 + 0] = b2;
    } 
    return arrayOfByte;
  }







  
  private void sendLogon(LogonCommand paramLogonCommand, SSPIAuthentication paramSSPIAuthentication, FederatedAuthenticationFeatureExtensionData paramFederatedAuthenticationFeatureExtensionData) throws SQLServerException {
    final class LogonProcessor
      extends TDSTokenHandler
    {
      private final SSPIAuthentication auth;






      
      private byte[] secBlobOut = null;
      
      StreamLoginAck loginAckToken;
      
      LogonProcessor(SSPIAuthentication param1SSPIAuthentication) {
        super("logon");
        this.auth = param1SSPIAuthentication;
        this.loginAckToken = null;
      }

      
      boolean onSSPI(TDSReader param1TDSReader) throws SQLServerException {
        StreamSSPI streamSSPI = new StreamSSPI();
        streamSSPI.setFromTDS(param1TDSReader);



        
        boolean[] arrayOfBoolean = { false };
        this.secBlobOut = this.auth.GenerateClientContext(streamSSPI.sspiBlob, arrayOfBoolean);
        return true;
      }

      
      boolean onLoginAck(TDSReader param1TDSReader) throws SQLServerException {
        this.loginAckToken = new StreamLoginAck();
        this.loginAckToken.setFromTDS(param1TDSReader);
        SQLServerConnection.this.sqlServerVersion = this.loginAckToken.sSQLServerVersion;
        SQLServerConnection.this.tdsVersion = this.loginAckToken.tdsVersion;
        return true;
      }


      
      final boolean complete(SQLServerConnection.LogonCommand param1LogonCommand, TDSReader param1TDSReader) throws SQLServerException {
        if (null != this.loginAckToken) {
          return true;
        }
        
        if (null != this.secBlobOut && 0 != this.secBlobOut.length) {


          
          param1LogonCommand.startRequest((byte)17).writeBytes(this.secBlobOut, 0, this.secBlobOut.length);
          return false;
        } 






        
        param1LogonCommand.startRequest((byte)17);
        param1LogonCommand.onRequestComplete();
        SQLServerConnection.this.tdsChannel.numMsgsSent++;
        
        TDSParser.parse(param1TDSReader, this);
        return true;
      }
    };

    
    assert !this.integratedSecurity || !this.fedAuthRequiredPreLoginResponse;
    
    assert !this.integratedSecurity || (!this.federatedAuthenticationInfoRequested && !this.federatedAuthenticationRequested);
    
    assert null == paramFederatedAuthenticationFeatureExtensionData || this.federatedAuthenticationInfoRequested || this.federatedAuthenticationRequested;
    
    assert null != paramFederatedAuthenticationFeatureExtensionData || (!this.federatedAuthenticationInfoRequested && !this.federatedAuthenticationRequested);
    
    String str1 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.WORKSTATION_ID.toString());
    String str2 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString());
    String str3 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString());
    String str4 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.APPLICATION_NAME.toString());
    String str5 = "Microsoft JDBC Driver 6.0";
    String str6 = generateInterfaceLibVersion();
    String str7 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.DATABASE_NAME.toString());
    String str8 = null;
    
    if (null != this.currentConnectPlaceHolder) {
      
      str8 = this.currentConnectPlaceHolder.getServerName();
    }
    else {
      
      str8 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.SERVER_NAME.toString());
    } 
    
    if (str8 != null && str8.length() > 128) {
      str8 = str8.substring(0, 128);
    }
    if (str1 == null || str1.length() == 0)
    {
      str1 = Util.lookupHostName();
    }
    
    byte[] arrayOfByte1 = new byte[0];
    boolean[] arrayOfBoolean = { false };
    if (null != paramSSPIAuthentication) {
      
      arrayOfByte1 = paramSSPIAuthentication.GenerateClientContext(arrayOfByte1, arrayOfBoolean);
      str2 = null;
      str3 = null;
    } 
    
    byte[] arrayOfByte2 = toUCS16(str1);
    byte[] arrayOfByte3 = toUCS16(str2);
    byte[] arrayOfByte4 = encryptPassword(str3);
    byte b1 = (arrayOfByte4 != null) ? arrayOfByte4.length : 0;
    byte[] arrayOfByte5 = toUCS16(str4);
    byte[] arrayOfByte6 = toUCS16(str8);
    byte[] arrayOfByte7 = toUCS16(str5);
    byte[] arrayOfByte8 = DatatypeConverter.parseHexBinary(str6);
    byte[] arrayOfByte9 = toUCS16(str7);
    byte[] arrayOfByte10 = new byte[6];
    int i = 0;
    int j = 0;


    
    if (this.serverMajorVersion >= 11) {
      
      this.tdsVersion = 1946157060;
    }
    else if (this.serverMajorVersion >= 10) {
      
      this.tdsVersion = 1930100739;
    
    }
    else if (this.serverMajorVersion >= 9) {
      
      this.tdsVersion = 1913192450;
    }
    else {
      
      assert false : "prelogin did not disconnect for the old version: " + this.serverMajorVersion;
    } 
    
    TDSWriter tDSWriter = paramLogonCommand.startRequest((byte)16);
    
    i = 94 + arrayOfByte2.length + arrayOfByte5.length + arrayOfByte6.length + arrayOfByte7.length + arrayOfByte9.length + arrayOfByte1.length + 4;








    
    if (!this.integratedSecurity && !this.federatedAuthenticationInfoRequested && !this.federatedAuthenticationRequested) {
      i = i + b1 + arrayOfByte3.length;
    }
    
    int k = i;
    
    i += writeAEFeatureRequest(false, tDSWriter);
    if (this.federatedAuthenticationInfoRequested || this.federatedAuthenticationRequested)
    {
      i += writeFedAuthFeatureRequest(false, tDSWriter, paramFederatedAuthenticationFeatureExtensionData);
    }
    
    i++;

    
    tDSWriter.writeInt(i);
    tDSWriter.writeInt(this.tdsVersion);
    tDSWriter.writeInt(this.requestedPacketSize);
    tDSWriter.writeBytes(arrayOfByte8);
    tDSWriter.writeInt(0);
    tDSWriter.writeInt(0);
    
    tDSWriter.writeByte((byte)-32);








    
    tDSWriter.writeByte((byte)(0x3 | (this.integratedSecurity ? Byte.MIN_VALUE : 0)));







    
    tDSWriter.writeByte((byte)(0x0 | ((this.applicationIntent != null && this.applicationIntent.equals(ApplicationIntent.READ_ONLY)) ? 32 : 0)));







    
    byte b2 = 0;

    
    b2 = 16;
    
    tDSWriter.writeByte((byte)(0x0 | b2 | ((this.serverMajorVersion >= 10) ? 8 : 0)));



    
    tDSWriter.writeInt(0);
    tDSWriter.writeInt(0);
    
    tDSWriter.writeShort((short)94);

    
    tDSWriter.writeShort((short)((str1 == null) ? 0 : str1.length()));
    j += arrayOfByte2.length;


    
    if (!this.integratedSecurity && !this.federatedAuthenticationInfoRequested && !this.federatedAuthenticationRequested) {

      
      tDSWriter.writeShort((short)(94 + j));
      tDSWriter.writeShort((short)((str2 == null) ? 0 : str2.length()));
      j += arrayOfByte3.length;
      
      tDSWriter.writeShort((short)(94 + j));
      tDSWriter.writeShort((short)((str3 == null) ? 0 : str3.length()));
      j += b1;
    
    }
    else {

      
      tDSWriter.writeShort((short)0);
      tDSWriter.writeShort((short)0);
      tDSWriter.writeShort((short)0);
      tDSWriter.writeShort((short)0);
    } 

    
    tDSWriter.writeShort((short)(94 + j));
    tDSWriter.writeShort((short)((str4 == null) ? 0 : str4.length()));
    j += arrayOfByte5.length;

    
    tDSWriter.writeShort((short)(94 + j));
    tDSWriter.writeShort((short)((str8 == null) ? 0 : str8.length()));
    j += arrayOfByte6.length;

    
    tDSWriter.writeShort((short)(94 + j));

    
    tDSWriter.writeShort((short)4);
    j += 4;



    
    assert null != str5;
    tDSWriter.writeShort((short)(94 + j));
    tDSWriter.writeShort((short)str5.length());
    j += arrayOfByte7.length;

    
    tDSWriter.writeShort((short)0);
    tDSWriter.writeShort((short)0);

    
    tDSWriter.writeShort((short)(94 + j));
    tDSWriter.writeShort((short)((str7 == null) ? 0 : str7.length()));
    j += arrayOfByte9.length;

    
    tDSWriter.writeBytes(arrayOfByte10);


    
    if (!this.integratedSecurity) {
      
      tDSWriter.writeShort((short)0);
      tDSWriter.writeShort((short)0);
    }
    else {
      
      tDSWriter.writeShort((short)(94 + j));
      if (65535 <= arrayOfByte1.length) {
        
        tDSWriter.writeShort((short)-1);
      } else {
        
        tDSWriter.writeShort((short)arrayOfByte1.length);
      } 
    } 
    
    tDSWriter.writeShort((short)0);
    tDSWriter.writeShort((short)0);
    
    if (this.tdsVersion >= 1913192450) {

      
      tDSWriter.writeShort((short)0);
      tDSWriter.writeShort((short)0);

      
      if (65535 <= arrayOfByte1.length) {
        tDSWriter.writeInt(arrayOfByte1.length);
      } else {
        tDSWriter.writeInt(0);
      } 
    } 
    tDSWriter.writeBytes(arrayOfByte2);

    
    tDSWriter.setDataLoggable(false);

    
    if (!this.integratedSecurity && !this.federatedAuthenticationInfoRequested && !this.federatedAuthenticationRequested) {
      
      tDSWriter.writeBytes(arrayOfByte3);
      tDSWriter.writeBytes(arrayOfByte4);
    } 
    tDSWriter.setDataLoggable(true);
    
    tDSWriter.writeBytes(arrayOfByte5);
    tDSWriter.writeBytes(arrayOfByte6);


    
    tDSWriter.writeInt(k);

    
    tDSWriter.writeBytes(arrayOfByte7);
    tDSWriter.writeBytes(arrayOfByte9);

    
    tDSWriter.setDataLoggable(false);
    if (this.integratedSecurity) {
      tDSWriter.writeBytes(arrayOfByte1, 0, arrayOfByte1.length);
    }

    
    writeAEFeatureRequest(true, tDSWriter);

    
    if (this.federatedAuthenticationInfoRequested || this.federatedAuthenticationRequested) {
      writeFedAuthFeatureRequest(true, tDSWriter, paramFederatedAuthenticationFeatureExtensionData);
    }
    
    tDSWriter.writeByte((byte)-1);
    tDSWriter.setDataLoggable(true);
    
    LogonProcessor logonProcessor = new LogonProcessor(paramSSPIAuthentication);
    TDSReader tDSReader = null;
    
    do {
      tDSReader = paramLogonCommand.startResponse();
      TDSParser.parse(tDSReader, logonProcessor);
    }
    while (!logonProcessor.complete(paramLogonCommand, tDSReader));
  }

  
  private String generateInterfaceLibVersion() {
    StringBuffer stringBuffer = new StringBuffer();

    
    int i = String.valueOf(8112).length();

    
    int j = Integer.valueOf(String.valueOf(8112).substring(0, i - 2)).intValue();
    int k = Integer.valueOf(String.valueOf(8112).substring(i - 2)).intValue();

    
    String str1 = Integer.toHexString(6);
    String str2 = Integer.toHexString(0);
    String str3 = Integer.toHexString(j);
    String str4 = Integer.toHexString(k);






    
    if (2 == str4.length()) {
      stringBuffer.append(str4);
    } else {
      
      stringBuffer.append("0");
      stringBuffer.append(str4);
    } 
    if (2 == str3.length()) {
      stringBuffer.append(str3);
    } else {
      
      stringBuffer.append("0");
      stringBuffer.append(str3);
    } 
    if (2 == str2.length()) {
      stringBuffer.append(str2);
    } else {
      
      stringBuffer.append("0");
      stringBuffer.append(str2);
    } 
    if (2 == str1.length()) {
      stringBuffer.append(str1);
    } else {
      
      stringBuffer.append("0");
      stringBuffer.append(str1);
    } 
    
    return stringBuffer.toString();
  }







  
  private void checkValidHoldability(int paramInt) throws SQLServerException {
    if (paramInt != 1 && paramInt != 2) {

      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidHoldability"));
      SQLServerException.makeFromDriverError(this, this, messageFormat.format(new Object[] { Integer.valueOf(paramInt) }, ), (String)null, true);
    } 
  }














  
  private void checkMatchesCurrentHoldability(int paramInt) throws SQLServerException {
    if (paramInt != this.holdability)
    {
      SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_sqlServerHoldability"), (String)null, false);
    }
  }




  
  public Statement createStatement(int paramInt1, int paramInt2, int paramInt3) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "createStatement", new Object[] { new Integer(paramInt1), new Integer(paramInt2), Integer.valueOf(paramInt3) });
    Statement statement = createStatement(paramInt1, paramInt2, paramInt3, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
    loggerExternal.exiting(getClassNameLogging(), "createStatement", statement);
    return statement;
  }

  
  public Statement createStatement(int paramInt1, int paramInt2, int paramInt3, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "createStatement", new Object[] { new Integer(paramInt1), new Integer(paramInt2), Integer.valueOf(paramInt3), paramSQLServerStatementColumnEncryptionSetting });
    checkClosed();
    checkValidHoldability(paramInt3);
    checkMatchesCurrentHoldability(paramInt3);
    SQLServerStatement sQLServerStatement = new SQLServerStatement(this, paramInt1, paramInt2, paramSQLServerStatementColumnEncryptionSetting);
    loggerExternal.exiting(getClassNameLogging(), "createStatement", sQLServerStatement);
    return sQLServerStatement;
  }

  
  public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { new Integer(paramInt1), new Integer(paramInt2), Integer.valueOf(paramInt3) });
    PreparedStatement preparedStatement = prepareStatement(paramString, paramInt1, paramInt2, paramInt3, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);




    
    loggerExternal.exiting(getClassNameLogging(), "prepareStatement", preparedStatement);
    return preparedStatement;
  }

  
  public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2, int paramInt3, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { new Integer(paramInt1), new Integer(paramInt2), Integer.valueOf(paramInt3), paramSQLServerStatementColumnEncryptionSetting });
    checkClosed();
    checkValidHoldability(paramInt3);
    checkMatchesCurrentHoldability(paramInt3);
    SQLServerPreparedStatement sQLServerPreparedStatement = new SQLServerPreparedStatement(this, paramString, paramInt1, paramInt2, paramSQLServerStatementColumnEncryptionSetting);




    
    loggerExternal.exiting(getClassNameLogging(), "prepareStatement", sQLServerPreparedStatement);
    return sQLServerPreparedStatement;
  }

  
  public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { new Integer(paramInt1), new Integer(paramInt2), Integer.valueOf(paramInt3) });
    CallableStatement callableStatement = prepareCall(paramString, paramInt1, paramInt2, paramInt3, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
    loggerExternal.exiting(getClassNameLogging(), "prepareCall", callableStatement);
    return callableStatement;
  }

  
  public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2, int paramInt3, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { new Integer(paramInt1), new Integer(paramInt2), Integer.valueOf(paramInt3), paramSQLServerStatementColumnEncryptionSetting });
    checkClosed();
    checkValidHoldability(paramInt3);
    checkMatchesCurrentHoldability(paramInt3);
    SQLServerCallableStatement sQLServerCallableStatement = new SQLServerCallableStatement(this, paramString, paramInt1, paramInt2, paramSQLServerStatementColumnEncryptionSetting);




    
    loggerExternal.exiting(getClassNameLogging(), "prepareCall", sQLServerCallableStatement);
    return sQLServerCallableStatement;
  }



  
  public PreparedStatement prepareStatement(String paramString, int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, new Integer(paramInt) });
    
    SQLServerPreparedStatement sQLServerPreparedStatement = (SQLServerPreparedStatement)prepareStatement(paramString, paramInt, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
    
    loggerExternal.exiting(getClassNameLogging(), "prepareStatement", sQLServerPreparedStatement);
    return sQLServerPreparedStatement;
  }

  
  public PreparedStatement prepareStatement(String paramString, int paramInt, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, new Integer(paramInt), paramSQLServerStatementColumnEncryptionSetting });
    checkClosed();
    SQLServerPreparedStatement sQLServerPreparedStatement = (SQLServerPreparedStatement)prepareStatement(paramString, 1003, 1007, paramSQLServerStatementColumnEncryptionSetting);
    sQLServerPreparedStatement.bRequestedGeneratedKeys = (paramInt == 1);
    loggerExternal.exiting(getClassNameLogging(), "prepareStatement", sQLServerPreparedStatement);
    return sQLServerPreparedStatement;
  }

  
  public PreparedStatement prepareStatement(String paramString, int[] paramArrayOfint) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, paramArrayOfint });
    SQLServerPreparedStatement sQLServerPreparedStatement = (SQLServerPreparedStatement)prepareStatement(paramString, paramArrayOfint, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
    
    loggerExternal.exiting(getClassNameLogging(), "prepareStatement", sQLServerPreparedStatement);
    return sQLServerPreparedStatement;
  }

  
  public PreparedStatement prepareStatement(String paramString, int[] paramArrayOfint, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, paramArrayOfint, paramSQLServerStatementColumnEncryptionSetting });
    
    checkClosed();
    if (paramArrayOfint == null || paramArrayOfint.length != 1) {
      SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_invalidColumnArrayLength"), (String)null, false);
    }
    
    SQLServerPreparedStatement sQLServerPreparedStatement = (SQLServerPreparedStatement)prepareStatement(paramString, 1003, 1007, paramSQLServerStatementColumnEncryptionSetting);
    sQLServerPreparedStatement.bRequestedGeneratedKeys = true;
    loggerExternal.exiting(getClassNameLogging(), "prepareStatement", sQLServerPreparedStatement);
    return sQLServerPreparedStatement;
  }

  
  public PreparedStatement prepareStatement(String paramString, String[] paramArrayOfString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, paramArrayOfString });
    
    SQLServerPreparedStatement sQLServerPreparedStatement = (SQLServerPreparedStatement)prepareStatement(paramString, paramArrayOfString, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
    
    loggerExternal.exiting(getClassNameLogging(), "prepareStatement", sQLServerPreparedStatement);
    return sQLServerPreparedStatement;
  }

  
  public PreparedStatement prepareStatement(String paramString, String[] paramArrayOfString, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, paramArrayOfString, paramSQLServerStatementColumnEncryptionSetting });
    checkClosed();
    if (paramArrayOfString == null || paramArrayOfString.length != 1)
    {
      SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_invalidColumnArrayLength"), (String)null, false);
    }
    
    SQLServerPreparedStatement sQLServerPreparedStatement = (SQLServerPreparedStatement)prepareStatement(paramString, 1003, 1007, paramSQLServerStatementColumnEncryptionSetting);
    sQLServerPreparedStatement.bRequestedGeneratedKeys = true;
    loggerExternal.exiting(getClassNameLogging(), "prepareStatement", sQLServerPreparedStatement);
    return sQLServerPreparedStatement;
  }



  
  public void releaseSavepoint(Savepoint paramSavepoint) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "releaseSavepoint", paramSavepoint);
    NotImplemented();
  }

  
  private final Savepoint setNamedSavepoint(String paramString) throws SQLServerException {
    if (true == this.databaseAutoCommitMode)
    {
      SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_cantSetSavepoint"), (String)null, false);
    }





    
    SQLServerSavepoint sQLServerSavepoint = new SQLServerSavepoint(this, paramString);







    
    connectionCommand("IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN IF @@TRANCOUNT = 2 COMMIT TRAN END SAVE TRAN " + Util.escapeSQLId(sQLServerSavepoint.getLabel()), "setSavepoint");


    
    return sQLServerSavepoint;
  }

  
  public Savepoint setSavepoint(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "setSavepoint", paramString);
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();
    Savepoint savepoint = setNamedSavepoint(paramString);
    loggerExternal.exiting(getClassNameLogging(), "setSavepoint", savepoint);
    return savepoint;
  }

  
  public Savepoint setSavepoint() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "setSavepoint");
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();
    Savepoint savepoint = setNamedSavepoint(null);
    loggerExternal.exiting(getClassNameLogging(), "setSavepoint", savepoint);
    return savepoint;
  }

  
  public void rollback(Savepoint paramSavepoint) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "rollback", paramSavepoint);
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();
    if (true == this.databaseAutoCommitMode)
    {
      SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_cantInvokeRollback"), (String)null, false);
    }




    
    connectionCommand("IF @@TRANCOUNT > 0 ROLLBACK TRAN " + Util.escapeSQLId(((SQLServerSavepoint)paramSavepoint).getLabel()), "rollbackSavepoint");

    
    loggerExternal.exiting(getClassNameLogging(), "rollback");
  }

  
  public int getHoldability() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getHoldability");
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.exiting(getClassNameLogging(), "getHoldability", Integer.valueOf(this.holdability)); 
    return this.holdability;
  }

  
  public void setHoldability(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "setHoldability", Integer.valueOf(paramInt));
    
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkValidHoldability(paramInt);
    checkClosed();
    
    if (this.holdability != paramInt) {



      
      assert 1 == paramInt || 2 == paramInt : "invalid holdability " + paramInt;
      
      connectionCommand((paramInt == 2) ? "SET CURSOR_CLOSE_ON_COMMIT ON" : "SET CURSOR_CLOSE_ON_COMMIT OFF", "setHoldability");




      
      this.holdability = paramInt;
    } 
    
    loggerExternal.exiting(getClassNameLogging(), "setHoldability");
  }

  
  public int getNetworkTimeout() throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC41();

    
    throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
  }

  
  public void setNetworkTimeout(Executor paramExecutor, int paramInt) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC41();

    
    throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
  }

  
  public String getSchema() throws SQLException {
    loggerExternal.entering(getClassNameLogging(), "getSchema");
    
    DriverJDBCVersion.checkSupportsJDBC41();
    
    checkClosed();
    
    SQLServerStatement sQLServerStatement = null;
    SQLServerResultSet sQLServerResultSet = null;

    
    try {
      sQLServerStatement = (SQLServerStatement)createStatement();
      sQLServerResultSet = sQLServerStatement.executeQueryInternal("SELECT SCHEMA_NAME()");
      if (sQLServerResultSet != null) {
        
        sQLServerResultSet.next();
        return sQLServerResultSet.getString(1);
      } 

      
      SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_getSchemaError"), (String)null, true);


    
    }
    catch (SQLException sQLException) {
      
      if (isSessionUnAvailable())
      {
        throw sQLException;
      }
      
      SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_getSchemaError"), (String)null, true);
    
    }
    finally {

      
      if (sQLServerResultSet != null)
      {
        sQLServerResultSet.close();
      }
      if (sQLServerStatement != null)
      {
        sQLServerStatement.close();
      }
    } 
    
    loggerExternal.exiting(getClassNameLogging(), "getSchema");
    return null;
  }

  
  public void setSchema(String paramString) throws SQLException {
    loggerExternal.entering(getClassNameLogging(), "setSchema", paramString);
    DriverJDBCVersion.checkSupportsJDBC41();
    
    checkClosed();
    addWarning(SQLServerException.getErrString("R_setSchemaWarning"));
    
    loggerExternal.exiting(getClassNameLogging(), "setSchema");
  }

  
  public synchronized void setSendTimeAsDatetime(boolean paramBoolean) {
    this.sendTimeAsDatetime = paramBoolean;
  }

  
  public Array createArrayOf(String paramString, Object[] paramArrayOfObject) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();

    
    throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
  }

  
  public Blob createBlob() throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    checkClosed();
    return new SQLServerBlob(this);
  }

  
  public Clob createClob() throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    checkClosed();
    return new SQLServerClob(this);
  }

  
  public NClob createNClob() throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    checkClosed();
    return new SQLServerNClob(this);
  }

  
  public SQLXML createSQLXML() throws SQLException {
    loggerExternal.entering(getClassNameLogging(), "createSQLXML");
    DriverJDBCVersion.checkSupportsJDBC4();
    SQLServerSQLXML sQLServerSQLXML = null;
    sQLServerSQLXML = new SQLServerSQLXML(this);
    
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.exiting(getClassNameLogging(), "createSQLXML", sQLServerSQLXML); 
    return sQLServerSQLXML;
  }

  
  public Struct createStruct(String paramString, Object[] paramArrayOfObject) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();

    
    throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
  }

  
  String getTrustedServerNameAE() throws SQLServerException {
    return this.trustedServerNameAE.toUpperCase();
  }

  
  public Properties getClientInfo() throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    loggerExternal.entering(getClassNameLogging(), "getClientInfo");
    checkClosed();
    Properties properties = new Properties();
    loggerExternal.exiting(getClassNameLogging(), "getClientInfo", properties);
    return properties;
  }

  
  public String getClientInfo(String paramString) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    loggerExternal.entering(getClassNameLogging(), "getClientInfo", paramString);
    checkClosed();
    loggerExternal.exiting(getClassNameLogging(), "getClientInfo", null);
    return null;
  }

  
  public void setClientInfo(Properties paramProperties) throws SQLClientInfoException {
    DriverJDBCVersion.checkSupportsJDBC4();
    loggerExternal.entering(getClassNameLogging(), "setClientInfo", paramProperties);


    
    try {
      checkClosed();
    } catch (SQLServerException sQLServerException) {
      
      SQLClientInfoException sQLClientInfoException = new SQLClientInfoException();
      sQLClientInfoException.initCause(sQLServerException);
      throw sQLClientInfoException;
    } 
    
    if (!paramProperties.isEmpty()) {
      
      Enumeration enumeration = paramProperties.keys();
      while (enumeration.hasMoreElements()) {
        
        MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidProperty"));
        Object[] arrayOfObject = { enumeration.nextElement() };
        addWarning(messageFormat.format(arrayOfObject));
      } 
    } 
    loggerExternal.exiting(getClassNameLogging(), "setClientInfo");
  }

  
  public void setClientInfo(String paramString1, String paramString2) throws SQLClientInfoException {
    DriverJDBCVersion.checkSupportsJDBC4();
    loggerExternal.entering(getClassNameLogging(), "setClientInfo", new Object[] { paramString1, paramString2 });


    
    try {
      checkClosed();
    } catch (SQLServerException sQLServerException) {
      
      SQLClientInfoException sQLClientInfoException = new SQLClientInfoException();
      sQLClientInfoException.initCause(sQLServerException);
      throw sQLClientInfoException;
    } 
    MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidProperty"));
    Object[] arrayOfObject = { paramString1 };
    addWarning(messageFormat.format(arrayOfObject));
    loggerExternal.exiting(getClassNameLogging(), "setClientInfo");
  }




















  
  public boolean isValid(int paramInt) throws SQLException {
    boolean bool = false;
    
    loggerExternal.entering(getClassNameLogging(), "isValid", Integer.valueOf(paramInt));
    
    DriverJDBCVersion.checkSupportsJDBC4();

    
    if (paramInt < 0) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidQueryTimeOutValue"));
      Object[] arrayOfObject = { Integer.valueOf(paramInt) };
      SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, true);
    } 

    
    if (isSessionUnAvailable()) {
      return false;
    }
    
    try {
      SQLServerStatement sQLServerStatement = new SQLServerStatement(this, 1003, 1007, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);






      
      if (0 != paramInt) {
        sQLServerStatement.setQueryTimeout(paramInt);
      }



      
      sQLServerStatement.executeQueryInternal("SELECT 1");
      sQLServerStatement.close();
      bool = true;
    }
    catch (SQLException sQLException) {



      
      connectionlogger.fine(toString() + " Exception checking connection validity: " + sQLException.getMessage());
    } 
    
    loggerExternal.exiting(getClassNameLogging(), "isValid", Boolean.valueOf(bool));
    return bool;
  }

  
  public boolean isWrapperFor(Class<?> paramClass) throws SQLException {
    loggerExternal.entering(getClassNameLogging(), "isWrapperFor", paramClass);
    DriverJDBCVersion.checkSupportsJDBC4();
    boolean bool = paramClass.isInstance(this);
    loggerExternal.exiting(getClassNameLogging(), "isWrapperFor", Boolean.valueOf(bool));
    return bool;
  }
  
  public <T> T unwrap(Class<T> paramClass) throws SQLException {
    T t;
    loggerExternal.entering(getClassNameLogging(), "unwrap", paramClass);
    DriverJDBCVersion.checkSupportsJDBC4();
    
    try {
      t = paramClass.cast(this);
    }
    catch (ClassCastException classCastException) {

      
      SQLServerException sQLServerException = new SQLServerException(classCastException.getMessage(), classCastException);
      throw sQLServerException;
    } 
    loggerExternal.exiting(getClassNameLogging(), "unwrap", t);
    return t;
  }








  
  static final char[] OUT = new char[] { ' ', 'O', 'U', 'T' };
  private static final int BROWSER_PORT = 1434;
  
  String replaceParameterMarkers(String paramString, Parameter[] paramArrayOfParameter, boolean paramBoolean) throws SQLServerException {
    char[] arrayOfChar = new char[paramString.length() + paramArrayOfParameter.length * (6 + OUT.length)];
    int i = 0;
    int j = 0;
    byte b1 = 0;
    
    byte b2 = 0;
    
    while (true) {
      int k = ParameterUtils.scanSQLForChar('?', paramString, j);
      paramString.getChars(j, k, arrayOfChar, i);
      i += k - j;
      
      if (paramString.length() == k) {
        break;
      }
      i += makeParamName(b1++, arrayOfChar, i);
      j = k + 1;
      
      if (paramArrayOfParameter[b2++].isOutput())
      {
        if (!paramBoolean || b2 > 1) {
          
          System.arraycopy(OUT, 0, arrayOfChar, i, OUT.length);
          i += OUT.length;
        } 
      }
    } 
    
    while (i < arrayOfChar.length) {
      arrayOfChar[i++] = ' ';
    }
    return new String(arrayOfChar);
  }







  
  static int makeParamName(int paramInt1, char[] paramArrayOfchar, int paramInt2) {
    paramArrayOfchar[paramInt2 + 0] = '@';
    paramArrayOfchar[paramInt2 + 1] = 'P';
    if (paramInt1 < 10) {
      
      paramArrayOfchar[paramInt2 + 2] = (char)(48 + paramInt1);
      return 3;
    } 

    
    if (paramInt1 < 100) {
      
      byte b = 2;
      
      while (true) {
        if (paramInt1 < b * 10) {
          
          paramArrayOfchar[paramInt2 + 2] = (char)(48 + b - 1);
          paramArrayOfchar[paramInt2 + 3] = (char)(48 + paramInt1 - (b - 1) * 10);
          return 4;
        } 
        b++;
      } 
    } 

    
    String str = "" + paramInt1;
    str.getChars(0, str.length(), paramArrayOfchar, paramInt2 + 2);
    return 2 + str.length();
  }









  
  void notifyPooledConnection(SQLServerException paramSQLServerException) {
    synchronized (this) {
      
      if (null != this.pooledConnectionParent)
      {
        this.pooledConnectionParent.notifyEvent(paramSQLServerException);
      }
    } 
  }



  
  void DetachFromPool() {
    synchronized (this) {
      
      this.pooledConnectionParent = null;
    } 
  }










  
  String getInstancePort(String paramString1, String paramString2) throws SQLServerException {
    String str1 = null;
    DatagramSocket datagramSocket = null;
    String str2 = null;

    
    try {
      str2 = "Failed to determine instance for the : " + paramString1 + " instance:" + paramString2;

      
      if (null == datagramSocket) {
        
        try {
          
          datagramSocket = new DatagramSocket();
          datagramSocket.setSoTimeout(1000);
        }
        catch (SocketException socketException) {


          
          str2 = "Unable to create local datagram socket";
          throw socketException;
        } 
      }




      
      assert null != datagramSocket;
      
      try {
        if (this.multiSubnetFailover) {

          
          InetAddress[] arrayOfInetAddress = InetAddress.getAllByName(paramString1);
          assert null != arrayOfInetAddress;
          for (InetAddress inetAddress : arrayOfInetAddress)
          {
            try
            {
              
              byte[] arrayOfByte = (" " + paramString2).getBytes();
              arrayOfByte[0] = 4;
              DatagramPacket datagramPacket = new DatagramPacket(arrayOfByte, arrayOfByte.length, inetAddress, 1434);
              datagramSocket.send(datagramPacket);
            }
            catch (IOException iOException)
            {
              str2 = "Error sending SQL Server Browser Service UDP request to address: " + inetAddress + ", port: " + '֚';
              throw iOException;
            }
          
          }
        
        } else {
          
          InetAddress inetAddress = InetAddress.getByName(paramString1);
          
          assert null != inetAddress;

          
          try {
            byte[] arrayOfByte = (" " + paramString2).getBytes();
            arrayOfByte[0] = 4;
            DatagramPacket datagramPacket = new DatagramPacket(arrayOfByte, arrayOfByte.length, inetAddress, 1434);
            datagramSocket.send(datagramPacket);
          }
          catch (IOException iOException) {
            
            str2 = "Error sending SQL Server Browser Service UDP request to address: " + inetAddress + ", port: " + '֚';
            throw iOException;
          }
        
        } 
      } catch (UnknownHostException unknownHostException) {
        
        str2 = "Unable to determine IP address of host: " + paramString1;
        throw unknownHostException;
      } 


      
      try {
        byte[] arrayOfByte = new byte[4096];
        DatagramPacket datagramPacket = new DatagramPacket(arrayOfByte, arrayOfByte.length);
        datagramSocket.receive(datagramPacket);
        str1 = new String(arrayOfByte, 3, arrayOfByte.length - 3);
        if (connectionlogger.isLoggable(Level.FINER)) {
          connectionlogger.fine(toString() + " Received SSRP UDP response from IP address: " + datagramPacket.getAddress().getHostAddress().toString());
        }
      } catch (IOException iOException) {

        
        str2 = "Error receiving SQL Server Browser Service UDP response from server: " + paramString1;
        throw iOException;
      }
    
    } catch (IOException iOException) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_sqlBrowserFailed"));
      Object[] arrayOfObject = { paramString1, paramString2, iOException.toString() };
      connectionlogger.log(Level.FINE, toString() + " " + str2, iOException);
      SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), "08001", false);
    }
    finally {
      
      if (null != datagramSocket)
        datagramSocket.close(); 
    } 
    assert null != str1;
    
    int i = str1.indexOf("tcp;");
    if (-1 == i) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_notConfiguredToListentcpip"));
      Object[] arrayOfObject = { paramString2 };
      SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), "08001", false);
    } 
    
    int j = i + 4;
    int k = str1.indexOf(';', j);
    return str1.substring(j, k);
  }
  
  int getNextSavepointId() {
    this.nNextSavePointId++;
    return this.nNextSavePointId;
  }



  
  void doSecurityCheck() {
    assert null != this.currentConnectPlaceHolder;
    this.currentConnectPlaceHolder.doSecurityCheck();
  }



  
  private static long columnEncryptionKeyCacheTtl = TimeUnit.SECONDS.convert(2L, TimeUnit.HOURS);

  
  public static synchronized void setColumnEncryptionKeyCacheTtl(int paramInt, TimeUnit paramTimeUnit) throws SQLServerException {
    if (paramInt < 0 || paramTimeUnit.equals(TimeUnit.MILLISECONDS) || paramTimeUnit.equals(TimeUnit.MICROSECONDS) || paramTimeUnit.equals(TimeUnit.NANOSECONDS))
    {
      throw new SQLServerException(null, SQLServerException.getErrString("R_invalidCEKCacheTtl"), null, 0, false);
    }
    
    columnEncryptionKeyCacheTtl = TimeUnit.SECONDS.convert(paramInt, paramTimeUnit);
  }

  
  static synchronized long getColumnEncryptionKeyCacheTtl() {
    return columnEncryptionKeyCacheTtl;
  }
}
