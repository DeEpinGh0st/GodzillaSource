package com.microsoft.sqlserver.jdbc;

import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;











public class SQLServerStatement
  implements ISQLServerStatement
{
  static final char LEFT_CURLY_BRACKET = '{';
  static final char RIGHT_CURLY_BRACKET = '}';
  private boolean isResponseBufferingAdaptive = false;
  private boolean wasResponseBufferingSet = false;
  static final String identityQuery = " select SCOPE_IDENTITY() AS GENERATED_KEYS";
  String procedureName;
  private int serverCursorId;
  private int serverCursorRowCount;
  
  final boolean getIsResponseBufferingAdaptive() {
    return this.isResponseBufferingAdaptive;
  } final boolean wasResponseBufferingSet() {
    return this.wasResponseBufferingSet;
  }
  boolean stmtPoolable;
  private TDSReader tdsReader;
  Parameter[] inOutParam;
  final SQLServerConnection connection;
  int queryTimeout;
  
  final int getServerCursorId() {
    return this.serverCursorId;
  }
  final int getServerCursorRowCount() {
    return this.serverCursorRowCount;
  }


  
  final TDSReader resultsReader()
  {
    return this.tdsReader; } final boolean wasExecuted() {
    return (null != this.tdsReader);
  }













  
  boolean isCloseOnCompletion = false;











  
  private volatile TDSCommand currentCommand = null;
  private TDSCommand lastStmtExecCmd = null;
  
  final void discardLastExecutionResults() {
    if (null != this.lastStmtExecCmd && !this.bIsClosed) {
      
      this.lastStmtExecCmd.close();
      this.lastStmtExecCmd = null;
    } 
    clearLastResult();
  }
  
  static final Logger loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.Statement");
  
  private final String loggingClassName;
  private final String traceID;
  
  String getClassNameLogging() {
    return this.loggingClassName;
  }






  
  protected SQLServerStatementColumnEncryptionSetting stmtColumnEncriptionSetting = SQLServerStatementColumnEncryptionSetting.UseConnectionSetting;
  private ExecuteProperties execProps;
  
  final class ExecuteProperties {
    private final boolean wasResponseBufferingSet;
    private final boolean isResponseBufferingAdaptive;
    private final int holdability;
    
    final boolean wasResponseBufferingSet() {
      return this.wasResponseBufferingSet;
    }
    final boolean isResponseBufferingAdaptive() {
      return this.isResponseBufferingAdaptive;
    }
    final int getHoldability() {
      return this.holdability;
    }
    
    ExecuteProperties(SQLServerStatement param1SQLServerStatement1) {
      this.wasResponseBufferingSet = param1SQLServerStatement1.wasResponseBufferingSet();
      this.isResponseBufferingAdaptive = param1SQLServerStatement1.getIsResponseBufferingAdaptive();
      this.holdability = param1SQLServerStatement1.connection.getHoldabilityInternal();
    }
  }
  
  final ExecuteProperties getExecProps() {
    return this.execProps;
  }









  
  final void executeStatement(TDSCommand paramTDSCommand) throws SQLServerException {
    discardLastExecutionResults();

    
    checkClosed();
    
    this.execProps = new ExecuteProperties(this);


    
    try {
      executeCommand(paramTDSCommand);
    }
    finally {
      
      this.lastStmtExecCmd = paramTDSCommand;
    } 
  }















  
  final void executeCommand(TDSCommand paramTDSCommand) throws SQLServerException {
    this.currentCommand = paramTDSCommand;
    this.connection.executeCommand(paramTDSCommand);
  }





  
  boolean moreResults = false;



  
  SQLServerResultSet resultSet;



  
  int resultSetCount = 0; static final int EXECUTE_NOT_SET = 0;
  static final int EXECUTE_QUERY = 1;
  static final int EXECUTE_UPDATE = 2;
  
  synchronized void incrResultSetCount() {
    this.resultSetCount++;
  }
  static final int EXECUTE = 3;
  static final int EXECUTE_BATCH = 4;
  static final int EXECUTE_QUERY_INTERNAL = 5;
  
  synchronized void decrResultSetCount() {
    this.resultSetCount--;
    assert this.resultSetCount >= 0;

    
    if (this.isCloseOnCompletion && (4 != this.executeMethod || !this.moreResults) && this.resultSetCount == 0)
    {

      
      closeInternal();
    }
  }










  
  int executeMethod = 0;



  
  long updateCount = -1L;



  
  boolean escapeProcessing;


  
  int maxRows = 0;

  
  int maxFieldSize = 0;









  
  int resultSetConcurrency;









  
  int appResultSetType;









  
  int resultSetType;










  
  final int getSQLResultSetType()
  {
    return this.resultSetType; } final int getCursorType() {
    return getResultSetScrollOpt() & 0xFFFFEFFF;
  }












  
  final boolean isCursorable(int paramInt) {
    return (this.resultSetType != 2003 && (3 == paramInt || 1 == paramInt));
  }


  
  boolean executedSqlDirectly = false;

  
  boolean expectCursorOutParams;

  
  String cursorName;

  
  int nFetchSize;
  
  int defaultFetchSize;
  
  int nFetchDirection;
  
  boolean bIsClosed;
  
  boolean bRequestedGeneratedKeys;
  
  private ResultSet autoGeneratedKeys;

  
  class StmtExecOutParamHandler
    extends TDSTokenHandler
  {
    StmtExecOutParamHandler() {
      super("StmtExecOutParamHandler");
    }

    
    boolean onRetStatus(TDSReader param1TDSReader) throws SQLServerException {
      (new StreamRetStatus()).setFromTDS(param1TDSReader);
      return true;
    }

    
    boolean onRetValue(TDSReader param1TDSReader) throws SQLServerException {
      if (SQLServerStatement.this.expectCursorOutParams) {
        
        Parameter parameter = new Parameter(Util.shouldHonorAEForParameters(SQLServerStatement.this.stmtColumnEncriptionSetting, SQLServerStatement.this.connection));

        
        parameter.skipRetValStatus(param1TDSReader);
        SQLServerStatement.this.serverCursorId = parameter.getInt(param1TDSReader);
        parameter.skipValue(param1TDSReader, true);
        
        parameter = new Parameter(Util.shouldHonorAEForParameters(SQLServerStatement.this.stmtColumnEncriptionSetting, SQLServerStatement.this.connection));
        
        parameter.skipRetValStatus(param1TDSReader);
        if (-1 == (SQLServerStatement.this.serverCursorRowCount = parameter.getInt(param1TDSReader)))
          SQLServerStatement.this.serverCursorRowCount = -3; 
        parameter.skipValue(param1TDSReader, true);

        
        SQLServerStatement.this.expectCursorOutParams = false;
        return true;
      } 
      
      return false;
    }

    
    boolean onDone(TDSReader param1TDSReader) throws SQLServerException {
      return false;
    }
  }




































  
  private final ArrayList<String> batchStatementBuffer = new ArrayList<>();

  
  private static final Logger stmtlogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerStatement");



  
  public String toString() {
    return this.traceID;
  }


  
  String getClassNameInternal() {
    return "SQLServerStatement";
  }

  
  private static int lastStatementID = 0; Vector<SQLWarning> sqlWarnings; private static synchronized int nextStatementID() {
    return ++lastStatementID;
  }

















  
  SQLServerStatement(SQLServerConnection paramSQLServerConnection, int paramInt1, int paramInt2, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
    int i = nextStatementID();
    String str = getClassNameInternal();
    this.traceID = str + ":" + i;
    this.loggingClassName = "com.microsoft.sqlserver.jdbc." + str + ":" + i;
    
    this.stmtPoolable = false;
    this.connection = paramSQLServerConnection;
    this.bIsClosed = false;


    
    if (1003 != paramInt1 && 1005 != paramInt1 && 1004 != paramInt1 && 2003 != paramInt1 && 2004 != paramInt1 && 1006 != paramInt1 && 1005 != paramInt1 && 1004 != paramInt1)
    {






      
      SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_unsupportedCursor"), (String)null, true);
    }


    
    if (1007 != paramInt2 && 1008 != paramInt2 && 1009 != paramInt2 && 1008 != paramInt2 && 1010 != paramInt2)
    {



      
      SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_unsupportedConcurrency"), (String)null, true);
    }

    
    if (null == paramSQLServerStatementColumnEncryptionSetting)
    {
      SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_unsupportedStmtColEncSetting"), (String)null, true);
    }

    
    this.stmtColumnEncriptionSetting = paramSQLServerStatementColumnEncryptionSetting;
    
    this.resultSetConcurrency = paramInt2;


    
    this.appResultSetType = paramInt1;



    
    if (1003 == paramInt1) {
      
      if (1007 == paramInt2)
      {

        
        String str1 = paramSQLServerConnection.getSelectMethod();
        this.resultSetType = (null == str1 || !str1.equals("cursor")) ? 2003 : 2004;

      
      }
      else
      {
        
        this.resultSetType = 2004;
      }
    
    } else if (1004 == paramInt1) {
      
      this.resultSetType = 1004;
    }
    else if (1005 == paramInt1) {
      
      this.resultSetType = 1005;
    }
    else {
      
      this.resultSetType = paramInt1;
    } 

    
    this.nFetchDirection = (2003 == this.resultSetType || 2004 == this.resultSetType) ? 1000 : 1002;








    
    this.nFetchSize = (1009 == this.resultSetConcurrency) ? 8 : 128;

    
    this.defaultFetchSize = this.nFetchSize;





    
    if (1007 != paramInt2 && (2003 == this.resultSetType || 1004 == this.resultSetType))
    {

      
      SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_unsupportedCursorAndConcurrency"), (String)null, true);
    }


    
    setResponseBuffering(this.connection.getResponseBuffering());

    
    if (stmtlogger.isLoggable(Level.FINER))
    {
      stmtlogger.finer("Properties for " + toString() + ":" + " Result type:" + this.appResultSetType + " (" + this.resultSetType + ")" + " Concurrency:" + this.resultSetConcurrency + " Fetchsize:" + this.nFetchSize + " bIsClosed:" + this.bIsClosed + " useLastUpdateCount:" + this.connection.useLastUpdateCount());
    }





    
    if (stmtlogger.isLoggable(Level.FINE))
    {
      stmtlogger.fine(toString() + " created by (" + this.connection.toString() + ")");
    }
  }

  
  final Logger getStatementLogger() {
    return stmtlogger;
  }



  
  final void NotImplemented() throws SQLServerException {
    SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_notSupported"), (String)null, false);
  }












  
  void closeInternal() {
    assert !this.bIsClosed;
    
    discardLastExecutionResults();
    
    this.bIsClosed = true;
    this.autoGeneratedKeys = null;
    this.sqlWarnings = null;
    this.inOutParam = null;
  }

  
  public void close() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "close");
    
    if (!this.bIsClosed) {
      closeInternal();
    }
    loggerExternal.exiting(getClassNameLogging(), "close");
  }

  
  public void closeOnCompletion() throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC41();
    
    loggerExternal.entering(getClassNameLogging(), "closeOnCompletion");
    
    checkClosed();

    
    this.isCloseOnCompletion = true;
    
    loggerExternal.exiting(getClassNameLogging(), "closeOnCompletion");
  }







  
  public ResultSet executeQuery(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "executeQuery", paramString);
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();
    executeStatement(new StmtExecCmd(this, paramString, 1, 2));
    loggerExternal.exiting(getClassNameLogging(), "executeQuery", this.resultSet);
    return this.resultSet;
  }

  
  final SQLServerResultSet executeQueryInternal(String paramString) throws SQLServerException {
    checkClosed();
    executeStatement(new StmtExecCmd(this, paramString, 5, 2));
    return this.resultSet;
  }







  
  public int executeUpdate(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "executeUpdate", paramString);
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();
    executeStatement(new StmtExecCmd(this, paramString, 2, 2));

    
    if (this.updateCount < -2147483648L || this.updateCount > 2147483647L) {
      SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_updateCountOutofRange"), (String)null, true);
    }
    loggerExternal.exiting(getClassNameLogging(), "executeUpdate", new Long(this.updateCount));
    
    return (int)this.updateCount;
  }







  
  public long executeLargeUpdate(String paramString) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    loggerExternal.entering(getClassNameLogging(), "executeLargeUpdate", paramString);
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();
    executeStatement(new StmtExecCmd(this, paramString, 2, 2));
    
    loggerExternal.exiting(getClassNameLogging(), "executeLargeUpdate", new Long(this.updateCount));
    return this.updateCount;
  }








  
  public boolean execute(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "execute", paramString);
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();
    executeStatement(new StmtExecCmd(this, paramString, 3, 2));
    loggerExternal.exiting(getClassNameLogging(), "execute", Boolean.valueOf((null != this.resultSet)));
    return (null != this.resultSet);
  }

  
  private final class StmtExecCmd
    extends TDSCommand
  {
    final SQLServerStatement stmt;
    
    final String sql;
    
    final int executeMethod;
    
    final int autoGeneratedKeys;
    
    StmtExecCmd(SQLServerStatement param1SQLServerStatement1, String param1String, int param1Int1, int param1Int2) {
      super(param1SQLServerStatement1.toString() + " executeXXX", param1SQLServerStatement1.queryTimeout);
      this.stmt = param1SQLServerStatement1;
      this.sql = param1String;
      this.executeMethod = param1Int1;
      this.autoGeneratedKeys = param1Int2;
    }

    
    final boolean doExecute() throws SQLServerException {
      this.stmt.doExecuteStatement(this);
      return false;
    }

    
    final void processResponse(TDSReader param1TDSReader) throws SQLServerException {
      SQLServerStatement.this.ensureExecuteResultsReader(param1TDSReader);
      SQLServerStatement.this.processExecuteResults();
    }
  }

  
  private String ensureSQLSyntax(String paramString) throws SQLServerException {
    if (paramString.indexOf('{') >= 0) {
      
      JDBCSyntaxTranslator jDBCSyntaxTranslator = new JDBCSyntaxTranslator();
      String str = jDBCSyntaxTranslator.translate(paramString);
      this.procedureName = jDBCSyntaxTranslator.getProcedureName();
      return str;
    } 
    
    return paramString;
  }

  
  void startResults() {
    this.moreResults = true;
  }
  
  final void setMaxRowsAndMaxFieldSize() throws SQLServerException {
    if (1 == this.executeMethod || 3 == this.executeMethod) {
      
      this.connection.setMaxRows(this.maxRows);
      this.connection.setMaxFieldSize(this.maxFieldSize);
    }
    else {
      
      assert 2 == this.executeMethod || 4 == this.executeMethod || 5 == this.executeMethod;





      
      this.connection.setMaxRows(0);
    } 
  }

  
  final void doExecuteStatement(StmtExecCmd paramStmtExecCmd) throws SQLServerException {
    resetForReexecute();

    
    this.executeMethod = paramStmtExecCmd.executeMethod;



    
    String str = ensureSQLSyntax(paramStmtExecCmd.sql);










    
    setMaxRowsAndMaxFieldSize();
    
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    if (isCursorable(this.executeMethod) && isSelect(str)) {
      
      if (stmtlogger.isLoggable(Level.FINE)) {
        stmtlogger.fine(toString() + " Executing server side cursor " + str);
      }
      doExecuteCursored(paramStmtExecCmd, str);
    }
    else {
      
      this.executedSqlDirectly = true;
      this.expectCursorOutParams = false;
      
      TDSWriter tDSWriter = paramStmtExecCmd.startRequest((byte)1);
      
      tDSWriter.writeString(str);


      
      if (1 == paramStmtExecCmd.autoGeneratedKeys && (2 == this.executeMethod || 3 == this.executeMethod) && str.trim().toUpperCase().startsWith("INSERT"))
      {

        
        tDSWriter.writeString(" select SCOPE_IDENTITY() AS GENERATED_KEYS");
      }
      
      if (stmtlogger.isLoggable(Level.FINE)) {
        stmtlogger.fine(toString() + " Executing (not server cursor) " + str);
      }
      
      ensureExecuteResultsReader(paramStmtExecCmd.startResponse(this.isResponseBufferingAdaptive));
      startResults();
      getNextResult();
    } 

    
    if (null == this.resultSet) {
      
      if (1 == this.executeMethod)
      {
        SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_noResultset"), (String)null, true);




      
      }



    
    }
    else if (2 == this.executeMethod || 4 == this.executeMethod) {
      
      SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_resultsetGeneratedForUpdate"), (String)null, false);
    } 
  }



  
  private final class StmtBatchExecCmd
    extends TDSCommand
  {
    final SQLServerStatement stmt;



    
    StmtBatchExecCmd(SQLServerStatement param1SQLServerStatement1) {
      super(param1SQLServerStatement1.toString() + " executeBatch", param1SQLServerStatement1.queryTimeout);
      this.stmt = param1SQLServerStatement1;
    }

    
    final boolean doExecute() throws SQLServerException {
      this.stmt.doExecuteStatementBatch(this);
      return false;
    }

    
    final void processResponse(TDSReader param1TDSReader) throws SQLServerException {
      SQLServerStatement.this.ensureExecuteResultsReader(param1TDSReader);
      SQLServerStatement.this.processExecuteResults();
    }
  }

  
  private final void doExecuteStatementBatch(StmtBatchExecCmd paramStmtBatchExecCmd) throws SQLServerException {
    resetForReexecute();

    
    this.connection.setMaxRows(0);
    
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }

    
    this.executeMethod = 4;
    this.executedSqlDirectly = true;
    this.expectCursorOutParams = false;
    
    TDSWriter tDSWriter = paramStmtBatchExecCmd.startRequest((byte)1);

    
    ListIterator<String> listIterator = this.batchStatementBuffer.listIterator();
    tDSWriter.writeString(listIterator.next());
    while (listIterator.hasNext()) {
      
      tDSWriter.writeString(" ; ");
      tDSWriter.writeString(listIterator.next());
    } 

    
    ensureExecuteResultsReader(paramStmtBatchExecCmd.startResponse(this.isResponseBufferingAdaptive));
    startResults();
    getNextResult();

    
    if (null != this.resultSet)
    {
      SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_resultsetGeneratedForUpdate"), (String)null, false);
    }
  }










  
  final void resetForReexecute() throws SQLServerException {
    ensureExecuteResultsReader(null);
    this.autoGeneratedKeys = null;
    this.updateCount = -1L;
    this.sqlWarnings = null;
    this.executedSqlDirectly = false;
    startResults();
  }






  
  final boolean isSelect(String paramString) throws SQLServerException {
    checkClosed();


    
    String str = paramString.trim();
    char c = str.charAt(0);
    if (c != 's' && c != 'S')
      return false; 
    return str.substring(0, 6).equalsIgnoreCase("select");
  }







  
  static String replaceParameterWithString(String paramString1, char paramChar, String paramString2) {
    int i = 0;
    while ((i = paramString1.indexOf("" + paramChar)) >= 0) {
      paramString1 = paramString1.substring(0, i) + paramString2 + paramString1.substring(i + 1, paramString1.length());
    }
    return paramString1;
  }





  
  static String replaceMarkerWithNull(String paramString) {
    if (paramString.indexOf("'") < 0) {
      return replaceParameterWithString(paramString, '?', "null");
    }

    
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, "'", true);
    boolean bool = true;
    String str = "";
    while (stringTokenizer.hasMoreTokens()) {
      String str1 = stringTokenizer.nextToken();
      if (str1.equals("'")) {
        str = str + "'";
        bool = !bool ? true : false;
        continue;
      } 
      if (bool) {
        String str2 = replaceParameterWithString(str1, '?', "null");
        str = str + str2;
        continue;
      } 
      str = str + str1;
    } 

    
    return str;
  }





  
  void checkClosed() throws SQLServerException {
    this.connection.checkClosed();
    if (this.bIsClosed) {
      SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_statementIsClosed"), (String)null, false);
    }
  }



  
  public final int getMaxFieldSize() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getMaxFieldSize");
    checkClosed();
    loggerExternal.exiting(getClassNameLogging(), "getMaxFieldSize", new Integer(this.maxFieldSize));
    return this.maxFieldSize;
  }

  
  public final void setMaxFieldSize(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "setMaxFieldSize", new Integer(paramInt));
    checkClosed();
    if (paramInt < 0) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
      Object[] arrayOfObject = { new Integer(paramInt) };
      SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), (String)null, true);
    } 
    this.maxFieldSize = paramInt;
    loggerExternal.exiting(getClassNameLogging(), "setMaxFieldSize");
  }

  
  public final int getMaxRows() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getMaxRows");
    checkClosed();
    loggerExternal.exiting(getClassNameLogging(), "getMaxRows", new Integer(this.maxRows));
    return this.maxRows;
  }

  
  public final long getLargeMaxRows() throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    loggerExternal.entering(getClassNameLogging(), "getLargeMaxRows");


    
    loggerExternal.exiting(getClassNameLogging(), "getLargeMaxRows", new Long(this.maxRows));
    
    return getMaxRows();
  }

  
  public final void setMaxRows(int paramInt) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setMaxRows", new Integer(paramInt)); 
    checkClosed();
    if (paramInt < 0) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidRowcount"));
      Object[] arrayOfObject = { new Integer(paramInt) };
      SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), (String)null, true);
    } 



    
    if (1006 != this.resultSetType)
      this.maxRows = paramInt; 
    loggerExternal.exiting(getClassNameLogging(), "setMaxRows");
  }

  
  public final void setLargeMaxRows(long paramLong) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "setLargeMaxRows", new Long(paramLong));
    }

    
    if (paramLong > 2147483647L)
    {
      throw new UnsupportedOperationException(SQLServerException.getErrString("R_invalidMaxRows"));
    }
    setMaxRows((int)paramLong);
    loggerExternal.exiting(getClassNameLogging(), "setLargeMaxRows");
  }

  
  public final void setEscapeProcessing(boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setEscapeProcessing", Boolean.valueOf(paramBoolean)); 
    checkClosed();
    this.escapeProcessing = paramBoolean;
    loggerExternal.exiting(getClassNameLogging(), "setEscapeProcessing");
  }

  
  public final int getQueryTimeout() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getQueryTimeout");
    checkClosed();
    loggerExternal.exiting(getClassNameLogging(), "getQueryTimeout", new Integer(this.queryTimeout));
    return this.queryTimeout;
  }

  
  public final void setQueryTimeout(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "setQueryTimeout", new Integer(paramInt));
    checkClosed();
    if (paramInt < 0) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidQueryTimeOutValue"));
      Object[] arrayOfObject = { new Integer(paramInt) };
      SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), (String)null, true);
    } 
    this.queryTimeout = paramInt;
    loggerExternal.exiting(getClassNameLogging(), "setQueryTimeout");
  }

  
  public final void cancel() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "cancel");
    checkClosed();

    
    if (null != this.currentCommand)
      this.currentCommand.interrupt(SQLServerException.getErrString("R_queryCancelled")); 
    loggerExternal.exiting(getClassNameLogging(), "cancel");
  }



  
  public final SQLWarning getWarnings() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getWarnings");
    checkClosed();
    if (this.sqlWarnings == null)
      return null; 
    SQLWarning sQLWarning = this.sqlWarnings.elementAt(0);
    loggerExternal.exiting(getClassNameLogging(), "getWarnings", sQLWarning);
    return sQLWarning;
  }

  
  public final void clearWarnings() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "clearWarnings");
    checkClosed();
    this.sqlWarnings = null;
    loggerExternal.exiting(getClassNameLogging(), "clearWarnings");
  }

  
  public final void setCursorName(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "setCursorName", paramString);
    checkClosed();
    this.cursorName = paramString;
    loggerExternal.exiting(getClassNameLogging(), "setCursorName");
  }

  
  final String getCursorName() {
    return this.cursorName;
  }

  
  public final ResultSet getResultSet() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getResultSet");
    checkClosed();
    loggerExternal.exiting(getClassNameLogging(), "getResultSet", this.resultSet);
    return this.resultSet;
  }

  
  public final int getUpdateCount() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getUpdateCount");
    
    checkClosed();

    
    if (this.updateCount < -2147483648L || this.updateCount > 2147483647L) {
      SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_updateCountOutofRange"), (String)null, true);
    }
    loggerExternal.exiting(getClassNameLogging(), "getUpdateCount", new Long(this.updateCount));
    
    return (int)this.updateCount;
  }

  
  public final long getLargeUpdateCount() throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    loggerExternal.entering(getClassNameLogging(), "getUpdateCount");
    checkClosed();
    loggerExternal.exiting(getClassNameLogging(), "getUpdateCount", new Long(this.updateCount));
    return this.updateCount;
  }

  
  final void ensureExecuteResultsReader(TDSReader paramTDSReader) {
    this.tdsReader = paramTDSReader;
  }

  
  final void processExecuteResults() throws SQLServerException {
    if (wasExecuted()) {
      
      processBatch();
      TDSParser.parse(resultsReader(), "batch completion");
      ensureExecuteResultsReader(null);
    } 
  }

  
  void processBatch() throws SQLServerException {
    processResults();
  }

  
  final void processResults() throws SQLServerException {
    SQLServerException sQLServerException = null;
    
    while (this.moreResults) {

      
      try {
        
        getNextResult();
      }
      catch (SQLServerException sQLServerException1) {


        
        if (this.moreResults) {

          
          if (2 == sQLServerException1.getDriverErrorCode()) {
            
            if (stmtlogger.isLoggable(Level.FINEST))
            {
              stmtlogger.finest(this + " ignoring database error: " + sQLServerException1.getErrorCode() + " " + sQLServerException1.getMessage());
            }



            
            continue;
          } 


          
          if (sQLServerException1.getSQLState().equals(SQLState.STATEMENT_CANCELED.getSQLStateCode())) {
            
            sQLServerException = sQLServerException1;
            
            continue;
          } 
        } 
        
        this.moreResults = false;
        throw sQLServerException1;
      } 
    } 
    
    clearLastResult();
    
    if (null != sQLServerException) {
      throw sQLServerException;
    }
  }





  
  public final boolean getMoreResults() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getMoreResults");
    checkClosed();



    
    getNextResult();
    loggerExternal.exiting(getClassNameLogging(), "getMoreResults", Boolean.valueOf((null != this.resultSet)));
    return (null != this.resultSet);
  }
















  
  final void clearLastResult() {
    this.updateCount = -1L;

    
    if (null != this.resultSet) {
      
      try {



        
        this.resultSet.close();
      }
      catch (SQLServerException sQLServerException) {
        
        stmtlogger.finest(this + " clearing last result; ignored error closing ResultSet: " + sQLServerException.getErrorCode() + " " + sQLServerException.getMessage());
      
      }
      finally {

        
        this.resultSet = null;
      } 
    }
  }











  
  final boolean getNextResult() throws SQLServerException {
    final class NextResult
      extends TDSTokenHandler
    {
      private StreamDone stmtDoneToken = null;
      final boolean isUpdateCount() { return (null != this.stmtDoneToken); } final long getUpdateCount() {
        return this.stmtDoneToken.getUpdateCount();
      } private boolean isResultSet = false;
      final boolean isResultSet() {
        return this.isResultSet;
      }
      private StreamRetStatus procedureRetStatToken = null;

      
      NextResult() {
        super("getNextResult");
      }





      
      boolean onColMetaData(TDSReader param1TDSReader) throws SQLServerException {
        if (null != this.stmtDoneToken) {
          return false;
        }



        
        if (null != getDatabaseError()) {
          return false;
        }
        
        this.isResultSet = true;
        return false;
      }



      
      boolean onDone(TDSReader param1TDSReader) throws SQLServerException {
        StreamDone streamDone = new StreamDone();
        streamDone.setFromTDS(param1TDSReader);




        
        if (streamDone.isAttnAck()) {
          return false;
        }





        
        if (streamDone.cmdIsDMLOrDDL()) {




          
          if (-1L == streamDone.getUpdateCount() && 4 != SQLServerStatement.this.executeMethod) {
            return true;
          }

          
          this.stmtDoneToken = streamDone;




          
          if (255 != streamDone.getTokenType()) {
            return false;
          }
          if (4 != SQLServerStatement.this.executeMethod)
          {
            
            if (null != SQLServerStatement.this.procedureName) {
              return false;
            }
            
            if (3 == SQLServerStatement.this.executeMethod) {
              return false;
            }




            
            if (!SQLServerStatement.this.connection.useLastUpdateCount()) {
              return false;


            
            }


          
          }


        
        }
        else {


          
          if (streamDone.isFinal()) {
            
            SQLServerStatement.this.moreResults = false;
            return false;
          } 
          
          if (4 == SQLServerStatement.this.executeMethod)
          {

            
            if (255 != streamDone.getTokenType() || streamDone.wasRPCInBatch()) {
              
              SQLServerStatement.this.moreResults = false;
              return false;
            } 
          }
        } 


        
        if (streamDone.isError()) {
          return false;
        }
        
        return true;
      }




      
      boolean onRetStatus(TDSReader param1TDSReader) throws SQLServerException {
        if (SQLServerStatement.this.consumeExecOutParam(param1TDSReader)) {
          
          SQLServerStatement.this.moreResults = false;



        
        }
        else {



          
          this.procedureRetStatToken = new StreamRetStatus();
          this.procedureRetStatToken.setFromTDS(param1TDSReader);
        } 
        
        return true;
      }





      
      boolean onRetValue(TDSReader param1TDSReader) throws SQLServerException {
        if (SQLServerStatement.this.moreResults && null == this.procedureRetStatToken) {
          
          Parameter parameter = new Parameter(Util.shouldHonorAEForParameters(SQLServerStatement.this.stmtColumnEncriptionSetting, SQLServerStatement.this.connection));
          parameter.skipRetValStatus(param1TDSReader);
          parameter.skipValue(param1TDSReader, true);
          return true;
        } 
        
        return false;
      }

      
      boolean onInfo(TDSReader param1TDSReader) throws SQLServerException {
        StreamInfo streamInfo = new StreamInfo();
        streamInfo.setFromTDS(param1TDSReader);












        
        if (16954 == streamInfo.msg.getErrorNumber()) {
          SQLServerStatement.this.executedSqlDirectly = true;
        }
        SQLWarning sQLWarning = new SQLWarning(streamInfo.msg.getMessage(), SQLServerException.generateStateCode(SQLServerStatement.this.connection, streamInfo.msg.getErrorNumber(), streamInfo.msg.getErrorState()), streamInfo.msg.getErrorNumber());




        
        if (SQLServerStatement.this.sqlWarnings == null) {
          
          SQLServerStatement.this.sqlWarnings = new Vector<>();
        }
        else {
          
          int i = SQLServerStatement.this.sqlWarnings.size();
          SQLWarning sQLWarning1 = SQLServerStatement.this.sqlWarnings.elementAt(i - 1);
          sQLWarning1.setNextWarning(sQLWarning);
        } 
        SQLServerStatement.this.sqlWarnings.add(sQLWarning);
        return true;
      }
    };

    
    if (!wasExecuted()) {
      
      this.moreResults = false;
      return false;
    } 

    
    clearLastResult();


    
    if (!this.moreResults) {
      return false;
    }
    
    NextResult nextResult = new NextResult();
    TDSParser.parse(resultsReader(), nextResult);

    
    if (null != nextResult.getDatabaseError()) {
      
      SQLServerException.makeFromDatabaseError(this.connection, (Object)null, nextResult.getDatabaseError().getMessage(), nextResult.getDatabaseError(), false);


    
    }
    else {


      
      if (nextResult.isResultSet()) {
        
        this.resultSet = new SQLServerResultSet(this);
        return true;
      } 







      
      if (nextResult.isUpdateCount()) {
        
        this.updateCount = nextResult.getUpdateCount();
        return true;
      } 
    } 






    
    this.updateCount = -1L;
    if (!this.moreResults) {
      return true;
    }


    
    this.moreResults = false;
    return false;
  }








  
  boolean consumeExecOutParam(TDSReader paramTDSReader) throws SQLServerException {
    if (this.expectCursorOutParams) {
      
      TDSParser.parse(paramTDSReader, new StmtExecOutParamHandler());
      return true;
    } 
    
    return false;
  }



  
  public final void setFetchDirection(int paramInt) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setFetchDirection", new Integer(paramInt)); 
    checkClosed();
    if ((1000 != paramInt && 1001 != paramInt && 1002 != paramInt) || (1000 != paramInt && (2003 == this.resultSetType || 2004 == this.resultSetType))) {






      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidFetchDirection"));
      Object[] arrayOfObject = { new Integer(paramInt) };
      SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), (String)null, false);
    } 
    
    this.nFetchDirection = paramInt;
    loggerExternal.exiting(getClassNameLogging(), "setFetchDirection");
  }

  
  public final int getFetchDirection() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getFetchDirection");
    checkClosed();
    loggerExternal.exiting(getClassNameLogging(), "getFetchDirection", new Integer(this.nFetchDirection));
    return this.nFetchDirection;
  }

  
  public final void setFetchSize(int paramInt) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "setFetchSize", new Integer(paramInt)); 
    checkClosed();
    if (paramInt < 0) {
      SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_invalidFetchSize"), (String)null, false);
    }
    this.nFetchSize = (0 == paramInt) ? this.defaultFetchSize : paramInt;
    loggerExternal.exiting(getClassNameLogging(), "setFetchSize");
  }
  
  public final int getFetchSize() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getFetchSize");
    checkClosed();
    loggerExternal.exiting(getClassNameLogging(), "getFetchSize", new Integer(this.nFetchSize));
    return this.nFetchSize;
  }

  
  public final int getResultSetConcurrency() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getResultSetConcurrency");
    checkClosed();
    loggerExternal.exiting(getClassNameLogging(), "getResultSetConcurrency", new Integer(this.resultSetConcurrency));
    return this.resultSetConcurrency;
  }

  
  public final int getResultSetType() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getResultSetType");
    checkClosed();
    loggerExternal.exiting(getClassNameLogging(), "getResultSetType", new Integer(this.appResultSetType));
    return this.appResultSetType;
  }

  
  public void addBatch(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "addBatch", paramString);
    checkClosed();



    
    paramString = ensureSQLSyntax(paramString);
    
    this.batchStatementBuffer.add(paramString);
    loggerExternal.exiting(getClassNameLogging(), "addBatch");
  }

  
  public void clearBatch() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "clearBatch");
    checkClosed();
    this.batchStatementBuffer.clear();
    loggerExternal.exiting(getClassNameLogging(), "clearBatch");
  }




  
  public int[] executeBatch() throws SQLServerException, BatchUpdateException {
    loggerExternal.entering(getClassNameLogging(), "executeBatch");
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();
    discardLastExecutionResults();




    
    try {
      int i = this.batchStatementBuffer.size();
      int[] arrayOfInt = new int[i];
      for (byte b1 = 0; b1 < i; b1++) {
        arrayOfInt[b1] = -3;
      }

      
      SQLServerException sQLServerException = null;
      
      for (byte b2 = 0; b2 < i; b2++) {

        
        try {



          
          if (0 == b2) {

            
            executeStatement(new StmtBatchExecCmd(this));

          
          }
          else {

            
            startResults();
            if (!getNextResult()) {
              break;
            }
          } 
          if (null != this.resultSet)
          {
            SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_resultsetGeneratedForUpdate"), (String)null, true);


          
          }
          else
          {

            
            arrayOfInt[b2] = (-1 != (int)this.updateCount) ? (int)this.updateCount : -2;
          }
        
        } catch (SQLServerException sQLServerException1) {



          
          if (this.connection.isSessionUnAvailable() || this.connection.rolledBackTransaction()) {
            throw sQLServerException1;
          }

          
          sQLServerException = sQLServerException1;
        } 
      } 

      
      if (null != sQLServerException)
      {
        throw new BatchUpdateException(sQLServerException.getMessage(), sQLServerException.getSQLState(), sQLServerException.getErrorCode(), arrayOfInt);
      }



      
      loggerExternal.exiting(getClassNameLogging(), "executeBatch", arrayOfInt);
      return arrayOfInt;

    
    }
    finally {


      
      this.batchStatementBuffer.clear();
    } 
  }

  
  public long[] executeLargeBatch() throws SQLServerException, BatchUpdateException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    loggerExternal.entering(getClassNameLogging(), "executeLargeBatch");
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    checkClosed();
    discardLastExecutionResults();




    
    try {
      int i = this.batchStatementBuffer.size();
      long[] arrayOfLong = new long[i];
      for (byte b1 = 0; b1 < i; b1++) {
        arrayOfLong[b1] = -3L;
      }

      
      SQLServerException sQLServerException = null;
      
      for (byte b2 = 0; b2 < i; b2++) {

        
        try {



          
          if (0 == b2) {

            
            executeStatement(new StmtBatchExecCmd(this));

          
          }
          else {

            
            startResults();
            if (!getNextResult()) {
              break;
            }
          } 
          if (null != this.resultSet)
          {
            SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_resultsetGeneratedForUpdate"), (String)null, true);


          
          }
          else
          {

            
            arrayOfLong[b2] = (-1L != this.updateCount) ? this.updateCount : -2L;
          }
        
        } catch (SQLServerException sQLServerException1) {



          
          if (this.connection.isSessionUnAvailable() || this.connection.rolledBackTransaction()) {
            throw sQLServerException1;
          }

          
          sQLServerException = sQLServerException1;
        } 
      } 

      
      if (null != sQLServerException)
      {
        DriverJDBCVersion.throwBatchUpdateException(sQLServerException, arrayOfLong);
      }
      loggerExternal.exiting(getClassNameLogging(), "executeLargeBatch", arrayOfLong);
      return arrayOfLong;

    
    }
    finally {


      
      this.batchStatementBuffer.clear();
    } 
  }






  
  public final Connection getConnection() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getConnection");
    if (this.bIsClosed)
    {
      SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_statementIsClosed"), (String)null, false);
    }
    Connection connection = this.connection.getConnection();
    loggerExternal.exiting(getClassNameLogging(), "getConnection", connection);
    return connection;
  }










  
  final int getResultSetScrollOpt() {
    boolean bool = (null == this.inOutParam) ? false : true;
    
    switch (this.resultSetType) {
      
      case 2004:
        return bool | ((1007 == this.resultSetConcurrency) ? 16 : 4);


      
      case 1006:
        return bool | 0x2;
      
      case 1005:
        return bool | true;
      
      case 1004:
        return bool | 0x8;
    } 


    
    return 0;
  }

  
  final int getResultSetCCOpt() {
    switch (this.resultSetConcurrency) {
      
      case 1007:
        return 8193;

      
      case 1008:
        return 24580;
      
      case 1009:
        return 24578;
      
      case 1010:
        return 24584;
    } 


    
    return 0;
  }

  
  private final void doExecuteCursored(StmtExecCmd paramStmtExecCmd, String paramString) throws SQLServerException {
    if (stmtlogger.isLoggable(Level.FINER))
    {
      stmtlogger.finer(toString() + " Execute for cursor open" + " SQL:" + paramString + " Scrollability:" + getResultSetScrollOpt() + " Concurrency:" + getResultSetCCOpt());
    }




    
    this.executedSqlDirectly = false;
    this.expectCursorOutParams = true;
    TDSWriter tDSWriter = paramStmtExecCmd.startRequest((byte)3);
    tDSWriter.writeShort((short)-1);
    tDSWriter.writeShort((short)2);
    tDSWriter.writeByte((byte)0);
    tDSWriter.writeByte((byte)0);

    
    tDSWriter.writeRPCInt(null, new Integer(0), true);

    
    tDSWriter.writeRPCStringUnicode(paramString);

    
    tDSWriter.writeRPCInt(null, new Integer(getResultSetScrollOpt()), false);

    
    tDSWriter.writeRPCInt(null, new Integer(getResultSetCCOpt()), false);

    
    tDSWriter.writeRPCInt(null, new Integer(0), true);
    
    ensureExecuteResultsReader(paramStmtExecCmd.startResponse(this.isResponseBufferingAdaptive));
    startResults();
    getNextResult();
  }



  
  public final int getResultSetHoldability() throws SQLException {
    loggerExternal.entering(getClassNameLogging(), "getResultSetHoldability");
    checkClosed();
    int i = this.connection.getHoldability();
    loggerExternal.exiting(getClassNameLogging(), "getResultSetHoldability", new Integer(i));
    return i;
  }

  
  public final boolean execute(String paramString, int paramInt) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      
      loggerExternal.entering(getClassNameLogging(), "execute", new Object[] { paramString, new Integer(paramInt) });
      if (Util.IsActivityTraceOn())
      {
        loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
      }
    } 
    checkClosed();
    if (paramInt != 1 && paramInt != 2) {

      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidAutoGeneratedKeys"));
      Object[] arrayOfObject = { new Integer(paramInt) };
      SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), (String)null, false);
    } 





    
    executeStatement(new StmtExecCmd(this, paramString, 3, paramInt));
    loggerExternal.exiting(getClassNameLogging(), "execute", Boolean.valueOf((null != this.resultSet)));
    return (null != this.resultSet);
  }

  
  public final boolean execute(String paramString, int[] paramArrayOfint) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "execute", new Object[] { paramString, paramArrayOfint }); 
    checkClosed();
    if (paramArrayOfint == null || paramArrayOfint.length != 1)
    {
      SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_invalidColumnArrayLength"), (String)null, false);
    }




    
    boolean bool = execute(paramString, 1);
    loggerExternal.exiting(getClassNameLogging(), "execute", Boolean.valueOf(bool));
    return bool;
  }

  
  public final boolean execute(String paramString, String[] paramArrayOfString) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "execute", new Object[] { paramString, paramArrayOfString }); 
    checkClosed();
    if (paramArrayOfString == null || paramArrayOfString.length != 1)
    {
      SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_invalidColumnArrayLength"), (String)null, false);
    }




    
    boolean bool = execute(paramString, 1);
    loggerExternal.exiting(getClassNameLogging(), "execute", Boolean.valueOf(bool));
    return bool;
  }

  
  public final int executeUpdate(String paramString, int paramInt) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      
      loggerExternal.entering(getClassNameLogging(), "executeUpdate", new Object[] { paramString, new Integer(paramInt) });
      if (Util.IsActivityTraceOn())
      {
        loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
      }
    } 
    checkClosed();
    if (paramInt != 1 && paramInt != 2) {

      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidAutoGeneratedKeys"));
      Object[] arrayOfObject = { new Integer(paramInt) };
      SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), (String)null, false);
    } 




    
    executeStatement(new StmtExecCmd(this, paramString, 2, paramInt));

    
    if (this.updateCount < -2147483648L || this.updateCount > 2147483647L) {
      SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_updateCountOutofRange"), (String)null, true);
    }
    loggerExternal.exiting(getClassNameLogging(), "executeUpdate", new Long(this.updateCount));
    
    return (int)this.updateCount;
  }

  
  public final long executeLargeUpdate(String paramString, int paramInt) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    if (loggerExternal.isLoggable(Level.FINER)) {
      
      loggerExternal.entering(getClassNameLogging(), "executeLargeUpdate", new Object[] { paramString, new Integer(paramInt) });
      if (Util.IsActivityTraceOn())
      {
        loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
      }
    } 
    checkClosed();
    if (paramInt != 1 && paramInt != 2) {

      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidAutoGeneratedKeys"));
      Object[] arrayOfObject = { new Integer(paramInt) };
      SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), (String)null, false);
    } 




    
    executeStatement(new StmtExecCmd(this, paramString, 2, paramInt));
    loggerExternal.exiting(getClassNameLogging(), "executeLargeUpdate", new Long(this.updateCount));
    return this.updateCount;
  }

  
  public final int executeUpdate(String paramString, int[] paramArrayOfint) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "executeUpdate", new Object[] { paramString, paramArrayOfint }); 
    checkClosed();
    if (paramArrayOfint == null || paramArrayOfint.length != 1)
    {
      SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_invalidColumnArrayLength"), (String)null, false);
    }




    
    int i = executeUpdate(paramString, 1);
    loggerExternal.exiting(getClassNameLogging(), "executeUpdate", new Integer(i));
    return i;
  }

  
  public final long executeLargeUpdate(String paramString, int[] paramArrayOfint) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "executeLargeUpdate", new Object[] { paramString, paramArrayOfint }); 
    checkClosed();
    if (paramArrayOfint == null || paramArrayOfint.length != 1)
    {
      SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_invalidColumnArrayLength"), (String)null, false);
    }




    
    long l = executeLargeUpdate(paramString, 1);
    loggerExternal.exiting(getClassNameLogging(), "executeLargeUpdate", new Long(l));
    return l;
  }

  
  public final int executeUpdate(String paramString, String[] paramArrayOfString) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "executeUpdate", new Object[] { paramString, paramArrayOfString }); 
    checkClosed();
    if (paramArrayOfString == null || paramArrayOfString.length != 1)
    {
      SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_invalidColumnArrayLength"), (String)null, false);
    }




    
    int i = executeUpdate(paramString, 1);
    loggerExternal.exiting(getClassNameLogging(), "executeUpdate", new Integer(i));
    return i;
  }

  
  public final long executeLargeUpdate(String paramString, String[] paramArrayOfString) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "executeLargeUpdate", new Object[] { paramString, paramArrayOfString }); 
    checkClosed();
    if (paramArrayOfString == null || paramArrayOfString.length != 1)
    {
      SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_invalidColumnArrayLength"), (String)null, false);
    }




    
    long l = executeLargeUpdate(paramString, 1);
    loggerExternal.exiting(getClassNameLogging(), "executeLargeUpdate", new Long(l));
    return l;
  }

  
  public final ResultSet getGeneratedKeys() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getGeneratedKeys");
    checkClosed();
    
    if (null == this.autoGeneratedKeys) {
      
      long l = this.updateCount;



      
      if (!getNextResult() || null == this.resultSet)
      {
        SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_statementMustBeExecuted"), (String)null, false);
      }





      
      this.autoGeneratedKeys = this.resultSet;
      this.updateCount = l;
    } 
    loggerExternal.exiting(getClassNameLogging(), "getGeneratedKeys", this.autoGeneratedKeys);
    return this.autoGeneratedKeys;
  }

  
  public final boolean getMoreResults(int paramInt) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getMoreResults", new Integer(paramInt)); 
    checkClosed();
    if (2 == paramInt) {
      NotImplemented();
    }
    if (1 != paramInt && 3 != paramInt) {
      SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_modeSuppliedNotValid"), (String)null, true);
    }
    
    SQLServerResultSet sQLServerResultSet = this.resultSet;
    boolean bool = getMoreResults();
    if (sQLServerResultSet != null) {
      
      try {
        
        sQLServerResultSet.close();
      }
      catch (SQLException sQLException) {
        
        throw new SQLServerException(null, sQLException.getMessage(), null, 0, false);
      } 
    }
    
    loggerExternal.exiting(getClassNameLogging(), "getMoreResults", Boolean.valueOf(bool));
    return bool;
  }

  
  public boolean isClosed() throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    
    loggerExternal.entering(getClassNameLogging(), "isClosed");
    boolean bool = (this.bIsClosed || this.connection.isSessionUnAvailable()) ? true : false;
    loggerExternal.exiting(getClassNameLogging(), "isClosed", Boolean.valueOf(bool));
    return bool;
  }

  
  public boolean isCloseOnCompletion() throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC41();
    
    loggerExternal.entering(getClassNameLogging(), "isCloseOnCompletion");
    checkClosed();
    loggerExternal.exiting(getClassNameLogging(), "isCloseOnCompletion", Boolean.valueOf(this.isCloseOnCompletion));
    return this.isCloseOnCompletion;
  }

  
  public boolean isPoolable() throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    loggerExternal.entering(getClassNameLogging(), "isPoolable");
    checkClosed();
    loggerExternal.exiting(getClassNameLogging(), "isPoolable", Boolean.valueOf(this.stmtPoolable));
    return this.stmtPoolable;
  }

  
  public void setPoolable(boolean paramBoolean) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    loggerExternal.entering(getClassNameLogging(), "setPoolable", Boolean.valueOf(paramBoolean));
    checkClosed();
    this.stmtPoolable = paramBoolean;
    loggerExternal.exiting(getClassNameLogging(), "setPoolable");
  }

  
  public boolean isWrapperFor(Class<?> paramClass) throws SQLException {
    loggerExternal.entering(getClassNameLogging(), "isWrapperFor");
    DriverJDBCVersion.checkSupportsJDBC4();
    boolean bool = paramClass.isInstance(this);
    loggerExternal.exiting(getClassNameLogging(), "isWrapperFor", Boolean.valueOf(bool));
    return bool;
  }
  
  public <T> T unwrap(Class<T> paramClass) throws SQLException {
    T t;
    loggerExternal.entering(getClassNameLogging(), "unwrap");
    DriverJDBCVersion.checkSupportsJDBC4();

    
    try {
      t = paramClass.cast(this);
    }
    catch (ClassCastException classCastException) {
      
      throw new SQLServerException(classCastException.getMessage(), classCastException);
    } 
    loggerExternal.exiting(getClassNameLogging(), "unwrap", t);
    return t;
  }




















  
  public final void setResponseBuffering(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "setResponseBuffering", paramString);
    checkClosed();
    if (paramString.equalsIgnoreCase("full")) {
      
      this.isResponseBufferingAdaptive = false;
      this.wasResponseBufferingSet = true;
    }
    else if (paramString.equalsIgnoreCase("adaptive")) {
      
      this.isResponseBufferingAdaptive = true;
      this.wasResponseBufferingSet = true;
    }
    else {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidresponseBuffering"));
      Object[] arrayOfObject = { new String(paramString) };
      SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), (String)null, false);
    } 
    loggerExternal.exiting(getClassNameLogging(), "setResponseBuffering");
  }
  
  public final String getResponseBuffering() throws SQLServerException {
    String str;
    loggerExternal.entering(getClassNameLogging(), "getResponseBuffering");
    checkClosed();
    
    if (this.wasResponseBufferingSet) {
      
      if (this.isResponseBufferingAdaptive) {
        str = "adaptive";
      } else {
        str = "full";
      } 
    } else {
      
      str = this.connection.getResponseBuffering();
    } 
    loggerExternal.exiting(getClassNameLogging(), "getResponseBuffering", str);
    return str;
  }
}
