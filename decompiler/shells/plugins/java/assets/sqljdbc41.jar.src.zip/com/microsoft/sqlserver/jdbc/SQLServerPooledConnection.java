package com.microsoft.sqlserver.jdbc;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.ConnectionEvent;
import javax.sql.ConnectionEventListener;
import javax.sql.PooledConnection;
import javax.sql.StatementEventListener;

public class SQLServerPooledConnection
  implements PooledConnection
{
  private final Vector<ConnectionEventListener> listeners;
  private SQLServerDataSource factoryDataSource;
  private SQLServerConnection physicalConnection;
  private SQLServerConnectionPoolProxy lastProxyConnection;
  private String factoryUser;
  private String factoryPassword;
  private Logger pcLogger;
  private static int basePooledConnectionID = 0;
  
  private final String traceID;

  
  SQLServerPooledConnection(SQLServerDataSource paramSQLServerDataSource, String paramString1, String paramString2) throws SQLException {
    this.listeners = new Vector<>();
    
    this.pcLogger = SQLServerDataSource.dsLogger;

    
    this.factoryDataSource = paramSQLServerDataSource;
    this.factoryUser = paramString1;
    this.factoryPassword = paramString2;
    
    if (this.pcLogger.isLoggable(Level.FINER)) {
      this.pcLogger.finer(toString() + " Start create new connection for pool.");
    }
    this.physicalConnection = createNewConnection();
    String str = getClass().getName();
    this.traceID = str.substring(1 + str.lastIndexOf('.')) + ":" + nextPooledConnectionID();
    if (this.pcLogger.isLoggable(Level.FINE)) {
      this.pcLogger.fine(toString() + " created by (" + paramSQLServerDataSource.toString() + ")" + " Physical connection " + safeCID() + ", End create new connection for pool");
    }
  }



  
  public String toString() {
    return this.traceID;
  }


  
  private SQLServerConnection createNewConnection() throws SQLException {
    return this.factoryDataSource.getConnectionInternal(this.factoryUser, this.factoryPassword, this);
  }




  
  public Connection getConnection() throws SQLException {
    if (this.pcLogger.isLoggable(Level.FINER))
      this.pcLogger.finer(toString() + " user:(default)."); 
    synchronized (this) {

      
      if (this.physicalConnection == null)
      {
        SQLServerException.makeFromDriverError(null, this, SQLServerException.getErrString("R_physicalConnectionIsClosed"), "", true);
      }




      
      this.physicalConnection.doSecurityCheck();
      if (this.pcLogger.isLoggable(Level.FINE)) {
        this.pcLogger.fine(toString() + " Physical connection, " + safeCID());
      }
      if (null != this.physicalConnection.getAuthenticationResult() && 
        Util.checkIfNeedNewAccessToken(this.physicalConnection))
      {
        this.physicalConnection = createNewConnection();
      }



      
      if (null != this.lastProxyConnection) {

        
        this.physicalConnection.resetPooledConnection();
        if (this.pcLogger.isLoggable(Level.FINE) && !this.lastProxyConnection.isClosed()) {
          this.pcLogger.fine(toString() + "proxy " + this.lastProxyConnection.toString() + " is not closed before getting the connection.");
        }
        this.lastProxyConnection.internalClose();
      } 
      
      this.lastProxyConnection = new SQLServerConnectionPoolProxy(this.physicalConnection);
      if (this.pcLogger.isLoggable(Level.FINE) && !this.lastProxyConnection.isClosed()) {
        this.pcLogger.fine(toString() + " proxy " + this.lastProxyConnection.toString() + " is returned.");
      }
      return this.lastProxyConnection;
    } 
  }






  
  void notifyEvent(SQLServerException paramSQLServerException) {
    if (this.pcLogger.isLoggable(Level.FINER)) {
      this.pcLogger.finer(toString() + " Exception:" + paramSQLServerException + safeCID());
    }
    
    if (null != paramSQLServerException)
    {
      synchronized (this) {
        
        if (null != this.lastProxyConnection) {
          
          this.lastProxyConnection.internalClose();
          this.lastProxyConnection = null;
        } 
      } 
    }

    
    synchronized (this.listeners) {
      
      for (byte b = 0; b < this.listeners.size(); b++) {
        
        ConnectionEventListener connectionEventListener = this.listeners.elementAt(b);
        
        if (connectionEventListener != null) {
          
          ConnectionEvent connectionEvent = new ConnectionEvent(this, paramSQLServerException);
          if (null == paramSQLServerException) {
            
            if (this.pcLogger.isLoggable(Level.FINER))
              this.pcLogger.finer(toString() + " notifyEvent:connectionClosed " + safeCID()); 
            connectionEventListener.connectionClosed(connectionEvent);
          }
          else {
            
            if (this.pcLogger.isLoggable(Level.FINER))
              this.pcLogger.finer(toString() + " notifyEvent:connectionErrorOccurred " + safeCID()); 
            connectionEventListener.connectionErrorOccurred(connectionEvent);
          } 
        } 
      } 
    } 
  }



  
  public void addConnectionEventListener(ConnectionEventListener paramConnectionEventListener) {
    if (this.pcLogger.isLoggable(Level.FINER))
      this.pcLogger.finer(toString() + safeCID()); 
    synchronized (this.listeners) {
      
      this.listeners.add(paramConnectionEventListener);
    } 
  }



  
  public void close() throws SQLException {
    if (this.pcLogger.isLoggable(Level.FINER))
      this.pcLogger.finer(toString() + " Closing physical connection, " + safeCID()); 
    synchronized (this) {

      
      if (null != this.lastProxyConnection)
      {
        this.lastProxyConnection.internalClose(); } 
      if (null != this.physicalConnection) {
        
        this.physicalConnection.DetachFromPool();
        this.physicalConnection.close();
      } 
      this.physicalConnection = null;
    } 
    synchronized (this.listeners) {
      
      this.listeners.clear();
    } 
  }




  
  public void removeConnectionEventListener(ConnectionEventListener paramConnectionEventListener) {
    if (this.pcLogger.isLoggable(Level.FINER))
      this.pcLogger.finer(toString() + safeCID()); 
    synchronized (this.listeners) {
      
      this.listeners.remove(paramConnectionEventListener);
    } 
  }

  
  public void addStatementEventListener(StatementEventListener paramStatementEventListener) {
    DriverJDBCVersion.checkSupportsJDBC4();

    
    throw new UnsupportedOperationException(SQLServerException.getErrString("R_notSupported"));
  }

  
  public void removeStatementEventListener(StatementEventListener paramStatementEventListener) {
    DriverJDBCVersion.checkSupportsJDBC4();

    
    throw new UnsupportedOperationException(SQLServerException.getErrString("R_notSupported"));
  }


  
  SQLServerConnection getPhysicalConnection() {
    return this.physicalConnection;
  }


  
  private static synchronized int nextPooledConnectionID() {
    basePooledConnectionID++;
    return basePooledConnectionID;
  }



  
  private String safeCID() {
    if (null == this.physicalConnection) return " ConnectionID:(null)"; 
    return this.physicalConnection.toString();
  }
}
