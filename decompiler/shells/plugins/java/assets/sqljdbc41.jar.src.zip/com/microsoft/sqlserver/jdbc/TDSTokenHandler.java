package com.microsoft.sqlserver.jdbc;
































































































































































class TDSTokenHandler
{
  final String logContext;
  private StreamError databaseError;
  
  final StreamError getDatabaseError() {
    return this.databaseError;
  }
  
  TDSTokenHandler(String paramString) {
    this.logContext = paramString;
  }

  
  boolean onSSPI(TDSReader paramTDSReader) throws SQLServerException {
    TDSParser.throwUnexpectedTokenException(paramTDSReader, this.logContext);
    return false;
  }

  
  boolean onLoginAck(TDSReader paramTDSReader) throws SQLServerException {
    TDSParser.throwUnexpectedTokenException(paramTDSReader, this.logContext);
    return false;
  }

  
  boolean onFeatureExtensionAck(TDSReader paramTDSReader) throws SQLServerException {
    TDSParser.throwUnexpectedTokenException(paramTDSReader, this.logContext);
    return false;
  }

  
  boolean onEnvChange(TDSReader paramTDSReader) throws SQLServerException {
    paramTDSReader.getConnection().processEnvChange(paramTDSReader);
    return true;
  }

  
  boolean onRetStatus(TDSReader paramTDSReader) throws SQLServerException {
    (new StreamRetStatus()).setFromTDS(paramTDSReader);
    return true;
  }

  
  boolean onRetValue(TDSReader paramTDSReader) throws SQLServerException {
    TDSParser.throwUnexpectedTokenException(paramTDSReader, this.logContext);
    return false;
  }

  
  boolean onDone(TDSReader paramTDSReader) throws SQLServerException {
    StreamDone streamDone = new StreamDone();
    streamDone.setFromTDS(paramTDSReader);
    return true;
  }

  
  boolean onError(TDSReader paramTDSReader) throws SQLServerException {
    if (null == this.databaseError) {
      
      this.databaseError = new StreamError();
      this.databaseError.setFromTDS(paramTDSReader);
    }
    else {
      
      (new StreamError()).setFromTDS(paramTDSReader);
    } 
    
    return true;
  }

  
  boolean onInfo(TDSReader paramTDSReader) throws SQLServerException {
    TDSParser.ignoreLengthPrefixedToken(paramTDSReader);
    return true;
  }

  
  boolean onOrder(TDSReader paramTDSReader) throws SQLServerException {
    TDSParser.ignoreLengthPrefixedToken(paramTDSReader);
    return true;
  }

  
  boolean onColMetaData(TDSReader paramTDSReader) throws SQLServerException {
    TDSParser.throwUnexpectedTokenException(paramTDSReader, this.logContext);
    return false;
  }

  
  boolean onRow(TDSReader paramTDSReader) throws SQLServerException {
    TDSParser.throwUnexpectedTokenException(paramTDSReader, this.logContext);
    return false;
  }

  
  boolean onNBCRow(TDSReader paramTDSReader) throws SQLServerException {
    TDSParser.throwUnexpectedTokenException(paramTDSReader, this.logContext);
    return false;
  }

  
  boolean onColInfo(TDSReader paramTDSReader) throws SQLServerException {
    TDSParser.ignoreLengthPrefixedToken(paramTDSReader);
    return true;
  }

  
  boolean onTabName(TDSReader paramTDSReader) throws SQLServerException {
    TDSParser.ignoreLengthPrefixedToken(paramTDSReader);
    return true;
  }

  
  void onEOF(TDSReader paramTDSReader) throws SQLServerException {
    if (null != getDatabaseError())
    {
      SQLServerException.makeFromDatabaseError(paramTDSReader.getConnection(), null, getDatabaseError().getMessage(), getDatabaseError(), false);
    }
  }






  
  boolean onFedAuthInfo(TDSReader paramTDSReader) throws SQLServerException {
    paramTDSReader.getConnection().processFedAuthInfo(paramTDSReader, this);
    return true;
  }
}
