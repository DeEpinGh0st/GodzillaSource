package com.microsoft.sqlserver.jdbc;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.NClob;
import java.sql.Ref;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.MessageFormat;
import java.util.Calendar;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import microsoft.sql.DateTimeOffset;

public final class SQLServerResultSet implements ISQLServerResultSet {
  private static int lastResultSetID = 0; private final String traceID;
  private static synchronized int nextResultSetID() {
    return ++lastResultSetID;
  } static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerResultSet");
  public String toString() { return this.traceID; } String logCursorState() {
    return " currentRow:" + this.currentRow + " numFetchedRows:" + this.numFetchedRows + " rowCount:" + this.rowCount;
  } private static final Logger loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.ResultSet"); private final String loggingClassName;
  private final SQLServerStatement stmt;
  private final int maxRows;
  private ResultSetMetaData metaData;
  
  String getClassNameLogging() {
    return this.loggingClassName;
  }



  
  private boolean isClosed = false;


  
  private final int serverCursorId;


  
  private int fetchDirection;


  
  private int fetchSize;


  
  private boolean isOnInsertRow = false;


  
  private boolean lastValueWasNull = false;


  
  private int lastColumnIndex;


  
  private boolean areNullCompressedColumnsInitialized = false;


  
  private RowType resultSetCurrentRowType = RowType.UNKNOWN; private Closeable activeStream; private final ScrollWindow scrollWindow; private static final int BEFORE_FIRST_ROW = 0;
  private static final int AFTER_LAST_ROW = -1;
  private static final int UNKNOWN_ROW = -2;
  
  final RowType getCurrentRowType() {
    return this.resultSetCurrentRowType;
  }


  
  final void setCurrentRowType(RowType paramRowType) {
    this.resultSetCurrentRowType = paramRowType;
  }

















  
  private int currentRow = 0;
  private boolean updatedCurrentRow = false;
  
  final boolean getUpdatedCurrentRow() {
    return this.updatedCurrentRow; } final void setUpdatedCurrentRow(boolean paramBoolean) {
    this.updatedCurrentRow = paramBoolean;
  }
  private boolean deletedCurrentRow = false; static final int UNKNOWN_ROW_COUNT = -3; private int rowCount; private final Column[] columns;
  
  final boolean getDeletedCurrentRow() { return this.deletedCurrentRow; } final void setDeletedCurrentRow(boolean paramBoolean) {
    this.deletedCurrentRow = paramBoolean;
  }













  
  private CekTable cekTable = null; private TDSReader tdsReader; private final FetchBuffer fetchBuffer;
  private SQLServerException rowErrorException;
  private int numFetchedRows;
  
  CekTable getCekTable() {
    return this.cekTable;
  }


  
  final void setColumnName(int paramInt, String paramString) {
    this.columns[paramInt - 1].setColumnName(paramString);
  }





  
  private final void skipColumns(int paramInt, boolean paramBoolean) throws SQLServerException {
    assert this.lastColumnIndex >= 1;
    assert 0 <= paramInt && paramInt <= this.columns.length;
    
    for (byte b = 0; b < paramInt; b++) {
      
      Column column = getColumn(this.lastColumnIndex++);
      column.skipValue(this.tdsReader, (paramBoolean && isForwardOnly()));
      if (paramBoolean) {
        column.clear();
      }
    } 
  }


















  
  public boolean isWrapperFor(Class<?> paramClass) throws SQLException {
    loggerExternal.entering(getClassNameLogging(), "isWrapperFor");
    DriverJDBCVersion.checkSupportsJDBC4();
    boolean bool = paramClass.isInstance(this);
    loggerExternal.exiting(getClassNameLogging(), "isWrapperFor", Boolean.valueOf(bool));
    return bool;
  }

















  
  SQLServerResultSet(SQLServerStatement paramSQLServerStatement) throws SQLServerException {
    final class ServerCursorInitializer
      extends CursorInitializer
    {
      private final SQLServerStatement stmt;

















      
      final int getRowCount() {
        return this.stmt.getServerCursorRowCount(); } final int getServerCursorId() {
        return this.stmt.getServerCursorId();
      }
      
      ServerCursorInitializer(SQLServerStatement param1SQLServerStatement) {
        super("ServerCursorInitializer");
        this.stmt = param1SQLServerStatement;
      }






      
      boolean onRetStatus(TDSReader param1TDSReader) throws SQLServerException {
        this.stmt.consumeExecOutParam(param1TDSReader);
        return true;
      }




      
      boolean onRetValue(TDSReader param1TDSReader) throws SQLServerException {
        return false;
      }
    };

    
    final class ClientCursorInitializer
      extends CursorInitializer
    {
      private int rowCount = -3;
      final int getRowCount() { return this.rowCount; } final int getServerCursorId() {
        return 0;
      }
      
      ClientCursorInitializer() {
        super("ClientCursorInitializer");
      }


      
      boolean onRow(TDSReader param1TDSReader) throws SQLServerException {
        return false;
      }


      
      boolean onNBCRow(TDSReader param1TDSReader) throws SQLServerException {
        return false;
      }




      
      boolean onError(TDSReader param1TDSReader) throws SQLServerException {
        this.rowCount = 0;
        return false;
      }



      
      boolean onDone(TDSReader param1TDSReader) throws SQLServerException {
        this.rowCount = 0;
        return false;
      }
    };

































































    
    this.rowErrorException = null; int i = nextResultSetID(); this.loggingClassName = "com.microsoft.sqlserver.jdbc.SQLServerResultSet:" + i; this.traceID = "SQLServerResultSet:" + i; this.stmt = paramSQLServerStatement; this.maxRows = paramSQLServerStatement.maxRows; this.fetchSize = paramSQLServerStatement.nFetchSize; this.fetchDirection = paramSQLServerStatement.nFetchDirection; TDSTokenHandler tDSTokenHandler = (TDSTokenHandler)(paramSQLServerStatement.executedSqlDirectly ? new ClientCursorInitializer() : new ServerCursorInitializer(paramSQLServerStatement)); TDSParser.parse(paramSQLServerStatement.resultsReader(), tDSTokenHandler); this.columns = tDSTokenHandler.buildColumns(); this.rowCount = tDSTokenHandler.getRowCount();
    this.serverCursorId = tDSTokenHandler.getServerCursorId();
    this.tdsReader = (0 == this.serverCursorId) ? paramSQLServerStatement.resultsReader() : null;
    this.fetchBuffer = new FetchBuffer();
    this.scrollWindow = isForwardOnly() ? null : new ScrollWindow(this.fetchSize);
    this.numFetchedRows = 0;
    paramSQLServerStatement.incrResultSetCount();
    if (logger.isLoggable(Level.FINE))
      logger.fine(toString() + " created by (" + this.stmt.toString() + ")");  } void checkClosed() throws SQLServerException { if (this.isClosed) {
      SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, SQLServerException.getErrString("R_resultsetClosed"), (String)null, false);
    }
    
    this.stmt.checkClosed();



    
    if (null != this.rowErrorException)
      throw this.rowErrorException;  } public <T> T unwrap(Class<T> paramClass) throws SQLException { T t; loggerExternal.entering(getClassNameLogging(), "unwrap"); DriverJDBCVersion.checkSupportsJDBC4(); try {
      t = paramClass.cast(this);
    } catch (ClassCastException classCastException) {
      throw new SQLServerException(classCastException.getMessage(), classCastException);
    }  loggerExternal.exiting(getClassNameLogging(), "unwrap", t); return t; }
  public boolean isClosed() throws SQLException { DriverJDBCVersion.checkSupportsJDBC4();
    
    loggerExternal.entering(getClassNameLogging(), "isClosed");
    boolean bool = (this.isClosed || this.stmt.isClosed()) ? true : false;
    loggerExternal.exiting(getClassNameLogging(), "isClosed", Boolean.valueOf(bool));
    return bool; }








  
  private final void throwNotScrollable() throws SQLServerException {
    SQLServerException.makeFromDriverError(this.stmt.connection, this, SQLServerException.getErrString("R_requestedOpNotSupportedOnForward"), (String)null, true);
  }






  
  private final boolean isForwardOnly() {
    return (2003 == this.stmt.getSQLResultSetType() || 2004 == this.stmt.getSQLResultSetType());
  }



  
  private final boolean isDynamic() {
    return (0 != this.serverCursorId && 2 == this.stmt.getCursorType());
  }

  
  private final void verifyResultSetIsScrollable() throws SQLServerException {
    if (isForwardOnly()) {
      throwNotScrollable();
    }
  }






  
  private final void throwNotUpdatable() throws SQLServerException {
    SQLServerException.makeFromDriverError(this.stmt.connection, this, SQLServerException.getErrString("R_resultsetNotUpdatable"), (String)null, true);
  }






  
  private final void verifyResultSetIsUpdatable() throws SQLServerException {
    if (1007 == this.stmt.resultSetConcurrency || 0 == this.serverCursorId) {
      throwNotUpdatable();
    }
  }






  
  private boolean hasCurrentRow() {
    return (0 != this.currentRow && -1 != this.currentRow);
  }



















  
  private void verifyResultSetHasCurrentRow() throws SQLServerException {
    if (!hasCurrentRow())
    {
      SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_resultsetNoCurrentRow"), (String)null, true);
    }
  }












  
  private void verifyCurrentRowIsNotDeleted(String paramString) throws SQLServerException {
    if (currentRowDeleted())
    {
      SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString(paramString), (String)null, true);
    }
  }












  
  private void verifyValidColumnIndex(int paramInt) throws SQLServerException {
    int i = this.columns.length;



    
    if (0 != this.serverCursorId) {
      i--;
    }
    if (paramInt < 1 || paramInt > i) {
      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_indexOutOfRange"));
      Object[] arrayOfObject = { new Integer(paramInt) };
      SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, messageFormat.format(arrayOfObject), "07009", false);
    } 
  }








  
  private void verifyResultSetIsNotOnInsertRow() throws SQLServerException {
    if (this.isOnInsertRow)
    {
      SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_mustNotBeOnInsertRow"), (String)null, true);
    }
  }



  
  private final void throwUnsupportedCursorOp() throws SQLServerException {
    SQLServerException.makeFromDriverError(this.stmt.connection, this, SQLServerException.getErrString("R_unsupportedCursorOperation"), (String)null, true);
  }
















  
  private void closeInternal() {
    if (this.isClosed) {
      return;
    }
    
    this.isClosed = true;

    
    discardFetchBuffer();

    
    closeServerCursor();

    
    this.metaData = null;

    
    this.stmt.decrResultSetCount();
  }

  
  public void close() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "close");
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    closeInternal();
    loggerExternal.exiting(getClassNameLogging(), "close");
  }







  
  public int findColumn(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "findColumn", paramString);
    checkClosed();










    
    byte b;









    
    for (b = 0; b < this.columns.length; b++) {
      
      if (this.columns[b].getColumnName().equals(paramString)) {
        
        loggerExternal.exiting(getClassNameLogging(), "findColumn", Integer.valueOf(b + 1));
        return b + 1;
      } 
    } 




    
    for (b = 0; b < this.columns.length; b++) {
      
      if (this.columns[b].getColumnName().equalsIgnoreCase(paramString)) {
        
        loggerExternal.exiting(getClassNameLogging(), "findColumn", Integer.valueOf(b + 1));
        return b + 1;
      } 
    } 
    MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidColumnName"));
    Object[] arrayOfObject = { paramString };
    SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, messageFormat.format(arrayOfObject), "07009", false);

    
    return 0;
  }

  
  final int getColumnCount() {
    int i = this.columns.length;
    if (0 != this.serverCursorId)
      i--; 
    return i;
  }



  
  final Column getColumn(int paramInt) throws SQLServerException {
    if (null != this.activeStream) {
      
      try {
        
        this.activeStream.close();
      }
      catch (IOException iOException) {
        
        SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, iOException.getMessage(), (String)null, true);
      }
      finally {
        
        this.activeStream = null;
      } 
    }
    
    return this.columns[paramInt - 1];
  }









  
  private final void initializeNullCompressedColumns() throws SQLServerException {
    if (this.resultSetCurrentRowType.equals(RowType.NBCROW) && !this.areNullCompressedColumnsInitialized) {
      
      int i = 0;
      
      int j = (this.columns.length - 1 >> 3) + 1;
      for (byte b = 0; b < j; b++) {

        
        int k = this.tdsReader.readUnsignedByte();


        
        if (k == 0) {
          
          i += 8;
        }
        else {
          
          for (byte b1 = 0; b1 < 8 && i < this.columns.length; b1++) {
            
            if ((k & 1 << b1) != 0)
            {
              this.columns[i].initFromCompressedNull();
            }
            i++;
          } 
        } 
      }  this.areNullCompressedColumnsInitialized = true;
    } 
  }

  
  private final Column loadColumn(int paramInt) throws SQLServerException {
    assert 1 <= paramInt && paramInt <= this.columns.length;
    
    initializeNullCompressedColumns();


    
    if (paramInt > this.lastColumnIndex && !this.columns[paramInt - 1].isInitialized()) {
      skipColumns(paramInt - this.lastColumnIndex, false);
    }
    
    return getColumn(paramInt);
  }
  
  private void NotImplemented() throws SQLServerException {
    SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_notSupported"), (String)null, false);
  }






  
  public void clearWarnings() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "clearWarnings");
    loggerExternal.exiting(getClassNameLogging(), "clearWarnings");
  }



  
  private void moverInit() throws SQLServerException {
    cancelInsert();
    cancelUpdates();
  }

  
  public boolean relative(int paramInt) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "relative", Integer.valueOf(paramInt));
    }
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + " rows:" + paramInt + logCursorState());
    }
    checkClosed();



    
    verifyResultSetIsScrollable();
    verifyResultSetHasCurrentRow();
    
    moverInit();
    moveRelative(paramInt);
    boolean bool = hasCurrentRow();
    loggerExternal.exiting(getClassNameLogging(), "relative", Boolean.valueOf(bool));
    return bool;
  }


  
  private final void moveRelative(int paramInt) throws SQLServerException {
    assert hasCurrentRow();

    
    if (0 == paramInt) {
      return;
    }
    if (paramInt > 0) {
      moveForward(paramInt);
    } else {
      moveBackward(paramInt);
    } 
  }
  
  private final void moveForward(int paramInt) throws SQLServerException {
    assert hasCurrentRow();
    assert paramInt > 0;

    
    if (this.scrollWindow.getRow() + paramInt <= this.scrollWindow.getMaxRows()) {
      
      byte b = 0;
      while (paramInt > 0 && this.scrollWindow.next(this)) {
        
        b++;
        paramInt--;
      } 

      
      updateCurrentRow(b);

      
      if (0 == paramInt) {
        return;
      }
    } 
    
    assert paramInt > 0;


    
    if (0 == this.serverCursorId) {
      
      assert -2 != this.currentRow;
      this.currentRow = clientMoveAbsolute(this.currentRow + paramInt);





      
      return;
    } 





    
    if (1 == paramInt) {
      doServerFetch(2, 0, this.fetchSize);
    } else {
      doServerFetch(32, paramInt + this.scrollWindow.getRow() - 1, this.fetchSize);
    } 
    
    if (!this.scrollWindow.next(this)) {
      
      this.currentRow = -1;
      
      return;
    } 
    
    updateCurrentRow(paramInt);
  }

  
  private final void moveBackward(int paramInt) throws SQLServerException {
    assert hasCurrentRow();
    assert paramInt < 0;

    
    if (this.scrollWindow.getRow() + paramInt >= 1) {
      
      for (byte b = 0; b > paramInt; b--) {
        this.scrollWindow.previous(this);
      }
      updateCurrentRow(paramInt);


      
      return;
    } 

    
    if (0 == this.serverCursorId) {
      
      assert -2 != this.currentRow;


      
      if (this.currentRow + paramInt < 1) {
        
        moveBeforeFirst();
      }
      else {
        
        this.currentRow = clientMoveAbsolute(this.currentRow + paramInt);
      } 









      
      return;
    } 









    
    if (-1 == paramInt) {
      
      doServerFetch(512, 0, this.fetchSize);

      
      if (!this.scrollWindow.next(this)) {
        
        this.currentRow = 0;
        
        return;
      } 
      
      while (this.scrollWindow.next(this));


      
      this.scrollWindow.previous(this);
    }
    else {
      
      doServerFetch(32, paramInt + this.scrollWindow.getRow() - 1, this.fetchSize);

      
      if (!this.scrollWindow.next(this)) {
        
        this.currentRow = 0;
        
        return;
      } 
    } 
    
    updateCurrentRow(paramInt);
  }







  
  private final void updateCurrentRow(int paramInt) {
    if (-2 != this.currentRow) {
      
      assert this.currentRow >= 1;
      this.currentRow += paramInt;
      assert this.currentRow >= 1;
    } 
  }








  
  public boolean next() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "next");
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + logCursorState());
    }
    checkClosed();
    
    moverInit();


    
    if (-1 == this.currentRow) {
      
      loggerExternal.exiting(getClassNameLogging(), "next", Boolean.valueOf(false));
      return false;
    } 

    
    if (!isForwardOnly()) {
      
      if (0 == this.currentRow) {
        moveFirst();
      } else {
        moveForward(1);
      }  boolean bool = hasCurrentRow();
      loggerExternal.exiting(getClassNameLogging(), "next", Boolean.valueOf(bool));
      return bool;
    } 




    
    if (0 != this.serverCursorId && this.maxRows > 0)
    {
      if (this.currentRow == this.maxRows) {
        
        this.currentRow = -1;
        loggerExternal.exiting(getClassNameLogging(), "next", Boolean.valueOf(false));
        return false;
      } 
    }


    
    if (fetchBufferNext()) {



      
      if (0 == this.currentRow) {
        this.currentRow = 1;
      } else {
        updateCurrentRow(1);
      } 


      
      assert 0 == this.maxRows || this.currentRow <= this.maxRows;
      loggerExternal.exiting(getClassNameLogging(), "next", Boolean.valueOf(true));
      
      return true;
    } 



    
    if (0 != this.serverCursorId) {
      
      doServerFetch(2, 0, this.fetchSize);


      
      if (fetchBufferNext()) {
        
        if (0 == this.currentRow) {
          this.currentRow = 1;
        } else {
          updateCurrentRow(1);
        } 
        assert 0 == this.maxRows || this.currentRow <= this.maxRows;
        loggerExternal.exiting(getClassNameLogging(), "next", Boolean.valueOf(true));
        return true;
      } 
    } 

    
    if (-3 == this.rowCount) {
      this.rowCount = this.currentRow;
    }
    this.currentRow = -1;
    loggerExternal.exiting(getClassNameLogging(), "next", Boolean.valueOf(false));
    return false;
  }

  
  public boolean wasNull() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "wasNull");
    checkClosed();
    loggerExternal.exiting(getClassNameLogging(), "wasNull", Boolean.valueOf(this.lastValueWasNull));
    return this.lastValueWasNull;
  }





  
  public boolean isBeforeFirst() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "isBeforeFirst");
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + logCursorState());
    }
    checkClosed();







    
    if (0 != this.serverCursorId)
    {
      switch (this.stmt.getCursorType()) {
        
        case 4:
          throwNotScrollable();
          break;
        
        case 2:
          throwUnsupportedCursorOp();
          break;



        
        case 16:
          throwNotScrollable();
          break;
      } 





    
    }
    if (this.isOnInsertRow) {
      return false;
    }

    
    if (0 != this.currentRow) {
      return false;
    }




    
    if (0 == this.serverCursorId) {
      return fetchBufferHasRows();
    }


    
    assert this.rowCount >= 0;
    boolean bool = (this.rowCount > 0) ? true : false;
    loggerExternal.exiting(getClassNameLogging(), "isBeforeFirst", Boolean.valueOf(bool));
    return bool;
  }

  
  public boolean isAfterLast() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "isAfterLast");
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + logCursorState());
    }
    checkClosed();





    
    if (0 != this.serverCursorId) {
      
      verifyResultSetIsScrollable();



      
      if (2 == this.stmt.getCursorType() && !isForwardOnly()) {
        throwUnsupportedCursorOp();
      }
    } 
    
    if (this.isOnInsertRow) {
      return false;
    }

    
    assert -1 != this.currentRow || -3 != this.rowCount;
    
    boolean bool = (-1 == this.currentRow && this.rowCount > 0) ? true : false;
    loggerExternal.exiting(getClassNameLogging(), "isAfterLast", Boolean.valueOf(bool));
    return bool;
  }














  
  public boolean isFirst() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "isFirst");
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + logCursorState());
    }
    checkClosed();


    
    verifyResultSetIsScrollable();


    
    if (isDynamic()) {
      throwUnsupportedCursorOp();
    }
    
    if (this.isOnInsertRow) {
      return false;
    }

    
    assert -2 != this.currentRow;

    
    boolean bool = (1 == this.currentRow) ? true : false;
    loggerExternal.exiting(getClassNameLogging(), "isFirst", Boolean.valueOf(bool));
    return bool;
  }














  
  public boolean isLast() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "isLast");
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + logCursorState());
    }
    checkClosed();


    
    verifyResultSetIsScrollable();


    
    if (isDynamic()) {
      throwUnsupportedCursorOp();
    }
    
    if (this.isOnInsertRow) {
      return false;
    }

    
    if (!hasCurrentRow()) {
      return false;
    }
    
    assert this.currentRow >= 1;

    
    if (-3 != this.rowCount) {
      
      assert this.currentRow <= this.rowCount;
      return (this.currentRow == this.rowCount);
    } 




    
    assert 0 == this.serverCursorId;





    
    boolean bool = !next() ? true : false;
    previous();
    loggerExternal.exiting(getClassNameLogging(), "isLast", Boolean.valueOf(bool));
    return bool;
  }

  
  public void beforeFirst() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "beforeFirst");
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + logCursorState());
    }
    checkClosed();


    
    verifyResultSetIsScrollable();
    
    moverInit();
    moveBeforeFirst();
    loggerExternal.exiting(getClassNameLogging(), "beforeFirst");
  }

  
  private final void moveBeforeFirst() throws SQLServerException {
    if (0 == this.serverCursorId) {
      
      fetchBufferBeforeFirst();
      this.scrollWindow.clear();
    }
    else {
      
      doServerFetch(1, 0, 0);
    } 
    
    this.currentRow = 0;
  }

  
  public void afterLast() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "afterLast");
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + logCursorState());
    }
    checkClosed();


    
    verifyResultSetIsScrollable();
    
    moverInit();
    moveAfterLast();
    loggerExternal.exiting(getClassNameLogging(), "afterLast");
  }

  
  private void moveAfterLast() throws SQLServerException {
    assert !isForwardOnly();
    
    if (0 == this.serverCursorId) {
      clientMoveAfterLast();
    } else {
      doServerFetch(8, 0, 0);
    } 
    this.currentRow = -1;
  }














  
  public boolean first() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "first");
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + logCursorState());
    }
    checkClosed();


    
    verifyResultSetIsScrollable();
    
    moverInit();
    moveFirst();
    boolean bool = hasCurrentRow();
    loggerExternal.exiting(getClassNameLogging(), "first", Boolean.valueOf(bool));
    return bool;
  }

  
  private final void moveFirst() throws SQLServerException {
    if (0 == this.serverCursorId) {
      
      moveBeforeFirst();
    
    }
    else {
      
      doServerFetch(1, 0, this.fetchSize);
    } 

    
    if (!this.scrollWindow.next(this)) {





      
      this.currentRow = -1;
      
      return;
    } 
    
    this.currentRow = isDynamic() ? -2 : 1;
  }














  
  public boolean last() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "last");
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + logCursorState());
    }
    checkClosed();


    
    verifyResultSetIsScrollable();
    
    moverInit();
    moveLast();
    boolean bool = hasCurrentRow();
    loggerExternal.exiting(getClassNameLogging(), "last", Boolean.valueOf(bool));
    return bool;
  }

  
  private final void moveLast() throws SQLServerException {
    if (0 == this.serverCursorId) {
      
      this.currentRow = clientMoveAbsolute(-1);
      
      return;
    } 
    
    doServerFetch(8, 0, this.fetchSize);

    
    if (!this.scrollWindow.next(this)) {





      
      this.currentRow = -1;
      
      return;
    } 
    
    while (this.scrollWindow.next(this));
    
    this.scrollWindow.previous(this);

    
    this.currentRow = isDynamic() ? -2 : this.rowCount;
  }







  
  public int getRow() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getRow");
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + logCursorState());
    }
    checkClosed();


    
    if (isDynamic() && !isForwardOnly()) {
      throwUnsupportedCursorOp();
    }




    
    if (!hasCurrentRow() || this.isOnInsertRow) {
      return 0;
    }
    
    assert this.currentRow >= 1;

    
    loggerExternal.exiting(getClassNameLogging(), "getRow", Integer.valueOf(this.currentRow));
    return this.currentRow;
  }















  
  public boolean absolute(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "absolute");
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + " row:" + paramInt + logCursorState());
    }
    checkClosed();


    
    verifyResultSetIsScrollable();


    
    if (isDynamic()) {
      throwUnsupportedCursorOp();
    }
    moverInit();
    moveAbsolute(paramInt);
    boolean bool = hasCurrentRow();
    loggerExternal.exiting(getClassNameLogging(), "absolute", Boolean.valueOf(bool));
    return bool;
  }



  
  private void moveAbsolute(int paramInt) throws SQLServerException {
    assert -2 != this.currentRow;
    assert !isDynamic();
    
    switch (paramInt) {

      
      case 0:
        moveBeforeFirst();
        return;

      
      case 1:
        moveFirst();
        return;

      
      case -1:
        moveLast();
        return;
    } 





    
    if (hasCurrentRow()) {
      
      assert this.currentRow >= 1;




      
      if (paramInt > 0) {
        
        moveRelative(paramInt - this.currentRow);


        
        return;
      } 

      
      if (-3 != this.rowCount) {
        
        assert paramInt < 0;
        moveRelative(this.rowCount + paramInt + 1 - this.currentRow);



        
        return;
      } 
    } 



    
    if (0 == this.serverCursorId) {
      
      this.currentRow = clientMoveAbsolute(paramInt);
      
      return;
    } 
    doServerFetch(16, paramInt, this.fetchSize);


    
    if (!this.scrollWindow.next(this)) {
      
      this.currentRow = (paramInt < 0) ? 0 : -1;

      
      return;
    } 
    
    if (paramInt > 0) {

      
      this.currentRow = paramInt;
    
    }
    else {
      
      assert paramInt < 0;
      assert this.rowCount + paramInt + 1 >= 1;
      this.currentRow = this.rowCount + paramInt + 1;
    } 
  }



  
  private final boolean fetchBufferHasRows() throws SQLServerException {
    assert 0 == this.serverCursorId;
    assert null != this.tdsReader;
    
    assert this.lastColumnIndex >= 0;

    
    if (this.lastColumnIndex >= 1) {
      return true;
    }

    
    int i = this.tdsReader.peekTokenType();





    
    return (209 == i || 210 == i || 171 == i || 170 == i);
  }




  
  final void discardCurrentRow() throws SQLServerException {
    assert this.lastColumnIndex >= 0;
    
    this.updatedCurrentRow = false;
    this.deletedCurrentRow = false;
    if (this.lastColumnIndex >= 1) {
      
      initializeNullCompressedColumns();
      
      for (byte b = 1; b < this.lastColumnIndex; b++) {
        getColumn(b).clear();
      }

      
      skipColumns(this.columns.length + 1 - this.lastColumnIndex, true);
    } 

    
    this.resultSetCurrentRowType = RowType.UNKNOWN;
    this.areNullCompressedColumnsInitialized = false;
  }

  
  final int fetchBufferGetRow() {
    if (isForwardOnly()) {
      return this.numFetchedRows;
    }
    return this.scrollWindow.getRow();
  }



  
  final void fetchBufferBeforeFirst() throws SQLServerException {
    assert 0 == this.serverCursorId;
    assert null != this.tdsReader;
    
    discardCurrentRow();
    
    this.fetchBuffer.reset();
    this.lastColumnIndex = 0;
  }


  
  final TDSReaderMark fetchBufferMark() {
    assert null != this.tdsReader;
    
    return this.tdsReader.mark();
  }


  
  final void fetchBufferReset(TDSReaderMark paramTDSReaderMark) throws SQLServerException {
    assert null != this.tdsReader;
    
    assert null != paramTDSReaderMark;
    
    discardCurrentRow();
    
    this.tdsReader.reset(paramTDSReaderMark);
    
    this.lastColumnIndex = 1;
  }


  
  final boolean fetchBufferNext() throws SQLServerException {
    if (null == this.tdsReader) {
      return false;
    }
    
    discardCurrentRow();


    
    RowType rowType = RowType.UNKNOWN;
    
    try {
      rowType = this.fetchBuffer.nextRow();
      if (rowType.equals(RowType.UNKNOWN)) {
        return false;
      }
    } catch (SQLServerException sQLServerException) {
      
      this.currentRow = -1;
      this.rowErrorException = sQLServerException;
      throw sQLServerException;
    }
    finally {
      
      this.lastColumnIndex = 0;
      this.resultSetCurrentRowType = rowType;
    } 

    
    this.numFetchedRows++;
    this.lastColumnIndex = 1;
    return true;
  }

  
  private final void clientMoveAfterLast() throws SQLServerException {
    assert -2 != this.currentRow;
    
    byte b = 0;
    while (fetchBufferNext()) {
      b++;
    }
    if (-3 == this.rowCount) {
      
      assert -1 != this.currentRow;
      this.rowCount = ((0 == this.currentRow) ? 0 : this.currentRow) + b;
    } 
  }

  
  private final int clientMoveAbsolute(int paramInt) throws SQLServerException {
    assert 0 == this.serverCursorId;
    
    this.scrollWindow.clear();





    
    if (paramInt < 0) {




      
      if (-3 == this.rowCount) {
        
        clientMoveAfterLast();
        this.currentRow = -1;
      } 


      
      assert this.rowCount >= 0;


      
      if (this.rowCount + paramInt < 0) {
        
        moveBeforeFirst();
        return 0;
      } 
      
      paramInt = this.rowCount + paramInt + 1;
    } 




    
    assert paramInt > 0;




    
    if (-1 == this.currentRow || paramInt <= this.currentRow) {
      moveBeforeFirst();
    }

    
    assert 0 == this.currentRow || this.currentRow < paramInt;
    while (this.currentRow != paramInt) {
      
      if (!fetchBufferNext()) {
        
        if (-3 == this.rowCount)
          this.rowCount = this.currentRow; 
        return -1;
      } 



      
      if (0 == this.currentRow) {
        this.currentRow = 1; continue;
      } 
      updateCurrentRow(1);
    } 
    
    return paramInt;
  }














  
  public boolean previous() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "previous");
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + logCursorState());
    }
    checkClosed();


    
    verifyResultSetIsScrollable();
    
    moverInit();
    
    if (0 == this.currentRow) {
      return false;
    }
    if (-1 == this.currentRow) {
      moveLast();
    } else {
      moveBackward(-1);
    } 
    boolean bool = hasCurrentRow();
    loggerExternal.exiting(getClassNameLogging(), "previous", Boolean.valueOf(bool));
    return bool;
  }

  
  private final void cancelInsert() {
    if (this.isOnInsertRow) {
      
      this.isOnInsertRow = false;
      clearColumnsValues();
    } 
  }


  
  final void clearColumnsValues() {
    int i = this.columns.length;
    for (byte b = 0; b < i; b++) {
      this.columns[b].cancelUpdates();
    }
  }
  
  public SQLWarning getWarnings() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getWarnings");
    loggerExternal.exiting(getClassNameLogging(), "getWarnings", null);
    return null;
  }

  
  public void setFetchDirection(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "setFetchDirection", Integer.valueOf(paramInt));
    checkClosed();


    
    verifyResultSetIsScrollable();
    
    if ((1000 != paramInt && 1001 != paramInt && 1002 != paramInt) || (1000 != paramInt && (2003 == this.stmt.resultSetType || 2004 == this.stmt.resultSetType))) {






      
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidFetchDirection"));
      Object[] arrayOfObject = { new Integer(paramInt) };
      SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, messageFormat.format(arrayOfObject), (String)null, false);
    } 
    
    this.fetchDirection = paramInt;
    loggerExternal.exiting(getClassNameLogging(), "setFetchDirection");
  }

  
  public int getFetchDirection() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getFetchDirection");
    checkClosed();
    loggerExternal.exiting(getClassNameLogging(), "getFetchDirection", Integer.valueOf(this.fetchDirection));
    return this.fetchDirection;
  }

  
  public void setFetchSize(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "setFetchSize", Integer.valueOf(paramInt));
    checkClosed();
    if (paramInt < 0) {
      SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_invalidFetchSize"), (String)null, false);
    }
    this.fetchSize = (0 == paramInt) ? this.stmt.defaultFetchSize : paramInt;
    loggerExternal.exiting(getClassNameLogging(), "setFetchSize");
  }
  
  public int getFetchSize() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getFetchSize");
    checkClosed();
    loggerExternal.exiting(getClassNameLogging(), "getFloat", Integer.valueOf(this.fetchSize));
    return this.fetchSize;
  }
  
  public int getType() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getType");
    checkClosed();
    
    int i = this.stmt.getResultSetType();
    loggerExternal.exiting(getClassNameLogging(), "getType", Integer.valueOf(i));
    return i;
  }

  
  public int getConcurrency() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getConcurrency");
    checkClosed();
    int i = this.stmt.getResultSetConcurrency();
    loggerExternal.exiting(getClassNameLogging(), "getConcurrency", Integer.valueOf(i));
    return i;
  }



















  
  Column getterGetColumn(int paramInt) throws SQLServerException {
    verifyResultSetHasCurrentRow();
    verifyCurrentRowIsNotDeleted("R_cantGetColumnValueFromDeletedRow");
    verifyValidColumnIndex(paramInt);

    
    if (this.updatedCurrentRow) {
      
      doRefreshRow();
      verifyResultSetHasCurrentRow();
    } 

    
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + " Getting Column:" + paramInt);
    }
    return loadColumn(paramInt);
  }

  
  private final Object getValue(int paramInt, JDBCType paramJDBCType) throws SQLServerException {
    return getValue(paramInt, paramJDBCType, null, null);
  }

  
  private final Object getValue(int paramInt, JDBCType paramJDBCType, Calendar paramCalendar) throws SQLServerException {
    return getValue(paramInt, paramJDBCType, null, paramCalendar);
  }

  
  private final Object getValue(int paramInt, JDBCType paramJDBCType, InputStreamGetterArgs paramInputStreamGetterArgs) throws SQLServerException {
    return getValue(paramInt, paramJDBCType, paramInputStreamGetterArgs, null);
  }

  
  private final Object getValue(int paramInt, JDBCType paramJDBCType, InputStreamGetterArgs paramInputStreamGetterArgs, Calendar paramCalendar) throws SQLServerException {
    Object object = getterGetColumn(paramInt).getValue(paramJDBCType, paramInputStreamGetterArgs, paramCalendar, this.tdsReader);
    this.lastValueWasNull = (null == object);
    return object;
  }

  
  private Object getStream(int paramInt, StreamType paramStreamType) throws SQLServerException {
    Object object = getValue(paramInt, paramStreamType.getJDBCType(), new InputStreamGetterArgs(paramStreamType, this.stmt.getExecProps().isResponseBufferingAdaptive(), isForwardOnly(), toString()));







    
    this.activeStream = (Closeable)object;
    return object;
  }
  
  private SQLXML getSQLXMLInternal(int paramInt) throws SQLServerException {
    SQLServerSQLXML sQLServerSQLXML = (SQLServerSQLXML)getValue(paramInt, JDBCType.SQLXML, new InputStreamGetterArgs(StreamType.SQLXML, this.stmt.getExecProps().isResponseBufferingAdaptive(), isForwardOnly(), toString()));







    
    if (null != sQLServerSQLXML)
      this.activeStream = sQLServerSQLXML.getStream(); 
    return sQLServerSQLXML;
  }


  
  public InputStream getAsciiStream(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getAsciiStream", Integer.valueOf(paramInt));
    checkClosed();
    InputStream inputStream = (InputStream)getStream(paramInt, StreamType.ASCII);
    loggerExternal.exiting(getClassNameLogging(), "getAsciiStream", inputStream);
    return inputStream;
  }

  
  public InputStream getAsciiStream(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getAsciiStream", paramString);
    checkClosed();
    InputStream inputStream = (InputStream)getStream(findColumn(paramString), StreamType.ASCII);
    loggerExternal.exiting(getClassNameLogging(), "getAsciiStream", inputStream);
    return inputStream;
  }
  
  @Deprecated
  public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getBigDecimal", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) }); 
    checkClosed();
    BigDecimal bigDecimal = (BigDecimal)getValue(paramInt1, JDBCType.DECIMAL);
    if (null != bigDecimal)
      bigDecimal = bigDecimal.setScale(paramInt2, 1); 
    loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", bigDecimal);
    return bigDecimal;
  }
  
  @Deprecated
  public BigDecimal getBigDecimal(String paramString, int paramInt) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "columnName", new Object[] { paramString, Integer.valueOf(paramInt) }); 
    checkClosed();
    BigDecimal bigDecimal = (BigDecimal)getValue(findColumn(paramString), JDBCType.DECIMAL);
    if (null != bigDecimal)
      bigDecimal = bigDecimal.setScale(paramInt, 1); 
    loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", bigDecimal);
    return bigDecimal;
  }

  
  public InputStream getBinaryStream(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getBinaryStream", Integer.valueOf(paramInt));
    checkClosed();
    InputStream inputStream = (InputStream)getStream(paramInt, StreamType.BINARY);
    loggerExternal.exiting(getClassNameLogging(), "getBinaryStream", inputStream);
    return inputStream;
  }

  
  public InputStream getBinaryStream(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getBinaryStream", paramString);
    checkClosed();
    InputStream inputStream = (InputStream)getStream(findColumn(paramString), StreamType.BINARY);
    loggerExternal.exiting(getClassNameLogging(), "getBinaryStream", inputStream);
    return inputStream;
  }

  
  public boolean getBoolean(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getBoolean", Integer.valueOf(paramInt));
    checkClosed();
    Boolean bool = (Boolean)getValue(paramInt, JDBCType.BIT);
    loggerExternal.exiting(getClassNameLogging(), "getBoolean", bool);
    return (null != bool) ? bool.booleanValue() : false;
  }

  
  public boolean getBoolean(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getBoolean", paramString);
    checkClosed();
    Boolean bool = (Boolean)getValue(findColumn(paramString), JDBCType.BIT);
    loggerExternal.exiting(getClassNameLogging(), "getBoolean", bool);
    return (null != bool) ? bool.booleanValue() : false;
  }

  
  public byte getByte(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getByte", Integer.valueOf(paramInt));
    checkClosed();
    Short short_ = (Short)getValue(paramInt, JDBCType.TINYINT);
    loggerExternal.exiting(getClassNameLogging(), "getByte", short_);
    return (null != short_) ? short_.byteValue() : 0;
  }

  
  public byte getByte(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getByte", paramString);
    checkClosed();
    Short short_ = (Short)getValue(findColumn(paramString), JDBCType.TINYINT);
    loggerExternal.exiting(getClassNameLogging(), "getByte", short_);
    return (null != short_) ? short_.byteValue() : 0;
  }

  
  public byte[] getBytes(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getBytes", Integer.valueOf(paramInt));
    checkClosed();
    byte[] arrayOfByte = (byte[])getValue(paramInt, JDBCType.BINARY);
    loggerExternal.exiting(getClassNameLogging(), "getBytes", arrayOfByte);
    return arrayOfByte;
  }

  
  public byte[] getBytes(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getBytes", paramString);
    checkClosed();
    byte[] arrayOfByte = (byte[])getValue(findColumn(paramString), JDBCType.BINARY);
    loggerExternal.exiting(getClassNameLogging(), "getBytes", arrayOfByte);
    return arrayOfByte;
  }

  
  public Date getDate(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getDate", Integer.valueOf(paramInt));
    checkClosed();
    Date date = (Date)getValue(paramInt, JDBCType.DATE);
    loggerExternal.exiting(getClassNameLogging(), "getDate", date);
    return date;
  }

  
  public Date getDate(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getDate", paramString);
    checkClosed();
    Date date = (Date)getValue(findColumn(paramString), JDBCType.DATE);
    loggerExternal.exiting(getClassNameLogging(), "getDate", date);
    return date;
  }

  
  public Date getDate(int paramInt, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getDate", new Object[] { Integer.valueOf(paramInt), paramCalendar }); 
    checkClosed();
    Date date = (Date)getValue(paramInt, JDBCType.DATE, paramCalendar);
    loggerExternal.exiting(getClassNameLogging(), "getDate", date);
    return date;
  }

  
  public Date getDate(String paramString, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getDate", new Object[] { paramString, paramCalendar }); 
    checkClosed();
    Date date = (Date)getValue(findColumn(paramString), JDBCType.DATE, paramCalendar);
    loggerExternal.exiting(getClassNameLogging(), "getDate", date);
    return date;
  }

  
  public double getDouble(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getDouble", Integer.valueOf(paramInt));
    checkClosed();
    Double double_ = (Double)getValue(paramInt, JDBCType.DOUBLE);
    loggerExternal.exiting(getClassNameLogging(), "getDouble", double_);
    return (null != double_) ? double_.doubleValue() : 0.0D;
  }

  
  public double getDouble(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getDouble", paramString);
    checkClosed();
    Double double_ = (Double)getValue(findColumn(paramString), JDBCType.DOUBLE);
    loggerExternal.exiting(getClassNameLogging(), "getDouble", double_);
    return (null != double_) ? double_.doubleValue() : 0.0D;
  }

  
  public float getFloat(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getFloat", Integer.valueOf(paramInt));
    checkClosed();
    Float float_ = (Float)getValue(paramInt, JDBCType.REAL);
    loggerExternal.exiting(getClassNameLogging(), "getFloat", float_);
    return (null != float_) ? float_.floatValue() : 0.0F;
  }

  
  public float getFloat(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getFloat", paramString);
    checkClosed();
    Float float_ = (Float)getValue(findColumn(paramString), JDBCType.REAL);
    loggerExternal.exiting(getClassNameLogging(), "getFloat", float_);
    return (null != float_) ? float_.floatValue() : 0.0F;
  }

  
  public int getInt(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getInt", Integer.valueOf(paramInt));
    checkClosed();
    Integer integer = (Integer)getValue(paramInt, JDBCType.INTEGER);
    loggerExternal.exiting(getClassNameLogging(), "getInt", integer);
    return (null != integer) ? integer.intValue() : 0;
  }

  
  public int getInt(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getInt", paramString);
    checkClosed();
    Integer integer = (Integer)getValue(findColumn(paramString), JDBCType.INTEGER);
    loggerExternal.exiting(getClassNameLogging(), "getInt", integer);
    return (null != integer) ? integer.intValue() : 0;
  }

  
  public long getLong(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getLong", Integer.valueOf(paramInt));
    checkClosed();
    Long long_ = (Long)getValue(paramInt, JDBCType.BIGINT);
    loggerExternal.exiting(getClassNameLogging(), "getLong", long_);
    return (null != long_) ? long_.longValue() : 0L;
  }

  
  public long getLong(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getLong", paramString);
    checkClosed();
    Long long_ = (Long)getValue(findColumn(paramString), JDBCType.BIGINT);
    loggerExternal.exiting(getClassNameLogging(), "getLong", long_);
    return (null != long_) ? long_.longValue() : 0L;
  }

  
  public ResultSetMetaData getMetaData() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getMetaData");
    checkClosed();
    if (this.metaData == null)
      this.metaData = new SQLServerResultSetMetaData(this.stmt.connection, this); 
    loggerExternal.exiting(getClassNameLogging(), "getMetaData", this.metaData);
    return this.metaData;
  }

  
  public Object getObject(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getObject", Integer.valueOf(paramInt));
    checkClosed();
    Object object = getValue(paramInt, getterGetColumn(paramInt).getTypeInfo().getSSType().getJDBCType());
    loggerExternal.exiting(getClassNameLogging(), "getObject", object);
    return object;
  }

  
  public <T> T getObject(int paramInt, Class<T> paramClass) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC41();

    
    throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
  }

  
  public Object getObject(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getObject", paramString);
    checkClosed();
    Object object = getObject(findColumn(paramString));
    loggerExternal.exiting(getClassNameLogging(), "getObject", object);
    return object;
  }

  
  public <T> T getObject(String paramString, Class<T> paramClass) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC41();

    
    throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
  }

  
  public short getShort(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getShort", Integer.valueOf(paramInt));
    checkClosed();
    Short short_ = (Short)getValue(paramInt, JDBCType.SMALLINT);
    loggerExternal.exiting(getClassNameLogging(), "getShort", short_);
    return (null != short_) ? short_.shortValue() : 0;
  }

  
  public short getShort(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getShort", paramString);
    checkClosed();
    Short short_ = (Short)getValue(findColumn(paramString), JDBCType.SMALLINT);
    loggerExternal.exiting(getClassNameLogging(), "getShort", short_);
    return (null != short_) ? short_.shortValue() : 0;
  }

  
  public String getString(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getString", Integer.valueOf(paramInt));
    checkClosed();
    
    String str = null;
    Object object = getValue(paramInt, JDBCType.CHAR);
    if (null != object) {
      str = object.toString();
    }
    loggerExternal.exiting(getClassNameLogging(), "getString", str);
    return str;
  }

  
  public String getString(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getString", paramString);
    checkClosed();
    
    String str = null;
    Object object = getValue(findColumn(paramString), JDBCType.CHAR);
    if (null != object) {
      str = object.toString();
    }
    loggerExternal.exiting(getClassNameLogging(), "getString", str);
    return str;
  }

  
  public String getNString(int paramInt) throws SQLException {
    loggerExternal.entering(getClassNameLogging(), "getNString", Integer.valueOf(paramInt));
    DriverJDBCVersion.checkSupportsJDBC4();
    checkClosed();
    String str = (String)getValue(paramInt, JDBCType.NCHAR);
    loggerExternal.exiting(getClassNameLogging(), "getNString", str);
    return str;
  }

  
  public String getNString(String paramString) throws SQLException {
    loggerExternal.entering(getClassNameLogging(), "getNString", paramString);
    DriverJDBCVersion.checkSupportsJDBC4();
    checkClosed();
    String str = (String)getValue(findColumn(paramString), JDBCType.NCHAR);
    loggerExternal.exiting(getClassNameLogging(), "getNString", str);
    return str;
  }

  
  public String getUniqueIdentifier(int paramInt) throws SQLException {
    loggerExternal.entering(getClassNameLogging(), "getUniqueIdentifier", Integer.valueOf(paramInt));
    checkClosed();
    String str = (String)getValue(paramInt, JDBCType.GUID);
    loggerExternal.exiting(getClassNameLogging(), "getUniqueIdentifier", str);
    return str;
  }

  
  public String getUniqueIdentifier(String paramString) throws SQLException {
    loggerExternal.entering(getClassNameLogging(), "getUniqueIdentifier", paramString);
    checkClosed();
    String str = (String)getValue(findColumn(paramString), JDBCType.GUID);
    loggerExternal.exiting(getClassNameLogging(), "getUniqueIdentifier", str);
    return str;
  }

  
  public Time getTime(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getTime", Integer.valueOf(paramInt));
    checkClosed();
    Time time = (Time)getValue(paramInt, JDBCType.TIME);
    loggerExternal.exiting(getClassNameLogging(), "getTime", time);
    return time;
  }

  
  public Time getTime(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getTime", paramString);
    checkClosed();
    Time time = (Time)getValue(findColumn(paramString), JDBCType.TIME);
    loggerExternal.exiting(getClassNameLogging(), "getTime", time);
    return time;
  }

  
  public Time getTime(int paramInt, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getTime", new Object[] { Integer.valueOf(paramInt), paramCalendar }); 
    checkClosed();
    Time time = (Time)getValue(paramInt, JDBCType.TIME, paramCalendar);
    loggerExternal.exiting(getClassNameLogging(), "getTime", time);
    return time;
  }

  
  public Time getTime(String paramString, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getTime", new Object[] { paramString, paramCalendar }); 
    checkClosed();
    Time time = (Time)getValue(findColumn(paramString), JDBCType.TIME, paramCalendar);
    loggerExternal.exiting(getClassNameLogging(), "getTime", time);
    return time;
  }

  
  public Timestamp getTimestamp(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getTimestamp", Integer.valueOf(paramInt));
    checkClosed();
    Timestamp timestamp = (Timestamp)getValue(paramInt, JDBCType.TIMESTAMP);
    loggerExternal.exiting(getClassNameLogging(), "getTimestamp", timestamp);
    return timestamp;
  }

  
  public Timestamp getTimestamp(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getTimestamp", paramString);
    checkClosed();
    Timestamp timestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.TIMESTAMP);
    loggerExternal.exiting(getClassNameLogging(), "getTimestamp", timestamp);
    return timestamp;
  }

  
  public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getTimestamp", new Object[] { Integer.valueOf(paramInt), paramCalendar }); 
    checkClosed();
    Timestamp timestamp = (Timestamp)getValue(paramInt, JDBCType.TIMESTAMP, paramCalendar);
    loggerExternal.exiting(getClassNameLogging(), "getTimeStamp", timestamp);
    return timestamp;
  }

  
  public Timestamp getTimestamp(String paramString, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getTimestamp", new Object[] { paramString, paramCalendar }); 
    checkClosed();
    Timestamp timestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.TIMESTAMP, paramCalendar);
    loggerExternal.exiting(getClassNameLogging(), "getTimestamp", timestamp);
    return timestamp;
  }

  
  public Timestamp getDateTime(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getDateTime", Integer.valueOf(paramInt));
    checkClosed();
    Timestamp timestamp = (Timestamp)getValue(paramInt, JDBCType.TIMESTAMP);
    loggerExternal.exiting(getClassNameLogging(), "getDateTime", timestamp);
    return timestamp;
  }

  
  public Timestamp getDateTime(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getDateTime", paramString);
    checkClosed();
    Timestamp timestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.TIMESTAMP);
    loggerExternal.exiting(getClassNameLogging(), "getDateTime", timestamp);
    return timestamp;
  }

  
  public Timestamp getDateTime(int paramInt, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getDateTime", new Object[] { Integer.valueOf(paramInt), paramCalendar }); 
    checkClosed();
    Timestamp timestamp = (Timestamp)getValue(paramInt, JDBCType.TIMESTAMP, paramCalendar);
    loggerExternal.exiting(getClassNameLogging(), "getDateTime", timestamp);
    return timestamp;
  }

  
  public Timestamp getDateTime(String paramString, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getDateTime", new Object[] { paramString, paramCalendar }); 
    checkClosed();
    Timestamp timestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.TIMESTAMP, paramCalendar);
    loggerExternal.exiting(getClassNameLogging(), "getDateTime", timestamp);
    return timestamp;
  }

  
  public Timestamp getSmallDateTime(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getSmallDateTime", Integer.valueOf(paramInt));
    checkClosed();
    Timestamp timestamp = (Timestamp)getValue(paramInt, JDBCType.TIMESTAMP);
    loggerExternal.exiting(getClassNameLogging(), "getSmallDateTime", timestamp);
    return timestamp;
  }

  
  public Timestamp getSmallDateTime(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getSmallDateTime", paramString);
    checkClosed();
    Timestamp timestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.TIMESTAMP);
    loggerExternal.exiting(getClassNameLogging(), "getSmallDateTime", timestamp);
    return timestamp;
  }

  
  public Timestamp getSmallDateTime(int paramInt, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getSmallDateTime", new Object[] { Integer.valueOf(paramInt), paramCalendar }); 
    checkClosed();
    Timestamp timestamp = (Timestamp)getValue(paramInt, JDBCType.TIMESTAMP, paramCalendar);
    loggerExternal.exiting(getClassNameLogging(), "getSmallDateTime", timestamp);
    return timestamp;
  }

  
  public Timestamp getSmallDateTime(String paramString, Calendar paramCalendar) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getSmallDateTime", new Object[] { paramString, paramCalendar }); 
    checkClosed();
    Timestamp timestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.TIMESTAMP, paramCalendar);
    loggerExternal.exiting(getClassNameLogging(), "getSmallDateTime", timestamp);
    return timestamp;
  }

  
  public DateTimeOffset getDateTimeOffset(int paramInt) throws SQLException {
    loggerExternal.entering(getClassNameLogging(), "getDateTimeOffset", Integer.valueOf(paramInt));
    checkClosed();

    
    if (!this.stmt.connection.isKatmaiOrLater()) {
      throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
    }



    
    DateTimeOffset dateTimeOffset = (DateTimeOffset)getValue(paramInt, JDBCType.DATETIMEOFFSET);
    loggerExternal.exiting(getClassNameLogging(), "getDateTimeOffset", dateTimeOffset);
    return dateTimeOffset;
  }

  
  public DateTimeOffset getDateTimeOffset(String paramString) throws SQLException {
    loggerExternal.entering(getClassNameLogging(), "getDateTimeOffset", paramString);
    checkClosed();

    
    if (!this.stmt.connection.isKatmaiOrLater()) {
      throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
    }



    
    DateTimeOffset dateTimeOffset = (DateTimeOffset)getValue(findColumn(paramString), JDBCType.DATETIMEOFFSET);
    loggerExternal.exiting(getClassNameLogging(), "getDateTimeOffset", dateTimeOffset);
    return dateTimeOffset;
  }
  
  @Deprecated
  public InputStream getUnicodeStream(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getUnicodeStream", Integer.valueOf(paramInt));
    NotImplemented();
    return null;
  }
  
  @Deprecated
  public InputStream getUnicodeStream(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getUnicodeStream", paramString);
    NotImplemented();
    return null;
  }

  
  public Object getObject(int paramInt, Map<String, Class<?>> paramMap) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "getObject", new Object[] { Integer.valueOf(paramInt), paramMap }); 
    NotImplemented();
    return null;
  }

  
  public Ref getRef(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getRef");
    NotImplemented();
    return null;
  }

  
  public Blob getBlob(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getBlob", Integer.valueOf(paramInt));
    checkClosed();
    Blob blob = (Blob)getValue(paramInt, JDBCType.BLOB);
    loggerExternal.exiting(getClassNameLogging(), "getBlob", blob);
    return blob;
  }

  
  public Blob getBlob(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getBlob", paramString);
    checkClosed();
    Blob blob = (Blob)getValue(findColumn(paramString), JDBCType.BLOB);
    loggerExternal.exiting(getClassNameLogging(), "getBlob", blob);
    return blob;
  }

  
  public Clob getClob(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getClob", Integer.valueOf(paramInt));
    checkClosed();
    Clob clob = (Clob)getValue(paramInt, JDBCType.CLOB);
    loggerExternal.exiting(getClassNameLogging(), "getClob", clob);
    return clob;
  }

  
  public Clob getClob(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getClob", paramString);
    checkClosed();
    Clob clob = (Clob)getValue(findColumn(paramString), JDBCType.CLOB);
    loggerExternal.exiting(getClassNameLogging(), "getClob", clob);
    return clob;
  }

  
  public NClob getNClob(int paramInt) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    loggerExternal.entering(getClassNameLogging(), "getNClob", Integer.valueOf(paramInt));
    checkClosed();
    NClob nClob = (NClob)getValue(paramInt, JDBCType.NCLOB);
    loggerExternal.exiting(getClassNameLogging(), "getNClob", nClob);
    return nClob;
  }

  
  public NClob getNClob(String paramString) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    loggerExternal.entering(getClassNameLogging(), "getNClob", paramString);
    checkClosed();
    NClob nClob = (NClob)getValue(findColumn(paramString), JDBCType.NCLOB);
    loggerExternal.exiting(getClassNameLogging(), "getNClob", nClob);
    return nClob;
  }

  
  public Array getArray(int paramInt) throws SQLServerException {
    NotImplemented();
    return null;
  }

  
  public Object getObject(String paramString, Map<String, Class<?>> paramMap) throws SQLServerException {
    NotImplemented();
    return null;
  }

  
  public Ref getRef(String paramString) throws SQLServerException {
    NotImplemented();
    return null;
  }

  
  public Array getArray(String paramString) throws SQLServerException {
    NotImplemented();
    return null;
  }

  
  public String getCursorName() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getCursorName");
    SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, SQLServerException.getErrString("R_positionedUpdatesNotSupported"), (String)null, false);
    loggerExternal.exiting(getClassNameLogging(), "getCursorName", null);
    return null;
  }

  
  public Reader getCharacterStream(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getCharacterStream", Integer.valueOf(paramInt));
    checkClosed();
    Reader reader = (Reader)getStream(paramInt, StreamType.CHARACTER);
    loggerExternal.exiting(getClassNameLogging(), "getCharacterStream", reader);
    return reader;
  }

  
  public Reader getCharacterStream(String paramString) throws SQLServerException {
    checkClosed();
    loggerExternal.entering(getClassNameLogging(), "getCharacterStream", paramString);
    Reader reader = (Reader)getStream(findColumn(paramString), StreamType.CHARACTER);
    loggerExternal.exiting(getClassNameLogging(), "getCharacterStream", reader);
    return reader;
  }

  
  public Reader getNCharacterStream(int paramInt) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    loggerExternal.entering(getClassNameLogging(), "getNCharacterStream", Integer.valueOf(paramInt));
    checkClosed();
    Reader reader = (Reader)getStream(paramInt, StreamType.NCHARACTER);
    loggerExternal.exiting(getClassNameLogging(), "getNCharacterStream", reader);
    return reader;
  }

  
  public Reader getNCharacterStream(String paramString) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    loggerExternal.entering(getClassNameLogging(), "getNCharacterStream", paramString);
    checkClosed();
    Reader reader = (Reader)getStream(findColumn(paramString), StreamType.NCHARACTER);
    loggerExternal.exiting(getClassNameLogging(), "getNCharacterStream", reader);
    return reader;
  }

  
  public BigDecimal getBigDecimal(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getBigDecimal", Integer.valueOf(paramInt));
    checkClosed();
    BigDecimal bigDecimal = (BigDecimal)getValue(paramInt, JDBCType.DECIMAL);
    loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", bigDecimal);
    return bigDecimal;
  }

  
  public BigDecimal getBigDecimal(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getBigDecimal", paramString);
    checkClosed();
    BigDecimal bigDecimal = (BigDecimal)getValue(findColumn(paramString), JDBCType.DECIMAL);
    loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", bigDecimal);
    return bigDecimal;
  }

  
  public BigDecimal getMoney(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getMoney", Integer.valueOf(paramInt));
    checkClosed();
    BigDecimal bigDecimal = (BigDecimal)getValue(paramInt, JDBCType.DECIMAL);
    loggerExternal.exiting(getClassNameLogging(), "getMoney", bigDecimal);
    return bigDecimal;
  }

  
  public BigDecimal getMoney(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getMoney", paramString);
    checkClosed();
    BigDecimal bigDecimal = (BigDecimal)getValue(findColumn(paramString), JDBCType.DECIMAL);
    loggerExternal.exiting(getClassNameLogging(), "getMoney", bigDecimal);
    return bigDecimal;
  }

  
  public BigDecimal getSmallMoney(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getSmallMoney", Integer.valueOf(paramInt));
    checkClosed();
    BigDecimal bigDecimal = (BigDecimal)getValue(paramInt, JDBCType.DECIMAL);
    loggerExternal.exiting(getClassNameLogging(), "getSmallMoney", bigDecimal);
    return bigDecimal;
  }

  
  public BigDecimal getSmallMoney(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getSmallMoney", paramString);
    checkClosed();
    BigDecimal bigDecimal = (BigDecimal)getValue(findColumn(paramString), JDBCType.DECIMAL);
    loggerExternal.exiting(getClassNameLogging(), "getSmallMoney", bigDecimal);
    return bigDecimal;
  }

  
  public RowId getRowId(int paramInt) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();

    
    throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
  }

  
  public RowId getRowId(String paramString) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();

    
    throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
  }

  
  public SQLXML getSQLXML(int paramInt) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    loggerExternal.entering(getClassNameLogging(), "getSQLXML", Integer.valueOf(paramInt));
    SQLXML sQLXML = getSQLXMLInternal(paramInt);
    loggerExternal.exiting(getClassNameLogging(), "getSQLXML", sQLXML);
    return sQLXML;
  }

  
  public SQLXML getSQLXML(String paramString) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    loggerExternal.entering(getClassNameLogging(), "getSQLXML", paramString);
    SQLXML sQLXML = getSQLXMLInternal(findColumn(paramString));
    loggerExternal.exiting(getClassNameLogging(), "getSQLXML", sQLXML);
    return sQLXML;
  }

  
  public boolean rowUpdated() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "rowUpdated");
    checkClosed();

    
    verifyResultSetIsUpdatable();


    
    loggerExternal.exiting(getClassNameLogging(), "rowUpdated", Boolean.valueOf(false));
    return false;
  }

  
  public boolean rowInserted() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "rowInserted");
    checkClosed();


    
    verifyResultSetIsUpdatable();


    
    loggerExternal.exiting(getClassNameLogging(), "rowInserted", Boolean.valueOf(false));
    return false;
  }

  
  public boolean rowDeleted() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "rowDeleted");
    checkClosed();


    
    verifyResultSetIsUpdatable();
    
    if (this.isOnInsertRow || !hasCurrentRow()) {
      return false;
    }
    boolean bool = currentRowDeleted();
    loggerExternal.exiting(getClassNameLogging(), "rowDeleted", Boolean.valueOf(bool));
    return bool;
  }









  
  private final boolean currentRowDeleted() throws SQLServerException {
    assert hasCurrentRow();

    
    assert null != this.tdsReader;

    
    return (this.deletedCurrentRow || (0 != this.serverCursorId && 2 == loadColumn(this.columns.length).getInt(this.tdsReader)));
  }













  
  private final Column updaterGetColumn(int paramInt) throws SQLServerException {
    verifyResultSetIsUpdatable();
    
    verifyValidColumnIndex(paramInt);

    
    if (!this.columns[paramInt - 1].isUpdatable())
    {
      SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_cantUpdateColumn"), "07009", false);
    }







    
    if (!this.isOnInsertRow) {




      
      if (!hasCurrentRow())
      {
        SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_resultsetNoCurrentRow"), (String)null, true);
      }







      
      verifyCurrentRowIsNotDeleted("R_cantUpdateDeletedRow");
    } 
    
    return getColumn(paramInt);
  }






  
  private void updateValue(int paramInt, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, boolean paramBoolean) throws SQLServerException {
    updaterGetColumn(paramInt).updateValue(paramJDBCType, paramObject, paramJavaType, null, null, null, this.stmt.connection, this.stmt.stmtColumnEncriptionSetting, null, paramBoolean, paramInt);
  }


















  
  private void updateValue(int paramInt, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, Calendar paramCalendar, boolean paramBoolean) throws SQLServerException {
    updaterGetColumn(paramInt).updateValue(paramJDBCType, paramObject, paramJavaType, null, paramCalendar, null, this.stmt.connection, this.stmt.stmtColumnEncriptionSetting, null, paramBoolean, paramInt);
  }



















  
  private void updateValue(int paramInt, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, Integer paramInteger1, Integer paramInteger2, boolean paramBoolean) throws SQLServerException {
    updaterGetColumn(paramInt).updateValue(paramJDBCType, paramObject, paramJavaType, null, null, paramInteger2, this.stmt.connection, this.stmt.stmtColumnEncriptionSetting, paramInteger1, paramBoolean, paramInt);
  }

















  
  private void updateStream(int paramInt, StreamType paramStreamType, Object paramObject, JavaType paramJavaType, long paramLong) throws SQLServerException {
    updaterGetColumn(paramInt).updateValue(paramStreamType.getJDBCType(), paramObject, paramJavaType, new StreamSetterArgs(paramStreamType, paramLong), null, null, this.stmt.connection, this.stmt.stmtColumnEncriptionSetting, null, false, paramInt);
  }












  
  private final void updateSQLXMLInternal(int paramInt, SQLXML paramSQLXML) throws SQLServerException {
    updaterGetColumn(paramInt).updateValue(JDBCType.SQLXML, paramSQLXML, JavaType.SQLXML, new StreamSetterArgs(StreamType.SQLXML, -1L), null, null, this.stmt.connection, this.stmt.stmtColumnEncriptionSetting, null, false, paramInt);
  }












  
  public void updateNull(int paramInt) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "updateNull", Integer.valueOf(paramInt));
    
    checkClosed();
    updateValue(paramInt, updaterGetColumn(paramInt).getTypeInfo().getSSType().getJDBCType(), null, JavaType.OBJECT, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateNull");
  }

  
  public void updateBoolean(int paramInt, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "updateBoolean", new Object[] { Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    updateValue(paramInt, JDBCType.BIT, Boolean.valueOf(paramBoolean), JavaType.BOOLEAN, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateBoolean");
  }

  
  public void updateBoolean(int paramInt, boolean paramBoolean1, boolean paramBoolean2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "updateBoolean", new Object[] { Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean1), Boolean.valueOf(paramBoolean2) }); 
    checkClosed();
    updateValue(paramInt, JDBCType.BIT, Boolean.valueOf(paramBoolean1), JavaType.BOOLEAN, paramBoolean2);





    
    loggerExternal.exiting(getClassNameLogging(), "updateBoolean");
  }

  
  public void updateByte(int paramInt, byte paramByte) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateByte", new Object[] { Integer.valueOf(paramInt), Byte.valueOf(paramByte) });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.TINYINT, Byte.valueOf(paramByte), JavaType.BYTE, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateByte");
  }

  
  public void updateByte(int paramInt, byte paramByte, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateByte", new Object[] { Integer.valueOf(paramInt), Byte.valueOf(paramByte), Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.TINYINT, Byte.valueOf(paramByte), JavaType.BYTE, paramBoolean);





    
    loggerExternal.exiting(getClassNameLogging(), "updateByte");
  }

  
  public void updateShort(int paramInt, short paramShort) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateShort", new Object[] { Integer.valueOf(paramInt), Short.valueOf(paramShort) });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.SMALLINT, Short.valueOf(paramShort), JavaType.SHORT, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateShort");
  }

  
  public void updateShort(int paramInt, short paramShort, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateShort", new Object[] { Integer.valueOf(paramInt), Short.valueOf(paramShort), Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.SMALLINT, Short.valueOf(paramShort), JavaType.SHORT, paramBoolean);





    
    loggerExternal.exiting(getClassNameLogging(), "updateShort");
  }

  
  public void updateInt(int paramInt1, int paramInt2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateInt", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) });
    }
    checkClosed();
    updateValue(paramInt1, JDBCType.INTEGER, Integer.valueOf(paramInt2), JavaType.INTEGER, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateInt");
  }

  
  public void updateInt(int paramInt1, int paramInt2, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateInt", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(paramInt1, JDBCType.INTEGER, Integer.valueOf(paramInt2), JavaType.INTEGER, paramBoolean);





    
    loggerExternal.exiting(getClassNameLogging(), "updateInt");
  }

  
  public void updateLong(int paramInt, long paramLong) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateLong", new Object[] { Integer.valueOf(paramInt), Long.valueOf(paramLong) });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.BIGINT, Long.valueOf(paramLong), JavaType.LONG, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateLong");
  }

  
  public void updateLong(int paramInt, long paramLong, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateLong", new Object[] { Integer.valueOf(paramInt), Long.valueOf(paramLong), Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.BIGINT, Long.valueOf(paramLong), JavaType.LONG, paramBoolean);





    
    loggerExternal.exiting(getClassNameLogging(), "updateLong");
  }

  
  public void updateFloat(int paramInt, float paramFloat) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateFloat", new Object[] { Integer.valueOf(paramInt), Float.valueOf(paramFloat) });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.REAL, Float.valueOf(paramFloat), JavaType.FLOAT, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateFloat");
  }

  
  public void updateFloat(int paramInt, float paramFloat, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateFloat", new Object[] { Integer.valueOf(paramInt), Float.valueOf(paramFloat), Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.REAL, Float.valueOf(paramFloat), JavaType.FLOAT, paramBoolean);





    
    loggerExternal.exiting(getClassNameLogging(), "updateFloat");
  }

  
  public void updateDouble(int paramInt, double paramDouble) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateDouble", new Object[] { Integer.valueOf(paramInt), Double.valueOf(paramDouble) });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.DOUBLE, Double.valueOf(paramDouble), JavaType.DOUBLE, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateDouble");
  }

  
  public void updateDouble(int paramInt, double paramDouble, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateDouble", new Object[] { Integer.valueOf(paramInt), Double.valueOf(paramDouble), Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.DOUBLE, Double.valueOf(paramDouble), JavaType.DOUBLE, paramBoolean);





    
    loggerExternal.exiting(getClassNameLogging(), "updateDouble");
  }

  
  public void updateMoney(int paramInt, BigDecimal paramBigDecimal) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "updateMoney", new Object[] { Integer.valueOf(paramInt), paramBigDecimal }); 
    checkClosed();
    updateValue(paramInt, JDBCType.MONEY, paramBigDecimal, JavaType.BIGDECIMAL, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateMoney");
  }

  
  public void updateMoney(int paramInt, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "updateMoney", new Object[] { Integer.valueOf(paramInt), paramBigDecimal, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    updateValue(paramInt, JDBCType.MONEY, paramBigDecimal, JavaType.BIGDECIMAL, paramBoolean);





    
    loggerExternal.exiting(getClassNameLogging(), "updateMoney");
  }

  
  public void updateMoney(String paramString, BigDecimal paramBigDecimal) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "updateMoney", new Object[] { paramString, paramBigDecimal }); 
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.MONEY, paramBigDecimal, JavaType.BIGDECIMAL, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateMoney");
  }

  
  public void updateMoney(String paramString, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "updateMoney", new Object[] { paramString, paramBigDecimal, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.MONEY, paramBigDecimal, JavaType.BIGDECIMAL, paramBoolean);





    
    loggerExternal.exiting(getClassNameLogging(), "updateMoney");
  }

  
  public void updateSmallMoney(int paramInt, BigDecimal paramBigDecimal) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "updateSmallMoney", new Object[] { Integer.valueOf(paramInt), paramBigDecimal }); 
    checkClosed();
    updateValue(paramInt, JDBCType.SMALLMONEY, paramBigDecimal, JavaType.BIGDECIMAL, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateSmallMoney");
  }

  
  public void updateSmallMoney(int paramInt, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "updateSmallMoney", new Object[] { Integer.valueOf(paramInt), paramBigDecimal, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    updateValue(paramInt, JDBCType.SMALLMONEY, paramBigDecimal, JavaType.BIGDECIMAL, paramBoolean);





    
    loggerExternal.exiting(getClassNameLogging(), "updateSmallMoney");
  }

  
  public void updateSmallMoney(String paramString, BigDecimal paramBigDecimal) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "updateSmallMoney", new Object[] { paramString, paramBigDecimal }); 
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.SMALLMONEY, paramBigDecimal, JavaType.BIGDECIMAL, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateSmallMoney");
  }

  
  public void updateSmallMoney(String paramString, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "updateSmallMoney", new Object[] { paramString, paramBigDecimal, Boolean.valueOf(paramBoolean) }); 
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.SMALLMONEY, paramBigDecimal, JavaType.BIGDECIMAL, paramBoolean);





    
    loggerExternal.exiting(getClassNameLogging(), "updateSmallMoney");
  }

  
  public void updateBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateBigDecimal", new Object[] { Integer.valueOf(paramInt), paramBigDecimal });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateBigDecimal");
  }

  
  public void updateBigDecimal(int paramInt, BigDecimal paramBigDecimal, Integer paramInteger1, Integer paramInteger2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateBigDecimal", new Object[] { Integer.valueOf(paramInt), paramBigDecimal, paramInteger2 });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, paramInteger1, paramInteger2, false);







    
    loggerExternal.exiting(getClassNameLogging(), "updateBigDecimal");
  }

  
  public void updateBigDecimal(int paramInt, BigDecimal paramBigDecimal, Integer paramInteger1, Integer paramInteger2, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateBigDecimal", new Object[] { Integer.valueOf(paramInt), paramBigDecimal, paramInteger2, Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, paramInteger1, paramInteger2, paramBoolean);







    
    loggerExternal.exiting(getClassNameLogging(), "updateBigDecimal");
  }

  
  public void updateString(int paramInt, String paramString) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateString", new Object[] { Integer.valueOf(paramInt), paramString });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.VARCHAR, paramString, JavaType.STRING, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateString");
  }

  
  public void updateString(int paramInt, String paramString, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateString", new Object[] { Integer.valueOf(paramInt), paramString, Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.VARCHAR, paramString, JavaType.STRING, paramBoolean);





    
    loggerExternal.exiting(getClassNameLogging(), "updateString");
  }

  
  public void updateNString(int paramInt, String paramString) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateNString", new Object[] { Integer.valueOf(paramInt), paramString });
    }
    DriverJDBCVersion.checkSupportsJDBC4();
    checkClosed();
    updateValue(paramInt, JDBCType.NVARCHAR, paramString, JavaType.STRING, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateNString");
  }

  
  public void updateNString(int paramInt, String paramString, boolean paramBoolean) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateNString", new Object[] { Integer.valueOf(paramInt), paramString, Boolean.valueOf(paramBoolean) });
    }
    DriverJDBCVersion.checkSupportsJDBC4();
    checkClosed();
    updateValue(paramInt, JDBCType.NVARCHAR, paramString, JavaType.STRING, paramBoolean);





    
    loggerExternal.exiting(getClassNameLogging(), "updateNString");
  }

  
  public void updateNString(String paramString1, String paramString2) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateNString", new Object[] { paramString1, paramString2 });
    }
    DriverJDBCVersion.checkSupportsJDBC4();
    checkClosed();
    updateValue(findColumn(paramString1), JDBCType.NVARCHAR, paramString2, JavaType.STRING, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateNString");
  }

  
  public void updateNString(String paramString1, String paramString2, boolean paramBoolean) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateNString", new Object[] { paramString1, paramString2, Boolean.valueOf(paramBoolean) });
    }
    DriverJDBCVersion.checkSupportsJDBC4();
    checkClosed();
    updateValue(findColumn(paramString1), JDBCType.NVARCHAR, paramString2, JavaType.STRING, paramBoolean);





    
    loggerExternal.exiting(getClassNameLogging(), "updateNString");
  }

  
  public void updateBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateBytes", new Object[] { Integer.valueOf(paramInt), paramArrayOfbyte });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.BINARY, paramArrayOfbyte, JavaType.BYTEARRAY, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateBytes");
  }

  
  public void updateBytes(int paramInt, byte[] paramArrayOfbyte, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateBytes", new Object[] { Integer.valueOf(paramInt), paramArrayOfbyte, Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.BINARY, paramArrayOfbyte, JavaType.BYTEARRAY, paramBoolean);





    
    loggerExternal.exiting(getClassNameLogging(), "updateBytes");
  }

  
  public void updateDate(int paramInt, Date paramDate) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateDate", new Object[] { Integer.valueOf(paramInt), paramDate });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.DATE, paramDate, JavaType.DATE, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateDate");
  }

  
  public void updateDate(int paramInt, Date paramDate, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateDate", new Object[] { Integer.valueOf(paramInt), paramDate, Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.DATE, paramDate, JavaType.DATE, paramBoolean);





    
    loggerExternal.exiting(getClassNameLogging(), "updateDate");
  }

  
  public void updateTime(int paramInt, Time paramTime) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateTime", new Object[] { Integer.valueOf(paramInt), paramTime });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.TIME, paramTime, JavaType.TIME, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateTime");
  }

  
  public void updateTime(int paramInt, Time paramTime, Integer paramInteger) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateTime", new Object[] { Integer.valueOf(paramInt), paramTime, paramInteger });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.TIME, paramTime, JavaType.TIME, null, paramInteger, false);







    
    loggerExternal.exiting(getClassNameLogging(), "updateTime");
  }

  
  public void updateTime(int paramInt, Time paramTime, Integer paramInteger, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateTime", new Object[] { Integer.valueOf(paramInt), paramTime, paramInteger, Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.TIME, paramTime, JavaType.TIME, null, paramInteger, paramBoolean);







    
    loggerExternal.exiting(getClassNameLogging(), "updateTime");
  }

  
  public void updateTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateTimestamp", new Object[] { Integer.valueOf(paramInt), paramTimestamp });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateTimestamp");
  }

  
  public void updateTimestamp(int paramInt1, Timestamp paramTimestamp, int paramInt2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateTimestamp", new Object[] { Integer.valueOf(paramInt1), paramTimestamp, Integer.valueOf(paramInt2) });
    }
    checkClosed();
    updateValue(paramInt1, JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, null, Integer.valueOf(paramInt2), false);







    
    loggerExternal.exiting(getClassNameLogging(), "updateTimestamp");
  }

  
  public void updateTimestamp(int paramInt1, Timestamp paramTimestamp, int paramInt2, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateTimestamp", new Object[] { Integer.valueOf(paramInt1), paramTimestamp, Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(paramInt1, JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, null, Integer.valueOf(paramInt2), paramBoolean);







    
    loggerExternal.exiting(getClassNameLogging(), "updateTimestamp");
  }

  
  public void updateDateTime(int paramInt, Timestamp paramTimestamp) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateDateTime", new Object[] { Integer.valueOf(paramInt), paramTimestamp });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.DATETIME, paramTimestamp, JavaType.TIMESTAMP, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateDateTime");
  }

  
  public void updateDateTime(int paramInt, Timestamp paramTimestamp, Integer paramInteger) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateDateTime", new Object[] { Integer.valueOf(paramInt), paramTimestamp, paramInteger });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.DATETIME, paramTimestamp, JavaType.TIMESTAMP, null, paramInteger, false);







    
    loggerExternal.exiting(getClassNameLogging(), "updateDateTime");
  }

  
  public void updateDateTime(int paramInt, Timestamp paramTimestamp, Integer paramInteger, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateDateTime", new Object[] { Integer.valueOf(paramInt), paramTimestamp, paramInteger, Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.DATETIME, paramTimestamp, JavaType.TIMESTAMP, null, paramInteger, paramBoolean);







    
    loggerExternal.exiting(getClassNameLogging(), "updateDateTime");
  }

  
  public void updateSmallDateTime(int paramInt, Timestamp paramTimestamp) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateSmallDateTime", new Object[] { Integer.valueOf(paramInt), paramTimestamp });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.SMALLDATETIME, paramTimestamp, JavaType.TIMESTAMP, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateSmallDateTime");
  }

  
  public void updateSmallDateTime(int paramInt, Timestamp paramTimestamp, Integer paramInteger) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateSmallDateTime", new Object[] { Integer.valueOf(paramInt), paramTimestamp, paramInteger });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.SMALLDATETIME, paramTimestamp, JavaType.TIMESTAMP, null, paramInteger, false);







    
    loggerExternal.exiting(getClassNameLogging(), "updateSmallDateTime");
  }

  
  public void updateSmallDateTime(int paramInt, Timestamp paramTimestamp, Integer paramInteger, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateSmallDateTime", new Object[] { Integer.valueOf(paramInt), paramTimestamp, paramInteger, Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.SMALLDATETIME, paramTimestamp, JavaType.TIMESTAMP, null, paramInteger, paramBoolean);







    
    loggerExternal.exiting(getClassNameLogging(), "updateSmallDateTime");
  }

  
  public void updateDateTimeOffset(int paramInt, DateTimeOffset paramDateTimeOffset) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateDateTimeOffset", new Object[] { Integer.valueOf(paramInt), paramDateTimeOffset });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateDateTimeOffset");
  }

  
  public void updateDateTimeOffset(int paramInt, DateTimeOffset paramDateTimeOffset, Integer paramInteger) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateDateTimeOffset", new Object[] { Integer.valueOf(paramInt), paramDateTimeOffset, paramInteger });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET, null, paramInteger, false);







    
    loggerExternal.exiting(getClassNameLogging(), "updateDateTimeOffset");
  }

  
  public void updateDateTimeOffset(int paramInt, DateTimeOffset paramDateTimeOffset, Integer paramInteger, boolean paramBoolean) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateDateTimeOffset", new Object[] { Integer.valueOf(paramInt), paramDateTimeOffset, paramInteger, Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET, null, paramInteger, paramBoolean);







    
    loggerExternal.exiting(getClassNameLogging(), "updateDateTimeOffset");
  }

  
  public void updateUniqueIdentifier(int paramInt, String paramString) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateUniqueIdentifier", new Object[] { Integer.valueOf(paramInt), paramString });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.GUID, paramString, JavaType.STRING, null, false);






    
    loggerExternal.exiting(getClassNameLogging(), "updateUniqueIdentifier");
  }

  
  public void updateUniqueIdentifier(int paramInt, String paramString, boolean paramBoolean) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateUniqueIdentifier", new Object[] { Integer.valueOf(paramInt), paramString, Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.GUID, paramString, JavaType.STRING, null, paramBoolean);






    
    loggerExternal.exiting(getClassNameLogging(), "updateUniqueIdentifier");
  }

  
  public void updateAsciiStream(int paramInt, InputStream paramInputStream) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateAsciiStream", new Object[] { Integer.valueOf(paramInt), paramInputStream });
    }
    checkClosed();
    updateStream(paramInt, StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, -1L);





    
    loggerExternal.exiting(getClassNameLogging(), "updateAsciiStream");
  }

  
  public void updateAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateAsciiStream", new Object[] { Integer.valueOf(paramInt1), paramInputStream, Integer.valueOf(paramInt2) });
    }
    checkClosed();
    updateStream(paramInt1, StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, paramInt2);





    
    loggerExternal.exiting(getClassNameLogging(), "updateAsciiStream");
  }

  
  public void updateAsciiStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    loggerExternal.entering(getClassNameLogging(), "updateAsciiStream", new Object[] { Integer.valueOf(paramInt), paramInputStream, Long.valueOf(paramLong) });
    
    checkClosed();
    updateStream(paramInt, StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, paramLong);





    
    loggerExternal.exiting(getClassNameLogging(), "updateAsciiStream");
  }

  
  public void updateAsciiStream(String paramString, InputStream paramInputStream) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateAsciiStream", new Object[] { paramString, paramInputStream });
    }
    checkClosed();
    updateStream(findColumn(paramString), StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, -1L);





    
    loggerExternal.exiting(getClassNameLogging(), "updateAsciiStream");
  }

  
  public void updateAsciiStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateAsciiStream", new Object[] { paramString, paramInputStream, Integer.valueOf(paramInt) });
    }
    checkClosed();
    updateStream(findColumn(paramString), StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, paramInt);





    
    loggerExternal.exiting(getClassNameLogging(), "updateAsciiStream");
  }

  
  public void updateAsciiStream(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateAsciiStream", new Object[] { paramString, paramInputStream, Long.valueOf(paramLong) });
    }
    checkClosed();
    updateStream(findColumn(paramString), StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, paramLong);





    
    loggerExternal.exiting(getClassNameLogging(), "updateAsciiStream");
  }

  
  public void updateBinaryStream(int paramInt, InputStream paramInputStream) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateBinaryStream", new Object[] { Integer.valueOf(paramInt), paramInputStream });
    }
    checkClosed();
    updateStream(paramInt, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, -1L);





    
    loggerExternal.exiting(getClassNameLogging(), "updateBinaryStream");
  }

  
  public void updateBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateBinaryStream", new Object[] { Integer.valueOf(paramInt1), paramInputStream, Integer.valueOf(paramInt2) });
    }
    checkClosed();
    updateStream(paramInt1, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramInt2);





    
    loggerExternal.exiting(getClassNameLogging(), "updateBinaryStream");
  }

  
  public void updateBinaryStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateBinaryStream", new Object[] { Integer.valueOf(paramInt), paramInputStream, Long.valueOf(paramLong) });
    }
    checkClosed();
    updateStream(paramInt, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramLong);





    
    loggerExternal.exiting(getClassNameLogging(), "updateBinaryStream");
  }

  
  public void updateBinaryStream(String paramString, InputStream paramInputStream) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateBinaryStream", new Object[] { paramString, paramInputStream });
    }
    checkClosed();
    updateStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, -1L);





    
    loggerExternal.exiting(getClassNameLogging(), "updateBinaryStream");
  }

  
  public void updateBinaryStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateBinaryStream", new Object[] { paramString, paramInputStream, Integer.valueOf(paramInt) });
    }
    checkClosed();
    updateStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramInt);





    
    loggerExternal.exiting(getClassNameLogging(), "updateBinaryStream");
  }

  
  public void updateBinaryStream(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateBinaryStream", new Object[] { paramString, paramInputStream, Long.valueOf(paramLong) });
    }
    checkClosed();
    updateStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramLong);





    
    loggerExternal.exiting(getClassNameLogging(), "updateBinaryStream");
  }

  
  public void updateCharacterStream(int paramInt, Reader paramReader) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateCharacterStream", new Object[] { Integer.valueOf(paramInt), paramReader });
    }
    checkClosed();
    updateStream(paramInt, StreamType.CHARACTER, paramReader, JavaType.READER, -1L);





    
    loggerExternal.exiting(getClassNameLogging(), "updateCharacterStream");
  }

  
  public void updateCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateCharacterStream", new Object[] { Integer.valueOf(paramInt1), paramReader, Integer.valueOf(paramInt2) });
    }
    checkClosed();
    updateStream(paramInt1, StreamType.CHARACTER, paramReader, JavaType.READER, paramInt2);





    
    loggerExternal.exiting(getClassNameLogging(), "updateCharacterStream");
  }

  
  public void updateCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateCharacterStream", new Object[] { Integer.valueOf(paramInt), paramReader, Long.valueOf(paramLong) });
    }
    checkClosed();
    updateStream(paramInt, StreamType.CHARACTER, paramReader, JavaType.READER, paramLong);





    
    loggerExternal.exiting(getClassNameLogging(), "updateCharacterStream");
  }

  
  public void updateCharacterStream(String paramString, Reader paramReader) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateCharacterStream", new Object[] { paramString, paramReader });
    }
    checkClosed();
    updateStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, -1L);





    
    loggerExternal.exiting(getClassNameLogging(), "updateCharacterStream");
  }

  
  public void updateCharacterStream(String paramString, Reader paramReader, int paramInt) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateCharacterStream", new Object[] { paramString, paramReader, Integer.valueOf(paramInt) });
    }
    checkClosed();
    updateStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, paramInt);





    
    loggerExternal.exiting(getClassNameLogging(), "updateCharacterStream");
  }

  
  public void updateCharacterStream(String paramString, Reader paramReader, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateCharacterStream", new Object[] { paramString, paramReader, Long.valueOf(paramLong) });
    }
    checkClosed();
    updateStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, paramLong);





    
    loggerExternal.exiting(getClassNameLogging(), "updateNCharacterStream");
  }

  
  public void updateNCharacterStream(int paramInt, Reader paramReader) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateNCharacterStream", new Object[] { Integer.valueOf(paramInt), paramReader });
    }
    checkClosed();
    updateStream(paramInt, StreamType.NCHARACTER, paramReader, JavaType.READER, -1L);





    
    loggerExternal.exiting(getClassNameLogging(), "updateNCharacterStream");
  }

  
  public void updateNCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateNCharacterStream", new Object[] { Integer.valueOf(paramInt), paramReader, Long.valueOf(paramLong) });
    }
    checkClosed();
    updateStream(paramInt, StreamType.NCHARACTER, paramReader, JavaType.READER, paramLong);





    
    loggerExternal.exiting(getClassNameLogging(), "updateNCharacterStream");
  }

  
  public void updateNCharacterStream(String paramString, Reader paramReader) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateNCharacterStream", new Object[] { paramString, paramReader });
    }
    checkClosed();
    updateStream(findColumn(paramString), StreamType.NCHARACTER, paramReader, JavaType.READER, -1L);





    
    loggerExternal.exiting(getClassNameLogging(), "updateNCharacterStream");
  }

  
  public void updateNCharacterStream(String paramString, Reader paramReader, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateNCharacterStream", new Object[] { paramString, paramReader, Long.valueOf(paramLong) });
    }
    checkClosed();
    updateStream(findColumn(paramString), StreamType.NCHARACTER, paramReader, JavaType.READER, paramLong);





    
    loggerExternal.exiting(getClassNameLogging(), "updateNCharacterStream");
  }

  
  public void updateObject(int paramInt, Object paramObject) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { Integer.valueOf(paramInt), paramObject });
    }
    checkClosed();
    updateObject(paramInt, paramObject, (Integer)null, null, null, false);
    
    loggerExternal.exiting(getClassNameLogging(), "updateObject");
  }


  
  public void updateObject(int paramInt, Object paramObject, SQLType paramSQLType) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { Integer.valueOf(paramInt), paramObject, paramSQLType });
    }
    checkClosed();
    
    updateObject(paramInt, paramObject, (Integer)null, JDBCType.of(paramSQLType.getVendorTypeNumber().intValue()), null, false);
    
    loggerExternal.exiting(getClassNameLogging(), "updateObject");
  }

  
  public void updateObject(int paramInt1, Object paramObject, int paramInt2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { Integer.valueOf(paramInt1), paramObject, Integer.valueOf(paramInt2) });
    }
    checkClosed();
    updateObject(paramInt1, paramObject, Integer.valueOf(paramInt2), null, null, false);
    
    loggerExternal.exiting(getClassNameLogging(), "updateObject");
  }

  
  public void updateObject(int paramInt1, Object paramObject, int paramInt2, int paramInt3) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { Integer.valueOf(paramInt1), paramObject, Integer.valueOf(paramInt3) });
    }
    checkClosed();
    updateObject(paramInt1, paramObject, Integer.valueOf(paramInt3), null, Integer.valueOf(paramInt2), false);
    
    loggerExternal.exiting(getClassNameLogging(), "updateObject");
  }

  
  public void updateObject(int paramInt1, Object paramObject, int paramInt2, int paramInt3, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { Integer.valueOf(paramInt1), paramObject, Integer.valueOf(paramInt3), Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateObject(paramInt1, paramObject, Integer.valueOf(paramInt3), null, Integer.valueOf(paramInt2), paramBoolean);
    
    loggerExternal.exiting(getClassNameLogging(), "updateObject");
  }

  
  public void updateObject(int paramInt1, Object paramObject, SQLType paramSQLType, int paramInt2) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { Integer.valueOf(paramInt1), paramObject, paramSQLType, Integer.valueOf(paramInt2) });
    }
    checkClosed();
    
    updateObject(paramInt1, paramObject, Integer.valueOf(paramInt2), JDBCType.of(paramSQLType.getVendorTypeNumber().intValue()), null, false);
    
    loggerExternal.exiting(getClassNameLogging(), "updateObject");
  }

  
  public void updateObject(int paramInt1, Object paramObject, SQLType paramSQLType, int paramInt2, boolean paramBoolean) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { Integer.valueOf(paramInt1), paramObject, paramSQLType, Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    
    updateObject(paramInt1, paramObject, Integer.valueOf(paramInt2), JDBCType.of(paramSQLType.getVendorTypeNumber().intValue()), null, paramBoolean);
    
    loggerExternal.exiting(getClassNameLogging(), "updateObject");
  }

  
  private final void updateObject(int paramInt, Object paramObject, Integer paramInteger1, JDBCType paramJDBCType, Integer paramInteger2, boolean paramBoolean) throws SQLServerException {
    Column column = updaterGetColumn(paramInt);
    SSType sSType = column.getTypeInfo().getSSType();
    
    if (null == paramObject) {
      
      if (null == paramJDBCType || paramJDBCType.isUnsupported())
      {
        
        paramJDBCType = sSType.getJDBCType();
      }
      
      column.updateValue(paramJDBCType, paramObject, JavaType.OBJECT, null, null, paramInteger1, this.stmt.connection, this.stmt.stmtColumnEncriptionSetting, paramInteger2, paramBoolean, paramInt);





    
    }
    else {





      
      JavaType javaType = JavaType.of(paramObject);
      JDBCType jDBCType = javaType.getJDBCType(sSType, sSType.getJDBCType());
      
      if (null == paramJDBCType) {

        
        paramJDBCType = jDBCType;


      
      }
      else if (!jDBCType.convertsTo(paramJDBCType)) {
        DataTypes.throwConversionError(jDBCType.toString(), paramJDBCType.toString());
      } 
      
      StreamSetterArgs streamSetterArgs = null;
      switch (javaType) {
        
        case READER:
          streamSetterArgs = new StreamSetterArgs(StreamType.CHARACTER, -1L);
          break;


        
        case INPUTSTREAM:
          streamSetterArgs = new StreamSetterArgs(paramJDBCType.isTextual() ? StreamType.CHARACTER : StreamType.BINARY, -1L);
          break;


        
        case SQLXML:
          streamSetterArgs = new StreamSetterArgs(StreamType.SQLXML, -1L);
          break;
      } 






      
      column.updateValue(paramJDBCType, paramObject, javaType, streamSetterArgs, null, paramInteger1, this.stmt.connection, this.stmt.stmtColumnEncriptionSetting, paramInteger2, paramBoolean, paramInt);
    } 
  }












  
  public void updateNull(String paramString) throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "updateNull", paramString);
    
    checkClosed();
    int i = findColumn(paramString);
    updateValue(i, updaterGetColumn(i).getTypeInfo().getSSType().getJDBCType(), null, JavaType.OBJECT, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateNull");
  }


  
  public void updateBoolean(String paramString, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateBoolean", new Object[] { paramString, Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.BIT, Boolean.valueOf(paramBoolean), JavaType.BOOLEAN, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateBoolean");
  }

  
  public void updateBoolean(String paramString, boolean paramBoolean1, boolean paramBoolean2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateBoolean", new Object[] { paramString, Boolean.valueOf(paramBoolean1), Boolean.valueOf(paramBoolean2) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.BIT, Boolean.valueOf(paramBoolean1), JavaType.BOOLEAN, paramBoolean2);





    
    loggerExternal.exiting(getClassNameLogging(), "updateBoolean");
  }

  
  public void updateByte(String paramString, byte paramByte) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateByte", new Object[] { paramString, Byte.valueOf(paramByte) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.BINARY, Byte.valueOf(paramByte), JavaType.BYTE, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateByte");
  }

  
  public void updateByte(String paramString, byte paramByte, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateByte", new Object[] { paramString, Byte.valueOf(paramByte), Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.BINARY, Byte.valueOf(paramByte), JavaType.BYTE, paramBoolean);





    
    loggerExternal.exiting(getClassNameLogging(), "updateByte");
  }

  
  public void updateShort(String paramString, short paramShort) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateShort", new Object[] { paramString, Short.valueOf(paramShort) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.SMALLINT, Short.valueOf(paramShort), JavaType.SHORT, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateShort");
  }

  
  public void updateShort(String paramString, short paramShort, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateShort", new Object[] { paramString, Short.valueOf(paramShort), Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.SMALLINT, Short.valueOf(paramShort), JavaType.SHORT, paramBoolean);





    
    loggerExternal.exiting(getClassNameLogging(), "updateShort");
  }

  
  public void updateInt(String paramString, int paramInt) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateInt", new Object[] { paramString, Integer.valueOf(paramInt) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.INTEGER, Integer.valueOf(paramInt), JavaType.INTEGER, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateInt");
  }

  
  public void updateInt(String paramString, int paramInt, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateInt", new Object[] { paramString, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.INTEGER, Integer.valueOf(paramInt), JavaType.INTEGER, paramBoolean);





    
    loggerExternal.exiting(getClassNameLogging(), "updateInt");
  }

  
  public void updateLong(String paramString, long paramLong) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateLong", new Object[] { paramString, Long.valueOf(paramLong) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.BIGINT, Long.valueOf(paramLong), JavaType.LONG, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateLong");
  }

  
  public void updateLong(String paramString, long paramLong, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateLong", new Object[] { paramString, Long.valueOf(paramLong), Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.BIGINT, Long.valueOf(paramLong), JavaType.LONG, paramBoolean);





    
    loggerExternal.exiting(getClassNameLogging(), "updateLong");
  }

  
  public void updateFloat(String paramString, float paramFloat) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateFloat", new Object[] { paramString, Float.valueOf(paramFloat) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.REAL, Float.valueOf(paramFloat), JavaType.FLOAT, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateFloat");
  }

  
  public void updateFloat(String paramString, float paramFloat, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateFloat", new Object[] { paramString, Float.valueOf(paramFloat), Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.REAL, Float.valueOf(paramFloat), JavaType.FLOAT, paramBoolean);





    
    loggerExternal.exiting(getClassNameLogging(), "updateFloat");
  }

  
  public void updateDouble(String paramString, double paramDouble) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateDouble", new Object[] { paramString, Double.valueOf(paramDouble) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.DOUBLE, Double.valueOf(paramDouble), JavaType.DOUBLE, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateDouble");
  }

  
  public void updateDouble(String paramString, double paramDouble, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateDouble", new Object[] { paramString, Double.valueOf(paramDouble), Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.DOUBLE, Double.valueOf(paramDouble), JavaType.DOUBLE, paramBoolean);





    
    loggerExternal.exiting(getClassNameLogging(), "updateDouble");
  }

  
  public void updateBigDecimal(String paramString, BigDecimal paramBigDecimal) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateBigDecimal", new Object[] { paramString, paramBigDecimal });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateBigDecimal");
  }

  
  public void updateBigDecimal(String paramString, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateBigDecimal", new Object[] { paramString, paramBigDecimal, Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, paramBoolean);





    
    loggerExternal.exiting(getClassNameLogging(), "updateBigDecimal");
  }

  
  public void updateBigDecimal(String paramString, BigDecimal paramBigDecimal, Integer paramInteger1, Integer paramInteger2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateBigDecimal", new Object[] { paramString, paramBigDecimal, paramInteger1, paramInteger2 });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, paramInteger1, paramInteger2, false);







    
    loggerExternal.exiting(getClassNameLogging(), "updateBigDecimal");
  }

  
  public void updateBigDecimal(String paramString, BigDecimal paramBigDecimal, Integer paramInteger1, Integer paramInteger2, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateBigDecimal", new Object[] { paramString, paramBigDecimal, paramInteger1, paramInteger2, Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, paramInteger1, paramInteger2, paramBoolean);







    
    loggerExternal.exiting(getClassNameLogging(), "updateBigDecimal");
  }

  
  public void updateString(String paramString1, String paramString2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateString", new Object[] { paramString1, paramString2 });
    }
    checkClosed();
    updateValue(findColumn(paramString1), JDBCType.VARCHAR, paramString2, JavaType.STRING, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateString");
  }

  
  public void updateString(String paramString1, String paramString2, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateString", new Object[] { paramString1, paramString2, Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(findColumn(paramString1), JDBCType.VARCHAR, paramString2, JavaType.STRING, paramBoolean);





    
    loggerExternal.exiting(getClassNameLogging(), "updateString");
  }

  
  public void updateBytes(String paramString, byte[] paramArrayOfbyte) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateBytes", new Object[] { paramString, paramArrayOfbyte });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.BINARY, paramArrayOfbyte, JavaType.BYTEARRAY, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateBytes");
  }

  
  public void updateBytes(String paramString, byte[] paramArrayOfbyte, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateBytes", new Object[] { paramString, paramArrayOfbyte, Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.BINARY, paramArrayOfbyte, JavaType.BYTEARRAY, paramBoolean);





    
    loggerExternal.exiting(getClassNameLogging(), "updateBytes");
  }

  
  public void updateDate(String paramString, Date paramDate) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateDate", new Object[] { paramString, paramDate });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.DATE, paramDate, JavaType.DATE, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateDate");
  }

  
  public void updateDate(String paramString, Date paramDate, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateDate", new Object[] { paramString, paramDate, Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.DATE, paramDate, JavaType.DATE, paramBoolean);





    
    loggerExternal.exiting(getClassNameLogging(), "updateDate");
  }

  
  public void updateTime(String paramString, Time paramTime) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateTime", new Object[] { paramString, paramTime });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.TIME, paramTime, JavaType.TIME, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateTime");
  }

  
  public void updateTime(String paramString, Time paramTime, int paramInt) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateTime", new Object[] { paramString, paramTime, Integer.valueOf(paramInt) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.TIME, paramTime, JavaType.TIME, null, Integer.valueOf(paramInt), false);







    
    loggerExternal.exiting(getClassNameLogging(), "updateTime");
  }

  
  public void updateTime(String paramString, Time paramTime, int paramInt, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateTime", new Object[] { paramString, paramTime, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.TIME, paramTime, JavaType.TIME, null, Integer.valueOf(paramInt), paramBoolean);







    
    loggerExternal.exiting(getClassNameLogging(), "updateTime");
  }

  
  public void updateTimestamp(String paramString, Timestamp paramTimestamp) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateTimestamp", new Object[] { paramString, paramTimestamp });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateTimestamp");
  }

  
  public void updateTimestamp(String paramString, Timestamp paramTimestamp, int paramInt) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateTimestamp", new Object[] { paramString, paramTimestamp, Integer.valueOf(paramInt) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, null, Integer.valueOf(paramInt), false);







    
    loggerExternal.exiting(getClassNameLogging(), "updateTimestamp");
  }

  
  public void updateTimestamp(String paramString, Timestamp paramTimestamp, int paramInt, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateTimestamp", new Object[] { paramString, paramTimestamp, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, null, Integer.valueOf(paramInt), paramBoolean);







    
    loggerExternal.exiting(getClassNameLogging(), "updateTimestamp");
  }

  
  public void updateDateTime(String paramString, Timestamp paramTimestamp) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateDateTime", new Object[] { paramString, paramTimestamp });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.DATETIME, paramTimestamp, JavaType.TIMESTAMP, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateDateTime");
  }

  
  public void updateDateTime(String paramString, Timestamp paramTimestamp, int paramInt) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateDateTime", new Object[] { paramString, paramTimestamp, Integer.valueOf(paramInt) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.DATETIME, paramTimestamp, JavaType.TIMESTAMP, null, Integer.valueOf(paramInt), false);







    
    loggerExternal.exiting(getClassNameLogging(), "updateDateTime");
  }

  
  public void updateDateTime(String paramString, Timestamp paramTimestamp, int paramInt, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateDateTime", new Object[] { paramString, paramTimestamp, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.DATETIME, paramTimestamp, JavaType.TIMESTAMP, null, Integer.valueOf(paramInt), paramBoolean);







    
    loggerExternal.exiting(getClassNameLogging(), "updateDateTime");
  }

  
  public void updateSmallDateTime(String paramString, Timestamp paramTimestamp) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateSmallDateTime", new Object[] { paramString, paramTimestamp });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.SMALLDATETIME, paramTimestamp, JavaType.TIMESTAMP, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateSmallDateTime");
  }

  
  public void updateSmallDateTime(String paramString, Timestamp paramTimestamp, int paramInt) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateSmallDateTime", new Object[] { paramString, paramTimestamp, Integer.valueOf(paramInt) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.SMALLDATETIME, paramTimestamp, JavaType.TIMESTAMP, null, Integer.valueOf(paramInt), false);







    
    loggerExternal.exiting(getClassNameLogging(), "updateSmallDateTime");
  }

  
  public void updateSmallDateTime(String paramString, Timestamp paramTimestamp, int paramInt, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateSmallDateTime", new Object[] { paramString, paramTimestamp, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.SMALLDATETIME, paramTimestamp, JavaType.TIMESTAMP, null, Integer.valueOf(paramInt), paramBoolean);







    
    loggerExternal.exiting(getClassNameLogging(), "updateSmallDateTime");
  }

  
  public void updateDateTimeOffset(String paramString, DateTimeOffset paramDateTimeOffset) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateDateTimeOffset", new Object[] { paramString, paramDateTimeOffset });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateDateTimeOffset");
  }

  
  public void updateDateTimeOffset(String paramString, DateTimeOffset paramDateTimeOffset, int paramInt) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateDateTimeOffset", new Object[] { paramString, paramDateTimeOffset, Integer.valueOf(paramInt) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET, null, Integer.valueOf(paramInt), false);







    
    loggerExternal.exiting(getClassNameLogging(), "updateDateTimeOffset");
  }

  
  public void updateDateTimeOffset(String paramString, DateTimeOffset paramDateTimeOffset, int paramInt, boolean paramBoolean) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateDateTimeOffset", new Object[] { paramString, paramDateTimeOffset, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET, null, Integer.valueOf(paramInt), paramBoolean);







    
    loggerExternal.exiting(getClassNameLogging(), "updateDateTimeOffset");
  }

  
  public void updateUniqueIdentifier(String paramString1, String paramString2) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateUniqueIdentifier", new Object[] { paramString1, paramString2 });
    }
    checkClosed();
    updateValue(findColumn(paramString1), JDBCType.GUID, paramString2, JavaType.STRING, null, false);






    
    loggerExternal.exiting(getClassNameLogging(), "updateUniqueIdentifier");
  }

  
  public void updateUniqueIdentifier(String paramString1, String paramString2, boolean paramBoolean) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateUniqueIdentifier", new Object[] { paramString1, paramString2, Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateValue(findColumn(paramString1), JDBCType.GUID, paramString2, JavaType.STRING, null, paramBoolean);






    
    loggerExternal.exiting(getClassNameLogging(), "updateUniqueIdentifier");
  }

  
  public void updateObject(String paramString, Object paramObject, int paramInt) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { paramString, paramObject, Integer.valueOf(paramInt) });
    }
    checkClosed();
    updateObject(findColumn(paramString), paramObject, Integer.valueOf(paramInt), null, null, false);






    
    loggerExternal.exiting(getClassNameLogging(), "updateObject");
  }

  
  public void updateObject(String paramString, Object paramObject, int paramInt1, int paramInt2) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { paramString, paramObject, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) });
    }
    checkClosed();
    updateObject(findColumn(paramString), paramObject, Integer.valueOf(paramInt2), null, Integer.valueOf(paramInt1), false);






    
    loggerExternal.exiting(getClassNameLogging(), "updateObject");
  }

  
  public void updateObject(String paramString, Object paramObject, int paramInt1, int paramInt2, boolean paramBoolean) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { paramString, paramObject, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean) });
    }
    checkClosed();
    updateObject(findColumn(paramString), paramObject, Integer.valueOf(paramInt2), null, Integer.valueOf(paramInt1), paramBoolean);






    
    loggerExternal.exiting(getClassNameLogging(), "updateObject");
  }

  
  public void updateObject(String paramString, Object paramObject, SQLType paramSQLType, int paramInt) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { paramString, paramObject, paramSQLType, Integer.valueOf(paramInt) });
    }
    checkClosed();

    
    updateObject(findColumn(paramString), paramObject, Integer.valueOf(paramInt), JDBCType.of(paramSQLType.getVendorTypeNumber().intValue()), null, false);






    
    loggerExternal.exiting(getClassNameLogging(), "updateObject");
  }

  
  public void updateObject(String paramString, Object paramObject, SQLType paramSQLType, int paramInt, boolean paramBoolean) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { paramString, paramObject, paramSQLType, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) });
    }
    checkClosed();

    
    updateObject(findColumn(paramString), paramObject, Integer.valueOf(paramInt), JDBCType.of(paramSQLType.getVendorTypeNumber().intValue()), null, paramBoolean);






    
    loggerExternal.exiting(getClassNameLogging(), "updateObject");
  }

  
  public void updateObject(String paramString, Object paramObject) throws SQLServerException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { paramString, paramObject });
    }
    checkClosed();
    updateObject(findColumn(paramString), paramObject, (Integer)null, null, null, false);






    
    loggerExternal.exiting(getClassNameLogging(), "updateObject");
  }

  
  public void updateObject(String paramString, Object paramObject, SQLType paramSQLType) throws SQLServerException {
    DriverJDBCVersion.checkSupportsJDBC42();
    
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { paramString, paramObject, paramSQLType });
    }
    checkClosed();

    
    updateObject(findColumn(paramString), paramObject, (Integer)null, JDBCType.of(paramSQLType.getVendorTypeNumber().intValue()), null, false);






    
    loggerExternal.exiting(getClassNameLogging(), "updateObject");
  }

  
  public void updateRowId(int paramInt, RowId paramRowId) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();

    
    throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
  }

  
  public void updateRowId(String paramString, RowId paramRowId) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();

    
    throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
  }

  
  public void updateSQLXML(int paramInt, SQLXML paramSQLXML) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "updateSQLXML", new Object[] { Integer.valueOf(paramInt), paramSQLXML }); 
    updateSQLXMLInternal(paramInt, paramSQLXML);
    loggerExternal.exiting(getClassNameLogging(), "updateSQLXML");
  }

  
  public void updateSQLXML(String paramString, SQLXML paramSQLXML) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER))
      loggerExternal.entering(getClassNameLogging(), "updateSQLXML", new Object[] { paramString, paramSQLXML }); 
    DriverJDBCVersion.checkSupportsJDBC4();
    updateSQLXMLInternal(findColumn(paramString), paramSQLXML);
    loggerExternal.exiting(getClassNameLogging(), "updateSQLXML");
  }

  
  public int getHoldability() throws SQLException {
    loggerExternal.entering(getClassNameLogging(), "getHoldability");
    
    DriverJDBCVersion.checkSupportsJDBC4();
    checkClosed();
    
    boolean bool = (0 == this.stmt.getServerCursorId()) ? true : this.stmt.getExecProps().getHoldability();









    
    loggerExternal.exiting(getClassNameLogging(), "getHoldability", Integer.valueOf(bool));
    
    return bool;
  }



  
  public void insertRow() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "insertRow");
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    final class InsertRowRPC
      extends TDSCommand
    {
      final String tableName;

      
      InsertRowRPC(String param1String) {
        super("InsertRowRPC", 0);
        this.tableName = param1String;
      }

      
      final boolean doExecute() throws SQLServerException {
        SQLServerResultSet.this.doInsertRowRPC(this, this.tableName);
        return true;
      }
    };
    
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + logCursorState());
    }
    checkClosed();


    
    verifyResultSetIsUpdatable();
    
    if (!this.isOnInsertRow)
    {
      SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_mustBeOnInsertRow"), (String)null, true);
    }




















    
    Column column = null;
    for (byte b = 0; b < this.columns.length; b++) {
      
      if (this.columns[b].hasUpdates()) {
        
        column = this.columns[b];
        
        break;
      } 
      if (null == column && this.columns[b].isUpdatable()) {
        column = this.columns[b];
      }
    } 
    if (null == column)
    {
      SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_noColumnParameterValue"), (String)null, true);
    }





    
    assert column.isUpdatable();
    assert null != column.getTableName();
    
    this.stmt.executeCommand(new InsertRowRPC(column.getTableName().asEscapedString()));
    
    if (-3 != this.rowCount)
      this.rowCount++; 
    loggerExternal.exiting(getClassNameLogging(), "insertRow");
  }

  
  private final void doInsertRowRPC(TDSCommand paramTDSCommand, String paramString) throws SQLServerException {
    assert 0 != this.serverCursorId;
    assert null != paramString;
    assert paramString.length() > 0;
    
    TDSWriter tDSWriter = paramTDSCommand.startRequest((byte)3);
    tDSWriter.writeShort((short)-1);
    tDSWriter.writeShort((short)1);
    tDSWriter.writeByte((byte)0);
    tDSWriter.writeByte((byte)0);
    tDSWriter.writeRPCInt(null, new Integer(this.serverCursorId), false);
    tDSWriter.writeRPCInt(null, new Integer(4), false);
    tDSWriter.writeRPCInt(null, new Integer(fetchBufferGetRow()), false);
    
    if (hasUpdatedColumns()) {
      
      tDSWriter.writeRPCStringUnicode(paramString);
      
      for (byte b = 0; b < this.columns.length; b++) {
        this.columns[b].sendByRPC(tDSWriter, this.stmt.connection);
      }
    } else {
      
      tDSWriter.writeRPCStringUnicode("");
      tDSWriter.writeRPCStringUnicode("INSERT INTO " + paramString + " DEFAULT VALUES");
    } 
    
    TDSParser.parse(paramTDSCommand.startResponse(), paramTDSCommand.getLogContext());
  }


  
  public void updateRow() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "updateRow");
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    final class UpdateRowRPC
      extends TDSCommand
    {
      UpdateRowRPC() {
        super("UpdateRowRPC", 0);
      }

      
      final boolean doExecute() throws SQLServerException {
        SQLServerResultSet.this.doUpdateRowRPC(this);
        return true;
      }
    };
    
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + logCursorState());
    }
    checkClosed();


    
    verifyResultSetIsUpdatable();



    
    verifyResultSetIsNotOnInsertRow();
    verifyResultSetHasCurrentRow();

    
    verifyCurrentRowIsNotDeleted("R_cantUpdateDeletedRow");
    
    if (!hasUpdatedColumns())
    {
      SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_noColumnParameterValue"), (String)null, true);
    }







    
    try {
      this.stmt.executeCommand(new UpdateRowRPC());
    }
    finally {
      
      cancelUpdates();
    } 
    
    this.updatedCurrentRow = true;
    loggerExternal.exiting(getClassNameLogging(), "updateRow");
  }

  
  private final void doUpdateRowRPC(TDSCommand paramTDSCommand) throws SQLServerException {
    assert 0 != this.serverCursorId;
    
    TDSWriter tDSWriter = paramTDSCommand.startRequest((byte)3);
    tDSWriter.writeShort((short)-1);
    tDSWriter.writeShort((short)1);
    tDSWriter.writeByte((byte)0);
    tDSWriter.writeByte((byte)0);
    tDSWriter.writeRPCInt(null, new Integer(this.serverCursorId), false);
    tDSWriter.writeRPCInt(null, new Integer(33), false);
    tDSWriter.writeRPCInt(null, new Integer(fetchBufferGetRow()), false);
    tDSWriter.writeRPCStringUnicode("");
    
    assert hasUpdatedColumns();
    
    for (byte b = 0; b < this.columns.length; b++) {
      this.columns[b].sendByRPC(tDSWriter, this.stmt.connection);
    }
    TDSParser.parse(paramTDSCommand.startResponse(), paramTDSCommand.getLogContext());
  }


  
  final boolean hasUpdatedColumns() {
    for (byte b = 0; b < this.columns.length; b++) {
      if (this.columns[b].hasUpdates())
        return true; 
    } 
    return false;
  }

  
  public void deleteRow() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "deleteRow");
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    final class DeleteRowRPC
      extends TDSCommand
    {
      DeleteRowRPC() {
        super("DeleteRowRPC", 0);
      }

      
      final boolean doExecute() throws SQLServerException {
        SQLServerResultSet.this.doDeleteRowRPC(this);
        return true;
      }
    };
    
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + logCursorState());
    }
    checkClosed();


    
    verifyResultSetIsUpdatable();

    
    verifyResultSetIsNotOnInsertRow();
    verifyResultSetHasCurrentRow();

    
    verifyCurrentRowIsNotDeleted("R_cantUpdateDeletedRow");

    
    try {
      this.stmt.executeCommand(new DeleteRowRPC());
    }
    finally {
      
      cancelUpdates();
    } 
    
    this.deletedCurrentRow = true;
    loggerExternal.exiting(getClassNameLogging(), "deleteRow");
  }

  
  private final void doDeleteRowRPC(TDSCommand paramTDSCommand) throws SQLServerException {
    assert 0 != this.serverCursorId;
    
    TDSWriter tDSWriter = paramTDSCommand.startRequest((byte)3);
    tDSWriter.writeShort((short)-1);
    tDSWriter.writeShort((short)1);
    tDSWriter.writeByte((byte)0);
    tDSWriter.writeByte((byte)0);
    tDSWriter.writeRPCInt(null, new Integer(this.serverCursorId), false);
    tDSWriter.writeRPCInt(null, new Integer(34), false);
    tDSWriter.writeRPCInt(null, new Integer(fetchBufferGetRow()), false);
    tDSWriter.writeRPCStringUnicode("");
    
    TDSParser.parse(paramTDSCommand.startResponse(), paramTDSCommand.getLogContext());
  }

  
  public void refreshRow() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "refreshRow");
    if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
    {
      loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
    }
    
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + logCursorState());
    }
    checkClosed();


    
    verifyResultSetIsScrollable();


    
    verifyResultSetIsUpdatable();


    
    verifyResultSetIsNotOnInsertRow();

    
    verifyResultSetHasCurrentRow();
    verifyCurrentRowIsNotDeleted("R_cantUpdateDeletedRow");





    
    if (1004 == this.stmt.getResultSetType() || 0 == this.serverCursorId) {
      return;
    }


    
    cancelUpdates();
    
    doRefreshRow();
    loggerExternal.exiting(getClassNameLogging(), "refreshRow");
  }

  
  private void doRefreshRow() throws SQLServerException {
    assert hasCurrentRow();


    
    int i = fetchBufferGetRow();


    
    doServerFetch(128, 0, 0);




    
    byte b = 0;
    while (b < i && (isForwardOnly() ? fetchBufferNext() : this.scrollWindow.next(this)))
    {
      
      b++;
    }
    
    if (b < i) {
      
      this.currentRow = -1;

      
      return;
    } 
    
    this.updatedCurrentRow = false;
  }

  
  private final void cancelUpdates() {
    if (!this.isOnInsertRow) {
      clearColumnsValues();
    }
  }
  
  public void cancelRowUpdates() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "cancelRowUpdates");
    checkClosed();



    
    verifyResultSetIsUpdatable();
    verifyResultSetIsNotOnInsertRow();
    
    cancelUpdates();
    loggerExternal.exiting(getClassNameLogging(), "cancelRowUpdates");
  }

  
  public void moveToInsertRow() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "moveToInsertRow");
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + logCursorState());
    }
    checkClosed();


    
    verifyResultSetIsUpdatable();
    
    cancelUpdates();
    this.isOnInsertRow = true;
    loggerExternal.exiting(getClassNameLogging(), "moveToInsertRow");
  }

  
  public void moveToCurrentRow() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "moveToCurrentRow");
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + logCursorState());
    }
    checkClosed();


    
    verifyResultSetIsUpdatable();




    
    cancelInsert();
    loggerExternal.exiting(getClassNameLogging(), "moveToCurrentRow");
  }


  
  public Statement getStatement() throws SQLServerException {
    loggerExternal.entering(getClassNameLogging(), "getStatement");
    checkClosed();
    loggerExternal.exiting(getClassNameLogging(), "getStatement", this.stmt);
    return this.stmt;
  }



  
  public void updateClob(int paramInt, Clob paramClob) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { Integer.valueOf(paramInt), paramClob });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.CLOB, paramClob, JavaType.CLOB, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateClob");
  }

  
  public void updateClob(int paramInt, Reader paramReader) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { Integer.valueOf(paramInt), paramReader });
    }
    checkClosed();
    updateStream(paramInt, StreamType.CHARACTER, paramReader, JavaType.READER, -1L);





    
    loggerExternal.exiting(getClassNameLogging(), "updateClob");
  }

  
  public void updateClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { Integer.valueOf(paramInt), paramReader, Long.valueOf(paramLong) });
    }
    checkClosed();
    updateStream(paramInt, StreamType.CHARACTER, paramReader, JavaType.READER, paramLong);





    
    loggerExternal.exiting(getClassNameLogging(), "updateClob");
  }

  
  public void updateClob(String paramString, Clob paramClob) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { paramString, paramClob });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.CLOB, paramClob, JavaType.CLOB, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateClob");
  }

  
  public void updateClob(String paramString, Reader paramReader) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { paramString, paramReader });
    }
    checkClosed();
    updateStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, -1L);





    
    loggerExternal.exiting(getClassNameLogging(), "updateClob");
  }

  
  public void updateClob(String paramString, Reader paramReader, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { paramString, paramReader, Long.valueOf(paramLong) });
    }
    checkClosed();
    updateStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, paramLong);





    
    loggerExternal.exiting(getClassNameLogging(), "updateClob");
  }

  
  public void updateNClob(int paramInt, NClob paramNClob) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { Integer.valueOf(paramInt), paramNClob });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.NCLOB, paramNClob, JavaType.NCLOB, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateNClob");
  }

  
  public void updateNClob(int paramInt, Reader paramReader) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateNClob", new Object[] { Integer.valueOf(paramInt), paramReader });
    }
    checkClosed();
    updateStream(paramInt, StreamType.NCHARACTER, paramReader, JavaType.READER, -1L);





    
    loggerExternal.exiting(getClassNameLogging(), "updateNClob");
  }

  
  public void updateNClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateNClob", new Object[] { Integer.valueOf(paramInt), paramReader, Long.valueOf(paramLong) });
    }
    checkClosed();
    updateStream(paramInt, StreamType.NCHARACTER, paramReader, JavaType.READER, paramLong);





    
    loggerExternal.exiting(getClassNameLogging(), "updateNClob");
  }

  
  public void updateNClob(String paramString, NClob paramNClob) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateNClob", new Object[] { paramString, paramNClob });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.NCLOB, paramNClob, JavaType.NCLOB, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateNClob");
  }

  
  public void updateNClob(String paramString, Reader paramReader) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateNClob", new Object[] { paramString, paramReader });
    }
    checkClosed();
    updateStream(findColumn(paramString), StreamType.NCHARACTER, paramReader, JavaType.READER, -1L);





    
    loggerExternal.exiting(getClassNameLogging(), "updateNClob");
  }

  
  public void updateNClob(String paramString, Reader paramReader, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateNClob", new Object[] { paramString, paramReader, Long.valueOf(paramLong) });
    }
    checkClosed();
    updateStream(findColumn(paramString), StreamType.NCHARACTER, paramReader, JavaType.READER, paramLong);





    
    loggerExternal.exiting(getClassNameLogging(), "updateNClob");
  }

  
  public void updateBlob(int paramInt, Blob paramBlob) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateBlob", new Object[] { Integer.valueOf(paramInt), paramBlob });
    }
    checkClosed();
    updateValue(paramInt, JDBCType.BLOB, paramBlob, JavaType.BLOB, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateBlob");
  }

  
  public void updateBlob(int paramInt, InputStream paramInputStream) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateBlob", new Object[] { Integer.valueOf(paramInt), paramInputStream });
    }
    checkClosed();
    updateStream(paramInt, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, -1L);





    
    loggerExternal.exiting(getClassNameLogging(), "updateBlob");
  }

  
  public void updateBlob(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateBlob", new Object[] { Integer.valueOf(paramInt), paramInputStream, Long.valueOf(paramLong) });
    }
    checkClosed();
    updateStream(paramInt, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramLong);





    
    loggerExternal.exiting(getClassNameLogging(), "updateBlob");
  }

  
  public void updateBlob(String paramString, Blob paramBlob) throws SQLException {
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateBlob", new Object[] { paramString, paramBlob });
    }
    checkClosed();
    updateValue(findColumn(paramString), JDBCType.BLOB, paramBlob, JavaType.BLOB, false);





    
    loggerExternal.exiting(getClassNameLogging(), "updateBlob");
  }

  
  public void updateBlob(String paramString, InputStream paramInputStream) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateBlob", new Object[] { paramString, paramInputStream });
    }
    checkClosed();
    updateStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, -1L);





    
    loggerExternal.exiting(getClassNameLogging(), "updateBlob");
  }

  
  public void updateBlob(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
    DriverJDBCVersion.checkSupportsJDBC4();
    if (loggerExternal.isLoggable(Level.FINER)) {
      loggerExternal.entering(getClassNameLogging(), "updateBlob", new Object[] { paramString, paramInputStream, Long.valueOf(paramLong) });
    }
    checkClosed();
    updateStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramLong);





    
    loggerExternal.exiting(getClassNameLogging(), "updateBlob");
  }
  
  public void updateArray(int paramInt, Array paramArray) throws SQLServerException {
    this.stmt.NotImplemented();
  }
  public void updateArray(String paramString, Array paramArray) throws SQLServerException {
    this.stmt.NotImplemented();
  }
  public void updateRef(int paramInt, Ref paramRef) throws SQLServerException {
    this.stmt.NotImplemented();
  }
  public void updateRef(String paramString, Ref paramRef) throws SQLServerException {
    this.stmt.NotImplemented();
  }
  public URL getURL(int paramInt) throws SQLServerException {
    this.stmt.NotImplemented();
    return null;
  }
  public URL getURL(String paramString) throws SQLServerException {
    this.stmt.NotImplemented();
    return null;
  }
























  
  private final class FetchBuffer
  {
    private final class FetchBufferTokenHandler
      extends TDSTokenHandler
    {
      FetchBufferTokenHandler() {
        super("FetchBufferTokenHandler");
      }




      
      boolean onColMetaData(TDSReader param2TDSReader) throws SQLServerException {
        (new StreamColumns(Util.shouldHonorAEForRead(SQLServerResultSet.this.stmt.stmtColumnEncriptionSetting, SQLServerResultSet.this.stmt.connection))).setFromTDS(param2TDSReader);
        return true;
      }

      
      boolean onRow(TDSReader param2TDSReader) throws SQLServerException {
        SQLServerResultSet.FetchBuffer.this.ensureStartMark();


        
        if (209 != param2TDSReader.readUnsignedByte() && !$assertionsDisabled) throw new AssertionError(); 
        SQLServerResultSet.FetchBuffer.this.fetchBufferCurrentRowType = RowType.ROW;
        return false;
      }

      
      boolean onNBCRow(TDSReader param2TDSReader) throws SQLServerException {
        SQLServerResultSet.FetchBuffer.this.ensureStartMark();


        
        if (210 != param2TDSReader.readUnsignedByte() && !$assertionsDisabled) throw new AssertionError();
        
        SQLServerResultSet.FetchBuffer.this.fetchBufferCurrentRowType = RowType.NBCROW;
        return false;
      }

      
      boolean onDone(TDSReader param2TDSReader) throws SQLServerException {
        SQLServerResultSet.FetchBuffer.this.ensureStartMark();

        
        StreamDone streamDone = new StreamDone();
        streamDone.setFromTDS(param2TDSReader);



        
        SQLServerResultSet.FetchBuffer.this.done = true;
        return (0 != SQLServerResultSet.this.serverCursorId);
      }




      
      boolean onRetStatus(TDSReader param2TDSReader) throws SQLServerException {
        StreamRetStatus streamRetStatus = new StreamRetStatus();
        streamRetStatus.setFromTDS(param2TDSReader);
        SQLServerResultSet.FetchBuffer.this.needsServerCursorFixup = (2 == streamRetStatus.getStatus());
        return true;
      }


      
      void onEOF(TDSReader param2TDSReader) throws SQLServerException {
        super.onEOF(param2TDSReader);
        SQLServerResultSet.FetchBuffer.this.done = true;
      }
    }
    
    private final FetchBufferTokenHandler fetchBufferTokenHandler = new FetchBufferTokenHandler();
    private TDSReaderMark startMark;
    
    final void clearStartMark() {
      this.startMark = null;
    }
    private RowType fetchBufferCurrentRowType = RowType.UNKNOWN; private boolean done; private boolean needsServerCursorFixup;
    
    final boolean needsServerCursorFixup() {
      return this.needsServerCursorFixup;
    }
    
    FetchBuffer() {
      init();
    }

    
    final void ensureStartMark() {
      if (null == this.startMark && !SQLServerResultSet.this.isForwardOnly()) {
        
        if (SQLServerResultSet.logger.isLoggable(Level.FINEST)) {
          SQLServerResultSet.logger.finest(toString() + " Setting fetch buffer start mark");
        }
        this.startMark = SQLServerResultSet.this.tdsReader.mark();
      } 
    }




    
    final void reset() {
      assert null != SQLServerResultSet.this.tdsReader;
      assert null != this.startMark;
      
      SQLServerResultSet.this.tdsReader.reset(this.startMark);
      this.fetchBufferCurrentRowType = RowType.UNKNOWN;
      this.done = false;
    }






    
    final void init() {
      this.startMark = (0 == SQLServerResultSet.this.serverCursorId && !SQLServerResultSet.this.isForwardOnly()) ? SQLServerResultSet.this.tdsReader.mark() : null;
      this.fetchBufferCurrentRowType = RowType.UNKNOWN;
      this.done = false;
      this.needsServerCursorFixup = false;
    }




    
    final RowType nextRow() throws SQLServerException {
      this.fetchBufferCurrentRowType = RowType.UNKNOWN;
      
      while (null != SQLServerResultSet.this.tdsReader && !this.done && this.fetchBufferCurrentRowType.equals(RowType.UNKNOWN)) {
        TDSParser.parse(SQLServerResultSet.this.tdsReader, this.fetchBufferTokenHandler);
      }
      if (this.fetchBufferCurrentRowType.equals(RowType.UNKNOWN) && null != this.fetchBufferTokenHandler.getDatabaseError())
      {
        SQLServerException.makeFromDatabaseError(SQLServerResultSet.this.stmt.connection, (Object)null, this.fetchBufferTokenHandler.getDatabaseError().getMessage(), this.fetchBufferTokenHandler.getDatabaseError(), false);
      }





      
      return this.fetchBufferCurrentRowType;
    }
  }

  
  private final class CursorFetchCommand
    extends TDSCommand
  {
    private final int serverCursorId;
    
    private int fetchType;
    
    private int startRow;
    
    private int numRows;
    
    CursorFetchCommand(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      super("doServerFetch", SQLServerResultSet.this.stmt.queryTimeout);
      this.serverCursorId = param1Int1;
      this.fetchType = param1Int2;
      this.startRow = param1Int3;
      this.numRows = param1Int4;
    }

    
    final boolean doExecute() throws SQLServerException {
      TDSWriter tDSWriter = startRequest((byte)3);
      tDSWriter.writeShort((short)-1);
      tDSWriter.writeShort((short)7);
      tDSWriter.writeByte((byte)2);
      tDSWriter.writeByte((byte)0);
      tDSWriter.writeRPCInt(null, new Integer(this.serverCursorId), false);
      tDSWriter.writeRPCInt(null, new Integer(this.fetchType), false);
      tDSWriter.writeRPCInt(null, new Integer(this.startRow), false);
      tDSWriter.writeRPCInt(null, new Integer(this.numRows), false);






      
      SQLServerResultSet.this.tdsReader = startResponse((SQLServerResultSet.this.isForwardOnly() && 1007 != SQLServerResultSet.this.stmt.resultSetConcurrency && SQLServerResultSet.this.stmt.getExecProps().wasResponseBufferingSet() && SQLServerResultSet.this.stmt.getExecProps().isResponseBufferingAdaptive()));




      
      return false;
    }

    
    final void processResponse(TDSReader param1TDSReader) throws SQLServerException {
      SQLServerResultSet.this.tdsReader = param1TDSReader;
      SQLServerResultSet.this.discardFetchBuffer();
    }
  }









  
  final void doServerFetch(int paramInt1, int paramInt2, int paramInt3) throws SQLServerException {
    if (logger.isLoggable(Level.FINER)) {
      logger.finer(toString() + " fetchType:" + paramInt1 + " startRow:" + paramInt2 + " numRows:" + paramInt3);
    }
    
    discardFetchBuffer();

    
    this.fetchBuffer.init();

    
    CursorFetchCommand cursorFetchCommand = new CursorFetchCommand(this.serverCursorId, paramInt1, paramInt2, paramInt3);
    this.stmt.executeCommand(cursorFetchCommand);
    
    this.numFetchedRows = 0;
    this.resultSetCurrentRowType = RowType.UNKNOWN;
    this.areNullCompressedColumnsInitialized = false;
    this.lastColumnIndex = 0;

    
    if (null != this.scrollWindow && 128 != paramInt1) {
      this.scrollWindow.resize(this.fetchSize);
    }






    
    if (paramInt3 < 0 || paramInt2 < 0) {

      
      try {
        
        while (this.scrollWindow.next(this));
      
      }
      catch (SQLException sQLException) {



        
        if (logger.isLoggable(Level.FINER)) {
          logger.finer(toString() + " Ignored exception from row error during server cursor fixup: " + sQLException.getMessage());
        }
      } 
      
      if (this.fetchBuffer.needsServerCursorFixup()) {
        
        doServerFetch(1, 0, 0);
        
        return;
      } 
      
      this.scrollWindow.reset();
    } 
  }
















  
  private final void discardFetchBuffer() {
    this.fetchBuffer.clearStartMark();

    
    if (null != this.scrollWindow) {
      this.scrollWindow.clear();
    }


    
    try {
      while (fetchBufferNext());
    
    }
    catch (SQLServerException sQLServerException) {
      
      if (logger.isLoggable(Level.FINER)) {
        logger.finer(this + " Encountered exception discarding fetch buffer: " + sQLServerException.getMessage());
      }
    } 
  }





  
  final void closeServerCursor() {
    if (0 == this.serverCursorId) {
      return;
    }

    
    if (this.stmt.connection.isSessionUnAvailable()) {
      
      if (logger.isLoggable(Level.FINER)) {
        logger.finer(this + ": Not closing cursor:" + this.serverCursorId + "; connection is already closed.");
      }
    } else {
      
      if (logger.isLoggable(Level.FINER)) {
        logger.finer(toString() + " Closing cursor:" + this.serverCursorId);
      }





















      
      try {
        this.stmt.executeCommand(new CloseServerCursorCommand());
      }
      catch (SQLServerException sQLServerException) {
        
        if (logger.isLoggable(Level.FINER)) {
          logger.finer(toString() + " Ignored error closing cursor:" + this.serverCursorId + " " + sQLServerException.getMessage());
        }
      } 
      if (logger.isLoggable(Level.FINER))
        logger.finer(toString() + " Closed cursor:" + this.serverCursorId); 
    } 
  }
}
