package com.microsoft.sqlserver.jdbc;



public enum SQLServerStatementColumnEncryptionSetting
{
  UseConnectionSetting,



  
  Enabled,




  
  ResultSetOnly,



  
  Disabled;
}
