package com.microsoft.sqlserver.jdbc;























































































































final class ServerPortPlaceHolder
{
  private final String serverName;
  private final int port;
  private final String instanceName;
  private final boolean checkLink;
  private final SQLServerConnectionSecurityManager securityManager;
  
  ServerPortPlaceHolder(String paramString1, int paramInt, String paramString2, boolean paramBoolean) {
    this.serverName = paramString1;
    this.port = paramInt;
    this.instanceName = paramString2;
    this.checkLink = paramBoolean;
    this.securityManager = new SQLServerConnectionSecurityManager(this.serverName, this.port);
    doSecurityCheck();
  }
  
  int getPortNumber() {
    return this.port;
  } String getServerName() { return this.serverName; } String getInstanceName() {
    return this.instanceName;
  }
  void doSecurityCheck() {
    this.securityManager.checkConnect();
    if (this.checkLink)
      this.securityManager.checkLink(); 
  }
}
