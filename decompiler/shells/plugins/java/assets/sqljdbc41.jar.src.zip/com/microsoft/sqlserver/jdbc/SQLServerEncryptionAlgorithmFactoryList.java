package com.microsoft.sqlserver.jdbc;

import java.text.MessageFormat;
import java.util.concurrent.ConcurrentHashMap;







final class SQLServerEncryptionAlgorithmFactoryList
{
  private ConcurrentHashMap<String, SQLServerEncryptionAlgorithmFactory> encryptionAlgoFactoryMap;
  private static final SQLServerEncryptionAlgorithmFactoryList instance = new SQLServerEncryptionAlgorithmFactoryList();
  
  private SQLServerEncryptionAlgorithmFactoryList() {
    this.encryptionAlgoFactoryMap = new ConcurrentHashMap<>();
    this.encryptionAlgoFactoryMap.putIfAbsent("AEAD_AES_256_CBC_HMAC_SHA256", new SQLServerAeadAes256CbcHmac256Factory());
  }
  
  static SQLServerEncryptionAlgorithmFactoryList getInstance() {
    return instance;
  }



  
  String getRegisteredCipherAlgorithmNames() {
    StringBuffer stringBuffer = new StringBuffer();
    boolean bool = true;
    for (String str : this.encryptionAlgoFactoryMap.keySet()) {
      if (bool) {
        stringBuffer.append("'");
        bool = false;
      } else {
        stringBuffer.append(", '");
      } 
      stringBuffer.append(str);
      stringBuffer.append("'");
    } 
    
    return stringBuffer.toString();
  }








  
  SQLServerEncryptionAlgorithm getAlgorithm(SQLServerSymmetricKey paramSQLServerSymmetricKey, SQLServerEncryptionType paramSQLServerEncryptionType, String paramString) throws SQLServerException {
    SQLServerEncryptionAlgorithm sQLServerEncryptionAlgorithm = null;
    SQLServerEncryptionAlgorithmFactory sQLServerEncryptionAlgorithmFactory = null;
    if (!this.encryptionAlgoFactoryMap.containsKey(paramString)) {
      MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_UnknownColumnEncryptionAlgorithm"));
      Object[] arrayOfObject = { paramString, getInstance().getRegisteredCipherAlgorithmNames() };
      throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
    } 
    
    sQLServerEncryptionAlgorithmFactory = this.encryptionAlgoFactoryMap.get(paramString);
    assert null != sQLServerEncryptionAlgorithmFactory : "Null Algorithm Factory class detected";
    sQLServerEncryptionAlgorithm = sQLServerEncryptionAlgorithmFactory.create(paramSQLServerSymmetricKey, paramSQLServerEncryptionType, paramString);
    return sQLServerEncryptionAlgorithm;
  }
}
