package com.microsoft.sqlserver.jdbc;

import java.io.IOException;













class PLPInputStream
  extends BaseInputStream
{
  static final long PLP_NULL = -1L;
  static final long UNKNOWN_PLP_LEN = -2L;
  static final int PLP_TERMINATOR = 0;
  private static final byte[] EMPTY_PLP_BYTES = new byte[0];
  
  int payloadLength;
  
  private static final int PLP_EOS = -1;
  
  private int currentChunkRemain;
  
  private int markedChunkRemain;
  
  private int leftOverReadLimit = 0;
  
  private byte[] oneByteArray = new byte[1];




  
  static final boolean isNull(TDSReader paramTDSReader) throws SQLServerException {
    TDSReaderMark tDSReaderMark = paramTDSReader.mark();
    
    try {
      return (null == makeTempStream(paramTDSReader, false, (ServerDTVImpl)null));
    }
    finally {
      
      paramTDSReader.reset(tDSReaderMark);
    } 
  }





  
  static final PLPInputStream makeTempStream(TDSReader paramTDSReader, boolean paramBoolean, ServerDTVImpl paramServerDTVImpl) throws SQLServerException {
    return makeStream(paramTDSReader, paramBoolean, paramBoolean, paramServerDTVImpl);
  }

  
  static final PLPInputStream makeStream(TDSReader paramTDSReader, InputStreamGetterArgs paramInputStreamGetterArgs, ServerDTVImpl paramServerDTVImpl) throws SQLServerException {
    PLPInputStream pLPInputStream = makeStream(paramTDSReader, paramInputStreamGetterArgs.isAdaptive, paramInputStreamGetterArgs.isStreaming, paramServerDTVImpl);
    if (null != pLPInputStream)
      pLPInputStream.setLoggingInfo(paramInputStreamGetterArgs.logContext); 
    return pLPInputStream;
  }


  
  private static final PLPInputStream makeStream(TDSReader paramTDSReader, boolean paramBoolean1, boolean paramBoolean2, ServerDTVImpl paramServerDTVImpl) throws SQLServerException {
    long l = paramTDSReader.readLong();

    
    if (-1L == l) {
      return null;
    }
    return new PLPInputStream(paramTDSReader, l, paramBoolean1, paramBoolean2, paramServerDTVImpl);
  }





  
  PLPInputStream(TDSReader paramTDSReader, long paramLong, boolean paramBoolean1, boolean paramBoolean2, ServerDTVImpl paramServerDTVImpl) throws SQLServerException {
    super(paramTDSReader, paramBoolean1, paramBoolean2, paramServerDTVImpl);
    this.payloadLength = (-2L != paramLong) ? (int)paramLong : -1;
    this.currentChunkRemain = this.markedChunkRemain = 0;
  }









  
  byte[] getBytes() throws SQLServerException {
    byte[] arrayOfByte;
    readBytesInternal((byte[])null, 0, 0);
    
    if (-1 == this.currentChunkRemain) {
      
      arrayOfByte = EMPTY_PLP_BYTES;

    
    }
    else {

      
      arrayOfByte = new byte[(-1 != this.payloadLength) ? this.payloadLength : this.currentChunkRemain];
      
      int i = 0;
      while (-1 != this.currentChunkRemain) {


        
        if (arrayOfByte.length == i) {
          
          byte[] arrayOfByte1 = new byte[i + this.currentChunkRemain];
          System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, i);
          arrayOfByte = arrayOfByte1;
        } 
        
        i += readBytesInternal(arrayOfByte, i, this.currentChunkRemain);
      } 
    } 


    
    try {
      close();
    }
    catch (IOException iOException) {
      
      SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, iOException.getMessage(), (String)null, true);
    } 





    
    return arrayOfByte;
  }







  
  public long skip(long paramLong) throws IOException {
    checkClosed();
    if (paramLong < 0L) return 0L; 
    if (paramLong > 2147483647L) {
      paramLong = 2147483647L;
    }
    long l = readBytes((byte[])null, 0, (int)paramLong);

    
    if (-1L == l) {
      return 0L;
    }
    return l;
  }








  
  public int available() throws IOException {
    checkClosed();



    
    try {
      if (0 == this.currentChunkRemain) {
        readBytesInternal((byte[])null, 0, 0);
      }
      if (-1 == this.currentChunkRemain) {
        return 0;
      }


      
      int i = this.tdsReader.available();
      if (i > this.currentChunkRemain) {
        i = this.currentChunkRemain;
      }
      return i;
    }
    catch (SQLServerException sQLServerException) {
      
      throw new IOException(sQLServerException.getMessage());
    } 
  }








  
  public int read() throws IOException {
    checkClosed();
    
    if (-1 != readBytes(this.oneByteArray, 0, 1))
      return this.oneByteArray[0] & 0xFF; 
    return -1;
  }








  
  public int read(byte[] paramArrayOfbyte) throws IOException {
    if (null == paramArrayOfbyte) {
      throw new NullPointerException();
    }
    checkClosed();
    
    return readBytes(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }










  
  public int read(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
    if (null == paramArrayOfbyte) {
      throw new NullPointerException();
    }


    
    if (paramInt1 < 0 || paramInt2 < 0 || paramInt1 + paramInt2 > paramArrayOfbyte.length) {
      throw new IndexOutOfBoundsException();
    }
    checkClosed();
    
    return readBytes(paramArrayOfbyte, paramInt1, paramInt2);
  }












  
  int readBytes(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
    if (0 == paramInt2) {
      return 0;
    }
    
    try {
      return readBytesInternal(paramArrayOfbyte, paramInt1, paramInt2);
    }
    catch (SQLServerException sQLServerException) {
      
      throw new IOException(sQLServerException.getMessage());
    } 
  }




  
  private int readBytesInternal(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLServerException {
    if (-1 == this.currentChunkRemain) {
      return -1;
    }



    
    int i = 0;



    
    while (true) {
      if (0 == this.currentChunkRemain) {
        
        this.currentChunkRemain = (int)this.tdsReader.readUnsignedInt();
        assert this.currentChunkRemain >= 0;
        if (0 == this.currentChunkRemain) {
          
          this.currentChunkRemain = -1;
          
          break;
        } 
      } 
      if (i == paramInt2) {
        break;
      }


      
      int j = paramInt2 - i;
      if (j > this.currentChunkRemain) {
        j = this.currentChunkRemain;
      }
      
      if (null == paramArrayOfbyte) {
        this.tdsReader.skip(j);
      } else {
        this.tdsReader.readBytes(paramArrayOfbyte, paramInt1 + i, j);
      } 
      i += j;
      this.currentChunkRemain -= j;
    } 
    
    if (i > 0) {
      
      if (this.isReadLimitSet && this.leftOverReadLimit > 0) {
        
        this.leftOverReadLimit -= i;
        if (this.leftOverReadLimit < 0)
          clearCurrentMark(); 
      } 
      return i;
    } 
    
    if (-1 == this.currentChunkRemain) {
      return -1;
    }
    return 0;
  }







  
  public void mark(int paramInt) {
    if (null != this.tdsReader && paramInt > 0) {
      
      this.currentMark = this.tdsReader.mark();
      this.markedChunkRemain = this.currentChunkRemain;
      this.leftOverReadLimit = paramInt;
      setReadLimit(paramInt);
    } 
  }



  
  public void close() throws IOException {
    if (null == this.tdsReader) {
      return;
    }
    while (skip(this.tdsReader.getConnection().getTDSPacketSize()) != 0L);

    
    closeHelper();
  }





  
  public void reset() throws IOException {
    resetHelper();
    this.leftOverReadLimit = this.readLimit;
    this.currentChunkRemain = this.markedChunkRemain;
  }
}
