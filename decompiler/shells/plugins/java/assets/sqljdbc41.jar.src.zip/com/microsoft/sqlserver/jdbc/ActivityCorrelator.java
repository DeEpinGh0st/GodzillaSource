package com.microsoft.sqlserver.jdbc;








final class ActivityCorrelator
{
  private static ThreadLocal<ActivityId> ActivityIdTls = new ThreadLocal<ActivityId>()
    {
      protected ActivityId initialValue()
      {
        return new ActivityId();
      }
    };



  
  static ActivityId getCurrent() {
    return ActivityIdTls.get();
  }








  
  static ActivityId getNext() {
    ActivityId activityId = getCurrent();

    
    activityId.Increment();

    
    return activityId;
  }

  
  static void setCurrentActivityIdSentFlag() {
    ActivityId activityId = getCurrent();
    activityId.setSentFlag();
  }
}
