package microsoft.sql;

import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;













public final class DateTimeOffset
  implements Serializable, Comparable<DateTimeOffset>
{
  private static final long serialVersionUID = 541973748553014280L;
  private final long utcMillis;
  private final int nanos;
  private final int minutesOffset;
  private static final int NANOS_MIN = 0;
  private static final int NANOS_MAX = 999999999;
  private static final int SS_NANOS_MAX = 9999999;
  private static final int MINUTES_OFFSET_MIN = -840;
  private static final int MINUTES_OFFSET_MAX = 840;
  private static final int HUNDRED_NANOS_PER_SECOND = 10000000;
  
  private DateTimeOffset(Timestamp paramTimestamp, int paramInt) {
    if (paramInt < -840 || paramInt > 840)
      throw new IllegalArgumentException(); 
    this.minutesOffset = paramInt;

    
    int i = paramTimestamp.getNanos();
    if (i < 0 || i > 999999999) {
      throw new IllegalArgumentException();
    }





    
    int j = (i + 50) / 100;
    this.nanos = 100 * j % 10000000;
    this.utcMillis = paramTimestamp.getTime() - (paramTimestamp.getNanos() / 1000000) + (1000 * j / 10000000);




    
    assert this.minutesOffset >= -840 && this.minutesOffset <= 840 : "minutesOffset: " + this.minutesOffset;
    assert this.nanos >= 0 && this.nanos <= 999999999 : "nanos: " + this.nanos;
    assert 0 == this.nanos % 100 : "nanos: " + this.nanos;
    assert 0L == this.utcMillis % 1000L : "utcMillis: " + this.utcMillis;
  }

  
  public static DateTimeOffset valueOf(Timestamp paramTimestamp, int paramInt) {
    return new DateTimeOffset(paramTimestamp, paramInt);
  }




  
  public static DateTimeOffset valueOf(Timestamp paramTimestamp, Calendar paramCalendar) {
    paramCalendar.setTimeInMillis(paramTimestamp.getTime());
    
    return new DateTimeOffset(paramTimestamp, (paramCalendar.get(15) + paramCalendar.get(16)) / 60000);
  }






  
  private String formattedValue = null;



  
  public String toString() {
    String str = this.formattedValue;
    if (null == str) {

      
      String str1 = (this.minutesOffset < 0) ? String.format(Locale.US, "-%1$02d:%2$02d", new Object[] { Integer.valueOf(-this.minutesOffset / 60), Integer.valueOf(-this.minutesOffset % 60) }) : String.format(Locale.US, "+%1$02d:%2$02d", new Object[] { Integer.valueOf(this.minutesOffset / 60), Integer.valueOf(this.minutesOffset % 60) });















      
      Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT" + str1), Locale.US);



      
      calendar.setTimeInMillis(this.utcMillis);


      
      assert this.nanos >= 0 && this.nanos <= 999999999;

      
      this.formattedValue = str = (0 == this.nanos) ? String.format(Locale.US, "%1$tF %1$tT %2$s", new Object[] { calendar, str1 }) : String.format(Locale.US, "%1$tF %1$tT.%2$s %3$s", new Object[] { calendar, BigDecimal.valueOf(this.nanos, 9).stripTrailingZeros().toPlainString().substring(2), str1 });
    } 
















    
    return str;
  }


  
  public boolean equals(Object paramObject) {
    if (this == paramObject) {
      return true;
    }
    
    if (!(paramObject instanceof DateTimeOffset)) {
      return false;
    }
    
    DateTimeOffset dateTimeOffset = (DateTimeOffset)paramObject;
    return (this.utcMillis == dateTimeOffset.utcMillis && this.nanos == dateTimeOffset.nanos && this.minutesOffset == dateTimeOffset.minutesOffset);
  }








  
  public int hashCode() {
    assert 0L == this.utcMillis % 1000L;
    long l = this.utcMillis / 1000L;
    
    int i = 571;
    i = 2011 * i + (int)l;
    i = 3217 * i + (int)(l / 60L * 60L * 24L * 365L);

    
    i = 3919 * i + this.nanos / 100000;
    i = 4463 * i + this.nanos / 1000;
    i = 5227 * i + this.nanos;


    
    i = 6689 * i + this.minutesOffset;
    i = 7577 * i + this.minutesOffset / 60;



    
    return i;
  }








  
  public Timestamp getTimestamp() {
    Timestamp timestamp = new Timestamp(this.utcMillis);
    timestamp.setNanos(this.nanos);
    return timestamp;
  }






  
  public int getMinutesOffset() {
    return this.minutesOffset;
  }

















  
  public int compareTo(DateTimeOffset paramDateTimeOffset) {
    assert this.nanos >= 0;
    assert paramDateTimeOffset.nanos >= 0;
    
    return (this.utcMillis > paramDateTimeOffset.utcMillis) ? 1 : ((this.utcMillis < paramDateTimeOffset.utcMillis) ? -1 : (this.nanos - paramDateTimeOffset.nanos));
  }

  
  private static class SerializationProxy
    implements Serializable
  {
    private final long utcMillis;
    
    private final int nanos;
    private final int minutesOffset;
    private static final long serialVersionUID = 664661379547314226L;
    
    SerializationProxy(DateTimeOffset param1DateTimeOffset) {
      this.utcMillis = param1DateTimeOffset.utcMillis;
      this.nanos = param1DateTimeOffset.nanos;
      this.minutesOffset = param1DateTimeOffset.minutesOffset;
    }



    
    private Object readResolve() {
      Timestamp timestamp = new Timestamp(this.utcMillis);
      timestamp.setNanos(this.nanos);
      return new DateTimeOffset(timestamp, this.minutesOffset);
    }
  }

  
  private Object writeReplace() {
    return new SerializationProxy(this);
  }







  
  private void readObject(ObjectInputStream paramObjectInputStream) throws InvalidObjectException {
    throw new InvalidObjectException("");
  }
}
