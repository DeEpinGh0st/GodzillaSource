package oracle.jdbc.rowset;

import java.io.BufferedReader;
import java.io.CharArrayReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringBufferInputStream;
import java.io.Writer;
import java.sql.Clob;
import java.sql.SQLException;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;



























public class OracleSerialClob
  implements Clob, Serializable, Cloneable
{
  private static final int MAX_CHAR_BUFFER_SIZE = 1024;
  private char[] buffer;
  private long length;
  private boolean isFreed = false;
  
  public OracleSerialClob(char[] paramArrayOfchar) throws SQLException {
    this.length = paramArrayOfchar.length;
    this.buffer = new char[(int)this.length];
    for (byte b = 0; b < this.length; b++) {
      this.buffer[b] = paramArrayOfchar[b];
    }
  }





  
  public OracleSerialClob(Clob paramClob) throws SQLException {
    this.length = paramClob.length();
    this.buffer = new char[(int)this.length];
    BufferedReader bufferedReader = new BufferedReader(paramClob.getCharacterStream());

    
    try {
      int i = 0;
      int j = 0;


      
      while (true)
      { i = bufferedReader.read(this.buffer, j, (int)(this.length - j));
        
        j += i;
        if (i <= 0)
          return;  } 
    } catch (IOException iOException) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 347, iOException.getMessage());
      sQLException.fillInStackTrace();
      throw sQLException;
    } finally {

      
      try {
        if (bufferedReader != null)
          bufferedReader.close(); 
      } catch (IOException iOException) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 347, iOException.getMessage());
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    } 
  }








  
  public OracleSerialClob(Reader paramReader) throws SQLException {
    try {
      int i = 0;
      char[] arrayOfChar = new char[1024];
      StringBuilder stringBuilder = new StringBuilder(1024);

      
      while (true) {
        i = paramReader.read(arrayOfChar);


        
        if (i == -1) {
          break;
        }
        stringBuilder.append(arrayOfChar, 0, i);
      } 
      
      paramReader.close();
      
      this.buffer = stringBuilder.toString().toCharArray();
      this.length = this.buffer.length;
    }
    catch (Exception exception) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 347, exception.getMessage());
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }








  
  public OracleSerialClob(Reader paramReader, long paramLong) throws SQLException {
    try {
      int i = 0;
      long l = paramLong;
      char[] arrayOfChar = new char[1024];
      StringBuilder stringBuilder = new StringBuilder(1024);
      
      while (l > 0L) {
        
        i = paramReader.read(arrayOfChar, 0, Math.min(1024, (int)l));



        
        if (i == -1) {
          break;
        }
        stringBuilder.append(arrayOfChar, 0, i);
        l -= i;
      } 
      
      paramReader.close();
      
      this.buffer = stringBuilder.toString().toCharArray();
      this.length = this.buffer.length;
    }
    catch (Exception exception) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 347, exception.getMessage());
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }







  
  public InputStream getAsciiStream() throws SQLException {
    if (this.isFreed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    return new StringBufferInputStream(new String(this.buffer));
  }





  
  public Reader getCharacterStream() throws SQLException {
    if (this.isFreed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    return new CharArrayReader(this.buffer);
  }







  
  public String getSubString(long paramLong, int paramInt) throws SQLException {
    if (this.isFreed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (paramLong < 1L || paramInt < 0 || paramInt > this.length || paramLong + paramInt - 1L > this.length) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    if (paramInt == 0) {
      return new String();
    }
    return new String(this.buffer, (int)paramLong - 1, paramInt);
  }






  
  public long length() throws SQLException {
    if (this.isFreed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    return this.length;
  }







  
  public long position(String paramString, long paramLong) throws SQLException {
    if (this.isFreed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (paramLong < 1L) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (paramLong > this.length || paramLong + paramString.length() - 1L > this.length) {
      return -1L;
    }
    char[] arrayOfChar = paramString.toCharArray();
    int i = (int)(paramLong - 1L);
    boolean bool = false;
    long l = arrayOfChar.length;
    
    while (i < this.length) {
      
      byte b = 0;
      long l1 = (i + 1);
      int j = i;
      while (b < l && j < this.length && arrayOfChar[b] == this.buffer[j]) {
        
        b++;
        j++;
        if (b == l) {
          return l1;
        }
      } 
      i++;
    } 
    return -1L;
  }





  
  public long position(Clob paramClob, long paramLong) throws SQLException {
    if (this.isFreed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    return position(paramClob.getSubString(1L, (int)paramClob.length()), paramLong);
  }

























  
  public int setString(long paramLong, String paramString) throws SQLException {
    if (this.isFreed) {
      
      SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
      sQLException1.fillInStackTrace();
      throw sQLException1;
    } 

    
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }


























  
  public int setString(long paramLong, String paramString, int paramInt1, int paramInt2) throws SQLException {
    if (this.isFreed) {
      
      SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
      sQLException1.fillInStackTrace();
      throw sQLException1;
    } 

    
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }






















  
  public OutputStream setAsciiStream(long paramLong) throws SQLException {
    if (this.isFreed) {
      
      SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
      sQLException1.fillInStackTrace();
      throw sQLException1;
    } 

    
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }























  
  public Writer setCharacterStream(long paramLong) throws SQLException {
    if (this.isFreed) {
      
      SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
      sQLException1.fillInStackTrace();
      throw sQLException1;
    } 

    
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }



















  
  public void truncate(long paramLong) throws SQLException {
    if (this.isFreed) {
      
      SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
      sQLException1.fillInStackTrace();
      throw sQLException1;
    } 

    
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }
















  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
