package oracle.jdbc.rowset;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Vector;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;


















































public class OracleRow
  implements Serializable, Cloneable
{
  private Object[] column;
  private Object[] changedColumn;
  private boolean[] isOriginalNull;
  private byte[] columnChangeFlag;
  private int noColumn = 0;




  
  private int noColumnsInserted;




  
  private boolean rowDeleted = false;




  
  private boolean rowInserted = false;




  
  private static final byte COLUMN_CHANGED = 17;




  
  private boolean rowUpdated = false;



  
  int[][] columnTypeInfo;




  
  public OracleRow(int paramInt) {
    this.noColumn = paramInt;
    this.column = new Object[paramInt];
    this.changedColumn = new Object[paramInt];
    this.columnChangeFlag = new byte[paramInt];
    this.isOriginalNull = new boolean[paramInt];
    this.columnTypeInfo = new int[paramInt][];
    for (byte b = 0; b < paramInt; b++) {
      this.columnChangeFlag[b] = 0;
    }
  }









  
  public OracleRow(int paramInt, boolean paramBoolean) {
    this(paramInt);


    
    this.rowInserted = paramBoolean;
    this.noColumnsInserted = 0;
  }










  
  public OracleRow(int paramInt, Object[] paramArrayOfObject) {
    this(paramInt);


    
    System.arraycopy(paramArrayOfObject, 0, this.column, 0, paramInt);
  }












  
  public void setColumnValue(int paramInt, Object paramObject) {
    if (this.rowInserted)
      this.noColumnsInserted++; 
    this.column[paramInt - 1] = paramObject;
  }






  
  void markOriginalNull(int paramInt, boolean paramBoolean) throws SQLException {
    this.isOriginalNull[paramInt - 1] = paramBoolean;
  }






  
  boolean isOriginalNull(int paramInt) throws SQLException {
    return this.isOriginalNull[paramInt - 1];
  }











  
  public void updateObject(int paramInt, Object paramObject) {
    updateObject(paramInt, paramObject, (int[])null);
  }





  
  void updateObject(int paramInt, Object paramObject, int[] paramArrayOfint) {
    if (this.rowInserted)
      this.noColumnsInserted++; 
    this.columnChangeFlag[paramInt - 1] = 17;
    this.changedColumn[paramInt - 1] = paramObject;
    this.columnTypeInfo[paramInt - 1] = paramArrayOfint;
  }








  
  public void cancelRowUpdates() {
    this.noColumnsInserted = 0;
    for (byte b = 0; b < this.noColumn; b++)
      this.columnChangeFlag[b] = 0; 
    this.changedColumn = null;
    this.changedColumn = new Object[this.noColumn];
  }











  
  public Object getColumn(int paramInt) {
    return this.column[paramInt - 1];
  }











  
  public Object getModifiedColumn(int paramInt) {
    return this.changedColumn[paramInt - 1];
  }













  
  public boolean isColumnChanged(int paramInt) {
    return (this.columnChangeFlag[paramInt - 1] == 17);
  }












  
  public boolean isRowUpdated() {
    if (this.rowInserted || this.rowDeleted) {
      return false;
    }
    for (byte b = 0; b < this.noColumn; b++) {
      if (this.columnChangeFlag[b] == 17)
        return true; 
    } 
    return false;
  }








  
  public void setRowUpdated(boolean paramBoolean) {
    this.rowUpdated = paramBoolean;
    if (!paramBoolean) {
      cancelRowUpdates();
    }
  }










  
  public boolean isRowInserted() {
    return this.rowInserted;
  }







  
  public void cancelRowDeletion() {
    this.rowDeleted = false;
  }









  
  public void setRowDeleted(boolean paramBoolean) {
    this.rowDeleted = paramBoolean;
  }








  
  public boolean isRowDeleted() {
    return this.rowDeleted;
  }







  
  public Object[] getOriginalRow() {
    return this.column;
  }








  
  public boolean isRowFullyPopulated() {
    if (!this.rowInserted) {
      return false;
    }
    return (this.noColumnsInserted == this.noColumn);
  }









  
  public void setInsertedFlag(boolean paramBoolean) {
    this.rowInserted = paramBoolean;
  }










  
  void makeUpdatesOriginal() {
    for (byte b = 0; b < this.noColumn; b++) {
      
      if (this.columnChangeFlag[b] == 17) {

        
        this.column[b] = this.changedColumn[b];
        this.changedColumn[b] = null;
        this.columnChangeFlag[b] = 0;
      } 
    } 
    
    this.rowUpdated = false;
  }










  
  public void insertRow() {
    this.columnChangeFlag = null;
    this.columnChangeFlag = new byte[this.noColumn];
    System.arraycopy(this.changedColumn, 0, this.column, 0, this.noColumn);
    this.changedColumn = null;
    this.changedColumn = new Object[this.noColumn];
  }








  
  public Collection toCollection() {
    Vector<Object> vector = new Vector(this.noColumn);
    for (byte b = 1; b <= this.noColumn; b++) {
      vector.add(isColumnChanged(b) ? getModifiedColumn(b) : getColumn(b));
    }
    
    return vector;
  }





  
  public OracleRow createCopy() throws SQLException {
    OracleRow oracleRow = new OracleRow(this.noColumn);
    for (byte b = 0; b < this.noColumn; b++) {
      
      oracleRow.column[b] = getCopy(this.column[b]);
      oracleRow.changedColumn[b] = getCopy(this.changedColumn[b]);
    } 
    
    System.arraycopy(this.columnChangeFlag, 0, oracleRow.columnChangeFlag, 0, this.noColumn);
    oracleRow.noColumnsInserted = this.noColumnsInserted;
    oracleRow.rowDeleted = this.rowDeleted;
    oracleRow.rowInserted = this.rowInserted;
    oracleRow.rowUpdated = this.rowUpdated;
    
    return oracleRow;
  }




  
  public Object getCopy(Object paramObject) throws SQLException {
    DataOutputStream dataOutputStream;
    String str = null;
    
    try {
      if (paramObject == null) {
        return null;
      }
      if (paramObject instanceof String) {
        str = (String)paramObject;
      }
      else if (paramObject instanceof Number) {
        BigDecimal bigDecimal = new BigDecimal(((Number)paramObject).toString());
      }
      else if (paramObject instanceof Date) {
        Date date = new Date(((Date)paramObject).getTime());
      }
      else if (paramObject instanceof Timestamp) {
        Timestamp timestamp = new Timestamp(((Timestamp)paramObject).getTime());
      
      }
      else if (paramObject instanceof InputStream) {
        DataInputStream dataInputStream = new DataInputStream((InputStream)paramObject);
      }
      else if (paramObject instanceof OutputStream) {
        dataOutputStream = new DataOutputStream((OutputStream)paramObject);
      }
      else {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 348, paramObject.getClass().getName());
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    } catch (Exception exception) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 349, paramObject.getClass().getName() + exception.getMessage());
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    return dataOutputStream;
  }






  
  public Object clone() throws CloneNotSupportedException {
    try {
      return createCopy();
    } catch (SQLException sQLException) {
      
      throw new CloneNotSupportedException("Error while cloning\n" + sQLException.getMessage());
    } 
  }












  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
