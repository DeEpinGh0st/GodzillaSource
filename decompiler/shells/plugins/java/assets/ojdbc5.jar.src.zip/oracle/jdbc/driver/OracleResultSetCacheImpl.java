package oracle.jdbc.driver;

import java.util.Vector;

















class OracleResultSetCacheImpl
  implements OracleResultSetCache
{
  private static int DEFAULT_WIDTH = 5;
  private static int DEFAULT_SIZE = 5;


  
  Vector cachedRows = null;

  
  int nbOfColumnsInRow;

  
  OracleResultSetCacheImpl() {
    this(DEFAULT_WIDTH);
  }





  
  OracleResultSetCacheImpl(int paramInt) {
    if (paramInt > 0) {
      this.nbOfColumnsInRow = paramInt;
    }
    this.cachedRows = new Vector(DEFAULT_SIZE);
  }




  
  public void put(int paramInt1, int paramInt2, Object paramObject) {
    Vector<Object> vector = null;


    
    while (this.cachedRows.size() < paramInt1) {
      
      vector = new Vector(this.nbOfColumnsInRow);
      this.cachedRows.addElement(vector);
    } 
    
    vector = this.cachedRows.elementAt(paramInt1 - 1);
    
    while (vector.size() < paramInt2) {
      vector.addElement(null);
    }
    vector.setElementAt(paramObject, paramInt2 - 1);
  }




  
  public Object get(int paramInt1, int paramInt2) {
    Vector vector = this.cachedRows.elementAt(paramInt1 - 1);
    
    return vector.elementAt(paramInt2 - 1);
  }




  
  public void remove(int paramInt) {
    this.cachedRows.removeElementAt(paramInt - 1);
  }



  
  public void remove(int paramInt1, int paramInt2) {
    this.cachedRows.removeElementAt(paramInt1 - 1);
  }


  
  public void clear() {}


  
  public void close() {}

  
  public int getLength() {
    return 0;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
