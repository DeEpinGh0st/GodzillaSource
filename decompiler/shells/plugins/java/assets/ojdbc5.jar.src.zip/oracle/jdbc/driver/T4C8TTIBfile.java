package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.sql.Datum;

































































































final class T4C8TTIBfile
  extends T4C8TTILob
{
  T4C8TTIBfile(T4CConnection paramT4CConnection) {
    super(paramT4CConnection);
  }

















  
  Datum createTemporaryLob(Connection paramConnection, boolean paramBoolean, int paramInt) throws SQLException, IOException {
    Object object = null;

    
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), "cannot create a temporary BFILE", -1);
    sQLException.fillInStackTrace();
    throw sQLException;
  }
















  
  boolean open(byte[] paramArrayOfbyte, int paramInt) throws SQLException, IOException {
    boolean bool = false;

    
    bool = _open(paramArrayOfbyte, 11, 256);
    
    return bool;
  }














  
  boolean close(byte[] paramArrayOfbyte) throws SQLException, IOException {
    boolean bool = false;
    
    bool = _close(paramArrayOfbyte, 512);
    
    return bool;
  }















  
  boolean isOpen(byte[] paramArrayOfbyte) throws SQLException, IOException {
    return _isOpen(paramArrayOfbyte, 1024);
  }

















  
  boolean doesExist(byte[] paramArrayOfbyte) throws SQLException, IOException {
    boolean bool = false;

    
    initializeLobdef();

    
    this.sourceLobLocator = paramArrayOfbyte;
    this.lobops = 2048L;
    this.nullO2U = true;
    
    doRPC();

    
    bool = this.lobnull;
    return bool;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
