package oracle.jdbc.rowset;

import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Vector;
import javax.sql.RowSet;
import javax.sql.RowSetMetaData;
import javax.sql.rowset.CachedRowSet;
import javax.sql.rowset.JoinRowSet;
import javax.sql.rowset.Joinable;
import oracle.jdbc.driver.DatabaseError;























public class OracleJoinRowSet
  extends OracleWebRowSet
  implements JoinRowSet
{
  private static final String MATCH_COLUMN_SUFFIX = "#MATCH_COLUMN";
  private static boolean[] supportedJoins = new boolean[] { false, true, false, false, false };

















  
  private int joinType = 1;
  private Vector addedRowSets = new Vector();
  private Vector addedRowSetNames = new Vector();















  
  private Object lockForJoinActions;
















  
  public synchronized void addRowSet(Joinable paramJoinable) throws SQLException {
    if (paramJoinable == null) {
      
      SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 350);
      sQLException1.fillInStackTrace();
      throw sQLException1;
    } 
    
    if (!(paramJoinable instanceof RowSet)) {
      
      SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 351);
      sQLException1.fillInStackTrace();
      throw sQLException1;
    } 
    
    OracleCachedRowSet oracleCachedRowSet = checkAndWrapRowSet((RowSet)paramJoinable);
    String str = getMatchColumnTableName((RowSet)paramJoinable);
    
    switch (this.joinType) {
      
      case 1:
        doInnerJoin(oracleCachedRowSet);
        
        this.addedRowSets.add(paramJoinable);
        this.addedRowSetNames.add(str);
        return;
    } 





    
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 352);
    sQLException.fillInStackTrace();
    throw sQLException;
  }
























  
  public synchronized void addRowSet(RowSet paramRowSet, int paramInt) throws SQLException {
    ((OracleRowSet)paramRowSet).setMatchColumn(paramInt);
    addRowSet((Joinable)paramRowSet);
  }






















  
  public synchronized void addRowSet(RowSet paramRowSet, String paramString) throws SQLException {
    ((OracleRowSet)paramRowSet).setMatchColumn(paramString);
    addRowSet((Joinable)paramRowSet);
  }































  
  public synchronized void addRowSet(RowSet[] paramArrayOfRowSet, int[] paramArrayOfint) throws SQLException {
    if (paramArrayOfRowSet.length != paramArrayOfint.length) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 353);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    for (byte b = 0; b < paramArrayOfRowSet.length; b++) {
      
      ((OracleRowSet)paramArrayOfRowSet[b]).setMatchColumn(paramArrayOfint[b]);
      addRowSet((Joinable)paramArrayOfRowSet[b]);
    } 
  }
































  
  public synchronized void addRowSet(RowSet[] paramArrayOfRowSet, String[] paramArrayOfString) throws SQLException {
    if (paramArrayOfRowSet.length != paramArrayOfString.length) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 353);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    for (byte b = 0; b < paramArrayOfRowSet.length; b++) {
      
      ((OracleRowSet)paramArrayOfRowSet[b]).setMatchColumn(paramArrayOfString[b]);
      addRowSet((Joinable)paramArrayOfRowSet[b]);
    } 
  }

















  
  public Collection getRowSets() throws SQLException {
    return this.addedRowSets;
  }














  
  public String[] getRowSetNames() throws SQLException {
    Object[] arrayOfObject = this.addedRowSetNames.toArray();
    String[] arrayOfString = new String[arrayOfObject.length];
    for (byte b = 0; b < arrayOfObject.length; b++)
    {
      arrayOfString[b] = (String)arrayOfObject[b];
    }
    return arrayOfString;
  }


























  
  public CachedRowSet toCachedRowSet() throws SQLException {
    OracleCachedRowSet oracleCachedRowSet = (OracleCachedRowSet)createCopy();

    
    oracleCachedRowSet.setCommand("");
    
    return oracleCachedRowSet;
  }














  
  public int getJoinType() {
    return this.joinType;
  }









  
  public boolean supportsCrossJoin() {
    return supportedJoins[0];
  }









  
  public boolean supportsInnerJoin() {
    return supportedJoins[1];
  }









  
  public boolean supportsLeftOuterJoin() {
    return supportedJoins[2];
  }









  
  public boolean supportsRightOuterJoin() {
    return supportedJoins[3];
  }









  
  public boolean supportsFullJoin() {
    return supportedJoins[4];
  }














  
  public void setJoinType(int paramInt) throws SQLException {
    if (paramInt != 1) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 352);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.joinType = paramInt;
  }















  
  public synchronized String getWhereClause() throws SQLException {
    if (this.addedRowSets.size() < 2) {
      return "WHERE";
    }
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("WHERE\n");
    
    OracleRowSet oracleRowSet = this.addedRowSets.get(0);
    int[] arrayOfInt = oracleRowSet.getMatchColumnIndexes();
    ResultSetMetaData resultSetMetaData = oracleRowSet.getMetaData();
    String str = oracleRowSet.getTableName();





    
    for (byte b = 1; b < this.addedRowSets.size(); b++) {
      
      if (b > 1)
      {
        stringBuffer.append("\nAND\n");
      }
      
      OracleRowSet oracleRowSet1 = this.addedRowSets.get(b);
      int[] arrayOfInt1 = oracleRowSet1.getMatchColumnIndexes();
      ResultSetMetaData resultSetMetaData1 = oracleRowSet1.getMetaData();
      String str1 = oracleRowSet1.getTableName();
      
      for (byte b1 = 0; b1 < arrayOfInt.length; b1++) {
        
        if (b1 > 0)
        {
          stringBuffer.append("\nAND\n");
        }
        
        stringBuffer.append("(" + str + "." + resultSetMetaData.getColumnName(arrayOfInt[b1]) + " = " + str1 + "." + resultSetMetaData1.getColumnName(arrayOfInt1[b1]) + ")");
      } 




      
      oracleRowSet = oracleRowSet1;
      arrayOfInt = arrayOfInt1;
      resultSetMetaData = resultSetMetaData1;
      str = str1;
    } 
    
    stringBuffer.append(";");
    
    return stringBuffer.toString();
  }






















  
  private void doInnerJoin(OracleCachedRowSet paramOracleCachedRowSet) throws SQLException {
    if (this.addedRowSets.isEmpty()) {

      
      setMetaData((RowSetMetaData)paramOracleCachedRowSet.getMetaData());
      populate(paramOracleCachedRowSet);
      
      setMatchColumn(paramOracleCachedRowSet.getMatchColumnIndexes());
    }
    else {
      
      Vector<OracleRow> vector = new Vector(100);
      OracleRowSetMetaData oracleRowSetMetaData = new OracleRowSetMetaData(10);
      
      int[] arrayOfInt1 = getMatchColumnIndexes();
      int[] arrayOfInt2 = paramOracleCachedRowSet.getMatchColumnIndexes();

      
      int i = getMetaData().getColumnCount() + paramOracleCachedRowSet.getMetaData().getColumnCount() - arrayOfInt2.length;

      
      oracleRowSetMetaData.setColumnCount(i);

      
      String str = getTableName() + "#" + paramOracleCachedRowSet.getTableName();

      
      for (byte b1 = 1; b1 <= this.colCount; b1++) {
        
        boolean bool1 = false;
        for (byte b = 0; b < arrayOfInt1.length; b++) {
          
          if (b1 == arrayOfInt1[b]) {
            
            bool1 = true;
            
            break;
          } 
        } 
        setNewColumnMetaData(b1, oracleRowSetMetaData, b1, (RowSetMetaData)this.rowsetMetaData, bool1, str);
      } 


      
      RowSetMetaData rowSetMetaData = (RowSetMetaData)paramOracleCachedRowSet.getMetaData();
      
      int j = rowSetMetaData.getColumnCount();

      
      int k = this.colCount + 1;
      int[] arrayOfInt3 = new int[j];
      int m;
      for (m = 1; m <= j; m++) {
        
        boolean bool1 = false;
        for (byte b = 0; b < arrayOfInt2.length; b++) {
          
          if (m == arrayOfInt1[b]) {
            
            bool1 = true;
            
            break;
          } 
        } 
        if (!bool1) {
          
          setNewColumnMetaData(k, oracleRowSetMetaData, m, rowSetMetaData, bool1, str);


          
          arrayOfInt3[m - 1] = k;
          k++;
        
        }
        else {
          
          arrayOfInt3[m - 1] = -1;
        } 
      } 
      
      beforeFirst();

      
      m = paramOracleCachedRowSet.size();
      boolean bool = false;
      
      for (byte b2 = 1; b2 <= this.rowCount; b2++) {
        
        next();
        paramOracleCachedRowSet.beforeFirst();
        
        for (byte b = 1; b <= m; b++) {
          
          paramOracleCachedRowSet.next();
          
          bool = true;
          for (byte b3 = 0; b3 < arrayOfInt1.length; b3++) {
            
            Object object1 = getObject(arrayOfInt1[b3]);
            Object object2 = paramOracleCachedRowSet.getObject(arrayOfInt2[b3]);
            if (!object1.equals(object2)) {
              
              bool = false;
              
              break;
            } 
          } 
          if (bool) {
            
            OracleRow oracleRow = new OracleRow(i, true);
            
            byte b4;
            for (b4 = 1; b4 <= this.colCount; b4++)
            {
              oracleRow.updateObject(b4, getObject(b4));
            }
            
            for (b4 = 1; b4 <= j; b4++) {
              
              if (arrayOfInt3[b4 - 1] != -1)
              {
                oracleRow.updateObject(arrayOfInt3[b4 - 1], paramOracleCachedRowSet.getObject(b4));
              }
            } 

            
            vector.add(oracleRow);
          } 
        } 
      } 
      
      this.rows = vector;
      this.presentRow = 0;
      this.rowCount = this.rows.size();
      setMetaData(oracleRowSetMetaData);
    } 
  }































  
  private void setNewColumnMetaData(int paramInt1, RowSetMetaData paramRowSetMetaData1, int paramInt2, RowSetMetaData paramRowSetMetaData2, boolean paramBoolean, String paramString) throws SQLException {
    paramRowSetMetaData1.setAutoIncrement(paramInt1, paramRowSetMetaData2.isAutoIncrement(paramInt2));
    paramRowSetMetaData1.setCaseSensitive(paramInt1, paramRowSetMetaData2.isCaseSensitive(paramInt2));
    paramRowSetMetaData1.setCatalogName(paramInt1, paramRowSetMetaData2.getCatalogName(paramInt2));
    paramRowSetMetaData1.setColumnDisplaySize(paramInt1, paramRowSetMetaData2.getColumnDisplaySize(paramInt2));

    
    if (paramBoolean) {
      
      paramRowSetMetaData1.setColumnName(paramInt1, paramRowSetMetaData2.getColumnName(paramInt1) + "#MATCH_COLUMN");
    
    }
    else {
      
      paramRowSetMetaData1.setColumnName(paramInt1, paramRowSetMetaData2.getColumnName(paramInt2));
    } 
    
    paramRowSetMetaData1.setColumnLabel(paramInt1, paramRowSetMetaData1.getColumnName(paramInt2));
    
    paramRowSetMetaData1.setColumnType(paramInt1, paramRowSetMetaData2.getColumnType(paramInt2));
    paramRowSetMetaData1.setColumnTypeName(paramInt1, paramRowSetMetaData2.getColumnTypeName(paramInt2));
    paramRowSetMetaData1.setCurrency(paramInt1, paramRowSetMetaData2.isCurrency(paramInt2));
    paramRowSetMetaData1.setNullable(paramInt1, paramRowSetMetaData2.isNullable(paramInt2));
    paramRowSetMetaData1.setPrecision(paramInt1, paramRowSetMetaData2.getPrecision(paramInt2));
    paramRowSetMetaData1.setScale(paramInt1, paramRowSetMetaData2.getScale(paramInt2));
    paramRowSetMetaData1.setSchemaName(paramInt1, paramRowSetMetaData2.getSchemaName(paramInt2));
    paramRowSetMetaData1.setSearchable(paramInt1, paramRowSetMetaData2.isSearchable(paramInt2));
    paramRowSetMetaData1.setSigned(paramInt1, paramRowSetMetaData2.isSigned(paramInt2));
    
    if (paramBoolean) {
      
      paramRowSetMetaData1.setTableName(paramInt1, paramString);
    }
    else {
      
      paramRowSetMetaData1.setTableName(paramInt1, paramRowSetMetaData2.getTableName(paramInt2));
    } 
  }


















  
  private OracleCachedRowSet checkAndWrapRowSet(RowSet paramRowSet) throws SQLException {
    OracleCachedRowSet oracleCachedRowSet = null;


    
    if (paramRowSet instanceof OracleCachedRowSet) {
      
      oracleCachedRowSet = (OracleCachedRowSet)paramRowSet;
    }
    else if (paramRowSet instanceof OracleJDBCRowSet) {
      
      oracleCachedRowSet = new OracleCachedRowSet();
      oracleCachedRowSet.populate(paramRowSet);
      
      int[] arrayOfInt = ((OracleJDBCRowSet)paramRowSet).getMatchColumnIndexes();
      oracleCachedRowSet.setMatchColumn(arrayOfInt);
    }
    else {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 354);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    return oracleCachedRowSet;
  }






  
  private String getMatchColumnTableName(RowSet paramRowSet) throws SQLException {
    String str = null;
    if (paramRowSet instanceof OracleRowSet)
    {
      str = ((OracleRowSet)paramRowSet).getTableName();
    }
    
    return str;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
