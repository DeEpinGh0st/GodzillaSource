package oracle.jdbc.rowset;

import java.sql.SQLException;
import javax.sql.rowset.Joinable;

public interface OracleJoinable extends Joinable {
  int[] getMatchColumnIndexes() throws SQLException;
  
  String[] getMatchColumnNames() throws SQLException;
  
  void setMatchColumn(int paramInt) throws SQLException;
  
  void setMatchColumn(int[] paramArrayOfint) throws SQLException;
  
  void setMatchColumn(String paramString) throws SQLException;
  
  void setMatchColumn(String[] paramArrayOfString) throws SQLException;
  
  void unsetMatchColumn(int paramInt) throws SQLException;
  
  void unsetMatchColumn(int[] paramArrayOfint) throws SQLException;
  
  void unsetMatchColumn(String paramString) throws SQLException;
  
  void unsetMatchColumn(String[] paramArrayOfString) throws SQLException;
}
