package oracle.jdbc.rowset;

import java.io.InputStream;
import java.io.Reader;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.sql.Connection;
import java.sql.Date;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Properties;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import javax.sql.RowSet;
import javax.sql.RowSetInternal;
import javax.sql.RowSetReader;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.driver.OracleDriver;
import oracle.jdbc.internal.OracleConnection;













































































public class OracleCachedRowSetReader
  implements RowSetReader, Serializable
{
  static final long serialVersionUID = -3565405169674271176L;
  static final transient int SETUNICODESTREAM_INTLENGTH = 1;
  static final transient int SETBINARYSTREAM_INTLENGTH = 2;
  static final transient int SETASCIISTREAM_INTLENGTH = 3;
  static final transient int SETCHARACTERSTREAM_INTLENGTH = 4;
  static final transient int TWO_PARAMETERS = 2;
  static final transient int THREE_PARAMETERS = 3;
  private static transient boolean driverManagerInitialized = false;
  
  Connection getConnection(RowSetInternal paramRowSetInternal) throws SQLException {
    Connection connection1 = null;





    
    Connection connection2 = paramRowSetInternal.getConnection();
    if (connection2 != null && !connection2.isClosed()) {
      
      connection1 = connection2;
    }
    else if (((RowSet)paramRowSetInternal).getDataSourceName() != null) {

      
      try {
        InitialContext initialContext = null;



        
        try {
          Properties properties = System.getProperties();
          initialContext = new InitialContext(properties);
        } catch (SecurityException securityException) {}

        
        if (initialContext == null)
          initialContext = new InitialContext(); 
        DataSource dataSource = (DataSource)initialContext.lookup(((RowSet)paramRowSetInternal).getDataSourceName());



        
        String str1 = ((RowSet)paramRowSetInternal).getUsername();
        String str2 = ((RowSet)paramRowSetInternal).getPassword();
        if (str1 == null && str2 == null)
        {
          connection1 = dataSource.getConnection();
        }
        else
        {
          connection1 = dataSource.getConnection(str1, str2);
        }
      
      } catch (NamingException namingException) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 300, namingException.getMessage());
        sQLException.fillInStackTrace();
        throw sQLException;
      }
    
    }
    else if (((RowSet)paramRowSetInternal).getUrl() != null) {
      
      if (!driverManagerInitialized) {
        
        DriverManager.registerDriver((Driver)new OracleDriver());
        driverManagerInitialized = true;
      } 
      String str1 = ((RowSet)paramRowSetInternal).getUrl();
      String str2 = ((RowSet)paramRowSetInternal).getUsername();
      String str3 = ((RowSet)paramRowSetInternal).getPassword();


      
      if (str1.equals("") || str2.equals("") || str3.equals("")) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 301);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      connection1 = DriverManager.getConnection(str1, str2, str3);
    } 
    
    return connection1;
  }









  
  private void setParams(Object[] paramArrayOfObject, PreparedStatement paramPreparedStatement) throws SQLException {
    for (byte b = 0; b < paramArrayOfObject.length; b++) {
      
      int i = 0;



      
      if (paramArrayOfObject[b] instanceof byte[]) {
        
        paramPreparedStatement.setObject(b + 1, paramArrayOfObject[b]);
      } else {

        
        try {




          
          i = Array.getLength(paramArrayOfObject[b]);
        }
        catch (IllegalArgumentException illegalArgumentException) {
          
          paramPreparedStatement.setObject(b + 1, paramArrayOfObject[b]);
        } 

        
        Object[] arrayOfObject = (Object[])paramArrayOfObject[b];


        
        if (i == 2) {
          
          if (arrayOfObject[0] == null) {
            paramPreparedStatement.setNull(b + 1, ((Integer)arrayOfObject[1]).intValue());
          }
          else if (arrayOfObject[0] instanceof Date) {
            
            if (arrayOfObject[1] instanceof Calendar)
            {
              paramPreparedStatement.setDate(b + 1, (Date)arrayOfObject[0], (Calendar)arrayOfObject[1]);
            
            }
            else
            {
              
              SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 323);
              sQLException.fillInStackTrace();
              throw sQLException;
            }
          
          }
          else if (arrayOfObject[0] instanceof Time) {
            
            if (arrayOfObject[1] instanceof Calendar)
            {
              paramPreparedStatement.setTime(b + 1, (Time)arrayOfObject[0], (Calendar)arrayOfObject[1]);
            
            }
            else
            {
              
              SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 323);
              sQLException.fillInStackTrace();
              throw sQLException;
            }
          
          }
          else if (arrayOfObject[0] instanceof Timestamp) {
            
            if (arrayOfObject[1] instanceof Calendar)
            {
              paramPreparedStatement.setTimestamp(b + 1, (Timestamp)arrayOfObject[0], (Calendar)arrayOfObject[1]);
            
            }
            else
            {
              
              SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 323);
              sQLException.fillInStackTrace();
              throw sQLException;


            
            }


          
          }
          else if (arrayOfObject[1] instanceof Integer) {
            paramPreparedStatement.setObject(b + 1, arrayOfObject[0], ((Integer)arrayOfObject[1]).intValue());
          
          }
        
        }
        else if (i == 3) {
          
          if (arrayOfObject[0] == null) {
            
            paramPreparedStatement.setNull(b + 1, ((Integer)arrayOfObject[1]).intValue(), (String)arrayOfObject[2]);

          
          }
          else if (arrayOfObject[0] instanceof Reader) {
            SQLException sQLException;
            switch (((Integer)arrayOfObject[2]).intValue()) {
              
              case 4:
                paramPreparedStatement.setCharacterStream(b + 1, (Reader)arrayOfObject[0], ((Integer)arrayOfObject[1]).intValue());
                break;







              
              default:
                sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 323);
                sQLException.fillInStackTrace();
                throw sQLException;
            } 

          
          } else if (arrayOfObject[0] instanceof InputStream) {
            SQLException sQLException; switch (((Integer)arrayOfObject[2]).intValue()) {
              
              case 1:
                paramPreparedStatement.setUnicodeStream(b + 1, (InputStream)arrayOfObject[0], ((Integer)arrayOfObject[1]).intValue());
                break;


              
              case 2:
                paramPreparedStatement.setBinaryStream(b + 1, (InputStream)arrayOfObject[0], ((Integer)arrayOfObject[1]).intValue());
                break;


              
              case 3:
                paramPreparedStatement.setAsciiStream(b + 1, (InputStream)arrayOfObject[0], ((Integer)arrayOfObject[1]).intValue());
                break;







              
              default:
                sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 323);
                sQLException.fillInStackTrace();
                throw sQLException;
            } 
          
          } else if (arrayOfObject[1] instanceof Integer && arrayOfObject[2] instanceof Integer) {

            
            paramPreparedStatement.setObject(b + 1, arrayOfObject[0], ((Integer)arrayOfObject[1]).intValue(), ((Integer)arrayOfObject[2]).intValue());
          
          }
          else {

            
            SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 323);
            sQLException.fillInStackTrace();
            throw sQLException;
          } 
        } 
      } 
    } 
  }








  
  public synchronized void readData(RowSetInternal paramRowSetInternal) throws SQLException {
    OracleCachedRowSet oracleCachedRowSet = (OracleCachedRowSet)paramRowSetInternal;
    
    Connection connection = getConnection(paramRowSetInternal);


    
    if (connection == null || oracleCachedRowSet.getCommand() == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 342);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    try {
      connection.setTransactionIsolation(oracleCachedRowSet.getTransactionIsolation());
    }
    catch (Exception exception) {}

    
    PreparedStatement preparedStatement = connection.prepareStatement(oracleCachedRowSet.getCommand(), oracleCachedRowSet.getType(), oracleCachedRowSet.getConcurrency());



    
    setParams(paramRowSetInternal.getParams(), preparedStatement);
    
    try {
      preparedStatement.setMaxRows(oracleCachedRowSet.getMaxRows());
      preparedStatement.setMaxFieldSize(oracleCachedRowSet.getMaxFieldSize());
      preparedStatement.setEscapeProcessing(oracleCachedRowSet.getEscapeProcessing());
      preparedStatement.setQueryTimeout(oracleCachedRowSet.getQueryTimeout());
    }
    catch (Exception exception) {}
    ResultSet resultSet = preparedStatement.executeQuery();
    oracleCachedRowSet.populate(resultSet, oracleCachedRowSet.getCurrentPage() * oracleCachedRowSet.getPageSize());
    resultSet.close();
    preparedStatement.close();
    
    try {
      connection.commit();
    } catch (SQLException sQLException) {}


    
    if (!oracleCachedRowSet.isConnectionStayingOpen())
    {
      connection.close();
    }
  }












  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
