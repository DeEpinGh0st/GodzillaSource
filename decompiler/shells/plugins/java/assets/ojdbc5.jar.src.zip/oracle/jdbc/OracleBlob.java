package oracle.jdbc;

import java.io.InputStream;
import java.sql.Blob;
import java.sql.SQLException;

public interface OracleBlob extends Blob {
  void open(LargeObjectAccessMode paramLargeObjectAccessMode) throws SQLException;
  
  void close() throws SQLException;
  
  boolean isOpen() throws SQLException;
  
  int getBytes(long paramLong, int paramInt, byte[] paramArrayOfbyte) throws SQLException;
  
  boolean isEmptyLob() throws SQLException;
  
  boolean isSecureFile() throws SQLException;
  
  InputStream getBinaryStream(long paramLong) throws SQLException;
  
  boolean isTemporary() throws SQLException;
}
