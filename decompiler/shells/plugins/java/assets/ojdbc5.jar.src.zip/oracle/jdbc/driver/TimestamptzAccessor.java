package oracle.jdbc.driver;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.TimeZone;
import oracle.sql.DATE;
import oracle.sql.Datum;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPTZ;
import oracle.sql.TIMEZONETAB;
import oracle.sql.ZONEIDMAP;










class TimestamptzAccessor
  extends DateTimeCommonAccessor
{
  static final int maxLength = 13;
  TimestampTzConverter tstzConverter = null;



  
  TimestamptzAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean) throws SQLException {
    init(paramOracleStatement, 181, 181, paramShort, paramBoolean);
    initForDataAccess(paramInt2, paramInt1, (String)null);
    
    if (this.statement.connection.timestamptzInGmt) {
      this.tstzConverter = new GmtTimestampTzConverter();
    } else {
      this.tstzConverter = new OldTimestampTzConverter();
    } 
  }




  
  TimestamptzAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort) throws SQLException {
    init(paramOracleStatement, 181, 181, paramShort, false);
    initForDescribe(181, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, null);
    
    initForDataAccess(0, paramInt1, (String)null);
    
    if (this.statement.connection.timestamptzInGmt) {
      this.tstzConverter = new GmtTimestampTzConverter();
    } else {
      this.tstzConverter = new OldTimestampTzConverter();
    } 
  }



  
  void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
    if (paramInt1 != 0) {
      this.externalType = paramInt1;
    }
    this.internalTypeMaxLength = 13;
    
    if (paramInt2 > 0 && paramInt2 < this.internalTypeMaxLength) {
      this.internalTypeMaxLength = paramInt2;
    }
    this.byteLength = this.internalTypeMaxLength;
  }



  
  String getString(int paramInt) throws SQLException {
    String str;
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
      return null;
    }
    int i = this.columnIndex + this.byteLength * paramInt;

    
    int j = 0;
    
    if ((oracleTZ1(i) & REGIONIDBIT) != 0) {
      
      j = getHighOrderbits(oracleTZ1(i));
      j += getLowOrderbits(oracleTZ2(i));

      
      TIMEZONETAB tIMEZONETAB = this.statement.connection.getTIMEZONETAB();
      if (tIMEZONETAB.checkID(j)) {
        tIMEZONETAB.updateTable((Connection)this.statement.connection, j);
      }
      str = ZONEIDMAP.getRegion(j);
    }
    else {
      
      int i5 = oracleTZ1(i) - OFFSET_HOUR;
      int i6 = oracleTZ2(i) - OFFSET_MINUTE;
      
      str = "GMT" + ((i5 < 0) ? "-" : "+") + Math.abs(i5) + ":" + ((i6 < 10) ? "0" : "") + i6;
    } 





    
    Calendar calendar = this.statement.getGMTCalendar();
    
    int k = oracleYear(i);
    
    calendar.set(1, k);
    calendar.set(2, oracleMonth(i));
    calendar.set(5, oracleDay(i));
    calendar.set(11, oracleHour(i));
    calendar.set(12, oracleMin(i));
    calendar.set(13, oracleSec(i));
    calendar.set(14, 0);
    
    if ((oracleTZ1(i) & REGIONIDBIT) != 0) {
      
      TIMEZONETAB tIMEZONETAB = this.statement.connection.getTIMEZONETAB();

      
      int i5 = tIMEZONETAB.getOffset(calendar, j);

      
      calendar.add(14, i5);
    }
    else {
      
      calendar.add(10, oracleTZ1(i) - OFFSET_HOUR);
      calendar.add(12, oracleTZ2(i) - OFFSET_MINUTE);
    } 

    
    k = calendar.get(1);
    
    int m = calendar.get(2) + 1;
    int n = calendar.get(5);
    int i1 = calendar.get(11);
    int i2 = calendar.get(12);
    int i3 = calendar.get(13);
    boolean bool = (i1 < 12) ? true : false;
    if (str.length() > 3 && str.startsWith("GMT")) {
      str = str.substring(3);
    }
    int i4 = oracleNanos(i);
    
    return toText(k, m, n, i1, i2, i3, i4, bool, str);
  }



  
  Date getDate(int paramInt) throws SQLException {
    return this.tstzConverter.getDate(paramInt);
  }




  
  Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
    return getDate(paramInt);
  }



  
  Time getTime(int paramInt) throws SQLException {
    return this.tstzConverter.getTime(paramInt);
  }




  
  Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
    return getTime(paramInt);
  }



  
  Timestamp getTimestamp(int paramInt) throws SQLException {
    return this.tstzConverter.getTimestamp(paramInt);
  }




  
  Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
    return getTimestamp(paramInt);
  }

  
  Object getObject(int paramInt) throws SQLException {
    return this.tstzConverter.getObject(paramInt);
  }


  
  Datum getOracleObject(int paramInt) throws SQLException {
    return this.tstzConverter.getOracleObject(paramInt);
  }

  
  DATE getDATE(int paramInt) throws SQLException {
    TIMESTAMPTZ tIMESTAMPTZ = this.tstzConverter.getTIMESTAMPTZ(paramInt);
    return TIMESTAMPTZ.toDATE((Connection)this.statement.connection, tIMESTAMPTZ.getBytes());
  }

  
  TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
    TIMESTAMPTZ tIMESTAMPTZ = this.tstzConverter.getTIMESTAMPTZ(paramInt);
    return TIMESTAMPTZ.toTIMESTAMP((Connection)this.statement.connection, tIMESTAMPTZ.getBytes());
  }

  
  TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
    return this.tstzConverter.getTIMESTAMPTZ(paramInt);
  }



  
  static int OFFSET_HOUR = 20;
  static int OFFSET_MINUTE = 60;

  
  static byte REGIONIDBIT = Byte.MIN_VALUE;







  
  static int setHighOrderbits(int paramInt) {
    return (paramInt & 0x1FC0) >> 6;
  }




  
  static int setLowOrderbits(int paramInt) {
    return (paramInt & 0x3F) << 2;
  }




  
  static int getHighOrderbits(int paramInt) {
    return (paramInt & 0x7F) << 6;
  }



  
  static int getLowOrderbits(int paramInt) {
    return (paramInt & 0xFC) >> 2;
  }









  
  class OldTimestampTzConverter
    extends TimestampTzConverter
  {
    Date getDate(int param1Int) throws SQLException {
      if (TimestamptzAccessor.this.rowSpaceIndicator == null) {


        
        SQLException sQLException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 



      
      if (TimestamptzAccessor.this.rowSpaceIndicator[TimestamptzAccessor.this.indicatorIndex + param1Int] == -1) {
        return null;
      }
      int i = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * param1Int;
      
      TimeZone timeZone = TimestamptzAccessor.this.statement.getDefaultTimeZone();
      Calendar calendar = Calendar.getInstance(timeZone);
      
      int j = TimestamptzAccessor.this.oracleYear(i);
      
      calendar.set(1, j);
      calendar.set(2, TimestamptzAccessor.this.oracleMonth(i));
      calendar.set(5, TimestamptzAccessor.this.oracleDay(i));
      calendar.set(11, TimestamptzAccessor.this.oracleHour(i));
      calendar.set(12, TimestamptzAccessor.this.oracleMin(i));
      calendar.set(13, TimestamptzAccessor.this.oracleSec(i));
      calendar.set(14, 0);
      
      if ((TimestamptzAccessor.this.oracleTZ1(i) & TimestamptzAccessor.REGIONIDBIT) != 0) {


        
        int k = TimestamptzAccessor.getHighOrderbits(TimestamptzAccessor.this.oracleTZ1(i));
        k += TimestamptzAccessor.getLowOrderbits(TimestamptzAccessor.this.oracleTZ2(i));
        
        TIMEZONETAB tIMEZONETAB = TimestamptzAccessor.this.statement.connection.getTIMEZONETAB();
        
        if (tIMEZONETAB.checkID(k)) {
          tIMEZONETAB.updateTable((Connection)TimestamptzAccessor.this.statement.connection, k);
        }
        int m = tIMEZONETAB.getOffset(calendar, k);
        
        boolean bool1 = timeZone.inDaylightTime(calendar.getTime());
        boolean bool2 = timeZone.inDaylightTime(new Date(calendar.getTimeInMillis() + m));





        
        if (!bool1 && bool2) {
          
          calendar.add(14, -1 * timeZone.getDSTSavings());





        
        }
        else if (bool1 && !bool2) {
          
          calendar.add(14, timeZone.getDSTSavings());
        } 


        
        calendar.add(10, m / 3600000);
        calendar.add(12, m % 3600000 / 60000);
      }
      else {
        
        calendar.add(10, TimestamptzAccessor.this.oracleTZ1(i) - TimestamptzAccessor.OFFSET_HOUR);
        calendar.add(12, TimestamptzAccessor.this.oracleTZ2(i) - TimestamptzAccessor.OFFSET_MINUTE);
      } 


      
      long l = calendar.getTimeInMillis();

      
      return new Date(l);
    }




    
    Time getTime(int param1Int) throws SQLException {
      if (TimestamptzAccessor.this.rowSpaceIndicator == null) {


        
        SQLException sQLException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 



      
      if (TimestamptzAccessor.this.rowSpaceIndicator[TimestamptzAccessor.this.indicatorIndex + param1Int] == -1) {
        return null;
      }
      int i = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * param1Int;
      
      TimeZone timeZone = TimestamptzAccessor.this.statement.getDefaultTimeZone();
      Calendar calendar = Calendar.getInstance(timeZone);
      
      int j = TimestamptzAccessor.this.oracleYear(i);
      
      calendar.set(1, j);
      calendar.set(2, TimestamptzAccessor.this.oracleMonth(i));
      calendar.set(5, TimestamptzAccessor.this.oracleDay(i));
      calendar.set(11, TimestamptzAccessor.this.oracleHour(i));
      calendar.set(12, TimestamptzAccessor.this.oracleMin(i));
      calendar.set(13, TimestamptzAccessor.this.oracleSec(i));
      calendar.set(14, 0);
      
      if ((TimestamptzAccessor.this.oracleTZ1(i) & TimestamptzAccessor.REGIONIDBIT) != 0) {


        
        int k = TimestamptzAccessor.getHighOrderbits(TimestamptzAccessor.this.oracleTZ1(i));
        k += TimestamptzAccessor.getLowOrderbits(TimestamptzAccessor.this.oracleTZ2(i));
        
        TIMEZONETAB tIMEZONETAB = TimestamptzAccessor.this.statement.connection.getTIMEZONETAB();
        
        if (tIMEZONETAB.checkID(k)) {
          tIMEZONETAB.updateTable((Connection)TimestamptzAccessor.this.statement.connection, k);
        }
        int m = tIMEZONETAB.getOffset(calendar, k);
        
        boolean bool1 = timeZone.inDaylightTime(calendar.getTime());
        boolean bool2 = timeZone.inDaylightTime(new Date(calendar.getTimeInMillis() + m));





        
        if (!bool1 && bool2) {
          
          calendar.add(14, -1 * timeZone.getDSTSavings());





        
        }
        else if (bool1 && !bool2) {
          
          calendar.add(14, timeZone.getDSTSavings());
        } 

        
        calendar.add(10, m / 3600000);
        calendar.add(12, m % 3600000 / 60000);
      }
      else {
        
        calendar.add(10, TimestamptzAccessor.this.oracleTZ1(i) - TimestamptzAccessor.OFFSET_HOUR);
        calendar.add(12, TimestamptzAccessor.this.oracleTZ2(i) - TimestamptzAccessor.OFFSET_MINUTE);
      } 

      
      long l = calendar.getTimeInMillis();

      
      return new Time(l);
    }




    
    Timestamp getTimestamp(int param1Int) throws SQLException {
      if (TimestamptzAccessor.this.rowSpaceIndicator == null) {


        
        SQLException sQLException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 



      
      if (TimestamptzAccessor.this.rowSpaceIndicator[TimestamptzAccessor.this.indicatorIndex + param1Int] == -1) {
        return null;
      }
      int i = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * param1Int;
      
      TimeZone timeZone = TimestamptzAccessor.this.statement.getDefaultTimeZone();
      Calendar calendar1 = Calendar.getInstance(timeZone);
      Calendar calendar2 = TimestamptzAccessor.this.statement.getGMTCalendar();
      
      int j = TimestamptzAccessor.this.oracleYear(i);
      
      calendar1.set(1, j);
      calendar1.set(2, TimestamptzAccessor.this.oracleMonth(i));
      calendar1.set(5, TimestamptzAccessor.this.oracleDay(i));
      calendar1.set(11, TimestamptzAccessor.this.oracleHour(i));
      calendar1.set(12, TimestamptzAccessor.this.oracleMin(i));
      calendar1.set(13, TimestamptzAccessor.this.oracleSec(i));
      calendar1.set(14, 0);
      
      calendar2.set(1, j);
      calendar2.set(2, TimestamptzAccessor.this.oracleMonth(i));
      calendar2.set(5, TimestamptzAccessor.this.oracleDay(i));
      calendar2.set(11, TimestamptzAccessor.this.oracleHour(i));
      calendar2.set(12, TimestamptzAccessor.this.oracleMin(i));
      calendar2.set(13, TimestamptzAccessor.this.oracleSec(i));
      calendar2.set(14, 0);
      
      if ((TimestamptzAccessor.this.oracleTZ1(i) & TimestamptzAccessor.REGIONIDBIT) != 0) {


        
        int m = TimestamptzAccessor.getHighOrderbits(TimestamptzAccessor.this.oracleTZ1(i));
        m += TimestamptzAccessor.getLowOrderbits(TimestamptzAccessor.this.oracleTZ2(i));

        
        TIMEZONETAB tIMEZONETAB = TimestamptzAccessor.this.statement.connection.getTIMEZONETAB();
        if (tIMEZONETAB.checkID(m)) {
          tIMEZONETAB.updateTable((Connection)TimestamptzAccessor.this.statement.connection, m);
        }
        int n = tIMEZONETAB.getOffset(calendar2, m);
        
        boolean bool1 = timeZone.inDaylightTime(calendar1.getTime());
        boolean bool2 = timeZone.inDaylightTime(new Date(calendar1.getTimeInMillis() + n));





        
        if (!bool1 && bool2) {

          
          calendar1.add(14, -1 * timeZone.getDSTSavings());





        
        }
        else if (bool1 && !bool2) {
          
          calendar1.add(14, timeZone.getDSTSavings());
        } 

        
        calendar1.add(10, n / 3600000);
        calendar1.add(12, n % 3600000 / 60000);
      }
      else {
        
        calendar1.add(10, TimestamptzAccessor.this.oracleTZ1(i) - TimestamptzAccessor.OFFSET_HOUR);
        calendar1.add(12, TimestamptzAccessor.this.oracleTZ2(i) - TimestamptzAccessor.OFFSET_MINUTE);
      } 

      
      long l = calendar1.getTimeInMillis();

      
      Timestamp timestamp = new Timestamp(l);

      
      int k = TimestamptzAccessor.this.oracleNanos(i);

      
      timestamp.setNanos(k);
      
      return timestamp;
    }




    
    TIMESTAMPTZ getTIMESTAMPTZ(int param1Int) throws SQLException {
      TIMESTAMPTZ tIMESTAMPTZ = null;
      
      if (TimestamptzAccessor.this.rowSpaceIndicator == null) {


        
        SQLException sQLException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 



      
      if (TimestamptzAccessor.this.rowSpaceIndicator[TimestamptzAccessor.this.indicatorIndex + param1Int] != -1) {
        
        int i = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * param1Int;
        byte[] arrayOfByte = new byte[13];
        
        System.arraycopy(TimestamptzAccessor.this.rowSpaceByte, i, arrayOfByte, 0, 13);
        
        tIMESTAMPTZ = new TIMESTAMPTZ(arrayOfByte);
      } 
      
      return tIMESTAMPTZ;
    }
  }










  
  class GmtTimestampTzConverter
    extends TimestampTzConverter
  {
    Date getDate(int param1Int) throws SQLException {
      if (TimestamptzAccessor.this.rowSpaceIndicator == null) {


        
        SQLException sQLException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 



      
      if (TimestamptzAccessor.this.rowSpaceIndicator[TimestamptzAccessor.this.indicatorIndex + param1Int] == -1) {
        return null;
      }
      int i = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * param1Int;
      
      Calendar calendar = TimestamptzAccessor.this.statement.getGMTCalendar();
      
      int j = TimestamptzAccessor.this.oracleYear(i);
      
      calendar.set(1, j);
      calendar.set(2, TimestamptzAccessor.this.oracleMonth(i));
      calendar.set(5, TimestamptzAccessor.this.oracleDay(i));
      calendar.set(11, TimestamptzAccessor.this.oracleHour(i));
      calendar.set(12, TimestamptzAccessor.this.oracleMin(i));
      calendar.set(13, TimestamptzAccessor.this.oracleSec(i));
      calendar.set(14, 0);

      
      long l = calendar.getTimeInMillis();

      
      return new Date(l);
    }




    
    Time getTime(int param1Int) throws SQLException {
      if (TimestamptzAccessor.this.rowSpaceIndicator == null) {


        
        SQLException sQLException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 



      
      if (TimestamptzAccessor.this.rowSpaceIndicator[TimestamptzAccessor.this.indicatorIndex + param1Int] == -1) {
        return null;
      }
      int i = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * param1Int;
      
      Calendar calendar = TimestamptzAccessor.this.statement.getGMTCalendar();
      
      int j = TimestamptzAccessor.this.oracleYear(i);
      
      calendar.set(1, j);
      calendar.set(2, TimestamptzAccessor.this.oracleMonth(i));
      calendar.set(5, TimestamptzAccessor.this.oracleDay(i));
      calendar.set(11, TimestamptzAccessor.this.oracleHour(i));
      calendar.set(12, TimestamptzAccessor.this.oracleMin(i));
      calendar.set(13, TimestamptzAccessor.this.oracleSec(i));
      calendar.set(14, 0);
      
      return new Time(calendar.getTimeInMillis());
    }




    
    Timestamp getTimestamp(int param1Int) throws SQLException {
      if (TimestamptzAccessor.this.rowSpaceIndicator == null) {


        
        SQLException sQLException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 



      
      if (TimestamptzAccessor.this.rowSpaceIndicator[TimestamptzAccessor.this.indicatorIndex + param1Int] == -1) {
        return null;
      }
      int i = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * param1Int;
      
      Calendar calendar = TimestamptzAccessor.this.statement.getGMTCalendar();
      
      int j = TimestamptzAccessor.this.oracleYear(i);
      
      calendar.set(1, j);
      calendar.set(2, TimestamptzAccessor.this.oracleMonth(i));
      calendar.set(5, TimestamptzAccessor.this.oracleDay(i));
      calendar.set(11, TimestamptzAccessor.this.oracleHour(i));
      calendar.set(12, TimestamptzAccessor.this.oracleMin(i));
      calendar.set(13, TimestamptzAccessor.this.oracleSec(i));
      calendar.set(14, 0);

      
      long l = calendar.getTimeInMillis();

      
      Timestamp timestamp = new Timestamp(l);

      
      int k = TimestamptzAccessor.this.oracleNanos(i);

      
      timestamp.setNanos(k);
      
      return timestamp;
    }




    
    TIMESTAMPTZ getTIMESTAMPTZ(int param1Int) throws SQLException {
      TIMESTAMPTZ tIMESTAMPTZ = null;
      
      if (TimestamptzAccessor.this.rowSpaceIndicator == null) {


        
        SQLException sQLException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 



      
      if (TimestamptzAccessor.this.rowSpaceIndicator[TimestamptzAccessor.this.indicatorIndex + param1Int] != -1) {
        
        int i = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * param1Int;
        byte[] arrayOfByte = new byte[13];
        
        System.arraycopy(TimestamptzAccessor.this.rowSpaceByte, i, arrayOfByte, 0, 13);
        
        tIMESTAMPTZ = new TIMESTAMPTZ(arrayOfByte);
      } 
      
      return tIMESTAMPTZ;
    }
  }



  
  abstract class TimestampTzConverter
  {
    abstract Date getDate(int param1Int) throws SQLException;



    
    abstract Time getTime(int param1Int) throws SQLException;


    
    abstract Timestamp getTimestamp(int param1Int) throws SQLException;


    
    Object getObject(int param1Int) throws SQLException {
      return getTIMESTAMPTZ(param1Int);
    }




    
    Datum getOracleObject(int param1Int) throws SQLException {
      return (Datum)getTIMESTAMPTZ(param1Int);
    }




    
    Object getObject(int param1Int, Map param1Map) throws SQLException {
      return getTIMESTAMPTZ(param1Int);
    }


    
    abstract TIMESTAMPTZ getTIMESTAMPTZ(int param1Int) throws SQLException;
  }

  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
