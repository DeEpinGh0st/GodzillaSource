package oracle.jdbc;
















public enum LargeObjectAccessMode
{
  private final int code;
  MODE_READONLY(0),
  MODE_READWRITE(1);
  
  LargeObjectAccessMode(int paramInt1) {
    this.code = paramInt1;
  }
  public int getCode() {
    return this.code;
  }
}
