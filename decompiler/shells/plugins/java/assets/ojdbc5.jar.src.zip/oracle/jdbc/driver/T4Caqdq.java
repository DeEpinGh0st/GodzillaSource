package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.aq.AQDequeueOptions;
import oracle.jdbc.aq.AQMessageProperties;
import oracle.jdbc.internal.OracleConnection;






























































final class T4Caqdq
  extends T4CTTIfun
{
  T4CTTIaqm aqm;
  T4Ctoh toh;
  private String queueName;
  private AQDequeueOptions dequeueOptions;
  private byte[] payloadToid;
  private byte[] queueNameBytes;
  private byte[] consumerNameBytes;
  private byte[] correlationBytes;
  private byte[] conditionBytes;
  private int nbExtensions;
  private byte[][] extensionTextValues;
  private byte[][] extensionBinaryValues;
  private int[] extensionKeywords;
  private byte[] payload;
  private boolean hasAMessageBeenDequeued;
  private byte[] dequeuedMessageId;
  private boolean isRawQueue;
  private AQMessagePropertiesI properties;
  
  T4Caqdq(T4CConnection paramT4CConnection) {
    super(paramT4CConnection, (byte)3);







    
    this.dequeueOptions = null;
    this.payloadToid = null;
    this.queueNameBytes = null;
    this.consumerNameBytes = null;
    this.correlationBytes = null;
    this.conditionBytes = null;
    this.nbExtensions = 0;
    this.extensionTextValues = (byte[][])null;
    this.extensionBinaryValues = (byte[][])null;
    this.extensionKeywords = null;

    
    this.payload = null;
    this.hasAMessageBeenDequeued = false;
    this.dequeuedMessageId = null;
    this.isRawQueue = false;
    this.properties = null;
    setFunCode((short)122);
    this.toh = new T4Ctoh();
    this.aqm = new T4CTTIaqm(this.connection, this.toh);
  }




  
  void doOAQDQ(String paramString, AQDequeueOptions paramAQDequeueOptions, byte[] paramArrayOfbyte, boolean paramBoolean, AQMessagePropertiesI paramAQMessagePropertiesI) throws SQLException, IOException {
    this.queueName = paramString;
    this.dequeueOptions = paramAQDequeueOptions;
    this.payloadToid = paramArrayOfbyte;
    this.isRawQueue = paramBoolean;
    this.properties = paramAQMessagePropertiesI;

    
    if (this.queueName != null && this.queueName.length() != 0) {
      this.queueNameBytes = this.meg.conv.StringToCharBytes(this.queueName);
    } else {
      this.queueNameBytes = null;
    } 
    String str1 = this.dequeueOptions.getConsumerName();
    
    if (str1 != null && str1.length() > 0) {
      
      this.consumerNameBytes = this.meg.conv.StringToCharBytes(str1);
    } else {
      
      this.consumerNameBytes = null;
    } 
    String str2 = this.dequeueOptions.getCorrelation();
    if (str2 != null && str2.length() != 0) {
      this.correlationBytes = this.meg.conv.StringToCharBytes(str2);
    } else {
      this.correlationBytes = null;
    } 
    String str3 = this.dequeueOptions.getCondition();
    if (str3 != null && str3.length() > 0) {
      this.conditionBytes = this.meg.conv.StringToCharBytes(str3);
    } else {
      this.conditionBytes = null;
    } 
    String str4 = this.dequeueOptions.getTransformation();
    if (str4 != null && str4.length() > 0) {
      
      this.nbExtensions = 1;
      this.extensionTextValues = new byte[this.nbExtensions][];
      this.extensionBinaryValues = new byte[this.nbExtensions][];
      this.extensionKeywords = new int[this.nbExtensions];
      this.extensionTextValues[0] = this.meg.conv.StringToCharBytes(str4);
      this.extensionBinaryValues[0] = null;
      this.extensionKeywords[0] = 196;
    } else {
      
      this.nbExtensions = 0;
    } 
    this.hasAMessageBeenDequeued = false;
    this.dequeuedMessageId = null;
    this.payload = null;
    
    doRPC();
  }







  
  void marshal() throws IOException {
    if (this.queueNameBytes != null && this.queueNameBytes.length != 0) {
      
      this.meg.marshalPTR();
      this.meg.marshalSWORD(this.queueNameBytes.length);
    }
    else {
      
      this.meg.marshalNULLPTR();
      this.meg.marshalSWORD(0);
    } 


    
    this.meg.marshalPTR();
    this.meg.marshalPTR();


    
    this.meg.marshalPTR();
    this.meg.marshalPTR();


    
    if (this.consumerNameBytes != null && this.consumerNameBytes.length != 0) {
      
      this.meg.marshalPTR();
      this.meg.marshalSWORD(this.consumerNameBytes.length);
    }
    else {
      
      this.meg.marshalNULLPTR();
      this.meg.marshalSWORD(0);
    } 

    
    this.meg.marshalSB4(this.dequeueOptions.getDequeueMode().getCode());

    
    this.meg.marshalSB4(this.dequeueOptions.getNavigation().getCode());

    
    this.meg.marshalSB4(this.dequeueOptions.getVisibility().getCode());

    
    this.meg.marshalSB4(this.dequeueOptions.getWait());


    
    byte[] arrayOfByte = this.dequeueOptions.getDequeueMessageId();
    boolean bool = false;
    if (arrayOfByte != null && arrayOfByte.length > 0) {
      
      this.meg.marshalPTR();
      this.meg.marshalSWORD(arrayOfByte.length);
      bool = true;
    }
    else {
      
      this.meg.marshalNULLPTR();
      this.meg.marshalSWORD(0);
    } 


    
    if (this.correlationBytes != null && this.correlationBytes.length != 0) {
      
      this.meg.marshalPTR();
      this.meg.marshalSWORD(this.correlationBytes.length);
    }
    else {
      
      this.meg.marshalNULLPTR();
      this.meg.marshalSWORD(0);
    } 


    
    this.meg.marshalPTR();
    this.meg.marshalSWORD(this.payloadToid.length);

    
    this.meg.marshalUB2(1);

    
    this.meg.marshalPTR();



    
    if (this.dequeueOptions.getRetrieveMessageId()) {
      
      this.meg.marshalPTR();
      this.meg.marshalSWORD(16);
    }
    else {
      
      this.meg.marshalNULLPTR();
      this.meg.marshalSWORD(0);
    } 

    
    int i = 0;
    if (this.connection.autocommit)
      i = 32; 
    if (this.dequeueOptions.getDeliveryFilter() == AQDequeueOptions.DeliveryFilter.BUFFERED) {
      i |= 0x2;
    } else if (this.dequeueOptions.getDeliveryFilter() == AQDequeueOptions.DeliveryFilter.PERSISTENT_OR_BUFFERED) {
      
      i |= 0x10;
    }  this.meg.marshalUB4(i);


    
    if (this.conditionBytes != null && this.conditionBytes.length > 0) {
      
      this.meg.marshalPTR();
      this.meg.marshalSWORD(this.conditionBytes.length);
    }
    else {
      
      this.meg.marshalNULLPTR();
      this.meg.marshalSWORD(0);
    } 


    
    if (this.nbExtensions > 0) {
      
      this.meg.marshalPTR();
      this.meg.marshalSWORD(this.nbExtensions);
    }
    else {
      
      this.meg.marshalNULLPTR();
      this.meg.marshalSWORD(0);
    } 


    
    if (this.queueNameBytes != null && this.queueNameBytes.length != 0) {
      this.meg.marshalCHR(this.queueNameBytes);
    }
    
    if (this.consumerNameBytes != null && this.consumerNameBytes.length != 0) {
      this.meg.marshalCHR(this.consumerNameBytes);
    }
    
    if (bool) {
      this.meg.marshalB1Array(arrayOfByte);
    }
    
    if (this.correlationBytes != null && this.correlationBytes.length != 0) {
      this.meg.marshalCHR(this.correlationBytes);
    }
    
    this.meg.marshalB1Array(this.payloadToid);
    
    if (this.conditionBytes != null && this.conditionBytes.length > 0) {
      this.meg.marshalCHR(this.conditionBytes);
    }
    if (this.nbExtensions > 0) {
      this.meg.marshalKPDKV(this.extensionTextValues, this.extensionBinaryValues, this.extensionKeywords);
    }
  }



  
  byte[] getPayload() {
    return this.payload;
  }


  
  boolean hasAMessageBeenDequeued() {
    return this.hasAMessageBeenDequeued;
  }


  
  byte[] getDequeuedMessageId() {
    return this.dequeuedMessageId;
  }



  
  void readRPA() throws SQLException, IOException {
    this.hasAMessageBeenDequeued = true;
    
    int i = (int)this.meg.unmarshalUB4();
    if (i > 0) {
      
      this.aqm.initToDefaultValues();
      this.aqm.receive();
      this.properties.setPriority(this.aqm.aqmpri);
      this.properties.setDelay(this.aqm.aqmdel);
      this.properties.setExpiration(this.aqm.aqmexp);
      if (this.aqm.aqmcorBytes != null) {
        
        String str = this.meg.conv.CharBytesToString(this.aqm.aqmcorBytes, this.aqm.aqmcorBytesLength, true);
        
        this.properties.setCorrelation(str);
      } 
      this.properties.setAttempts(this.aqm.aqmatt);
      if (this.aqm.aqmeqnBytes != null) {
        
        String str = this.meg.conv.CharBytesToString(this.aqm.aqmeqnBytes, this.aqm.aqmeqnBytesLength, true);
        
        this.properties.setExceptionQueue(str);
      } 
      this.properties.setMessageState(AQMessageProperties.MessageState.getMessageState(this.aqm.aqmsta));
      this.properties.setEnqueueTime(this.aqm.aqmeqt.timestampValue());
      AQAgentI aQAgentI = new AQAgentI();
      if (this.aqm.senderAgentName != null) {
        aQAgentI.setName(this.meg.conv.CharBytesToString(this.aqm.senderAgentName, this.aqm.senderAgentNameLength, true));
      }

      
      if (this.aqm.senderAgentAddress != null) {
        aQAgentI.setAddress(this.meg.conv.CharBytesToString(this.aqm.senderAgentAddress, this.aqm.senderAgentAddressLength, true));
      }

      
      aQAgentI.setProtocol(this.aqm.senderAgentProtocol);
      
      this.properties.setSender(aQAgentI);
      this.properties.setPreviousQueueMessageId(this.aqm.originalMsgId);
      this.properties.setDeliveryMode(AQMessageProperties.DeliveryMode.getDeliveryMode(this.aqm.aqmflg));

      
      if (this.aqm.aqmetiBytes != null) {
        
        String str = this.meg.conv.CharBytesToString(this.aqm.aqmetiBytes, this.aqm.aqmetiBytes.length, true);
        
        this.properties.setTransactionGroup(str);
      } 
    } 
    
    int j = (int)this.meg.unmarshalUB4();

    
    this.toh.unmarshal(this.meg);
    int k = this.toh.imageLength;

    
    if (k > 0) {

      
      int m = k;
      
      if (this.isRawQueue) {



        
        if (k > 4) {
          m -= 4;
        }

        
        m = Math.min(m, this.dequeueOptions.getMaximumBufferLength());

        
        byte[] arrayOfByte = new byte[m];
        int[] arrayOfInt = new int[1];
        if (k > 4) {
          this.meg.unmarshalCLR(arrayOfByte, 0, arrayOfInt, arrayOfByte.length, 4);
        } else {
          this.meg.unmarshalCLR(arrayOfByte, 0, arrayOfInt, arrayOfByte.length);
        }  this.payload = arrayOfByte;
      
      }
      else {
        
        byte[] arrayOfByte = new byte[m];
        int[] arrayOfInt = new int[1];
        this.meg.unmarshalCLR(arrayOfByte, 0, arrayOfInt, arrayOfByte.length);
        this.payload = arrayOfByte;
      } 
    } 

    
    if (this.dequeueOptions.getRetrieveMessageId()) {
      
      byte[] arrayOfByte = new byte[16];
      this.meg.unmarshalBuffer(arrayOfByte, 0, 16);
      this.dequeuedMessageId = arrayOfByte;
    } 
  }



  
  void processError() throws SQLException {
    if (this.oer.retCode != 25228)
    {
      this.oer.processError();
    }
  }












  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
