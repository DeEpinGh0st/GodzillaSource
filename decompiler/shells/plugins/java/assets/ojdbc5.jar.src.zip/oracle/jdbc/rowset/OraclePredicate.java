package oracle.jdbc.rowset;

import java.sql.SQLException;
import javax.sql.RowSet;
import javax.sql.rowset.Predicate;

public interface OraclePredicate extends Predicate {
  boolean evaluate(RowSet paramRowSet);
  
  boolean evaluate(Object paramObject, int paramInt) throws SQLException;
  
  boolean evaluate(Object paramObject, String paramString) throws SQLException;
}
