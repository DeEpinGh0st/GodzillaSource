package oracle.jdbc.pool;

import java.sql.SQLException;
import java.util.Hashtable;
import java.util.Properties;
import java.util.StringTokenizer;
import javax.naming.Context;
import javax.naming.Name;
import javax.naming.Reference;
import javax.naming.StringRefAddr;
import javax.naming.spi.ObjectFactory;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.xa.client.OracleXADataSource;

































public class OracleDataSourceFactory
  implements ObjectFactory
{
  private static final String CONNECTION_CACHING_ENABLED = "connectionCachingEnabled";
  private static final String CONNECTION_CACHE_NAME = "connectionCacheName";
  private static final String CONNECTION_CACHE_PROPERTIES = "connectionCacheProperties";
  private static final String CONNECTION_PROPERTIES = "connectionProperties";
  private static final String FAST_CONNECTION_FAILOVER_ENABLED = "fastConnectionFailoverEnabled";
  private static final String ONS_CONFIG_STR = "onsConfigStr";
  private static final String ORACLE_CONN_DATA_POOL_SOURCE = "oracle.jdbc.pool.OracleConnectionPoolDataSource";
  private static final String ORACLE_OCI_CONN_POOL = "oracle.jdbc.pool.OracleOCIConnectionPool";
  private static final String ORACLE_DATA_SOURCE = "oracle.jdbc.pool.OracleDataSource";
  private static final String ORACLE_XA_DATA_SOURCE = "oracle.jdbc.xa.client.OracleXADataSource";
  
  public Object getObjectInstance(Object paramObject, Name paramName, Context paramContext, Hashtable paramHashtable) throws Exception {
    Reference reference = (Reference)paramObject;
    OracleDataSource oracleDataSource = null;
    String str = reference.getClassName();
    Properties properties = new Properties();
    
    if (str.equals("oracle.jdbc.pool.OracleDataSource") || str.equals("oracle.jdbc.xa.client.OracleXADataSource")) {
      OracleXADataSource oracleXADataSource;
      
      if (str.equals("oracle.jdbc.pool.OracleDataSource")) {
        oracleDataSource = new OracleDataSource();
      } else {
        
        oracleXADataSource = new OracleXADataSource();
      } 
      
      StringRefAddr stringRefAddr = null;

      
      if ((stringRefAddr = (StringRefAddr)reference.get("connectionCachingEnabled")) != null) {
        String str1 = (String)stringRefAddr.getContent();
        
        if (str1.equals(String.valueOf("true"))) {
          oracleXADataSource.setConnectionCachingEnabled(true);
        }
      } 
      
      if ((stringRefAddr = (StringRefAddr)reference.get("connectionCacheName")) != null) {
        oracleXADataSource.setConnectionCacheName((String)stringRefAddr.getContent());
      }
      
      if ((stringRefAddr = (StringRefAddr)reference.get("connectionCacheProperties")) != null) {
        String str1 = (String)stringRefAddr.getContent();
        Properties properties1 = extractConnectionCacheProperties(str1);
        oracleXADataSource.setConnectionCacheProperties(properties1);
      } 
      
      if ((stringRefAddr = (StringRefAddr)reference.get("connectionProperties")) != null) {
        String str1 = (String)stringRefAddr.getContent();
        Properties properties1 = extractConnectionProperties(str1);
        oracleXADataSource.setConnectionProperties(properties1);
      } 
      
      if ((stringRefAddr = (StringRefAddr)reference.get("fastConnectionFailoverEnabled")) != null) {
        
        String str1 = (String)stringRefAddr.getContent();
        
        if (str1.equals(String.valueOf("true"))) {
          oracleXADataSource.setFastConnectionFailoverEnabled(true);
        }
      } 
      
      if ((stringRefAddr = (StringRefAddr)reference.get("onsConfigStr")) != null) {
        oracleXADataSource.setONSConfiguration((String)stringRefAddr.getContent());
      }
    }
    else if (str.equals("oracle.jdbc.pool.OracleConnectionPoolDataSource")) {
      oracleDataSource = new OracleConnectionPoolDataSource();
    }
    else if (str.equals("oracle.jdbc.pool.OracleOCIConnectionPool")) {
      oracleDataSource = new OracleOCIConnectionPool();
      
      String str1 = null;
      String str2 = null;
      String str3 = null;
      String str4 = null;
      String str5 = null;
      String str6 = null;
      String str7 = null;
      StringRefAddr stringRefAddr = null;
      
      Object object = null;
      String str8 = null;


      
      if ((stringRefAddr = (StringRefAddr)reference.get("connpool_min_limit")) != null)
      {
        str1 = (String)stringRefAddr.getContent();
      }
      
      if ((stringRefAddr = (StringRefAddr)reference.get("connpool_max_limit")) != null)
      {
        str2 = (String)stringRefAddr.getContent();
      }
      
      if ((stringRefAddr = (StringRefAddr)reference.get("connpool_increment")) != null)
      {
        str3 = (String)stringRefAddr.getContent();
      }
      
      if ((stringRefAddr = (StringRefAddr)reference.get("connpool_active_size")) != null)
      {
        str4 = (String)stringRefAddr.getContent();
      }
      
      if ((stringRefAddr = (StringRefAddr)reference.get("connpool_pool_size")) != null)
      {
        str5 = (String)stringRefAddr.getContent();
      }
      
      if ((stringRefAddr = (StringRefAddr)reference.get("connpool_timeout")) != null)
      {
        str6 = (String)stringRefAddr.getContent();
      }
      
      if ((stringRefAddr = (StringRefAddr)reference.get("connpool_nowait")) != null)
      {
        str7 = (String)stringRefAddr.getContent();
      }
      
      if ((stringRefAddr = (StringRefAddr)reference.get("transactions_distributed")) != null)
      {
        str8 = (String)stringRefAddr.getContent();
      }


      
      properties.put("connpool_min_limit", str1);
      properties.put("connpool_max_limit", str2);
      properties.put("connpool_increment", str3);
      properties.put("connpool_active_size", str4);
      
      properties.put("connpool_pool_size", str5);
      properties.put("connpool_timeout", str6);
      
      if (str7 == "true") {
        properties.put("connpool_nowait", str7);
      }
      
      if (str8 == "true") {
        properties.put("transactions_distributed", str8);
      
      }
    
    }
    else {
      
      return null;
    } 
    
    if (oracleDataSource != null) {
      
      StringRefAddr stringRefAddr = null;
      
      if ((stringRefAddr = (StringRefAddr)reference.get("url")) != null)
      {
        oracleDataSource.setURL((String)stringRefAddr.getContent());
      }
      
      if ((stringRefAddr = (StringRefAddr)reference.get("userName")) != null || (stringRefAddr = (StringRefAddr)reference.get("u")) != null || (stringRefAddr = (StringRefAddr)reference.get("user")) != null)
      {
        
        oracleDataSource.setUser((String)stringRefAddr.getContent());
      }
      
      if ((stringRefAddr = (StringRefAddr)reference.get("passWord")) != null || (stringRefAddr = (StringRefAddr)reference.get("password")) != null)
      {
        oracleDataSource.setPassword((String)stringRefAddr.getContent());
      }
      
      if ((stringRefAddr = (StringRefAddr)reference.get("description")) != null || (stringRefAddr = (StringRefAddr)reference.get("describe")) != null)
      {
        oracleDataSource.setDescription((String)stringRefAddr.getContent());
      }
      
      if ((stringRefAddr = (StringRefAddr)reference.get("driverType")) != null || (stringRefAddr = (StringRefAddr)reference.get("driver")) != null)
      {
        oracleDataSource.setDriverType((String)stringRefAddr.getContent());
      }
      
      if ((stringRefAddr = (StringRefAddr)reference.get("serverName")) != null || (stringRefAddr = (StringRefAddr)reference.get("host")) != null)
      {
        oracleDataSource.setServerName((String)stringRefAddr.getContent());
      }
      
      if ((stringRefAddr = (StringRefAddr)reference.get("databaseName")) != null || (stringRefAddr = (StringRefAddr)reference.get("sid")) != null)
      {
        oracleDataSource.setDatabaseName((String)stringRefAddr.getContent());
      }
      
      if ((stringRefAddr = (StringRefAddr)reference.get("serviceName")) != null) {
        oracleDataSource.setServiceName((String)stringRefAddr.getContent());
      }
      
      if ((stringRefAddr = (StringRefAddr)reference.get("networkProtocol")) != null || (stringRefAddr = (StringRefAddr)reference.get("protocol")) != null)
      {
        oracleDataSource.setNetworkProtocol((String)stringRefAddr.getContent());
      }
      
      if ((stringRefAddr = (StringRefAddr)reference.get("portNumber")) != null || (stringRefAddr = (StringRefAddr)reference.get("port")) != null) {
        
        String str1 = (String)stringRefAddr.getContent();
        
        oracleDataSource.setPortNumber(Integer.parseInt(str1));
      } 
      
      if ((stringRefAddr = (StringRefAddr)reference.get("tnsentryname")) != null || (stringRefAddr = (StringRefAddr)reference.get("tns")) != null) {
        
        oracleDataSource.setTNSEntryName((String)stringRefAddr.getContent());
      }
      else if (str.equals("oracle.jdbc.pool.OracleOCIConnectionPool")) {













        
        String str1 = null;
        
        if ((stringRefAddr = (StringRefAddr)reference.get("connpool_is_poolcreated")) != null)
        {
          str1 = (String)stringRefAddr.getContent();
        }
        
        if (str1.equals(String.valueOf("true"))) {
          ((OracleOCIConnectionPool)oracleDataSource).setPoolConfig(properties);
        }
      } 
    } 
    
    return oracleDataSource;
  }

















  
  private Properties extractConnectionCacheProperties(String paramString) throws SQLException {
    Properties properties = new Properties();

    
    paramString = paramString.substring(1, paramString.length() - 1);

    
    int i = paramString.indexOf("AttributeWeights", 0);
    
    if (i >= 0) {







      
      if (paramString.charAt(i + 16) != '=' || (i > 0 && paramString.charAt(i - 1) != ' ')) {


        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 139);
        
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      Properties properties1 = new Properties();
      int j = paramString.indexOf("}", i);
      String str1 = paramString.substring(i, j);

      
      String str2 = str1.substring(18);
      
      StringTokenizer stringTokenizer1 = new StringTokenizer(str2, ", ");

      
      synchronized (stringTokenizer1) {
        
        while (stringTokenizer1.hasMoreTokens()) {
          
          String str3 = stringTokenizer1.nextToken();
          int k = str3.length();
          int m = str3.indexOf("=");
          
          String str4 = str3.substring(0, m);
          String str5 = str3.substring(m + 1, k);
          
          properties1.setProperty(str4, str5);
        } 
      } 
      
      properties.put("AttributeWeights", properties1);

      
      if (i > 0 && j + 1 == paramString.length()) {
        
        paramString = paramString.substring(0, i - 2);
      }
      else if (i > 0 && j + 1 < paramString.length()) {
        
        String str3 = paramString.substring(0, i - 2);
        String str4 = paramString.substring(j + 1, paramString.length());
        
        paramString = str3.concat(str4);
      }
      else {
        
        paramString = paramString.substring(j + 2, paramString.length());
      } 
    } 

    
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, ", ");
    
    synchronized (stringTokenizer) {
      
      while (stringTokenizer.hasMoreTokens()) {
        
        String str1 = stringTokenizer.nextToken();
        int j = str1.length();
        int k = str1.indexOf("=");
        
        String str2 = str1.substring(0, k);
        String str3 = str1.substring(k + 1, j);
        
        properties.setProperty(str2, str3);
      } 
    } 
    return properties;
  }





  
  private Properties extractConnectionProperties(String paramString) throws SQLException {
    Properties properties = new Properties();

    
    paramString = paramString.substring(1, paramString.length() - 1);
    
    String[] arrayOfString = paramString.split(";");
    
    for (String str1 : arrayOfString) {
      int i = str1.length();
      int j = str1.indexOf("=");
      
      if (i == 0 || j <= 0) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190);
        
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      String str2 = str1.substring(0, j);
      String str3 = str1.substring(j + 1, i);
      
      properties.setProperty(str2.trim(), str3.trim());
    } 
    return properties;
  }











  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
