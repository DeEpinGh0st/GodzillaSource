package oracle.jdbc.driver;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import oracle.sql.ARRAY;
import oracle.sql.BFILE;
import oracle.sql.BINARY_FLOAT;
import oracle.sql.BLOB;
import oracle.sql.CLOB;
import oracle.sql.DATE;
import oracle.sql.Datum;
import oracle.sql.INTERVALDS;
import oracle.sql.NUMBER;
import oracle.sql.OPAQUE;
import oracle.sql.ORAData;
import oracle.sql.REF;
import oracle.sql.STRUCT;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPTZ;

abstract class BaseResultSet extends OracleResultSet {
  SQLWarning sqlWarning = null;


  
  boolean autoRefetch = true;

  
  boolean closed = false;

  
  boolean close_statement_on_close = false;


  
  public void closeStatementOnClose() {
    this.close_statement_on_close = true;
  }












  
  public void beforeFirst() throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "beforeFirst");
    sQLException.fillInStackTrace();
    throw sQLException;
  }





  
  public void afterLast() throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "afterLast");
    sQLException.fillInStackTrace();
    throw sQLException;
  }





  
  public boolean first() throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "first");
    sQLException.fillInStackTrace();
    throw sQLException;
  }





  
  public boolean last() throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "last");
    sQLException.fillInStackTrace();
    throw sQLException;
  }





  
  public boolean absolute(int paramInt) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "absolute");
    sQLException.fillInStackTrace();
    throw sQLException;
  }





  
  public boolean relative(int paramInt) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "relative");
    sQLException.fillInStackTrace();
    throw sQLException;
  }





  
  public boolean previous() throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "previous");
    sQLException.fillInStackTrace();
    throw sQLException;
  }










  
  public void setFetchDirection(int paramInt) throws SQLException {
    if (paramInt == 1000)
      return; 
    if (paramInt == 1001 || paramInt == 1002) {
      
      SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "setFetchDirection(FETCH_REVERSE, FETCH_UNKNOWN)");
      sQLException1.fillInStackTrace();
      throw sQLException1;
    } 

    
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setFetchDirection");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public int getFetchDirection() throws SQLException {
    return 1000;
  }



  
  public int getType() throws SQLException {
    return 1003;
  }



  
  public int getConcurrency() throws SQLException {
    return 1007;
  }



  
  public SQLWarning getWarnings() throws SQLException {
    return this.sqlWarning;
  }



  
  public void clearWarnings() throws SQLException {
    this.sqlWarning = null;
  }










  
  public void updateArray(int paramInt, Array paramArray) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateArray");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBigDecimal");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateBlob(int paramInt, Blob paramBlob) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBlob");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateBoolean(int paramInt, boolean paramBoolean) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBoolean");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateByte(int paramInt, byte paramByte) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateByte");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBytes");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateClob(int paramInt, Clob paramClob) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateClob");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateDate(int paramInt, Date paramDate) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateDate");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateDate(int paramInt, Date paramDate, Calendar paramCalendar) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateDate");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateDouble(int paramInt, double paramDouble) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateDouble");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateFloat(int paramInt, float paramFloat) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateFloat");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateInt(int paramInt1, int paramInt2) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateInt");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateLong(int paramInt, long paramLong) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateLong");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateObject(int paramInt, Object paramObject) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateObject");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateObject(int paramInt1, Object paramObject, int paramInt2) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateObject");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateRef(int paramInt, Ref paramRef) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateRef");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateShort(int paramInt, short paramShort) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateShort");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateString(int paramInt, String paramString) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateString");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateTime(int paramInt, Time paramTime) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTime");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateTime(int paramInt, Time paramTime, Calendar paramCalendar) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTime");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTimestamp");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTimestamp");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateURL(int paramInt, URL paramURL) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateURL");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateARRAY(int paramInt, ARRAY paramARRAY) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateARRAY");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateBFILE(int paramInt, BFILE paramBFILE) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBFILE");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateBfile(int paramInt, BFILE paramBFILE) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBfile");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateBinaryFloat(int paramInt, float paramFloat) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBinaryFloat");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateBinaryFloat(int paramInt, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBinaryFloat");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateBinaryDouble(int paramInt, double paramDouble) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBinaryDouble");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateBinaryDouble(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBinaryDouble");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateBLOB(int paramInt, BLOB paramBLOB) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBLOB");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateCHAR(int paramInt, CHAR paramCHAR) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateCHAR");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateCLOB(int paramInt, CLOB paramCLOB) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateCLOB");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateCursor(int paramInt, ResultSet paramResultSet) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateCursor");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateCustomDatum(int paramInt, CustomDatum paramCustomDatum) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateCustomDatum");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateDATE(int paramInt, DATE paramDATE) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateDATE");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateFixedCHAR(int paramInt, String paramString) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateFixedCHAR");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateINTERVALDS(int paramInt, INTERVALDS paramINTERVALDS) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateINTERVALDS");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateINTERVALYM(int paramInt, INTERVALYM paramINTERVALYM) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateINTERVALYM");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateNUMBER(int paramInt, NUMBER paramNUMBER) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateNUMBER");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateOPAQUE(int paramInt, OPAQUE paramOPAQUE) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateOPAQUE");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateOracleObject(int paramInt, Datum paramDatum) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateOracleObject");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateORAData(int paramInt, ORAData paramORAData) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateORAData");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateRAW(int paramInt, RAW paramRAW) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateRAW");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateREF(int paramInt, REF paramREF) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateREF");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateRefType(int paramInt, REF paramREF) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateRefType");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateROWID(int paramInt, ROWID paramROWID) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateROWID");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateSTRUCT(int paramInt, STRUCT paramSTRUCT) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateSTRUCT");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateTIMESTAMPLTZ(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTIMESTAMPLTZ");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateTIMESTAMPTZ(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTIMESTAMPTZ");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateTIMESTAMP(int paramInt, TIMESTAMP paramTIMESTAMP) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTIMESTAMP");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateAsciiStream");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBinaryStream");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateCharacterStream");
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public void updateUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateUnicodeStream");
    sQLException.fillInStackTrace();
    throw sQLException;
  }









  
  public void updateNull(int paramInt) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateNull");
    sQLException.fillInStackTrace();
    throw sQLException;
  }





  
  public boolean rowUpdated() throws SQLException {
    return false;
  }



  
  public boolean rowInserted() throws SQLException {
    return false;
  }



  
  public boolean rowDeleted() throws SQLException {
    return false;
  }




  
  public void insertRow() throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "insertRow");
    sQLException.fillInStackTrace();
    throw sQLException;
  }





  
  public void updateRow() throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateRow");
    sQLException.fillInStackTrace();
    throw sQLException;
  }





  
  public void deleteRow() throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "deleteRow");
    sQLException.fillInStackTrace();
    throw sQLException;
  }





  
  public void refreshRow() throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, (Object)null);
    sQLException.fillInStackTrace();
    throw sQLException;
  }





  
  public void cancelRowUpdates() throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "cancelRowUpdates");
    sQLException.fillInStackTrace();
    throw sQLException;
  }





  
  public void moveToInsertRow() throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "moveToInsertRow");
    sQLException.fillInStackTrace();
    throw sQLException;
  }





  
  public void moveToCurrentRow() throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "moveToCurrentRow");
    sQLException.fillInStackTrace();
    throw sQLException;
  }

























  
  public void setAutoRefetch(boolean paramBoolean) throws SQLException {
    this.autoRefetch = paramBoolean;
  }













  
  public boolean getAutoRefetch() throws SQLException {
    return this.autoRefetch;
  }



  
  public void close() throws SQLException {
    this.closed = true;
  }







  
  OracleStatement getOracleStatement() throws SQLException {
    return null;
  }










  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
