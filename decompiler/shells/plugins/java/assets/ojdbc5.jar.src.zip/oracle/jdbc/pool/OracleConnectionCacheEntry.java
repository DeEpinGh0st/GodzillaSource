package oracle.jdbc.pool;

import java.util.HashMap;
import java.util.Vector;





















class OracleConnectionCacheEntry
{
  Vector userConnList = null;
  HashMap attrConnMap = null;
}
