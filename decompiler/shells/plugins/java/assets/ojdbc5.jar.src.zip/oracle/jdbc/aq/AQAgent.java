package oracle.jdbc.aq;

import java.sql.SQLException;

public interface AQAgent {
  void setAddress(String paramString) throws SQLException;
  
  String getAddress();
  
  void setName(String paramString) throws SQLException;
  
  String getName();
  
  void setProtocol(int paramInt) throws SQLException;
  
  int getProtocol();
  
  String toString();
}
