package oracle.jdbc.oci;

import java.sql.SQLException;
import java.util.Properties;
import oracle.jdbc.driver.OracleOCIConnection;

























public class OracleOCIConnection
  extends OracleOCIConnection
{
  public OracleOCIConnection(String paramString, Properties paramProperties, Object paramObject) throws SQLException {
    super(paramString, paramProperties, paramObject);
  }
}
