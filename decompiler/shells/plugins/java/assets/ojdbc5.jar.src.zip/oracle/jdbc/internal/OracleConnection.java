package oracle.jdbc.internal;

import java.net.SocketException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.EnumSet;
import java.util.Enumeration;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Executor;
import javax.transaction.xa.XAResource;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.oracore.OracleTypeADT;
import oracle.jdbc.oracore.OracleTypeCLOB;
import oracle.jdbc.pool.OracleConnectionCacheCallback;
import oracle.jdbc.pool.OraclePooledConnection;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.BFILE;
import oracle.sql.BLOB;
import oracle.sql.BfileDBAccess;
import oracle.sql.BlobDBAccess;
import oracle.sql.CLOB;
import oracle.sql.ClobDBAccess;
import oracle.sql.CustomDatum;
import oracle.sql.Datum;
import oracle.sql.StructDescriptor;
import oracle.sql.TIMEZONETAB;











































public interface OracleConnection
  extends OracleConnection
{
  public static final String CONNECTION_PROPERTY_LOGON_CAP = "oracle.jdbc.thinLogonCapability";
  public static final String CONNECTION_PROPERTY_LOGON_CAP_DEFAULT = "o5";
  public static final byte CONNECTION_PROPERTY_LOGON_CAP_ACCESSMODE = 3;
  public static final String CONNECTION_PROPERTY_NLS_LANG_BACKDOOR = "oracle.jdbc.ociNlsLangBackwardCompatible";
  public static final String CONNECTION_PROPERTY_NLS_LANG_BACKDOOR_DEFAULT = "false";
  public static final byte CONNECTION_PROPERTY_NLS_LANG_BACKDOOR_ACCESSMODE = 3;
  public static final String CONNECTION_PROPERTY_SPAWN_NEW_THREAD_TO_CANCEL = "oracle.jdbc.spawnNewThreadToCancel";
  public static final String CONNECTION_PROPERTY_SPAWN_NEW_THREAD_TO_CANCEL_DEFAULT = "false";
  public static final byte CONNECTION_PROPERTY_SPAWN_NEW_THREAD_TO_CANCEL_ACCESSMODE = 3;
  public static final String CONNECTION_PROPERTY_OVERRIDE_ENABLE_READ_DATA_IN_LOCATOR = "oracle.jdbc.overrideEnableReadDataInLocator";
  public static final String CONNECTION_PROPERTY_OVERRIDE_ENABLE_READ_DATA_IN_LOCATOR_DEFAULT = "false";
  public static final byte CONNECTION_PROPERTY_OVERRIDE_ENABLE_READ_DATA_IN_LOCATOR_ACCESSMODE = 3;
  public static final String CONNECTION_PROPERTY_PERMIT_TIMESTAMP_DATE_MISMATCH = "oracle.jdbc.internal.permitBindDateDefineTimestampMismatch";
  public static final String CONNECTION_PROPERTY_PERMIT_TIMESTAMP_DATE_MISMATCH_DEFAULT = "false";
  public static final byte CONNECTION_PROPERTY_PERMIT_TIMESTAMP_DATE_MISMATCH_ACCESSMODE = 3;
  public static final String CONNECTION_PROPERTY_QUICK_ASCII_CONVERSION = "oracle.jdbc.quickASCIIConversion";
  public static final String CONNECTION_PROPERTY_QUICK_ASCII_CONVERSION_DEFAULT = "false";
  public static final byte CONNECTION_PROPERTY_QUICK_ASCII_CONVERSION_ACCESSMODE = 3;
  public static final String CONNECTION_PROPERTY_ENABLE_JAVANET_FASTPATH = "oracle.jdbc.enableJavaNetFastPath";
  public static final String CONNECTION_PROPERTY_ENABLE_JAVANET_FASTPATH_DEFAULT = "false";
  public static final byte CONNECTION_PROPERTY_ENABLE_JAVANET_FASTPATH_ACCESSMODE = 3;
  public static final String CONNECTION_PROPERTY_PLSQL_VARCHAR_PARAMETER_4K_ONLY = "oracle.jdbc.plsqlVarcharParameter4KOnly";
  public static final String CONNECTION_PROPERTY_PLSQL_VARCHAR_PARAMETER_4K_ONLY_DEFAULT = "false";
  public static final byte CONNECTION_PROPERTY_PLSQL_VARCHAR_PARAMETER_4K_ONLY_ACCESSMODE = 3;
  public static final int CHAR_TO_ASCII = 0;
  public static final int CHAR_TO_UNICODE = 1;
  public static final int RAW_TO_ASCII = 2;
  public static final int RAW_TO_UNICODE = 3;
  public static final int UNICODE_TO_CHAR = 4;
  public static final int ASCII_TO_CHAR = 5;
  public static final int NONE = 6;
  public static final int JAVACHAR_TO_CHAR = 7;
  public static final int RAW_TO_JAVACHAR = 8;
  public static final int CHAR_TO_JAVACHAR = 9;
  public static final int GLOBAL_TXN = 1;
  public static final int NO_GLOBAL_TXN = 0;
  
  short getStructAttrNCsId() throws SQLException;
  
  Map getTypeMap() throws SQLException;
  
  Properties getDBAccessProperties() throws SQLException;
  
  Properties getOCIHandles() throws SQLException;
  
  String getDatabaseProductVersion() throws SQLException;
  
  String getURL() throws SQLException;
  
  short getVersionNumber() throws SQLException;
  
  Map getJavaObjectTypeMap();
  
  void setJavaObjectTypeMap(Map paramMap);
  
  byte getInstanceProperty(InstanceProperty paramInstanceProperty) throws SQLException;
  
  BfileDBAccess createBfileDBAccess() throws SQLException;
  
  BlobDBAccess createBlobDBAccess() throws SQLException;
  
  ClobDBAccess createClobDBAccess() throws SQLException;
  
  void setDefaultFixedString(boolean paramBoolean);
  
  boolean getDefaultFixedString();
  
  OracleConnection getWrapper();
  
  Class classForNameAndSchema(String paramString1, String paramString2) throws ClassNotFoundException;
  
  void setFDO(byte[] paramArrayOfbyte) throws SQLException;
  
  byte[] getFDO(boolean paramBoolean) throws SQLException;
  
  boolean getBigEndian() throws SQLException;
  
  Object getDescriptor(byte[] paramArrayOfbyte);
  
  void putDescriptor(byte[] paramArrayOfbyte, Object paramObject) throws SQLException;
  
  OracleConnection getPhysicalConnection();
  
  void removeDescriptor(String paramString);
  
  void removeAllDescriptor();
  
  int numberOfDescriptorCacheEntries();
  
  Enumeration descriptorCacheKeys();
  
  long getTdoCState(String paramString1, String paramString2) throws SQLException;
  
  BufferCacheStatistics getByteBufferCacheStatistics();
  
  BufferCacheStatistics getCharBufferCacheStatistics();
  
  Datum toDatum(CustomDatum paramCustomDatum) throws SQLException;
  
  short getDbCsId() throws SQLException;
  
  short getJdbcCsId() throws SQLException;
  
  short getNCharSet();
  
  ResultSet newArrayDataResultSet(Datum[] paramArrayOfDatum, long paramLong, int paramInt, Map paramMap) throws SQLException;
  
  ResultSet newArrayDataResultSet(ARRAY paramARRAY, long paramLong, int paramInt, Map paramMap) throws SQLException;
  
  ResultSet newArrayLocatorResultSet(ArrayDescriptor paramArrayDescriptor, byte[] paramArrayOfbyte, long paramLong, int paramInt, Map paramMap) throws SQLException;
  
  ResultSetMetaData newStructMetaData(StructDescriptor paramStructDescriptor) throws SQLException;
  
  void getForm(OracleTypeADT paramOracleTypeADT, OracleTypeCLOB paramOracleTypeCLOB, int paramInt) throws SQLException;
  
  int CHARBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt, char[] paramArrayOfchar) throws SQLException;
  
  int NCHARBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt, char[] paramArrayOfchar) throws SQLException;
  
  boolean IsNCharFixedWith();
  
  short getDriverCharSet();
  
  int getC2SNlsRatio();
  
  int getMaxCharSize() throws SQLException;
  
  int getMaxCharbyteSize();
  
  int getMaxNCharbyteSize();
  
  boolean isCharSetMultibyte(short paramShort);
  
  int javaCharsToCHARBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException;
  
  int javaCharsToNCHARBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException;
  
  void setStartTime(long paramLong) throws SQLException;
  
  long getStartTime() throws SQLException;
  
  boolean isStatementCacheInitialized();
  
  void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection) throws SQLException;
  
  void setTypeMap(Map paramMap) throws SQLException;
  
  String getProtocolType();
  
  Connection getLogicalConnection(OraclePooledConnection paramOraclePooledConnection, boolean paramBoolean) throws SQLException;
  
  void setTxnMode(int paramInt);
  
  int getTxnMode();
  
  int getHeapAllocSize() throws SQLException;
  
  int getOCIEnvHeapAllocSize() throws SQLException;
  
  void setAbandonedTimeoutEnabled(boolean paramBoolean) throws SQLException;
  
  int getHeartbeatNoChangeCount() throws SQLException;
  
  void closeInternal(boolean paramBoolean) throws SQLException;
  
  void cleanupAndClose(boolean paramBoolean) throws SQLException;
  
  OracleConnectionCacheCallback getConnectionCacheCallbackObj() throws SQLException;
  
  Object getConnectionCacheCallbackPrivObj() throws SQLException;
  
  int getConnectionCacheCallbackFlag() throws SQLException;
  
  Properties getServerSessionInfo() throws SQLException;
  
  CLOB createClob(byte[] paramArrayOfbyte) throws SQLException;
  
  CLOB createClobWithUnpickledBytes(byte[] paramArrayOfbyte) throws SQLException;
  
  CLOB createClob(byte[] paramArrayOfbyte, short paramShort) throws SQLException;
  
  BLOB createBlob(byte[] paramArrayOfbyte) throws SQLException;
  
  BLOB createBlobWithUnpickledBytes(byte[] paramArrayOfbyte) throws SQLException;
  
  BFILE createBfile(byte[] paramArrayOfbyte) throws SQLException;
  
  boolean isDescriptorSharable(OracleConnection paramOracleConnection) throws SQLException;
  
  OracleStatement refCursorCursorToStatement(int paramInt) throws SQLException;
  
  XAResource getXAResource() throws SQLException;
  
  boolean isV8Compatible() throws SQLException;
  
  boolean getMapDateToTimestamp();
  
  byte[] createLightweightSession(String paramString, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfint) throws SQLException;
  
  void executeLightweightSessionRoundtrip(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfint) throws SQLException;
  
  void executeLightweightSessionPiggyback(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2) throws SQLException;
  
  void doXSNamespaceOp(XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace, XSNamespace[][] paramArrayOfXSNamespace1) throws SQLException;
  
  void doXSNamespaceOp(XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace) throws SQLException;
  
  String getDefaultSchemaNameForNamedTypes() throws SQLException;
  
  void setUsable(boolean paramBoolean);
  
  Class getClassForType(String paramString, Map<String, Class> paramMap);
  
  void addXSEventListener(XSEventListener paramXSEventListener) throws SQLException;
  
  void addXSEventListener(XSEventListener paramXSEventListener, Executor paramExecutor) throws SQLException;
  
  void removeXSEventListener(XSEventListener paramXSEventListener) throws SQLException;
  
  int getTimezoneVersionNumber() throws SQLException;
  
  TIMEZONETAB getTIMEZONETAB() throws SQLException;
  
  String getDatabaseTimeZone() throws SQLException;
  
  boolean getTimestamptzInGmt();
  
  boolean getUse1900AsYearForTime();
  
  boolean isDataInLocatorEnabled() throws SQLException;
  
  boolean isLobStreamPosStandardCompliant() throws SQLException;
  
  long getCurrentSCN() throws SQLException;
  
  EnumSet<TransactionState> getTransactionState() throws SQLException;
  
  boolean isConnectionSocketKeepAlive() throws SocketException, SQLException;
  
  public enum InstanceProperty
  {
    ASM_VOLUME_SUPPORTED,











    
    INSTANCE_TYPE;
  }






  
  public enum TransactionState
  {
    TRANSACTION_STARTED,


    
    TRANSACTION_ENDED,


    
    TRANSACTION_READONLY,



    
    TRANSACTION_INTENTION;
  }






























































































































































































































































































































































































































































































































































  
  public enum XSOperationCode
  {
    NAMESPACE_CREATE(1),
    NAMESPACE_DELETE(2),
    ATTRIBUTE_CREATE(3),
    ATTRIBUTE_SET(4),
    ATTRIBUTE_DELETE(5),
    ATTRIBUTE_RESET(6);
    private final int code;
    
    XSOperationCode(int param1Int1) {
      this.code = param1Int1;
    }

    
    public final int getCode() {
      return this.code;
    }
  }
  
  public static interface BufferCacheStatistics {
    int getId();
    
    int[] getBufferSizes();
    
    int getCacheHits(int param1Int);
    
    int getCacheMisses(int param1Int);
    
    int getBuffersCached(int param1Int);
    
    int getBucketsFull(int param1Int);
    
    int getReferencesCleared(int param1Int);
    
    int getTooBigToCache();
  }
}
