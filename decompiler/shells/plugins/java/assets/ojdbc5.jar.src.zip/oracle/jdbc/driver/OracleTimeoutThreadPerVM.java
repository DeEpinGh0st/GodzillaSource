package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;





















class OracleTimeoutThreadPerVM
  extends OracleTimeout
{
  private static final OracleTimeoutPollingThread watchdog = new OracleTimeoutPollingThread();


  
  private OracleStatement statement;


  
  private long interruptAfter;


  
  private String name;


  
  OracleTimeoutThreadPerVM(String paramString) {
    this.name = paramString;
    this.interruptAfter = Long.MAX_VALUE;
    watchdog.addTimeout(this);
  }










  
  void close() {
    watchdog.removeTimeout(this);
  }















  
  synchronized void setTimeout(long paramLong, OracleStatement paramOracleStatement) throws SQLException {
    if (this.interruptAfter != Long.MAX_VALUE) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 131);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    this.statement = paramOracleStatement;
    this.interruptAfter = System.currentTimeMillis() + paramLong;
  }




















  
  synchronized void cancelTimeout() throws SQLException {
    this.statement = null;
    this.interruptAfter = Long.MAX_VALUE;
  }























  
  void interruptIfAppropriate(long paramLong) {
    if (paramLong > this.interruptAfter)
    {
      synchronized (this) {
        
        if (paramLong > this.interruptAfter) {

          
          if (this.statement.connection.spawnNewThreadToCancel) {
            final OracleStatement s = this.statement;
            Thread thread = new Thread(new Runnable() {
                  public void run() {
                    try {
                      s.cancel();
                    }
                    catch (Throwable throwable) {}
                  }
                });

            
            thread.setName("interruptIfAppropriate_" + this);
            thread.setDaemon(true);
            thread.setPriority(10);
            thread.start();
          } else {
            
            try {
              this.statement.cancel();
            }
            catch (Throwable throwable) {}
          } 


          
          this.statement = null;
          this.interruptAfter = Long.MAX_VALUE;
        } 
      } 
    }
  }












  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }



  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
