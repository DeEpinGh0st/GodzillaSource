package oracle.jdbc.rowset;

import java.io.Serializable;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import javax.sql.RowSet;
import javax.sql.RowSetEvent;
import javax.sql.RowSetListener;
import javax.sql.rowset.Joinable;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;

























































































































































































































abstract class OracleRowSet
  implements Serializable, Cloneable, Joinable
{
  protected String dataSource;
  protected String dataSourceName;
  protected String url;
  protected String username;
  protected String password;
  protected Map typeMap;
  protected int maxFieldSize;
  protected int maxRows;
  protected int queryTimeout;
  protected int fetchSize;
  protected int transactionIsolation;
  protected boolean escapeProcessing;
  protected String command;
  protected int concurrency;
  protected boolean readOnly;
  protected int fetchDirection;
  protected int rowsetType;
  protected boolean showDeleted;
  protected Vector listener;
  protected RowSetEvent rowsetEvent;
  protected Vector matchColumnIndexes;
  protected Vector matchColumnNames;
  protected boolean isClosed;
  
  protected OracleRowSet() throws SQLException {
    initializeProperties();



    
    this.matchColumnIndexes = new Vector(10);
    this.matchColumnNames = new Vector(10);
    
    this.listener = new Vector();
    this.rowsetEvent = new RowSetEvent((RowSet)this);
    
    this.isClosed = false;
  }









  
  protected void initializeProperties() {
    this.command = null;
    this.concurrency = 1007;
    this.dataSource = null;
    this.dataSourceName = null;
    
    this.escapeProcessing = true;
    this.fetchDirection = 1002;
    this.fetchSize = 0;
    this.maxFieldSize = 0;
    this.maxRows = 0;
    this.queryTimeout = 0;
    this.readOnly = false;
    this.showDeleted = false;
    this.transactionIsolation = 2;
    this.rowsetType = 1005;
    this.typeMap = new HashMap<Object, Object>();
    this.username = null;
    this.password = null;
    this.url = null;
  }












  
  public String getCommand() {
    return this.command;
  }





  
  public int getConcurrency() throws SQLException {
    return this.concurrency;
  }







  
  public String getDataSource() {
    return this.dataSource;
  }




  
  public String getDataSourceName() {
    return this.dataSourceName;
  }





  
  public boolean getEscapeProcessing() throws SQLException {
    return this.escapeProcessing;
  }





  
  public int getFetchDirection() throws SQLException {
    return this.fetchDirection;
  }





  
  public int getFetchSize() throws SQLException {
    return this.fetchSize;
  }





  
  public int getMaxFieldSize() throws SQLException {
    return this.maxFieldSize;
  }





  
  public int getMaxRows() throws SQLException {
    return this.maxRows;
  }




  
  public String getPassword() {
    return this.password;
  }





  
  public int getQueryTimeout() throws SQLException {
    return this.queryTimeout;
  }




  
  public boolean getReadOnly() {
    return isReadOnly();
  }




  
  public boolean isReadOnly() {
    return this.readOnly;
  }




  
  public boolean getShowDeleted() {
    return this.showDeleted;
  }




  
  public int getTransactionIsolation() {
    return this.transactionIsolation;
  }





  
  public int getType() throws SQLException {
    return this.rowsetType;
  }





  
  public Map getTypeMap() throws SQLException {
    return this.typeMap;
  }




  
  public String getUrl() {
    return this.url;
  }




  
  public String getUsername() {
    return this.username;
  }






  
  public void setCommand(String paramString) throws SQLException {
    this.command = paramString;
  }






  
  public void setConcurrency(int paramInt) throws SQLException {
    if (paramInt == 1007 || paramInt == 1008) {
      this.concurrency = paramInt;
    } else {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }












  
  public void setDataSource(String paramString) {
    this.dataSource = paramString;
  }






  
  public void setDataSourceName(String paramString) throws SQLException {
    this.dataSourceName = paramString;
  }






  
  public void setEscapeProcessing(boolean paramBoolean) throws SQLException {
    this.escapeProcessing = paramBoolean;
  }












  
  public void setFetchDirection(int paramInt) throws SQLException {
    this.fetchDirection = paramInt;
  }






  
  public void setFetchSize(int paramInt) throws SQLException {
    this.fetchSize = paramInt;
  }







  
  public void setMaxFieldSize(int paramInt) throws SQLException {
    this.maxFieldSize = paramInt;
  }






  
  public void setMaxRows(int paramInt) throws SQLException {
    this.maxRows = paramInt;
  }






  
  public void setPassword(String paramString) throws SQLException {
    this.password = paramString;
  }






  
  public void setQueryTimeout(int paramInt) throws SQLException {
    this.queryTimeout = paramInt;
  }







  
  public void setReadOnly(boolean paramBoolean) throws SQLException {
    this.readOnly = paramBoolean;
  }






  
  public void setShowDeleted(boolean paramBoolean) throws SQLException {
    this.showDeleted = paramBoolean;
  }






  
  public void setTransactionIsolation(int paramInt) throws SQLException {
    this.transactionIsolation = paramInt;
  }






  
  public void setType(int paramInt) throws SQLException {
    if (paramInt == 1003 || paramInt == 1004 || paramInt == 1005) {

      
      this.rowsetType = paramInt;
    } else {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }






  
  public void setTypeMap(Map paramMap) throws SQLException {
    this.typeMap = paramMap;
  }





  
  public void setUrl(String paramString) {
    this.url = paramString;
  }






  
  public void setUsername(String paramString) throws SQLException {
    this.username = paramString;
  }
















  
  public void addRowSetListener(RowSetListener paramRowSetListener) {
    for (byte b = 0; b < this.listener.size(); b++) {
      if (this.listener.elementAt(b).equals(paramRowSetListener))
        return; 
    }  this.listener.add(paramRowSetListener);
  }





  
  public void removeRowSetListener(RowSetListener paramRowSetListener) {
    for (byte b = 0; b < this.listener.size(); b++) {
      if (this.listener.elementAt(b).equals(paramRowSetListener)) {
        this.listener.remove(b);
      }
    } 
  }








  
  protected synchronized void notifyCursorMoved() {
    int i = this.listener.size();
    if (i > 0) {
      for (byte b = 0; b < i; b++) {
        ((RowSetListener)this.listener.elementAt(b)).cursorMoved(this.rowsetEvent);
      }
    }
  }







  
  protected void notifyRowChanged() {
    int i = this.listener.size();
    if (i > 0) {
      for (byte b = 0; b < i; b++)
      {
        ((RowSetListener)this.listener.elementAt(b)).rowChanged(this.rowsetEvent);
      }
    }
  }








  
  protected void notifyRowSetChanged() {
    int i = this.listener.size();
    if (i > 0) {
      for (byte b = 0; b < i; b++)
      {
        ((RowSetListener)this.listener.elementAt(b)).rowSetChanged(this.rowsetEvent);
      }
    }
  }






















  
  public int[] getMatchColumnIndexes() throws SQLException {
    int[] arrayOfInt;
    if (this.matchColumnIndexes.size() == 0 && this.matchColumnNames.size() == 0) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 334);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.matchColumnNames.size() > 0) {
      
      String[] arrayOfString = getMatchColumnNames();
      int i = arrayOfString.length;
      arrayOfInt = new int[i];
      
      for (byte b = 0; b < i; b++)
      {
        arrayOfInt[b] = findColumn(arrayOfString[b]);
      }
    }
    else {
      
      int i = this.matchColumnIndexes.size();
      arrayOfInt = new int[i];
      int j = -1;
      
      for (byte b = 0; b < i; b++) {

        
        try {
          j = ((Integer)this.matchColumnIndexes.get(b)).intValue();
        
        }
        catch (Exception exception) {

          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 336);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 



        
        if (j <= 0) {

          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 336);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 



        
        arrayOfInt[b] = j;
      } 
    } 

    
    return arrayOfInt;
  }















  
  public String[] getMatchColumnNames() throws SQLException {
    checkIfMatchColumnNamesSet();
    
    int i = this.matchColumnNames.size();
    String[] arrayOfString = new String[i];
    String str = null;
    
    for (byte b = 0; b < i; b++) {

      
      try {
        str = this.matchColumnNames.get(b);
      
      }
      catch (Exception exception) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 337);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 



      
      if (str == null || str.equals("")) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 337);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 



      
      arrayOfString[b] = str;
    } 

    
    return arrayOfString;
  }















  
  public void setMatchColumn(int paramInt) throws SQLException {
    if (paramInt <= 0) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 336);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    try {
      this.matchColumnIndexes.clear();
      this.matchColumnNames.clear();
      
      this.matchColumnIndexes.add(0, Integer.valueOf(paramInt));
    
    }
    catch (Exception exception) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 338);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }


















  
  public void setMatchColumn(int[] paramArrayOfint) throws SQLException {
    this.matchColumnIndexes.clear();
    this.matchColumnNames.clear();
    
    if (paramArrayOfint == null) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    for (byte b = 0; b < paramArrayOfint.length; b++) {
      
      if (paramArrayOfint[b] <= 0) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 336);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 


      
      try {
        this.matchColumnIndexes.add(b, Integer.valueOf(paramArrayOfint[b]));
      
      }
      catch (Exception exception) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 338);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    } 
  }


















  
  public void setMatchColumn(String paramString) throws SQLException {
    if (paramString == null || paramString.equals("")) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    try {
      this.matchColumnIndexes.clear();
      this.matchColumnNames.clear();
      
      this.matchColumnNames.add(0, paramString.trim());
    
    }
    catch (Exception exception) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 339);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }



















  
  public void setMatchColumn(String[] paramArrayOfString) throws SQLException {
    this.matchColumnIndexes.clear();
    this.matchColumnNames.clear();
    
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      
      if (paramArrayOfString[b] == null || paramArrayOfString[b].equals("")) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 


      
      try {
        this.matchColumnNames.add(b, paramArrayOfString[b].trim());
      
      }
      catch (Exception exception) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 339);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    } 
  }


















  
  public void unsetMatchColumn(int paramInt) throws SQLException {
    checkIfMatchColumnIndexesSet();
    
    if (paramInt <= 0) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 336);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    int i = -1;

    
    try {
      i = ((Integer)this.matchColumnIndexes.get(0)).intValue();
    
    }
    catch (Exception exception) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 334);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (i != paramInt) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 340);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    this.matchColumnIndexes.clear();
    this.matchColumnNames.clear();
  }















  
  public void unsetMatchColumn(int[] paramArrayOfint) throws SQLException {
    checkIfMatchColumnIndexesSet();
    
    if (paramArrayOfint == null) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    int i = -1;
    
    for (byte b = 0; b < paramArrayOfint.length; b++) {
      
      if (paramArrayOfint[b] <= 0) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 336);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 


      
      try {
        i = ((Integer)this.matchColumnIndexes.get(b)).intValue();
      
      }
      catch (Exception exception) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 334);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 


      
      if (i != paramArrayOfint[b]) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 340);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    } 


    
    this.matchColumnIndexes.clear();
    this.matchColumnNames.clear();
  }
















  
  public void unsetMatchColumn(String paramString) throws SQLException {
    checkIfMatchColumnNamesSet();
    
    if (paramString == null || paramString.equals("")) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = null;

    
    try {
      str = this.matchColumnNames.get(0);
    
    }
    catch (Exception exception) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 335);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (!str.equals(paramString.trim())) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 341);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    this.matchColumnIndexes.clear();
    this.matchColumnNames.clear();
  }















  
  public void unsetMatchColumn(String[] paramArrayOfString) throws SQLException {
    checkIfMatchColumnNamesSet();
    
    if (paramArrayOfString == null) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = null;
    
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      
      if (paramArrayOfString[b] == null || paramArrayOfString[b].equals("")) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 


      
      try {
        str = this.matchColumnNames.get(b);
      
      }
      catch (Exception exception) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 335);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 



      
      if (!str.equals(paramArrayOfString[b])) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 341);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    } 


    
    this.matchColumnIndexes.clear();
    this.matchColumnNames.clear();
  }











  
  protected void checkIfMatchColumnIndexesSet() throws SQLException {
    if (this.matchColumnIndexes.size() == 0) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 334);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }







  
  protected void checkIfMatchColumnNamesSet() throws SQLException {
    if (this.matchColumnNames.size() == 0) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 335);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }




  
  public abstract int findColumn(String paramString) throws SQLException;




  
  public abstract ResultSetMetaData getMetaData() throws SQLException;



  
  abstract String getTableName() throws SQLException;



  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
