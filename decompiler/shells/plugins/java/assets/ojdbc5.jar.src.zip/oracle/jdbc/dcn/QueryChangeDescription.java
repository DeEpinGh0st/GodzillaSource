package oracle.jdbc.dcn;












































public interface QueryChangeDescription
{
  long getQueryId();
  
  QueryChangeEventType getQueryChangeEventType();
  
  TableChangeDescription[] getTableChangeDescription();
  
  public enum QueryChangeEventType
  {
    DEREG(DatabaseChangeEvent.EventType.DEREG.getCode()),



    
    QUERYCHANGE(DatabaseChangeEvent.EventType.QUERYCHANGE.getCode());
    private final int code;
    
    QueryChangeEventType(int param1Int1) {
      this.code = param1Int1;
    }




    
    public final int getCode() {
      return this.code;
    }



    
    public static final QueryChangeEventType getQueryChangeEventType(int param1Int) {
      if (param1Int == DEREG.getCode()) {
        return DEREG;
      }
      return QUERYCHANGE;
    }
  }
}
