package oracle.jdbc.rowset;

import javax.sql.rowset.spi.XmlWriter;

public interface OracleWebRowSetXmlWriter extends XmlWriter {}
