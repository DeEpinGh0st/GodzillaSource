package oracle.jdbc.pool;

import java.io.UnsupportedEncodingException;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.concurrent.atomic.AtomicInteger;
import javax.sql.ConnectionPoolDataSource;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.ons.ONS;
import oracle.ons.ONSException;





































public class OracleConnectionCacheManager
{
  private static OracleConnectionCacheManager cacheManagerInstance = null;
  
  protected Hashtable m_connCache = null;

  
  public static final int REFRESH_INVALID_CONNECTIONS = 4096;

  
  public static final int REFRESH_ALL_CONNECTIONS = 8192;

  
  public static final String PHYSICAL_CONNECTION_CREATED_COUNT = "PhysicalConnectionCreatedCount";

  
  public static final String PHYSICAL_CONNECTION_CLOSED_COUNT = "PhysicalConnectionClosedCount";

  
  protected static final int FAILOVER_EVENT_TYPE_SERVICE = 256;

  
  protected static final int FAILOVER_EVENT_TYPE_HOST = 512;
  
  protected static final String EVENT_DELIMITER = "{} =";
  
  protected OracleFailoverEventHandlerThread failoverEventHandlerThread = null;
  
  private static boolean isONSInitializedForRemoteSubscription = false;
  
  static final int ORAERROR_END_OF_FILE_ON_COM_CHANNEL = 3113;
  
  static final int ORAERROR_NOT_CONNECTED_TO_ORACLE = 3114;
  
  static final int ORAERROR_INIT_SHUTDOWN_IN_PROGRESS = 1033;
  
  static final int ORAERROR_ORACLE_NOT_AVAILABLE = 1034;
  
  static final int ORAERROR_IMMEDIATE_SHUTDOWN_IN_PROGRESS = 1089;
  
  static final int ORAERROR_SHUTDOWN_IN_PROGRESS_NO_CONN = 1090;
  
  static final int ORAERROR_NET_IO_EXCEPTION = 17002;
  
  protected int[] fatalErrorCodes = null;
  protected int failoverEnabledCacheCount = 0;



  
  protected static AtomicInteger UNNAMED_CACHE_COUNT;




  
  private OracleConnectionCacheManager() {
    this.m_connCache = new Hashtable<Object, Object>();

    
    UNNAMED_CACHE_COUNT = new AtomicInteger();
  }
















  
  public static synchronized OracleConnectionCacheManager getConnectionCacheManagerInstance() throws SQLException {
    try {
      if (cacheManagerInstance == null) {
        cacheManagerInstance = new OracleConnectionCacheManager();
      }
    } catch (RuntimeException runtimeException) {}


    
    return cacheManagerInstance;
  }

















  
  public String createCache(OracleDataSource paramOracleDataSource, Properties paramProperties) throws SQLException {
    String str = null;
    
    if (paramOracleDataSource == null || !paramOracleDataSource.getConnectionCachingEnabled()) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 137);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 





    
    if (paramOracleDataSource.connCacheName != null) {
      
      str = paramOracleDataSource.connCacheName;
    }
    else {
      
      str = paramOracleDataSource.dataSourceName + "#0x" + Integer.toHexString(UNNAMED_CACHE_COUNT.getAndIncrement());
    } 


    
    createCache(str, paramOracleDataSource, paramProperties);
    
    return str;
  }


















  
  public void createCache(String paramString, OracleDataSource paramOracleDataSource, Properties paramProperties) throws SQLException {
    if (paramOracleDataSource == null || !paramOracleDataSource.getConnectionCachingEnabled()) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 137);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    if (paramString == null) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 138);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.m_connCache.containsKey(paramString)) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 140);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    boolean bool = paramOracleDataSource.getFastConnectionFailoverEnabled();






    
    if (bool && this.failoverEventHandlerThread == null) {


      
      final String onsConfigStr = paramOracleDataSource.getONSConfiguration();


      
      if (str != null && !str.equals(""))
      {





        
        synchronized (this) {
          
          if (!isONSInitializedForRemoteSubscription) {

            
            try {
              
              AccessController.doPrivileged(new PrivilegedExceptionAction()
                  {



                    
                    public Object run() throws ONSException
                    {
                      ONS oNS = new ONS(onsConfigStr);
                      return null;
                    }
                  });
            }
            catch (PrivilegedActionException privilegedActionException) {

              
              SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 175, privilegedActionException);
              sQLException.fillInStackTrace();
              throw sQLException;
            } 

            
            isONSInitializedForRemoteSubscription = true;
          } 
        } 
      }
      
      this.failoverEventHandlerThread = new OracleFailoverEventHandlerThread();
    } 

    
    OracleImplicitConnectionCache oracleImplicitConnectionCache = new OracleImplicitConnectionCache(paramOracleDataSource, paramProperties);

    
    oracleImplicitConnectionCache.cacheName = paramString;
    paramOracleDataSource.odsCache = oracleImplicitConnectionCache;

    
    this.m_connCache.put(paramString, oracleImplicitConnectionCache);






    
    if (bool)
    {


      
      checkAndStartThread(this.failoverEventHandlerThread);
    }
  }


























  
  public void removeCache(String paramString, long paramLong) throws SQLException {
    OracleImplicitConnectionCache oracleImplicitConnectionCache = (paramString != null) ? (OracleImplicitConnectionCache)this.m_connCache.remove(paramString) : null;

    
    if (oracleImplicitConnectionCache != null) {
      
      oracleImplicitConnectionCache.disableConnectionCache();

      
      if (paramLong > 0L) {
        
        try {
          
          Thread.currentThread(); Thread.sleep(paramLong * 1000L);
        }
        catch (InterruptedException interruptedException) {}
      }




      
      if (oracleImplicitConnectionCache.cacheEnabledDS.getFastConnectionFailoverEnabled()) {
        cleanupFCFThreads(oracleImplicitConnectionCache);
      }
      
      oracleImplicitConnectionCache.closeConnectionCache((paramLong < 0L) ? 32 : 1);
      
      oracleImplicitConnectionCache = null;
    
    }
    else {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }
















  
  public void reinitializeCache(String paramString, Properties paramProperties) throws SQLException {
    OracleImplicitConnectionCache oracleImplicitConnectionCache = (paramString != null) ? (OracleImplicitConnectionCache)this.m_connCache.get(paramString) : null;

    
    if (oracleImplicitConnectionCache != null) {
      
      disableCache(paramString);
      oracleImplicitConnectionCache.reinitializeCacheConnections(paramProperties);
      enableCache(paramString);
    
    }
    else {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }













  
  public boolean existsCache(String paramString) throws SQLException {
    return this.m_connCache.containsKey(paramString);
  }













  
  public void enableCache(String paramString) throws SQLException {
    OracleImplicitConnectionCache oracleImplicitConnectionCache = (paramString != null) ? (OracleImplicitConnectionCache)this.m_connCache.get(paramString) : null;

    
    if (oracleImplicitConnectionCache != null) {
      
      oracleImplicitConnectionCache.enableConnectionCache();
    
    }
    else {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }














  
  public void disableCache(String paramString) throws SQLException {
    OracleImplicitConnectionCache oracleImplicitConnectionCache = (paramString != null) ? (OracleImplicitConnectionCache)this.m_connCache.get(paramString) : null;

    
    if (oracleImplicitConnectionCache != null) {
      
      oracleImplicitConnectionCache.disableConnectionCache();
    
    }
    else {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }



















  
  public void refreshCache(String paramString, int paramInt) throws SQLException {
    OracleImplicitConnectionCache oracleImplicitConnectionCache = (paramString != null) ? (OracleImplicitConnectionCache)this.m_connCache.get(paramString) : null;

    
    if (oracleImplicitConnectionCache != null) {
      
      switch (paramInt) {
        
        case 4096:
        case 8192:
          oracleImplicitConnectionCache.refreshCacheConnections(paramInt);
          return;
      } 

      
      SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException1.fillInStackTrace();
      throw sQLException1;
    } 




    
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
    sQLException.fillInStackTrace();
    throw sQLException;
  }


















  
  public void purgeCache(String paramString, boolean paramBoolean) throws SQLException {
    OracleImplicitConnectionCache oracleImplicitConnectionCache = (paramString != null) ? (OracleImplicitConnectionCache)this.m_connCache.get(paramString) : null;

    
    if (oracleImplicitConnectionCache != null) {
      
      oracleImplicitConnectionCache.purgeCacheConnections(paramBoolean, 1);
    
    }
    else {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }















  
  public Properties getCacheProperties(String paramString) throws SQLException {
    OracleImplicitConnectionCache oracleImplicitConnectionCache = (paramString != null) ? (OracleImplicitConnectionCache)this.m_connCache.get(paramString) : null;

    
    if (oracleImplicitConnectionCache != null)
    {
      return oracleImplicitConnectionCache.getConnectionCacheProperties();
    }


    
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
    sQLException.fillInStackTrace();
    throw sQLException;
  }














  
  public String[] getCacheNameList() throws SQLException {
    return (String[])this.m_connCache.keySet().toArray((Object[])new String[this.m_connCache.size()]);
  }
















  
  public int getNumberOfAvailableConnections(String paramString) throws SQLException {
    OracleImplicitConnectionCache oracleImplicitConnectionCache = (paramString != null) ? (OracleImplicitConnectionCache)this.m_connCache.get(paramString) : null;

    
    if (oracleImplicitConnectionCache != null)
    {
      return oracleImplicitConnectionCache.cacheSize;
    }


    
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
    sQLException.fillInStackTrace();
    throw sQLException;
  }















  
  public int getNumberOfActiveConnections(String paramString) throws SQLException {
    OracleImplicitConnectionCache oracleImplicitConnectionCache = (paramString != null) ? (OracleImplicitConnectionCache)this.m_connCache.get(paramString) : null;

    
    if (oracleImplicitConnectionCache != null)
    {
      return oracleImplicitConnectionCache.getNumberOfCheckedOutConnections();
    }


    
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
    sQLException.fillInStackTrace();
    throw sQLException;
  }
























  
  public synchronized void setConnectionPoolDataSource(String paramString, ConnectionPoolDataSource paramConnectionPoolDataSource) throws SQLException {
    OracleImplicitConnectionCache oracleImplicitConnectionCache = (paramString != null) ? (OracleImplicitConnectionCache)this.m_connCache.get(paramString) : null;

    
    if (oracleImplicitConnectionCache != null) {
      
      if (oracleImplicitConnectionCache.cacheSize > 0) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 78);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 


      
      ((OracleConnectionPoolDataSource)paramConnectionPoolDataSource).makeURL();
      ((OracleConnectionPoolDataSource)paramConnectionPoolDataSource).setURL(((OracleConnectionPoolDataSource)paramConnectionPoolDataSource).url);
      
      oracleImplicitConnectionCache.connectionPoolDS = (OracleConnectionPoolDataSource)paramConnectionPoolDataSource;
    
    }
    else {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }

















  
  protected void verifyAndHandleEvent(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
    String str1 = null;
    String str2 = null;
    String str3 = null;
    String str4 = null;
    String str5 = null;
    
    int i = 0;
    StringTokenizer stringTokenizer = null;

    
    try {
      stringTokenizer = new StringTokenizer(new String(paramArrayOfbyte, "UTF-8"), "{} =", true);
    }
    catch (UnsupportedEncodingException unsupportedEncodingException) {}



    
    String str6 = null;
    String str7 = null;
    String str8 = null;


    
    while (stringTokenizer.hasMoreTokens()) {
      
      str7 = null;
      str6 = stringTokenizer.nextToken();
      if (str6.equals("=") && stringTokenizer.hasMoreTokens()) {
        
        str7 = stringTokenizer.nextToken();
      }
      else {
        
        str8 = str6;
      } 
      
      if (str8.equalsIgnoreCase("version") && str7 != null && !str7.equals("1.0")) {


        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 146);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      if (str8.equalsIgnoreCase("service") && str7 != null) {
        str1 = str7;
      }
      if (str8.equalsIgnoreCase("instance") && str7 != null && !str7.equals(" "))
      {
        
        str2 = str7.toLowerCase().intern();
      }
      
      if (str8.equalsIgnoreCase("database") && str7 != null) {
        str3 = str7.toLowerCase().intern();
      }
      if (str8.equalsIgnoreCase("host") && str7 != null) {
        str4 = str7.toLowerCase().intern();
      }
      if (str8.equalsIgnoreCase("status") && str7 != null) {
        str5 = str7;
      }
      if (str8.equalsIgnoreCase("card") && str7 != null) {
        
        try {
          
          i = Integer.parseInt(str7);
        }
        catch (NumberFormatException numberFormatException) {}
      }
    } 



    
    invokeFailoverProcessingThreads(paramInt, str1, str2, str3, str4, str5, i);

    
    stringTokenizer = null;
  }













  
  private void invokeFailoverProcessingThreads(int paramInt1, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, int paramInt2) throws SQLException {
    OracleImplicitConnectionCache oracleImplicitConnectionCache = null;
    boolean bool1 = false;
    boolean bool2 = false;
    
    if (paramInt1 == 256) {
      bool1 = true;
    }
    if (paramInt1 == 512) {
      bool2 = true;
    }
    Iterator<OracleImplicitConnectionCache> iterator = this.m_connCache.values().iterator();
    
    while (iterator.hasNext()) {
      
      oracleImplicitConnectionCache = iterator.next();








      
      if ((bool1 && paramString1.equalsIgnoreCase(oracleImplicitConnectionCache.dataSourceServiceName)) || bool2) {


        
        OracleFailoverWorkerThread oracleFailoverWorkerThread = new OracleFailoverWorkerThread(oracleImplicitConnectionCache, paramInt1, paramString2, paramString3, paramString4, paramString5, paramInt2);


        
        checkAndStartThread(oracleFailoverWorkerThread);
        
        oracleImplicitConnectionCache.failoverWorkerThread = oracleFailoverWorkerThread;
      } 
    } 
  }











  
  protected void checkAndStartThread(Thread paramThread) throws SQLException {
    try {
      if (!paramThread.isAlive())
      {
        paramThread.setDaemon(true);
        paramThread.start();
      }
    
    } catch (IllegalThreadStateException illegalThreadStateException) {}
  }











  
  protected boolean failoverEnabledCacheExists() {
    if (this.failoverEnabledCacheCount > 0) {
      return true;
    }
    return false;
  }









  
  protected void parseRuntimeLoadBalancingEvent(String paramString, byte[] paramArrayOfbyte) throws SQLException {
    OracleImplicitConnectionCache oracleImplicitConnectionCache = null;
    Enumeration<OracleImplicitConnectionCache> enumeration = this.m_connCache.elements();
    
    while (enumeration.hasMoreElements()) {

      
      try {
        oracleImplicitConnectionCache = enumeration.nextElement();
        if (paramString.equalsIgnoreCase(oracleImplicitConnectionCache.dataSourceServiceName))
        {
          if (paramArrayOfbyte == null) {
            oracleImplicitConnectionCache.zapRLBInfo(); continue;
          } 
          retrieveServiceMetrics(oracleImplicitConnectionCache, paramArrayOfbyte);
        }
      
      } catch (Exception exception) {}
    } 
  }















  
  private void retrieveServiceMetrics(OracleImplicitConnectionCache paramOracleImplicitConnectionCache, byte[] paramArrayOfbyte) throws SQLException {
    StringTokenizer stringTokenizer = null;
    String str1 = null;
    String str2 = null;
    int i = 0;
    byte b = 0;
    boolean bool = false;

    
    try {
      stringTokenizer = new StringTokenizer(new String(paramArrayOfbyte, "UTF-8"), "{} =", true);
    
    }
    catch (UnsupportedEncodingException unsupportedEncodingException) {}



    
    String str3 = null;
    String str4 = null;
    String str5 = null;
    
    while (stringTokenizer.hasMoreTokens()) {
      
      str4 = null;
      str3 = stringTokenizer.nextToken();
      
      if (str3.equals("=") && stringTokenizer.hasMoreTokens()) {
        
        str4 = stringTokenizer.nextToken();
      } else {
        if (str3.equals("}")) {

          
          if (bool) {
            
            paramOracleImplicitConnectionCache.updateDatabaseInstance(str2, str1, i, b);
            bool = false;
          } 
          continue;
        } 
        if (str3.equals("{") || str3.equals(" ")) {
          continue;
        }


        
        str5 = str3;
        bool = true;
      } 
      
      if (str5.equalsIgnoreCase("version") && str4 != null)
      {
        if (!str4.equals("1.0")) {

          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 146);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 
      }

      
      if (str5.equalsIgnoreCase("database") && str4 != null) {
        str2 = str4.toLowerCase().intern();
      }
      if (str5.equalsIgnoreCase("instance") && str4 != null) {
        str1 = str4.toLowerCase().intern();
      }
      if (str5.equalsIgnoreCase("percent") && str4 != null) {
        
        try {
          
          i = Integer.parseInt(str4);
          if (i == 0) i = 1;
        
        } catch (NumberFormatException numberFormatException) {}
      }



      
      if (str5.equalsIgnoreCase("flag") && str4 != null) {
        
        if (str4.equalsIgnoreCase("good")) {
          b = 1; continue;
        }  if (str4.equalsIgnoreCase("violating")) {
          b = 3; continue;
        }  if (str4.equalsIgnoreCase("NO_DATA")) {
          b = 4; continue;
        }  if (str4.equalsIgnoreCase("UNKNOWN")) {
          b = 2; continue;
        }  if (str4.equalsIgnoreCase("BLOCKED")) {
          b = 5;
        }
      } 
    } 
    
    paramOracleImplicitConnectionCache.processDatabaseInstances();
  }









  
  protected void cleanupFCFThreads(OracleImplicitConnectionCache paramOracleImplicitConnectionCache) throws SQLException {
    cleanupFCFWorkerThread(paramOracleImplicitConnectionCache);
    paramOracleImplicitConnectionCache.cleanupRLBThreads();

    
    if (this.failoverEnabledCacheCount <= 0) {
      cleanupFCFEventHandlerThread();
    }
    
    this.failoverEnabledCacheCount--;
  }











  
  protected void cleanupFCFWorkerThread(OracleImplicitConnectionCache paramOracleImplicitConnectionCache) throws SQLException {
    if (paramOracleImplicitConnectionCache.failoverWorkerThread != null) {

      
      try {
        if (paramOracleImplicitConnectionCache.failoverWorkerThread.isAlive()) {
          paramOracleImplicitConnectionCache.failoverWorkerThread.join();
        }
      } catch (InterruptedException interruptedException) {}



      
      paramOracleImplicitConnectionCache.failoverWorkerThread = null;
    } 
  }













  
  protected void cleanupFCFEventHandlerThread() throws SQLException {
    if (this.failoverEventHandlerThread != null) {

      
      try {
        this.failoverEventHandlerThread.interrupt();
      }
      catch (Exception exception) {}



      
      this.failoverEventHandlerThread = null;
    } 
  }













  
  public boolean isFatalConnectionError(SQLException paramSQLException) {
    boolean bool = false;
    int i = paramSQLException.getErrorCode();

    
    if (i == 3113 || i == 3114 || i == 1033 || i == 1034 || i == 1089 || i == 1090 || i == 17002)
    {





      
      bool = true;
    }

    
    if (!bool && this.fatalErrorCodes != null)
    {
      for (byte b = 0; b < this.fatalErrorCodes.length; b++) {
        if (i == this.fatalErrorCodes[b]) {
          
          bool = true;
          break;
        } 
      }  } 
    return bool;
  }











  
  public synchronized void setConnectionErrorCodes(int[] paramArrayOfint) throws SQLException {
    if (paramArrayOfint != null) {
      this.fatalErrorCodes = paramArrayOfint;
    }
  }










  
  public int[] getConnectionErrorCodes() throws SQLException {
    return this.fatalErrorCodes;
  }

















  
  public Map getStatistics(String paramString) throws SQLException {
    Map map = null;
    OracleImplicitConnectionCache oracleImplicitConnectionCache = null;
    
    if (this.m_connCache != null && (oracleImplicitConnectionCache = (OracleImplicitConnectionCache)this.m_connCache.get(paramString)) != null)
    {
      map = oracleImplicitConnectionCache.getStatistics();
    }
    return map;
  }











  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
