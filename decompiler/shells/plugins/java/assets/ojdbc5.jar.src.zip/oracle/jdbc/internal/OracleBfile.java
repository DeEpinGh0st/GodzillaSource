package oracle.jdbc.internal;

import java.io.InputStream;
import java.io.Reader;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.OracleBfile;
import oracle.sql.BFILE;
import oracle.sql.BfileDBAccess;

public interface OracleBfile extends OracleDatumWithConnection, OracleBfile {
  long position(BFILE paramBFILE, long paramLong) throws SQLException;
  
  byte[] getLocator();
  
  void setLocator(byte[] paramArrayOfbyte);
  
  Object toJdbc() throws SQLException;
  
  boolean isConvertibleTo(Class paramClass);
  
  Reader characterStreamValue() throws SQLException;
  
  InputStream asciiStreamValue() throws SQLException;
  
  InputStream binaryStreamValue() throws SQLException;
  
  Object makeJdbcArray(int paramInt);
  
  BfileDBAccess getDBAccess() throws SQLException;
  
  void setLength(long paramLong);
  
  Connection getJavaSqlConnection() throws SQLException;
}
