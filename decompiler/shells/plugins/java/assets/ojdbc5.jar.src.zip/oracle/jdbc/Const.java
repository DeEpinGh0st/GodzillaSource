package oracle.jdbc;













































public class Const
{
  public static final short NCHAR = 2;
  public static final short CHAR = 1;
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
