package oracle.jdbc.driver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


















class SQLStateMapping
{
  public static final int SQLEXCEPTION = 0;
  public static final int SQLNONTRANSIENTEXCEPTION = 1;
  public static final int SQLTRANSIENTEXCEPTION = 2;
  public static final int SQLDATAEXCEPTION = 3;
  public static final int SQLFEATURENOTSUPPORTEDEXCEPTION = 4;
  public static final int SQLINTEGRITYCONSTRAINTVIOLATIONEXCEPTION = 5;
  public static final int SQLINVALIDAUTHORIZATIONSPECEXCEPTION = 6;
  public static final int SQLNONTRANSIENTCONNECTIONEXCEPTION = 7;
  public static final int SQLSYNTAXERROREXCEPTION = 8;
  public static final int SQLTIMEOUTEXCEPTION = 9;
  public static final int SQLTRANSACTIONROLLBACKEXCEPTION = 10;
  public static final int SQLTRANSIENTCONNECTIONEXCEPTION = 11;
  public static final int SQLCLIENTINFOEXCEPTION = 12;
  public static final int SQLRECOVERABLEEXCEPTION = 13;
  int low;
  int high;
  public String sqlState;
  public int exception;
  static final String mappingResource = "errorMap.xml";
  static SQLStateMapping[] all;
  private static final int NUMEBER_OF_MAPPINGS_IN_ERRORMAP_XML = 128;
  
  public SQLStateMapping(int paramInt1, int paramInt2, String paramString, int paramInt3) {
    this.low = paramInt1;
    this.sqlState = paramString;
    this.exception = paramInt3;
    this.high = paramInt2;
  }


  
  public boolean isIncluded(int paramInt) {
    return (this.low <= paramInt && paramInt <= this.high);
  }


  
  public SQLException newSQLException(String paramString, int paramInt) {
    switch (this.exception) {
      case 0:
        return new SQLException(paramString, this.sqlState, paramInt);
    } 

    
    return new SQLException(paramString, this.sqlState, paramInt);
  }


  
  boolean lessThan(SQLStateMapping paramSQLStateMapping) {
    if (this.low < paramSQLStateMapping.low) {
      return (this.high < paramSQLStateMapping.high);
    }
    
    return (this.high <= paramSQLStateMapping.high);
  }

  
  public String toString() {
    return super.toString() + "(" + this.low + ", " + this.high + ", " + this.sqlState + ", " + this.exception + ")";
  }



  
  public static void main(String[] paramArrayOfString) throws IOException {
    SQLStateMapping[] arrayOfSQLStateMapping = doGetMappings();
    System.out.println("a\t" + arrayOfSQLStateMapping);
    for (byte b = 0; b < arrayOfSQLStateMapping.length; b++) {
      System.out.println("low:\t" + (arrayOfSQLStateMapping[b]).low + "\thigh:\t" + (arrayOfSQLStateMapping[b]).high + "\tsqlState:\t" + (arrayOfSQLStateMapping[b]).sqlState + "\tsqlException:\t" + (arrayOfSQLStateMapping[b]).exception);
    }
  }





  
  static SQLStateMapping[] getMappings() {
    if (all == null) {
      try {
        all = doGetMappings();
      }
      catch (Throwable throwable) {
        
        all = new SQLStateMapping[0];
      } 
    }
    return all;
  }




  
  static SQLStateMapping[] doGetMappings() throws IOException {
    InputStream inputStream = SQLStateMapping.class.getResourceAsStream("errorMap.xml");
    ArrayList arrayList = new ArrayList(128);
    load(inputStream, arrayList);
    return (SQLStateMapping[])arrayList.toArray((Object[])new SQLStateMapping[0]);
  }


















  
  static void load(InputStream paramInputStream, List paramList) throws IOException {
    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(paramInputStream));
    Tokenizer tokenizer = new Tokenizer(bufferedReader);
    int i = -1;
    int j = -1;
    String str1 = null;
    int k = -1;
    String str2 = null;
    byte b = 0;
    String str3;
    while ((str3 = tokenizer.next()) != null) {
      switch (b) {
        case false:
          if (str3.equals("<")) b = 1; 
          continue;
        case true:
          if (str3.equals("!")) { b = 2; continue; }
           if (str3.equals("oraErrorSqlStateSqlExceptionMapping")) { b = 6; continue; }
           throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"oraErrorSqlStateSqlExceptionMapping\".");

        
        case true:
          if (str3.equals("-")) { b = 3; continue; }
           throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"-\".");

        
        case true:
          if (str3.equals("-")) b = 4; 
          continue;
        case true:
          if (str3.equals("-")) { b = 5; continue; }
           b = 3;
          continue;
        case true:
          if (str3.equals(">")) { b = 1; continue; }
           throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \">\".");

        
        case true:
          if (str3.equals(">")) { b = 7; continue; }
           throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \">\".");

        
        case true:
          if (str3.equals("<")) { b = 8; continue; }
           throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"<\".");

        
        case true:
          if (str3.equals("!")) { b = 9; continue; }
           if (str3.equals("error")) { b = 14; continue; }
           if (str3.equals("/")) { b = 16; continue; }
           throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected one of \"!--\", \"error\", \"/\".");

        
        case true:
          if (str3.equals("-")) { b = 10; continue; }
           throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"-\".");

        
        case true:
          if (str3.equals("-")) { b = 11; continue; }
           throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"-\".");

        
        case true:
          if (str3.equals("-")) b = 12; 
          continue;
        case true:
          if (str3.equals("-")) { b = 13; continue; }
           b = 11;
          continue;
        case true:
          if (str3.equals(">")) { b = 7; continue; }
           throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \">\".");

        
        case true:
          if (str3.equals("/")) { b = 15; continue; }
           if (str3.equals("oraErrorFrom")) { b = 19; continue; }
           if (str3.equals("oraErrorTo")) { b = 21; continue; }
           if (str3.equals("sqlState")) { b = 23; continue; }
           if (str3.equals("sqlException")) { b = 25; continue; }
           if (str3.equals("comment")) { b = 27; continue; }
           throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected one of " + "\"oraErrorFrom\", \"oraErrorTo\", \"sqlState\", " + "\"sqlException\", \"comment\", \"/\".");



        
        case true:
          if (str3.equals(">")) {
            try {
              createOne(paramList, i, j, str1, k, str2);
            }
            catch (IOException iOException) {
              throw new IOException("Invalid error element at line " + tokenizer.lineno + " of errorMap.xml. " + iOException.getMessage());
            } 
            
            i = -1;
            j = -1;
            str1 = null;
            k = -1;
            str2 = null;
            b = 7; continue;
          } 
          throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \">\".");

        
        case true:
          if (str3.equals("oraErrorSqlStateSqlExceptionMapping")) { b = 17; continue; }
           throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"oraErrorSqlStateSqlExceptionMapping\".");

        
        case true:
          if (str3.equals(">")) { b = 18; continue; }
           throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \">\".");
        
        case true:
          continue;
        
        case true:
          if (str3.equals("=")) { b = 20; continue; }
           throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"=\".");

        
        case true:
          try {
            i = Integer.parseInt(str3);
          }
          catch (NumberFormatException numberFormatException) {
            throw new IOException("Unexpected value \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected an integer.");
          } 
          
          b = 14;
          continue;
        case true:
          if (str3.equals("=")) { b = 22; continue; }
           throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"=\".");

        
        case true:
          try {
            j = Integer.parseInt(str3);
          }
          catch (NumberFormatException numberFormatException) {
            throw new IOException("Unexpected value \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected an integer.");
          } 
          
          b = 14;
          continue;
        case true:
          if (str3.equals("=")) { b = 24; continue; }
           throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"=\".");

        
        case true:
          str1 = str3;
          b = 14;
          continue;
        case true:
          if (str3.equals("=")) { b = 26; continue; }
           throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"=\".");

        
        case true:
          try {
            k = valueOf(str3);
          }
          catch (Exception exception) {
            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected SQLException" + " subclass name.");
          } 

          
          b = 14;
          continue;
        case true:
          if (str3.equals("=")) { b = 28; continue; }
           throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"=\".");

        
        case true:
          str2 = str3;
          b = 14;
          continue;
      } 
      throw new IOException("Unknown parser state " + b + " at line " + tokenizer.lineno + " of errorMap.xml.");
    } 
  }












  
  private static final class Tokenizer
  {
    int lineno = 1;
    Reader r;
    int c;
    
    Tokenizer(Reader param1Reader) throws IOException {
      this.r = param1Reader;
      this.c = param1Reader.read();
    }
    
    String next() throws IOException {
      StringBuffer stringBuffer = new StringBuffer(16);
      boolean bool = true;
      
      while (this.c != -1) {
        if (this.c == 10) this.lineno++; 
        if (this.c <= 32 && bool) {
          this.c = this.r.read();
          continue;
        } 
        if (this.c <= 32 && !bool) {
          this.c = this.r.read();
          break;
        } 
        if (this.c == 34) {
          for (; (this.c = this.r.read()) != 34; stringBuffer.append((char)this.c));
          this.c = this.r.read();
          break;
        } 
        if ((48 <= this.c && this.c <= 57) || (65 <= this.c && this.c <= 90) || (97 <= this.c && this.c <= 122) || this.c == 95) {
          
          do
          {
            
            stringBuffer.append((char)this.c);

          
          }
          while ((48 <= (this.c = this.r.read()) && this.c <= 57) || (65 <= this.c && this.c <= 90) || (97 <= this.c && this.c <= 122) || this.c == 95);
          break;
        } 
        stringBuffer.append((char)this.c);
        this.c = this.r.read();
        break;
      } 
      if (stringBuffer.length() > 0) return stringBuffer.toString(); 
      return null;
    }
  }

  
  private static void createOne(List paramList, int paramInt1, int paramInt2, String paramString1, int paramInt3, String paramString2) throws IOException {
    if (paramInt1 == -1) throw new IOException("oraErrorFrom is a required attribute"); 
    if (paramInt2 == -1) paramInt2 = paramInt1; 
    if (paramString1 == null || paramString1.length() == 0) throw new IOException("sqlState is a required attribute"); 
    if (paramInt3 == -1) throw new IOException("sqlException is a required attribute"); 
    if (paramString2 == null || paramString2.length() < 8) throw new IOException("a lengthy comment in required"); 
    SQLStateMapping sQLStateMapping = new SQLStateMapping(paramInt1, paramInt2, paramString1, paramInt3);
    add(paramList, sQLStateMapping);
  }
  
  static void add(List<SQLStateMapping> paramList, SQLStateMapping paramSQLStateMapping) {
    int i = paramList.size();
    for (; i > 0 && 
      !((SQLStateMapping)paramList.get(i - 1)).lessThan(paramSQLStateMapping); i--);


    
    paramList.add(i, paramSQLStateMapping);
  }

  
  static int valueOf(String paramString) throws Exception {
    if (paramString.equalsIgnoreCase("SQLEXCEPTION")) return 0; 
    if (paramString.equalsIgnoreCase("SQLNONTRANSIENTEXCEPTION")) return 1; 
    if (paramString.equalsIgnoreCase("SQLTRANSIENTEXCEPTION")) return 2; 
    if (paramString.equalsIgnoreCase("SQLDATAEXCEPTION")) return 3; 
    if (paramString.equalsIgnoreCase("SQLFEATURENOTSUPPORTEDEXCEPTION")) return 4; 
    if (paramString.equalsIgnoreCase("SQLINTEGRITYCONSTRAINTVIOLATIONEXCEPTION")) return 5; 
    if (paramString.equalsIgnoreCase("SQLINVALIDAUTHORIZATIONSPECEXCEPTION")) return 6; 
    if (paramString.equalsIgnoreCase("SQLNONTRANSIENTCONNECTIONEXCEPTION")) return 7; 
    if (paramString.equalsIgnoreCase("SQLSYNTAXERROREXCEPTION")) return 8; 
    if (paramString.equalsIgnoreCase("SQLTIMEOUTEXCEPTION")) return 9; 
    if (paramString.equalsIgnoreCase("SQLTRANSACTIONROLLBACKEXCEPTION")) return 10; 
    if (paramString.equalsIgnoreCase("SQLTRANSIENTCONNECTIONEXCEPTION")) return 11; 
    if (paramString.equalsIgnoreCase("SQLCLIENTINFOEXCEPTION")) return 12; 
    if (paramString.equalsIgnoreCase("SQLRECOVERABLEEXCEPTION")) return 13; 
    throw new Exception("unexpected exception name: " + paramString);
  }

  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
