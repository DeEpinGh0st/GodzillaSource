package oracle.jdbc.rowset;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.sql.Blob;
import java.sql.SQLException;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;




















public class OracleSerialBlob
  implements Blob, Serializable, Cloneable
{
  private byte[] buffer;
  private long length;
  private boolean isFreed = false;
  
  public OracleSerialBlob(byte[] paramArrayOfbyte) throws SQLException {
    this.length = paramArrayOfbyte.length;
    this.buffer = new byte[(int)this.length];
    for (byte b = 0; b < this.length; b++) {
      this.buffer[b] = paramArrayOfbyte[b];
    }
  }





  
  public OracleSerialBlob(Blob paramBlob) throws SQLException {
    this.length = paramBlob.length();
    this.buffer = new byte[(int)this.length];
    BufferedInputStream bufferedInputStream = new BufferedInputStream(paramBlob.getBinaryStream());

    
    try {
      int i = 0;
      int j = 0;


      
      while (true)
      { i = bufferedInputStream.read(this.buffer, j, (int)(this.length - j));
        
        j += i;
        if (i <= 0)
          return;  } 
    } catch (IOException iOException) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 346, iOException.getMessage());
      sQLException.fillInStackTrace();
      throw sQLException;
    } finally {

      
      try {
        if (bufferedInputStream != null)
          bufferedInputStream.close(); 
      } catch (IOException iOException) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 346, iOException.getMessage());
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    } 
  }







  
  public InputStream getBinaryStream() throws SQLException {
    if (this.isFreed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    return new ByteArrayInputStream(this.buffer);
  }







  
  public byte[] getBytes(long paramLong, int paramInt) throws SQLException {
    if (this.isFreed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    byte[] arrayOfByte = null;
    
    paramLong--;
    if (paramLong < 0L || paramInt > this.length || paramLong + paramInt > this.length) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    arrayOfByte = new byte[paramInt];
    System.arraycopy(this.buffer, (int)paramLong, arrayOfByte, 0, paramInt);

    
    return arrayOfByte;
  }





  
  public long length() throws SQLException {
    if (this.isFreed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    return this.length;
  }







  
  public long position(byte[] paramArrayOfbyte, long paramLong) throws SQLException {
    if (this.isFreed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (paramLong < 1L) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (paramLong > this.length || paramLong + paramArrayOfbyte.length - 1L > this.length) {
      return -1L;
    }
    int i = (int)(paramLong - 1L);
    boolean bool = false;
    long l = paramArrayOfbyte.length;
    
    while (i < this.length) {
      
      byte b = 0;
      long l1 = (i + 1);
      int j = i;
      while (b < l && j < this.length && paramArrayOfbyte[b] == this.buffer[j]) {
        
        b++;
        j++;
        if (b == l) {
          return l1;
        }
      } 
      i++;
    } 
    
    return -1L;
  }





  
  public long position(Blob paramBlob, long paramLong) throws SQLException {
    if (this.isFreed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    return position(paramBlob.getBytes(1L, (int)paramBlob.length()), paramLong);
  }

























  
  public int setBytes(long paramLong, byte[] paramArrayOfbyte) throws SQLException {
    if (this.isFreed) {
      
      SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
      sQLException1.fillInStackTrace();
      throw sQLException1;
    } 

    
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }





























  
  public int setBytes(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
    if (this.isFreed) {
      
      SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
      sQLException1.fillInStackTrace();
      throw sQLException1;
    } 

    
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }






















  
  public OutputStream setBinaryStream(long paramLong) throws SQLException {
    if (this.isFreed) {
      
      SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
      sQLException1.fillInStackTrace();
      throw sQLException1;
    } 

    
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }


















  
  public void truncate(long paramLong) throws SQLException {
    if (this.isFreed) {
      
      SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
      sQLException1.fillInStackTrace();
      throw sQLException1;
    } 

    
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }
















  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
