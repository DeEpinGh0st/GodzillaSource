package oracle.jdbc.driver;

import java.sql.SQLException;
import java.util.EventListener;
import java.util.Properties;
import java.util.concurrent.Executor;
import oracle.jdbc.NotificationRegistration;
import oracle.jdbc.aq.AQNotificationEvent;
import oracle.jdbc.aq.AQNotificationListener;
import oracle.jdbc.dcn.DatabaseChangeListener;
import oracle.jdbc.internal.OracleConnection;
















































abstract class NTFRegistration
{
  private final boolean jdbcGetsNotification;
  private final String clientHost;
  private final int clientTCPPort;
  private final Properties options;
  private final boolean isPurgeOnNTF;
  private final String username;
  private final int namespace;
  private final int jdbcRegId;
  private final String dbName;
  private final short databaseVersion;
  private NotificationRegistration.RegistrationState state;
  private NTFEventListener[] listeners = new NTFEventListener[0];












  
  NTFRegistration(int paramInt1, int paramInt2, boolean paramBoolean, String paramString1, String paramString2, int paramInt3, Properties paramProperties, String paramString3, short paramShort) {
    this.namespace = paramInt2;
    this.clientHost = paramString2;
    this.clientTCPPort = paramInt3;
    this.options = paramProperties;
    this.jdbcRegId = paramInt1;
    this.username = paramString3;
    this.jdbcGetsNotification = paramBoolean;
    this.dbName = paramString1;
    this.state = NotificationRegistration.RegistrationState.ACTIVE;
    if (this.options.getProperty("NTF_QOS_PURGE_ON_NTFN", "false").compareToIgnoreCase("true") == 0) {
      
      this.isPurgeOnNTF = true;
    } else {
      this.isPurgeOnNTF = false;
    }  this.databaseVersion = paramShort;
  }

  
  short getDatabaseVersion() {
    return this.databaseVersion;
  }


  
  synchronized void addListener(NTFEventListener paramNTFEventListener) throws SQLException {
    if (this.state == NotificationRegistration.RegistrationState.CLOSED) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 251);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    if (!this.jdbcGetsNotification) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 247);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    int i = this.listeners.length;
    for (byte b = 0; b < i; b++) {
      if (this.listeners[b].getListener() == paramNTFEventListener.getListener()) {


        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 248);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    } 
    
    NTFEventListener[] arrayOfNTFEventListener = new NTFEventListener[i + 1];
    System.arraycopy(this.listeners, 0, arrayOfNTFEventListener, 0, i);
    arrayOfNTFEventListener[i] = paramNTFEventListener;
    
    this.listeners = arrayOfNTFEventListener;
  }






  
  synchronized void removeListener(EventListener paramEventListener) throws SQLException {
    byte b1 = 0;
    int i = this.listeners.length;
    
    for (b1 = 0; b1 < i && 
      this.listeners[b1].getListener() != paramEventListener; b1++);
    
    if (b1 == i) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 249);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    NTFEventListener[] arrayOfNTFEventListener = new NTFEventListener[i - 1];
    byte b2 = 0;
    for (b1 = 0; b1 < i; b1++) {
      if (this.listeners[b1].getListener() != paramEventListener) {
        arrayOfNTFEventListener[b2++] = this.listeners[b1];
      }
    } 
    this.listeners = arrayOfNTFEventListener;
  }





  
  void notify(final NTFDCNEvent event) {
    long l = 0L;
    
    NTFEventListener[] arrayOfNTFEventListener = this.listeners;


    
    int i = arrayOfNTFEventListener.length;
    for (byte b = 0; b < i; b++) {
      
      Executor executor = arrayOfNTFEventListener[b].getExecutor();


      
      if (executor != null) {
        
        final DatabaseChangeListener l = arrayOfNTFEventListener[b].getDCNListener();
        
        executor.execute(new Runnable() {
              public void run() {
                l.onDatabaseChangeNotification(event);
              }
            });
      }
      else {
        
        arrayOfNTFEventListener[b].getDCNListener().onDatabaseChangeNotification(event);
      } 
    } 




    
    if (event.isDeregistrationEvent() || this.isPurgeOnNTF) {
      
      PhysicalConnection.ntfManager.removeRegistration(this);
      PhysicalConnection.ntfManager.freeJdbcRegId(getJdbcRegId());
      PhysicalConnection.ntfManager.cleanListenersT4C(getClientTCPPort());
      this.state = NotificationRegistration.RegistrationState.CLOSED;
    } 
  }







  
  void notify(final NTFAQEvent event) {
    long l = 0L;
    
    NTFEventListener[] arrayOfNTFEventListener = this.listeners;


    
    int i = arrayOfNTFEventListener.length;
    for (byte b = 0; b < i; b++) {
      
      Executor executor = arrayOfNTFEventListener[b].getExecutor();



      
      if (executor != null) {
        
        final AQNotificationListener l = arrayOfNTFEventListener[b].getAQListener();
        
        executor.execute(new Runnable() {
              public void run() {
                l.onAQNotification(event);
              }
            });
      }
      else {
        
        arrayOfNTFEventListener[b].getAQListener().onAQNotification(event);
      } 
    } 





    
    if (event.getEventType() == AQNotificationEvent.EventType.DEREG || this.isPurgeOnNTF) {
      
      PhysicalConnection.ntfManager.removeRegistration(this);
      PhysicalConnection.ntfManager.freeJdbcRegId(getJdbcRegId());
      PhysicalConnection.ntfManager.cleanListenersT4C(getClientTCPPort());
      this.state = NotificationRegistration.RegistrationState.CLOSED;
    } 
  }



  
  public Properties getRegistrationOptions() {
    return this.options;
  }



  
  int getJdbcRegId() {
    return this.jdbcRegId;
  }

  
  public String getUserName() {
    return this.username;
  }
  
  String getClientHost() {
    return this.clientHost;
  }

  
  int getClientTCPPort() {
    return this.clientTCPPort;
  }
  
  public String getDatabaseName() {
    return this.dbName;
  }
  
  public NotificationRegistration.RegistrationState getState() {
    return this.state;
  }
  
  protected void setState(NotificationRegistration.RegistrationState paramRegistrationState) {
    this.state = paramRegistrationState;
  }
  
  int getNamespace() {
    return this.namespace;
  }










  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
