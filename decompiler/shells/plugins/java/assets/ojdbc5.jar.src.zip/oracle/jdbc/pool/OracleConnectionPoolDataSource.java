package oracle.jdbc.pool;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;
import javax.sql.ConnectionPoolDataSource;
import javax.sql.PooledConnection;
import oracle.jdbc.internal.OracleConnection;


















































public class OracleConnectionPoolDataSource
  extends OracleDataSource
  implements ConnectionPoolDataSource
{
  public PooledConnection getPooledConnection() throws SQLException {
    String str1 = null;
    String str2 = null;
    synchronized (this) {
      
      str1 = this.user;
      str2 = this.password;
    } 
    return getPooledConnection(str1, str2);
  }














  
  public PooledConnection getPooledConnection(String paramString1, String paramString2) throws SQLException {
    Connection connection = getPhysicalConnection(paramString1, paramString2);
    OraclePooledConnection oraclePooledConnection = new OraclePooledConnection(connection);

    
    if (paramString2 == null)
      paramString2 = this.password; 
    oraclePooledConnection.setUserName(!paramString1.startsWith("\"") ? paramString1.toLowerCase() : paramString1, paramString2);

    
    return oraclePooledConnection;
  }




  
  PooledConnection getPooledConnection(Properties paramProperties) throws SQLException {
    Connection connection = getPhysicalConnection(paramProperties);
    OraclePooledConnection oraclePooledConnection = new OraclePooledConnection(connection);
    
    String str1 = paramProperties.getProperty("user");
    if (str1 == null)
      str1 = ((OracleConnection)connection).getUserName(); 
    String str2 = paramProperties.getProperty("password");
    if (str2 == null)
      str2 = this.password; 
    oraclePooledConnection.setUserName(!str1.startsWith("\"") ? str1.toLowerCase() : str1, str2);

    
    return oraclePooledConnection;
  }






  
  protected Connection getPhysicalConnection() throws SQLException {
    return getConnection(this.user, this.password);
  }







  
  protected Connection getPhysicalConnection(String paramString1, String paramString2, String paramString3) throws SQLException {
    this.url = paramString1;
    return getConnection(paramString2, paramString3);
  }







  
  protected Connection getPhysicalConnection(String paramString1, String paramString2) throws SQLException {
    return getConnection(paramString1, paramString2);
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
