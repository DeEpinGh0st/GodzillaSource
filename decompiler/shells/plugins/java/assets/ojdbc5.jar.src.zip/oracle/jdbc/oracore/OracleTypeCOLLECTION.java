package oracle.jdbc.oracore;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.Datum;
import oracle.sql.SQLName;
import oracle.sql.StructDescriptor;
import oracle.sql.TypeDescriptor;




























public class OracleTypeCOLLECTION
  extends OracleTypeADT
  implements Serializable
{
  static final long serialVersionUID = -7279638692691669378L;
  public static final int TYPE_PLSQL_INDEX_TABLE = 1;
  public static final int TYPE_NESTED_TABLE = 2;
  public static final int TYPE_VARRAY = 3;
  int userCode = 0;
  long maxSize = 0L;
  OracleType elementType = null;
  static final int CURRENT_USER_OBJECT = 0;
  static final int CURRENT_USER_SYNONYM = 1;
  static final int CURRENT_USER_SYNONYM_10g = 2;
  static final int CURRENT_USER_PUBLIC_SYNONYM = 3;
  static final int CURRENT_USER_PUBLIC_SYNONYM_10g = 4;
  static final int POSSIBLY_OTHER_USER_OBJECT = 5;
  
  public OracleTypeCOLLECTION(String paramString, OracleConnection paramOracleConnection) throws SQLException {
    super(paramString, (Connection)paramOracleConnection);
  }
  
  static final int POSSIBLY_OTHER_USER_OBJECT_10g = 6;
  static final int OTHER_USER_OBJECT = 7;
  static final int OTHER_USER_SYNONYM = 8;
  
  public OracleTypeCOLLECTION(OracleTypeADT paramOracleTypeADT, int paramInt, OracleConnection paramOracleConnection) throws SQLException {
    super(paramOracleTypeADT, paramInt, (Connection)paramOracleConnection);
  }

  
  static final int PUBLIC_SYNONYM = 9;
  
  static final int PUBLIC_SYNONYM_10g = 10;
  
  static final int BREAK = 11;
  
  public OracleTypeCOLLECTION(SQLName paramSQLName, byte[] paramArrayOfbyte1, int paramInt, byte[] paramArrayOfbyte2, OracleConnection paramOracleConnection) throws SQLException {
    super(paramSQLName, paramArrayOfbyte1, paramInt, paramArrayOfbyte2, paramOracleConnection);
  }












  
  public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection) throws SQLException {
    if (paramObject != null) {
      
      if (paramObject instanceof ARRAY) {
        return (Datum)paramObject;
      }
      
      ArrayDescriptor arrayDescriptor = createArrayDescriptor();
      
      return (Datum)new ARRAY(arrayDescriptor, (Connection)this.connection, paramObject);
    } 

    
    return null;
  }








  
  public int getTypeCode() {
    return 2003;
  }







  
  public boolean isInHierarchyOf(OracleType paramOracleType) throws SQLException {
    if (paramOracleType == null) {
      return false;
    }
    if (paramOracleType == this) {
      return true;
    }
    if (paramOracleType.getClass() != getClass()) {
      return false;
    }
    return paramOracleType.getTypeDescriptor().getName().equals(this.descriptor.getName());
  }





  
  public boolean isInHierarchyOf(StructDescriptor paramStructDescriptor) throws SQLException {
    return false;
  }



  
  public boolean isObjectType() {
    return false;
  }










  
  public void parseTDSrec(TDSReader paramTDSReader) throws SQLException {
    long l = paramTDSReader.readLong();


    
    this.maxSize = paramTDSReader.readLong();




    
    this.userCode = paramTDSReader.readByte();

    
    paramTDSReader.addSimplePatch(l, this);
  }








  
  public Datum unlinearize(byte[] paramArrayOfbyte, long paramLong, Datum paramDatum, int paramInt, Map paramMap) throws SQLException {
    return unlinearize(paramArrayOfbyte, paramLong, paramDatum, 1L, -1, paramInt, paramMap);
  }





  
  public Datum unlinearize(byte[] paramArrayOfbyte, long paramLong1, Datum paramDatum, long paramLong2, int paramInt1, int paramInt2, Map paramMap) throws SQLException {
    OracleConnection oracleConnection = getConnection();
    Datum datum = null;



    
    if (oracleConnection == null) {
      
      datum = unlinearizeInternal(paramArrayOfbyte, paramLong1, paramDatum, paramLong2, paramInt1, paramInt2, paramMap);
    
    }
    else {
      
      synchronized (oracleConnection) {
        
        datum = unlinearizeInternal(paramArrayOfbyte, paramLong1, paramDatum, paramLong2, paramInt1, paramInt2, paramMap);
      } 
    } 

    
    return datum;
  }








  
  public synchronized Datum unlinearizeInternal(byte[] paramArrayOfbyte, long paramLong1, Datum paramDatum, long paramLong2, int paramInt1, int paramInt2, Map paramMap) throws SQLException {
    if (paramArrayOfbyte == null) {
      return null;
    }
    
    PickleContext pickleContext = new PickleContext(paramArrayOfbyte, paramLong1);
    
    return (Datum)unpickle81(pickleContext, (ARRAY)paramDatum, paramLong2, paramInt1, 1, paramInt2, paramMap);
  }







  
  public synchronized boolean isInlineImage(byte[] paramArrayOfbyte, int paramInt) throws SQLException {
    if (paramArrayOfbyte == null) {
      return false;
    }

    
    if (PickleContext.isCollectionImage_pctx(paramArrayOfbyte[paramInt]))
      return true; 
    if (PickleContext.isDegenerateImage_pctx(paramArrayOfbyte[paramInt])) {
      return false;
    }
    
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image is not a collection image");
    sQLException.fillInStackTrace();
    throw sQLException;
  }










  
  protected int pickle81(PickleContext paramPickleContext, Datum paramDatum) throws SQLException {
    ARRAY aRRAY = (ARRAY)paramDatum;
    
    boolean bool = aRRAY.hasDataSeg();
    int i = 0;
    int j = paramPickleContext.offset() + 2;
    
    if (bool) {
      
      if (!this.metaDataInitialized) {
        copy_properties((OracleTypeCOLLECTION)aRRAY.getDescriptor().getPickler());
      }
      Datum[] arrayOfDatum = aRRAY.getOracleArray();

      
      if (this.userCode == 3)
      {
        if (arrayOfDatum.length > this.maxSize) {
          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 71, null);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 
      }
      
      i += paramPickleContext.writeCollImageHeader(arrayOfDatum.length, this.typeVersion);
      
      for (byte b = 0; b < arrayOfDatum.length; b++)
      {
        if (arrayOfDatum[b] == null) {
          i += paramPickleContext.writeElementNull();
        } else {
          i += this.elementType.pickle81(paramPickleContext, arrayOfDatum[b]);
        }
      
      }
    
    } else {
      
      i += paramPickleContext.writeCollImageHeader(aRRAY.getLocator());
    } 
    
    paramPickleContext.patchImageLen(j, i);
    
    return i;
  }







  
  ARRAY unpickle81(PickleContext paramPickleContext, ARRAY paramARRAY, int paramInt1, int paramInt2, Map paramMap) throws SQLException {
    return unpickle81(paramPickleContext, paramARRAY, 1L, -1, paramInt1, paramInt2, paramMap);
  }










  
  ARRAY unpickle81(PickleContext paramPickleContext, ARRAY paramARRAY, long paramLong, int paramInt1, int paramInt2, int paramInt3, Map paramMap) throws SQLException {
    ARRAY aRRAY = paramARRAY;
    
    if (aRRAY == null) {
      
      ArrayDescriptor arrayDescriptor = createArrayDescriptor();
      
      aRRAY = new ARRAY(arrayDescriptor, (byte[])null, (Connection)this.connection);
    } 
    
    if (unpickle81ImgHeader(paramPickleContext, aRRAY, paramInt2, paramInt3))
    {
      if (paramLong == 1L && paramInt1 == -1) {
        unpickle81ImgBody(paramPickleContext, aRRAY, paramInt3, paramMap);
      } else {
        unpickle81ImgBody(paramPickleContext, aRRAY, paramLong, paramInt1, paramInt3, paramMap);
      } 
    }
    
    return aRRAY;
  }




  
  boolean unpickle81ImgHeader(PickleContext paramPickleContext, ARRAY paramARRAY, int paramInt1, int paramInt2) throws SQLException {
    boolean bool = true;
    
    if (paramInt1 == 3)
    {
      paramARRAY.setImage(paramPickleContext.image(), paramPickleContext.absoluteOffset(), 0L);
    }
    
    byte b = paramPickleContext.readByte();
    
    if (!PickleContext.is81format(b)) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image is not in 8.1 format");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (!PickleContext.hasPrefix(b)) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image has no prefix segment");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (PickleContext.isCollectionImage_pctx(b)) {
      bool = true;
    } else if (PickleContext.isDegenerateImage_pctx(b)) {
      bool = false;
    } else {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image is not a collection image");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    paramPickleContext.readByte();

    
    if (paramInt1 == 9) {
      
      paramPickleContext.skipBytes(paramPickleContext.readLength(true) - 2);
      
      return false;
    } 
    if (paramInt1 == 3) {
      
      long l = paramPickleContext.readLength();
      
      paramARRAY.setImageLength(l);
      paramPickleContext.skipTo(paramARRAY.getImageOffset() + l);
      
      return false;
    } 
    
    paramPickleContext.skipLength();

    
    int i = paramPickleContext.readLength();



    
    paramARRAY.setPrefixFlag(paramPickleContext.readByte());
    
    if (paramARRAY.isInline()) {





      
      paramPickleContext.readDataValue(i - 1);
    }
    else {
      
      paramARRAY.setLocator(paramPickleContext.readDataValue(i - 1));
    } 
    
    return paramARRAY.isInline();
  }








  
  void unpickle81ImgBody(PickleContext paramPickleContext, ARRAY paramARRAY, long paramLong, int paramInt1, int paramInt2, Map paramMap) throws SQLException {
    paramPickleContext.readByte();

    
    int i = paramPickleContext.readLength();
    
    paramARRAY.setLength(i);
    
    if (paramInt2 == 0) {
      return;
    }

    
    int j = (int)getAccessLength(i, paramLong, paramInt1);
    boolean bool = (ArrayDescriptor.getCacheStyle(paramARRAY) == 1) ? true : false;



    
    if (paramLong > 1L && j > 0) {
      
      long l = paramARRAY.getLastIndex();
      
      if (l < paramLong) {
        
        if (l > 0L) {
          paramPickleContext.skipTo(paramARRAY.getLastOffset());
        } else {
          l = 1L;
        } 
        if (bool) {
          long l1;
          for (l1 = l; l1 < paramLong; l1++) {
            
            paramARRAY.setIndexOffset(l1, paramPickleContext.offset());
            this.elementType.unpickle81rec(paramPickleContext, 9, null);
          } 
        } else {
          long l1;
          
          for (l1 = l; l1 < paramLong; l1++) {
            this.elementType.unpickle81rec(paramPickleContext, 9, null);
          }
        } 
      } else if (l > paramLong) {
        
        long l1 = paramARRAY.getOffset(paramLong);
        
        if (l1 != -1L) {
          
          paramPickleContext.skipTo(l1);

        
        }
        else if (bool) {
          
          for (byte b = 1; b < paramLong; b++)
          {
            paramARRAY.setIndexOffset(b, paramPickleContext.offset());
            this.elementType.unpickle81rec(paramPickleContext, 9, null);
          }
        
        } else {
          
          for (byte b = 1; b < paramLong; b++) {
            this.elementType.unpickle81rec(paramPickleContext, 9, null);
          }
        } 
      } else {
        
        paramPickleContext.skipTo(paramARRAY.getLastOffset());
      } 
      paramARRAY.setLastIndexOffset(paramLong, paramPickleContext.offset());
    } 

    
    unpickle81ImgBodyElements(paramPickleContext, paramARRAY, (int)paramLong, j, paramInt2, paramMap);
  }








  
  void unpickle81ImgBody(PickleContext paramPickleContext, ARRAY paramARRAY, int paramInt, Map paramMap) throws SQLException {
    paramPickleContext.readByte();

    
    int i = paramPickleContext.readLength();
    
    paramARRAY.setLength(i);
    
    if (paramInt == 0) {
      return;
    }

    
    unpickle81ImgBodyElements(paramPickleContext, paramARRAY, 1, i, paramInt, paramMap);
  }




  
  private void unpickle81ImgBodyElements(PickleContext paramPickleContext, ARRAY paramARRAY, int paramInt1, int paramInt2, int paramInt3, Map paramMap) throws SQLException {
    Datum[] arrayOfDatum;
    Object[] arrayOfObject;
    SQLException sQLException;
    boolean bool = (ArrayDescriptor.getCacheStyle(paramARRAY) == 1) ? true : false;


    
    switch (paramInt3) {


      
      case 1:
        arrayOfDatum = new Datum[paramInt2];
        
        if (bool) {
          
          for (byte b = 0; b < paramInt2; b++)
          {
            paramARRAY.setIndexOffset((paramInt1 + b), paramPickleContext.offset());
            
            arrayOfDatum[b] = (Datum)this.elementType.unpickle81rec(paramPickleContext, paramInt3, paramMap);
          }
        
        }
        else {
          
          for (byte b = 0; b < paramInt2; b++) {
            arrayOfDatum[b] = (Datum)this.elementType.unpickle81rec(paramPickleContext, paramInt3, paramMap);
          }
        } 
        
        paramARRAY.setDatumArray(arrayOfDatum);
        break;



      
      case 2:
        arrayOfObject = ArrayDescriptor.makeJavaArray(paramInt2, this.elementType.getTypeCode());

        
        if (bool) {
          
          for (byte b = 0; b < paramInt2; b++)
          {
            paramARRAY.setIndexOffset((paramInt1 + b), paramPickleContext.offset());
            
            arrayOfObject[b] = this.elementType.unpickle81rec(paramPickleContext, paramInt3, paramMap);
          }
        
        } else {
          
          for (byte b = 0; b < paramInt2; b++) {
            arrayOfObject[b] = this.elementType.unpickle81rec(paramPickleContext, paramInt3, paramMap);
          }
        } 
        paramARRAY.setObjArray(arrayOfObject);
        break;







      
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
        if (this.elementType instanceof OracleTypeNUMBER || this.elementType instanceof OracleTypeFLOAT) {

          
          paramARRAY.setObjArray(OracleTypeNUMBER.unpickle81NativeArray(paramPickleContext, 1L, paramInt2, paramInt3));
          
          break;
        } 
        
        sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "This feature is limited to numeric collection");
        sQLException.fillInStackTrace();
        throw sQLException;





      
      default:
        sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "Invalid conversion type " + this.elementType);
        sQLException.fillInStackTrace();
        throw sQLException;
    } 


    
    paramARRAY.setLastIndexOffset((paramInt1 + paramInt2), paramPickleContext.offset());
  }




















  
  static final String[] sqlString = new String[] { "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM USER_COLL_TYPES WHERE TYPE_NAME = :1", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM USER_COLL_TYPES WHERE TYPE_NAME in (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :1 CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :1 FROM DUAL) ", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM USER_COLL_TYPES WHERE TYPE_NAME in (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :1 CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :1 FROM DUAL) ", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM USER_COLL_TYPES WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM ALL_SYNONYMS START WITH SYNONYM_NAME = :1 AND  OWNER = 'PUBLIC' CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER UNION SELECT :2  FROM DUAL) ", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM USER_COLL_TYPES WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM ALL_SYNONYMS START WITH SYNONYM_NAME = :1 AND  OWNER = 'PUBLIC' CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER UNION SELECT :2  FROM DUAL) ", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :tname CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :tname FROM DUAL)", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :tname CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :tname FROM DUAL)", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES WHERE OWNER = :1 AND TYPE_NAME = :2", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES WHERE OWNER = (SELECT TABLE_OWNER FROM ALL_SYNONYMS WHERE SYNONYM_NAME=:1) AND TYPE_NAME = (SELECT TABLE_NAME FROM ALL_SYNONYMS WHERE SYNONYM_NAME=:2) ", "DECLARE   the_owner VARCHAR2(100);   the_type  VARCHAR2(100); begin  SELECT TABLE_NAME, TABLE_OWNER INTO THE_TYPE, THE_OWNER  FROM ALL_SYNONYMS  WHERE TABLE_NAME IN (SELECT TYPE_NAME FROM ALL_TYPES)  START WITH SYNONYM_NAME = :1 AND OWNER = 'PUBLIC'  CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER; OPEN :2 FOR SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES  WHERE TYPE_NAME = THE_TYPE and OWNER = THE_OWNER; END;", "DECLARE   the_owner VARCHAR2(100);   the_type  VARCHAR2(100); begin  SELECT TABLE_NAME, TABLE_OWNER INTO THE_TYPE, THE_OWNER  FROM ALL_SYNONYMS  WHERE TABLE_NAME IN (SELECT TYPE_NAME FROM ALL_TYPES)  START WITH SYNONYM_NAME = :1 AND OWNER = 'PUBLIC'  CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER; OPEN :2 FOR SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES  WHERE TYPE_NAME = THE_TYPE and OWNER = THE_OWNER; END;" };







































































































  
  private void initCollElemTypeName() throws SQLException {
    if (this.connection == null)
      return; 
    synchronized (this.connection) {
      if (this.sqlName == null) {
        getFullName();
      }
      CallableStatement callableStatement = null;
      PreparedStatement preparedStatement = null;
      ResultSet resultSet = null;
      try {
        byte b = this.sqlName.getSchema().equalsIgnoreCase(this.connection.getDefaultSchemaNameForNamedTypes()) ? 0 : 7;

        
        while (b != 11) {
          
          switch (b) {

            
            case false:
              preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b]);
              preparedStatement.setString(1, this.sqlName.getSimpleName());
              preparedStatement.setFetchSize(1);
              resultSet = preparedStatement.executeQuery();
              b = 1;
              break;
            
            case true:
              if (this.connection.getVersionNumber() >= 10000)
              {
                b = 2;
              }

            
            case true:
              preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b]);
              preparedStatement.setString(1, this.sqlName.getSimpleName());
              preparedStatement.setString(2, this.sqlName.getSimpleName());
              preparedStatement.setFetchSize(1);
              resultSet = preparedStatement.executeQuery();
              b = 3;
              break;
            
            case true:
              if (this.connection.getVersionNumber() >= 10000)
              {
                b = 4;
              }

            
            case true:
              preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b]);
              preparedStatement.setString(1, this.sqlName.getSimpleName());
              preparedStatement.setString(2, this.sqlName.getSimpleName());
              preparedStatement.setFetchSize(1);
              resultSet = preparedStatement.executeQuery();
              b = 5;
              break;
            
            case true:
              if (this.connection.getVersionNumber() >= 10000)
              {
                b = 6;
              }

            
            case true:
              preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b]);
              preparedStatement.setString(1, this.sqlName.getSimpleName());
              preparedStatement.setString(2, this.sqlName.getSimpleName());
              preparedStatement.setFetchSize(1);
              resultSet = preparedStatement.executeQuery();
              b = 8;
              break;

            
            case true:
              preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b]);
              preparedStatement.setString(1, this.sqlName.getSchema());
              preparedStatement.setString(2, this.sqlName.getSimpleName());
              preparedStatement.setFetchSize(1);
              resultSet = preparedStatement.executeQuery();
              b = 8;
              break;

            
            case true:
              preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b]);
              preparedStatement.setString(1, this.sqlName.getSimpleName());
              preparedStatement.setString(2, this.sqlName.getSimpleName());
              preparedStatement.setFetchSize(1);
              resultSet = preparedStatement.executeQuery();
              b = 9;
              break;
            
            case true:
              if (this.connection.getVersionNumber() >= 10000)
              {
                b = 10;
              }

            
            case true:
              callableStatement = this.connection.prepareCall(getSqlHint() + sqlString[b]);
              callableStatement.setString(1, this.sqlName.getSimpleName());
              callableStatement.registerOutParameter(2, -10);
              callableStatement.execute();
              resultSet = ((OracleCallableStatement)callableStatement).getCursor(2);
              b = 11;
              break;
          } 
          
          if (resultSet.next()) {
            
            if (this.attrTypeNames == null) {
              this.attrTypeNames = new String[1];
            }
            this.attrTypeNames[0] = resultSet.getString(2) + "." + resultSet.getString(1);
            b = 11; continue;
          }  if (b == 11) {
            
            SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
            sQLException.fillInStackTrace();
            throw sQLException;
          } 
        } 
        while (b != 11);
      } finally {
        
        if (resultSet != null)
          resultSet.close(); 
        if (preparedStatement != null)
          preparedStatement.close(); 
        if (callableStatement != null) {
          callableStatement.close();
        }
      } 
    } 
  }



  
  public String getAttributeName(int paramInt) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public String getAttributeName(int paramInt, boolean paramBoolean) throws SQLException {
    return getAttributeName(paramInt);
  }









  
  public String getAttributeType(int paramInt) throws SQLException {
    if (paramInt != 1) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.sqlName == null) {
      getFullName();
    }
    if (this.attrTypeNames == null) {
      initCollElemTypeName();
    }
    return this.attrTypeNames[0];
  }



  
  public String getAttributeType(int paramInt, boolean paramBoolean) throws SQLException {
    if (paramBoolean) {
      return getAttributeType(paramInt);
    }
    
    if (paramInt != 1) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.sqlName != null && this.attrTypeNames != null) {
      return this.attrTypeNames[0];
    }
    return null;
  }




  
  public int getNumAttrs() throws SQLException {
    return 0;
  }



  
  public OracleType getAttrTypeAt(int paramInt) throws SQLException {
    return null;
  }



  
  ArrayDescriptor createArrayDescriptor() throws SQLException {
    return new ArrayDescriptor(this, (Connection)this.connection);
  }



  
  ArrayDescriptor createArrayDescriptorWithItsOwnTree() throws SQLException {
    if (this.descriptor == null)
    {
      if (this.sqlName == null && getFullName(false) == null) {
        
        this.descriptor = (TypeDescriptor)new ArrayDescriptor(this, (Connection)this.connection);
      }
      else {
        
        this.descriptor = (TypeDescriptor)ArrayDescriptor.createDescriptor(this.sqlName, (Connection)this.connection);
      } 
    }
    
    return (ArrayDescriptor)this.descriptor;
  }



  
  public OracleType getElementType() throws SQLException {
    return this.elementType;
  }



  
  public int getUserCode() throws SQLException {
    return this.userCode;
  }



  
  public long getMaxLength() throws SQLException {
    return this.maxSize;
  }




  
  private long getAccessLength(long paramLong1, long paramLong2, int paramInt) throws SQLException {
    if (paramLong2 > paramLong1) {
      return 0L;
    }
    if (paramInt < 0)
    {
      return paramLong1 - paramLong2 + 1L;
    }

    
    return Math.min(paramLong1 - paramLong2 + 1L, paramInt);
  }








  
  private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
    paramObjectOutputStream.writeInt(this.userCode);
    paramObjectOutputStream.writeLong(this.maxSize);
    paramObjectOutputStream.writeObject(this.elementType);
  }




  
  private void readObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {
    this.userCode = paramObjectInputStream.readInt();
    this.maxSize = paramObjectInputStream.readLong();
    this.elementType = (OracleType)paramObjectInputStream.readObject();
  }



  
  public void setConnection(OracleConnection paramOracleConnection) throws SQLException {
    this.connection = paramOracleConnection;
    
    this.elementType.setConnection(paramOracleConnection);
  }



  
  public void initMetadataRecursively() throws SQLException {
    initMetadata(this.connection);
    if (this.elementType != null) this.elementType.initMetadataRecursively();
  
  }


  
  public void initChildNamesRecursively(Map paramMap) throws SQLException {
    TypeTreeElement typeTreeElement = (TypeTreeElement)paramMap.get(this.sqlName);
    
    if (this.elementType != null) {
      
      this.elementType.setNames(typeTreeElement.getChildSchemaName(0), typeTreeElement.getChildTypeName(0));
      this.elementType.initChildNamesRecursively(paramMap);
      this.elementType.cacheDescriptor();
    } 
  }



  
  public void cacheDescriptor() throws SQLException {
    this.descriptor = (TypeDescriptor)ArrayDescriptor.createDescriptor(this);
  }



  
  public void printXML(PrintWriter paramPrintWriter, int paramInt) throws SQLException {
    printXML(paramPrintWriter, paramInt, false);
  }


  
  public void printXML(PrintWriter paramPrintWriter, int paramInt, boolean paramBoolean) throws SQLException {
    byte b;
    for (b = 0; b < paramInt; ) { paramPrintWriter.print("  "); b++; }
     paramPrintWriter.println("<OracleTypeCOLLECTION sqlName=\"" + this.sqlName + "\" " + ">");

    
    if (this.elementType != null)
      this.elementType.printXML(paramPrintWriter, paramInt + 1, paramBoolean); 
    for (b = 0; b < paramInt; ) { paramPrintWriter.print("  "); b++; }
     paramPrintWriter.println("</OracleTypeCOLLECTION>");
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
