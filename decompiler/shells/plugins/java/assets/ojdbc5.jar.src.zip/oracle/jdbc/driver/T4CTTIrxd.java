package oracle.jdbc.driver;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.BitSet;
import java.util.Vector;
import oracle.jdbc.OracleResultSetMetaData;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.oracore.OracleTypeADT;
































class T4CTTIrxd
  extends T4CTTIMsg
{
  static final byte[] NO_BYTES = new byte[0];


  
  byte[] buffer;

  
  byte[] bufferCHAR;

  
  BitSet bvcColSent = null;
  int nbOfColumns = 0;



  
  boolean bvcFound = false;



  
  boolean isFirstCol;



  
  static final byte TTICMD_UNAUTHORIZED = 1;



  
  T4CTTIrxd(T4CConnection paramT4CConnection) {
    super(paramT4CConnection, (byte)7);
    
    this.isFirstCol = true;
  }



  
  void init() {
    this.isFirstCol = true;
  }



  
  void setNumberOfColumns(int paramInt) {
    this.nbOfColumns = paramInt;
    this.bvcFound = false;
    
    if (this.bvcColSent == null || this.bvcColSent.length() < this.nbOfColumns) {
      this.bvcColSent = new BitSet(this.nbOfColumns);
    } else {
      this.bvcColSent.clear();
    } 
  }



  
  void unmarshalBVC(int paramInt) throws SQLException, IOException {
    byte b1 = 0;
    
    int i;
    for (i = 0; i < this.bvcColSent.length(); i++) {
      this.bvcColSent.clear(i);
    }
    
    i = this.nbOfColumns / 8 + ((this.nbOfColumns % 8 != 0) ? 1 : 0);

    
    for (byte b2 = 0; b2 < i; b2++) {
      
      byte b = (byte)(this.meg.unmarshalUB1() & 0xFF);
      
      for (byte b3 = 0; b3 < 8; b3++) {
        
        if ((b & 1 << b3) != 0) {
          
          this.bvcColSent.set(b2 * 8 + b3);
          
          b1++;
        } 
      } 
    } 
    
    if (b1 != paramInt) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), -1, "INTERNAL ERROR: oracle.jdbc.driver.T4CTTIrxd.unmarshalBVC: bits missing in vector");
      
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    this.bvcFound = true;
  }








  
  void readBitVector(byte[] paramArrayOfbyte) throws SQLException, IOException {
    byte b;
    for (b = 0; b < this.bvcColSent.length(); b++) {
      this.bvcColSent.clear(b);
    }
    if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
      this.bvcFound = false;
    } else {
      
      for (b = 0; b < paramArrayOfbyte.length; b++) {
        byte b1 = paramArrayOfbyte[b];
        for (byte b2 = 0; b2 < 8; b2++) {
          if ((b1 & 1 << b2) != 0)
            this.bvcColSent.set(b * 8 + b2); 
        } 
      } 
      this.bvcFound = true;
    } 
  }























  
  Vector<IOException> marshal(byte[] paramArrayOfbyte1, char[] paramArrayOfchar1, short[] paramArrayOfshort1, int paramInt1, byte[] paramArrayOfbyte2, DBConversion paramDBConversion, InputStream[] paramArrayOfInputStream, byte[][] paramArrayOfbyte, OracleTypeADT[] paramArrayOfOracleTypeADT, byte[] paramArrayOfbyte3, char[] paramArrayOfchar2, short[] paramArrayOfshort2, byte[] paramArrayOfbyte4, int paramInt2, int[] paramArrayOfint1, boolean paramBoolean1, int[] paramArrayOfint2, int[] paramArrayOfint3, int[][] paramArrayOfint, boolean paramBoolean2) throws IOException {
    Vector<IOException> vector = null;
    
    try {
      int k;
      
      marshalTTCcode();

      
      int i = paramArrayOfshort1[paramInt1 + 0] & 0xFFFF;




















      
      byte b1 = 0;
      int j = paramArrayOfint3[0];
      int[] arrayOfInt = paramArrayOfint[0];
      
      byte b2 = 0;


      
      if (paramBoolean2) {
        
        k = 1;
        assert j > 0 : "No postoned columns in RXD";
      }
      else {
        
        for (byte b = 0; b < i; b++) {
          
          if (b1 < j && arrayOfInt[b1] == b) {

            
            b1++;
            
            continue;
          } 
          boolean bool = false;



          
          int m = paramInt1 + 5 + 10 * b;



          
          int i2 = paramArrayOfshort1[m + 0] & 0xFFFF;



          
          if (paramArrayOfbyte4 != null && (paramArrayOfbyte4[b] & 0x20) == 0) {


            
            if (i2 == 998) {
              b2++;
            }
            
            continue;
          } 
          int n = ((paramArrayOfshort1[m + 7] & 0xFFFF) << 16) + (paramArrayOfshort1[m + 8] & 0xFFFF) + paramInt2;


          
          int i3 = ((paramArrayOfshort1[m + 5] & 0xFFFF) << 16) + (paramArrayOfshort1[m + 6] & 0xFFFF) + paramInt2;



          
          int i1 = paramArrayOfshort1[n] & 0xFFFF;
          
          short s = paramArrayOfshort1[i3];
          
          if (i2 == 116) {
            
            this.meg.marshalUB1((short)1);
            this.meg.marshalUB1((short)0);
            
            continue;
          } 
          if (i2 == 994) {
            
            s = -1;
            int i4 = paramArrayOfint2[3 + b * 4 + 0];


            
            if (i4 == 109) {
              bool = true;
            }
          } else if (i2 == 8 || i2 == 24 || (!paramBoolean1 && paramArrayOfint1 != null && paramArrayOfint1.length > b && paramArrayOfint1[b] > 4000)) {















            
            if (j >= arrayOfInt.length) {
              
              int[] arrayOfInt1 = new int[arrayOfInt.length << 1];

              
              System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, arrayOfInt.length);


              
              arrayOfInt = arrayOfInt1;
            } 
            
            arrayOfInt[j++] = b;


            
            continue;
          } 

          
          if (s == -1) {
            
            if (i2 == 109 || bool) {

              
              this.meg.marshalDALC(NO_BYTES);
              this.meg.marshalDALC(NO_BYTES);
              this.meg.marshalDALC(NO_BYTES);
              this.meg.marshalUB2(0);
              this.meg.marshalUB4(0L);
              this.meg.marshalUB2(1);
              
              continue;
            } 
            if (i2 == 998) {
              
              b2++;
              this.meg.marshalUB4(0L);
              continue;
            } 
            if (i2 == 112 || i2 == 113 || i2 == 114) {
              
              this.meg.marshalUB4(0L);
              continue;
            } 
            if (i2 != 8 && i2 != 24) {







              
              this.meg.marshalUB1((short)0);
              
              continue;
            } 
          } 
          
          if (i2 == 998) {

            
            int i4 = (paramArrayOfshort2[6 + b2 * 8 + 4] & 0xFFFF) << 16 & 0xFFFF000 | paramArrayOfshort2[6 + b2 * 8 + 5] & 0xFFFF;

            
            int i5 = (paramArrayOfshort2[6 + b2 * 8 + 6] & 0xFFFF) << 16 & 0xFFFF000 | paramArrayOfshort2[6 + b2 * 8 + 7] & 0xFFFF;

            
            int i6 = paramArrayOfshort2[6 + b2 * 8] & 0xFFFF;
            int i7 = paramArrayOfshort2[6 + b2 * 8 + 1] & 0xFFFF;
            
            this.meg.marshalUB4(i4);
            
            for (byte b3 = 0; b3 < i4; b3++) {
              
              int i8 = i5 + b3 * i7;
              
              if (i6 == 9) {
                
                int i9 = paramArrayOfchar2[i8] / 2;
                int i10 = 0;
                i10 = paramDBConversion.javaCharsToCHARBytes(paramArrayOfchar2, i8 + 1, paramArrayOfbyte2, 0, i9);




                
                this.meg.marshalCLR(paramArrayOfbyte2, i10);
              }
              else {
                
                i1 = paramArrayOfbyte3[i8];
                
                if (i1 < 1) {
                  this.meg.marshalUB1((short)0);
                } else {
                  this.meg.marshalCLR(paramArrayOfbyte3, i8 + 1, i1);
                } 
              } 
            } 
            b2++;


          
          }
          else {


            
            int i4 = paramArrayOfshort1[m + 1] & 0xFFFF;


            
            if (i4 != 0) {




              
              int i5 = ((paramArrayOfshort1[m + 3] & 0xFFFF) << 16) + (paramArrayOfshort1[m + 4] & 0xFFFF) + i4 * paramInt2;





              
              if (i2 == 6) {
                
                i5++;
                i1--;
              }
              else if (i2 == 9) {
                
                i5 += 2;
                
                i1 -= 2;
              }
              else if (i2 == 114 || i2 == 113 || i2 == 112) {

                
                this.meg.marshalUB4(i1);
              } 

              
              if (i2 == 109 || i2 == 111) {
                
                if (paramArrayOfbyte == null) {

                  
                  SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), -1, "INTERNAL ERROR: oracle.jdbc.driver.T4CTTIrxd.marshal: parameterDatum is null");
                  
                  sQLException.fillInStackTrace();
                  throw sQLException;
                } 

                
                byte[] arrayOfByte = paramArrayOfbyte[b];
                
                i1 = (arrayOfByte == null) ? 0 : arrayOfByte.length;
                
                if (i2 == 109) {
                  
                  this.meg.marshalDALC(NO_BYTES);
                  this.meg.marshalDALC(NO_BYTES);
                  this.meg.marshalDALC(NO_BYTES);
                  this.meg.marshalUB2(0);
                  
                  this.meg.marshalUB4(i1);
                  this.meg.marshalUB2(1);
                } 
                
                if (i1 > 0) {
                  this.meg.marshalCLR(arrayOfByte, 0, i1);
                }
              } else if (i2 == 104) {


                
                i5 += 2;
                
                long[] arrayOfLong = T4CRowidAccessor.stringToRowid(paramArrayOfbyte1, i5, 18);
                
                byte b3 = 14;
                long l1 = arrayOfLong[0];
                int i6 = (int)arrayOfLong[1];
                boolean bool1 = false;
                long l2 = arrayOfLong[2];
                int i7 = (int)arrayOfLong[3];

                
                if (l1 == 0L && i6 == 0 && l2 == 0L && i7 == 0)
                {



                  
                  this.meg.marshalUB1((short)0);
                }
                else
                {
                  this.meg.marshalUB1(b3);
                  this.meg.marshalUB4(l1);
                  this.meg.marshalUB2(i6);
                  this.meg.marshalUB1(bool1);
                  this.meg.marshalUB4(l2);
                  this.meg.marshalUB2(i7);
                }
              
              } else if (i2 == 208) {


                
                i5 += 2;
                i1 -= 2;
                this.meg.marshalUB4(i1);
                this.meg.marshalCLR(paramArrayOfbyte1, i5, i1);

              
              }
              else if (i1 < 1) {
                this.meg.marshalUB1((short)0);
              } else {
                this.meg.marshalCLR(paramArrayOfbyte1, i5, i1);

              
              }

            
            }
            else {

              
              int i7 = paramArrayOfshort1[m + 9] & 0xFFFF;





              
              int i5 = paramArrayOfshort1[m + 2] & 0xFFFF;

              
              int i6 = ((paramArrayOfshort1[m + 3] & 0xFFFF) << 16) + (paramArrayOfshort1[m + 4] & 0xFFFF) + i5 * paramInt2 + 1;



              
              if (i2 == 996) {







                
                char c = paramArrayOfchar1[i6 - 1];
                
                if (this.bufferCHAR == null || this.bufferCHAR.length < c) {
                  this.bufferCHAR = new byte[c];
                }
                for (byte b3 = 0; b3 < c; b3++) {
                  
                  this.bufferCHAR[b3] = (byte)((paramArrayOfchar1[i6 + b3 / 2] & 0xFF00) >> 8 & 0xFF);


                  
                  if (b3 < c - 1) {
                    
                    this.bufferCHAR[b3 + 1] = (byte)(paramArrayOfchar1[i6 + b3 / 2] & 0xFF & 0xFF);

                    
                    b3++;
                  } 
                } 
                
                this.meg.marshalCLR(this.bufferCHAR, c);
                
                if (this.bufferCHAR.length > 4000) {
                  this.bufferCHAR = null;
                }
              } else {
                int i8;






                
                if (i2 == 96) {


                  
                  i8 = i1 / 2;
                  i6--;
                }
                else {
                  
                  i8 = (i1 - 2) / 2;
                } 

                
                int i9 = 0;



                
                if (i7 == 2) {
                  
                  i9 = paramDBConversion.javaCharsToNCHARBytes(paramArrayOfchar1, i6, paramArrayOfbyte2, 0, i8);
                
                }
                else {
                  
                  i9 = paramDBConversion.javaCharsToCHARBytes(paramArrayOfchar1, i6, paramArrayOfbyte2, 0, i8);
                } 



                
                this.meg.marshalCLR(paramArrayOfbyte2, i9);
              } 
            } 
          } 

          
          continue;
        } 

        
        k = j;
      } 
      
      if (j > 0)
      {
        for (byte b = 0; b < k; b++) {
          
          int i6 = arrayOfInt[b];
          
          int m = paramInt1 + 5 + 10 * i6;


          
          int i4 = paramArrayOfshort1[m + 0] & 0xFFFF;


          
          int n = ((paramArrayOfshort1[m + 7] & 0xFFFF) << 16) + (paramArrayOfshort1[m + 8] & 0xFFFF) + paramInt2;


          
          int i5 = ((paramArrayOfshort1[m + 5] & 0xFFFF) << 16) + (paramArrayOfshort1[m + 6] & 0xFFFF) + paramInt2;


          
          short s = paramArrayOfshort1[i5];
          int i1 = paramArrayOfshort1[n] & 0xFFFF;
          
          int i2 = paramArrayOfshort1[m + 2] & 0xFFFF;

          
          int i3 = ((paramArrayOfshort1[m + 3] & 0xFFFF) << 16) + (paramArrayOfshort1[m + 4] & 0xFFFF) + i2 * paramInt2 + 1;



          
          if (s == -1) {
            
            this.meg.marshalUB1((short)0);

          
          }
          else if (i4 == 996) {







            
            char c = paramArrayOfchar1[i3 - 1];
            
            if (this.bufferCHAR == null || this.bufferCHAR.length < c) {
              this.bufferCHAR = new byte[c];
            }
            for (byte b3 = 0; b3 < c; b3++) {
              
              this.bufferCHAR[b3] = (byte)((paramArrayOfchar1[i3 + b3 / 2] & 0xFF00) >> 8 & 0xFF);


              
              if (b3 < c - 1) {
                
                this.bufferCHAR[b3 + 1] = (byte)(paramArrayOfchar1[i3 + b3 / 2] & 0xFF & 0xFF);
                
                b3++;
              } 
            } 
            
            this.meg.marshalCLR(this.bufferCHAR, c);
            
            if (this.bufferCHAR.length > 4000) {
              this.bufferCHAR = null;
            }
          } else if (i4 != 8 && i4 != 24) {
            int i7;




            
            if (i4 == 96) {


              
              i7 = i1 / 2;
              i3--;
            }
            else {
              
              i7 = (i1 - 2) / 2;
            } 
            
            int i8 = paramArrayOfshort1[m + 9] & 0xFFFF;



            
            int i9 = 0;



            
            if (i8 == 2) {
              
              i9 = paramDBConversion.javaCharsToNCHARBytes(paramArrayOfchar1, i3, paramArrayOfbyte2, 0, i7);
            
            }
            else {
              
              i9 = paramDBConversion.javaCharsToCHARBytes(paramArrayOfchar1, i3, paramArrayOfbyte2, 0, i7);
            } 



            
            this.meg.marshalCLR(paramArrayOfbyte2, i9);
          
          }
          else {
            
            int i7 = i6;

            
            if (paramArrayOfInputStream != null) {
              
              InputStream inputStream = paramArrayOfInputStream[i7];
              
              if (inputStream != null) {


                
                byte b3 = 64;
                
                if (this.buffer == null) {
                  this.buffer = new byte[b3];
                }
                int i8 = 0;

                
                this.meg.marshalUB1((short)254);
                
                boolean bool = false;
                
                while (!bool && !this.connection.sentCancel) {
                  
                  try {
                    i8 = inputStream.read(this.buffer, 0, b3);
                  } catch (IOException iOException) {
                    i8 = -1;
                    if (vector == null)
                      vector = new Vector(); 
                    vector.add(iOException);
                  } 
                  
                  if (i8 == -1) {
                    bool = true;
                  }
                  if (i8 > 0) {


                    
                    this.meg.marshalUB1((short)(i8 & 0xFF));

                    
                    this.meg.marshalB1Array(this.buffer, 0, i8);
                  } 
                } 

                
                this.meg.marshalUB1((short)0);
              } 
            } 
          } 
        } 
      }










      
      paramArrayOfint3[0] = j;
      paramArrayOfint[0] = arrayOfInt;
    }
    catch (SQLException sQLException) {
      
      IOException iOException = new IOException();
      iOException.initCause(sQLException);
      throw iOException;
    } 
    
    return vector;
  }







  
  boolean unmarshal(Accessor[] paramArrayOfAccessor, int paramInt) throws SQLException, IOException {
    return unmarshal(paramArrayOfAccessor, 0, paramInt);
  }













  
  boolean unmarshal(Accessor[] paramArrayOfAccessor, int paramInt1, int paramInt2) throws SQLException, IOException {
    if (paramInt1 == 0) {
      this.isFirstCol = true;
    }
    for (int i = paramInt1; i < paramInt2 && i < paramArrayOfAccessor.length; i++) {
      
      if (paramArrayOfAccessor[i] != null) {















        
        if ((paramArrayOfAccessor[i]).physicalColumnIndex < 0) {


          
          byte b1 = 0;
          
          for (byte b2 = 0; b2 < paramInt2 && b2 < paramArrayOfAccessor.length; b2++) {
            
            if (paramArrayOfAccessor[b2] != null) {
              
              (paramArrayOfAccessor[b2]).physicalColumnIndex = b1;
              
              if (!(paramArrayOfAccessor[b2]).isUseLess) {
                b1++;
              }
            } 
          } 
        } 
        if (this.bvcFound && !(paramArrayOfAccessor[i]).isUseLess && !this.bvcColSent.get((paramArrayOfAccessor[i]).physicalColumnIndex)) {


          
          paramArrayOfAccessor[i].copyRow();
        }
        else {
          
          byte b = 0;


          
          if ((paramArrayOfAccessor[i]).statement.statementType != 2 && !(paramArrayOfAccessor[i]).statement.sqlKind.isPlsqlOrCall()) {

            
            int j = (paramArrayOfAccessor[i]).metaDataIndex + (paramArrayOfAccessor[i]).lastRowProcessed * 1;
            
            if ((paramArrayOfAccessor[i]).securityAttribute == OracleResultSetMetaData.SecurityAttribute.ENABLED) {
              b = (byte)this.meg.unmarshalUB1();
            }
            (paramArrayOfAccessor[i]).rowSpaceMetaData[j] = b;
          } 
          
          if (paramArrayOfAccessor[i].unmarshalOneRow()) {
            return true;
          }
          this.isFirstCol = false;
        } 
      } 
    } 
    
    this.bvcFound = false;
    
    return false;
  }





  
  boolean unmarshal(Accessor[] paramArrayOfAccessor, int paramInt1, int paramInt2, int paramInt3) throws SQLException, IOException {
    return false;
  }











  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
