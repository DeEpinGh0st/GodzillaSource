package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;















































class LRUStatementCache
{
  private int cacheSize;
  private int numElements;
  private OracleStatementCacheEntry applicationCacheStart;
  private OracleStatementCacheEntry applicationCacheEnd;
  private OracleStatementCacheEntry implicitCacheStart;
  private OracleStatementCacheEntry explicitCacheStart;
  boolean implicitCacheEnabled;
  boolean explicitCacheEnabled;
  private boolean debug = false;
  
  protected LRUStatementCache(int paramInt) throws SQLException {
    if (paramInt < 0) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 123);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.cacheSize = paramInt;
    this.numElements = 0;
    
    this.implicitCacheStart = null;
    this.explicitCacheStart = null;
    
    this.implicitCacheEnabled = false;
    this.explicitCacheEnabled = false;
  }














  
  protected void resize(int paramInt) throws SQLException {
    if (paramInt < 0) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 123);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (paramInt >= this.cacheSize || paramInt >= this.numElements) {

      
      this.cacheSize = paramInt;
    
    }
    else {

      
      OracleStatementCacheEntry oracleStatementCacheEntry = this.applicationCacheEnd;
      for (; this.numElements > paramInt; oracleStatementCacheEntry = oracleStatementCacheEntry.applicationPrev) {
        purgeCacheEntry(oracleStatementCacheEntry);
      }
      this.cacheSize = paramInt;
    } 
  }













  
  public void setImplicitCachingEnabled(boolean paramBoolean) throws SQLException {
    if (!paramBoolean) {
      purgeImplicitCache();
    }
    this.implicitCacheEnabled = paramBoolean;
  }












  
  public boolean getImplicitCachingEnabled() throws SQLException {
    boolean bool;
    if (this.cacheSize == 0) {
      bool = false;
    } else {
      bool = this.implicitCacheEnabled;
    }  return bool;
  }













  
  public void setExplicitCachingEnabled(boolean paramBoolean) throws SQLException {
    if (!paramBoolean) {
      purgeExplicitCache();
    }
    this.explicitCacheEnabled = paramBoolean;
  }












  
  public boolean getExplicitCachingEnabled() throws SQLException {
    boolean bool;
    if (this.cacheSize == 0) {
      bool = false;
    } else {
      bool = this.explicitCacheEnabled;
    }  return bool;
  }


















  
  protected void addToImplicitCache(OraclePreparedStatement paramOraclePreparedStatement, String paramString, int paramInt1, int paramInt2) throws SQLException {
    if (!this.implicitCacheEnabled || this.cacheSize == 0 || paramOraclePreparedStatement.cacheState == 2) {
      return;
    }







    
    if (this.numElements == this.cacheSize) {
      purgeCacheEntry(this.applicationCacheEnd);
    }

    
    paramOraclePreparedStatement.enterImplicitCache();

    
    OracleStatementCacheEntry oracleStatementCacheEntry = new OracleStatementCacheEntry();
    
    oracleStatementCacheEntry.statement = paramOraclePreparedStatement;
    oracleStatementCacheEntry.onImplicit = true;
    
    oracleStatementCacheEntry.sql = paramString;
    oracleStatementCacheEntry.statementType = paramInt1;
    oracleStatementCacheEntry.scrollType = paramInt2;

    
    oracleStatementCacheEntry.applicationNext = this.applicationCacheStart;
    oracleStatementCacheEntry.applicationPrev = null;
    
    if (this.applicationCacheStart != null) {
      this.applicationCacheStart.applicationPrev = oracleStatementCacheEntry;
    }
    this.applicationCacheStart = oracleStatementCacheEntry;
    
    oracleStatementCacheEntry.implicitNext = this.implicitCacheStart;
    oracleStatementCacheEntry.implicitPrev = null;
    
    if (this.implicitCacheStart != null) {
      this.implicitCacheStart.implicitPrev = oracleStatementCacheEntry;
    }
    this.implicitCacheStart = oracleStatementCacheEntry;

    
    if (this.applicationCacheEnd == null) {
      this.applicationCacheEnd = oracleStatementCacheEntry;
    }

    
    this.numElements++;
  }














  
  protected void addToExplicitCache(OraclePreparedStatement paramOraclePreparedStatement, String paramString) throws SQLException {
    if (!this.explicitCacheEnabled || this.cacheSize == 0 || paramOraclePreparedStatement.cacheState == 2) {
      return;
    }





    
    if (this.numElements == this.cacheSize) {
      purgeCacheEntry(this.applicationCacheEnd);
    }

    
    paramOraclePreparedStatement.enterExplicitCache();

    
    OracleStatementCacheEntry oracleStatementCacheEntry = new OracleStatementCacheEntry();
    
    oracleStatementCacheEntry.statement = paramOraclePreparedStatement;
    oracleStatementCacheEntry.sql = paramString;
    oracleStatementCacheEntry.onImplicit = false;

    
    oracleStatementCacheEntry.applicationNext = this.applicationCacheStart;
    oracleStatementCacheEntry.applicationPrev = null;
    
    if (this.applicationCacheStart != null) {
      this.applicationCacheStart.applicationPrev = oracleStatementCacheEntry;
    }
    this.applicationCacheStart = oracleStatementCacheEntry;
    
    oracleStatementCacheEntry.explicitNext = this.explicitCacheStart;
    oracleStatementCacheEntry.explicitPrev = null;
    
    if (this.explicitCacheStart != null) {
      this.explicitCacheStart.explicitPrev = oracleStatementCacheEntry;
    }
    this.explicitCacheStart = oracleStatementCacheEntry;

    
    if (this.applicationCacheEnd == null) {
      this.applicationCacheEnd = oracleStatementCacheEntry;
    }

    
    this.numElements++;
  }



















  
  protected OracleStatement searchImplicitCache(String paramString, int paramInt1, int paramInt2) throws SQLException {
    if (!this.implicitCacheEnabled)
    {

      
      return null;
    }

    
    OracleStatementCacheEntry oracleStatementCacheEntry = null;
    
    for (oracleStatementCacheEntry = this.implicitCacheStart; oracleStatementCacheEntry != null; oracleStatementCacheEntry = oracleStatementCacheEntry.implicitNext) {
      
      if (oracleStatementCacheEntry.statementType == paramInt1 && oracleStatementCacheEntry.scrollType == paramInt2 && oracleStatementCacheEntry.sql.equals(paramString)) {
        break;
      }
    } 
    
    if (oracleStatementCacheEntry != null) {







      
      if (oracleStatementCacheEntry.applicationPrev != null) {
        oracleStatementCacheEntry.applicationPrev.applicationNext = oracleStatementCacheEntry.applicationNext;
      }
      if (oracleStatementCacheEntry.applicationNext != null) {
        oracleStatementCacheEntry.applicationNext.applicationPrev = oracleStatementCacheEntry.applicationPrev;
      }
      if (this.applicationCacheStart == oracleStatementCacheEntry) {
        this.applicationCacheStart = oracleStatementCacheEntry.applicationNext;
      }
      if (this.applicationCacheEnd == oracleStatementCacheEntry) {
        this.applicationCacheEnd = oracleStatementCacheEntry.applicationPrev;
      }
      if (oracleStatementCacheEntry.implicitPrev != null) {
        oracleStatementCacheEntry.implicitPrev.implicitNext = oracleStatementCacheEntry.implicitNext;
      }
      if (oracleStatementCacheEntry.implicitNext != null) {
        oracleStatementCacheEntry.implicitNext.implicitPrev = oracleStatementCacheEntry.implicitPrev;
      }
      if (this.implicitCacheStart == oracleStatementCacheEntry) {
        this.implicitCacheStart = oracleStatementCacheEntry.implicitNext;
      }

      
      this.numElements--;

      
      oracleStatementCacheEntry.statement.exitImplicitCacheToActive();


      
      return oracleStatementCacheEntry.statement;
    } 







    
    return null;
  }















  
  protected OracleStatement searchExplicitCache(String paramString) throws SQLException {
    if (!this.explicitCacheEnabled)
    {

      
      return null;
    }

    
    OracleStatementCacheEntry oracleStatementCacheEntry = null;
    
    for (oracleStatementCacheEntry = this.explicitCacheStart; oracleStatementCacheEntry != null; oracleStatementCacheEntry = oracleStatementCacheEntry.explicitNext) {
      
      if (oracleStatementCacheEntry.sql.equals(paramString)) {
        break;
      }
    } 
    if (oracleStatementCacheEntry != null) {








      
      if (oracleStatementCacheEntry.applicationPrev != null) {
        oracleStatementCacheEntry.applicationPrev.applicationNext = oracleStatementCacheEntry.applicationNext;
      }
      if (oracleStatementCacheEntry.applicationNext != null) {
        oracleStatementCacheEntry.applicationNext.applicationPrev = oracleStatementCacheEntry.applicationPrev;
      }
      if (this.applicationCacheStart == oracleStatementCacheEntry) {
        this.applicationCacheStart = oracleStatementCacheEntry.applicationNext;
      }
      if (this.applicationCacheEnd == oracleStatementCacheEntry) {
        this.applicationCacheEnd = oracleStatementCacheEntry.applicationPrev;
      }
      if (oracleStatementCacheEntry.explicitPrev != null) {
        oracleStatementCacheEntry.explicitPrev.explicitNext = oracleStatementCacheEntry.explicitNext;
      }
      if (oracleStatementCacheEntry.explicitNext != null) {
        oracleStatementCacheEntry.explicitNext.explicitPrev = oracleStatementCacheEntry.explicitPrev;
      }
      if (this.explicitCacheStart == oracleStatementCacheEntry) {
        this.explicitCacheStart = oracleStatementCacheEntry.explicitNext;
      }

      
      this.numElements--;

      
      oracleStatementCacheEntry.statement.exitExplicitCacheToActive();
      
      return oracleStatementCacheEntry.statement;
    } 





    
    return null;
  }












  
  protected void purgeImplicitCache() throws SQLException {
    for (OracleStatementCacheEntry oracleStatementCacheEntry = this.implicitCacheStart; oracleStatementCacheEntry != null; 
      oracleStatementCacheEntry = oracleStatementCacheEntry.implicitNext) {
      purgeCacheEntry(oracleStatementCacheEntry);
    }
    this.implicitCacheStart = null;
  }












  
  protected void purgeExplicitCache() throws SQLException {
    for (OracleStatementCacheEntry oracleStatementCacheEntry = this.explicitCacheStart; oracleStatementCacheEntry != null; 
      oracleStatementCacheEntry = oracleStatementCacheEntry.explicitNext) {
      purgeCacheEntry(oracleStatementCacheEntry);
    }
    this.explicitCacheStart = null;
  }














  
  private void purgeCacheEntry(OracleStatementCacheEntry paramOracleStatementCacheEntry) throws SQLException {
    if (paramOracleStatementCacheEntry.applicationNext != null) {
      paramOracleStatementCacheEntry.applicationNext.applicationPrev = paramOracleStatementCacheEntry.applicationPrev;
    }
    if (paramOracleStatementCacheEntry.applicationPrev != null) {
      paramOracleStatementCacheEntry.applicationPrev.applicationNext = paramOracleStatementCacheEntry.applicationNext;
    }
    if (this.applicationCacheStart == paramOracleStatementCacheEntry) {
      this.applicationCacheStart = paramOracleStatementCacheEntry.applicationNext;
    }
    if (this.applicationCacheEnd == paramOracleStatementCacheEntry) {
      this.applicationCacheEnd = paramOracleStatementCacheEntry.applicationPrev;
    }
    if (paramOracleStatementCacheEntry.onImplicit) {
      
      if (paramOracleStatementCacheEntry.implicitNext != null) {
        paramOracleStatementCacheEntry.implicitNext.implicitPrev = paramOracleStatementCacheEntry.implicitPrev;
      }
      if (paramOracleStatementCacheEntry.implicitPrev != null) {
        paramOracleStatementCacheEntry.implicitPrev.implicitNext = paramOracleStatementCacheEntry.implicitNext;
      }
      if (this.implicitCacheStart == paramOracleStatementCacheEntry) {
        this.implicitCacheStart = paramOracleStatementCacheEntry.implicitNext;
      }
    } else {
      
      if (paramOracleStatementCacheEntry.explicitNext != null) {
        paramOracleStatementCacheEntry.explicitNext.explicitPrev = paramOracleStatementCacheEntry.explicitPrev;
      }
      if (paramOracleStatementCacheEntry.explicitPrev != null) {
        paramOracleStatementCacheEntry.explicitPrev.explicitNext = paramOracleStatementCacheEntry.explicitNext;
      }
      if (this.explicitCacheStart == paramOracleStatementCacheEntry) {
        this.explicitCacheStart = paramOracleStatementCacheEntry.explicitNext;
      }
    } 
    
    this.numElements--;

    
    if (paramOracleStatementCacheEntry.onImplicit) {
      paramOracleStatementCacheEntry.statement.exitImplicitCacheToClose();
    } else {
      paramOracleStatementCacheEntry.statement.exitExplicitCacheToClose();
    } 
  }







  
  public int getCacheSize() {
    return this.cacheSize;
  }











  
  public void printCache(String paramString) throws SQLException {
    System.out.println("*** Start of Statement Cache Dump (" + paramString + ") ***");
    System.out.println("cache size: " + this.cacheSize + " num elements: " + this.numElements + " implicit enabled: " + this.implicitCacheEnabled + " explicit enabled: " + this.explicitCacheEnabled);


    
    System.out.println("applicationStart: " + this.applicationCacheStart + "  applicationEnd: " + this.applicationCacheEnd);
    
    OracleStatementCacheEntry oracleStatementCacheEntry;
    for (oracleStatementCacheEntry = this.applicationCacheStart; oracleStatementCacheEntry != null; oracleStatementCacheEntry = oracleStatementCacheEntry.applicationNext) {
      oracleStatementCacheEntry.print();
    }
    System.out.println("implicitStart: " + this.implicitCacheStart);
    
    for (oracleStatementCacheEntry = this.implicitCacheStart; oracleStatementCacheEntry != null; oracleStatementCacheEntry = oracleStatementCacheEntry.implicitNext) {
      oracleStatementCacheEntry.print();
    }
    System.out.println("explicitStart: " + this.explicitCacheStart);
    
    for (oracleStatementCacheEntry = this.explicitCacheStart; oracleStatementCacheEntry != null; oracleStatementCacheEntry = oracleStatementCacheEntry.explicitNext) {
      oracleStatementCacheEntry.print();
    }
    System.out.println("*** End of Statement Cache Dump (" + paramString + ") ***");
  }








  
  public void close() throws SQLException {
    OracleStatementCacheEntry oracleStatementCacheEntry = this.applicationCacheStart;
    for (; oracleStatementCacheEntry != null; oracleStatementCacheEntry = oracleStatementCacheEntry.applicationNext) {


      
      if (oracleStatementCacheEntry.onImplicit) {
        oracleStatementCacheEntry.statement.exitImplicitCacheToClose();
      } else {
        oracleStatementCacheEntry.statement.exitExplicitCacheToClose();
      } 
    } 


    
    this.applicationCacheStart = null;
    this.applicationCacheEnd = null;
    this.implicitCacheStart = null;
    this.explicitCacheStart = null;
    this.numElements = 0;
  }











  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
