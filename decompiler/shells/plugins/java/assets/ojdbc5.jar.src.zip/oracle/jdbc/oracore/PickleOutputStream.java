package oracle.jdbc.oracore;

import java.io.ByteArrayOutputStream;
















public class PickleOutputStream
  extends ByteArrayOutputStream
{
  public PickleOutputStream() {}
  
  public PickleOutputStream(int paramInt) {
    super(paramInt);
  }




  
  public synchronized int offset() {
    return this.count;
  }





  
  public synchronized void overwrite(int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int paramInt3) {
    if (paramInt2 < 0 || paramInt2 > paramArrayOfbyte.length || paramInt3 < 0 || paramInt2 + paramInt3 > paramArrayOfbyte.length || paramInt2 + paramInt3 < 0 || paramInt1 + paramInt3 > this.buf.length)
    {
      
      throw new IndexOutOfBoundsException();
    }
    if (paramInt3 == 0) {
      return;
    }

    
    for (byte b = 0; b < paramInt3; b++)
    {
      this.buf[paramInt1 + b] = paramArrayOfbyte[paramInt2 + b];
    }
  }


















  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
