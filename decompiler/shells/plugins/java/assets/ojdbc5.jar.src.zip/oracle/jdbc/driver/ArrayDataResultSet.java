package oracle.jdbc.driver;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;
import oracle.jdbc.OracleDataFactory;
import oracle.jdbc.OracleResultSet;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.ARRAY;
import oracle.sql.BFILE;
import oracle.sql.BLOB;
import oracle.sql.CHAR;
import oracle.sql.CLOB;
import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import oracle.sql.DATE;
import oracle.sql.Datum;
import oracle.sql.INTERVALDS;
import oracle.sql.INTERVALYM;
import oracle.sql.NUMBER;
import oracle.sql.OPAQUE;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.RAW;
import oracle.sql.REF;
import oracle.sql.ROWID;
import oracle.sql.STRUCT;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;

class ArrayDataResultSet extends BaseResultSet {
  Datum[] data;
  Map map;
  private int currentIndex;
  private int lastIndex;
  
  public ArrayDataResultSet(OracleConnection paramOracleConnection, Datum[] paramArrayOfDatum, Map paramMap) throws SQLException {
    this.connection = (PhysicalConnection)paramOracleConnection;
    this.data = paramArrayOfDatum;
    this.map = paramMap;
    this.currentIndex = 0;
    this.lastIndex = (this.data == null) ? 0 : this.data.length;
    this.fetchSize = OracleConnection.DEFAULT_ROW_PREFETCH;
  }


  
  PhysicalConnection connection;

  
  private Boolean wasNull;

  
  private int fetchSize;

  
  ARRAY array;

  
  public ArrayDataResultSet(OracleConnection paramOracleConnection, Datum[] paramArrayOfDatum, long paramLong, int paramInt, Map paramMap) throws SQLException {
    this.connection = (PhysicalConnection)paramOracleConnection;
    this.data = paramArrayOfDatum;
    this.map = paramMap;
    this.currentIndex = (int)paramLong - 1;
    
    byte b = (this.data == null) ? 0 : this.data.length;
    
    this.lastIndex = this.currentIndex + Math.min(b - this.currentIndex, paramInt);
    
    this.fetchSize = OracleConnection.DEFAULT_ROW_PREFETCH;
  }





  
  public ArrayDataResultSet(OracleConnection paramOracleConnection, ARRAY paramARRAY, long paramLong, int paramInt, Map paramMap) throws SQLException {
    this.connection = (PhysicalConnection)paramOracleConnection;
    this.array = paramARRAY;
    this.map = paramMap;
    this.currentIndex = (int)paramLong - 1;
    
    byte b = (this.array == null) ? 0 : paramARRAY.length();
    
    this.lastIndex = this.currentIndex + ((paramInt == -1) ? (b - this.currentIndex) : Math.min(b - this.currentIndex, paramInt));

    
    this.fetchSize = OracleConnection.DEFAULT_ROW_PREFETCH;
  }




  
  public boolean next() throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "next");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    this.currentIndex++;
    
    return (this.currentIndex <= this.lastIndex);
  }


  
  public void close() throws SQLException {
    synchronized (this.connection) {
      
      super.close();
    } 
  }


  
  public boolean wasNull() throws SQLException {
    synchronized (this.connection) {

      
      if (this.wasNull == null) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 24, (Object)null);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      return this.wasNull.booleanValue();
    } 
  }


  
  public String getString(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        return datum.stringValue();
      }
      return null;
    } 
  }


  
  public ResultSet getCursor(int paramInt) throws SQLException {
    synchronized (this.connection) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCursor");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }






  
  public Datum getOracleObject(int paramInt) throws SQLException {
    if (this.currentIndex <= 0) {
      
      SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14, (Object)null);
      sQLException1.fillInStackTrace();
      throw sQLException1;
    } 
    
    if (paramInt == 1) {
      
      this.wasNull = Boolean.FALSE;
      
      return (Datum)new NUMBER(this.currentIndex);
    } 
    if (paramInt == 2) {
      
      if (this.data != null) {
        
        this.wasNull = (this.data[this.currentIndex - 1] == null) ? Boolean.TRUE : Boolean.FALSE;

        
        return this.data[this.currentIndex - 1];
      } 
      if (this.array != null) {


        
        Datum[] arrayOfDatum = this.array.getOracleArray(this.currentIndex, 1);
        
        if (arrayOfDatum != null && arrayOfDatum.length >= 1) {
          
          this.wasNull = (arrayOfDatum[0] == null) ? Boolean.TRUE : Boolean.FALSE;
          
          return arrayOfDatum[0];
        } 
      } 

      
      SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Out of sync");
      sQLException1.fillInStackTrace();
      throw sQLException1;
    } 


    
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3, (Object)null);
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public ROWID getROWID(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof ROWID) {
          return (ROWID)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getROWID");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }


  
  public NUMBER getNUMBER(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof NUMBER) {
          return (NUMBER)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getNUMBER");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }


  
  public DATE getDATE(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof DATE) {
          return (DATE)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getDATE");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }


  
  public ARRAY getARRAY(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof ARRAY) {
          return (ARRAY)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getARRAY");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }


  
  public STRUCT getSTRUCT(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof STRUCT) {
          return (STRUCT)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getSTRUCT");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }


  
  public OPAQUE getOPAQUE(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof OPAQUE) {
          return (OPAQUE)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getOPAQUE");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }


  
  public REF getREF(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof REF) {
          return (REF)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getREF");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }


  
  public CHAR getCHAR(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof CHAR) {
          return (CHAR)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCHAR");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }


  
  public RAW getRAW(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof RAW) {
          return (RAW)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getRAW");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }


  
  public BLOB getBLOB(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof BLOB) {
          return (BLOB)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBLOB");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }


  
  public CLOB getCLOB(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof CLOB) {
          return (CLOB)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCLOB");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }


  
  public BFILE getBFILE(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof BFILE) {
          return (BFILE)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBFILE");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }


  
  public INTERVALDS getINTERVALDS(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof INTERVALDS) {
          return (INTERVALDS)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }


  
  public INTERVALYM getINTERVALYM(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof INTERVALYM) {
          return (INTERVALYM)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }



  
  public BFILE getBfile(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      return getBFILE(paramInt);
    } 
  }


  
  public TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof TIMESTAMP) {
          return (TIMESTAMP)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMP");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }


  
  public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof TIMESTAMPTZ) {
          return (TIMESTAMPTZ)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPTZ");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }


  
  public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof TIMESTAMPLTZ) {
          return (TIMESTAMPLTZ)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPLTZ");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }


  
  public boolean getBoolean(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        return datum.booleanValue();
      }
      return false;
    } 
  }




  
  public OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(int paramInt) throws SQLException {
    return null;
  }


  
  public byte getByte(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        return datum.byteValue();
      }
      return 0;
    } 
  }


  
  public short getShort(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      long l = getLong(paramInt);
      
      if (l > 65537L || l < -65538L) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 26, "getShort");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      return (short)(int)l;
    } 
  }


  
  public int getInt(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null)
      {
        return datum.intValue();
      }
      
      return 0;
    } 
  }


  
  public long getLong(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null)
      {
        return datum.longValue();
      }
      
      return 0L;
    } 
  }


  
  public float getFloat(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null)
      {
        return datum.floatValue();
      }
      
      return 0.0F;
    } 
  }


  
  public double getDouble(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null)
      {
        return datum.doubleValue();
      }
      
      return 0.0D;
    } 
  }



  
  public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt1);
      
      if (datum != null)
      {
        return datum.bigDecimalValue();
      }
      
      return null;
    } 
  }


  
  public byte[] getBytes(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof RAW) {
          return ((RAW)datum).shareBytes();
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBytes");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }


  
  public Date getDate(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null)
      {
        return datum.dateValue();
      }
      
      return null;
    } 
  }


  
  public Time getTime(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null)
      {
        return datum.timeValue();
      }
      
      return null;
    } 
  }



  
  public Timestamp getTimestamp(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null)
      {
        return datum.timestampValue();
      }
      
      return null;
    } 
  }



  
  public InputStream getAsciiStream(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null)
      {
        datum.asciiStreamValue();
      }
      
      return null;
    } 
  }



  
  public InputStream getUnicodeStream(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        DBConversion dBConversion = this.connection.conversion;
        byte[] arrayOfByte = datum.shareBytes();
        
        if (datum instanceof RAW)
        {
          return dBConversion.ConvertStream(new ByteArrayInputStream(arrayOfByte), 3);
        }
        if (datum instanceof CHAR)
        {
          return dBConversion.ConvertStream(new ByteArrayInputStream(arrayOfByte), 1);
        }

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getUnicodeStream");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }



  
  public InputStream getBinaryStream(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null)
      {
        return datum.binaryStreamValue();
      }
      
      return null;
    } 
  }



  
  public Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory) throws SQLException {
    synchronized (this.connection) {
      
      Object object = getObject(paramInt);
      return paramOracleDataFactory.create(object, 0);
    } 
  }


  
  public Object getObject(int paramInt) throws SQLException {
    synchronized (this.connection) {


      
      return getObject(paramInt, this.map);
    } 
  }






  
  public CustomDatum getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);



      
      return paramCustomDatumFactory.create(datum, 0);
    } 
  }



  
  public ORAData getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);



      
      return paramORADataFactory.create(datum, 0);
    } 
  }





  
  public ResultSetMetaData getMetaData() throws SQLException {
    synchronized (this.connection) {

      
      if (this.closed) {
        
        SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getMetaData");
        sQLException1.fillInStackTrace();
        throw sQLException1;
      } 



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "getMetaData");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }




  
  public int findColumn(String paramString) throws SQLException {
    synchronized (this.connection) {

      
      if (paramString.equalsIgnoreCase("index"))
        return 1; 
      if (paramString.equalsIgnoreCase("value")) {
        return 2;
      }
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6, "get_column_index");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }










  
  public Statement getStatement() throws SQLException {
    return null;
  }



  
  public Object getObject(int paramInt, Map paramMap) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof STRUCT) {
          return ((STRUCT)datum).toJdbc(paramMap);
        }
        return datum.toJdbc();
      } 
      
      return null;
    } 
  }


  
  public Ref getRef(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      return (Ref)getREF(paramInt);
    } 
  }


  
  public Blob getBlob(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      return (Blob)getBLOB(paramInt);
    } 
  }


  
  public Clob getClob(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      return (Clob)getCLOB(paramInt);
    } 
  }



  
  public Array getArray(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      return (Array)getARRAY(paramInt);
    } 
  }










  
  public Reader getCharacterStream(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null)
      {
        return datum.characterStreamValue();
      }
      
      return null;
    } 
  }



  
  public BigDecimal getBigDecimal(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null)
      {
        return datum.bigDecimalValue();
      }
      
      return null;
    } 
  }



  
  public Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        DATE dATE = null;
        
        if (datum instanceof DATE) {
          dATE = (DATE)datum;
        } else {
          dATE = new DATE(datum.stringValue());
        } 
        if (dATE != null) {
          return dATE.dateValue(paramCalendar);
        }
      } 
      return null;
    } 
  }



  
  public Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        DATE dATE = null;
        
        if (datum instanceof DATE) {
          dATE = (DATE)datum;
        } else {
          dATE = new DATE(datum.stringValue());
        } 
        if (dATE != null) {
          return dATE.timeValue(paramCalendar);
        }
      } 
      return null;
    } 
  }



  
  public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        DATE dATE = null;
        
        if (datum instanceof DATE) {
          dATE = (DATE)datum;
        } else {
          dATE = new DATE(datum.stringValue());
        } 
        if (dATE != null) {
          return dATE.timestampValue(paramCalendar);
        }
      } 
      return null;
    } 
  }




  
  public URL getURL(int paramInt) throws SQLException {
    synchronized (this.connection) {



































      
      SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }



  
  public String getCursorName() throws SQLException {
    synchronized (this.connection) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "getCursorName");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }














  
  public boolean isBeforeFirst() throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    return (this.currentIndex < 1);
  }




  
  public boolean isAfterLast() throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    return (this.currentIndex > this.lastIndex);
  }




  
  public boolean isFirst() throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    return (this.currentIndex == 1);
  }




  
  public boolean isLast() throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    return (this.currentIndex == this.lastIndex);
  }




  
  public int getRow() throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    return this.currentIndex;
  }








  
  public void setFetchSize(int paramInt) throws SQLException {
    if (paramInt < 0) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    if (paramInt == 0) {
      this.fetchSize = OracleConnection.DEFAULT_ROW_PREFETCH;
    } else {
      this.fetchSize = paramInt;
    } 
  }


  
  public int getFetchSize() throws SQLException {
    return this.fetchSize;
  }











  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return this.connection;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
