package oracle.jdbc.internal;

import oracle.jdbc.OracleResultSetCache;

public interface OracleResultSetCache extends OracleResultSetCache {}
