package oracle.jdbc.internal;

import java.sql.SQLException;
import oracle.jdbc.OracleStatement;







































































































public interface OracleStatement
  extends OracleStatement
{
  public static final int DEFAULT_RSET_TYPE = 1;
  public static final int CLOSED = 0;
  public static final int ACTIVE = 1;
  public static final int CACHED = 2;
  public static final int NON_CACHED = 3;
  
  void setFixedString(boolean paramBoolean);
  
  boolean getFixedString();
  
  int sendBatch() throws SQLException;
  
  boolean getserverCursor();
  
  int getcacheState();
  
  int getstatementType();
  
  SqlKind getSqlKind() throws SQLException;
  
  long getChecksum() throws SQLException;
  
  void setSnapshotSCN(long paramLong) throws SQLException;
  
  public enum SqlKind
  {
    SELECT(false, false, true, false),
    DELETE(false, true, false, false),
    INSERT(false, true, false, false),
    MERGE(false, true, false, false),
    UPDATE(false, true, false, false),
    PLSQL_BLOCK(true, false, false, false),
    CALL_BLOCK(true, false, false, false),
    SELECT_FOR_UPDATE(false, false, true, false),
    ALTER_SESSION(false, false, false, true),
    OTHER(false, false, false, true),
    UNINITIALIZED(false, false, false, false);
    
    private final boolean dml;
    
    private final boolean plsqlOrCall;
    
    private final boolean select;
    
    private final boolean other;

    
    SqlKind(boolean param1Boolean1, boolean param1Boolean2, boolean param1Boolean3, boolean param1Boolean4) {
      this.dml = param1Boolean2;
      this.plsqlOrCall = param1Boolean1;
      this.select = param1Boolean3;
      this.other = param1Boolean4;
    }
    
    public boolean isPlsqlOrCall() { return this.plsqlOrCall; }
    public boolean isDML() { return this.dml; }
    public boolean isSELECT() { return this.select; } public boolean isOTHER() {
      return this.other;
    }
  }
}
