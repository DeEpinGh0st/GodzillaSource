package oracle.jdbc.oracore;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.StringWriter;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Vector;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.AttributeDescriptor;
import oracle.sql.BLOB;
import oracle.sql.Datum;
import oracle.sql.JAVA_STRUCT;
import oracle.sql.NUMBER;
import oracle.sql.SQLName;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;
import oracle.sql.TypeDescriptor;
















public class OracleTypeADT
  extends OracleNamedType
  implements Serializable
{
  static final long serialVersionUID = 3031304012507165702L;
  static final int S_TOP = 1;
  static final int S_EMBEDDED = 2;
  static final int S_UPT_ADT = 4;
  static final int S_JAVA_OBJECT = 16;
  static final int S_FINAL_TYPE = 32;
  static final int S_SUB_TYPE = 64;
  static final int S_ATTR_TDS = 128;
  static final int S_HAS_METADATA = 256;
  static final int S_TDS_PARSED = 512;
  private int statusBits = 1;





  
  int tdsVersion = -9999;
  
  static final int KOPT_V80 = 1;
  
  static final int KOPT_V81 = 2;
  
  static final int KOPT_VNFT = 3;
  
  static final int KOPT_VERSION = 3;
  
  boolean endOfAdt = false;
  
  int typeVersion = 1;

  
  long fixedDataSize = -1L;
  int alignmentRequirement = -1;

  
  OracleType[] attrTypes = null;
  
  String[] attrNames;
  String[] attrTypeNames;
  public long tdoCState = 0L;
  
  byte[] toid = null;
  
  int charSetId;
  
  int charSetForm;
  
  int flattenedAttrNum;
  
  transient int opcode;
  transient int idx = 1;
  
  boolean isTransient = false;
  
  static final int CURRENT_USER_OBJECT = 0;
  
  static final int CURRENT_USER_SYNONYM = 1;
  
  static final int CURRENT_USER_SYNONYM_10g = 2;
  
  static final int CURRENT_USER_PUBLIC_SYNONYM = 3;
  
  static final int CURRENT_USER_PUBLIC_SYNONYM_10g = 4;
  
  static final int POSSIBLY_OTHER_USER_OBJECT = 5;
  
  static final int POSSIBLY_OTHER_USER_OBJECT_10g = 6;
  
  static final int OTHER_USER_OBJECT = 7;
  
  static final int OTHER_USER_SYNONYM = 8;
  
  static final int PUBLIC_SYNONYM = 9;
  static final int PUBLIC_SYNONYM_10g = 10;
  static final int BREAK = 11;
  
  public OracleTypeADT(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, short paramShort, String paramString) throws SQLException {
    this(paramString, (Connection)null);
    
    this.toid = paramArrayOfbyte;
    this.typeVersion = paramInt1;
    this.charSetId = paramInt2;
    this.charSetForm = paramShort;
  }




  
  public OracleTypeADT(String paramString, Connection paramConnection) throws SQLException
  {
    super(paramString, (OracleConnection)paramConnection);
























































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































    
    this.numberOfLocalAttributes = -1;




































    
    this.LOCAL_TYPE = 0;
    this.LOOK_FOR_USER_SYNONYM = 1;
    this.LOOK_FOR_PUBLIC_SYNONYM = 2;
    this.initMetaData1_9_0_SQL = new String[] { "SELECT INSTANTIABLE, supertype_owner, supertype_name, LOCAL_ATTRIBUTES FROM all_types WHERE type_name = :1 AND owner = :2 ", "DECLARE \n bind_synonym_name user_synonyms.synonym_name%type := :1; \n the_table_owner  user_synonyms.table_owner%type; \n the_table_name   user_synonyms.table_name%type; \n the_db_link      user_synonyms.db_link%type; \n sql_string       VARCHAR2(1000); \nBEGIN \n   SELECT TABLE_NAME, TABLE_OWNER, DB_LINK INTO  \n         the_table_name, the_table_owner, the_db_link \n         FROM USER_SYNONYMS WHERE \n         SYNONYM_NAME = bind_synonym_name; \n \n   sql_string := 'SELECT INSTANTIABLE, SUPERTYPE_OWNER,      SUPERTYPE_NAME, LOCAL_ATTRIBUTES FROM ALL_TYPES'; \n \n   IF the_db_link IS NOT NULL  \n   THEN \n     sql_string := sql_string || '@' || the_db_link; \n   END IF; \n   sql_string := sql_string       || ' WHERE TYPE_NAME = '''       || the_table_name   || ''' AND OWNER = '''       || the_table_owner  || ''''; \n   OPEN :2 FOR sql_string; \nEND;", "DECLARE \n bind_synonym_name user_synonyms.synonym_name%type := :1; \n the_table_owner  user_synonyms.table_owner%type; \n the_table_name   user_synonyms.table_name%type; \n the_db_link      user_synonyms.db_link%type; \n sql_string       VARCHAR2(1000); \nBEGIN \n   SELECT TABLE_NAME, TABLE_OWNER, DB_LINK INTO  \n         the_table_name, the_table_owner, the_db_link \n         FROM ALL_SYNONYMS WHERE \n         OWNER = 'PUBLIC' AND \n         SYNONYM_NAME = bind_synonym_name; \n \n   sql_string := 'SELECT INSTANTIABLE, SUPERTYPE_OWNER,      SUPERTYPE_NAME, LOCAL_ATTRIBUTES FROM ALL_TYPES'; \n \n   IF the_db_link IS NOT NULL  \n   THEN \n     sql_string := sql_string || '@' || the_db_link; \n   END IF; \n   sql_string := sql_string       || ' WHERE TYPE_NAME = '''       || the_table_name   || ''' AND OWNER = '''       || the_table_owner  || ''''; \n   OPEN :2 FOR sql_string; \nEND;" }; } public OracleTypeADT(OracleTypeADT paramOracleTypeADT, int paramInt, Connection paramConnection) throws SQLException { super(paramOracleTypeADT, paramInt, (OracleConnection)paramConnection); this.numberOfLocalAttributes = -1; this.LOCAL_TYPE = 0; this.LOOK_FOR_USER_SYNONYM = 1; this.LOOK_FOR_PUBLIC_SYNONYM = 2; this.initMetaData1_9_0_SQL = new String[] { "SELECT INSTANTIABLE, supertype_owner, supertype_name, LOCAL_ATTRIBUTES FROM all_types WHERE type_name = :1 AND owner = :2 ", "DECLARE \n bind_synonym_name user_synonyms.synonym_name%type := :1; \n the_table_owner  user_synonyms.table_owner%type; \n the_table_name   user_synonyms.table_name%type; \n the_db_link      user_synonyms.db_link%type; \n sql_string       VARCHAR2(1000); \nBEGIN \n   SELECT TABLE_NAME, TABLE_OWNER, DB_LINK INTO  \n         the_table_name, the_table_owner, the_db_link \n         FROM USER_SYNONYMS WHERE \n         SYNONYM_NAME = bind_synonym_name; \n \n   sql_string := 'SELECT INSTANTIABLE, SUPERTYPE_OWNER,      SUPERTYPE_NAME, LOCAL_ATTRIBUTES FROM ALL_TYPES'; \n \n   IF the_db_link IS NOT NULL  \n   THEN \n     sql_string := sql_string || '@' || the_db_link; \n   END IF; \n   sql_string := sql_string       || ' WHERE TYPE_NAME = '''       || the_table_name   || ''' AND OWNER = '''       || the_table_owner  || ''''; \n   OPEN :2 FOR sql_string; \nEND;", "DECLARE \n bind_synonym_name user_synonyms.synonym_name%type := :1; \n the_table_owner  user_synonyms.table_owner%type; \n the_table_name   user_synonyms.table_name%type; \n the_db_link      user_synonyms.db_link%type; \n sql_string       VARCHAR2(1000); \nBEGIN \n   SELECT TABLE_NAME, TABLE_OWNER, DB_LINK INTO  \n         the_table_name, the_table_owner, the_db_link \n         FROM ALL_SYNONYMS WHERE \n         OWNER = 'PUBLIC' AND \n         SYNONYM_NAME = bind_synonym_name; \n \n   sql_string := 'SELECT INSTANTIABLE, SUPERTYPE_OWNER,      SUPERTYPE_NAME, LOCAL_ATTRIBUTES FROM ALL_TYPES'; \n \n   IF the_db_link IS NOT NULL  \n   THEN \n     sql_string := sql_string || '@' || the_db_link; \n   END IF; \n   sql_string := sql_string       || ' WHERE TYPE_NAME = '''       || the_table_name   || ''' AND OWNER = '''       || the_table_owner  || ''''; \n   OPEN :2 FOR sql_string; \nEND;" }; } public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection) throws SQLException { if (paramObject != null) { if (paramObject instanceof STRUCT) return (Datum)paramObject;  if (paramObject instanceof java.sql.SQLData || paramObject instanceof oracle.jdbc.internal.ObjectData) return (Datum)STRUCT.toSTRUCT(paramObject, (OracleConnection)paramOracleConnection);  if (paramObject instanceof Object[]) { StructDescriptor structDescriptor = createStructDescriptor(); return (Datum)createObjSTRUCT(structDescriptor, (Object[])paramObject); }  SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject); sQLException.fillInStackTrace(); throw sQLException; }  return null; } public Datum[] toDatumArray(Object paramObject, OracleConnection paramOracleConnection, long paramLong, int paramInt) throws SQLException { Datum[] arrayOfDatum = null; if (paramObject != null) if (paramObject instanceof Object[]) { Object[] arrayOfObject = (Object[])paramObject; int i = (int)((paramInt == -1) ? arrayOfObject.length : Math.min(arrayOfObject.length - paramLong + 1L, paramInt)); arrayOfDatum = new Datum[i]; for (byte b = 0; b < i; b++) arrayOfDatum[b] = toDatum(arrayOfObject[(int)paramLong + b - 1], paramOracleConnection);  } else { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject); sQLException.fillInStackTrace(); throw sQLException; }   return arrayOfDatum; } public int getTypeCode() throws SQLException { if ((getStatus() & 0x10) != 0) return 2008;  return 2002; } public OracleType[] getAttrTypes() throws SQLException { if (this.attrTypes == null) init(this.connection);  return this.attrTypes; } public boolean isInHierarchyOf(OracleType paramOracleType) throws SQLException { if (paramOracleType == null) return false;  if (!paramOracleType.isObjectType()) return false;  StructDescriptor structDescriptor = (StructDescriptor)paramOracleType.getTypeDescriptor(); return this.descriptor.isInHierarchyOf(structDescriptor.getName()); } public boolean isInHierarchyOf(StructDescriptor paramStructDescriptor) throws SQLException { if (paramStructDescriptor == null) return false;  return this.descriptor.isInHierarchyOf(paramStructDescriptor.getName()); } public boolean isObjectType() { return true; } public TypeDescriptor getTypeDescriptor() { return this.descriptor; } public void init(OracleConnection paramOracleConnection) throws SQLException { synchronized (paramOracleConnection) { byte[] arrayOfByte = initMetadata(paramOracleConnection); init(arrayOfByte, paramOracleConnection); }  } public void init(byte[] paramArrayOfbyte, OracleConnection paramOracleConnection) throws SQLException { synchronized (paramOracleConnection) { this.statusBits = 1; this.connection = paramOracleConnection; if (paramArrayOfbyte != null) parseTDS(paramArrayOfbyte, 0L);  setStatusBits(256); }  } public byte[] initMetadata(OracleConnection paramOracleConnection) throws SQLException { synchronized (this.connection) { byte[] arrayOfByte = null; if ((this.statusBits & 0x100) != 0) return null;  if (this.sqlName == null) getFullName();  if ((this.statusBits & 0x100) == 0) { CallableStatement callableStatement = null; try { if (this.tdoCState == 0L) this.tdoCState = this.connection.getTdoCState(this.sqlName.getSchema(), this.sqlName.getSimpleName());  String str = "begin :1 := dbms_pickler.get_type_shape(:2,:3,:4,:5,:6,:7); end;"; boolean bool = false; callableStatement = this.connection.prepareCall(str); callableStatement.registerOutParameter(1, 2); callableStatement.registerOutParameter(4, -3, 16); callableStatement.registerOutParameter(5, 4); callableStatement.registerOutParameter(6, -4); callableStatement.registerOutParameter(7, -4); callableStatement.setString(2, this.sqlName.getSchema()); callableStatement.setString(3, this.sqlName.getSimpleName()); callableStatement.execute(); int i = callableStatement.getInt(1); if (i != 0) { if (i != 24331) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 74, this.sqlName.toString()); sQLException.fillInStackTrace(); throw sQLException; }  if (i == 24331) { bool = true; callableStatement.registerOutParameter(6, 2004); callableStatement.execute(); i = callableStatement.getInt(1); if (i != 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 74, this.sqlName.toString()); sQLException.fillInStackTrace(); throw sQLException; }  }  }  this.toid = callableStatement.getBytes(4); this.typeVersion = NUMBER.toInt(callableStatement.getBytes(5)); if (!bool) { arrayOfByte = callableStatement.getBytes(6); } else { try { Blob blob = ((OracleCallableStatement)callableStatement).getBlob(6); InputStream inputStream = blob.getBinaryStream(); arrayOfByte = new byte[(int)blob.length()]; inputStream.read(arrayOfByte); inputStream.close(); ((BLOB)blob).freeTemporary(); } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  }  this.metaDataInitialized = true; this.flattenedAttrNum = Util.getUnsignedByte(arrayOfByte[8]) * 256 + Util.getUnsignedByte(arrayOfByte[9]); callableStatement.getBytes(7); } finally { if (callableStatement != null) callableStatement.close();  }  }  setStatusBits(256); return arrayOfByte; }  } TDSReader parseTDS(byte[] paramArrayOfbyte, long paramLong) throws SQLException { if (this.attrTypes != null) return null;  TDSReader tDSReader = new TDSReader(paramArrayOfbyte, paramLong); long l1 = tDSReader.readLong() + tDSReader.offset(); tDSReader.checkNextByte((byte)38); this.tdsVersion = tDSReader.readByte(); tDSReader.skipBytes(2); this.flattenedAttrNum = tDSReader.readUB2(); if ((tDSReader.readByte() & 0xFF) == 255) setStatusBits(128);  long l2 = tDSReader.offset(); tDSReader.checkNextByte((byte)41); if (tDSReader.readUB2() != 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 47, "parseTDS"); sQLException.fillInStackTrace(); throw sQLException; }  long l3 = tDSReader.readLong(); parseTDSrec(tDSReader); if (this.tdsVersion >= 3) { tDSReader.skip_to(l2 + l3 + 2L); tDSReader.skipBytes(2 * this.flattenedAttrNum); byte b = tDSReader.readByte(); if (tDSReader.isJavaObject(this.tdsVersion, b)) setStatusBits(16);  if (tDSReader.isFinalType(this.tdsVersion, b)) setStatusBits(32);  if (tDSReader.readByte() != 1) setStatusBits(64);  } else { setStatusBits(32); }  tDSReader.skip_to(l1); return tDSReader; } public void parseTDSrec(TDSReader paramTDSReader) throws SQLException { Vector<OracleType> vector = new Vector(5); OracleType oracleType = null; this.idx = 1; while ((oracleType = getNextTypeObject(paramTDSReader)) != null) vector.addElement(oracleType);  if (this.opcode == 42) { this.endOfAdt = true; applyTDSpatches(paramTDSReader); }  this.attrTypes = new OracleType[vector.size()]; vector.copyInto((Object[])this.attrTypes); } private void applyTDSpatches(TDSReader paramTDSReader) throws SQLException { TDSPatch tDSPatch = paramTDSReader.getNextPatch(); while (tDSPatch != null) { paramTDSReader.moveToPatchPos(tDSPatch); int i = tDSPatch.getType(); if (i == 0) { OracleNamedType oracleNamedType; SQLException sQLException; OracleTypeADT oracleTypeADT; TDSReader tDSReader; paramTDSReader.readByte(); byte b = tDSPatch.getUptTypeCode(); switch (b) { case -6: paramTDSReader.readLong();case -5: oracleNamedType = tDSPatch.getOwner(); oracleTypeADT = null; if (oracleNamedType.hasName()) { oracleTypeADT = new OracleTypeADT(oracleNamedType.getFullName(), (Connection)this.connection); } else { oracleTypeADT = new OracleTypeADT(oracleNamedType.getParent(), oracleNamedType.getOrder(), (Connection)this.connection); }  oracleTypeADT.setUptADT(); tDSReader = oracleTypeADT.parseTDS(paramTDSReader.tds(), paramTDSReader.absoluteOffset()); paramTDSReader.skipBytes((int)tDSReader.offset()); tDSPatch.apply(oracleTypeADT.cleanup()); break;case 58: oracleNamedType = tDSPatch.getOwner(); oracleTypeADT = null; if (oracleNamedType.hasName()) { oracleTypeADT = new OracleTypeOPAQUE(oracleNamedType.getFullName(), this.connection); } else { oracleTypeADT = new OracleTypeOPAQUE(oracleNamedType.getParent(), oracleNamedType.getOrder(), this.connection); }  oracleTypeADT.parseTDSrec(paramTDSReader); tDSPatch.apply(oracleTypeADT); break;default: sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1); sQLException.fillInStackTrace(); throw sQLException; }  } else if (i == 1) { OracleType oracleType = getNextTypeObject(paramTDSReader); tDSPatch.apply(oracleType, this.opcode); } else { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 47, "parseTDS"); sQLException.fillInStackTrace(); throw sQLException; }  tDSPatch = paramTDSReader.getNextPatch(); }  } public OracleNamedType cleanup() { synchronized (this.connection) { if (this.attrTypes.length == 1 && this.attrTypes[0] instanceof OracleTypeCOLLECTION) { OracleTypeCOLLECTION oracleTypeCOLLECTION = (OracleTypeCOLLECTION)this.attrTypes[0]; oracleTypeCOLLECTION.copy_properties(this); return oracleTypeCOLLECTION; }  if (this.attrTypes.length == 1 && (this.statusBits & 0x80) != 0 && this.attrTypes[0] instanceof OracleTypeUPT && ((OracleTypeUPT)this.attrTypes[0]).realType instanceof OracleTypeOPAQUE) { OracleTypeOPAQUE oracleTypeOPAQUE = (OracleTypeOPAQUE)((OracleTypeUPT)this.attrTypes[0]).realType; oracleTypeOPAQUE.copy_properties(this); return oracleTypeOPAQUE; }  return this; }  } void copy_properties(OracleTypeADT paramOracleTypeADT) { this.sqlName = paramOracleTypeADT.sqlName; this.parent = paramOracleTypeADT.parent; this.idx = paramOracleTypeADT.idx; this.connection = paramOracleTypeADT.connection; this.toid = paramOracleTypeADT.toid; this.tdsVersion = paramOracleTypeADT.tdsVersion; this.typeVersion = paramOracleTypeADT.typeVersion; this.tdoCState = paramOracleTypeADT.tdoCState; this.endOfAdt = paramOracleTypeADT.endOfAdt; } OracleType getNextTypeObject(TDSReader paramTDSReader) throws SQLException { OracleTypeDATE oracleTypeDATE; OracleTypeCHAR oracleTypeCHAR; OracleTypeADT oracleTypeADT; OracleTypeNUMBER oracleTypeNUMBER; OracleTypeFLOAT oracleTypeFLOAT; OracleTypeBINARY_FLOAT oracleTypeBINARY_FLOAT; OracleTypeBINARY_DOUBLE oracleTypeBINARY_DOUBLE; OracleTypeSINT32 oracleTypeSINT32; OracleTypeREF oracleTypeREF; OracleTypeBFILE oracleTypeBFILE; OracleTypeRAW oracleTypeRAW; OracleTypeCLOB oracleTypeCLOB; OracleTypeBLOB oracleTypeBLOB; OracleTypeTIMESTAMP oracleTypeTIMESTAMP; OracleTypeTIMESTAMPTZ oracleTypeTIMESTAMPTZ; OracleTypeTIMESTAMPLTZ oracleTypeTIMESTAMPLTZ; OracleTypeINTERVAL oracleTypeINTERVAL; OracleTypeCOLLECTION oracleTypeCOLLECTION; while (true) { this.opcode = paramTDSReader.readByte(); if (this.opcode == 43) continue;  if (this.opcode == 44) { byte b = paramTDSReader.readByte(); if (paramTDSReader.isJavaObject(3, b)) setStatusBits(16);  continue; }  break; }  switch (this.opcode) { case 40: case 42: return null;case 2: oracleTypeDATE = new OracleTypeDATE(); oracleTypeDATE.parseTDSrec(paramTDSReader); this.idx++; return oracleTypeDATE;case 7: oracleTypeCHAR = new OracleTypeCHAR(this.connection, 12); oracleTypeCHAR.parseTDSrec(paramTDSReader); this.idx++; return oracleTypeCHAR;case 1: oracleTypeCHAR = new OracleTypeCHAR(this.connection, 1); oracleTypeCHAR.parseTDSrec(paramTDSReader); this.idx++; return oracleTypeCHAR;case 39: oracleTypeADT = new OracleTypeADT(this, this.idx, (Connection)this.connection); oracleTypeADT.setEmbeddedADT(); oracleTypeADT.parseTDSrec(paramTDSReader); this.idx++; return oracleTypeADT;case 6: oracleTypeNUMBER = new OracleTypeNUMBER(2); oracleTypeNUMBER.parseTDSrec(paramTDSReader); this.idx++; return oracleTypeNUMBER;case 3: oracleTypeNUMBER = new OracleTypeNUMBER(3); oracleTypeNUMBER.parseTDSrec(paramTDSReader); this.idx++; return oracleTypeNUMBER;case 4: oracleTypeNUMBER = new OracleTypeNUMBER(8); oracleTypeNUMBER.parseTDSrec(paramTDSReader); this.idx++; return oracleTypeNUMBER;case 5: oracleTypeFLOAT = new OracleTypeFLOAT(); oracleTypeFLOAT.parseTDSrec(paramTDSReader); this.idx++; return oracleTypeFLOAT;case 37: oracleTypeBINARY_FLOAT = new OracleTypeBINARY_FLOAT(); oracleTypeBINARY_FLOAT.parseTDSrec(paramTDSReader); this.idx++; return oracleTypeBINARY_FLOAT;case 45: oracleTypeBINARY_DOUBLE = new OracleTypeBINARY_DOUBLE(); oracleTypeBINARY_DOUBLE.parseTDSrec(paramTDSReader); this.idx++; return oracleTypeBINARY_DOUBLE;case 8: oracleTypeSINT32 = new OracleTypeSINT32(); oracleTypeSINT32.parseTDSrec(paramTDSReader); this.idx++; return oracleTypeSINT32;case 9: oracleTypeREF = new OracleTypeREF(this, this.idx, this.connection); oracleTypeREF.parseTDSrec(paramTDSReader); this.idx++; return oracleTypeREF;case 31: oracleTypeBFILE = new OracleTypeBFILE(this.connection); oracleTypeBFILE.parseTDSrec(paramTDSReader); this.idx++; return oracleTypeBFILE;case 19: oracleTypeRAW = new OracleTypeRAW(); oracleTypeRAW.parseTDSrec(paramTDSReader); this.idx++; return oracleTypeRAW;case 29: oracleTypeCLOB = new OracleTypeCLOB(this.connection); oracleTypeCLOB.parseTDSrec(paramTDSReader); if (this.sqlName != null && !this.endOfAdt) this.connection.getForm(this, oracleTypeCLOB, this.idx);  this.idx++; return oracleTypeCLOB;case 30: oracleTypeBLOB = new OracleTypeBLOB(this.connection); oracleTypeBLOB.parseTDSrec(paramTDSReader); this.idx++; return oracleTypeBLOB;case 21: oracleTypeTIMESTAMP = new OracleTypeTIMESTAMP(this.connection); oracleTypeTIMESTAMP.parseTDSrec(paramTDSReader); this.idx++; return oracleTypeTIMESTAMP;case 23: oracleTypeTIMESTAMPTZ = new OracleTypeTIMESTAMPTZ(this.connection); oracleTypeTIMESTAMPTZ.parseTDSrec(paramTDSReader); this.idx++; return oracleTypeTIMESTAMPTZ;case 33: oracleTypeTIMESTAMPLTZ = new OracleTypeTIMESTAMPLTZ(this.connection); oracleTypeTIMESTAMPLTZ.parseTDSrec(paramTDSReader); this.idx++; return oracleTypeTIMESTAMPLTZ;case 24: oracleTypeINTERVAL = new OracleTypeINTERVAL(this.connection); oracleTypeINTERVAL.parseTDSrec(paramTDSReader); this.idx++; return oracleTypeINTERVAL;case 28: oracleTypeCOLLECTION = new OracleTypeCOLLECTION(this, this.idx, this.connection); oracleTypeCOLLECTION.parseTDSrec(paramTDSReader); this.idx++; return oracleTypeCOLLECTION;case 27: oracleTypeUPT = new OracleTypeUPT(this, this.idx, this.connection); oracleTypeUPT.parseTDSrec(paramTDSReader); this.idx++; return oracleTypeUPT; }  OracleTypeUPT oracleTypeUPT = null; SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 48, "get_next_type: " + this.opcode); sQLException.fillInStackTrace(); throw sQLException; } public byte[] linearize(Datum paramDatum) throws SQLException { synchronized (this.connection) { return pickle81(paramDatum); }  } public Datum unlinearize(byte[] paramArrayOfbyte, long paramLong, Datum paramDatum, int paramInt, Map paramMap) throws SQLException { OracleConnection oracleConnection = getConnection(); Datum datum = null; if (oracleConnection == null) { datum = _unlinearize(paramArrayOfbyte, paramLong, paramDatum, paramInt, paramMap); } else { synchronized (oracleConnection) { datum = _unlinearize(paramArrayOfbyte, paramLong, paramDatum, paramInt, paramMap); }  }  return datum; } public Datum _unlinearize(byte[] paramArrayOfbyte, long paramLong, Datum paramDatum, int paramInt, Map paramMap) throws SQLException { synchronized (this.connection) { if (paramArrayOfbyte == null) return null;  PickleContext pickleContext = new PickleContext(paramArrayOfbyte, paramLong); return (Datum)unpickle81(pickleContext, (STRUCT)paramDatum, 1, paramInt, paramMap); }  } protected STRUCT unpickle81(PickleContext paramPickleContext, STRUCT paramSTRUCT, int paramInt1, int paramInt2, Map paramMap) throws SQLException { long l2; Datum[] arrayOfDatum; Object[] arrayOfObject; byte b1; STRUCT sTRUCT = paramSTRUCT; long l1 = paramPickleContext.offset(); byte b = paramPickleContext.readByte(); if (!PickleContext.is81format(b)) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image is not in 8.1 format"); sQLException1.fillInStackTrace(); throw sQLException1; }  if (PickleContext.isCollectionImage_pctx(b)) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image is a collection image,expecting ADT"); sQLException1.fillInStackTrace(); throw sQLException1; }  if (!paramPickleContext.readAndCheckVersion()) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image version is not recognized"); sQLException1.fillInStackTrace(); throw sQLException1; }  switch (paramInt1) { case 9: paramPickleContext.skipBytes(paramPickleContext.readLength(true) - 2); return sTRUCT;case 3: l2 = paramPickleContext.readLength(); sTRUCT = unpickle81Prefix(paramPickleContext, sTRUCT, b); if (sTRUCT == null) { StructDescriptor structDescriptor = createStructDescriptor(); sTRUCT = createByteSTRUCT(structDescriptor, (byte[])null); }  sTRUCT.setImage(paramPickleContext.image(), l1, 0L); sTRUCT.setImageLength(l2); paramPickleContext.skipTo(l1 + l2); return sTRUCT; }  paramPickleContext.skipLength(); sTRUCT = unpickle81Prefix(paramPickleContext, sTRUCT, b); if (sTRUCT == null) { StructDescriptor structDescriptor = createStructDescriptor(); sTRUCT = createByteSTRUCT(structDescriptor, (byte[])null); }  OracleType[] arrayOfOracleType = sTRUCT.getDescriptor().getOracleTypeADT().getAttrTypes(); switch (paramInt2) { case 1: arrayOfDatum = new Datum[arrayOfOracleType.length]; for (b1 = 0; b1 < arrayOfOracleType.length; b1++) arrayOfDatum[b1] = (Datum)arrayOfOracleType[b1].unpickle81rec(paramPickleContext, paramInt2, paramMap);  sTRUCT.setDatumArray(arrayOfDatum); return sTRUCT;case 2: arrayOfObject = new Object[arrayOfOracleType.length]; for (b1 = 0; b1 < arrayOfOracleType.length; b1++) arrayOfObject[b1] = arrayOfOracleType[b1].unpickle81rec(paramPickleContext, paramInt2, paramMap);  sTRUCT.setObjArray(arrayOfObject); return sTRUCT; }  SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1); sQLException.fillInStackTrace(); throw sQLException; } protected STRUCT unpickle81Prefix(PickleContext paramPickleContext, STRUCT paramSTRUCT, byte paramByte) throws SQLException { STRUCT sTRUCT = paramSTRUCT; if (PickleContext.hasPrefix(paramByte)) { long l = (paramPickleContext.readLength() + paramPickleContext.absoluteOffset()); byte b1 = paramPickleContext.readByte(); byte b2 = (byte)(b1 & 0xC); boolean bool1 = (b2 == 0) ? true : false; boolean bool2 = (b2 == 4) ? true : false; boolean bool3 = (b2 == 8) ? true : false; boolean bool4 = (b2 == 12) ? true : false; boolean bool5 = ((b1 & 0x10) != 0) ? true : false; if (bool2) { byte[] arrayOfByte = paramPickleContext.readBytes(16); String str = toid2typename((Connection)this.connection, arrayOfByte); StructDescriptor structDescriptor = (StructDescriptor)TypeDescriptor.getTypeDescriptor(str, (OracleConnection)this.connection); if (sTRUCT == null) { sTRUCT = createByteSTRUCT(structDescriptor, (byte[])null); } else { sTRUCT.setDescriptor(structDescriptor); }  }  if (bool5) paramPickleContext.readLength();  if ((bool3 | bool4) != 0) { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }  paramPickleContext.skipTo(l); }  return sTRUCT; } protected Object unpickle81rec(PickleContext paramPickleContext, int paramInt, Map paramMap) throws SQLException { byte b = paramPickleContext.readByte(); byte b1 = 0; if (PickleContext.isAtomicNull(b)) return null;  if (PickleContext.isImmediatelyEmbeddedNull(b)) b1 = paramPickleContext.readByte();  STRUCT sTRUCT = unpickle81datum(paramPickleContext, b, b1); return toObject(sTRUCT, paramInt, paramMap); } protected Object unpickle81rec(PickleContext paramPickleContext, byte paramByte, int paramInt, Map paramMap) throws SQLException { STRUCT sTRUCT = unpickle81datum(paramPickleContext, paramByte, (byte)0); return toObject(sTRUCT, paramInt, paramMap); } private STRUCT unpickle81datum(PickleContext paramPickleContext, byte paramByte1, byte paramByte2) throws SQLException { int i = getNumAttrs(); StructDescriptor structDescriptor = createStructDescriptor(); STRUCT sTRUCT = createByteSTRUCT(structDescriptor, (byte[])null); OracleType oracleType = getAttrTypeAt(0); Object object = null; if (PickleContext.isImmediatelyEmbeddedNull(paramByte1) && paramByte2 == 1) { object = null; } else if (PickleContext.isImmediatelyEmbeddedNull(paramByte1)) { object = ((OracleTypeADT)oracleType).unpickle81datum(paramPickleContext, paramByte1, (byte)(paramByte2 - 1)); } else if (PickleContext.isElementNull(paramByte1)) { if (oracleType.getTypeCode() == 2002 || oracleType.getTypeCode() == 2008) { Datum datum = oracleType.unpickle81datumAsNull(paramPickleContext, paramByte1, paramByte2); } else { object = null; }  } else { object = oracleType.unpickle81rec(paramPickleContext, paramByte1, 1, null); }  Datum[] arrayOfDatum = new Datum[i]; arrayOfDatum[0] = (Datum)object; for (byte b = 1; b < i; b++) { oracleType = getAttrTypeAt(b); arrayOfDatum[b] = (Datum)oracleType.unpickle81rec(paramPickleContext, 1, null); }  sTRUCT.setDatumArray(arrayOfDatum); return sTRUCT; } protected Datum unpickle81datumAsNull(PickleContext paramPickleContext, byte paramByte1, byte paramByte2) throws SQLException { int i = getNumAttrs(); StructDescriptor structDescriptor = createStructDescriptor(); STRUCT sTRUCT = createByteSTRUCT(structDescriptor, (byte[])null); Datum[] arrayOfDatum = new Datum[i]; byte b = 0; OracleType oracleType = getAttrTypeAt(b); if (oracleType.getTypeCode() == 2002 || oracleType.getTypeCode() == 2008) { arrayOfDatum[b++] = oracleType.unpickle81datumAsNull(paramPickleContext, paramByte1, paramByte2); } else { arrayOfDatum[b++] = (Datum)null; }  for (; b < i; b++) { oracleType = getAttrTypeAt(b); if (oracleType.getTypeCode() == 2002 || oracleType.getTypeCode() == 2008) { arrayOfDatum[b] = (Datum)oracleType.unpickle81rec(paramPickleContext, 1, null); } else { arrayOfDatum[b] = (Datum)oracleType.unpickle81rec(paramPickleContext, 1, null); }  }  sTRUCT.setDatumArray(arrayOfDatum); return (Datum)sTRUCT; } public byte[] pickle81(Datum paramDatum) throws SQLException { PickleContext pickleContext = new PickleContext(); pickleContext.initStream(); pickle81(pickleContext, paramDatum); byte[] arrayOfByte = pickleContext.stream2Bytes(); paramDatum.setShareBytes(arrayOfByte); return arrayOfByte; } protected int pickle81(PickleContext paramPickleContext, Datum paramDatum) throws SQLException { int i = paramPickleContext.offset() + 2; int j = 0; j += paramPickleContext.writeImageHeader(shouldHavePrefix()); j += pickle81Prefix(paramPickleContext); j += pickle81rec(paramPickleContext, paramDatum, 0); paramPickleContext.patchImageLen(i, j); return j; } private boolean hasVersion() { return (this.typeVersion > 1); } private boolean needsToid() { if (this.isTransient) return false;  return ((this.statusBits & 0x40) != 0 || (this.statusBits & 0x20) == 0 || hasVersion()); } private boolean shouldHavePrefix() { if (this.isTransient) return false;  return (hasVersion() || needsToid()); } protected int pickle81Prefix(PickleContext paramPickleContext) throws SQLException { if (shouldHavePrefix()) { int i = 0; int j = 1; int k = 1; if (needsToid()) { k += (getTOID()).length; j |= 0x4; }  if (hasVersion()) { j |= 0x10; if (this.typeVersion > PickleContext.KOPI20_LN_MAXV) { k += 5; } else { k += 2; }  }  i = paramPickleContext.writeLength(k); i += paramPickleContext.writeData((byte)j); if (needsToid()) i += paramPickleContext.writeData(this.toid);  if (hasVersion()) if (this.typeVersion > PickleContext.KOPI20_LN_MAXV) { i += paramPickleContext.writeLength(this.typeVersion); } else { i += paramPickleContext.writeSB2(this.typeVersion); }   return i; }  return 0; } private int pickle81rec(PickleContext paramPickleContext, Datum paramDatum, int paramInt) throws SQLException { int i = 0; if (!this.metaDataInitialized) copy_properties((OracleTypeADT)((STRUCT)paramDatum).getDescriptor().getPickler());  Datum[] arrayOfDatum = ((STRUCT)paramDatum).getOracleAttributes(); int j = arrayOfDatum.length; byte b = 0; OracleType oracleType = getAttrTypeAt(0); if (oracleType instanceof OracleTypeADT && !(oracleType instanceof OracleTypeCOLLECTION) && !(oracleType instanceof OracleTypeUPT)) { b = 1; if (arrayOfDatum[0] == null) { if (paramInt > 0) { i += paramPickleContext.writeImmediatelyEmbeddedElementNull((byte)paramInt); } else { i += paramPickleContext.writeAtomicNull(); }  } else { i += ((OracleTypeADT)oracleType).pickle81rec(paramPickleContext, arrayOfDatum[0], paramInt + 1); }  }  for (; b < j; b++) { oracleType = getAttrTypeAt(b); if (arrayOfDatum[b] == null) { if (oracleType instanceof OracleTypeADT && !(oracleType instanceof OracleTypeCOLLECTION) && !(oracleType instanceof OracleTypeUPT)) { i += paramPickleContext.writeAtomicNull(); } else { i += paramPickleContext.writeElementNull(); }  } else if (oracleType instanceof OracleTypeADT && !(oracleType instanceof OracleTypeCOLLECTION) && !(oracleType instanceof OracleTypeUPT)) { i += ((OracleTypeADT)oracleType).pickle81rec(paramPickleContext, arrayOfDatum[b], 1); } else { i += oracleType.pickle81(paramPickleContext, arrayOfDatum[b]); }  }  return i; } private Object toObject(STRUCT paramSTRUCT, int paramInt, Map paramMap) throws SQLException { switch (paramInt) { case 1: return paramSTRUCT;case 2: if (paramSTRUCT != null) return paramSTRUCT.toJdbc(paramMap);  return null; }  SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1); sQLException.fillInStackTrace(); throw sQLException; } public String getAttributeType(int paramInt) throws SQLException { return getAttributeType(paramInt, true); } public String getAttributeType(int paramInt, boolean paramBoolean) throws SQLException { if (paramBoolean) { if (this.sqlName == null) getFullName();  if (this.attrNames == null) initADTAttrNames();  }  if (paramInt < 1 || (this.attrTypeNames != null && paramInt > this.attrTypeNames.length)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid index"); sQLException.fillInStackTrace(); throw sQLException; }  if (this.attrTypeNames != null) return this.attrTypeNames[paramInt - 1];  return null; } public String getAttributeName(int paramInt) throws SQLException { if (this.attrNames == null) initADTAttrNames();  String str = null; if (this.attrNames != null) { synchronized (this.connection) { if (paramInt < 1 || paramInt > this.attrNames.length) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid index"); sQLException.fillInStackTrace(); throw sQLException; }  }  str = this.attrNames[paramInt - 1]; }  return str; } public String getAttributeName(int paramInt, boolean paramBoolean) throws SQLException { if (paramBoolean && this.connection != null) return getAttributeName(paramInt);  if (paramInt < 1 || (this.attrNames != null && paramInt > this.attrNames.length)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid index"); sQLException.fillInStackTrace(); throw sQLException; }  if (this.attrNames != null) return this.attrNames[paramInt - 1];  return null; } static final String[] sqlString = new String[] { "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM USER_TYPE_ATTRS WHERE TYPE_NAME = :1 ORDER BY ATTR_NO", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM USER_TYPE_ATTRS WHERE TYPE_NAME in (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :1 CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :1 FROM DUAL) ORDER BY ATTR_NO", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM USER_TYPE_ATTRS WHERE TYPE_NAME in (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :1 CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :1 FROM DUAL) ORDER BY ATTR_NO", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM USER_TYPE_ATTRS WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM ALL_SYNONYMS START WITH SYNONYM_NAME = :1 AND  OWNER = 'PUBLIC' CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER UNION SELECT :2  FROM DUAL) ORDER BY ATTR_NO", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM USER_TYPE_ATTRS WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM ALL_SYNONYMS START WITH SYNONYM_NAME = :1 AND  OWNER = 'PUBLIC' CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER UNION SELECT :2  FROM DUAL) ORDER BY ATTR_NO", "DECLARE CURSOR usyn_cur IS SELECT table_name, table_owner from user_synonyms; TYPE table_name_type IS TABLE OF usyn_cur%ROWTYPE; table_names table_name_type; lastrow BINARY_INTEGER := null; l_syntname user_synonyms.table_name%TYPE; l_syntown  user_synonyms.table_owner%TYPE; BEGIN SELECT TABLE_NAME, TABLE_OWNER BULK COLLECT INTO table_names FROM USER_SYNONYMS START WITH SYNONYM_NAME = ? CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME; IF table_names.LAST IS NOT NULL THEN   lastrow := table_names.LAST;   l_syntname := table_names(lastrow).table_name;   l_syntown :=  table_names(lastrow).table_owner; END IF; OPEN ? FOR SELECT  ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER   FROM ALL_TYPE_ATTRS  A   WHERE (TYPE_NAME = l_syntname OR TYPE_NAME = ?)  AND  A.OWNER = l_syntown   ORDER BY ATTR_NO; END;", "DECLARE CURSOR usyn_cur IS SELECT table_name, table_owner from user_synonyms; TYPE table_name_type IS TABLE OF usyn_cur%ROWTYPE; table_names table_name_type; lastrow BINARY_INTEGER := null; l_syntname user_synonyms.table_name%TYPE; l_syntown  user_synonyms.table_owner%TYPE; BEGIN SELECT TABLE_NAME, TABLE_OWNER BULK COLLECT INTO table_names FROM USER_SYNONYMS START WITH SYNONYM_NAME = ? CONNECT BY NOCYCLEPRIOR TABLE_NAME = SYNONYM_NAME; IF table_names.LAST IS NOT NULL THEN   lastrow := table_names.LAST;   l_syntname := table_names(lastrow).table_name;   l_syntown :=  table_names(lastrow).table_owner; END IF; OPEN ? FOR SELECT  ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER   FROM ALL_TYPE_ATTRS  A   WHERE (TYPE_NAME = l_syntname OR TYPE_NAME = ?)  AND  A.OWNER = l_syntown   ORDER BY ATTR_NO; END;", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM ALL_TYPE_ATTRS WHERE OWNER = :1 AND TYPE_NAME = :2 ORDER BY ATTR_NO", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM ALL_TYPE_ATTRS WHERE OWNER = (SELECT TABLE_OWNER FROM ALL_SYNONYMS WHERE SYNONYM_NAME=:1) AND TYPE_NAME = (SELECT TABLE_NAME FROM ALL_SYNONYMS WHERE SYNONYM_NAME=:2) ORDER BY ATTR_NO", "DECLARE   the_owner VARCHAR2(100);   the_type  VARCHAR2(100); begin  SELECT TABLE_NAME, TABLE_OWNER INTO THE_TYPE, THE_OWNER  FROM ALL_SYNONYMS  WHERE TABLE_NAME IN (SELECT TYPE_NAME FROM ALL_TYPES)  START WITH SYNONYM_NAME = :1 AND OWNER = 'PUBLIC'  CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER; OPEN :2 FOR SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME,  ATTR_TYPE_OWNER FROM ALL_TYPE_ATTRS  WHERE TYPE_NAME = THE_TYPE and OWNER = THE_OWNER; END;", "DECLARE   the_owner VARCHAR2(100);   the_type  VARCHAR2(100); begin  SELECT TABLE_NAME, TABLE_OWNER INTO THE_TYPE, THE_OWNER  FROM ALL_SYNONYMS  WHERE TABLE_NAME IN (SELECT TYPE_NAME FROM ALL_TYPES)  START WITH SYNONYM_NAME = :1 AND OWNER = 'PUBLIC'  CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER; OPEN :2 FOR SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME,  ATTR_TYPE_OWNER FROM ALL_TYPE_ATTRS  WHERE TYPE_NAME = THE_TYPE and OWNER = THE_OWNER; END;" }; static final int SEARCH_USER_TYPES = 0; static final int SEARCH_ALL_TYPES = 1; private void initADTAttrNames() throws SQLException { if (this.connection == null) return;  if (this.sqlName == null) getFullName();  if (this.toid != null) { initADTAttrNamesUsingTOID(); return; }  synchronized (this.connection) { OracleCallableStatement oracleCallableStatement = null; PreparedStatement preparedStatement = null; ResultSet resultSet = null; String[] arrayOfString1 = new String[this.attrTypes.length]; String[] arrayOfString2 = new String[this.attrTypes.length]; byte b1 = 0; byte b2 = 0; if (this.attrNames == null) { b1 = this.sqlName.getSchema().equals(this.connection.getDefaultSchemaNameForNamedTypes()) ? 0 : 7; while (b1 != 11) { CallableStatement callableStatement; switch (b1) { case false: preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b1]); preparedStatement.setString(1, this.sqlName.getSimpleName()); preparedStatement.setFetchSize(this.idx); resultSet = preparedStatement.executeQuery(); b1 = 1; break;case true: if (this.connection.getVersionNumber() >= 10000) b1 = 2; case true: preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b1]); preparedStatement.setString(1, this.sqlName.getSimpleName()); preparedStatement.setString(2, this.sqlName.getSimpleName()); preparedStatement.setFetchSize(this.idx); resultSet = preparedStatement.executeQuery(); b1 = 3; break;case true: if (this.connection.getVersionNumber() >= 10000) b1 = 4; case true: preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b1]); preparedStatement.setString(1, this.sqlName.getSimpleName()); preparedStatement.setString(2, this.sqlName.getSimpleName()); preparedStatement.setFetchSize(this.idx); resultSet = preparedStatement.executeQuery(); b1 = 5; break;case true: if (this.connection.getVersionNumber() >= 10000) b1 = 6; case true: oracleCallableStatement = (OracleCallableStatement)this.connection.prepareCall(getSqlHint() + sqlString[b1]); oracleCallableStatement.setString(1, this.sqlName.getSimpleName()); oracleCallableStatement.setString(3, this.sqlName.getSimpleName()); oracleCallableStatement.registerOutParameter(2, -10); oracleCallableStatement.execute(); resultSet = oracleCallableStatement.getCursor(2); resultSet.setFetchSize(1); b1 = 8; break;case true: preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b1]); preparedStatement.setString(1, this.sqlName.getSchema()); preparedStatement.setString(2, this.sqlName.getSimpleName()); preparedStatement.setFetchSize(this.idx); resultSet = preparedStatement.executeQuery(); b1 = 8; break;case true: preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b1]); preparedStatement.setString(1, this.sqlName.getSimpleName()); preparedStatement.setString(2, this.sqlName.getSimpleName()); preparedStatement.setFetchSize(this.idx); resultSet = preparedStatement.executeQuery(); b1 = 9; break;case true: if (this.connection.getVersionNumber() >= 10000) b1 = 10; case true: callableStatement = this.connection.prepareCall(getSqlHint() + sqlString[b1]); callableStatement.setString(1, this.sqlName.getSimpleName()); callableStatement.registerOutParameter(2, -10); callableStatement.execute(); resultSet = ((OracleCallableStatement)callableStatement).getCursor(2); b1 = 11; break; }  try { b2 = 0; for (; b2 < this.attrTypes.length && resultSet.next(); b2++) { if (resultSet.getInt(1) != b2 + 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "inconsistent ADT attribute"); sQLException.fillInStackTrace(); throw sQLException; }  arrayOfString1[b2] = resultSet.getString(2); String str = resultSet.getString(4); arrayOfString2[b2] = ""; if (str != null) arrayOfString2[b2] = str + ".";  arrayOfString2[b2] = arrayOfString2[b2] + resultSet.getString(3); }  if (b2 != 0) { this.attrTypeNames = arrayOfString2; this.attrNames = arrayOfString1; b1 = 11; } else { if (resultSet != null) resultSet.close();  if (preparedStatement != null) preparedStatement.close();  if (callableStatement != null) callableStatement.close();  }  } finally { if (resultSet != null) resultSet.close();  if (preparedStatement != null) preparedStatement.close();  if (callableStatement != null) callableStatement.close();  }  }  }  }  } static final String[] sqlStringTOID = new String[] { "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM USER_TYPE_ATTRS a, USER_TYPES b WHERE b.TYPE_OID = :1 AND a.TYPE_NAME = b.TYPE_NAME ORDER BY ATTR_NO", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM ALL_TYPE_ATTRS a, ALL_TYPES b WHERE b.TYPE_OID = :1 AND a.TYPE_NAME = b.TYPE_NAME AND a.OWNER = b.OWNER ORDER BY ATTR_NO" }; Boolean isInstanciable; String superTypeName; int numberOfLocalAttributes; String[] subTypeNames; final int LOCAL_TYPE = 0; final int LOOK_FOR_USER_SYNONYM = 1; final int LOOK_FOR_PUBLIC_SYNONYM = 2; final String[] initMetaData1_9_0_SQL; static final int TDS_SIZE = 4; static final int TDS_NUMBER = 1; static final int KOPM_OTS_SQL_CHAR = 1; static final int KOPM_OTS_DATE = 2; static final int KOPM_OTS_DECIMAL = 3; static final int KOPM_OTS_DOUBLE = 4; static final int KOPM_OTS_FLOAT = 5; static final int KOPM_OTS_NUMBER = 6; static final int KOPM_OTS_SQL_VARCHAR2 = 7; static final int KOPM_OTS_SINT32 = 8; static final int KOPM_OTS_REF = 9; static final int KOPM_OTS_VARRAY = 10; static final int KOPM_OTS_UINT8 = 11; static final int KOPM_OTS_SINT8 = 12; static final int KOPM_OTS_UINT16 = 13; static final int KOPM_OTS_UINT32 = 14; static final int KOPM_OTS_LOB = 15; static final int KOPM_OTS_CANONICAL = 17; protected OracleTypeADT() { this.numberOfLocalAttributes = -1; this.LOCAL_TYPE = 0; this.LOOK_FOR_USER_SYNONYM = 1; this.LOOK_FOR_PUBLIC_SYNONYM = 2; this.initMetaData1_9_0_SQL = new String[] { "SELECT INSTANTIABLE, supertype_owner, supertype_name, LOCAL_ATTRIBUTES FROM all_types WHERE type_name = :1 AND owner = :2 ", "DECLARE \n bind_synonym_name user_synonyms.synonym_name%type := :1; \n the_table_owner  user_synonyms.table_owner%type; \n the_table_name   user_synonyms.table_name%type; \n the_db_link      user_synonyms.db_link%type; \n sql_string       VARCHAR2(1000); \nBEGIN \n   SELECT TABLE_NAME, TABLE_OWNER, DB_LINK INTO  \n         the_table_name, the_table_owner, the_db_link \n         FROM USER_SYNONYMS WHERE \n         SYNONYM_NAME = bind_synonym_name; \n \n   sql_string := 'SELECT INSTANTIABLE, SUPERTYPE_OWNER,      SUPERTYPE_NAME, LOCAL_ATTRIBUTES FROM ALL_TYPES'; \n \n   IF the_db_link IS NOT NULL  \n   THEN \n     sql_string := sql_string || '@' || the_db_link; \n   END IF; \n   sql_string := sql_string       || ' WHERE TYPE_NAME = '''       || the_table_name   || ''' AND OWNER = '''       || the_table_owner  || ''''; \n   OPEN :2 FOR sql_string; \nEND;", "DECLARE \n bind_synonym_name user_synonyms.synonym_name%type := :1; \n the_table_owner  user_synonyms.table_owner%type; \n the_table_name   user_synonyms.table_name%type; \n the_db_link      user_synonyms.db_link%type; \n sql_string       VARCHAR2(1000); \nBEGIN \n   SELECT TABLE_NAME, TABLE_OWNER, DB_LINK INTO  \n         the_table_name, the_table_owner, the_db_link \n         FROM ALL_SYNONYMS WHERE \n         OWNER = 'PUBLIC' AND \n         SYNONYM_NAME = bind_synonym_name; \n \n   sql_string := 'SELECT INSTANTIABLE, SUPERTYPE_OWNER,      SUPERTYPE_NAME, LOCAL_ATTRIBUTES FROM ALL_TYPES'; \n \n   IF the_db_link IS NOT NULL  \n   THEN \n     sql_string := sql_string || '@' || the_db_link; \n   END IF; \n   sql_string := sql_string       || ' WHERE TYPE_NAME = '''       || the_table_name   || ''' AND OWNER = '''       || the_table_owner  || ''''; \n   OPEN :2 FOR sql_string; \nEND;" }; } static final int KOPM_OTS_OCTET = 18; static final int KOPM_OTS_RAW = 19; static final int KOPM_OTS_ROWID = 20; static final int KOPM_OTS_STAMP = 21; static final int KOPM_OTS_TZSTAMP = 23; static final int KOPM_OTS_INTERVAL = 24; static final int KOPM_OTS_PTR = 25; static final int KOPM_OTS_SINT16 = 26; static final int KOPM_OTS_UPT = 27; static final int KOPM_OTS_COLLECTION = 28; static final int KOPM_OTS_CLOB = 29; static final int KOPM_OTS_BLOB = 30; static final int KOPM_OTS_BFILE = 31; static final int KOPM_OTS_BINARY_INTEGE = 32; static final int KOPM_OTS_IMPTZSTAMP = 33; static final int KOPM_OTS_BFLOAT = 37; static final int KOPM_OTS_BDOUBLE = 45; static final int KOTTCOPQ = 58; static final int KOPT_OP_STARTEMBADT = 39; static final int KOPT_OP_ENDEMBADT = 40; static final int KOPT_OP_STARTADT = 41; static final int KOPT_OP_ENDADT = 42; static final int KOPT_OP_SUBTYPE_MARKER = 43; static final int KOPT_OP_EMBADT_INFO = 44; static final int KOPT_OPCODE_START = 38; static final int KOPT_OP_VERSION = 38; static final int REGULAR_PATCH = 0; static final int SIMPLE_PATCH = 1; private void initADTAttrNamesUsingTOID() throws SQLException { synchronized (this.connection) { CallableStatement callableStatement = null; PreparedStatement preparedStatement = null; ResultSet resultSet = null; String[] arrayOfString1 = new String[this.attrTypes.length]; String[] arrayOfString2 = new String[this.attrTypes.length]; byte b1 = 0; byte b2 = 0; if (this.attrNames == null) { b1 = this.sqlName.getSchema().equals(this.connection.getDefaultSchemaNameForNamedTypes()) ? 0 : 1; while (b1 != 11) { switch (b1) { case false: preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlStringTOID[b1]); preparedStatement.setBytes(1, this.toid); preparedStatement.setFetchSize(this.idx); resultSet = preparedStatement.executeQuery(); b1 = 1; break;case true: preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlStringTOID[b1]); preparedStatement.setBytes(1, this.toid); preparedStatement.setFetchSize(this.idx); resultSet = preparedStatement.executeQuery(); b1 = 11; break; }  try { b2 = 0; for (; b2 < this.attrTypes.length && resultSet.next(); b2++) { if (resultSet.getInt(1) != b2 + 1 && b1 == 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "inconsistent ADT attribute"); sQLException.fillInStackTrace(); throw sQLException; }  arrayOfString1[b2] = resultSet.getString(2); String str = resultSet.getString(4); arrayOfString2[b2] = ""; if (str != null) arrayOfString2[b2] = str + ".";  arrayOfString2[b2] = arrayOfString2[b2] + resultSet.getString(3); }  if (b2 != 0) { this.attrTypeNames = arrayOfString2; this.attrNames = arrayOfString1; b1 = 11; } else { if (resultSet != null) resultSet.close();  if (preparedStatement != null) preparedStatement.close();  }  } finally { if (resultSet != null) resultSet.close();  if (preparedStatement != null) preparedStatement.close();  if (callableStatement != null) callableStatement.close();  }  }  }  }  } StructDescriptor createStructDescriptor() throws SQLException { StructDescriptor structDescriptor = (StructDescriptor)this.descriptor; if (structDescriptor == null) structDescriptor = new StructDescriptor(this, (Connection)this.connection);  return structDescriptor; } STRUCT createObjSTRUCT(StructDescriptor paramStructDescriptor, Object[] paramArrayOfObject) throws SQLException { if ((this.statusBits & 0x10) != 0) return (STRUCT)new JAVA_STRUCT(paramStructDescriptor, (Connection)this.connection, paramArrayOfObject);  return new STRUCT(paramStructDescriptor, (Connection)this.connection, paramArrayOfObject); } STRUCT createByteSTRUCT(StructDescriptor paramStructDescriptor, byte[] paramArrayOfbyte) throws SQLException { if ((this.statusBits & 0x10) != 0) return (STRUCT)new JAVA_STRUCT(paramStructDescriptor, paramArrayOfbyte, (Connection)this.connection);  return new STRUCT(paramStructDescriptor, paramArrayOfbyte, (Connection)this.connection); } public static String getSubtypeName(Connection paramConnection, byte[] paramArrayOfbyte, long paramLong) throws SQLException { PickleContext pickleContext = new PickleContext(paramArrayOfbyte, paramLong); byte b = pickleContext.readByte(); if (PickleContext.is81format(b)) if (!PickleContext.isCollectionImage_pctx(b)) if (PickleContext.hasPrefix(b)) { if (!pickleContext.readAndCheckVersion()) { SQLException sQLException = DatabaseError.createSqlException(null, 1, "Image version is not recognized"); sQLException.fillInStackTrace(); throw sQLException; }  pickleContext.skipLength(); pickleContext.skipLength(); b = pickleContext.readByte(); if ((b & 0x4) != 0) { byte[] arrayOfByte = pickleContext.readBytes(16); return toid2typename(paramConnection, arrayOfByte); }  return null; }    return null; } public static String toid2typename(Connection paramConnection, byte[] paramArrayOfbyte) throws SQLException { String str = (String)((OracleConnection)paramConnection).getDescriptor(paramArrayOfbyte); if (str == null) { PreparedStatement preparedStatement = null; ResultSet resultSet = null; try { preparedStatement = paramConnection.prepareStatement("select owner, type_name from all_types where type_oid = :1"); preparedStatement.setBytes(1, paramArrayOfbyte); resultSet = preparedStatement.executeQuery(); if (resultSet.next()) { str = resultSet.getString(1) + "." + resultSet.getString(2); ((OracleConnection)paramConnection).putDescriptor(paramArrayOfbyte, str); } else { SQLException sQLException = DatabaseError.createSqlException(null, 1, "Invalid type oid"); sQLException.fillInStackTrace(); throw sQLException; }  } finally { if (resultSet != null) resultSet.close();  if (preparedStatement != null) preparedStatement.close();  }  }  return str; } public int getTdsVersion() { return this.tdsVersion; } public void printDebug() {} private String debugText() { StringWriter stringWriter = new StringWriter(); PrintWriter printWriter = new PrintWriter(stringWriter); printWriter.println("OracleTypeADT = " + this); printWriter.println("sqlName = " + this.sqlName); printWriter.println("OracleType[] : "); if (this.attrTypes != null) { for (byte b = 0; b < this.attrTypes.length; b++) printWriter.println("[" + b + "] = " + this.attrTypes[b]);  } else { printWriter.println("null"); }  printWriter.println("toid : "); if (this.toid != null) { printUnsignedByteArray(this.toid, printWriter); } else { printWriter.println("null"); }  printWriter.println("tds version : " + this.tdsVersion); printWriter.println("type version : " + this.typeVersion); printWriter.println("type version : " + this.typeVersion); printWriter.println("opcode : " + this.opcode); printWriter.println("tdoCState : " + this.tdoCState); return stringWriter.getBuffer().substring(0); } public byte[] getTOID() { try { if (this.toid == null) initMetadata(this.connection);  } catch (SQLException sQLException) {} return this.toid; } public int getImageFormatVersion() { return PickleContext.KOPI20_VERSION; } public int getTypeVersion() { try { if (this.typeVersion == -1) initMetadata(this.connection);  } catch (SQLException sQLException) {} return this.typeVersion; } public int getCharSet() { return this.charSetId; } public int getCharSetForm() { return this.charSetForm; } public long getTdoCState() { synchronized (this.connection) { try { if (this.tdoCState == 0L) { getFullName(); this.tdoCState = this.connection.getTdoCState(this.sqlName.getSchema(), this.sqlName.getSimpleName()); }  } catch (SQLException sQLException) {} return this.tdoCState; }  } public long getFIXED_DATA_SIZE() { try { return getFixedDataSize(); } catch (SQLException sQLException) { return 0L; }  } public long getFixedDataSize() throws SQLException { return this.fixedDataSize; } public int getAlignmentReq() throws SQLException { return this.alignmentRequirement; } public int getNumAttrs() throws SQLException { if (this.attrTypes == null && this.connection != null) init(this.connection);  return this.attrTypes.length; } public OracleType getAttrTypeAt(int paramInt) throws SQLException { if (this.attrTypes == null && this.connection != null) init(this.connection);  return this.attrTypes[paramInt]; } public boolean isEmbeddedADT() throws SQLException { return ((this.statusBits & 0x2) != 0); } public boolean isUptADT() throws SQLException { return ((this.statusBits & 0x4) != 0); } public boolean isTopADT() throws SQLException { return ((this.statusBits & 0x1) != 0); } public void setStatus(int paramInt) throws SQLException { this.statusBits = paramInt; } void setEmbeddedADT() throws SQLException { maskAndSetStatusBits(-16, 2); } void setUptADT() throws SQLException { maskAndSetStatusBits(-16, 4); } public boolean isSubType() throws SQLException { return ((this.statusBits & 0x40) != 0); } public boolean isFinalType() throws SQLException { return (((this.statusBits & 0x20) != 0)) | (((this.statusBits & 0x2) != 0)); } public boolean isJavaObject() throws SQLException { return ((this.statusBits & 0x10) != 0); } public int getStatus() throws SQLException { if ((this.statusBits & 0x1) != 0 && (this.statusBits & 0x100) == 0) init(this.connection);  return this.statusBits; } public static OracleTypeADT shallowClone(OracleTypeADT paramOracleTypeADT) throws SQLException { OracleTypeADT oracleTypeADT = new OracleTypeADT(); shallowCopy(paramOracleTypeADT, oracleTypeADT); return oracleTypeADT; } public static void shallowCopy(OracleTypeADT paramOracleTypeADT1, OracleTypeADT paramOracleTypeADT2) throws SQLException { paramOracleTypeADT2.connection = paramOracleTypeADT1.connection; paramOracleTypeADT2.sqlName = paramOracleTypeADT1.sqlName; paramOracleTypeADT2.parent = paramOracleTypeADT1.parent; paramOracleTypeADT2.idx = paramOracleTypeADT1.idx; paramOracleTypeADT2.descriptor = paramOracleTypeADT1.descriptor; paramOracleTypeADT2.statusBits = paramOracleTypeADT1.statusBits; paramOracleTypeADT2.typeCode = paramOracleTypeADT1.typeCode; paramOracleTypeADT2.dbTypeCode = paramOracleTypeADT1.dbTypeCode; paramOracleTypeADT2.tdsVersion = paramOracleTypeADT1.tdsVersion; paramOracleTypeADT2.typeVersion = paramOracleTypeADT1.typeVersion; paramOracleTypeADT2.fixedDataSize = paramOracleTypeADT1.fixedDataSize; paramOracleTypeADT2.alignmentRequirement = paramOracleTypeADT1.alignmentRequirement; paramOracleTypeADT2.attrTypes = paramOracleTypeADT1.attrTypes; paramOracleTypeADT2.sqlName = paramOracleTypeADT1.sqlName; paramOracleTypeADT2.tdoCState = paramOracleTypeADT1.tdoCState; paramOracleTypeADT2.toid = paramOracleTypeADT1.toid; paramOracleTypeADT2.charSetId = paramOracleTypeADT1.charSetId; paramOracleTypeADT2.charSetForm = paramOracleTypeADT1.charSetForm; paramOracleTypeADT2.flattenedAttrNum = paramOracleTypeADT1.flattenedAttrNum; paramOracleTypeADT2.statusBits = paramOracleTypeADT1.statusBits; paramOracleTypeADT2.attrNames = paramOracleTypeADT1.attrNames; paramOracleTypeADT2.attrTypeNames = paramOracleTypeADT1.attrTypeNames; paramOracleTypeADT2.opcode = paramOracleTypeADT1.opcode; paramOracleTypeADT2.idx = paramOracleTypeADT1.idx; } private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException { paramObjectOutputStream.writeInt(this.statusBits); paramObjectOutputStream.writeInt(this.tdsVersion); paramObjectOutputStream.writeInt(this.typeVersion); paramObjectOutputStream.writeObject(null); paramObjectOutputStream.writeObject(null); paramObjectOutputStream.writeLong(this.fixedDataSize); paramObjectOutputStream.writeInt(this.alignmentRequirement); paramObjectOutputStream.writeObject(this.attrTypes); paramObjectOutputStream.writeObject(this.attrNames); paramObjectOutputStream.writeObject(this.attrTypeNames); paramObjectOutputStream.writeLong(this.tdoCState); paramObjectOutputStream.writeObject(this.toid); paramObjectOutputStream.writeObject(null); paramObjectOutputStream.writeInt(this.charSetId); paramObjectOutputStream.writeInt(this.charSetForm); paramObjectOutputStream.writeBoolean(true); paramObjectOutputStream.writeInt(this.flattenedAttrNum); } private void readObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException { this.statusBits = paramObjectInputStream.readInt(); this.tdsVersion = paramObjectInputStream.readInt(); this.typeVersion = paramObjectInputStream.readInt(); paramObjectInputStream.readObject(); paramObjectInputStream.readObject(); paramObjectInputStream.readLong(); paramObjectInputStream.readInt(); this.attrTypes = (OracleType[])paramObjectInputStream.readObject(); this.attrNames = (String[])paramObjectInputStream.readObject(); this.attrTypeNames = (String[])paramObjectInputStream.readObject(); paramObjectInputStream.readLong(); this.toid = (byte[])paramObjectInputStream.readObject(); paramObjectInputStream.readObject(); this.charSetId = paramObjectInputStream.readInt(); this.charSetForm = paramObjectInputStream.readInt(); paramObjectInputStream.readBoolean(); this.flattenedAttrNum = paramObjectInputStream.readInt(); } public void setConnection(OracleConnection paramOracleConnection) throws SQLException { synchronized (paramOracleConnection) { this.connection = paramOracleConnection; for (byte b = 0; b < this.attrTypes.length; b++) this.attrTypes[b].setConnection(this.connection);  }  } private void setStatusBits(int paramInt) { synchronized (this.connection) { this.statusBits |= paramInt; }  } private void maskAndSetStatusBits(int paramInt1, int paramInt2) { synchronized (this.connection) { this.statusBits &= paramInt1; this.statusBits |= paramInt2; }  } private void printUnsignedByteArray(byte[] paramArrayOfbyte, PrintWriter paramPrintWriter) { int i = paramArrayOfbyte.length; int[] arrayOfInt = Util.toJavaUnsignedBytes(paramArrayOfbyte); byte b; for (b = 0; b < i; b++) paramPrintWriter.print("0x" + Integer.toHexString(arrayOfInt[b]) + " ");  paramPrintWriter.println(); for (b = 0; b < i; b++) paramPrintWriter.print(arrayOfInt[b] + " ");  paramPrintWriter.println(); } public void initChildNamesRecursively(Map paramMap) throws SQLException { TypeTreeElement typeTreeElement = (TypeTreeElement)paramMap.get(this.sqlName); if (this.attrTypes != null && this.attrTypes.length > 0) for (byte b = 0; b < this.attrTypes.length; b++) { OracleType oracleType = this.attrTypes[b]; oracleType.setNames(typeTreeElement.getChildSchemaName(b + 1), typeTreeElement.getChildTypeName(b + 1)); oracleType.initChildNamesRecursively(paramMap); oracleType.cacheDescriptor(); }   } public void cacheDescriptor() throws SQLException { this.descriptor = (TypeDescriptor)StructDescriptor.createDescriptor(this); } private void initMetaData1() throws SQLException { short s = this.connection.getVersionNumber(); if (s >= 9000) { initMetaData1_9_0(); } else { initMetaData1_pre_9_0(); }  } public OracleTypeADT(SQLName paramSQLName, byte[] paramArrayOfbyte1, int paramInt, byte[] paramArrayOfbyte2, OracleConnection paramOracleConnection) throws SQLException { this.numberOfLocalAttributes = -1; this.LOCAL_TYPE = 0; this.LOOK_FOR_USER_SYNONYM = 1; this.LOOK_FOR_PUBLIC_SYNONYM = 2; this.initMetaData1_9_0_SQL = new String[] { "SELECT INSTANTIABLE, supertype_owner, supertype_name, LOCAL_ATTRIBUTES FROM all_types WHERE type_name = :1 AND owner = :2 ", "DECLARE \n bind_synonym_name user_synonyms.synonym_name%type := :1; \n the_table_owner  user_synonyms.table_owner%type; \n the_table_name   user_synonyms.table_name%type; \n the_db_link      user_synonyms.db_link%type; \n sql_string       VARCHAR2(1000); \nBEGIN \n   SELECT TABLE_NAME, TABLE_OWNER, DB_LINK INTO  \n         the_table_name, the_table_owner, the_db_link \n         FROM USER_SYNONYMS WHERE \n         SYNONYM_NAME = bind_synonym_name; \n \n   sql_string := 'SELECT INSTANTIABLE, SUPERTYPE_OWNER,      SUPERTYPE_NAME, LOCAL_ATTRIBUTES FROM ALL_TYPES'; \n \n   IF the_db_link IS NOT NULL  \n   THEN \n     sql_string := sql_string || '@' || the_db_link; \n   END IF; \n   sql_string := sql_string       || ' WHERE TYPE_NAME = '''       || the_table_name   || ''' AND OWNER = '''       || the_table_owner  || ''''; \n   OPEN :2 FOR sql_string; \nEND;", "DECLARE \n bind_synonym_name user_synonyms.synonym_name%type := :1; \n the_table_owner  user_synonyms.table_owner%type; \n the_table_name   user_synonyms.table_name%type; \n the_db_link      user_synonyms.db_link%type; \n sql_string       VARCHAR2(1000); \nBEGIN \n   SELECT TABLE_NAME, TABLE_OWNER, DB_LINK INTO  \n         the_table_name, the_table_owner, the_db_link \n         FROM ALL_SYNONYMS WHERE \n         OWNER = 'PUBLIC' AND \n         SYNONYM_NAME = bind_synonym_name; \n \n   sql_string := 'SELECT INSTANTIABLE, SUPERTYPE_OWNER,      SUPERTYPE_NAME, LOCAL_ATTRIBUTES FROM ALL_TYPES'; \n \n   IF the_db_link IS NOT NULL  \n   THEN \n     sql_string := sql_string || '@' || the_db_link; \n   END IF; \n   sql_string := sql_string       || ' WHERE TYPE_NAME = '''       || the_table_name   || ''' AND OWNER = '''       || the_table_owner  || ''''; \n   OPEN :2 FOR sql_string; \nEND;" }; this.sqlName = paramSQLName; init(paramArrayOfbyte2, paramOracleConnection); this.toid = paramArrayOfbyte1; this.typeVersion = paramInt; } public OracleTypeADT(AttributeDescriptor[] paramArrayOfAttributeDescriptor, OracleConnection paramOracleConnection) throws SQLException { this.numberOfLocalAttributes = -1; this.LOCAL_TYPE = 0; this.LOOK_FOR_USER_SYNONYM = 1; this.LOOK_FOR_PUBLIC_SYNONYM = 2; this.initMetaData1_9_0_SQL = new String[] { "SELECT INSTANTIABLE, supertype_owner, supertype_name, LOCAL_ATTRIBUTES FROM all_types WHERE type_name = :1 AND owner = :2 ", "DECLARE \n bind_synonym_name user_synonyms.synonym_name%type := :1; \n the_table_owner  user_synonyms.table_owner%type; \n the_table_name   user_synonyms.table_name%type; \n the_db_link      user_synonyms.db_link%type; \n sql_string       VARCHAR2(1000); \nBEGIN \n   SELECT TABLE_NAME, TABLE_OWNER, DB_LINK INTO  \n         the_table_name, the_table_owner, the_db_link \n         FROM USER_SYNONYMS WHERE \n         SYNONYM_NAME = bind_synonym_name; \n \n   sql_string := 'SELECT INSTANTIABLE, SUPERTYPE_OWNER,      SUPERTYPE_NAME, LOCAL_ATTRIBUTES FROM ALL_TYPES'; \n \n   IF the_db_link IS NOT NULL  \n   THEN \n     sql_string := sql_string || '@' || the_db_link; \n   END IF; \n   sql_string := sql_string       || ' WHERE TYPE_NAME = '''       || the_table_name   || ''' AND OWNER = '''       || the_table_owner  || ''''; \n   OPEN :2 FOR sql_string; \nEND;", "DECLARE \n bind_synonym_name user_synonyms.synonym_name%type := :1; \n the_table_owner  user_synonyms.table_owner%type; \n the_table_name   user_synonyms.table_name%type; \n the_db_link      user_synonyms.db_link%type; \n sql_string       VARCHAR2(1000); \nBEGIN \n   SELECT TABLE_NAME, TABLE_OWNER, DB_LINK INTO  \n         the_table_name, the_table_owner, the_db_link \n         FROM ALL_SYNONYMS WHERE \n         OWNER = 'PUBLIC' AND \n         SYNONYM_NAME = bind_synonym_name; \n \n   sql_string := 'SELECT INSTANTIABLE, SUPERTYPE_OWNER,      SUPERTYPE_NAME, LOCAL_ATTRIBUTES FROM ALL_TYPES'; \n \n   IF the_db_link IS NOT NULL  \n   THEN \n     sql_string := sql_string || '@' || the_db_link; \n   END IF; \n   sql_string := sql_string       || ' WHERE TYPE_NAME = '''       || the_table_name   || ''' AND OWNER = '''       || the_table_owner  || ''''; \n   OPEN :2 FOR sql_string; \nEND;" }; setConnectionInternal(paramOracleConnection); this.isTransient = true; this.flattenedAttrNum = paramArrayOfAttributeDescriptor.length; this.attrTypes = new OracleType[this.flattenedAttrNum]; this.attrNames = new String[this.flattenedAttrNum]; byte b; for (b = 0; b < this.flattenedAttrNum; b++)
      this.attrNames[b] = paramArrayOfAttributeDescriptor[b].getAttributeName();  this.statusBits |= 0x100; for (b = 0; b < this.flattenedAttrNum; b++) {
      SQLException sQLException; TypeDescriptor typeDescriptor = paramArrayOfAttributeDescriptor[b].getTypeDescriptor(); switch (typeDescriptor.getInternalTypeCode()) {
        case 12:
          this.attrTypes[b] = new OracleTypeDATE(); break;
        case 9:
          this.attrTypes[b] = new OracleTypeCHAR(this.connection, 12); ((OracleTypeCHAR)this.attrTypes[b]).length = (int)typeDescriptor.getPrecision(); ((OracleTypeCHAR)this.attrTypes[b]).form = 1; break;
        case 96:
          this.attrTypes[b] = new OracleTypeCHAR(this.connection, 1); ((OracleTypeCHAR)this.attrTypes[b]).length = (int)typeDescriptor.getPrecision(); ((OracleTypeCHAR)this.attrTypes[b]).form = 1; break;
        case 108:
          this.attrTypes[b] = typeDescriptor.getPickler(); ((OracleTypeADT)this.attrTypes[b]).setEmbeddedADT(); break;
        case 2:
          this.attrTypes[b] = new OracleTypeNUMBER(2); ((OracleTypeNUMBER)this.attrTypes[b]).precision = (int)typeDescriptor.getPrecision(); ((OracleTypeNUMBER)this.attrTypes[b]).scale = typeDescriptor.getScale(); break;
        case 7:
          this.attrTypes[b] = new OracleTypeNUMBER(3); ((OracleTypeNUMBER)this.attrTypes[b]).precision = (int)typeDescriptor.getPrecision(); ((OracleTypeNUMBER)this.attrTypes[b]).scale = typeDescriptor.getScale(); break;
        case 22:
          this.attrTypes[b] = new OracleTypeNUMBER(8); ((OracleTypeNUMBER)this.attrTypes[b]).precision = (int)typeDescriptor.getPrecision(); ((OracleTypeNUMBER)this.attrTypes[b]).scale = typeDescriptor.getScale(); break;
        case 4:
          this.attrTypes[b] = new OracleTypeFLOAT(); ((OracleTypeFLOAT)this.attrTypes[b]).precision = (int)typeDescriptor.getPrecision(); break;
        case 100:
          this.attrTypes[b] = new OracleTypeBINARY_FLOAT(); break;
        case 101:
          this.attrTypes[b] = new OracleTypeBINARY_DOUBLE(); break;
        case 29:
          this.attrTypes[b] = new OracleTypeSINT32(); break;
        case 110:
          this.attrTypes[b] = new OracleTypeREF(this, b, this.connection); break;
        case 114:
          this.attrTypes[b] = new OracleTypeBFILE(this.connection); break;
        case 95:
          this.attrTypes[b] = new OracleTypeRAW(); break;
        case 112:
          this.attrTypes[b] = new OracleTypeCLOB(this.connection); break;
        case 113:
          this.attrTypes[b] = new OracleTypeBLOB(this.connection); break;
        case 187:
          this.attrTypes[b] = new OracleTypeTIMESTAMP(this.connection); ((OracleTypeTIMESTAMP)this.attrTypes[b]).precision = (int)typeDescriptor.getPrecision(); break;
        case 188:
          this.attrTypes[b] = new OracleTypeTIMESTAMPTZ(this.connection); ((OracleTypeTIMESTAMPTZ)this.attrTypes[b]).precision = (int)typeDescriptor.getPrecision(); break;
        case 232:
          this.attrTypes[b] = new OracleTypeTIMESTAMPLTZ(this.connection); ((OracleTypeTIMESTAMPLTZ)this.attrTypes[b]).precision = (int)typeDescriptor.getPrecision(); break;
        case 189:
          this.attrTypes[b] = new OracleTypeINTERVAL(this.connection); ((OracleTypeINTERVAL)this.attrTypes[b]).typeId = 7; ((OracleTypeINTERVAL)this.attrTypes[b]).precision = (int)typeDescriptor.getPrecision(); ((OracleTypeINTERVAL)this.attrTypes[b]).scale = typeDescriptor.getScale(); break;
        case 190:
          this.attrTypes[b] = new OracleTypeINTERVAL(this.connection); ((OracleTypeINTERVAL)this.attrTypes[b]).typeId = 10;
          ((OracleTypeINTERVAL)this.attrTypes[b]).precision = (int)typeDescriptor.getPrecision();
          ((OracleTypeINTERVAL)this.attrTypes[b]).scale = typeDescriptor.getScale();
          break;
        case 122:
          this.attrTypes[b] = new OracleTypeCOLLECTION(this, b, this.connection);
          break;
        default:
          sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 48, "type: " + typeDescriptor.getInternalTypeCode());
          sQLException.fillInStackTrace();
          throw sQLException;
      } 
    }  } public Boolean isInstanciable() throws SQLException { if (this.isInstanciable == null)
      initMetaData1(); 
    return this.isInstanciable; }
  public String getSuperTypeName() throws SQLException { if (this.superTypeName == null)
      initMetaData1(); 
    return this.superTypeName; }
  public int getNumberOfLocalAttributes() throws SQLException { if (this.numberOfLocalAttributes == -1)
      initMetaData1(); 
    return this.numberOfLocalAttributes; }
  public String[] getSubtypeNames() throws SQLException { if (this.subTypeNames == null)
      initMetaData1(); 
    return this.subTypeNames; }
  private void initMetaData1_9_0() throws SQLException { if (getTOID() != null) {
      initMetaData1_9_0UseToid();
      
      return;
    } 
    byte b = 0;

    
    if (this.sqlName == null) {
      getFullName();
    }
    synchronized (this.connection) {
      
      synchronized (this) {
        
        if (this.numberOfLocalAttributes == -1) {
          
          PreparedStatement preparedStatement = null;
          OracleCallableStatement oracleCallableStatement = null;
          ResultSet resultSet = null;
          int i = -1;



          
          try {
            while (true) {
              switch (b) {
                
                case false:
                  preparedStatement = this.connection.prepareStatement(this.initMetaData1_9_0_SQL[b]);

                  
                  preparedStatement.setString(1, this.sqlName.getSimpleName());
                  preparedStatement.setString(2, this.sqlName.getSchema());
                  
                  preparedStatement.setFetchSize(1);
                  resultSet = preparedStatement.executeQuery();
                  break;


                
                case true:
                case true:
                  try {
                    oracleCallableStatement = (OracleCallableStatement)this.connection.prepareCall(this.initMetaData1_9_0_SQL[b]);

                    
                    oracleCallableStatement.setString(1, this.sqlName.getSimpleName());
                    oracleCallableStatement.registerOutParameter(2, -10);

                    
                    oracleCallableStatement.execute();
                    
                    resultSet = oracleCallableStatement.getCursor(2);
                    resultSet.setFetchSize(1);
                  } catch (SQLException sQLException) {
                    
                    if (sQLException.getErrorCode() == 1403) {
                      
                      if (b == 1) {
                        
                        oracleCallableStatement.close();
                        b++;

                        
                        continue;
                      } 
                      
                      SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Inconsistent catalog view");
                      sQLException1.fillInStackTrace();
                      throw sQLException1;
                    } 


                    
                    throw sQLException;
                  } 
                  break;
              } 


              
              if (resultSet.next()) {
                
                this.isInstanciable = new Boolean(resultSet.getString(1).equals("YES"));
                this.superTypeName = resultSet.getString(2) + "." + resultSet.getString(3);
                i = resultSet.getInt(4);

                
                break;
              } 

              
              if (b == 2) {


                
                SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Inconsistent catalog view");
                sQLException.fillInStackTrace();
                throw sQLException;
              } 

              
              resultSet.close();
              if (oracleCallableStatement != null)
                oracleCallableStatement.close(); 
              b++;
            
            }
          
          }
          finally {
            
            if (resultSet != null) {
              resultSet.close();
            }
            if (preparedStatement != null) {
              preparedStatement.close();
            }
            if (oracleCallableStatement != null) {
              oracleCallableStatement.close();
            }
          } 
          this.numberOfLocalAttributes = i;
        } 
      } 
    }  }





  
  private void initMetaData1_9_0UseToid() throws SQLException {
    String str = "SELECT INSTANTIABLE, supertype_owner, supertype_name, LOCAL_ATTRIBUTES, cursor(select owner, type_name from all_types WHERE supertype_name = t.type_name and supertype_owner = t.owner)  FROM all_types t WHERE TYPE_OID = :3";



    
    PreparedStatement preparedStatement = null;
    ResultSet resultSet1 = null;
    ResultSet resultSet2 = null;

    
    if (this.sqlName == null) {
      getFullName();
    }
    
    try {
      preparedStatement = this.connection.prepareStatement(str);
      preparedStatement.setBytes(1, getTOID());
      
      preparedStatement.setFetchSize(1);
      resultSet1 = preparedStatement.executeQuery();
      if (resultSet1.next()) {
        
        this.isInstanciable = new Boolean(resultSet1.getString(1).equals("YES"));
        this.superTypeName = resultSet1.getString(2) + "." + resultSet1.getString(3);
        this.numberOfLocalAttributes = resultSet1.getInt(4);
        resultSet2 = (ResultSet)resultSet1.getObject(5);

        
        ArrayList<String> arrayList = new ArrayList(5);
        while (resultSet2.next()) {
          arrayList.add(resultSet2.getString(1) + "." + resultSet2.getString(2));
        }
        this.subTypeNames = new String[arrayList.size()];
        for (byte b = 0; b < this.subTypeNames.length; b++) {
          this.subTypeNames[b] = arrayList.get(b);
        }
      }
      else {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Inconsistent catalog view");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    } finally {
      
      if (resultSet2 != null) resultSet2.close(); 
      if (resultSet1 != null) resultSet1.close(); 
      if (preparedStatement != null) preparedStatement.close();
    
    } 
  }






  
  private synchronized void initMetaData1_pre_9_0() throws SQLException {
    this.isInstanciable = new Boolean(true);
    this.superTypeName = "";
    this.numberOfLocalAttributes = 0;
  }








  
  private void initMetaData2() throws SQLException {
    short s = this.connection.getVersionNumber();
    
    if (s >= 9000) {
      initMetaData2_9_0();
    } else {
      
      initMetaData2_pre_9_0();
    } 
  }







  
  private void initMetaData2_9_0() throws SQLException {
    if (getTOID() != null) {
      initMetaData1_9_0UseToid();
      
      return;
    } 
    
    if (this.sqlName == null) {
      getFullName();
    }
    synchronized (this.connection) {
      
      synchronized (this) {
        
        if (this.subTypeNames == null) {
          
          PreparedStatement preparedStatement = null;
          ResultSet resultSet = null;
          String[] arrayOfString = null;

          
          try {
            preparedStatement = this.connection.prepareStatement("select owner, type_name from all_types where supertype_name = :1 and supertype_owner = :2");

            
            preparedStatement.setString(1, this.sqlName.getSimpleName());
            preparedStatement.setString(2, this.sqlName.getSchema());
            
            resultSet = preparedStatement.executeQuery();
            
            Vector<String> vector = new Vector();
            
            while (resultSet.next()) {
              vector.addElement(resultSet.getString(1) + "." + resultSet.getString(2));
            }
            arrayOfString = new String[vector.size()];
            
            for (byte b = 0; b < arrayOfString.length; b++) {
              arrayOfString[b] = vector.elementAt(b);
            }
            vector.removeAllElements();
            
            vector = null;
          }
          finally {
            
            if (resultSet != null) {
              resultSet.close();
            }
            if (preparedStatement != null) {
              preparedStatement.close();
            }
          } 
          this.subTypeNames = arrayOfString;
        } 
      } 
    } 
  }











  
  private void initMetaData2_pre_9_0() throws SQLException {
    this.subTypeNames = new String[0];
  }







  
  public void printXML(PrintWriter paramPrintWriter, int paramInt) throws SQLException {
    printXML(paramPrintWriter, paramInt, false);
  }





  
  public void printXML(PrintWriter paramPrintWriter, int paramInt, boolean paramBoolean) throws SQLException {
    byte b;
    for (b = 0; b < paramInt; ) { paramPrintWriter.print("  "); b++; }
     paramPrintWriter.print("<OracleTypeADT sqlName=\"" + this.sqlName + "\" ");
    
    paramPrintWriter.print(" typecode=\"" + this.typeCode + "\"");
    if (this.tdsVersion != -9999)
      paramPrintWriter.print(" tds_version=\"" + this.tdsVersion + "\""); 
    paramPrintWriter.println();
    for (b = 0; b < paramInt + 4; ) { paramPrintWriter.print("  "); b++; }
     paramPrintWriter.println(" is_embedded=\"" + isEmbeddedADT() + "\"" + " is_top_level=\"" + isTopADT() + "\"" + " is_upt=\"" + isUptADT() + "\"" + " finalType=\"" + isFinalType() + "\"" + " subtype=\"" + isSubType() + "\">");




    
    if (this.attrTypes != null && this.attrTypes.length > 0) {
      
      for (b = 0; b < paramInt + 1; ) { paramPrintWriter.print("  "); b++; }
       paramPrintWriter.println("<attributes>");
      for (b = 0; b < this.attrTypes.length; b++) {
        byte b1;
        for (b1 = 0; b1 < paramInt + 2; ) { paramPrintWriter.print("  "); b1++; }

        
        paramPrintWriter.println("<attribute name=\"" + getAttributeName(b + 1, paramBoolean) + "\" " + " type=\"" + getAttributeType(b + 1, false) + "\" >");

        
        this.attrTypes[b].printXML(paramPrintWriter, paramInt + 3, paramBoolean);
        for (b1 = 0; b1 < paramInt + 2; ) { paramPrintWriter.print("  "); b1++; }
         paramPrintWriter.println("</attribute> ");
      } 
      for (b = 0; b < paramInt + 1; ) { paramPrintWriter.print("  "); b++; }
       paramPrintWriter.println("</attributes>");
    } 
    for (b = 0; b < paramInt; ) { paramPrintWriter.print("  "); b++; }
     paramPrintWriter.println("</OracleTypeADT>");
  }
























































  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
