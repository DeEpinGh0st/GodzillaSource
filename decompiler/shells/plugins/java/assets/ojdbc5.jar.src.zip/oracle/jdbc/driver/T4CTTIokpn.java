package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.TIMESTAMPTZ;





































































































































final class T4CTTIokpn
  extends T4CTTIfun
{
  static final int REGISTER_KPNDEF = 1;
  static final int UNREGISTER_KPNDEF = 2;
  static final int POST_KPNDEF = 3;
  static final int EXISTINGCLIENT_KPNDEF = 0;
  static final int NEWCLIENT_KPNDEF = 1;
  static final int KPUN_PRS_RAW = 1;
  static final int KPUN_VER_10200 = 2;
  static final int KPUN_VER_11100 = 3;
  static final int KPUN_VER_11200 = 4;
  static final int OCI_SUBSCR_NAMESPACE_ANONYMOUS = 0;
  static final int OCI_SUBSCR_NAMESPACE_AQ = 1;
  static final int OCI_SUBSCR_NAMESPACE_DBCHANGE = 2;
  static final int OCI_SUBSCR_NAMESPACE_MAX = 3;
  static final int KPD_CHNF_OPFILTER = 1;
  static final int KPD_CHNF_INSERT = 2;
  static final int KPD_CHNF_UPDATE = 4;
  static final int KPD_CHNF_DELETE = 8;
  static final int KPD_CHNF_ROWID = 16;
  static final int KPD_CQ_QUERYNF = 32;
  static final int KPD_CQ_BEST_EFFORT = 64;
  static final int KPD_CQ_CLQRYCACHE = 128;
  static final int KPD_CHNF_INVALID_REGID = 0;
  static final int SUBSCR_QOS_RELIABLE = 1;
  static final int SUBSCR_QOS_PAYLOAD = 2;
  static final int SUBSCR_QOS_REPLICATE = 4;
  static final int SUBSCR_QOS_SECURE = 8;
  static final int SUBSCR_QOS_PURGE_ON_NTFN = 16;
  static final int SUBSCR_QOS_MULTICBK = 32;
  static final byte SUBSCR_NTFN_GROUPING_CLASS_NONE = 0;
  static final byte SUBSCR_NTFN_GROUPING_CLASS_TIME = 1;
  static final byte SUBSCR_NTFN_GROUPING_TYPE_SUMMARY = 1;
  static final byte SUBSCR_NTFN_GROUPING_TYPE_LAST = 2;
  private int opcode;
  private int mode;
  private int nbOfRegistrationInfo;
  private String user;
  private String location;
  private int[] namespace;
  private int[] kpdnrgrpval;
  private int[] kpdnrgrprepcnt;
  private int[] payloadType;
  private int[] qosFlags;
  private int[] timeout;
  private int[] dbchangeOpFilter;
  private int[] dbchangeTxnLag;
  private byte[][] registeredAgentName;
  private byte[][] kpdnrcx;
  private byte[] kpdnrgrpcla;
  private byte[] kpdnrgrptyp;
  private TIMESTAMPTZ[] kpdnrgrpstatim;
  private long[] dbchangeRegistrationId;
  private byte[] userArr;
  private byte[] locationArr;
  private long regid;
  
  T4CTTIokpn(T4CConnection paramT4CConnection) {
    super(paramT4CConnection, (byte)3);








    
    this.dbchangeTxnLag = null;
    this.registeredAgentName = (byte[][])null;
    this.kpdnrcx = (byte[][])null;
    this.kpdnrgrptyp = null;
    this.kpdnrgrpstatim = null;
    this.dbchangeRegistrationId = null;
    this.userArr = null;
    this.locationArr = null;
    
    this.regid = 0L;
    setFunCode((short)125);
  }






















  
  void doOKPN(int paramInt1, int paramInt2, String paramString1, String paramString2, int paramInt3, int[] paramArrayOfint1, String[] paramArrayOfString, byte[][] paramArrayOfbyte, int[] paramArrayOfint2, int[] paramArrayOfint3, int[] paramArrayOfint4, int[] paramArrayOfint5, int[] paramArrayOfint6, long[] paramArrayOflong, byte[] paramArrayOfbyte1, int[] paramArrayOfint7, byte[] paramArrayOfbyte2, TIMESTAMPTZ[] paramArrayOfTIMESTAMPTZ, int[] paramArrayOfint8) throws IOException, SQLException {
    this.opcode = paramInt1;
    this.mode = paramInt2;
    this.user = paramString1;
    this.location = paramString2;
    this.nbOfRegistrationInfo = paramInt3;
    this.namespace = paramArrayOfint1;
    this.kpdnrcx = paramArrayOfbyte;
    this.payloadType = paramArrayOfint2;
    this.qosFlags = paramArrayOfint3;
    this.timeout = paramArrayOfint4;
    this.dbchangeOpFilter = paramArrayOfint5;
    this.dbchangeTxnLag = paramArrayOfint6;
    this.dbchangeRegistrationId = paramArrayOflong;
    this.kpdnrgrpcla = paramArrayOfbyte1;
    this.kpdnrgrpval = paramArrayOfint7;
    this.kpdnrgrptyp = paramArrayOfbyte2;
    this.kpdnrgrpstatim = paramArrayOfTIMESTAMPTZ;
    this.kpdnrgrprepcnt = paramArrayOfint8;
    
    this.registeredAgentName = new byte[this.nbOfRegistrationInfo][];
    for (byte b = 0; b < this.nbOfRegistrationInfo; b++) {
      if (paramArrayOfString[b] != null)
        this.registeredAgentName[b] = this.meg.conv.StringToCharBytes(paramArrayOfString[b]); 
    } 
    if (this.user != null) {
      this.userArr = this.meg.conv.StringToCharBytes(this.user);
    } else {
      this.userArr = null;
    } 
    if (this.location != null) {
      this.locationArr = this.meg.conv.StringToCharBytes(this.location);
    } else {
      this.locationArr = null;
    } 
    
    this.regid = 0L;
    
    doRPC();
  }




  
  void marshal() throws IOException {
    boolean bool = true;
    byte b1 = 2;

    
    this.meg.marshalUB1((short)(byte)this.opcode);
    
    this.meg.marshalUB4(this.mode);
    
    if (this.userArr != null) {
      
      this.meg.marshalPTR();
      this.meg.marshalUB4(this.userArr.length);
    }
    else {
      
      this.meg.marshalNULLPTR();
      this.meg.marshalUB4(0L);
    } 

    
    if (this.locationArr != null) {
      
      this.meg.marshalPTR();
      this.meg.marshalUB4(this.locationArr.length);
    }
    else {
      
      this.meg.marshalNULLPTR();
      this.meg.marshalUB4(0L);
    } 

    
    this.meg.marshalPTR();
    this.meg.marshalUB4(this.nbOfRegistrationInfo);
    
    this.meg.marshalUB2(bool);
    
    this.meg.marshalUB2(b1);
    if (this.connection.getTTCVersion() >= 4) {

      
      this.meg.marshalNULLPTR();
      
      this.meg.marshalPTR();
      
      if (this.connection.getTTCVersion() >= 5) {

        
        this.meg.marshalNULLPTR();
        
        this.meg.marshalPTR();
      } 
    } 


    
    if (this.userArr != null)
      this.meg.marshalCHR(this.userArr); 
    if (this.locationArr != null) {
      this.meg.marshalCHR(this.locationArr);
    }
    for (byte b2 = 0; b2 < this.nbOfRegistrationInfo; b2++) {

      
      this.meg.marshalUB4(this.namespace[b2]);
      
      byte[] arrayOfByte = this.registeredAgentName[b2];
      
      if (arrayOfByte != null && arrayOfByte.length > 0) {
        
        this.meg.marshalUB4(arrayOfByte.length);
        this.meg.marshalCLR(arrayOfByte, 0, arrayOfByte.length);
      } else {
        
        this.meg.marshalUB4(0L);
      } 
      if (this.kpdnrcx[b2] != null && (this.kpdnrcx[b2]).length > 0) {
        
        this.meg.marshalUB4((this.kpdnrcx[b2]).length);
        this.meg.marshalCLR(this.kpdnrcx[b2], 0, (this.kpdnrcx[b2]).length);
      } else {
        
        this.meg.marshalUB4(0L);
      } 
      this.meg.marshalUB4(this.payloadType[b2]);
      if (this.connection.getTTCVersion() >= 4) {

        
        this.meg.marshalUB4(this.qosFlags[b2]);
        byte[] arrayOfByte1 = new byte[0];
        this.meg.marshalUB4(arrayOfByte1.length);
        if (arrayOfByte1.length > 0) {
          this.meg.marshalCLR(arrayOfByte1, arrayOfByte1.length);
        }
        this.meg.marshalUB4(this.timeout[b2]);
        
        boolean bool1 = false;
        this.meg.marshalUB4(bool1);
        
        this.meg.marshalUB4(this.dbchangeOpFilter[b2]);
        
        this.meg.marshalUB4(this.dbchangeTxnLag[b2]);
        this.meg.marshalUB4((int)this.dbchangeRegistrationId[b2]);
        
        if (this.connection.getTTCVersion() >= 5) {
          
          this.meg.marshalUB1((short)this.kpdnrgrpcla[b2]);
          this.meg.marshalUB4(this.kpdnrgrpval[b2]);
          this.meg.marshalUB1((short)this.kpdnrgrptyp[b2]);
          if (this.kpdnrgrpstatim[b2] == null) {
            this.meg.marshalDALC(null);
          } else {
            this.meg.marshalDALC(this.kpdnrgrpstatim[b2].shareBytes());
          }  this.meg.marshalSB4(this.kpdnrgrprepcnt[b2]);

          
          this.meg.marshalSB8(this.dbchangeRegistrationId[b2]);
        } 
      } 
    } 
  }



  
  long getRegistrationId() {
    return this.regid;
  }






  
  void readRPA() throws IOException, SQLException {
    int i = (int)this.meg.unmarshalUB4();
    for (byte b = 0; b < i; b++)
      this.meg.unmarshalUB4(); 
    int[] arrayOfInt = new int[i]; int j;
    for (j = 0; j < i; j++)
      arrayOfInt[j] = (int)this.meg.unmarshalUB4(); 
    this.regid = arrayOfInt[0];
    if (this.connection.getTTCVersion() >= 5) {
      
      j = (int)this.meg.unmarshalUB4();
      long l = this.meg.unmarshalSB8();
      this.regid = l;
    } 
  }











  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return this.connection;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
