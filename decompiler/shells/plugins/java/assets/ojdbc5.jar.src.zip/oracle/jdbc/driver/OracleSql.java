package oracle.jdbc.driver;

import java.io.PrintWriter;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.internal.OracleStatement;





























public class OracleSql
{
  static final int UNINITIALIZED = -1;
  static final String[] EMPTY_LIST = new String[0];
  
  DBConversion conversion;
  
  String originalSql;
  
  String parameterSql;
  
  String utickSql;
  String processedSql;
  String rowidSql;
  String actualSql;
  byte[] sqlBytes;
  OracleStatement.SqlKind sqlKind = OracleStatement.SqlKind.UNINITIALIZED;
  byte sqlKindByte = -1;
  int parameterCount = -1;
  int returningIntoParameterCount = -1;
  boolean currentConvertNcharLiterals = true;
  boolean currentProcessEscapes = true;
  boolean includeRowid = false;
  String[] parameterList = EMPTY_LIST;
  char[] currentParameter = null;
  
  int bindParameterCount = -1;
  String[] bindParameterList = null;
  int cachedBindParameterCount = -1;
  String[] cachedBindParameterList = null;
  String cachedParameterSql;
  String cachedUtickSql;
  String cachedProcessedSql;
  String cachedRowidSql;
  String cachedActualSql;
  byte[] cachedSqlBytes;
  int selectEndIndex = -1;
  int orderByStartIndex = -1;
  int orderByEndIndex = -1;
  int whereStartIndex = -1;
  int whereEndIndex = -1;
  int forUpdateStartIndex = -1;
  int forUpdateEndIndex = -1;
  
  int[] ncharLiteralLocation = new int[513];
  int lastNcharLiteralLocation = -1;
  
  static final String paramPrefix = "rowid";
  int paramSuffix = 0;







  
  StringBuffer stringBufferForScrollableStatement;







  
  private static final int cMax = 127;







  
  protected void initialize(String paramString) throws SQLException {
    if (paramString == null || paramString.length() == 0) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 104);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.originalSql = paramString;
    this.utickSql = null;
    this.processedSql = null;
    this.rowidSql = null;
    this.actualSql = null;
    this.sqlBytes = null;
    this.sqlKind = OracleStatement.SqlKind.UNINITIALIZED;
    this.parameterCount = -1;
    this.parameterList = EMPTY_LIST;
    this.includeRowid = false;
    
    this.parameterSql = this.originalSql;
    this.bindParameterCount = -1;
    this.bindParameterList = null;
    this.cachedBindParameterCount = -1;
    this.cachedBindParameterList = null;
    this.cachedParameterSql = null;
    this.cachedActualSql = null;
    this.cachedProcessedSql = null;
    this.cachedRowidSql = null;
    this.cachedSqlBytes = null;
    this.selectEndIndex = -1;
    this.orderByStartIndex = -1;
    this.orderByEndIndex = -1;
    this.whereStartIndex = -1;
    this.whereEndIndex = -1;
    this.forUpdateStartIndex = -1;
    this.forUpdateEndIndex = -1;
  }










  
  String getOriginalSql() {
    return this.originalSql;
  }








  
  boolean setNamedParameters(int paramInt, String[] paramArrayOfString) throws SQLException {
    boolean bool = false;
    
    if (paramInt == 0) {
      
      this.bindParameterCount = -1;
      bool = (this.bindParameterCount != this.cachedBindParameterCount) ? true : false;
    }
    else {
      
      this.bindParameterCount = paramInt;
      this.bindParameterList = paramArrayOfString;
      bool = (this.bindParameterCount != this.cachedBindParameterCount) ? true : false;
      
      if (!bool) {
        for (byte b = 0; b < paramInt; b++) {
          if (this.bindParameterList[b] != this.cachedBindParameterList[b]) {
            
            bool = true;
            break;
          } 
        } 
      }
      if (bool) {
        
        if (this.bindParameterCount != getParameterCount()) {
          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 197);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 
        
        char[] arrayOfChar = this.originalSql.toCharArray();
        StringBuffer stringBuffer = new StringBuffer();
        
        byte b1 = 0;
        
        for (byte b2 = 0; b2 < arrayOfChar.length; b2++) {
          
          if (arrayOfChar[b2] != '?') {
            
            stringBuffer.append(arrayOfChar[b2]);
          }
          else {
            
            stringBuffer.append(this.bindParameterList[b1++]);
            stringBuffer.append("=>" + nextArgument());
          } 
        } 
        
        this.parameterSql = stringBuffer.toString();
        this.actualSql = null;
        this.utickSql = null;
        this.processedSql = null;
        this.rowidSql = null;
        this.sqlBytes = null;
      }
      else {
        
        this.parameterSql = this.cachedParameterSql;
        this.actualSql = this.cachedActualSql;
        this.utickSql = this.cachedUtickSql;
        this.processedSql = this.cachedProcessedSql;
        this.rowidSql = this.cachedRowidSql;
        this.sqlBytes = this.cachedSqlBytes;
      } 
    } 
    
    this.cachedBindParameterList = null;
    this.cachedParameterSql = null;
    this.cachedActualSql = null;
    this.cachedUtickSql = null;
    this.cachedProcessedSql = null;
    this.cachedRowidSql = null;
    this.cachedSqlBytes = null;
    
    return bool;
  }






  
  void resetNamedParameters() {
    this.cachedBindParameterCount = this.bindParameterCount;
    
    if (this.bindParameterCount != -1) {
      
      if (this.cachedBindParameterList == null || this.cachedBindParameterList == this.bindParameterList || this.cachedBindParameterList.length < this.bindParameterCount)
      {
        
        this.cachedBindParameterList = new String[this.bindParameterCount];
      }
      System.arraycopy(this.bindParameterList, 0, this.cachedBindParameterList, 0, this.bindParameterCount);

      
      this.cachedParameterSql = this.parameterSql;
      this.cachedActualSql = this.actualSql;
      this.cachedUtickSql = this.utickSql;
      this.cachedProcessedSql = this.processedSql;
      this.cachedRowidSql = this.rowidSql;
      this.cachedSqlBytes = this.sqlBytes;
      
      this.bindParameterCount = -1;
      this.bindParameterList = null;
      this.parameterSql = this.originalSql;
      this.actualSql = null;
      this.utickSql = null;
      this.processedSql = null;
      this.rowidSql = null;
      this.sqlBytes = null;
    } 
  }














  
  String getSql(boolean paramBoolean1, boolean paramBoolean2) throws SQLException {
    if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) {
      computeBasicInfo(this.parameterSql);
    }
    
    if (paramBoolean1 != this.currentProcessEscapes || paramBoolean2 != this.currentConvertNcharLiterals) {

      
      if (paramBoolean2 != this.currentConvertNcharLiterals) {
        this.utickSql = null;
      }
      
      this.processedSql = null;
      this.rowidSql = null;
      this.actualSql = null;
      this.sqlBytes = null;
    } 
    
    this.currentConvertNcharLiterals = paramBoolean2;
    this.currentProcessEscapes = paramBoolean1;
    
    if (this.actualSql == null) {
      if (this.utickSql == null) {
        this.utickSql = this.currentConvertNcharLiterals ? convertNcharLiterals(this.parameterSql) : this.parameterSql;
      }
      
      if (this.processedSql == null) {
        this.processedSql = this.currentProcessEscapes ? parse(this.utickSql) : this.utickSql;
      }
      if (this.rowidSql == null) {
        this.rowidSql = this.includeRowid ? addRowid(this.processedSql) : this.processedSql;
      }
      this.actualSql = this.rowidSql;
    } 

    
    return this.actualSql;
  }





  
  String getRevisedSql() throws SQLException {
    String str = null;
    
    if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) computeBasicInfo(this.parameterSql);
    
    str = removeForUpdate(this.parameterSql);
    
    return addRowid(str);
  }











  
  String removeForUpdate(String paramString) throws SQLException {
    if (this.orderByStartIndex != -1 && (this.forUpdateStartIndex == -1 || this.forUpdateStartIndex > this.orderByStartIndex)) {


      
      paramString = paramString.substring(0, this.orderByStartIndex);
    }
    else if (this.forUpdateStartIndex != -1) {
      
      paramString = paramString.substring(0, this.forUpdateStartIndex);
    } 
    
    return paramString;
  }














  
  void appendForUpdate(StringBuffer paramStringBuffer) throws SQLException {
    if (this.orderByStartIndex != -1 && (this.forUpdateStartIndex == -1 || this.forUpdateStartIndex > this.orderByStartIndex)) {


      
      paramStringBuffer.append(this.originalSql.substring(this.orderByStartIndex));
    }
    else if (this.forUpdateStartIndex != -1) {
      
      paramStringBuffer.append(this.originalSql.substring(this.forUpdateStartIndex));
    } 
  }
  
  protected OracleSql(DBConversion paramDBConversion) {
    this.stringBufferForScrollableStatement = null;
    this.conversion = paramDBConversion;
  }








  
  String getInsertSqlForUpdatableResultSet(UpdatableResultSet paramUpdatableResultSet) throws SQLException {
    String str = getOriginalSql();
    boolean bool = generatedSqlNeedEscapeProcessing();
    
    if (this.stringBufferForScrollableStatement == null) {
      this.stringBufferForScrollableStatement = new StringBuffer(str.length() + 100);
    } else {
      this.stringBufferForScrollableStatement.delete(0, this.stringBufferForScrollableStatement.length());
    } 
    this.stringBufferForScrollableStatement.append("insert into (");
    
    this.stringBufferForScrollableStatement.append(removeForUpdate(str));
    this.stringBufferForScrollableStatement.append(") values ( ");
    
    byte b = 1;
    for (; b < paramUpdatableResultSet.getColumnCount(); 
      b++) {
      
      if (b != 1) {
        this.stringBufferForScrollableStatement.append(", ");
      }
      if (bool) {
        this.stringBufferForScrollableStatement.append("?");
      } else {
        this.stringBufferForScrollableStatement.append(":" + generateParameterName());
      } 
    } 
    this.stringBufferForScrollableStatement.append(")");
    
    this.paramSuffix = 0;
    
    return this.stringBufferForScrollableStatement.substring(0, this.stringBufferForScrollableStatement.length());
  }
















  
  String getRefetchSqlForScrollableResultSet(ScrollableResultSet paramScrollableResultSet, int paramInt) throws SQLException {
    String str = getRevisedSql();
    boolean bool = generatedSqlNeedEscapeProcessing();
    
    if (this.stringBufferForScrollableStatement == null) {
      this.stringBufferForScrollableStatement = new StringBuffer(str.length() + 100);
    } else {
      this.stringBufferForScrollableStatement.delete(0, this.stringBufferForScrollableStatement.length());
    } 
    
    this.stringBufferForScrollableStatement.append(str);
    
    if (this.whereStartIndex == -1) {
      
      this.stringBufferForScrollableStatement.append(bool ? " WHERE ( ROWID = ?" : (" WHERE ( ROWID = :" + generateParameterName()));
    } else {
      
      this.stringBufferForScrollableStatement.append(bool ? " AND ( ROWID = ?" : (" AND ( ROWID = :" + generateParameterName()));
    } 
    
    for (byte b = 0; b < paramInt - 1; b++) {
      if (bool) {
        this.stringBufferForScrollableStatement.append(" OR ROWID = ?");
      } else {
        
        this.stringBufferForScrollableStatement.append(" OR ROWID = :" + generateParameterName());
      } 
    }  this.stringBufferForScrollableStatement.append(" ) ");

    
    appendForUpdate(this.stringBufferForScrollableStatement);
    
    this.paramSuffix = 0;
    
    return this.stringBufferForScrollableStatement.substring(0, this.stringBufferForScrollableStatement.length());
  }














  
  String getUpdateSqlForUpdatableResultSet(UpdatableResultSet paramUpdatableResultSet, int paramInt, Object[] paramArrayOfObject, int[] paramArrayOfint) throws SQLException {
    String str = getRevisedSql();
    boolean bool = generatedSqlNeedEscapeProcessing();
    
    if (this.stringBufferForScrollableStatement == null) {
      this.stringBufferForScrollableStatement = new StringBuffer(str.length() + 100);
    } else {
      this.stringBufferForScrollableStatement.delete(0, this.stringBufferForScrollableStatement.length());
    } 

    
    this.stringBufferForScrollableStatement.append("update (");
    this.stringBufferForScrollableStatement.append(str);
    this.stringBufferForScrollableStatement.append(") set ");

    
    if (paramArrayOfObject != null)
    {
      for (byte b = 0; b < paramInt; b++) {
        
        if (b > 0) {
          this.stringBufferForScrollableStatement.append(", ");
        }
        this.stringBufferForScrollableStatement.append(paramUpdatableResultSet.getInternalMetadata().getColumnName(paramArrayOfint[b] + 1));

        
        if (bool) {
          this.stringBufferForScrollableStatement.append(" = ?");
        } else {
          this.stringBufferForScrollableStatement.append(" = :" + generateParameterName());
        } 
      } 
    }
    
    this.stringBufferForScrollableStatement.append(" WHERE ");
    if (bool) {
      this.stringBufferForScrollableStatement.append(" ROWID = ?");
    } else {
      this.stringBufferForScrollableStatement.append(" ROWID = :" + generateParameterName());
    } 
    
    this.paramSuffix = 0;
    
    return this.stringBufferForScrollableStatement.substring(0, this.stringBufferForScrollableStatement.length());
  }












  
  String getDeleteSqlForUpdatableResultSet(UpdatableResultSet paramUpdatableResultSet) throws SQLException {
    String str = getRevisedSql();
    boolean bool = generatedSqlNeedEscapeProcessing();
    
    if (this.stringBufferForScrollableStatement == null) {
      this.stringBufferForScrollableStatement = new StringBuffer(str.length() + 100);
    } else {
      this.stringBufferForScrollableStatement.delete(0, this.stringBufferForScrollableStatement.length());
    } 

    
    this.stringBufferForScrollableStatement.append("delete from (");
    this.stringBufferForScrollableStatement.append(str);
    this.stringBufferForScrollableStatement.append(") where ");
    
    if (bool) {
      this.stringBufferForScrollableStatement.append(" ROWID = ?");
    } else {
      this.stringBufferForScrollableStatement.append(" ROWID = :" + generateParameterName());
    } 
    
    this.paramSuffix = 0;
    
    return this.stringBufferForScrollableStatement.substring(0, this.stringBufferForScrollableStatement.length());
  }








  
  final boolean generatedSqlNeedEscapeProcessing() {
    return (this.parameterCount > 0 && this.parameterList == EMPTY_LIST);
  }









  
  byte[] getSqlBytes(boolean paramBoolean1, boolean paramBoolean2) throws SQLException {
    if (this.sqlBytes == null || paramBoolean1 != this.currentProcessEscapes)
    {
      this.sqlBytes = this.conversion.StringToCharBytes(getSql(paramBoolean1, paramBoolean2));
    }

    
    return this.sqlBytes;
  }










  
  OracleStatement.SqlKind getSqlKind() throws SQLException {
    if (this.parameterSql == null) {
      return OracleStatement.SqlKind.UNINITIALIZED;
    }
    if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) {
      computeBasicInfo(this.parameterSql);
    }
    return this.sqlKind;
  }










  
  protected int getParameterCount() throws SQLException {
    if (this.parameterCount == -1)
    {
      computeBasicInfo(this.parameterSql);
    }
    
    return this.parameterCount;
  }













  
  protected String[] getParameterList() throws SQLException {
    if (this.parameterCount == -1)
    {
      computeBasicInfo(this.parameterSql);
    }
    
    return this.parameterList;
  }











  
  void setIncludeRowid(boolean paramBoolean) {
    if (paramBoolean != this.includeRowid) {
      
      this.includeRowid = paramBoolean;
      this.rowidSql = null;
      this.actualSql = null;
      this.sqlBytes = null;
    } 
  }




  
  public String toString() {
    return (this.parameterSql == null) ? "null" : this.parameterSql;
  }












  
  private String hexUnicode(int paramInt) throws SQLException {
    String str = Integer.toHexString(paramInt);
    switch (str.length()) {
      case 0:
        return "\\0000";
      case 1: return "\\000" + str;
      case 2: return "\\00" + str;
      case 3: return "\\0" + str;
      case 4: return "\\" + str;
    } 
    
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89, "Unexpected case in OracleSql.hexUnicode: " + paramInt);
    sQLException.fillInStackTrace();
    throw sQLException;
  }



















  
  String convertNcharLiterals(String paramString) throws SQLException {
    if (this.lastNcharLiteralLocation <= 2) return paramString; 
    String str = "";
    byte b = 0;
    
    while (true) {
      int i = this.ncharLiteralLocation[b++];
      int j = this.ncharLiteralLocation[b++];
      
      str = str + paramString.substring(i, j);
      if (b >= this.lastNcharLiteralLocation)
        break;  i = this.ncharLiteralLocation[b];
      str = str + "u'";
      
      for (int k = j + 2; k < i; k++) {
        
        char c = paramString.charAt(k);
        if (c == '\\') { str = str + "\\\\"; }
        else if (c < '') { str = str + c; }
        else { str = str + hexUnicode(c); }
      
      } 
    }  return str;
  }





  
  private static final int[][] TRANSITION = OracleSqlReadOnly.TRANSITION;

  
  private static final int[][] ACTION = OracleSqlReadOnly.ACTION;
  
  private static final int NO_ACTION = 0;
  
  private static final int DELETE_ACTION = 1;
  
  private static final int INSERT_ACTION = 2;
  
  private static final int MERGE_ACTION = 3;
  
  private static final int UPDATE_ACTION = 4;
  
  private static final int PLSQL_ACTION = 5;
  
  private static final int CALL_ACTION = 6;
  private static final int SELECT_ACTION = 7;
  private static final int ORDER_ACTION = 10;
  private static final int ORDER_BY_ACTION = 11;
  private static final int WHERE_ACTION = 9;
  private static final int FOR_ACTION = 12;
  private static final int FOR_UPDATE_ACTION = 13;
  private static final int OTHER_ACTION = 8;
  private static final int QUESTION_ACTION = 14;
  private static final int PARAMETER_ACTION = 15;
  private static final int END_PARAMETER_ACTION = 16;
  private static final int START_NCHAR_LITERAL_ACTION = 17;
  private static final int END_NCHAR_LITERAL_ACTION = 18;
  private static final int SAVE_DELIMITER_ACTION = 19;
  private static final int LOOK_FOR_DELIMITER_ACTION = 20;
  private static final int ALTER_SESSION_ACTION = 21;
  private static final int RETURNING_ACTION = 22;
  private static final int INTO_ACTION = 23;
  private static final int INITIAL_STATE = 0;
  private static final int RESTART_STATE = 66;
  private static final OracleSqlReadOnly.ODBCAction[][] ODBC_ACTION = OracleSqlReadOnly.ODBC_ACTION;

  
  private static final boolean DEBUG_CBI = false;

  
  int current_argument;

  
  int i;

  
  int length;

  
  char currentChar;

  
  boolean first;

  
  String odbc_sql;

  
  StringBuffer oracle_sql;

  
  StringBuffer token_buffer;

  
  void computeBasicInfo(String paramString) throws SQLException {
    this.parameterCount = 0;
    boolean bool1 = false;
    boolean bool2 = false;
    this.returningIntoParameterCount = 0;
    
    this.lastNcharLiteralLocation = 0;
    this.ncharLiteralLocation[this.lastNcharLiteralLocation++] = 0;
    
    byte b1 = 0;
    
    byte b2 = 0;
    
    int i = 0;
    int j = paramString.length();
    int k = -1;
    int m = -1;
    int n = j + 1;

    
    for (byte b3 = 0; b3 < n; b3++) {
      
      byte b = (b3 < j) ? paramString.charAt(b3) : 32;
      this.currentChar = b;
      
      if (b > 127)
      {



        
        if (Character.isLetterOrDigit(b)) {
          this.currentChar = 'X';
        } else {
          this.currentChar = ' ';
        } 
      }

      
      switch (ACTION[i][this.currentChar]) {




        
        case 1:
          this.sqlKind = OracleStatement.SqlKind.DELETE;
          break;

        
        case 2:
          this.sqlKind = OracleStatement.SqlKind.INSERT;
          break;

        
        case 3:
          this.sqlKind = OracleStatement.SqlKind.MERGE;
          break;

        
        case 4:
          this.sqlKind = OracleStatement.SqlKind.UPDATE;
          break;

        
        case 5:
          this.sqlKind = OracleStatement.SqlKind.PLSQL_BLOCK;
          break;

        
        case 6:
          this.sqlKind = OracleStatement.SqlKind.CALL_BLOCK;
          break;

        
        case 7:
          this.sqlKind = OracleStatement.SqlKind.SELECT;
          this.selectEndIndex = b3;
          break;

        
        case 8:
          this.sqlKind = OracleStatement.SqlKind.OTHER;
          break;

        
        case 9:
          this.whereStartIndex = b3 - 5;
          this.whereEndIndex = b3;
          break;

        
        case 10:
          k = b3 - 5;
          break;

        
        case 11:
          this.orderByStartIndex = k;
          this.orderByEndIndex = b3;
          break;

        
        case 12:
          m = b3 - 3;
          break;

        
        case 13:
          this.forUpdateStartIndex = m;
          this.forUpdateEndIndex = b3;
          if (this.sqlKind == OracleStatement.SqlKind.SELECT) {
            this.sqlKind = OracleStatement.SqlKind.SELECT_FOR_UPDATE;
          }
          break;
        
        case 21:
          this.sqlKind = OracleStatement.SqlKind.ALTER_SESSION;
          break;

        
        case 14:
          this.parameterCount++;
          if (bool2) this.returningIntoParameterCount++;
          
          break;
        
        case 15:
          if (this.currentParameter == null) {
            this.currentParameter = new char[32];
          }
          if (b2 >= this.currentParameter.length) {
            
            SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 134, new String(this.currentParameter));
            sQLException.fillInStackTrace();
            throw sQLException;
          } 
          
          this.currentParameter[b2++] = b;
          break;

        
        case 16:
          if (b2 > 0) {
            
            if (this.parameterList == EMPTY_LIST) {
              
              this.parameterList = new String[Math.max(8, this.parameterCount * 4)];
            }
            else if (this.parameterList.length <= this.parameterCount) {
              
              String[] arrayOfString = new String[this.parameterList.length * 4];
              
              System.arraycopy(this.parameterList, 0, arrayOfString, 0, this.parameterList.length);

              
              this.parameterList = arrayOfString;
            } 
            
            this.parameterList[this.parameterCount] = (new String(this.currentParameter, 0, b2)).intern();
            
            b2 = 0;
            this.parameterCount++;
            if (bool2) this.returningIntoParameterCount++;
          
          } 
          break;
        
        case 17:
          this.ncharLiteralLocation[this.lastNcharLiteralLocation++] = b3 - 1;
          if (this.lastNcharLiteralLocation >= this.ncharLiteralLocation.length) {
            growNcharLiteralLocation(this.ncharLiteralLocation.length << 2);
          }
          break;
        case 18:
          this.ncharLiteralLocation[this.lastNcharLiteralLocation++] = b3;
          if (this.lastNcharLiteralLocation >= this.ncharLiteralLocation.length) {
            growNcharLiteralLocation(this.ncharLiteralLocation.length << 2);
          }
          break;
        
        case 19:
          if (b == 91) { b1 = 93; break; }
           if (b == 123) { b1 = 125; break; }
           if (b == 60) { b1 = 62; break; }
           if (b == 40) { b1 = 41; break; }
           b1 = b;
          break;
        
        case 20:
          if (b == b1)
          {
            
            i++;
          }
          break;

        
        case 22:
          bool1 = true;
          break;
        
        case 23:
          if (bool1) bool2 = true;
          
          break;
      } 
      i = TRANSITION[i][this.currentChar];
    } 
    
    if (this.lastNcharLiteralLocation + 2 >= this.ncharLiteralLocation.length)
      growNcharLiteralLocation(this.lastNcharLiteralLocation + 2); 
    this.ncharLiteralLocation[this.lastNcharLiteralLocation++] = j;
    this.ncharLiteralLocation[this.lastNcharLiteralLocation] = j;
  }




  
  void growNcharLiteralLocation(int paramInt) {
    int[] arrayOfInt = new int[paramInt];
    System.arraycopy(this.ncharLiteralLocation, 0, arrayOfInt, 0, this.ncharLiteralLocation.length);
    this.ncharLiteralLocation = null;
    this.ncharLiteralLocation = arrayOfInt;
  }



  
  private String addRowid(String paramString) throws SQLException {
    if (this.selectEndIndex == -1) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 88);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    return "select rowid as \"__Oracle_JDBC_interal_ROWID__\"," + paramString.substring(this.selectEndIndex);
  }










  
  enum ParseMode
  {
    NORMAL, SCALAR, LOCATE_1, LOCATE_2;
  }















  
  String parse(String paramString) throws SQLException {
    this.first = true;
    this.current_argument = 1;
    this.i = 0;
    this.odbc_sql = paramString;
    this.length = this.odbc_sql.length();
    
    if (this.oracle_sql == null) {
      
      this.oracle_sql = new StringBuffer(this.length);
      this.token_buffer = new StringBuffer(32);
    }
    else {
      
      this.oracle_sql.ensureCapacity(this.length);
    } 
    
    this.oracle_sql.delete(0, this.oracle_sql.length());
    skipSpace();
    handleODBC(ParseMode.NORMAL);
    
    if (this.i < this.length) {
      
      Integer integer = Integer.valueOf(this.i);

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 33, integer);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    return this.oracle_sql.substring(0, this.oracle_sql.length());
  }






  
  void handleODBC(ParseMode paramParseMode) throws SQLException {
    int i = (paramParseMode == ParseMode.NORMAL) ? 0 : 66;
    byte b1 = 0;
    byte b2 = 0;
    
    while (this.i < this.length) {
      SQLException sQLException;
      byte b = (this.i < this.length) ? this.odbc_sql.charAt(this.i) : 32;
      this.currentChar = b;
      
      if (b > 127)
      {



        
        if (Character.isLetterOrDigit(b)) {
          this.currentChar = 'X';
        } else {
          this.currentChar = ' ';
        } 
      }

      
      switch (ODBC_ACTION[i][this.currentChar]) {




        
        case COPY:
          this.oracle_sql.append(b);
          break;
        
        case QUESTION:
          this.oracle_sql.append(nextArgument());
          this.oracle_sql.append(' ');
          break;
        
        case SAVE_DELIMITER:
          if (b == 91) { b1 = 93; }
          else if (b == 123) { b1 = 125; }
          else if (b == 60) { b1 = 62; }
          else if (b == 40) { b1 = 41; }
          else { b1 = b; }
           this.oracle_sql.append(b);
          break;
        
        case LOOK_FOR_DELIMITER:
          if (b == b1)
          {
            
            i++;
          }
          this.oracle_sql.append(b);
          break;
        
        case FUNCTION:
          handleFunction();
          break;
        
        case CALL:
          handleCall();
          break;
        
        case TIME:
          handleTime();
          break;
        
        case TIMESTAMP:
          handleTimestamp();
          break;
        
        case DATE:
          handleDate();
          break;
        
        case ESCAPE:
          handleEscape();
          break;
        
        case SCALAR_FUNCTION:
          handleScalarFunction();
          break;
        
        case OUTER_JOIN:
          handleOuterJoin();
          break;

        
        case UNKNOWN_ESCAPE:
          sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, Integer.valueOf(this.i));
          sQLException.fillInStackTrace();
          throw sQLException;

        
        case END_ODBC_ESCAPE:
          if (paramParseMode == ParseMode.SCALAR) {
            
            i = TRANSITION[i][this.currentChar];
            return;
          } 


        
        case COMMA:
          if (paramParseMode == ParseMode.LOCATE_1 && b2 > 1) {
            this.oracle_sql.append(b); break;
          } 
          if (paramParseMode == ParseMode.LOCATE_1) {
            
            i = TRANSITION[i][this.currentChar];
            return;
          } 
          if (paramParseMode == ParseMode.LOCATE_2) {
            break;
          }

          
          this.oracle_sql.append(b);
          break;

        
        case OPEN_PAREN:
          if (paramParseMode == ParseMode.LOCATE_1) {
            if (b2 > 0) this.oracle_sql.append(b); 
            b2++; break;
          } 
          if (paramParseMode == ParseMode.LOCATE_2) {
            b2++;
            this.oracle_sql.append(b);
            
            break;
          } 
          this.oracle_sql.append(b);
          break;

        
        case CLOSE_PAREN:
          if (paramParseMode == ParseMode.LOCATE_1) {
            b2--;
            this.oracle_sql.append(b); break;
          } 
          if (paramParseMode == ParseMode.LOCATE_2 && b2 > 1) {
            b2--;
            this.oracle_sql.append(b); break;
          } 
          if (paramParseMode == ParseMode.LOCATE_2) {
            this.i++;
            
            i = TRANSITION[i][this.currentChar];
            
            return;
          } 
          
          this.oracle_sql.append(b);
          break;

        
        case BEGIN:
          this.first = false;
          this.oracle_sql.append(b);
          break;
      } 

      
      i = TRANSITION[i][this.currentChar];
      this.i++;
    } 
  }




  
  void handleFunction() throws SQLException {
    boolean bool = this.first;
    this.first = false;
    
    if (bool) {
      this.oracle_sql.append("BEGIN ");
    }
    appendChar(this.oracle_sql, '?');
    skipSpace();
    
    if (this.currentChar != '=') {
      
      String str = this.i + ". Expecting \"=\" got \"" + this.currentChar + "\"";

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 33, str);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    this.i++;
    
    skipSpace();
    
    if (!this.odbc_sql.startsWith("call", this.i)) {
      
      String str = this.i + ". Expecting \"call\"";

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 33, str);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    this.i += 4;
    
    this.oracle_sql.append(" := ");
    skipSpace();
    handleODBC(ParseMode.SCALAR);
    
    if (bool) {
      this.oracle_sql.append("; END;");
    }
  }



  
  void handleCall() throws SQLException {
    boolean bool = this.first;
    this.first = false;
    
    if (bool) {
      this.oracle_sql.append("BEGIN ");
    }
    skipSpace();
    handleODBC(ParseMode.SCALAR);
    skipSpace();
    
    if (bool) {
      this.oracle_sql.append("; END;");
    }
  }




  
  void handleTimestamp() throws SQLException {
    this.oracle_sql.append("TO_TIMESTAMP (");
    skipSpace();
    handleODBC(ParseMode.SCALAR);
    this.oracle_sql.append(", 'YYYY-MM-DD HH24:MI:SS.FF')");
  }



  
  void handleTime() throws SQLException {
    this.oracle_sql.append("TO_DATE (");
    skipSpace();
    handleODBC(ParseMode.SCALAR);
    this.oracle_sql.append(", 'HH24:MI:SS')");
  }



  
  void handleDate() throws SQLException {
    this.oracle_sql.append("TO_DATE (");
    skipSpace();
    handleODBC(ParseMode.SCALAR);
    this.oracle_sql.append(", 'YYYY-MM-DD')");
  }



  
  void handleEscape() throws SQLException {
    this.oracle_sql.append("ESCAPE ");
    skipSpace();
    handleODBC(ParseMode.SCALAR);
  }



  
  void handleScalarFunction() throws SQLException {
    this.token_buffer.delete(0, this.token_buffer.length());
    
    this.i++;
    
    skipSpace();


    
    while (this.i < this.length && (Character.isJavaLetterOrDigit(this.currentChar = this.odbc_sql.charAt(this.i)) || this.currentChar == '?')) {

      
      this.token_buffer.append(this.currentChar);
      
      this.i++;
    } 



    
    String str = this.token_buffer.substring(0, this.token_buffer.length()).toUpperCase().intern();






    
    if (str == "ABS")
    { usingFunctionName(str); }
    else if (str == "ACOS")
    { usingFunctionName(str); }
    else if (str == "ASIN")
    { usingFunctionName(str); }
    else if (str == "ATAN")
    { usingFunctionName(str); }
    else if (str == "ATAN2")
    { usingFunctionName(str); }
    else if (str == "CEILING")
    { usingFunctionName("CEIL"); }
    else if (str == "COS")
    { usingFunctionName(str); }
    else { if (str == "COT") {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      if (str == "DEGREES") {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      if (str == "EXP")
      { usingFunctionName(str); }
      else if (str == "FLOOR")
      { usingFunctionName(str); }
      else if (str == "LOG")
      { usingFunctionName("LN"); }
      else if (str == "LOG10")
      { replacingFunctionPrefix("LOG ( 10, "); }
      else if (str == "MOD")
      { usingFunctionName(str); }
      else if (str == "PI")
      { replacingFunctionPrefix("( 3.141592653589793238462643383279502884197169399375 "); }
      else if (str == "POWER")
      { usingFunctionName(str); }
      else { if (str == "RADIANS") {
          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 
        if (str == "RAND") {
          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 
        if (str == "ROUND")
        { usingFunctionName(str); }
        else if (str == "SIGN")
        { usingFunctionName(str); }
        else if (str == "SIN")
        { usingFunctionName(str); }
        else if (str == "SQRT")
        { usingFunctionName(str); }
        else if (str == "TAN")
        { usingFunctionName(str); }
        else if (str == "TRUNCATE")
        { usingFunctionName("TRUNC");
           }
        
        else if (str == "ASCII")
        { usingFunctionName(str); }
        else if (str == "CHAR")
        { usingFunctionName("CHR");
          
           }
        
        else if (str == "CONCAT")
        { usingFunctionName(str); }
        else { if (str == "DIFFERENCE") {
            
            SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
            sQLException.fillInStackTrace();
            throw sQLException;
          } 
          if (str == "INSERT") {
            
            SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
            sQLException.fillInStackTrace();
            throw sQLException;
          } 
          if (str == "LCASE")
          { usingFunctionName("LOWER"); }
          else { if (str == "LEFT") {
              
              SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
              sQLException.fillInStackTrace();
              throw sQLException;
            } 
            if (str == "LENGTH") {
              usingFunctionName(str);
            } else if (str == "LOCATE") {


              
              StringBuffer stringBuffer1 = this.oracle_sql;
              this.oracle_sql = new StringBuffer();
              handleODBC(ParseMode.LOCATE_1);
              StringBuffer stringBuffer2 = this.oracle_sql;
              this.oracle_sql = stringBuffer1;
              this.oracle_sql.append("INSTR(");
              handleODBC(ParseMode.LOCATE_2);
              this.oracle_sql.append(',');
              this.oracle_sql.append(stringBuffer2);
              this.oracle_sql.append(')');
              handleODBC(ParseMode.SCALAR);
            }
            else if (str == "LTRIM") {
              usingFunctionName(str);
            }
            else {
              
              if (str == "REPEAT") {
                
                SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
                sQLException.fillInStackTrace();
                throw sQLException;
              } 
              if (str == "REPLACE")
              { usingFunctionName(str); }
              else { if (str == "RIGHT") {
                  
                  SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
                  sQLException.fillInStackTrace();
                  throw sQLException;
                } 
                if (str == "RTRIM")
                { usingFunctionName(str); }
                else if (str == "SOUNDEX")
                { usingFunctionName(str); }
                else { if (str == "SPACE") {
                    
                    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
                    sQLException.fillInStackTrace();
                    throw sQLException;
                  } 
                  if (str == "SUBSTRING")
                  { usingFunctionName("SUBSTR"); }
                  else if (str == "UCASE")
                  { usingFunctionName("UPPER");



                    
                     }
                  
                  else if (str == "CURDATE")
                  { replacingFunctionPrefix("(CURRENT_DATE"); }
                  else if (str == "CURTIME")
                  { replacingFunctionPrefix("(CURRENT_TIMESTAMP"); }
                  else { if (str == "DAYNAME") {
                      
                      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
                      sQLException.fillInStackTrace();
                      throw sQLException;
                    } 
                    if (str == "DAYOFMONTH")
                    { replacingFunctionPrefix("EXTRACT ( DAY FROM "); }
                    else { if (str == "DAYOFWEEK") {
                        
                        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
                        sQLException.fillInStackTrace();
                        throw sQLException;
                      } 
                      if (str == "DAYOFYEAR") {
                        
                        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
                        sQLException.fillInStackTrace();
                        throw sQLException;
                      } 


                      
                      if (str == "HOUR")
                      { replacingFunctionPrefix("EXTRACT ( HOUR FROM "); }
                      else if (str == "MINUTE")
                      { replacingFunctionPrefix("EXTRACT ( MINUTE FROM "); }
                      else if (str == "MONTH")
                      { replacingFunctionPrefix("EXTRACT ( MONTH FROM "); }
                      else { if (str == "MONTHNAME") {
                          
                          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
                          sQLException.fillInStackTrace();
                          throw sQLException;
                        } 
                        if (str == "NOW")
                        { replacingFunctionPrefix("(CURRENT_TIMESTAMP"); }
                        else { if (str == "QUARTER") {
                            
                            SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
                            sQLException.fillInStackTrace();
                            throw sQLException;
                          } 
                          if (str == "SECOND")
                          { replacingFunctionPrefix("EXTRACT ( SECOND FROM "); }
                          else { if (str == "TIMESTAMPADD") {
                              
                              SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
                              sQLException.fillInStackTrace();
                              throw sQLException;
                            } 
                            if (str == "TIMESTAMPDIFF") {
                              
                              SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
                              sQLException.fillInStackTrace();
                              throw sQLException;
                            } 
                            if (str == "WEEK") {
                              
                              SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
                              sQLException.fillInStackTrace();
                              throw sQLException;
                            } 
                            if (str == "YEAR")
                            { replacingFunctionPrefix("EXTRACT ( YEAR FROM "); }
                            else
                            
                            { if (str == "DATABASE") {
                                
                                SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
                                sQLException.fillInStackTrace();
                                throw sQLException;
                              } 
                              if (str == "IFNULL")
                              { usingFunctionName("NVL"); }
                              else if (str == "USER")
                              { replacingFunctionPrefix("(USER"); }
                              else
                              
                              { if (str == "CONVERT") {

                                  
                                  SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
                                  sQLException1.fillInStackTrace();
                                  throw sQLException1;
                                } 



                                
                                SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
                                sQLException.fillInStackTrace();
                                throw sQLException; }  }  }  }  }  }  }
                   }
                 }
            
            }  }
           }
         }
       }
     } void usingFunctionName(String paramString) throws SQLException { this.oracle_sql.append(paramString);
    skipSpace();
    handleODBC(ParseMode.SCALAR); }




  
  void replacingFunctionPrefix(String paramString) throws SQLException {
    skipSpace();

    
    if (this.i < this.length && (this.currentChar = this.odbc_sql.charAt(this.i)) == '(') {
      this.i++;
    } else {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 33);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.oracle_sql.append(paramString);
    skipSpace();
    handleODBC(ParseMode.SCALAR);
  }



  
  void handleOuterJoin() throws SQLException {
    this.oracle_sql.append(" ( ");
    skipSpace();
    handleODBC(ParseMode.SCALAR);
    this.oracle_sql.append(" ) ");
  }



  
  String nextArgument() {
    String str = ":" + this.current_argument;
    
    this.current_argument++;
    
    return str;
  }



  
  void appendChar(StringBuffer paramStringBuffer, char paramChar) {
    if (paramChar == '?') {
      paramStringBuffer.append(nextArgument());
    } else {
      paramStringBuffer.append(paramChar);
    } 
  }


  
  void skipSpace() {
    while (this.i < this.length && (this.currentChar = this.odbc_sql.charAt(this.i)) == ' ') {
      this.i++;
    }
  }





  
  String generateParameterName() {
    String str;
    if (this.parameterCount == 0 || this.parameterList == null)
    {
      return "rowid" + this.paramSuffix++;
    }


    
    label13: while (true) {
      str = "rowid" + this.paramSuffix++;
      for (byte b = 0; b < this.parameterList.length; b++)
      
      { if (str.equals(this.parameterList[b]))
          continue label13;  }  break;
    }  return str;
  }
















  
  static boolean isValidPlsqlWarning(String paramString) throws SQLException {
    return paramString.matches("('\\s*([a-zA-Z0-9:,\\(\\)\\s])*')\\s*(,\\s*'([a-zA-Z0-9:,\\(\\)\\s])*')*");
  }














  
  public static boolean isValidObjectName(String paramString) throws SQLException {
    if (paramString.matches("([a-zA-Z]{1}\\w*(\\$|\\#)*\\w*)|(\".*)"))
    {
      return true;
    }




    
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;

    
    if (!Character.isLetter(arrayOfChar[0]))
    {
      return false;
    }
    
    for (byte b = 1; b < i; b++) {
      
      if (!Character.isLetterOrDigit(arrayOfChar[b]) && arrayOfChar[b] != '$' && arrayOfChar[b] != '#' && arrayOfChar[b] != '_')
      {


        
        return false;
      }
    } 
    
    return true;
  }




















  
  public static void main(String[] paramArrayOfString) {
    String[] arrayOfString;
    if (paramArrayOfString.length < 2) {
      System.err.println("ERROR: incorrect usage. OracleSql (-transition <file> | <process_escapes> <convert_nchars> { <sql> } )");
      return;
    } 
    if (paramArrayOfString[0].equals("-dump")) {
      dumpTransitionMatrix(paramArrayOfString[1]);
      return;
    } 
    boolean bool1 = paramArrayOfString[0].equals("true");
    boolean bool2 = paramArrayOfString[1].equals("true");

    
    if (paramArrayOfString.length > 2) {
      arrayOfString = new String[paramArrayOfString.length - 2];
      System.arraycopy(paramArrayOfString, 2, arrayOfString, 0, arrayOfString.length);
    } else {
      
      arrayOfString = new String[] { "select ? from dual", "insert into dual values (?)", "delete from dual", "update dual set dummy = ?", "merge tab into dual", " select ? from dual where ? = ?", "select ?from dual where?=?for update", "select '?', n'?', q'???', q'{?}', q'{cat's}' from dual", "select'?',n'?',q'???',q'{?}',q'{cat's}'from dual", "select--line\n? from dual", "select --line\n? from dual", "--line\nselect ? from dual", " --line\nselect ? from dual", "--line\n select ? from dual", "begin proc4in4out (:x1, :x2, :x3, :x4); end;", "{CALL tkpjpn01(:pin, :pinout, :pout)}", "select :NumberBindVar as the_number from dual", "select {fn locate(bob(carol(),ted(alice,sue)), 'xfy')} from dual", "CREATE USER vijay6 IDENTIFIED BY \"vjay?\"", "ALTER SESSION SET TIME", "SELECT ename FROM emp WHERE hiredate BETWEEN {ts'1980-12-17'} AND {ts '1981-09-28'} " };
    } 


























    
    for (String str : arrayOfString) {
      try {
        System.out.println("\n\n-----------------------");
        System.out.println(str);
        System.out.println();
        OracleSql oracleSql = new OracleSql(null);
        
        oracleSql.initialize(str);
        String str1 = oracleSql.getSql(bool1, bool2);
        
        System.out.println(oracleSql.sqlKind + ", " + oracleSql.parameterCount);
        
        String[] arrayOfString1 = oracleSql.getParameterList();
        
        if (arrayOfString1 == EMPTY_LIST) {
          System.out.println("parameterList is empty");
        } else {
          for (byte b = 0; b < arrayOfString1.length; b++)
            System.out.println("parameterList[" + b + "] = " + arrayOfString1[b]); 
        } 
        if (oracleSql.getSqlKind().isDML()) {
          int i = oracleSql.getReturnParameterCount();
          if (i == -1) { System.out.println("no return parameters"); }
          else { System.out.println(i + " return parameters"); }
        
        } 
        if (oracleSql.lastNcharLiteralLocation == 2) { System.out.println("No NCHAR literals"); }
        else
        { System.out.println("NCHAR Literals");
          for (byte b = 1; b < oracleSql.lastNcharLiteralLocation - 1;)
            System.out.println(str1.substring(oracleSql.ncharLiteralLocation[b++], oracleSql.ncharLiteralLocation[b++]));  }
        
        System.out.println("Keywords");
        if (oracleSql.selectEndIndex == -1) { System.out.println("no select"); }
        else { System.out.println("'" + str1.substring(oracleSql.selectEndIndex - 6, oracleSql.selectEndIndex) + "'"); }
         if (oracleSql.orderByStartIndex == -1) { System.out.println("no order by"); }
        else { System.out.println("'" + str1.substring(oracleSql.orderByStartIndex, oracleSql.orderByEndIndex) + "'"); }
         if (oracleSql.whereStartIndex == -1) { System.out.println("no where"); }
        else { System.out.println("'" + str1.substring(oracleSql.whereStartIndex, oracleSql.whereEndIndex) + "'"); }
         if (oracleSql.forUpdateStartIndex == -1) { System.out.println("no for update"); }
        else { System.out.println("'" + str1.substring(oracleSql.forUpdateStartIndex, oracleSql.forUpdateEndIndex) + "'"); }
        
        System.out.println("isPlsqlOrCall(): " + oracleSql.getSqlKind().isPlsqlOrCall());
        System.out.println("isDML(): " + oracleSql.getSqlKind().isDML());
        System.out.println("isSELECT(): " + oracleSql.getSqlKind().isSELECT());
        System.out.println("isOTHER(): " + oracleSql.getSqlKind().isOTHER());
        System.out.println("\"" + str1 + "\"");
        System.out.println("\"" + oracleSql.getRevisedSql() + "\"");
      }
      catch (Exception exception) {
        System.out.println(exception);
      } 
    } 
  }
  
  private static final void dumpTransitionMatrix(String paramString) {
    try {
      PrintWriter printWriter = new PrintWriter(paramString);
      printWriter.print(",");
      for (byte b1 = 0; b1 < ''; ) { printWriter.print("'" + ((b1 < 32) ? ("0x" + Integer.toHexString(b1)) : Character.toString((char)b1)) + ((b1 < 127) ? "'," : "'")); b1++; }
       printWriter.println();
      int[][] arrayOfInt = OracleSqlReadOnly.TRANSITION;
      String[] arrayOfString = OracleSqlReadOnly.PARSER_STATE_NAME;
      for (byte b2 = 0; b2 < TRANSITION.length; b2++) {
        printWriter.print(arrayOfString[b2] + ",");
        for (byte b = 0; b < (arrayOfInt[b2]).length; ) { printWriter.print(arrayOfString[arrayOfInt[b2][b]] + ((b < 127) ? "," : "")); b++; }
         printWriter.println();
      } 
      printWriter.close();
    }
    catch (Throwable throwable) {
      System.err.println(throwable);
    } 
  }












  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }









  
  int getReturnParameterCount() throws SQLException {
    if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) {
      computeBasicInfo(this.parameterSql);
    }
    
    if (!this.sqlKind.isDML()) return -1; 
    return this.returningIntoParameterCount;
  }




  
  private int getSubstrPos(String paramString1, String paramString2) throws SQLException {
    int i = -1;
    int j = paramString1.indexOf(paramString2);
    
    if (j >= 1 && Character.isWhitespace(paramString1.charAt(j - 1))) {

      
      int k = j + paramString2.length();
      
      if (k < paramString1.length() && Character.isWhitespace(paramString1.charAt(k)))
      {
        
        i = j;
      }
    } 
    return i;
  }



  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
