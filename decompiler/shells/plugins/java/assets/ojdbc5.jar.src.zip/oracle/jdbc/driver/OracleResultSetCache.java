package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleResultSetCache;

public interface OracleResultSetCache extends OracleResultSetCache {}
