package oracle.jdbc.rowset;

import javax.sql.RowSet;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;





























class OracleWebRowSetXmlReaderDomHandler
  extends OracleWebRowSetXmlReaderContHandler
{
  OracleWebRowSetXmlReaderDomHandler(RowSet paramRowSet) {
    super(paramRowSet);
  }




  
  void readXMLDocument(Document paramDocument) throws SAXException {
    Element element = paramDocument.getDocumentElement();
    startElement(null, null, "webRowSet", null);

    
    Node node1 = element.getElementsByTagName("properties").item(0);
    
    startElement(null, null, "properties", null);

    
    NodeList nodeList1 = node1.getChildNodes();
    int i = nodeList1.getLength();



    
    for (byte b1 = 0; b1 < i; b1++) {
      
      Node node = nodeList1.item(b1);

      
      if (!(node instanceof org.w3c.dom.Text)) {


        
        String str1 = node.getNodeName();
        startElement(null, null, str1, null);


        
        if (node.hasChildNodes()) {
          
          processElement(node.getFirstChild().getNodeValue());

        
        }
        else {

          
          processElement("");
        } 
        
        endElement(null, null, str1);
      } 
    } 
    endElement(null, null, "properties");

    
    Node node2 = element.getElementsByTagName("metadata").item(0);
    
    startElement(null, null, "metadata", null);

    
    Node node3 = node2.getFirstChild().getNextSibling();
    
    String str = node3.getNodeName();
    startElement(null, null, str, null);

    
    processElement(node3.getFirstChild().getNodeValue());
    endElement(null, null, str);

    
    NodeList nodeList2 = node2.getChildNodes();
    int j = nodeList2.getLength();

    
    for (byte b2 = 3; b2 < j; b2++) {
      
      Node node = nodeList2.item(b2);

      
      NodeList nodeList = node.getChildNodes();
      int m = nodeList.getLength();
      
      for (byte b = 0; b < m; b++) {
        
        Node node5 = nodeList.item(b);

        
        if (!(node5 instanceof org.w3c.dom.Text)) {


          
          String str1 = node5.getNodeName();
          startElement(null, null, str1, null);


          
          if (node5.hasChildNodes()) {
            
            processElement(node5.getFirstChild().getNodeValue());

          
          }
          else {

            
            processElement("");
          } 
          
          endElement(null, null, str1);
        } 
      } 
    } 
    endElement(null, null, "metadata");

    
    Node node4 = element.getElementsByTagName("data").item(0);
    startElement(null, null, "data", null);

    
    NodeList nodeList3 = node4.getChildNodes();
    int k = nodeList3.getLength();
    
    for (byte b3 = 0; b3 < k; b3++) {
      
      Node node = nodeList3.item(b3);

      
      if (!(node instanceof org.w3c.dom.Text)) {


        
        String str1 = node.getNodeName();
        startElement(null, null, str1, null);

        
        NodeList nodeList = node.getChildNodes();
        int m = nodeList.getLength();
        
        for (byte b = 0; b < m; b++) {
          
          Node node5 = nodeList.item(b);

          
          if (!(node5 instanceof org.w3c.dom.Text)) {


            
            String str3, str2 = node5.getNodeName();
            startElement(null, null, str2, null);



            
            if (node5.hasChildNodes()) {
              
              str3 = node5.getFirstChild().getNodeValue();
              if (str3 == null)
              {
                startElement(null, null, "null", null);
              
              }
            
            }
            else {
              
              str3 = "";
            } 
            
            processElement(str3);
            
            endElement(null, null, str2);
          } 
        } 

        
        endElement(null, null, str1);
      } 
    } 
    
    endElement(null, null, "data");
    
    endElement(null, null, "webRowSet");
    
    endDocument();
  }
}
