package oracle.jdbc.driver;

import java.io.IOException;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;






































class NTFListener
  extends Thread
{
  private NTFConnection[] connections = null;
  private int nbOfConnections = 0;
  
  private boolean needsToBeClosed = false;
  
  NTFManager dcnManager;
  ServerSocketChannel ssChannel;
  int tcpport;
  
  NTFListener(NTFManager paramNTFManager, ServerSocketChannel paramServerSocketChannel, int paramInt) {
    this.dcnManager = paramNTFManager;
    this.connections = new NTFConnection[10];
    this.ssChannel = paramServerSocketChannel;
    this.tcpport = paramInt;
  }




  
  public void run() {
    try {
      Selector selector = Selector.open();
      this.ssChannel.register(selector, 16);




      
      while (true) {
        selector.select();
        if (this.needsToBeClosed) {
          break;
        }
        Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();
        while (iterator.hasNext()) {
          
          SelectionKey selectionKey = iterator.next();
          
          if ((selectionKey.readyOps() & 0x10) == 16) {



            
            ServerSocketChannel serverSocketChannel = (ServerSocketChannel)selectionKey.channel();
            
            SocketChannel socketChannel = serverSocketChannel.accept();
            NTFConnection nTFConnection = new NTFConnection(this.dcnManager, socketChannel);

            
            if (this.connections.length == this.nbOfConnections) {

              
              NTFConnection[] arrayOfNTFConnection = new NTFConnection[this.connections.length * 2];
              System.arraycopy(this.connections, 0, arrayOfNTFConnection, 0, this.connections.length);
              this.connections = arrayOfNTFConnection;
            } 
            this.connections[this.nbOfConnections++] = nTFConnection;
            nTFConnection.start();
            iterator.remove();
          } 
        } 
      } 
      selector.close();
      this.ssChannel.close();
    }
    catch (IOException iOException) {}
  }








  
  synchronized void closeThisListener() {
    for (byte b = 0; b < this.nbOfConnections; b++) {
      
      this.connections[b].closeThisConnection();
      this.connections[b].interrupt();
    } 
    this.needsToBeClosed = true;
  }

  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
