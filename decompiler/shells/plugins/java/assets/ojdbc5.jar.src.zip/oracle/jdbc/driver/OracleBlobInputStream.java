package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.BFILE;
import oracle.sql.BLOB;
import oracle.sql.Datum;


















class OracleBlobInputStream
  extends OracleBufferedStream
{
  long lobOffset;
  Datum lob;
  long markedByte;
  boolean endOfStream = false;
  long maxPosition = Long.MAX_VALUE;






  
  public OracleBlobInputStream(BLOB paramBLOB) throws SQLException {
    this(paramBLOB, ((PhysicalConnection)paramBLOB.getJavaSqlConnection()).getDefaultStreamChunkSize(), 1L);
  }












  
  public OracleBlobInputStream(BLOB paramBLOB, int paramInt) throws SQLException {
    this(paramBLOB, paramInt, 1L);
  }












  
  public OracleBlobInputStream(BLOB paramBLOB, int paramInt, long paramLong) throws SQLException {
    super(paramInt);

    
    if (paramBLOB == null || paramInt <= 0 || paramLong < 1L)
    {
      throw new IllegalArgumentException("Illegal Arguments");
    }
    
    this.lob = (Datum)paramBLOB;
    this.markedByte = -1L;
    this.lobOffset = paramLong;
  }











  
  public OracleBlobInputStream(BLOB paramBLOB, int paramInt, long paramLong1, long paramLong2) throws SQLException {
    this(paramBLOB, paramInt, paramLong1);
    this.maxPosition = paramLong1 + paramLong2;
  }






  
  public OracleBlobInputStream(BFILE paramBFILE) throws SQLException {
    this(paramBFILE, ((PhysicalConnection)paramBFILE.getJavaSqlConnection()).getDefaultStreamChunkSize(), 1L);
  }











  
  public OracleBlobInputStream(BFILE paramBFILE, int paramInt) throws SQLException {
    this(paramBFILE, paramInt, 1L);
  }











  
  public OracleBlobInputStream(BFILE paramBFILE, int paramInt, long paramLong) throws SQLException {
    super(paramInt);

    
    if (paramBFILE == null || paramInt <= 0 || paramLong < 1L)
    {
      throw new IllegalArgumentException("Illegal Arguments");
    }
    
    this.lob = (Datum)paramBFILE;
    this.markedByte = -1L;
    this.lobOffset = paramLong;
  }







  
  public boolean needBytes(int paramInt) throws IOException {
    ensureOpen();
    
    if (this.pos >= this.count) {
      
      if (!this.endOfStream) {
        
        if (paramInt > this.currentBufferSize) {
          
          this.currentBufferSize = Math.max(paramInt, this.initialBufferSize);
          this.resizableBuffer = new byte[this.currentBufferSize];
        } 
        
        try {
          int i;
          if (this.currentBufferSize < this.maxPosition - this.lobOffset) { i = this.currentBufferSize; }
          else { i = (int)(this.maxPosition - this.lobOffset); }

          
          if (this.lob instanceof BLOB) {
            this.count = ((BLOB)this.lob).getBytes(this.lobOffset, i, this.resizableBuffer);
          } else {
            this.count = ((BFILE)this.lob).getBytes(this.lobOffset, i, this.resizableBuffer);
          } 
          
          if (this.count < this.currentBufferSize) {
            this.endOfStream = true;
          }
          if (this.count > 0)
          {

            
            this.pos = 0;
            this.lobOffset += this.count;
            if (this.lobOffset > this.maxPosition) this.endOfStream = true;
            
            return true;
          }
        
        } catch (SQLException sQLException) {

          
          IOException iOException = DatabaseError.createIOException(sQLException);
          iOException.fillInStackTrace();
          throw iOException;
        } 
      } 

      
      return false;
    } 
    
    return true;
  }










  
  void ensureOpen() throws IOException {
    try {
      if (this.closed)
      {
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 57, (Object)null);
        sQLException.fillInStackTrace();
        throw sQLException;
      }
    
    } catch (SQLException sQLException) {

      
      IOException iOException = DatabaseError.createIOException(sQLException);
      iOException.fillInStackTrace();
      throw iOException;
    } 
  }











  
  public boolean markSupported() {
    return true;
  }














  
  public void mark(int paramInt) {
    if (paramInt < 0) {
      throw new IllegalArgumentException("Read-ahead limit < 0");
    }
    this.markedByte = this.lobOffset - this.count + this.pos;
  }






  
  public void markInternal(int paramInt) {}






  
  public void reset() throws IOException {
    ensureOpen();
    
    if (this.markedByte < 0L) {
      throw new IOException("Mark invalid or stream not marked.");
    }
    this.lobOffset = this.markedByte;
    this.pos = this.count;
    this.endOfStream = false;
  }















  
  public long skip(long paramLong) throws IOException {
    ensureOpen();
    
    long l = 0L;
    
    if ((this.count - this.pos) >= paramLong) {
      
      this.pos = (int)(this.pos + paramLong);
      l += paramLong;
    }
    else {
      
      l += (this.count - this.pos);
      this.pos = this.count;

      
      try {
        long l1 = 0L;
        
        if (this.lob instanceof BLOB) {
          l1 = ((BLOB)this.lob).length() - this.lobOffset + 1L;
        } else {
          l1 = ((BFILE)this.lob).length() - this.lobOffset + 1L;
        } 
        if (l1 >= paramLong - l)
        {
          this.lobOffset += paramLong - l;
          l += paramLong - l;
        }
        else
        {
          this.lobOffset += l1;
          l += l1;
        }
      
      } catch (SQLException sQLException) {

        
        IOException iOException = DatabaseError.createIOException(sQLException);
        iOException.fillInStackTrace();
        throw iOException;
      } 
    } 

    
    return l;
  }












  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    OracleConnection oracleConnection = null;
    
    if (this.lob != null) {
      
      try {
        
        if (this.lob instanceof BLOB) {
          oracleConnection = ((BLOB)this.lob).getInternalConnection();
        } else {
          oracleConnection = ((BFILE)this.lob).getInternalConnection();
        } 
      } catch (Exception exception) {
        
        oracleConnection = null;
      } 
    }
    
    return oracleConnection;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
