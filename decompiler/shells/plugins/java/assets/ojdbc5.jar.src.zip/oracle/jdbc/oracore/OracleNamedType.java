package oracle.jdbc.oracore;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.Datum;
import oracle.sql.SQLName;
import oracle.sql.TypeDescriptor;











public abstract class OracleNamedType
  extends OracleType
  implements Serializable
{
  transient OracleConnection connection;
  SQLName sqlName = null;
  transient OracleTypeADT parent = null;
  transient int idx;
  transient TypeDescriptor descriptor = null;



























  
  public String getFullName() throws SQLException {
    return getFullName(false);
  }




  
  public String getFullName(boolean paramBoolean) throws SQLException {
    String str = null;
    
    if (paramBoolean || this.sqlName == null)
    {
      
      if (this.parent != null && (str = this.parent.getAttributeType(this.idx)) != null) {

        
        this.sqlName = new SQLName(str, (OracleConnection)this.connection);
      }
      else {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Unable to resolve name");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    }
    return this.sqlName.getName();
  }



  
  public String getSchemaName() throws SQLException {
    if (this.sqlName == null) getFullName(); 
    return this.sqlName.getSchema();
  }



  
  public String getSimpleName() throws SQLException {
    if (this.sqlName == null) getFullName(); 
    return this.sqlName.getSimpleName();
  }



  
  public boolean hasName() throws SQLException {
    return (this.sqlName != null);
  }



  
  public OracleTypeADT getParent() throws SQLException {
    return this.parent;
  }



  
  public void setParent(OracleTypeADT paramOracleTypeADT) throws SQLException {
    this.parent = paramOracleTypeADT;
  }



  
  public int getOrder() throws SQLException {
    return this.idx;
  }



  
  public void setOrder(int paramInt) throws SQLException {
    this.idx = paramInt;
  }










  
  public OracleConnection getConnection() throws SQLException {
    return this.connection;
  }











  
  public void setConnection(OracleConnection paramOracleConnection) throws SQLException {
    setConnectionInternal(paramOracleConnection);
  }



  
  public void setConnectionInternal(OracleConnection paramOracleConnection) {
    this.connection = paramOracleConnection;
  }















  
  public Datum unlinearize(byte[] paramArrayOfbyte, long paramLong, Datum paramDatum, int paramInt, Map paramMap) throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }
















  
  public Datum unlinearize(byte[] paramArrayOfbyte, long paramLong1, Datum paramDatum, long paramLong2, int paramInt1, int paramInt2, Map paramMap) throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }









  
  public byte[] linearize(Datum paramDatum) throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public TypeDescriptor getDescriptor() throws SQLException {
    return this.descriptor;
  }



  
  public void setDescriptor(TypeDescriptor paramTypeDescriptor) throws SQLException {
    this.descriptor = paramTypeDescriptor;
  }



  
  public int getTypeVersion() {
    return 1;
  }









  
  private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
    try {
      paramObjectOutputStream.writeUTF(getFullName());
    }
    catch (SQLException sQLException) {

      
      IOException iOException = DatabaseError.createIOException(sQLException);
      iOException.fillInStackTrace();
      throw iOException;
    } 
  }





  
  private void readObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {
    String str = paramObjectInputStream.readUTF(); 
    try { this.sqlName = new SQLName(str, null); } catch (SQLException sQLException) {}
    this.parent = null;
    this.idx = -1;
  }




  
  public void fixupConnection(OracleConnection paramOracleConnection) throws SQLException {
    if (this.connection == null) setConnection(paramOracleConnection);
  
  }







  
  public void printXML(PrintWriter paramPrintWriter, int paramInt) throws SQLException {
    printXML(paramPrintWriter, paramInt, false);
  }


  
  public void printXML(PrintWriter paramPrintWriter, int paramInt, boolean paramBoolean) throws SQLException {
    for (byte b = 0; b < paramInt; ) { paramPrintWriter.print("  "); b++; }
     paramPrintWriter.println("<OracleNamedType/>");
  }



  
  public void initNamesRecursively() throws SQLException {
    Map map = createTypesTreeMap();
    if (map.size() > 0) {
      initChildNamesRecursively(map);
    }
  }


  
  public void setNames(String paramString1, String paramString2) throws SQLException {
    this.sqlName = new SQLName(paramString1, paramString2, (OracleConnection)this.connection);
  }



  
  public void setSqlName(SQLName paramSQLName) {
    this.sqlName = paramSQLName;
  }










  
  public Map createTypesTreeMap() throws SQLException {
    Map map = null;
    String str = this.connection.getDefaultSchemaNameForNamedTypes();
    if (this.sqlName.getSchema().equals(str)) {
      map = getNodeMapFromUserTypes();
    }
    if (map == null)
      map = getNodeMapFromAllTypes(); 
    return map;
  }

  
  static String getUserTypeTreeSql = "select level depth, parent_type, child_type, ATTR_NO, child_type_owner from  (select TYPE_NAME parent_type, ELEM_TYPE_NAME child_type, 0 ATTR_NO,       ELEM_TYPE_OWNER child_type_owner     from USER_COLL_TYPES  union   select TYPE_NAME parent_type, ATTR_TYPE_NAME child_type, ATTR_NO,       ATTR_TYPE_OWNER child_type_owner     from USER_TYPE_ATTRS  ) start with parent_type  = ?  connect by prior  child_type = parent_type";





  
  String sqlHint;





  
  protected OracleNamedType() {
    this.sqlHint = null; } public OracleNamedType(String paramString, OracleConnection paramOracleConnection) throws SQLException { this.sqlHint = null; setConnectionInternal(paramOracleConnection); this.sqlName = new SQLName(paramString, (OracleConnection)paramOracleConnection); } protected OracleNamedType(OracleTypeADT paramOracleTypeADT, int paramInt, OracleConnection paramOracleConnection) { this.sqlHint = null;
    setConnectionInternal(paramOracleConnection);
    this.parent = paramOracleTypeADT;
    this.idx = paramInt; } String getSqlHint() throws SQLException {
    if (this.sqlHint == null)
    {
      if (this.connection.getVersionNumber() >= 11000) {
        this.sqlHint = "";
      } else {
        this.sqlHint = "/*+RULE*/";
      }  } 
    return this.sqlHint;
  }




  
  Map getNodeMapFromUserTypes() throws SQLException {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;
    
    try {
      preparedStatement = this.connection.prepareStatement(getSqlHint() + getUserTypeTreeSql);
      preparedStatement.setString(1, this.sqlName.getSimpleName());
      resultSet = preparedStatement.executeQuery();
      
      while (resultSet.next()) {
        
        int i = resultSet.getInt(1);
        String str1 = resultSet.getString(2);
        String str2 = resultSet.getString(3);
        int j = resultSet.getInt(4);
        String str3 = resultSet.getString(5);
        if (str3 != null && !str3.equals(this.sqlName.getSchema())) {
          
          hashMap = null;
          break;
        } 
        if (str1.length() > 0) {
          
          SQLName sQLName = new SQLName(this.sqlName.getSchema(), str1, (OracleConnection)this.connection);
          TypeTreeElement typeTreeElement = null;
          if (hashMap.containsKey(sQLName)) {
            typeTreeElement = (TypeTreeElement)hashMap.get(sQLName);
          } else {
            
            typeTreeElement = new TypeTreeElement(this.sqlName.getSchema(), str1);
            hashMap.put(sQLName, typeTreeElement);
          } 
          typeTreeElement.putChild(this.sqlName.getSchema(), str2, j);
        } 
      } 
    } finally {
      if (resultSet != null) resultSet.close();  if (preparedStatement != null) preparedStatement.close(); 
    }  return hashMap;
  }


  
  static String getAllTypeTreeSql = "select parent_type, parent_type_owner, child_type, ATTR_NO, child_type_owner from ( select TYPE_NAME parent_type,  OWNER parent_type_owner,     ELEM_TYPE_NAME child_type, 0 ATTR_NO,     ELEM_TYPE_OWNER child_type_owner   from ALL_COLL_TYPES union   select TYPE_NAME parent_type, OWNER parent_type_owner,     ATTR_TYPE_NAME child_type, ATTR_NO,     ATTR_TYPE_OWNER child_type_owner   from ALL_TYPE_ATTRS ) start with parent_type  = ?  and parent_type_owner = ? connect by prior child_type = parent_type   and ( child_type_owner = parent_type_owner or child_type_owner is null )";















  
  Map getNodeMapFromAllTypes() throws SQLException {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;
    
    try {
      preparedStatement = this.connection.prepareStatement(getSqlHint() + getAllTypeTreeSql);
      preparedStatement.setString(1, this.sqlName.getSimpleName());
      preparedStatement.setString(2, this.sqlName.getSchema());
      resultSet = preparedStatement.executeQuery();
      
      while (resultSet.next()) {
        
        String str1 = resultSet.getString(1);
        String str2 = resultSet.getString(2);
        String str3 = resultSet.getString(3);
        int i = resultSet.getInt(4);
        String str4 = resultSet.getString(5);
        if (str4 == null) str4 = "SYS"; 
        if (str1.length() > 0) {
          
          SQLName sQLName = new SQLName(str2, str1, (OracleConnection)this.connection);
          TypeTreeElement typeTreeElement = null;
          if (hashMap.containsKey(sQLName)) {
            typeTreeElement = (TypeTreeElement)hashMap.get(sQLName);
          } else {
            
            typeTreeElement = new TypeTreeElement(str2, str1);
            hashMap.put(sQLName, typeTreeElement);
          } 
          typeTreeElement.putChild(str4, str3, i);
        } 
      } 
    } finally {
      if (resultSet != null) resultSet.close();  if (preparedStatement != null) preparedStatement.close(); 
    }  return hashMap;
  }











  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return this.connection;
  }











































  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
