package oracle.jdbc.driver;

import java.sql.Array;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;











class ArrayLocatorResultSet
  extends OracleResultSetImpl
{
  static int COUNT_UNLIMITED = -1;


  
  Map map;


  
  long beginIndex;


  
  int count;

  
  long currentIndex;


  
  public ArrayLocatorResultSet(OracleConnection paramOracleConnection, ArrayDescriptor paramArrayDescriptor, byte[] paramArrayOfbyte, Map paramMap) throws SQLException {
    this(paramOracleConnection, paramArrayDescriptor, paramArrayOfbyte, 0L, COUNT_UNLIMITED, paramMap);
  }
















  
  public ArrayLocatorResultSet(OracleConnection paramOracleConnection, ArrayDescriptor paramArrayDescriptor, byte[] paramArrayOfbyte, long paramLong, int paramInt, Map paramMap) throws SQLException {
    super((PhysicalConnection)paramOracleConnection, (OracleStatement)null);

    
    if (paramArrayDescriptor == null || paramOracleConnection == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid arguments");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    this.close_statement_on_close = true;
    
    this.count = paramInt;
    this.currentIndex = 0L;
    this.beginIndex = paramLong;
    
    this.map = paramMap;
    
    OraclePreparedStatement oraclePreparedStatement = null;

    
    ARRAY aRRAY = new ARRAY(paramArrayDescriptor, (Connection)paramOracleConnection, null);
    
    aRRAY.setLocator(paramArrayOfbyte);

    
    if (paramArrayDescriptor.getBaseType() == 2002 || paramArrayDescriptor.getBaseType() == 2008) {




      
      oraclePreparedStatement = (OraclePreparedStatement)((OraclePreparedStatementWrapper)paramOracleConnection.prepareStatement("SELECT ROWNUM, SYS_NC_ROWINFO$ FROM TABLE( CAST(:1 AS " + paramArrayDescriptor.getName() + ") )")).preparedStatement;


    
    }
    else {


      
      oraclePreparedStatement = (OraclePreparedStatement)((OraclePreparedStatementWrapper)paramOracleConnection.prepareStatement("SELECT ROWNUM, COLUMN_VALUE FROM TABLE( CAST(:1 AS " + paramArrayDescriptor.getName() + ") )")).preparedStatement;
    } 


    
    oraclePreparedStatement.setArray(1, (Array)aRRAY);
    oraclePreparedStatement.executeQuery();
    
    this.statement = oraclePreparedStatement;
  }





  
  public boolean next() throws SQLException {
    synchronized (this.connection) {

      
      if (this.currentIndex < this.beginIndex) {
        
        while (this.currentIndex < this.beginIndex) {
          
          this.currentIndex++;
          
          if (!super.next()) {
            return false;
          }
        } 
        return true;
      } 

      
      if (this.count == COUNT_UNLIMITED)
      {
        return super.next();
      }
      if (this.currentIndex < this.beginIndex + this.count - 1L) {
        
        this.currentIndex++;
        
        return super.next();
      } 

      
      return false;
    } 
  }





  
  public Object getObject(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      return getObject(paramInt, this.map);
    } 
  }





  
  public int findColumn(String paramString) throws SQLException {
    synchronized (this.connection) {

      
      if (paramString.equalsIgnoreCase("index"))
        return 1; 
      if (paramString.equalsIgnoreCase("value")) {
        return 2;
      }
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6, "get_column_index");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }




  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
