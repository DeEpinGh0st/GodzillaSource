package oracle.jdbc.connector;

import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.resource.ResourceException;
import javax.resource.spi.ConnectionManager;
import javax.resource.spi.ConnectionRequestInfo;
import javax.resource.spi.EISSystemException;
import javax.resource.spi.ManagedConnection;
import javax.resource.spi.ManagedConnectionFactory;
import javax.resource.spi.ResourceAdapterInternalException;
import javax.resource.spi.SecurityException;
import javax.resource.spi.security.PasswordCredential;
import javax.security.auth.Subject;
import javax.sql.XAConnection;
import javax.sql.XADataSource;



















public class OracleManagedConnectionFactory
  implements ManagedConnectionFactory
{
  private XADataSource xaDataSource = null;
  private String xaDataSourceName = null;



  
  private static final String RAERR_MCF_SET_XADS = "invalid xads";


  
  private static final String RAERR_MCF_GET_PCRED = "no password credential";



  
  public OracleManagedConnectionFactory() throws ResourceException {}



  
  public OracleManagedConnectionFactory(XADataSource paramXADataSource) throws ResourceException {
    this.xaDataSource = paramXADataSource;
    this.xaDataSourceName = "XADataSource";
  }





  
  public void setXADataSourceName(String paramString) {
    this.xaDataSourceName = paramString;
  }





  
  public String getXADataSourceName() {
    return this.xaDataSourceName;
  }
















  
  public Object createConnectionFactory(ConnectionManager paramConnectionManager) throws ResourceException {
    if (this.xaDataSource == null)
    {
      setupXADataSource();
    }
    
    return this.xaDataSource;
  }














  
  public Object createConnectionFactory() throws ResourceException {
    return createConnectionFactory(null);
  }




















  
  public ManagedConnection createManagedConnection(Subject paramSubject, ConnectionRequestInfo paramConnectionRequestInfo) throws ResourceException {
    try {
      if (this.xaDataSource == null)
      {
        setupXADataSource();
      }
      
      XAConnection xAConnection = null;
      PasswordCredential passwordCredential = getPasswordCredential(paramSubject, paramConnectionRequestInfo);
      
      if (passwordCredential == null) {
        
        xAConnection = this.xaDataSource.getXAConnection();
      }
      else {
        
        xAConnection = this.xaDataSource.getXAConnection(passwordCredential.getUserName(), new String(passwordCredential.getPassword()));
      } 

      
      OracleManagedConnection oracleManagedConnection = new OracleManagedConnection(xAConnection);
      
      oracleManagedConnection.setPasswordCredential(passwordCredential);

      
      oracleManagedConnection.setLogWriter(getLogWriter());
      
      return oracleManagedConnection;
    }
    catch (SQLException sQLException) {
      
      EISSystemException eISSystemException = new EISSystemException("SQLException: " + sQLException.getMessage());

      
      eISSystemException.setLinkedException(sQLException);
      
      throw eISSystemException;
    } 
  }























  
  public ManagedConnection matchManagedConnections(Set paramSet, Subject paramSubject, ConnectionRequestInfo paramConnectionRequestInfo) throws ResourceException {
    PasswordCredential passwordCredential = getPasswordCredential(paramSubject, paramConnectionRequestInfo);
    Iterator<Object> iterator = paramSet.iterator();
    
    while (iterator.hasNext()) {
      
      OracleManagedConnection oracleManagedConnection = (OracleManagedConnection)iterator.next();
      
      if (oracleManagedConnection instanceof OracleManagedConnection) {
        
        OracleManagedConnection oracleManagedConnection1 = oracleManagedConnection;

        
        if (oracleManagedConnection1.getPasswordCredential().equals(passwordCredential))
        {
          return oracleManagedConnection1;
        }
      } 
    } 
    
    return null;
  }















  
  public void setLogWriter(PrintWriter paramPrintWriter) throws ResourceException {
    try {
      if (this.xaDataSource == null)
      {
        setupXADataSource();
      }
      
      this.xaDataSource.setLogWriter(paramPrintWriter);
    }
    catch (SQLException sQLException) {


      
      EISSystemException eISSystemException = new EISSystemException("SQLException: " + sQLException.getMessage());

      
      eISSystemException.setLinkedException(sQLException);
      
      throw eISSystemException;
    } 
  }














  
  public PrintWriter getLogWriter() throws ResourceException {
    try {
      if (this.xaDataSource == null)
      {
        setupXADataSource();
      }
      
      return this.xaDataSource.getLogWriter();
    }
    catch (SQLException sQLException) {


      
      EISSystemException eISSystemException = new EISSystemException("SQLException: " + sQLException.getMessage());

      
      eISSystemException.setLinkedException(sQLException);
      
      throw eISSystemException;
    } 
  }









































  
  private void setupXADataSource() throws ResourceException {
    try {
      InitialContext initialContext = null;

      
      try {
        Properties properties = System.getProperties();
        
        initialContext = new InitialContext(properties);
      }
      catch (SecurityException securityException) {}


      
      if (initialContext == null)
      {
        initialContext = new InitialContext();
      }
      
      XADataSource xADataSource = (XADataSource)initialContext.lookup(this.xaDataSourceName);
      
      if (xADataSource == null)
      {
        throw new ResourceAdapterInternalException("Invalid XADataSource object");
      }
      
      this.xaDataSource = xADataSource;
    }
    catch (NamingException namingException) {
      
      ResourceException resourceException = new ResourceException("NamingException: " + namingException.getMessage());

      
      resourceException.setLinkedException(namingException);
      
      throw resourceException;
    } 
  }








  
  private PasswordCredential getPasswordCredential(Subject paramSubject, ConnectionRequestInfo paramConnectionRequestInfo) throws ResourceException {
    if (paramSubject != null) {


      
      Set<PasswordCredential> set = paramSubject.getPrivateCredentials(PasswordCredential.class);
      Iterator<PasswordCredential> iterator = set.iterator();
      
      while (iterator.hasNext()) {
        
        PasswordCredential passwordCredential1 = iterator.next();
        
        if (passwordCredential1.getManagedConnectionFactory().equals(this))
        {
          return passwordCredential1;
        }
      } 
      
      throw new SecurityException("Can not find user/password information", "no password credential");
    } 

    
    if (paramConnectionRequestInfo == null)
    {
      return null;
    }

    
    OracleConnectionRequestInfo oracleConnectionRequestInfo = (OracleConnectionRequestInfo)paramConnectionRequestInfo;
    
    PasswordCredential passwordCredential = new PasswordCredential(oracleConnectionRequestInfo.getUser(), oracleConnectionRequestInfo.getPassword().toCharArray());

    
    passwordCredential.setManagedConnectionFactory(this);
    
    return passwordCredential;
  }






  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
