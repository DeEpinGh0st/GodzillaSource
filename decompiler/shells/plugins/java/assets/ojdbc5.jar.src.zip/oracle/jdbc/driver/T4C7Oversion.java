package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;






























final class T4C7Oversion
  extends T4CTTIfun
{
  byte[] rdbmsVersion = new byte[] { 78, 111, 116, 32, 100, 101, 116, 101, 114, 109, 105, 110, 101, 100, 32, 121, 101, 116 };



  
  private final boolean rdbmsVersionO2U = true;


  
  private final int bufLen = 256;
  private final boolean retVerLenO2U = true;
  int retVerLen = 0;
  private final boolean retVerNumO2U = true;
  long retVerNum = 0L;






  
  T4C7Oversion(T4CConnection paramT4CConnection) {
    super(paramT4CConnection, (byte)3);
    
    setFunCode((short)59);
  }



  
  void doOVERSION() throws SQLException, IOException {
    doRPC();
  }





  
  void readRPA() throws IOException, SQLException {
    this.retVerLen = this.meg.unmarshalUB2();
    this.rdbmsVersion = this.meg.unmarshalCHR(this.retVerLen);
    this.retVerNum = this.meg.unmarshalUB4();
  }




  
  void processRPA() throws SQLException {
    if (this.rdbmsVersion == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 438);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }










  
  byte[] getVersion() {
    return this.rdbmsVersion;
  }









  
  short getVersionNumber() {
    int i = 0;
    
    i = (int)(i + (this.retVerNum >>> 24L & 0xFFL) * 1000L);
    i = (int)(i + (this.retVerNum >>> 20L & 0xFL) * 100L);
    i = (int)(i + (this.retVerNum >>> 12L & 0xFL) * 10L);
    i = (int)(i + (this.retVerNum >>> 8L & 0xFL));
    
    return (short)i;
  }









  
  long getVersionNumberasIs() {
    return this.retVerNum;
  }










  
  void marshal() throws IOException {
    this.meg.marshalO2U(true);
    this.meg.marshalSWORD(256);
    this.meg.marshalO2U(true);
    this.meg.marshalO2U(true);
  }












  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return this.connection;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
