package oracle.jdbc.driver;

import java.sql.SQLException;









































class T4CKvaldfList
{
  static final int INTIAL_CAPACITY = 30;
  private int capacity;
  private int offset;
  private byte[][] keys;
  private byte[][] values;
  private byte[] flags;
  DBConversion conv;
  
  T4CKvaldfList(DBConversion paramDBConversion) {
    this.conv = paramDBConversion;
    initializeList();
  }



  
  void initializeList() {
    this.capacity = 30;
    this.offset = 0;
    this.keys = new byte[this.capacity][];
    this.values = new byte[this.capacity][];
    this.flags = new byte[this.capacity];
  }



  
  void add(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte paramByte) {
    if (this.offset == this.capacity) {
      
      byte[][] arrayOfByte1 = new byte[this.capacity * 2][];
      byte[][] arrayOfByte2 = new byte[this.capacity * 2][];
      byte[] arrayOfByte = new byte[this.capacity * 2];
      System.arraycopy(this.keys, 0, arrayOfByte1, 0, this.capacity);
      System.arraycopy(this.values, 0, arrayOfByte2, 0, this.capacity);
      System.arraycopy(this.flags, 0, arrayOfByte, 0, this.capacity);
      this.keys = arrayOfByte1;
      this.values = arrayOfByte2;
      this.flags = arrayOfByte;
      this.capacity *= 2;
    } 
    this.keys[this.offset] = paramArrayOfbyte1;
    this.values[this.offset] = paramArrayOfbyte2;
    this.flags[this.offset++] = paramByte;
  }



  
  void add(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    add(paramArrayOfbyte1, paramArrayOfbyte2, (byte)0);
  }



  
  void add(String paramString, byte[] paramArrayOfbyte) throws SQLException {
    add(this.conv.StringToCharBytes(paramString), paramArrayOfbyte, (byte)0);
  }


  
  void add(String paramString, byte[] paramArrayOfbyte, byte paramByte) throws SQLException {
    add(this.conv.StringToCharBytes(paramString), paramArrayOfbyte, paramByte);
  }



  
  int size() {
    return this.offset;
  }


  
  byte[][] getKeys() {
    return this.keys;
  }


  
  byte[][] getValues() {
    return this.values;
  }


  
  byte[] getFlags() {
    return this.flags;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
