package oracle.jdbc.oracore;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.DATE;
import oracle.sql.Datum;
import oracle.sql.TIMESTAMP;


















public class OracleTypeDATE
  extends OracleType
  implements Serializable
{
  static final long serialVersionUID = -5858803341118747965L;
  
  public OracleTypeDATE() {}
  
  public OracleTypeDATE(int paramInt) {
    super(paramInt);
  }











  
  public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection) throws SQLException {
    DATE dATE = null;
    
    if (paramObject != null) {
      
      try {
        
        if (paramObject instanceof DATE) {
          dATE = (DATE)paramObject;
        } else if (paramObject instanceof TIMESTAMP) {
          dATE = new DATE(((TIMESTAMP)paramObject).timestampValue());
        } else {
          dATE = new DATE(paramObject);
        } 
      } catch (SQLException sQLException1) {

        
        SQLException sQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject);
        sQLException2.fillInStackTrace();
        throw sQLException2;
      } 
    }
    
    return (Datum)dATE;
  }










  
  public Datum[] toDatumArray(Object paramObject, OracleConnection paramOracleConnection, long paramLong, int paramInt) throws SQLException {
    Datum[] arrayOfDatum = null;
    
    if (paramObject != null)
    {
      if (paramObject instanceof char[][]) {
        
        char[][] arrayOfChar = (char[][])paramObject;
        int i = (int)((paramInt == -1) ? arrayOfChar.length : Math.min(arrayOfChar.length - paramLong + 1L, paramInt));

        
        arrayOfDatum = new Datum[i];
        
        for (byte b = 0; b < i; b++) {
          arrayOfDatum[b] = toDatum(new String(arrayOfChar[(int)paramLong + b - 1]), paramOracleConnection);
        }
      } else {
        if (paramObject instanceof Object[])
        {
          return super.toDatumArray(paramObject, paramOracleConnection, paramLong, paramInt);
        }

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    }
    return arrayOfDatum;
  }






  
  public int getTypeCode() {
    return 91;
  }



















  
  protected Object toObject(byte[] paramArrayOfbyte, int paramInt, Map paramMap) throws SQLException {
    if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
      return null;
    }
    if (paramInt == 1)
      return new DATE(paramArrayOfbyte); 
    if (paramInt == 2)
      return DATE.toTimestamp(paramArrayOfbyte); 
    if (paramInt == 3) {
      return paramArrayOfbyte;
    }
    
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramArrayOfbyte);
    sQLException.fillInStackTrace();
    throw sQLException;
  }















  
  private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {}














  
  private void readObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {}














  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
