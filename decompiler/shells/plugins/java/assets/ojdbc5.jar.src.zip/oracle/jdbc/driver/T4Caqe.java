package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.aq.AQEnqueueOptions;
import oracle.jdbc.internal.OracleConnection;
































































































































































































final class T4Caqe
  extends T4CTTIfun
{
  static final int KPD_AQ_BUFMSG = 2;
  static final int KPD_AQ_EITHER = 16;
  static final int OCI_COMMIT_ON_SUCCESS = 32;
  static final int ATTR_TRANSFORMATION = 196;
  T4CTTIaqm aqm;
  T4Ctoh toh;
  private byte[] queueNameBytes;
  private AQEnqueueOptions enqueueOptions;
  private AQMessagePropertiesI messageProperties;
  private byte[] messageData;
  private byte[] messageOid;
  private boolean isRawQueue;
  private int nbExtensions;
  private byte[][] extensionTextValues;
  private byte[][] extensionBinaryValues;
  private int[] extensionKeywords;
  private AQAgentI[] attrRecipientList;
  private byte[][] recipientTextValues;
  private byte[][] recipientBinaryValues;
  private int[] recipientKeywords;
  private byte[] aqmcorBytes;
  private byte[] aqmeqnBytes;
  private boolean retrieveMessageId;
  private byte[] outMsgid;
  private byte[] senderAgentName;
  private byte[] senderAgentAddress;
  private byte senderAgentProtocol;
  
  T4Caqe(T4CConnection paramT4CConnection) {
    super(paramT4CConnection, (byte)3);





    
    this.queueNameBytes = null;
    this.enqueueOptions = null;
    this.messageProperties = null;
    this.messageData = null;
    this.messageOid = null;
    this.isRawQueue = false;
    this.nbExtensions = 0;
    this.extensionTextValues = (byte[][])null;
    this.extensionBinaryValues = (byte[][])null;
    this.extensionKeywords = null;
    this.attrRecipientList = null;
    this.recipientTextValues = (byte[][])null;
    this.recipientBinaryValues = (byte[][])null;
    this.recipientKeywords = null;

    
    this.retrieveMessageId = false;
    this.outMsgid = null;
    this.senderAgentName = null;
    this.senderAgentAddress = null;
    this.senderAgentProtocol = 0;
    setFunCode((short)121);
    this.toh = new T4Ctoh();
    this.aqm = new T4CTTIaqm(this.connection, this.toh);
  }







  
  void doOAQEQ(String paramString, AQEnqueueOptions paramAQEnqueueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, boolean paramBoolean) throws SQLException, IOException {
    this.enqueueOptions = paramAQEnqueueOptions;
    this.messageProperties = paramAQMessagePropertiesI;
    
    String str1 = this.messageProperties.getCorrelation();
    if (str1 != null && str1.length() != 0) {
      this.aqmcorBytes = this.meg.conv.StringToCharBytes(str1);
    } else {
      this.aqmcorBytes = null;
    }  String str2 = this.messageProperties.getExceptionQueue();
    if (str2 != null && str2.length() != 0) {
      this.aqmeqnBytes = this.meg.conv.StringToCharBytes(str2);
    } else {
      this.aqmeqnBytes = null;
    } 
    AQAgentI aQAgentI = (AQAgentI)this.messageProperties.getSender();
    if (aQAgentI != null) {
      
      if (aQAgentI.getName() != null) {
        this.senderAgentName = this.meg.conv.StringToCharBytes(aQAgentI.getName());
      } else {
        
        this.senderAgentName = null;
      }  if (aQAgentI.getAddress() != null) {
        this.senderAgentAddress = this.meg.conv.StringToCharBytes(aQAgentI.getAddress());
      } else {
        
        this.senderAgentAddress = null;
      }  this.senderAgentProtocol = (byte)aQAgentI.getProtocol();
    }
    else {
      
      this.senderAgentName = null;
      this.senderAgentAddress = null;
      this.senderAgentProtocol = 0;
    } 
    
    this.messageData = paramArrayOfbyte1;
    this.messageOid = paramArrayOfbyte2;
    this.isRawQueue = paramBoolean;
    if (paramString != null && paramString.length() != 0) {
      this.queueNameBytes = this.meg.conv.StringToCharBytes(paramString);
    } else {
      this.queueNameBytes = null;
    } 
    this.attrRecipientList = (AQAgentI[])this.messageProperties.getRecipientList();
    
    if (this.attrRecipientList != null && this.attrRecipientList.length > 0) {
      
      this.recipientTextValues = new byte[this.attrRecipientList.length * 3][];
      this.recipientBinaryValues = new byte[this.attrRecipientList.length * 3][];
      this.recipientKeywords = new int[this.attrRecipientList.length * 3];
      for (byte b = 0; b < this.attrRecipientList.length; b++) {
        
        if (this.attrRecipientList[b].getName() != null) {
          this.recipientTextValues[3 * b] = this.meg.conv.StringToCharBytes(this.attrRecipientList[b].getName());
        }
        
        if (this.attrRecipientList[b].getAddress() != null) {
          this.recipientTextValues[3 * b + 1] = this.meg.conv.StringToCharBytes(this.attrRecipientList[b].getAddress());
        }
        
        this.recipientBinaryValues[3 * b + 2] = new byte[1];
        this.recipientBinaryValues[3 * b + 2][0] = (byte)this.attrRecipientList[b].getProtocol();
        this.recipientKeywords[3 * b] = 3 * b;
        this.recipientKeywords[3 * b + 1] = 3 * b + 1;
        this.recipientKeywords[3 * b + 2] = 3 * b + 2;
      } 
    } 
    
    String str3 = this.enqueueOptions.getTransformation();
    if (str3 != null && str3.length() > 0) {
      
      this.nbExtensions = 1;
      this.extensionTextValues = new byte[this.nbExtensions][];
      this.extensionBinaryValues = new byte[this.nbExtensions][];
      this.extensionKeywords = new int[this.nbExtensions];
      this.extensionTextValues[0] = this.meg.conv.StringToCharBytes(str3);
      this.extensionBinaryValues[0] = null;
      this.extensionKeywords[0] = 196;
    } else {
      
      this.nbExtensions = 0;
    }  this.outMsgid = null;
    doRPC();
  }







  
  void marshal() throws IOException {
    if (this.queueNameBytes != null && this.queueNameBytes.length != 0) {
      
      this.meg.marshalPTR();
      this.meg.marshalSWORD(this.queueNameBytes.length);
    }
    else {
      
      this.meg.marshalNULLPTR();
      this.meg.marshalSWORD(0);
    } 
    
    this.aqm.initToDefaultValues();
    this.aqm.aqmpri = this.messageProperties.getPriority();
    this.aqm.aqmdel = this.messageProperties.getDelay();
    this.aqm.aqmexp = this.messageProperties.getExpiration();
    this.aqm.aqmcorBytes = this.aqmcorBytes;
    this.aqm.aqmeqnBytes = this.aqmeqnBytes;
    this.aqm.senderAgentName = this.senderAgentName;
    this.aqm.senderAgentAddress = this.senderAgentAddress;
    this.aqm.senderAgentProtocol = this.senderAgentProtocol;
    this.aqm.originalMsgId = this.messageProperties.getPreviousQueueMessageId();
    this.aqm.marshal();
    
    AQAgentI[] arrayOfAQAgentI = (AQAgentI[])this.messageProperties.getRecipientList();


    
    if (arrayOfAQAgentI != null && arrayOfAQAgentI.length > 0) {
      
      this.meg.marshalPTR();
      this.meg.marshalSWORD(arrayOfAQAgentI.length * 3);
    }
    else {
      
      this.meg.marshalNULLPTR();
      this.meg.marshalSWORD(0);
    } 

    
    this.meg.marshalSB4(this.enqueueOptions.getVisibility().getCode());

    
    boolean bool = false;
    if (this.enqueueOptions.getRelativeMessageId() != null && (this.enqueueOptions.getRelativeMessageId()).length > 0) {

      
      bool = true;
      this.meg.marshalPTR();
      this.meg.marshalSWORD((this.enqueueOptions.getRelativeMessageId()).length);
    }
    else {
      
      this.meg.marshalNULLPTR();
      this.meg.marshalSWORD(0);
    } 
    
    this.meg.marshalSWORD(this.enqueueOptions.getSequenceDeviation().getCode());

    
    this.meg.marshalPTR();
    this.meg.marshalSWORD(16);
    
    this.meg.marshalUB2(1);
    if (!this.isRawQueue) {

      
      this.meg.marshalPTR();
      
      this.meg.marshalNULLPTR();
      
      this.meg.marshalUB4(0L);
    
    }
    else {
      
      this.meg.marshalNULLPTR();
      
      this.meg.marshalPTR();
      
      this.meg.marshalUB4(this.messageData.length);
    } 
    if (this.enqueueOptions.getRetrieveMessageId()) {
      
      this.retrieveMessageId = true;
      
      this.meg.marshalPTR();
      
      this.meg.marshalSWORD(16);
    }
    else {
      
      this.retrieveMessageId = false;
      
      this.meg.marshalNULLPTR();
      
      this.meg.marshalSWORD(0);
    } 

    
    int i = 0;
    if (this.connection.autocommit)
      i = 32; 
    if (this.enqueueOptions.getDeliveryMode() == AQEnqueueOptions.DeliveryMode.BUFFERED)
      i |= 0x2; 
    this.meg.marshalUB4(i);
    
    this.meg.marshalNULLPTR();
    
    this.meg.marshalNULLPTR();


    
    if (this.nbExtensions > 0) {
      
      this.meg.marshalPTR();
      this.meg.marshalSWORD(this.nbExtensions);
    
    }
    else {
      
      this.meg.marshalNULLPTR();
      
      this.meg.marshalSWORD(0);
    } 

    
    this.meg.marshalNULLPTR();
    
    this.meg.marshalSWORD(0);
    
    this.meg.marshalNULLPTR();
    
    this.meg.marshalSWORD(0);
    
    this.meg.marshalNULLPTR();
    
    if (this.connection.getTTCVersion() >= 4) {



      
      this.meg.marshalNULLPTR();
      
      this.meg.marshalSWORD(0);
      
      this.meg.marshalNULLPTR();
      
      this.meg.marshalSWORD(0);
      
      this.meg.marshalNULLPTR();
      
      this.meg.marshalSWORD(0);
      
      this.meg.marshalNULLPTR();
      
      this.meg.marshalNULLPTR();
    } 


    
    if (this.queueNameBytes != null && this.queueNameBytes.length != 0) {
      this.meg.marshalCHR(this.queueNameBytes);
    }
    if (arrayOfAQAgentI != null && arrayOfAQAgentI.length > 0)
    {
      this.meg.marshalKPDKV(this.recipientTextValues, this.recipientBinaryValues, this.recipientKeywords);
    }



    
    if (bool) {
      this.meg.marshalB1Array(this.enqueueOptions.getRelativeMessageId());
    }
    
    this.meg.marshalB1Array(this.messageOid);

    
    if (!this.isRawQueue) {
      
      this.toh.init(this.messageOid, this.messageData.length);
      this.toh.marshal(this.meg);
      this.meg.marshalCLR(this.messageData, 0, this.messageData.length);
    } else {
      
      this.meg.marshalB1Array(this.messageData);
    } 
    if (this.nbExtensions > 0) {
      this.meg.marshalKPDKV(this.extensionTextValues, this.extensionBinaryValues, this.extensionKeywords);
    }
  }



  
  byte[] getMessageId() {
    return this.outMsgid;
  }



  
  void readRPA() throws SQLException, IOException {
    if (this.retrieveMessageId) {
      
      this.outMsgid = new byte[16];
      this.meg.unmarshalBuffer(this.outMsgid, 0, 16);
    } 
    int i = this.meg.unmarshalUB2();
  }













  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
