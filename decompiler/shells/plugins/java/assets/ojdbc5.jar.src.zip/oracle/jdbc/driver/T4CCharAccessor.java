package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import oracle.sql.DATE;
import oracle.sql.Datum;
import oracle.sql.NUMBER;
import oracle.sql.RAW;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;





































class T4CCharAccessor
  extends CharAccessor
{
  T4CMAREngine mare;
  boolean underlyingLong = false;
  final int[] meta;
  final int[] tmp;
  
  T4CCharAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException {
    super(paramOracleStatement, paramInt1, paramShort, paramInt2, paramBoolean);





































































    
    this.meta = new int[1];
    this.tmp = new int[1]; this.mare = paramT4CMAREngine; calculateSizeTmpByteArray(); } T4CCharAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, int paramInt9, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort); this.meta = new int[1]; this.tmp = new int[1];
    this.mare = paramT4CMAREngine;
    this.definedColumnType = paramInt8;
    this.definedColumnSize = paramInt9;
    calculateSizeTmpByteArray();
    this.oacmxl = paramInt7;
    if (this.oacmxl == -1) {
      this.underlyingLong = true;
      this.oacmxl = 4000;
    }  } boolean unmarshalOneRow() throws SQLException, IOException { if (this.isUseLess) {
      
      this.lastRowProcessed++;
      
      return false;
    } 

    
    int i = this.indicatorIndex + this.lastRowProcessed;
    int j = this.lengthIndex + this.lastRowProcessed;


    
    byte[] arrayOfByte = this.statement.tmpByteArray;
    int k = this.columnIndex + this.lastRowProcessed * this.charLength;


    
    if (this.rowSpaceIndicator == null) {


      
      byte[] arrayOfByte1 = new byte[16000];
      
      this.mare.unmarshalCLR(arrayOfByte1, 0, this.meta);
      processIndicator(this.meta[0]);
      
      this.lastRowProcessed++;
      
      return false;
    } 


    
    if (this.isNullByDescribe) {
      
      this.rowSpaceIndicator[i] = -1;
      this.rowSpaceIndicator[j] = 0;
      this.lastRowProcessed++;
      
      if (this.statement.connection.versionNumber < 9200) {
        processIndicator(0);
      }
      return false;
    } 
    
    if (this.statement.maxFieldSize > 0) {
      this.mare.unmarshalCLR(arrayOfByte, 0, this.meta, this.statement.maxFieldSize);
    } else {
      this.mare.unmarshalCLR(arrayOfByte, 0, this.meta);
    } 
    this.tmp[0] = this.meta[0];
    
    int m = 0;
    
    if (this.formOfUse == 2) {
      m = this.statement.connection.conversion.NCHARBytesToJavaChars(arrayOfByte, 0, this.rowSpaceChar, k + 1, this.tmp, this.charLength - 1);




    
    }
    else {





      
      m = this.statement.connection.conversion.CHARBytesToJavaChars(arrayOfByte, 0, this.rowSpaceChar, k + 1, this.tmp, this.charLength - 1);
    } 

    
    this.rowSpaceChar[k] = (char)(m * 2);


    
    processIndicator(this.meta[0]);
    
    if (this.meta[0] == 0) {


      
      this.rowSpaceIndicator[i] = -1;
      this.rowSpaceIndicator[j] = 0;
    }
    else {
      
      this.rowSpaceIndicator[j] = (short)(this.meta[0] * 2);


      
      this.rowSpaceIndicator[i] = 0;
    } 
    
    this.lastRowProcessed++;
    
    return false; }
  void processIndicator(int paramInt) throws IOException, SQLException { if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
      this.mare.unmarshalUB2(); this.mare.unmarshalUB2();
    } else if (this.statement.connection.versionNumber < 9200) {
      this.mare.unmarshalSB2();
      if (!this.statement.sqlKind.isPlsqlOrCall())
        this.mare.unmarshalSB2(); 
    } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) {
      this.mare.processIndicator((paramInt <= 0), paramInt);
    }  } void copyRow() throws SQLException, IOException { int i;
    if (this.lastRowProcessed == 0) {
      i = this.statement.rowPrefetchInLastFetch - 1;
    } else {
      i = this.lastRowProcessed - 1;
    } 
    
    int j = this.columnIndex + this.lastRowProcessed * this.charLength;
    int k = this.columnIndex + i * this.charLength;
    int m = this.indicatorIndex + this.lastRowProcessed;
    int n = this.indicatorIndex + i;
    int i1 = this.lengthIndex + this.lastRowProcessed;
    int i2 = this.lengthIndex + i;
    short s = this.rowSpaceIndicator[i2];
    int i3 = this.metaDataIndex + this.lastRowProcessed * 1;
    
    int i4 = this.metaDataIndex + i * 1;


    
    this.rowSpaceIndicator[i1] = (short)s;
    this.rowSpaceIndicator[m] = this.rowSpaceIndicator[n];

    
    if (!this.isNullByDescribe)
    {
      System.arraycopy(this.rowSpaceChar, k, this.rowSpaceChar, j, this.rowSpaceChar[k] / 2 + 1);
    }


    
    System.arraycopy(this.rowSpaceMetaData, i4, this.rowSpaceMetaData, i3, 1);

    
    this.lastRowProcessed++; }










  
  void saveDataFromOldDefineBuffers(byte[] paramArrayOfbyte, char[] paramArrayOfchar, short[] paramArrayOfshort, int paramInt1, int paramInt2) throws SQLException {
    int i = this.columnIndex + (paramInt2 - 1) * this.charLength;
    
    int j = this.columnIndexLastRow + (paramInt1 - 1) * this.charLength;
    
    int k = this.indicatorIndex + paramInt2 - 1;
    int m = this.indicatorIndexLastRow + paramInt1 - 1;
    int n = this.lengthIndex + paramInt2 - 1;
    int i1 = this.lengthIndexLastRow + paramInt1 - 1;
    short s = paramArrayOfshort[i1];
    
    this.rowSpaceIndicator[n] = (short)s;
    this.rowSpaceIndicator[k] = paramArrayOfshort[m];

    
    if (s != 0) {
      
      System.arraycopy(paramArrayOfchar, j, this.rowSpaceChar, i, paramArrayOfchar[j] / 2 + 1);
    
    }
    else {
      
      this.rowSpaceChar[i] = Character.MIN_VALUE;
    } 
  }

















  
  void calculateSizeTmpByteArray() {
    int i;
    if (this.formOfUse == 2) {


      
      i = (this.charLength - 1) * this.statement.connection.conversion.maxNCharSize;
    }
    else {
      
      i = (this.charLength - 1) * this.statement.connection.conversion.cMaxCharSize;
    } 
    
    if (this.statement.sizeTmpByteArray < i) {
      this.statement.sizeTmpByteArray = i;
    }
  }








  
  String getString(int paramInt) throws SQLException {
    String str = super.getString(paramInt);
    
    if (str != null && this.definedColumnSize > 0 && str.length() > this.definedColumnSize)
    {
      str = str.substring(0, this.definedColumnSize);
    }
    return str;
  }






  
  NUMBER getNUMBER(int paramInt) throws SQLException {
    NUMBER nUMBER = null;
    
    if (this.definedColumnType == 0) {
      nUMBER = super.getNUMBER(paramInt);
    } else {
      
      String str = getString(paramInt);
      if (str != null)
      {






        
        return T4CVarcharAccessor.StringToNUMBER(str);
      }
    } 
    
    return nUMBER;
  }



  
  DATE getDATE(int paramInt) throws SQLException {
    DATE dATE = null;
    
    if (this.definedColumnType == 0) {
      dATE = super.getDATE(paramInt);
    } else {
      
      Date date = getDate(paramInt);
      if (date != null)
      {






        
        dATE = new DATE(date);
      }
    } 
    
    return dATE;
  }




  
  TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
    TIMESTAMP tIMESTAMP = null;
    
    if (this.definedColumnType == 0) {
      tIMESTAMP = super.getTIMESTAMP(paramInt);
    } else {
      
      String str = getString(paramInt);
      if (str != null) {








        
        int[] arrayOfInt = new int[1];
        Calendar calendar = T4CVarcharAccessor.DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM"), arrayOfInt);

        
        Timestamp timestamp = new Timestamp(calendar.getTimeInMillis());
        timestamp.setNanos(arrayOfInt[0]);
        tIMESTAMP = new TIMESTAMP(timestamp);
      } 
    } 
    
    return tIMESTAMP;
  }



  
  TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
    TIMESTAMPTZ tIMESTAMPTZ = null;
    
    if (this.definedColumnType == 0) {
      tIMESTAMPTZ = super.getTIMESTAMPTZ(paramInt);
    } else {
      
      String str = getString(paramInt);
      if (str != null) {









        
        int[] arrayOfInt = new int[1];
        Calendar calendar = T4CVarcharAccessor.DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), arrayOfInt);

        
        Timestamp timestamp = new Timestamp(calendar.getTimeInMillis());
        timestamp.setNanos(arrayOfInt[0]);
        tIMESTAMPTZ = new TIMESTAMPTZ((Connection)this.statement.connection, timestamp, calendar);
      } 
    } 


    
    return tIMESTAMPTZ;
  }



  
  TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
    TIMESTAMPLTZ tIMESTAMPLTZ = null;
    
    if (this.definedColumnType == 0) {
      tIMESTAMPLTZ = super.getTIMESTAMPLTZ(paramInt);
    } else {
      
      String str = getString(paramInt);
      if (str != null) {









        
        int[] arrayOfInt = new int[1];
        Calendar calendar = T4CVarcharAccessor.DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), arrayOfInt);

        
        Timestamp timestamp = new Timestamp(calendar.getTimeInMillis());
        timestamp.setNanos(arrayOfInt[0]);
        tIMESTAMPLTZ = new TIMESTAMPLTZ((Connection)this.statement.connection, timestamp, calendar);
      } 
    } 


    
    return tIMESTAMPLTZ;
  }



  
  RAW getRAW(int paramInt) throws SQLException {
    RAW rAW = null;
    
    if (this.definedColumnType == 0) {
      rAW = super.getRAW(paramInt);
    } else {
      
      if (this.rowSpaceIndicator == null) {


        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 



      
      if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1)
      {
        if (this.definedColumnType == -2 || this.definedColumnType == -3 || this.definedColumnType == -4) {

          
          rAW = new RAW(getBytesFromHexChars(paramInt));
        } else {
          rAW = new RAW(super.getBytes(paramInt));
        } 
      }
    } 
    return rAW;
  }



  
  Datum getOracleObject(int paramInt) throws SQLException {
    if (this.definedColumnType == 0) {
      return super.getOracleObject(paramInt);
    }
    
    Datum datum = null;
    
    if (this.rowSpaceIndicator == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      switch (this.definedColumnType) {




        
        case -1:
        case 1:
        case 12:
          return super.getOracleObject(paramInt);










        
        case -7:
        case -6:
        case -5:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        case 8:
        case 16:
          return (Datum)getNUMBER(paramInt);
        
        case 91:
          return (Datum)getDATE(paramInt);
        
        case 92:
          return (Datum)getDATE(paramInt);
        
        case 93:
          return (Datum)getTIMESTAMP(paramInt);
        
        case -101:
          return (Datum)getTIMESTAMPTZ(paramInt);
        
        case -102:
          return (Datum)getTIMESTAMPLTZ(paramInt);


        
        case -4:
        case -3:
        case -2:
          return (Datum)getRAW(paramInt);
        
        case -8:
          return (Datum)getROWID(paramInt);
      } 

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    return datum;
  }





  
  byte[] getBytes(int paramInt) throws SQLException {
    if (this.definedColumnType == 0) {
      return super.getBytes(paramInt);
    }
    Datum datum = getOracleObject(paramInt);
    if (datum != null) {
      return datum.shareBytes();
    }
    return null;
  }




  
  boolean getBoolean(int paramInt) throws SQLException {
    boolean bool = false;
    
    if (this.definedColumnType == 0) {
      bool = super.getBoolean(paramInt);
    } else {
      
      bool = getNUMBER(paramInt).booleanValue();
    } 
    
    return bool;
  }




  
  byte getByte(int paramInt) throws SQLException {
    byte b = 0;
    
    if (this.definedColumnType == 0) {
      b = super.getByte(paramInt);
    } else {
      
      NUMBER nUMBER = getNUMBER(paramInt);
      if (nUMBER != null) {
        b = nUMBER.byteValue();
      }
    } 
    return b;
  }




  
  int getInt(int paramInt) throws SQLException {
    int i = 0;
    
    if (this.definedColumnType == 0) {
      i = super.getInt(paramInt);
    } else {
      
      NUMBER nUMBER = getNUMBER(paramInt);
      if (nUMBER != null) {
        i = nUMBER.intValue();
      }
    } 
    return i;
  }




  
  short getShort(int paramInt) throws SQLException {
    short s = 0;
    
    if (this.definedColumnType == 0) {
      s = super.getShort(paramInt);
    } else {
      
      NUMBER nUMBER = getNUMBER(paramInt);
      if (nUMBER != null) {
        s = nUMBER.shortValue();
      }
    } 
    return s;
  }




  
  long getLong(int paramInt) throws SQLException {
    long l = 0L;
    
    if (this.definedColumnType == 0) {
      l = super.getLong(paramInt);
    } else {
      
      NUMBER nUMBER = getNUMBER(paramInt);
      if (nUMBER != null) {
        l = nUMBER.longValue();
      }
    } 
    return l;
  }




  
  float getFloat(int paramInt) throws SQLException {
    float f = 0.0F;
    
    if (this.definedColumnType == 0) {
      f = super.getFloat(paramInt);
    } else {
      
      NUMBER nUMBER = getNUMBER(paramInt);
      if (nUMBER != null) {
        f = nUMBER.floatValue();
      }
    } 
    return f;
  }




  
  double getDouble(int paramInt) throws SQLException {
    double d = 0.0D;
    
    if (this.definedColumnType == 0) {
      d = super.getDouble(paramInt);
    } else {
      
      NUMBER nUMBER = getNUMBER(paramInt);
      if (nUMBER != null) {
        d = nUMBER.doubleValue();
      }
    } 
    return d;
  }






  
  Date getDate(int paramInt) throws SQLException {
    Date date = null;
    
    if (this.definedColumnType == 0) {
      date = super.getDate(paramInt);
    } else {
      
      String str = getString(paramInt);
      if (str != null) {







        
        int[] arrayOfInt = new int[1];
        
        date = new Date(T4CVarcharAccessor.DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCDATEFM"), arrayOfInt).getTimeInMillis());
      } 
    } 


    
    return date;
  }




  
  Timestamp getTimestamp(int paramInt) throws SQLException {
    Timestamp timestamp = null;
    
    if (this.definedColumnType == 0) {
      timestamp = super.getTimestamp(paramInt);
    } else {
      
      String str = getString(paramInt);
      if (str != null) {
        
        int[] arrayOfInt = new int[1];
        Calendar calendar = T4CVarcharAccessor.DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM"), arrayOfInt);

        
        timestamp = new Timestamp(calendar.getTimeInMillis());
        timestamp.setNanos(arrayOfInt[0]);
      } 
    } 
    
    return timestamp;
  }




  
  Time getTime(int paramInt) throws SQLException {
    Time time = null;
    
    if (this.definedColumnType == 0) {
      time = super.getTime(paramInt);
    } else {
      
      String str = getString(paramInt);
      if (str != null) {
        
        int[] arrayOfInt = new int[1];
        Calendar calendar = T4CVarcharAccessor.DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), arrayOfInt);

        
        time = new Time(calendar.getTimeInMillis());
      } 
    } 
    
    return time;
  }




  
  Object getObject(int paramInt) throws SQLException {
    if (this.definedColumnType == 0) {
      return super.getObject(paramInt);
    }
    
    Object object = null;
    
    if (this.rowSpaceIndicator == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      switch (this.definedColumnType) {




        
        case -1:
        case 1:
        case 12:
          return getString(paramInt);

        
        case 2:
        case 3:
          return getBigDecimal(paramInt);
        
        case 4:
          return Integer.valueOf(getInt(paramInt));
        
        case -6:
          return Byte.valueOf(getByte(paramInt));
        
        case 5:
          return Short.valueOf(getShort(paramInt));

        
        case -7:
        case 16:
          return Boolean.valueOf(getBoolean(paramInt));
        
        case -5:
          return Long.valueOf(getLong(paramInt));
        
        case 7:
          return Float.valueOf(getFloat(paramInt));

        
        case 6:
        case 8:
          return Double.valueOf(getDouble(paramInt));
        
        case 91:
          return getDate(paramInt);
        
        case 92:
          return getTime(paramInt);
        
        case 93:
          return getTimestamp(paramInt);


        
        case -4:
        case -3:
        case -2:
          return getBytesFromHexChars(paramInt);
      } 

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    return object;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
