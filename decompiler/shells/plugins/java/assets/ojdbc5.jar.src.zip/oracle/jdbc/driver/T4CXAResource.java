package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import javax.sql.XAConnection;
import javax.transaction.xa.XAException;
import javax.transaction.xa.XAResource;
import javax.transaction.xa.Xid;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.xa.OracleXAConnection;
import oracle.jdbc.xa.OracleXAException;
import oracle.jdbc.xa.OracleXid;
import oracle.jdbc.xa.client.OracleXADataSource;
import oracle.jdbc.xa.client.OracleXAResource;

















class T4CXAResource
  extends OracleXAResource
{
  T4CConnection physicalConn;
  int[] applicationValueArr = new int[1];
  
  boolean isTransLoose = false;
  
  byte[] context;
  
  int errorNumber;
  
  private String password;
  
  T4CXAResource(T4CConnection paramT4CConnection, OracleXAConnection paramOracleXAConnection, boolean paramBoolean) throws XAException {
    super((Connection)paramT4CConnection, paramOracleXAConnection);
    
    this.physicalConn = paramT4CConnection;
    this.isTransLoose = paramBoolean;
  }




  
  protected int doStart(Xid paramXid, int paramInt) throws XAException {
    synchronized (this.physicalConn) {
      
      int i = -1;






















      
      if (this.isTransLoose) {
        paramInt |= 0x10000;
      }




      
      int j = paramInt & 0x8200000;

      
      if (j == 134217728 && OracleXid.isLocalTransaction(paramXid)) {
        return 0;
      }




































      
      this.applicationValueArr[0] = 0;


      
      try {
        try {
          T4CTTIOtxse t4CTTIOtxse = this.physicalConn.otxse;
          byte[] arrayOfByte1 = null;
          byte[] arrayOfByte2 = paramXid.getGlobalTransactionId();
          byte[] arrayOfByte3 = paramXid.getBranchQualifier();
          
          int k = 0;
          int m = 0;
          
          if (arrayOfByte2 != null && arrayOfByte3 != null) {
            
            k = Math.min(arrayOfByte2.length, 64);
            m = Math.min(arrayOfByte3.length, 64);
            arrayOfByte1 = new byte[128];
            
            System.arraycopy(arrayOfByte2, 0, arrayOfByte1, 0, k);
            System.arraycopy(arrayOfByte3, 0, arrayOfByte1, k, m);
          } 
          
          int n = 0;

          
          if ((paramInt & 0x200000) != 0 || (paramInt & 0x8000000) != 0) {
            n |= 0x4;
          } else {
            n |= 0x1;
          } 
          if ((paramInt & 0x100) != 0) {
            n |= 0x100;
          }
          if ((paramInt & 0x200) != 0) {
            n |= 0x200;
          }
          if ((paramInt & 0x400) != 0) {
            n |= 0x400;
          }
          if ((paramInt & 0x10000) != 0) {
            n |= 0x10000;
          }



          
          this.physicalConn.needLine();
          this.physicalConn.sendPiggyBackedMessages();
          t4CTTIOtxse.doOTXSE(1, null, arrayOfByte1, paramXid.getFormatId(), k, m, this.timeout, n, this.applicationValueArr);


          
          this.applicationValueArr[0] = t4CTTIOtxse.getApplicationValue();
          byte[] arrayOfByte4 = t4CTTIOtxse.getContext();


          
          if (arrayOfByte4 != null) {
            this.context = arrayOfByte4;
          }
          i = 0;
        }
        catch (IOException iOException) {





          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
          sQLException.fillInStackTrace();
          throw sQLException;
        }
      
      }
      catch (SQLException sQLException) {


        
        i = sQLException.getErrorCode();


        
        if (i == 0) {
          throw new XAException(-6);
        }
      } 




































      
      return i;
    } 
  }




  
  protected int doEnd(Xid paramXid, int paramInt, boolean paramBoolean) throws XAException {
    synchronized (this.physicalConn) {
      
      int i = -1;




















      
      try {
        T4CTTIOtxse t4CTTIOtxse = this.physicalConn.otxse;
        byte[] arrayOfByte1 = null;
        byte[] arrayOfByte2 = paramXid.getGlobalTransactionId();
        byte[] arrayOfByte3 = paramXid.getBranchQualifier();
        
        int j = 0;
        int k = 0;
        
        if (arrayOfByte2 != null && arrayOfByte3 != null) {
          
          j = Math.min(arrayOfByte2.length, 64);
          k = Math.min(arrayOfByte3.length, 64);
          arrayOfByte1 = new byte[128];
          
          System.arraycopy(arrayOfByte2, 0, arrayOfByte1, 0, j);
          System.arraycopy(arrayOfByte3, 0, arrayOfByte1, j, k);
        } 


        
        if (this.context == null) {
          
          i = doStart(paramXid, 134217728);
          
          if (i != 0) {
            return i;
          }
        } 
        byte[] arrayOfByte4 = this.context;
        int m = 0;
        if ((paramInt & 0x2) == 2) {
          
          m = 1048576;
        } else if ((paramInt & 0x2000000) == 33554432 && (paramInt & 0x100000) != 1048576) {











          
          m = 1048576;
        } 



        
        this.applicationValueArr[0] = this.applicationValueArr[0] >> 16;






        
        this.physicalConn.needLine();
        this.physicalConn.sendPiggyBackedMessages();
        t4CTTIOtxse.doOTXSE(2, arrayOfByte4, arrayOfByte1, paramXid.getFormatId(), j, k, this.timeout, m, this.applicationValueArr);


        
        this.applicationValueArr[0] = t4CTTIOtxse.getApplicationValue();
        byte[] arrayOfByte5 = t4CTTIOtxse.getContext();

        
        if (arrayOfByte5 != null) {
          this.context = arrayOfByte5;
        }
        i = 0;
      }
      catch (IOException iOException) {





        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
        sQLException.fillInStackTrace();
        throw sQLException;

      
      }
      catch (SQLException sQLException) {


        
        i = sQLException.getErrorCode();


        
        if (i == 0) {
          throw new XAException(-6);
        }
      } 
      return i;
    } 
  }














  
  protected void doCommit(Xid paramXid, boolean paramBoolean) throws SQLException, XAException {
    synchronized (this.physicalConn) {

      
      byte b = paramBoolean ? 4 : 2;

      
      try {
        int i = doTransaction(paramXid, 1, b);

        
        if (!paramBoolean || (i != 2 && i != 4))
        {



          
          if (paramBoolean || i != 5) {


            
            if (i == 8) {
              throw new XAException(106);
            }
            throw new XAException(-6);
          }  } 
      } catch (SQLException sQLException) {
        
        int i = sQLException.getErrorCode();
        if (i == 24756) {


          
          kputxrec(paramXid, 1, this.timeout + 120, sQLException);
        }
        else if (i == 24780) {


          
          OracleXADataSource oracleXADataSource = null;
          XAConnection xAConnection = null;

          
          try {
            oracleXADataSource = new OracleXADataSource();
            
            oracleXADataSource.setURL(this.physicalConn.url);
            oracleXADataSource.setUser(this.physicalConn.userName);
            this.physicalConn.getPasswordInternal(this);
            oracleXADataSource.setPassword(this.password);
            
            xAConnection = oracleXADataSource.getXAConnection();
            
            XAResource xAResource = xAConnection.getXAResource();
            
            xAResource.commit(paramXid, paramBoolean);
          }
          catch (SQLException sQLException1) {


            
            XAException xAException = new XAException(-6);
            xAException.initCause(sQLException1);
            throw xAException;
          } finally {

            
            try {
              
              if (xAConnection != null) {
                xAConnection.close();
              }
              if (oracleXADataSource != null) {
                oracleXADataSource.close();
              }
            } catch (Exception exception) {}
          }
        
        }
        else {
          
          throw sQLException;
        } 
      } 
    } 
  }




  
  protected int doPrepare(Xid paramXid) throws XAException, SQLException {
    synchronized (this.physicalConn) {
      
      byte b = -1;
      try {
        int i = doTransaction(paramXid, 3, 0);

        
        if (i == 8)
        {
          
          throw new XAException(106);
        }
        if (i == 4) {

          
          b = 3;
        }
        else if (i == 1) {

          
          b = 0;
        } else {
          if (i == 3)
          {


            
            throw new XAException(100);
          }


          
          throw new XAException(-6);
        }
      
      } catch (SQLException sQLException) {
        
        int i = sQLException.getErrorCode();




        
        if (i == 25351) {

          
          XAException xAException = new XAException(-6);
          xAException.initCause(sQLException);
          throw xAException;
        } 
        throw sQLException;
      } 
      return b;
    } 
  }




  
  protected int doForget(Xid paramXid) throws XAException, SQLException {
    synchronized (this.physicalConn) {
      
      boolean bool = false;
      
      if (OracleXid.isLocalTransaction(paramXid)) {
        return 24771;
      }

      
      int i = doStart(paramXid, 134217728);
      
      if (i != 24756) {


        
        if (i == 0) {
          
          try {


            
            doEnd(paramXid, 0, false);
          }
          catch (Exception exception) {}
        }



        
        if (i == 0 || i == 2079 || i == 24754 || i == 24761 || i == 24774 || i == 24776 || i == 25351)
        {




          
          return 24769; } 
        if (i == 24752) {
          return 24771;
        }
        return i;
      } 
      
      kputxrec(paramXid, 4, 1, null);
      
      return bool;
    } 
  }



  
  protected void doRollback(Xid paramXid) throws XAException, SQLException {
    synchronized (this.physicalConn) {

      
      try {
        int i = doTransaction(paramXid, 2, 3);

        
        if (i == 8)
          throw new XAException(106); 
        if (i != 3)
        {


          
          throw new XAException(-6);
        }
      } catch (SQLException sQLException) {
        
        int i = sQLException.getErrorCode();

        
        if (i == 24756) {


          
          kputxrec(paramXid, 2, this.timeout + 120, sQLException);
        }
        else if (i == 24780) {



          
          OracleXADataSource oracleXADataSource = null;
          XAConnection xAConnection = null;

          
          try {
            oracleXADataSource = new OracleXADataSource();
            
            oracleXADataSource.setURL(this.physicalConn.url);
            oracleXADataSource.setUser(this.physicalConn.userName);
            this.physicalConn.getPasswordInternal(this);
            oracleXADataSource.setPassword(this.password);
            
            xAConnection = oracleXADataSource.getXAConnection();
            
            XAResource xAResource = xAConnection.getXAResource();
            
            xAResource.rollback(paramXid);
          
          }
          catch (SQLException sQLException1) {

            
            XAException xAException = new XAException(-6);
            xAException.initCause(sQLException1);
            throw xAException;
          } finally {

            
            try {
              
              if (xAConnection != null) {
                xAConnection.close();
              }
              if (oracleXADataSource != null) {
                oracleXADataSource.close();
              }
            } catch (Exception exception) {}
          }
        
        } else if (i != 25402) {




          
          throw sQLException;
        } 
      } 
    } 
  }














  
  int doTransaction(Xid paramXid, int paramInt1, int paramInt2) throws SQLException {
    int i = -1;



    
    try {
      T4CTTIOtxen t4CTTIOtxen = this.physicalConn.otxen;
      byte[] arrayOfByte1 = null;
      byte[] arrayOfByte2 = paramXid.getGlobalTransactionId();
      byte[] arrayOfByte3 = paramXid.getBranchQualifier();
      
      int j = 0;
      int k = 0;
      
      if (arrayOfByte2 != null && arrayOfByte3 != null) {
        
        j = Math.min(arrayOfByte2.length, 64);
        k = Math.min(arrayOfByte3.length, 64);
        arrayOfByte1 = new byte[128];
        
        System.arraycopy(arrayOfByte2, 0, arrayOfByte1, 0, j);
        System.arraycopy(arrayOfByte3, 0, arrayOfByte1, j, k);
      } 
      
      byte[] arrayOfByte4 = this.context;
      
      this.physicalConn.needLine();
      this.physicalConn.sendPiggyBackedMessages();
      t4CTTIOtxen.doOTXEN(paramInt1, arrayOfByte4, arrayOfByte1, paramXid.getFormatId(), j, k, this.timeout, paramInt2, 0);
      
      i = t4CTTIOtxen.getOutStateFromServer();

    
    }
    catch (IOException iOException) {







      
      this.physicalConn.handleIOException(iOException);
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    return i;
  }












  
  protected void kputxrec(Xid paramXid, int paramInt1, int paramInt2, SQLException paramSQLException) throws XAException, SQLException {
    byte b1, b2;
    switch (paramInt1) {

      
      case 1:
        b1 = 3;
        break;

      
      case 4:
        b1 = 2;
        break;

      
      default:
        b1 = 0;
        break;
    } 
    
    int i = 0;

    
    while (paramInt2-- > 0) {
      
      i = doTransaction(paramXid, 5, b1);
      
      if (i == 7) {
        
        try {

          
          Thread.sleep(1000L);
        }
        catch (Exception exception) {}
      }
    } 






    
    if (i == 7)
    {

      
      throw new XAException(-6);
    }






    
    byte b = -1;
    
    switch (i) {

      
      case 3:
        if (paramInt1 == 1) {
          byte b3 = 7;
          
          break;
        } 
        b2 = 8;
        b = -3;
        break;


      
      case 0:
        if (paramInt1 == 4) {
          
          b2 = 8;
          b = -3;
          
          break;
        } 
        b2 = 7;
        if (paramInt1 == 1) {
          b = -4;
        }
        break;

      
      case 2:
        if (paramInt1 == 4) {
          
          b2 = 8;

          
          b = -6;
          break;
        } 
      case 5:
        if (paramInt1 == 4) {
          
          b2 = 7;
          
          break;
        } 
        b = 7;
        b2 = 8;
        break;

      
      case 4:
        if (paramInt1 == 4) {
          
          b2 = 7;
          
          break;
        } 
        b = 6;
        b2 = 8;
        break;

      
      case 6:
        if (paramInt1 == 4) {
          
          b2 = 7;
          
          break;
        } 
        b = 5;
        b2 = 8;
        break;


      
      default:
        b = -3;
        b2 = 8;
        break;
    } 

    
    T4CTTIk2rpc t4CTTIk2rpc = this.physicalConn.k2rpc;

    
    try {
      t4CTTIk2rpc.doOK2RPC(3, b2);
    }
    catch (IOException iOException) {

      
      XAException xAException = new XAException(-7);
      xAException.initCause(iOException);
      throw xAException;
    }
    catch (SQLException sQLException) {

      
      XAException xAException = new XAException(-6);
      xAException.initCause(sQLException);
      throw xAException;
    } 
    
    if (b != -1) {


      
      OracleXAException oracleXAException = null;
      if (paramSQLException != null) {
        
        oracleXAException = new OracleXAException(paramSQLException.getErrorCode(), b);
        oracleXAException.initCause(paramSQLException);
      } else {
        
        oracleXAException = new OracleXAException(0, b);
      } 
      throw oracleXAException;
    } 
  }




  
  final void setPasswordInternal(String paramString) {
    this.password = paramString;
  }










  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return this.physicalConn;
  }










































































  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
