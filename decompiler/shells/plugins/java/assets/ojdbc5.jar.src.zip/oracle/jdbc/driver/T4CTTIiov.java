package oracle.jdbc.driver;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import oracle.jdbc.oracore.OracleTypeADT;




























class T4CTTIiov
  extends T4CTTIMsg
{
  T4C8TTIrxh rxh;
  T4CTTIrxd rxd;
  short bindtype = 0;
  
  byte[] iovector;
  int bindcnt = 0;
  int inbinds = 0;
  int outbinds = 0;



  
  static final byte BV_IN_V = 32;



  
  static final byte BV_OUT_V = 16;



  
  T4CTTIiov(T4CConnection paramT4CConnection, T4C8TTIrxh paramT4C8TTIrxh, T4CTTIrxd paramT4CTTIrxd) throws SQLException, IOException {
    super(paramT4CConnection, (byte)0);
    
    this.rxh = paramT4C8TTIrxh;
    this.rxd = paramT4CTTIrxd;
  }















  
  void init() throws SQLException, IOException {}














  
  Accessor[] processRXD(Accessor[] paramArrayOfAccessor, int paramInt1, byte[] paramArrayOfbyte1, char[] paramArrayOfchar1, short[] paramArrayOfshort1, int paramInt2, DBConversion paramDBConversion, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, InputStream[][] paramArrayOfInputStream, byte[][][] paramArrayOfbyte, OracleTypeADT[][] paramArrayOfOracleTypeADT, OracleStatement paramOracleStatement, byte[] paramArrayOfbyte4, char[] paramArrayOfchar2, short[] paramArrayOfshort2) throws SQLException, IOException {
    if (paramArrayOfbyte3 != null)
    {
      for (byte b = 0; b < paramArrayOfbyte3.length; b++) {
        
        if ((paramArrayOfbyte3[b] & 0x10) != 0 && (paramArrayOfAccessor == null || paramArrayOfAccessor.length <= b || paramArrayOfAccessor[b] == null)) {





          
          int i = paramInt2 + 5 + 10 * b;



          
          int j = paramArrayOfshort1[i + 0] & 0xFFFF;

          
          int k = j;
          
          if (j == 9) {
            j = 1;
          }
          Accessor accessor = paramOracleStatement.allocateAccessor(j, j, b, 0, (short)0, null, false);







          
          accessor.rowSpaceIndicator = null;

          
          if (accessor.defineType == 109 || accessor.defineType == 111)
          {
            accessor.setOffsets(1);
          }
          if (paramArrayOfAccessor == null)
          {
            paramArrayOfAccessor = new Accessor[b + 1];
            paramArrayOfAccessor[b] = accessor;
          }
          else if (paramArrayOfAccessor.length <= b)
          {
            Accessor[] arrayOfAccessor = new Accessor[b + 1];
            
            arrayOfAccessor[b] = accessor;
            
            for (byte b1 = 0; b1 < paramArrayOfAccessor.length; b1++) {
              
              if (paramArrayOfAccessor[b1] != null) {
                arrayOfAccessor[b1] = paramArrayOfAccessor[b1];
              }
            } 
            paramArrayOfAccessor = arrayOfAccessor;
          
          }
          else
          {
            
            paramArrayOfAccessor[b] = accessor;
          }
        
        } else if ((paramArrayOfbyte3[b] & 0x10) == 0 && paramArrayOfAccessor != null && b < paramArrayOfAccessor.length && paramArrayOfAccessor[b] != null) {




          
          (paramArrayOfAccessor[b]).isUseLess = true;
        } 
      } 
    }


    
    return paramArrayOfAccessor;
  }





  
  void unmarshalV10() throws IOException, SQLException {
    this.rxh.unmarshalV10(this.rxd);
    
    this.bindcnt = this.rxh.numRqsts;








    
    this.iovector = new byte[this.connection.all8.numberOfBindPositions];
    
    for (byte b = 0; b < this.iovector.length; b++) {


      
      if ((this.bindtype = this.meg.unmarshalUB1()) == 0) {


        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 



      
      if ((this.bindtype & 0x20) > 0) {
        
        this.iovector[b] = (byte)(this.iovector[b] | 0x20);
        this.inbinds++;
      } 
      
      if ((this.bindtype & 0x10) > 0) {
        
        this.iovector[b] = (byte)(this.iovector[b] | 0x10);
        this.outbinds++;
      } 
    } 
  }












  
  byte[] getIOVector() {
    return this.iovector;
  }







  
  boolean isIOVectorEmpty() {
    return (this.iovector.length == 0);
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
