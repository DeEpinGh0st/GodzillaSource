package oracle.jdbc.driver;

import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.logging.Level;



























































public class OracleLog
{
  private static final int maxPrintBytes = 512;
  public static final boolean TRACE = false;
  
  public static boolean isDebugZip() {
    boolean bool = true;

    
    bool = false;
    return bool;
  }











  
  public static boolean isPrivateLogAvailable() {
    return false;
  }










  
  public static boolean isEnabled() {
    return false;
  }







  
  public static boolean registerClassNameAndGetCurrentTraceSetting(Class paramClass) {
    return false;
  }









  
  public static void setTrace(boolean paramBoolean) {}









  
  private static void initialize() {
    setupFromSystemProperties();
  }







  
  public static void setupFromSystemProperties() {
    boolean bool = false;
    securityExceptionWhileGettingSystemProperties = false;
    
    try {
      String str = null;
      str = getSystemProperty("oracle.jdbc.Trace", null);
      if (str != null && str.compareTo("true") == 0) {
        bool = true;
      }
    } catch (SecurityException securityException) {
      
      securityExceptionWhileGettingSystemProperties = true;
    } 
    setTrace(bool);
  }













  
  private static String getSystemProperty(String paramString) {
    return getSystemProperty(paramString, null);
  }




  
  private static String getSystemProperty(String paramString1, String paramString2) {
    if (paramString1 != null) {
      
      final String fstr = paramString1;
      final String fdefaultValue = paramString2;
      final String[] retStr = { paramString2 };
      AccessController.doPrivileged(new PrivilegedAction()
          {
            public Object run()
            {
              retStr[0] = System.getProperty(fstr, fdefaultValue);
              return null;
            }
          });
      return arrayOfString[0];
    } 
    return paramString2;
  }






  
  public static String argument() {
    return "";
  }
  
  public static String argument(boolean paramBoolean) {
    return Boolean.toString(paramBoolean);
  }
  
  public static String argument(byte paramByte) {
    return Byte.toString(paramByte);
  }
  
  public static String argument(short paramShort) {
    return Short.toString(paramShort);
  }
  
  public static String argument(int paramInt) {
    return Integer.toString(paramInt);
  }
  
  public static String argument(long paramLong) {
    return Long.toString(paramLong);
  }
  
  public static String argument(float paramFloat) {
    return Float.toString(paramFloat);
  }
  
  public static String argument(double paramDouble) {
    return Double.toString(paramDouble);
  }
  
  public static String argument(Object paramObject) {
    if (paramObject == null) return "null"; 
    if (paramObject instanceof String) return "\"" + (String)paramObject + "\""; 
    return paramObject.toString();
  }


















  
  public static String byteToHexString(byte paramByte) {
    StringBuffer stringBuffer = new StringBuffer("");
    int i = 0xFF & paramByte;
    
    if (i <= 15) {
      stringBuffer.append("0x0");
    } else {
      stringBuffer.append("0x");
    } 
    stringBuffer.append(Integer.toHexString(i));
    
    return stringBuffer.toString();
  }

















  
  public static String bytesToPrintableForm(String paramString, byte[] paramArrayOfbyte) {
    boolean bool = (paramArrayOfbyte == null) ? false : paramArrayOfbyte.length;
    
    return bytesToPrintableForm(paramString, paramArrayOfbyte, bool);
  }




















  
  public static String bytesToPrintableForm(String paramString, byte[] paramArrayOfbyte, int paramInt) {
    String str = null;
    
    if (paramArrayOfbyte == null) {
      str = paramString + ": null";
    } else {
      str = paramString + " (" + paramArrayOfbyte.length + " bytes):\n" + bytesToFormattedStr(paramArrayOfbyte, paramInt, "  ");
    } 
    
    return str;
  }























  
  public static String bytesToFormattedStr(byte[] paramArrayOfbyte, int paramInt, String paramString) {
    StringBuffer stringBuffer = new StringBuffer("");
    
    if (paramString == null) {
      paramString = new String("");
    }
    stringBuffer.append(paramString);
    
    if (paramArrayOfbyte == null) {
      
      stringBuffer.append("byte [] is null");
      
      return stringBuffer.toString();
    } 
    
    for (byte b = 0; b < paramInt; b++) {
      
      if (b >= 'Ȁ') {
        
        stringBuffer.append("\n" + paramString + "... last " + (paramInt - 512) + " bytes were not printed to limit the output size");

        
        break;
      } 
      
      if (b > 0 && b % 20 == 0) {
        stringBuffer.append("\n" + paramString);
      }
      if (b % 20 == 10) {
        stringBuffer.append(" ");
      }
      int i = 0xFF & paramArrayOfbyte[b];
      
      if (i <= 15) {
        stringBuffer.append("0");
      }
      stringBuffer.append(Integer.toHexString(i) + " ");
    } 
    
    return stringBuffer.toString();
  }













  
  public static byte[] strToUcs2Bytes(String paramString) {
    if (paramString == null) {
      return null;
    }
    return charsToUcs2Bytes(paramString.toCharArray());
  }













  
  public static byte[] charsToUcs2Bytes(char[] paramArrayOfchar) {
    if (paramArrayOfchar == null) {
      return null;
    }
    return charsToUcs2Bytes(paramArrayOfchar, paramArrayOfchar.length);
  }















  
  public static byte[] charsToUcs2Bytes(char[] paramArrayOfchar, int paramInt) {
    if (paramArrayOfchar == null) {
      return null;
    }
    if (paramInt < 0) {
      return null;
    }
    return charsToUcs2Bytes(paramArrayOfchar, paramInt, 0);
  }








  
  public static byte[] charsToUcs2Bytes(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
    if (paramArrayOfchar == null) {
      return null;
    }
    if (paramInt1 > paramArrayOfchar.length - paramInt2) {
      paramInt1 = paramArrayOfchar.length - paramInt2;
    }
    if (paramInt1 < 0) {
      return null;
    }
    byte[] arrayOfByte = new byte[2 * paramInt1]; byte b;
    int i;
    for (i = paramInt2, b = 0; i < paramInt1; i++) {
      
      arrayOfByte[b++] = (byte)(paramArrayOfchar[i] >> 8 & 0xFF);
      arrayOfByte[b++] = (byte)(paramArrayOfchar[i] & 0xFF);
    } 
    
    return arrayOfByte;
  }














  
  public static String toPrintableStr(String paramString, int paramInt) {
    if (paramString == null)
    {
      return "null";
    }
    
    if (paramString.length() > paramInt)
    {
      return paramString.substring(0, paramInt - 1) + "\n ... the actual length was " + paramString.length();
    }

    
    return paramString;
  }









  
  public static final Level INTERNAL_ERROR = OracleLevel.INTERNAL_ERROR;
  public static final Level TRACE_1 = OracleLevel.TRACE_1;
  public static final Level TRACE_10 = OracleLevel.TRACE_10;
  public static final Level TRACE_16 = OracleLevel.TRACE_16;
  public static final Level TRACE_20 = OracleLevel.TRACE_20;
  public static final Level TRACE_30 = OracleLevel.TRACE_30;
  public static final Level TRACE_32 = OracleLevel.TRACE_32;


  
  static boolean securityExceptionWhileGettingSystemProperties;


  
  static {
    initialize();
  }




  
  public static String toHex(long paramLong, int paramInt) {
    String str;
    switch (paramInt) {
      
      case 1:
        str = "00" + Long.toString(paramLong & 0xFFL, 16);

























        
        return "0x" + str.substring(str.length() - 2 * paramInt);case 2: str = "0000" + Long.toString(paramLong & 0xFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 3: str = "000000" + Long.toString(paramLong & 0xFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 4: str = "00000000" + Long.toString(paramLong & 0xFFFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 5: str = "0000000000" + Long.toString(paramLong & 0xFFFFFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 6: str = "000000000000" + Long.toString(paramLong & 0xFFFFFFFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 7: str = "00000000000000" + Long.toString(paramLong & 0xFFFFFFFFFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);
      case 8:
        return toHex(paramLong >> 32L, 4) + toHex(paramLong, 4).substring(2);
    } 
    return "more than 8 bytes"; } public static String toHex(byte paramByte) {
    String str = "00" + Integer.toHexString(paramByte & 0xFF);
    return "0x" + str.substring(str.length() - 2);
  }

  
  public static String toHex(short paramShort) {
    return toHex(paramShort, 2);
  }

  
  public static String toHex(int paramInt) {
    return toHex(paramInt, 4);
  }

  
  public static String toHex(byte[] paramArrayOfbyte, int paramInt) {
    if (paramArrayOfbyte == null)
      return "null"; 
    if (paramInt > paramArrayOfbyte.length)
      return "byte array not long enough"; 
    String str = "[";
    int i = Math.min(64, paramInt);
    for (byte b = 0; b < i; b++)
    {
      str = str + toHex(paramArrayOfbyte[b]) + " ";
    }
    if (i < paramInt)
      str = str + "..."; 
    return str + "]";
  }

  
  public static String toHex(byte[] paramArrayOfbyte) {
    if (paramArrayOfbyte == null)
      return "null"; 
    return toHex(paramArrayOfbyte, paramArrayOfbyte.length);
  }


  
  private static class OracleLevel
    extends Level
  {
    static final OracleLevel INTERNAL_ERROR = new OracleLevel("INTERNAL_ERROR", 1100);
    static final OracleLevel TRACE_1 = new OracleLevel("TRACE_1", Level.FINE.intValue());
    static final OracleLevel TRACE_10 = new OracleLevel("TRACE_10", 446);
    static final OracleLevel TRACE_16 = new OracleLevel("TRACE_16", Level.FINER.intValue());
    static final OracleLevel TRACE_20 = new OracleLevel("TRACE_20", 376);
    static final OracleLevel TRACE_30 = new OracleLevel("TRACE_30", 316);
    static final OracleLevel TRACE_32 = new OracleLevel("TRACE_32", Level.FINEST.intValue());
    
    OracleLevel(String param1String, int param1Int) {
      super(param1String, param1Int);
    }
  }
}
