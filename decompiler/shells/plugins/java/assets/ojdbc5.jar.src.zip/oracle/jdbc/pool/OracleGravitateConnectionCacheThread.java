package oracle.jdbc.pool;

import java.sql.SQLException;
















class OracleGravitateConnectionCacheThread
  extends Thread
{
  protected OracleImplicitConnectionCache implicitCache = null;




  
  OracleGravitateConnectionCacheThread(OracleImplicitConnectionCache paramOracleImplicitConnectionCache) throws SQLException {
    this.implicitCache = paramOracleImplicitConnectionCache;
  }




  
  public void run() {
    this.implicitCache.gravitateCache();
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
