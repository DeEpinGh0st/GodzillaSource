package oracle.jdbc.driver;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.TimeZone;
import oracle.sql.DATE;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPTZ;

















abstract class DateTimeCommonAccessor
  extends Accessor
{
  static final int GREGORIAN_CUTOVER_YEAR = 1582;
  static final long GREGORIAN_CUTOVER = -12219292800000L;
  static final int JAN_1_1_JULIAN_DAY = 1721426;
  static final int EPOCH_JULIAN_DAY = 2440588;
  static final int ONE_SECOND = 1000;
  static final int ONE_MINUTE = 60000;
  static final int ONE_HOUR = 3600000;
  static final long ONE_DAY = 86400000L;
  static final int[] NUM_DAYS = new int[] { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 };



  
  static final int[] LEAP_NUM_DAYS = new int[] { 0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335 };
  
  static final int ORACLE_CENTURY = 0;
  
  static final int ORACLE_YEAR = 1;
  
  static final int ORACLE_MONTH = 2;
  
  static final int ORACLE_DAY = 3;
  
  static final int ORACLE_HOUR = 4;
  
  static final int ORACLE_MIN = 5;
  
  static final int ORACLE_SEC = 6;
  
  static final int ORACLE_NANO1 = 7;
  
  static final int ORACLE_NANO2 = 8;
  
  static final int ORACLE_NANO3 = 9;
  static final int ORACLE_NANO4 = 10;
  static final int ORACLE_TZ1 = 11;
  static final int ORACLE_TZ2 = 12;
  static final int SIZE_DATE = 7;
  static final int MAX_TIMESTAMP_LENGTH = 11;
  static TimeZone epochTimeZone;
  static long epochTimeZoneOffset;
  
  Time getTime(int paramInt) throws SQLException {
    Time time = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      int i = this.columnIndex + this.byteLength * paramInt;


      
      TimeZone timeZone = this.statement.getDefaultTimeZone();
      
      if (timeZone != epochTimeZone) {
        
        epochTimeZoneOffset = calculateEpochOffset(timeZone);
        epochTimeZone = timeZone;
      } 
      
      time = new Time(oracleTime(i) - epochTimeZoneOffset);
    } 
    
    return time;
  }





  
  Date getDate(int paramInt) throws SQLException {
    return getDate(paramInt, this.statement.getDefaultCalendar());
  }





  
  Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
    if (paramCalendar == null) {
      return getDate(paramInt);
    }
    Date date = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      int i = this.columnIndex + this.byteLength * paramInt;
      int j = oracleYear(i);
      
      Calendar calendar = (Calendar)paramCalendar.clone();
      
      calendar.set(j, oracleMonth(i), oracleDay(i), 0, 0, 0);
      calendar.set(14, 0);


      
      if (j > 0 && calendar.isSet(0)) {
        calendar.set(0, 1);
      }
      date = new Date(calendar.getTimeInMillis());
    } 
    
    return date;
  }





  
  Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
    if (paramCalendar == null)
    {
      return getTime(paramInt);
    }
    
    Time time = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      int i = this.columnIndex + this.byteLength * paramInt;
      int j = oracleYear(i);
      
      Calendar calendar = (Calendar)paramCalendar.clone();
      
      calendar.set(1, 1970);
      calendar.set(2, 0);
      calendar.set(5, 1);
      calendar.set(11, oracleHour(i));
      calendar.set(12, oracleMin(i));
      calendar.set(13, oracleSec(i));
      calendar.set(14, 0);


      
      if (j > 0 && calendar.isSet(0)) {
        calendar.set(0, 1);
      }
      time = new Time(calendar.getTimeInMillis());
    } 
    
    return time;
  }




  
  Timestamp getTimestamp(int paramInt) throws SQLException {
    return getTimestamp(paramInt, this.statement.getDefaultCalendar());
  }





  
  Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
    if (paramCalendar == null)
    {
      return getTimestamp(paramInt);
    }
    
    Timestamp timestamp = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      int i = this.columnIndex + this.byteLength * paramInt;
      int j = oracleYear(i);
      
      Calendar calendar = (Calendar)paramCalendar.clone();
      calendar.set(j, oracleMonth(i), oracleDay(i), oracleHour(i), oracleMin(i), oracleSec(i));
      
      calendar.set(14, 0);


      
      if (j > 0 && calendar.isSet(0)) {
        calendar.set(0, 1);
      }
      timestamp = new Timestamp(calendar.getTimeInMillis());
      
      short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
      if (s >= 11)
      {
        timestamp.setNanos(oracleNanos(i));
      }
    } 
    
    return timestamp;
  }






  
  DATE getDATE(int paramInt) throws SQLException {
    DATE dATE = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      int i = this.columnIndex + this.byteLength * paramInt;
      byte[] arrayOfByte = new byte[7];
      
      System.arraycopy(this.rowSpaceByte, i, arrayOfByte, 0, 7);
      
      dATE = new DATE(arrayOfByte);
    } 
    
    return dATE;
  }




  
  TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
    TIMESTAMP tIMESTAMP = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
      int i = this.columnIndex + this.byteLength * paramInt;
      byte[] arrayOfByte = new byte[s];
      System.arraycopy(this.rowSpaceByte, i, arrayOfByte, 0, s);
      tIMESTAMP = new TIMESTAMP(arrayOfByte);
    } 
    
    return tIMESTAMP;
  }




  
  final int oracleYear(int paramInt) {
    int i = ((this.rowSpaceByte[0 + paramInt] & 0xFF) - 100) * 100 + (this.rowSpaceByte[1 + paramInt] & 0xFF) - 100;


    
    return (i <= 0) ? (i + 1) : i;
  }




  
  final int oracleMonth(int paramInt) {
    return this.rowSpaceByte[2 + paramInt] - 1;
  }




  
  final int oracleDay(int paramInt) {
    return this.rowSpaceByte[3 + paramInt];
  }




  
  final int oracleHour(int paramInt) {
    return this.rowSpaceByte[4 + paramInt] - 1;
  }




  
  final int oracleMin(int paramInt) {
    return this.rowSpaceByte[5 + paramInt] - 1;
  }




  
  final int oracleSec(int paramInt) {
    return this.rowSpaceByte[6 + paramInt] - 1;
  }




  
  final int oracleTZ1(int paramInt) {
    return this.rowSpaceByte[11 + paramInt];
  }




  
  final int oracleTZ2(int paramInt) {
    return this.rowSpaceByte[12 + paramInt];
  }



  
  final int oracleTime(int paramInt) {
    int i = oracleHour(paramInt);
    
    i *= 60;
    i += oracleMin(paramInt);
    i *= 60;
    i += oracleSec(paramInt);
    i *= 1000;
    
    return i;
  }



  
  final int oracleNanos(int paramInt) {
    int i = (this.rowSpaceByte[7 + paramInt] & 0xFF) << 24;
    
    i |= (this.rowSpaceByte[8 + paramInt] & 0xFF) << 16;
    i |= (this.rowSpaceByte[9 + paramInt] & 0xFF) << 8;
    i |= this.rowSpaceByte[10 + paramInt] & 0xFF & 0xFF;
    
    return i;
  }




  
  static final long computeJulianDay(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3) {
    boolean bool = (paramInt1 % 4 == 0) ? true : false;
    int i = paramInt1 - 1;
    long l = 365L * i + floorDivide(i, 4L) + 1721423L;
    
    if (paramBoolean) {
      
      bool = (bool && (paramInt1 % 100 != 0 || paramInt1 % 400 == 0)) ? true : false;

      
      l += floorDivide(i, 400L) - floorDivide(i, 100L) + 2L;
    } 




    
    return l + paramInt3 + (bool ? LEAP_NUM_DAYS[paramInt2] : NUM_DAYS[paramInt2]);
  }



  
  static final long floorDivide(long paramLong1, long paramLong2) {
    return (paramLong1 >= 0L) ? (paramLong1 / paramLong2) : ((paramLong1 + 1L) / paramLong2 - 1L);
  }




  
  static final long julianDayToMillis(long paramLong) {
    return (paramLong - 2440588L) * 86400000L;
  }






  
  static final long zoneOffset(TimeZone paramTimeZone, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    return paramTimeZone.getOffset((paramInt1 < 0) ? 0 : 1, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
  }

















  
  static long getMillis(int paramInt1, int paramInt2, int paramInt3, int paramInt4, TimeZone paramTimeZone) {
    boolean bool = (paramInt1 >= 1582) ? true : false;
    long l1 = computeJulianDay(bool, paramInt1, paramInt2, paramInt3);
    long l2 = (l1 - 2440588L) * 86400000L;


    
    if (bool != ((l2 >= -12219292800000L) ? true : false)) {
      
      l1 = computeJulianDay(!bool, paramInt1, paramInt2, paramInt3);
      l2 = (l1 - 2440588L) * 86400000L;
    } 


    
    l2 += paramInt4;



    
    return l2 - zoneOffset(paramTimeZone, paramInt1, paramInt2, paramInt3, julianDayToDayOfWeek(l1), paramInt4);
  }














  
  static final int julianDayToDayOfWeek(long paramLong) {
    int i = (int)((paramLong + 1L) % 7L);
    
    return i + ((i < 0) ? 8 : 1);
  }















  
  static long calculateEpochOffset(TimeZone paramTimeZone) {
    return zoneOffset(paramTimeZone, 1970, 0, 1, 5, 0);
  }











  
  String toText(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean, String paramString) throws SQLException {
    return TIMESTAMPTZ.toString(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramString);
  }










  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
