package oracle.jdbc.internal;

import oracle.jdbc.StructMetaData;

public interface StructMetaData extends StructMetaData {}
