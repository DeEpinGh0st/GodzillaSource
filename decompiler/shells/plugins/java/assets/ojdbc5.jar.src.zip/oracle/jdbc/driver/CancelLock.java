package oracle.jdbc.driver;


















































class CancelLock
{
  private enum State
  {
    IDLE, EXECUTING, CANCELING;
  }
  private State state = State.IDLE;

  
  synchronized void enterExecuting() {
    assert this.state == State.IDLE;
    this.state = State.EXECUTING;
  }

  
  synchronized void exitExecuting() {
    while (this.state != State.EXECUTING) {
      
      assert this.state == State.CANCELING;
      try {
        wait();
      } catch (InterruptedException interruptedException) {}
    } 
    this.state = State.IDLE;
  }

  
  synchronized boolean enterCanceling() {
    if (this.state == State.EXECUTING) {
      
      this.state = State.CANCELING;
      return true;
    } 
    
    return false;
  }

  
  synchronized void exitCanceling() {
    assert this.state == State.CANCELING;
    this.state = State.EXECUTING;
    notify();
  }
}
