package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;

























































































final class T4CTTIoscid
  extends T4CTTIfun
{
  static final int KPDUSR_CID_RESET = 1;
  static final int KPDUSR_PROXY_RESET = 2;
  static final int KPDUSR_PROXY_TKTSENT = 4;
  static final int KPDUSR_MODULE_RESET = 8;
  static final int KPDUSR_ACTION_RESET = 16;
  static final int KPDUSR_EXECID_RESET = 32;
  static final int KPDUSR_EXECSQ_RESET = 64;
  static final int KPDUSR_COLLCT_RESET = 128;
  static final int KPDUSR_CLINFO_RESET = 256;
  private byte[] cidcid;
  private byte[] cidmod;
  private byte[] cidact;
  private byte[] cideci;
  private boolean[] endToEndHasChanged;
  private String[] endToEndValues;
  private int endToEndECIDSequenceNumber;
  
  T4CTTIoscid(T4CConnection paramT4CConnection) {
    super(paramT4CConnection, (byte)17);


    
    this.cidcid = null;
    this.cidmod = null;
    this.cidact = null;
    this.cideci = null;
    
    this.endToEndHasChanged = null;
    this.endToEndValues = null;
    setFunCode((short)135);
  }


  
  void doOSCID(boolean[] paramArrayOfboolean, String[] paramArrayOfString, int paramInt) throws IOException, SQLException {
    this.endToEndHasChanged = paramArrayOfboolean;
    this.endToEndValues = paramArrayOfString;
    this.endToEndECIDSequenceNumber = paramInt;
    
    if (this.endToEndValues[1] != null) {
      this.cidcid = this.meg.conv.StringToCharBytes(this.endToEndValues[1]);
    } else {
      
      this.cidcid = null;
    } 
    if (this.endToEndValues[3] != null) {
      this.cidmod = this.meg.conv.StringToCharBytes(this.endToEndValues[3]);
    } else {
      
      this.cidmod = null;
    } 
    if (this.endToEndValues[0] != null) {
      this.cidact = this.meg.conv.StringToCharBytes(this.endToEndValues[0]);
    } else {
      
      this.cidact = null;
    } 
    if (this.endToEndValues[2] != null) {
      this.cideci = this.meg.conv.StringToCharBytes(this.endToEndValues[2]);
    } else {
      
      this.cideci = null;
    }  doPigRPC();
  }




  
  void marshal() throws IOException {
    int i = 64;
    
    if (this.endToEndHasChanged[0]) {
      i |= 0x10;
    }
    if (this.endToEndHasChanged[1]) {
      i |= 0x1;
    }
    if (this.endToEndHasChanged[2]) {
      i |= 0x20;
    }
    if (this.endToEndHasChanged[3]) {
      i |= 0x8;
    }

    
    this.meg.marshalNULLPTR();
    this.meg.marshalNULLPTR();
    this.meg.marshalUB4(i);
    
    boolean bool1 = false, bool2 = false;
    boolean bool3 = false, bool4 = false;
    
    if (this.endToEndHasChanged[1]) {
      
      this.meg.marshalPTR();
      
      if (this.cidcid != null) {
        this.meg.marshalUB4(this.cidcid.length);
      } else {
        this.meg.marshalUB4(0L);
      }  bool1 = true;
    }
    else {
      
      this.meg.marshalNULLPTR();
      this.meg.marshalUB4(0L);
    } 

    
    if (this.endToEndHasChanged[3]) {
      
      this.meg.marshalPTR();
      
      if (this.cidmod != null) {
        this.meg.marshalUB4(this.cidmod.length);
      } else {
        this.meg.marshalUB4(0L);
      }  bool2 = true;
    }
    else {
      
      this.meg.marshalNULLPTR();
      this.meg.marshalUB4(0L);
    } 
    
    if (this.endToEndHasChanged[0]) {
      
      this.meg.marshalPTR();
      if (this.cidact != null) {
        this.meg.marshalUB4(this.cidact.length);
      } else {
        this.meg.marshalUB4(0L);
      }  bool3 = true;
    }
    else {
      
      this.meg.marshalNULLPTR();
      this.meg.marshalUB4(0L);
    } 
    
    if (this.endToEndHasChanged[2]) {
      
      this.meg.marshalPTR();
      
      if (this.cideci != null) {
        this.meg.marshalUB4(this.cideci.length);
      } else {
        this.meg.marshalUB4(0L);
      }  bool4 = true;
    }
    else {
      
      this.meg.marshalNULLPTR();
      this.meg.marshalUB4(0L);
    } 
    
    this.meg.marshalUB2(0);
    this.meg.marshalUB2(this.endToEndECIDSequenceNumber);
    this.meg.marshalNULLPTR();
    this.meg.marshalUB4(0L);
    this.meg.marshalNULLPTR();
    this.meg.marshalUB4(0L);
    this.meg.marshalNULLPTR();
    this.meg.marshalUB4(0L);

    
    if (bool1 && this.cidcid != null) {
      this.meg.marshalCHR(this.cidcid);
    }
    if (bool2 && this.cidmod != null) {
      this.meg.marshalCHR(this.cidmod);
    }
    if (bool3 && this.cidact != null) {
      this.meg.marshalCHR(this.cidact);
    }
    if (bool4 && this.cideci != null) {
      this.meg.marshalCHR(this.cideci);
    }
  }
  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
