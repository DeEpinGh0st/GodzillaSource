package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.XSAttribute;
import oracle.jdbc.internal.XSNamespace;
import oracle.sql.TIMESTAMPTZ;






















































class XSNamespaceI
  extends XSNamespace
{
  String namespaceName = null;
  XSAttributeI[] attributes = null; byte[] namespaceNameBytes;
  byte[] timestampBytes = null;
  long flag = 0L;
  byte[][] aclList = (byte[][])null;

  
  public void setNamespaceName(String paramString) throws SQLException {
    this.namespaceName = paramString;
  }
  
  public void setTimestamp(TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
    this.timestampBytes = paramTIMESTAMPTZ.toBytes();
  }
  
  private void setTimestamp(byte[] paramArrayOfbyte) throws SQLException {
    this.timestampBytes = paramArrayOfbyte;
  }
  
  public void setACLIdList(byte[][] paramArrayOfbyte) throws SQLException {
    this.aclList = paramArrayOfbyte;
  }

  
  public void setFlag(long paramLong) throws SQLException {
    this.flag = paramLong;
  }
  
  public void setAttributes(XSAttribute[] paramArrayOfXSAttribute) throws SQLException {
    if (paramArrayOfXSAttribute != null) {
      
      XSAttributeI[] arrayOfXSAttributeI = new XSAttributeI[paramArrayOfXSAttribute.length];
      for (byte b = 0; b < paramArrayOfXSAttribute.length; b++) {
        arrayOfXSAttributeI[b] = (XSAttributeI)paramArrayOfXSAttribute[b];
      }
      this.attributes = arrayOfXSAttributeI;
    } 
  }

  
  void doCharConversion(DBConversion paramDBConversion) throws SQLException {
    if (this.namespaceName != null) {
      this.namespaceNameBytes = paramDBConversion.StringToCharBytes(this.namespaceName);
    } else {
      this.namespaceNameBytes = null;
    } 
    if (this.attributes != null)
    {
      for (byte b = 0; b < this.attributes.length; b++) {
        this.attributes[b].doCharConversion(paramDBConversion);
      }
    }
  }
  
  public String getNamespaceName() {
    return this.namespaceName;
  }

  
  public TIMESTAMPTZ getTimestamp() {
    return new TIMESTAMPTZ(this.timestampBytes);
  }

  
  public long getFlag() {
    return this.flag;
  }

  
  public XSAttribute[] getAttributes() {
    return (XSAttribute[])this.attributes;
  }
  
  public byte[][] getACLIdList() {
    return this.aclList;
  }

  
  void marshal(T4CMAREngine paramT4CMAREngine) throws IOException {
    if (this.namespaceNameBytes != null) {
      
      paramT4CMAREngine.marshalUB4(this.namespaceNameBytes.length);
      paramT4CMAREngine.marshalCLR(this.namespaceNameBytes, this.namespaceNameBytes.length);
    } else {
      
      paramT4CMAREngine.marshalUB4(0L);
    } 
    if (this.timestampBytes != null) {
      
      paramT4CMAREngine.marshalUB4(this.timestampBytes.length);
      paramT4CMAREngine.marshalCLR(this.timestampBytes, this.timestampBytes.length);
    } else {
      
      paramT4CMAREngine.marshalUB4(0L);
    } 
    paramT4CMAREngine.marshalUB4(this.flag);
    
    if (this.attributes != null) {
      
      paramT4CMAREngine.marshalUB4(this.attributes.length);

      
      paramT4CMAREngine.marshalUB1((short)28);
      for (byte b = 0; b < this.attributes.length; b++) {
        this.attributes[b].marshal(paramT4CMAREngine);
      }
    } else {
      paramT4CMAREngine.marshalUB4(0L);
    } 
    if (this.aclList != null) {
      
      byte[] arrayOfByte = new byte[this.aclList.length * 16];
      for (byte b = 0; b < this.aclList.length; b++)
        System.arraycopy(this.aclList[b], 0, arrayOfByte, 16 * b, 16); 
      paramT4CMAREngine.marshalUB4(arrayOfByte.length);
      paramT4CMAREngine.marshalCLR(arrayOfByte, arrayOfByte.length);
    } else {
      
      paramT4CMAREngine.marshalUB4(0L);
    } 
  }
  static XSNamespaceI unmarshal(T4CMAREngine paramT4CMAREngine) throws SQLException, IOException {
    int[] arrayOfInt = new int[1];
    String str = null;

    
    int i = (int)paramT4CMAREngine.unmarshalUB4();
    if (i > 0) {
      
      byte[] arrayOfByte2 = new byte[i];
      paramT4CMAREngine.unmarshalCLR(arrayOfByte2, 0, arrayOfInt);
      str = paramT4CMAREngine.conv.CharBytesToString(arrayOfByte2, arrayOfInt[0]);
    } 
    
    byte[] arrayOfByte = null;
    int j = (int)paramT4CMAREngine.unmarshalUB4();
    if (j > 0) {
      arrayOfByte = paramT4CMAREngine.unmarshalNBytes(j);
    }
    long l = paramT4CMAREngine.unmarshalUB4();
    
    XSAttribute[] arrayOfXSAttribute = null;
    int k = (int)paramT4CMAREngine.unmarshalUB4();
    arrayOfXSAttribute = new XSAttribute[k];
    if (k > 0)
      paramT4CMAREngine.unmarshalUB1();  int m;
    for (m = 0; m < k; m++) {
      arrayOfXSAttribute[m] = XSAttributeI.unmarshal(paramT4CMAREngine);
    }
    m = (int)paramT4CMAREngine.unmarshalUB4();
    byte[][] arrayOfByte1 = (byte[][])null;
    if (m > 0) {
      
      byte[] arrayOfByte2 = new byte[m];
      paramT4CMAREngine.unmarshalCLR(arrayOfByte2, 0, arrayOfInt);
      
      int n = m / 16;
      arrayOfByte1 = new byte[n][];
      for (byte b = 0; b < n; b++) {
        
        arrayOfByte1[b] = new byte[16];
        System.arraycopy(arrayOfByte2, b * 16, arrayOfByte1[b], 0, 16);
      } 
    } 
    
    XSNamespaceI xSNamespaceI = new XSNamespaceI();
    xSNamespaceI.setNamespaceName(str);
    xSNamespaceI.setTimestamp(arrayOfByte);
    xSNamespaceI.setFlag(l);
    xSNamespaceI.setAttributes(arrayOfXSAttribute);
    xSNamespaceI.setACLIdList(arrayOfByte1);
    return xSNamespaceI;
  }
}
