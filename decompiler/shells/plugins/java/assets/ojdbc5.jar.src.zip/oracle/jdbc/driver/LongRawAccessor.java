package oracle.jdbc.driver;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.sql.SQLException;

















class LongRawAccessor
  extends RawCommonAccessor
{
  OracleInputStream stream;
  int columnPosition = 0;




  
  LongRawAccessor(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, short paramShort, int paramInt3) throws SQLException {
    init(paramOracleStatement, 24, 24, paramShort, false);
    
    this.columnPosition = paramInt1;
    
    initForDataAccess(paramInt3, paramInt2, (String)null);
  }





  
  LongRawAccessor(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, short paramShort) throws SQLException {
    init(paramOracleStatement, 24, 24, paramShort, false);
    
    this.columnPosition = paramInt1;
    
    initForDescribe(24, paramInt2, paramBoolean, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramShort, null);

    
    int i = paramOracleStatement.maxFieldSize;
    
    if (i > 0 && (paramInt2 == 0 || i < paramInt2)) {
      paramInt2 = i;
    }
    initForDataAccess(0, paramInt2, (String)null);
  }




  
  void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
    if (paramInt1 != 0) {
      this.externalType = paramInt1;
    }
    this.isStream = true;
    this.isColumnNumberAware = true;
    this.internalTypeMaxLength = Integer.MAX_VALUE;
    
    if (paramInt2 > 0 && paramInt2 < this.internalTypeMaxLength) {
      this.internalTypeMaxLength = paramInt2;
    }
    this.byteLength = 0;

    
    this.stream = this.statement.connection.driverExtension.createInputStream(this.statement, this.columnPosition, this);
  }











  
  OracleInputStream initForNewRow() throws SQLException {
    this.stream = this.statement.connection.driverExtension.createInputStream(this.statement, this.columnPosition, this);



    
    return this.stream;
  }








  
  void updateColumnNumber(int paramInt) {
    this.columnPosition = ++paramInt;
    
    if (this.stream != null) {
      this.stream.columnIndex = paramInt;
    }
  }
















  
  byte[] getBytes(int paramInt) throws SQLException {
    byte[] arrayOfByte = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1)
    {
      if (this.stream != null) {




        
        if (this.stream.closed) {
          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 
        
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(1024);
        byte[] arrayOfByte1 = new byte[1024];
        
        try {
          int i;
          
          while ((i = this.stream.read(arrayOfByte1)) != -1)
          {
            byteArrayOutputStream.write(arrayOfByte1, 0, i);
          }
        }
        catch (IOException iOException) {

          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 

        
        arrayOfByte = byteArrayOutputStream.toByteArray();
      } 
    }


    
    return arrayOfByte;
  }















  
  InputStream getAsciiStream(int paramInt) throws SQLException {
    InputStream inputStream = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1 && this.stream != null) {
      
      if (this.stream.closed) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      PhysicalConnection physicalConnection = this.statement.connection;
      
      inputStream = physicalConnection.conversion.ConvertStream(this.stream, 2);
    } 


    
    return inputStream;
  }













  
  InputStream getUnicodeStream(int paramInt) throws SQLException {
    InputStream inputStream = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1 && this.stream != null) {
      
      if (this.stream.closed) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      PhysicalConnection physicalConnection = this.statement.connection;
      
      inputStream = physicalConnection.conversion.ConvertStream(this.stream, 3);
    } 


    
    return inputStream;
  }













  
  Reader getCharacterStream(int paramInt) throws SQLException {
    Reader reader = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1 && this.stream != null) {
      
      if (this.stream.closed) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      PhysicalConnection physicalConnection = this.statement.connection;
      
      reader = physicalConnection.conversion.ConvertCharacterStream(this.stream, 8);
    } 



    
    return reader;
  }













  
  InputStream getBinaryStream(int paramInt) throws SQLException {
    InputStream inputStream = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1 && this.stream != null) {
      
      if (this.stream.closed) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      PhysicalConnection physicalConnection = this.statement.connection;
      
      inputStream = physicalConnection.conversion.ConvertStream(this.stream, 6);
    } 


    
    return inputStream;
  }




  
  public String toString() {
    return "LongRawAccessor@" + Integer.toHexString(hashCode()) + "{columnPosition = " + this.columnPosition + "}";
  }




  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
