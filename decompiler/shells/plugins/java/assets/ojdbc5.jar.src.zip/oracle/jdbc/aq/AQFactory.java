package oracle.jdbc.aq;

import java.sql.SQLException;
import oracle.jdbc.driver.InternalFactory;












































public abstract class AQFactory
{
  public static AQMessage createAQMessage(AQMessageProperties paramAQMessageProperties) throws SQLException {
    return (AQMessage)InternalFactory.createAQMessage(paramAQMessageProperties);
  }







  
  public static AQMessageProperties createAQMessageProperties() throws SQLException {
    return (AQMessageProperties)InternalFactory.createAQMessageProperties();
  }






  
  public static AQAgent createAQAgent() throws SQLException {
    return (AQAgent)InternalFactory.createAQAgent();
  }

  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
