package oracle.jdbc.oracore;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.Datum;
import oracle.sql.REF;
import oracle.sql.StructDescriptor;
import oracle.sql.TypeDescriptor;
















public class OracleTypeREF
  extends OracleNamedType
  implements Serializable
{
  static final long serialVersionUID = 3186448715463064573L;
  
  protected OracleTypeREF() {}
  
  public OracleTypeREF(String paramString, OracleConnection paramOracleConnection) throws SQLException {
    super(paramString, paramOracleConnection);
  }



  
  public OracleTypeREF(OracleTypeADT paramOracleTypeADT, int paramInt, OracleConnection paramOracleConnection) {
    super(paramOracleTypeADT, paramInt, paramOracleConnection);
  }











  
  public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection) throws SQLException {
    REF rEF = null;
    
    if (paramObject != null)
    {
      if (paramObject instanceof REF) {
        rEF = (REF)paramObject;
      } else {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    }
    
    return (Datum)rEF;
  }










  
  public int getTypeCode() {
    return 2006;
  }

















  
  protected Object toObject(byte[] paramArrayOfbyte, int paramInt, Map paramMap) throws SQLException {
    if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
      return null;
    }
    if (paramInt == 1 || paramInt == 2) {
      
      StructDescriptor structDescriptor = createStructDescriptor();
      
      return new REF(structDescriptor, (Connection)this.connection, paramArrayOfbyte);
    } 
    if (paramInt == 3)
    {
      return paramArrayOfbyte;
    }

    
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramArrayOfbyte);
    sQLException.fillInStackTrace();
    throw sQLException;
  }





  
  StructDescriptor createStructDescriptor() throws SQLException {
    if (this.descriptor == null)
    {
      if (this.sqlName == null && getFullName(false) == null) {
        
        OracleTypeADT oracleTypeADT = new OracleTypeADT(getParent(), getOrder(), (Connection)this.connection);
        
        this.descriptor = (TypeDescriptor)new StructDescriptor(oracleTypeADT, (Connection)this.connection);
      }
      else {
        
        this.descriptor = (TypeDescriptor)StructDescriptor.createDescriptor(this.sqlName, (Connection)this.connection);
      } 
    }
    return (StructDescriptor)this.descriptor;
  }

















  
  private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {}

















  
  private void readObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {}
















  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
