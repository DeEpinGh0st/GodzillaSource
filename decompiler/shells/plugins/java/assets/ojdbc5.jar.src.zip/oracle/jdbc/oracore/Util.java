package oracle.jdbc.oracore;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.sql.SQLException;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;




















public class Util
{
  static void checkNextByte(InputStream paramInputStream, byte paramByte) throws SQLException {
    try {
      if (paramInputStream.read() != paramByte)
      {
        SQLException sQLException = DatabaseError.createSqlException(null, 47, "parseTDS");
        sQLException.fillInStackTrace();
        throw sQLException;
      }
    
    } catch (IOException iOException) {

      
      SQLException sQLException = DatabaseError.createSqlException(null, iOException);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }












  
  public static int[] toJavaUnsignedBytes(byte[] paramArrayOfbyte) {
    int[] arrayOfInt = new int[paramArrayOfbyte.length];
    
    for (byte b = 0; b < paramArrayOfbyte.length; b++) {
      arrayOfInt[b] = paramArrayOfbyte[b] & 0xFF;
    }
    return arrayOfInt;
  }



  
  static byte[] readBytes(InputStream paramInputStream, int paramInt) throws SQLException {
    byte[] arrayOfByte = new byte[paramInt];

    
    try {
      int i = paramInputStream.read(arrayOfByte);
      
      if (i != paramInt)
      {
        byte[] arrayOfByte1 = new byte[i];
        
        System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, i);
        
        return arrayOfByte1;
      }
    
    } catch (IOException iOException) {

      
      SQLException sQLException = DatabaseError.createSqlException(null, iOException);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    return arrayOfByte;
  }




  
  static void writeBytes(OutputStream paramOutputStream, byte[] paramArrayOfbyte) throws SQLException {
    try {
      paramOutputStream.write(paramArrayOfbyte);
    }
    catch (IOException iOException) {

      
      SQLException sQLException = DatabaseError.createSqlException(null, iOException);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }





  
  static void skipBytes(InputStream paramInputStream, int paramInt) throws SQLException {
    try {
      paramInputStream.skip(paramInt);
    }
    catch (IOException iOException) {

      
      SQLException sQLException = DatabaseError.createSqlException(null, iOException);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }




  
  static long readLong(InputStream paramInputStream) throws SQLException {
    byte[] arrayOfByte = new byte[4];

    
    try {
      paramInputStream.read(arrayOfByte);
      
      return ((((arrayOfByte[0] & 0xFF) * 256 + (arrayOfByte[1] & 0xFF)) * 256 + (arrayOfByte[2] & 0xFF)) * 256 + (arrayOfByte[3] & 0xFF));
    
    }
    catch (IOException iOException) {

      
      SQLException sQLException = DatabaseError.createSqlException(null, iOException);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }





  
  static short readShort(InputStream paramInputStream) throws SQLException {
    byte[] arrayOfByte = new byte[2];

    
    try {
      paramInputStream.read(arrayOfByte);
      
      return (short)((arrayOfByte[0] & 0xFF) * 256 + (arrayOfByte[1] & 0xFF));
    }
    catch (IOException iOException) {

      
      SQLException sQLException = DatabaseError.createSqlException(null, iOException);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }






  
  static byte readByte(InputStream paramInputStream) throws SQLException {
    try {
      return (byte)paramInputStream.read();
    }
    catch (IOException iOException) {

      
      SQLException sQLException = DatabaseError.createSqlException(null, iOException);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }








  
  static byte fdoGetSize(byte[] paramArrayOfbyte, int paramInt) {
    byte b = fdoGetEntry(paramArrayOfbyte, paramInt);

    
    return (byte)(b >> 3 & 0x1F);
  }






  
  static byte fdoGetAlign(byte[] paramArrayOfbyte, int paramInt) {
    byte b = fdoGetEntry(paramArrayOfbyte, paramInt);

    
    return (byte)(b & 0x7);
  }








  
  static int ldsRound(int paramInt1, int paramInt2) {
    int i = ldsRoundTable[paramInt2];
    
    return (paramInt1 >> i) + 1 << i;
  }






  
  private static byte fdoGetEntry(byte[] paramArrayOfbyte, int paramInt) {
    short s = getUnsignedByte(paramArrayOfbyte[5]);
    return paramArrayOfbyte[6 + s + paramInt];
  }



  
  private static int[] ldsRoundTable = new int[] { 0, 1, 0, 2, 0, 0, 0, 3, 0 };





  
  public static short getUnsignedByte(byte paramByte) {
    return (short)(paramByte & 0xFF);
  }



  
  public static byte[] serializeObject(Object paramObject) throws IOException {
    if (paramObject == null) {
      return null;
    }
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
    
    objectOutputStream.writeObject(paramObject);
    objectOutputStream.flush();
    
    return byteArrayOutputStream.toByteArray();
  }




  
  public static Object deserializeObject(byte[] paramArrayOfbyte) throws IOException, ClassNotFoundException {
    if (paramArrayOfbyte == null) {
      return null;
    }
    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(paramArrayOfbyte);
    
    return (new ObjectInputStream(byteArrayInputStream)).readObject();
  }




  
  public static void printByteArray(byte[] paramArrayOfbyte) {
    System.out.println("DONT CALL THIS -- oracle.jdbc.oracore.Util.printByteArray");
  }










  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }
























  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
