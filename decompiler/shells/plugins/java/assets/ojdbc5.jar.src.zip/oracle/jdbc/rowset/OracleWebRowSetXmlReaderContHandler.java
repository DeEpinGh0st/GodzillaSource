package oracle.jdbc.rowset;

import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;
import javax.sql.RowSet;
import javax.sql.RowSetMetaData;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;






































class OracleWebRowSetXmlReaderContHandler
  extends DefaultHandler
{
  private OracleWebRowSet wrset;
  private RowSetMetaData rsetMetaData;
  private Vector updatesToRowSet;
  private Vector keyCols;
  private String columnValue;
  private String propertyValue;
  private String metadataValue;
  private boolean isNullValue;
  private int columnIndex;
  private Hashtable propertyNameTagMap;
  private Hashtable metadataNameTagMap;
  private Hashtable dataNameTagMap;
  protected static final String WEBROWSET_ELEMENT_NAME = "webRowSet";
  protected static final String PROPERTIES_ELEMENT_NAME = "properties";
  protected static final String METADATA_ELEMENT_NAME = "metadata";
  protected static final String DATA_ELEMENT_NAME = "data";
  private int state;
  private static final int INITIAL_STATE = 0;
  private static final int PROPERTIES_STATE = 1;
  private static final int METADATA_STATE = 2;
  private static final int DATA_STATE = 3;
  private int tag;
  private static final int NO_TAG = -1;
  private String[] propertyNames = new String[] { "command", "concurrency", "datasource", "escape-processing", "fetch-direction", "fetch-size", "isolation-level", "key-columns", "map", "max-field-size", "max-rows", "query-timeout", "read-only", "rowset-type", "show-deleted", "table-name", "url", "sync-provider", "null", "column", "type", "class", "sync-provider-name", "sync-provider-vendor", "sync-provider-version", "sync-provider-grade", "data-source-lock" };

  
  private boolean readReadOnlyValue;

  
  private static final int PROPERTY_COMMAND_TAG = 0;

  
  private static final int PROPERTY_CONCURRENCY_TAG = 1;

  
  private static final int PROPERTY_DATASOURCETAG = 2;

  
  private static final int PROPERTY_ESCAPEPROCESSING_TAG = 3;

  
  private static final int PROPERTY_FETCHDIRECTION_TAG = 4;

  
  private static final int PROPERTY_FETCHSIZE_TAG = 5;
  
  private static final int PROPERTY_ISOLATIONLEVEL_TAG = 6;
  
  private static final int PROPERTY_KEYCOLUMNS_TAG = 7;
  
  private static final int PROPERTY_MAP_TAG = 8;
  
  private static final int PROPERTY_MAXFIELDSIZE_TAG = 9;
  
  private static final int PROPERTY_MAXROWS_TAG = 10;
  
  private static final int PROPERTY_QUERYTIMEOUT_TAG = 11;
  
  private static final int PROPERTY_READONLY_TAG = 12;
  
  private static final int PROPERTY_ROWSETTYPE_TAG = 13;
  
  private static final int PROPERTY_SHOWDELETED_TAG = 14;
  
  private static final int PROPERTY_TABLENAME_TAG = 15;
  
  private static final int PROPERTY_URL_TAG = 16;
  
  private static final int PROPERTY_SYNCPROVIDER_TAG = 17;
  
  private static final int PROPERTY_NULL_TAG = 18;
  
  private static final int PROPERTY_COLUMN_TAG = 19;
  
  private static final int PROPERTY_TYPE_TAG = 20;
  
  private static final int PROPERTY_CLASS_TAG = 21;
  
  private static final int PROPERTY_SYNCPROVIDERNAME_TAG = 22;
  
  private static final int PROPERTY_SYNCPROVIDERVENDOR_TAG = 23;
  
  private static final int PROPERTY_SYNCPROVIDERVERSION_TAG = 24;
  
  private static final int PROPERTY_SYNCPROVIDERGRADE_TAG = 25;
  
  private static final int PROPERTY_DATASOURCELOCK_TAG = 26;
  
  private String[] metadataNames = new String[] { "column-count", "column-definition", "column-index", "auto-increment", "case-sensitive", "currency", "nullable", "signed", "searchable", "column-display-size", "column-label", "column-name", "schema-name", "column-precision", "column-scale", "table-name", "catalog-name", "column-type", "column-type-name", "null" };

  
  private static final int METADATA_COLUMNCOUNT_TAG = 0;

  
  private static final int METADATA_COLUMNDEFINITION_TAG = 1;

  
  private static final int METADATA_COLUMNINDEX_TAG = 2;

  
  private static final int METADATA_AUTOINCREMENT_TAG = 3;

  
  private static final int METADATA_CASESENSITIVE_TAG = 4;

  
  private static final int METADATA_CURRENCY_TAG = 5;
  
  private static final int METADATA_NULLABLE_TAG = 6;
  
  private static final int METADATA_SIGNED_TAG = 7;
  
  private static final int METADATA_SEARCHABLE_TAG = 8;
  
  private static final int METADATA_COLUMNDISPLAYSIZE_TAG = 9;
  
  private static final int METADATA_COLUMNLABEL_TAG = 10;
  
  private static final int METADATA_COLUMNNAME_TAG = 11;
  
  private static final int METADATA_SCHEMANAME_TAG = 12;
  
  private static final int METADATA_COLUMNPRECISION_TAG = 13;
  
  private static final int METADATA_COLUMNSCALE_TAG = 14;
  
  private static final int METADATA_TABLENAME_TAG = 15;
  
  private static final int METADATA_CATALOGNAME_TAG = 16;
  
  private static final int METADATA_COLUMNTYPE_TAG = 17;
  
  private static final int METADATA_COLUMNTYPENAME_TAG = 18;
  
  private static final int METADATA_NULL_TAG = 19;
  
  private String[] dataNames = new String[] { "currentRow", "insertRow", "deleteRow", "modifyRow", "columnValue", "updateValue", "null" };


  
  private static final int DATA_CURRENTROW_TAG = 0;

  
  private static final int DATA_INSERTROW_TAG = 1;

  
  private static final int DATA_DELETEROW_TAG = 2;

  
  private static final int DATA_MODIFYROW_TAG = 3;

  
  private static final int DATA_COLUMNVALUE_TAG = 4;

  
  private static final int DATA_UPDATEVALUE_TAG = 5;

  
  private static final int DATA_NULL_TAG = 6;


  
  OracleWebRowSetXmlReaderContHandler(RowSet paramRowSet) {
    this.wrset = (OracleWebRowSet)paramRowSet;
    
    initialize();
  }

















  
  public void characters(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws SAXException {
    String str = new String(paramArrayOfchar, paramInt1, paramInt2);
    processElement(str);
  }








  
  public void endDocument() throws SAXException {
    try {
      if (this.readReadOnlyValue)
      {
        this.wrset.setReadOnly(this.readReadOnlyValue);
      }
    }
    catch (SQLException sQLException) {

      
      throw new SAXException(sQLException.getMessage());
    } 
  }

















  
  public void endElement(String paramString1, String paramString2, String paramString3) throws SAXException {
    int i;
    String str = (paramString2 == null || paramString2.equals("")) ? paramString3 : paramString2;
    
    switch (getState()) {
      
      case 1:
        if (str.equals("properties")) {
          
          this.state = 0;
          
          break;
        } 
        
        try {
          int j = ((Integer)this.propertyNameTagMap.get(str)).intValue();
          
          switch (j) {
            
            case 7:
              if (this.keyCols != null) {
                
                int[] arrayOfInt = new int[this.keyCols.size()];
                
                for (byte b = 0; b < arrayOfInt.length; b++) {
                  arrayOfInt[b] = Integer.parseInt((String)this.keyCols.elementAt(b));
                }
                this.wrset.setKeyColumns(arrayOfInt);
              } 
              break;
          } 








          
          setPropertyValue(this.propertyValue);
        
        }
        catch (SQLException sQLException) {
          
          throw new SAXException(sQLException.getMessage());
        } 

        
        this.propertyValue = "";

        
        setNullValue(false);

        
        setTag(-1);
        break;


      
      case 2:
        if (str.equals("metadata")) {

          
          try {
            this.wrset.setMetaData(this.rsetMetaData);



            
            this.state = 0;
          }
          catch (SQLException sQLException) {


            
            throw new SAXException("Error setting metadata in WebRowSet: " + sQLException.getMessage());
          } 





          
          break;
        } 





        
        try {
          setMetaDataValue(this.metadataValue);
        
        }
        catch (SQLException sQLException) {




          
          throw new SAXException("Error setting metadata value: " + sQLException.getMessage());
        } 



        
        this.metadataValue = "";

        
        setNullValue(false);

        
        setTag(-1);
        break;


      
      case 3:
        if (str.equals("data")) {
          
          this.state = 0;
          
          return;
        } 
        
        i = ((Integer)this.dataNameTagMap.get(str)).intValue();
        
        switch (i) {
          default:
            break;


          
          case 4:
            try {
              this.columnIndex++;









              
              insertValue(this.columnValue);


              
              this.columnValue = "";

              
              setNullValue(false);

              
              setTag(-1);
            }
            catch (SQLException sQLException) {
              
              throw new SAXException("Error inserting column values: " + sQLException.getMessage());
            } 
            break;




          
          case 0:
            try {
              this.wrset.insertRow();
              this.wrset.moveToCurrentRow();
              this.wrset.next();
              
              OracleRow oracleRow = this.wrset.getCurrentRow();
              oracleRow.setInsertedFlag(false);
              applyUpdates();
            }
            catch (SQLException sQLException) {
              
              throw new SAXException("Error constructing current row: " + sQLException.getMessage());
            } 
            break;




          
          case 2:
            try {
              this.wrset.insertRow();
              this.wrset.moveToCurrentRow();
              this.wrset.next();
              
              OracleRow oracleRow = this.wrset.getCurrentRow();
              oracleRow.setInsertedFlag(false);
              oracleRow.setRowDeleted(true);
              applyUpdates();
            }
            catch (SQLException sQLException) {
              
              throw new SAXException("Error constructing deleted row: " + sQLException.getMessage());
            } 
            break;




          
          case 1:
            try {
              this.wrset.insertRow();
              this.wrset.moveToCurrentRow();
              this.wrset.next();
              
              applyUpdates();
            }
            catch (SQLException sQLException) {
              
              throw new SAXException("Error constructing inserted row: " + sQLException.getMessage());
            } 
            break;

          
          case 3:
            break;
        } 
        
        try {
          this.wrset.insertRow();
          this.wrset.moveToCurrentRow();
          this.wrset.next();
          
          OracleRow oracleRow = this.wrset.getCurrentRow();
          oracleRow.setRowDeleted(true);
          applyUpdates();
        }
        catch (SQLException sQLException) {
          
          throw new SAXException("Error constructing modified row: " + sQLException.getMessage());
        } 
        break;
    } 
  }











  
  public void startElement(String paramString1, String paramString2, String paramString3, Attributes paramAttributes) throws SAXException {
    int i, j, k;
    String str = (paramString2 == null || paramString2.equals("")) ? paramString3 : paramString2;

    
    switch (getState()) {
      
      case 1:
        i = ((Integer)this.propertyNameTagMap.get(str)).intValue();



        
        if (i == 18) {

          
          setNullValue(true);
          this.propertyValue = null;
        
        }
        else {
          
          setTag(i);
        } 
        return;

      
      case 2:
        j = ((Integer)this.metadataNameTagMap.get(str)).intValue();



        
        if (j == 19) {

          
          setNullValue(true);
          this.metadataValue = null;
        
        }
        else {
          
          setTag(j);
        } 
        return;

      
      case 3:
        k = ((Integer)this.dataNameTagMap.get(str)).intValue();

        
        if (k == 6) {
          
          setNullValue(true);
          this.columnValue = null;
        }
        else {
          
          setTag(k);
          
          if (k == 0 || k == 1 || k == 2 || k == 3) {






            
            this.columnIndex = 0;

            
            try {
              this.wrset.moveToInsertRow();
            }
            catch (SQLException sQLException) {}
          } 
        } 
        return;
    } 
    setState(str);
  }






  
  public void error(SAXParseException paramSAXParseException) throws SAXParseException {
    throw paramSAXParseException;
  }



  
  public void warning(SAXParseException paramSAXParseException) throws SAXParseException {
    System.out.println("** Warning, line " + paramSAXParseException.getLineNumber() + ", uri " + paramSAXParseException.getSystemId());
    
    System.out.println("   " + paramSAXParseException.getMessage());
  }








  
  private void initialize() {
    this.propertyNameTagMap = new Hashtable<Object, Object>(30);
    int i = this.propertyNames.length; byte b;
    for (b = 0; b < i; b++) {
      this.propertyNameTagMap.put(this.propertyNames[b], Integer.valueOf(b));
    }
    this.metadataNameTagMap = new Hashtable<Object, Object>(30);
    i = this.metadataNames.length;
    for (b = 0; b < i; b++) {
      this.metadataNameTagMap.put(this.metadataNames[b], Integer.valueOf(b));
    }
    this.dataNameTagMap = new Hashtable<Object, Object>(10);
    i = this.dataNames.length;
    for (b = 0; b < i; b++) {
      this.dataNameTagMap.put(this.dataNames[b], Integer.valueOf(b));
    }
    this.updatesToRowSet = new Vector();
    this.columnValue = "";
    this.propertyValue = "";
    this.metadataValue = "";
    this.isNullValue = false;
    this.columnIndex = 0;
    
    this.readReadOnlyValue = false;
  }




  
  protected void processElement(String paramString) throws SAXException {
    try {
      switch (getState()) {
        
        case 1:
          this.propertyValue = paramString;
          break;
        
        case 2:
          this.metadataValue = paramString;
          break;
        
        case 3:
          setDataValue(paramString);
          break;
      } 

    
    } catch (SQLException sQLException) {
      
      throw new SAXException("processElement: " + sQLException.getMessage());
    } 
  }

  
  private BigDecimal getBigDecimalValue(String paramString) {
    return new BigDecimal(paramString);
  }

  
  private byte[] getBinaryValue(String paramString) {
    return paramString.getBytes();
  }

  
  private boolean getBooleanValue(String paramString) {
    return Boolean.valueOf(paramString).booleanValue();
  }

  
  private byte getByteValue(String paramString) {
    return Byte.parseByte(paramString);
  }

  
  private Date getDateValue(String paramString) {
    return new Date(getLongValue(paramString));
  }

  
  private double getDoubleValue(String paramString) {
    return Double.parseDouble(paramString);
  }

  
  private float getFloatValue(String paramString) {
    return Float.parseFloat(paramString);
  }

  
  private int getIntegerValue(String paramString) {
    return Integer.parseInt(paramString);
  }

  
  private long getLongValue(String paramString) {
    return Long.parseLong(paramString);
  }

  
  private boolean getNullValue() {
    return this.isNullValue;
  }

  
  private short getShortValue(String paramString) {
    return Short.parseShort(paramString);
  }

  
  private String getStringValue(String paramString) {
    return paramString;
  }

  
  private Time getTimeValue(String paramString) {
    return new Time(getLongValue(paramString));
  }

  
  private Timestamp getTimestampValue(String paramString) {
    return new Timestamp(getLongValue(paramString));
  }


  
  private Blob getBlobValue(String paramString) throws SQLException {
    return new OracleSerialBlob(paramString.getBytes());
  }


  
  private Clob getClobValue(String paramString) throws SQLException {
    return new OracleSerialClob(paramString.toCharArray());
  }


  
  private void applyUpdates() throws SAXException {
    if (this.updatesToRowSet.size() > 0) {

      
      try {
        
        Iterator<Object[]> iterator = this.updatesToRowSet.iterator();
        while (iterator.hasNext()) {
          
          Object[] arrayOfObject = iterator.next();
          this.columnIndex = ((Integer)arrayOfObject[0]).intValue();
          insertValue((String)arrayOfObject[1]);
        } 
        
        this.wrset.updateRow();
      }
      catch (SQLException sQLException) {
        
        throw new SAXException("Error updating row: " + sQLException.getMessage());
      } 

      
      this.updatesToRowSet.removeAllElements();
    } 
  }


  
  private void insertValue(String paramString) throws SQLException {
    if (getNullValue() || paramString == null) {
      
      this.wrset.updateNull(this.columnIndex);
      
      return;
    } 
    int i = this.wrset.getMetaData().getColumnType(this.columnIndex);
    
    switch (i) {
      
      case -7:
        this.wrset.updateByte(this.columnIndex, getByteValue(paramString));
        return;
      
      case 5:
        this.wrset.updateShort(this.columnIndex, getShortValue(paramString));
        return;
      
      case 4:
        this.wrset.updateInt(this.columnIndex, getIntegerValue(paramString));
        return;
      
      case -5:
        this.wrset.updateLong(this.columnIndex, getLongValue(paramString));
        return;
      
      case 6:
      case 7:
        this.wrset.updateFloat(this.columnIndex, getFloatValue(paramString));
        return;
      
      case 8:
        this.wrset.updateDouble(this.columnIndex, getDoubleValue(paramString));
        return;
      
      case 2:
      case 3:
        this.wrset.updateObject(this.columnIndex, getBigDecimalValue(paramString));
        return;
      
      case -4:
      case -3:
      case -2:
        this.wrset.updateBytes(this.columnIndex, getBinaryValue(paramString));
        return;
      
      case 91:
        this.wrset.updateDate(this.columnIndex, getDateValue(paramString));
        return;
      
      case 92:
        this.wrset.updateTime(this.columnIndex, getTimeValue(paramString));
        return;
      
      case 93:
        this.wrset.updateTimestamp(this.columnIndex, getTimestampValue(paramString));
        return;






      
      case -1:
      case 1:
      case 12:
        this.wrset.updateString(this.columnIndex, getStringValue(paramString));
        return;
      
      case 2004:
        this.wrset.updateBlob(this.columnIndex, getBlobValue(paramString));
        return;
      
      case 2005:
        this.wrset.updateClob(this.columnIndex, getClobValue(paramString));
        return;
    } 




    
    throw new SQLException("The type " + i + " is not supported currently.");
  }


  
  private void setPropertyValue(String paramString) throws SQLException {
    int i;
    boolean bool = getNullValue();
    
    switch (getTag()) {
      default:
        return;





      
      case 0:
        if (bool) {

          
          this.wrset.setCommand((String)null);
        
        }
        else {
          
          this.wrset.setCommand(paramString);
        } 


      
      case 1:
        if (bool) {


          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 357);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 


        
        this.wrset.setConcurrency(getIntegerValue(paramString));

      
      case 2:
        if (bool) {

          
          this.wrset.setDataSourceName(null);
        
        }
        else {
          
          this.wrset.setDataSourceName(paramString);
        } 


      
      case 3:
        if (bool) {


          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 357);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 


        
        this.wrset.setEscapeProcessing(getBooleanValue(paramString));

      
      case 4:
        if (bool) {


          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 357);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 


        
        i = this.wrset.getType();
        if (i != 1005)
        {
          this.wrset.setFetchDirection(getIntegerValue(paramString));
        }


      
      case 5:
        if (bool) {


          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 357);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 


        
        this.wrset.setFetchSize(getIntegerValue(paramString));

      
      case 6:
        if (bool) {


          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 357);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 


        
        this.wrset.setTransactionIsolation(getIntegerValue(paramString));

      
      case 19:
        if (this.keyCols == null)
        {
          this.keyCols = new Vector();
        }
        
        this.keyCols.add(paramString);

      
      case 9:
        if (bool) {


          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 357);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 


        
        this.wrset.setMaxFieldSize(getIntegerValue(paramString));

      
      case 10:
        if (bool) {


          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 357);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 


        
        this.wrset.setMaxRows(getIntegerValue(paramString));

      
      case 11:
        if (bool) {


          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 357);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 


        
        this.wrset.setQueryTimeout(getIntegerValue(paramString));

      
      case 12:
        if (bool) {


          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 357);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 



        
        this.readReadOnlyValue = getBooleanValue(paramString);


      
      case 13:
        if (bool) {


          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 357);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 


        
        this.wrset.setType(getIntegerValue(paramString));


      
      case 14:
        if (bool) {


          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 357);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 


        
        this.wrset.setShowDeleted(getBooleanValue(paramString));

      
      case 15:
        if (bool) {

          
          this.wrset.setTableName((String)null);
        
        }
        else {
          
          this.wrset.setTableName(paramString);
        } 


      
      case 16:
        if (bool) {

          
          this.wrset.setUrl(null);
        
        }
        else {
          
          this.wrset.setUrl(paramString);
        } 
      
      case 22:
        break;
    } 
    if (bool)
    {
      
      this.wrset.setSyncProvider((String)null);
    }


    
    this.wrset.setSyncProvider(paramString);
  }






  
  private void setMetaDataValue(String paramString) throws SQLException {
    int i;
    boolean bool = getNullValue();
    
    switch (getTag()) {
      default:
        return;


      
      case 0:
        if (bool) {


          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 358);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 


        
        i = getIntegerValue(paramString);

        
        this.rsetMetaData = new OracleRowSetMetaData(i);

        
        this.columnIndex = 0;


      
      case 2:
        this.columnIndex++;

      
      case 3:
        if (bool) {


          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 358);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 


        
        this.rsetMetaData.setAutoIncrement(this.columnIndex, getBooleanValue(paramString));

      
      case 4:
        if (bool) {


          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 358);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 


        
        this.rsetMetaData.setCaseSensitive(this.columnIndex, getBooleanValue(paramString));

      
      case 5:
        if (bool) {


          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 358);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 


        
        this.rsetMetaData.setCurrency(this.columnIndex, getBooleanValue(paramString));

      
      case 6:
        if (bool) {


          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 358);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 


        
        this.rsetMetaData.setNullable(this.columnIndex, getIntegerValue(paramString));

      
      case 7:
        if (bool) {


          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 358);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 


        
        this.rsetMetaData.setSigned(this.columnIndex, getBooleanValue(paramString));

      
      case 8:
        if (bool) {


          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 358);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 


        
        this.rsetMetaData.setSearchable(this.columnIndex, getBooleanValue(paramString));

      
      case 9:
        if (bool) {


          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 358);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 


        
        this.rsetMetaData.setColumnDisplaySize(this.columnIndex, getIntegerValue(paramString));

      
      case 10:
        if (bool) {

          
          this.rsetMetaData.setColumnLabel(this.columnIndex, null);
        
        }
        else {
          
          this.rsetMetaData.setColumnLabel(this.columnIndex, paramString);
        } 


      
      case 11:
        if (bool) {

          
          this.rsetMetaData.setColumnName(this.columnIndex, null);
        
        }
        else {
          
          this.rsetMetaData.setColumnName(this.columnIndex, paramString);
        } 


      
      case 12:
        if (bool) {

          
          this.rsetMetaData.setSchemaName(this.columnIndex, null);
        
        }
        else {
          
          this.rsetMetaData.setSchemaName(this.columnIndex, paramString);
        } 


      
      case 13:
        if (bool) {


          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 358);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 


        
        this.rsetMetaData.setPrecision(this.columnIndex, getIntegerValue(paramString));

      
      case 14:
        if (bool) {


          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 358);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 


        
        this.rsetMetaData.setScale(this.columnIndex, getIntegerValue(paramString));

      
      case 15:
        if (bool) {

          
          this.rsetMetaData.setTableName(this.columnIndex, null);
        
        }
        else {
          
          this.rsetMetaData.setTableName(this.columnIndex, paramString);
        } 


      
      case 16:
        if (bool) {

          
          this.rsetMetaData.setCatalogName(this.columnIndex, null);
        
        }
        else {
          
          this.rsetMetaData.setCatalogName(this.columnIndex, paramString);
        } 


      
      case 17:
        if (bool) {


          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 358);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 


        
        this.rsetMetaData.setColumnType(this.columnIndex, getIntegerValue(paramString));
      case 18:
        break;
    } 
    if (bool)
    {
      
      this.rsetMetaData.setColumnTypeName(this.columnIndex, null);
    }


    
    this.rsetMetaData.setColumnTypeName(this.columnIndex, paramString);
  }







  
  private void setDataValue(String paramString) throws SQLException {
    switch (getTag()) {
      default:
        return;




      
      case 4:
        this.columnValue = paramString;
      case 5:
        break;
    } 
    Object[] arrayOfObject = new Object[2];
    arrayOfObject[1] = paramString;
    arrayOfObject[0] = Integer.valueOf(this.columnIndex);
    this.updatesToRowSet.add(arrayOfObject);
  }




  
  protected void setNullValue(boolean paramBoolean) {
    this.isNullValue = paramBoolean;
  }

  
  private int getState() {
    return this.state;
  }

  
  private int getTag() {
    return this.tag;
  }


  
  private void setState(String paramString) throws SAXException {
    if (paramString.equals("webRowSet")) {
      this.state = 0;
    }
    else if (paramString.equals("properties")) {
      
      if (this.state != 1) {
        this.state = 1;
      } else {
        this.state = 0;
      }
    
    } else if (paramString.equals("metadata")) {
      
      if (this.state != 2) {
        this.state = 2;
      } else {
        this.state = 0;
      }
    
    } else if (paramString.equals("data")) {
      if (this.state != 3) {
        this.state = 3;
      } else {
        this.state = 0;
      } 
    } 
  }
  private void setTag(int paramInt) {
    this.tag = paramInt;
  }










  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
