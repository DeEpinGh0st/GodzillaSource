package oracle.jdbc.internal;

import java.util.EventListener;

public interface XSEventListener extends EventListener {
  void onXSEvent(XSEvent paramXSEvent);
}
