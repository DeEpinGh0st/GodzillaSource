package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.jdbc.OracleParameterMetaData;
import oracle.jdbc.internal.OracleConnection;
















class OracleParameterMetaData
  implements OracleParameterMetaData
{
  int parameterCount = 0;

  
  int parameterNoNulls;

  
  int parameterNullable;
  
  int parameterNullableUnknown;
  
  int parameterModeUnknown;
  
  int parameterModeIn;
  
  int parameterModeInOut;
  
  int parameterModeOut;

  
  public int getParameterCount() throws SQLException {
    return this.parameterCount;
  }















  
  public int isNullable(int paramInt) throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  } public boolean isSigned(int paramInt) throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  } public int getPrecision(int paramInt) throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  } OracleParameterMetaData(int paramInt) throws SQLException {
    this.parameterNoNulls = 0;






    
    this.parameterNullable = 1;






    
    this.parameterNullableUnknown = 2;































































































































    
    this.parameterModeUnknown = 0;





    
    this.parameterModeIn = 1;





    
    this.parameterModeInOut = 2;





    
    this.parameterModeOut = 4;
    this.parameterCount = paramInt;
  }




  
  public int getScale(int paramInt) throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public int getParameterMode(int paramInt) throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }
  public int getParameterType(int paramInt) throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }
  public String getParameterTypeName(int paramInt) throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }
  public String getParameterClassName(int paramInt) throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }
  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
