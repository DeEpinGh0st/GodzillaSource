package oracle.jdbc.aq;

import java.sql.SQLException;



































public class AQEnqueueOptions
{
  private byte[] attrRelativeMessageId;
  private SequenceDeviationOption attrSequenceDeviation;
  private VisibilityOption attrVisibility;
  private DeliveryMode attrDeliveryMode;
  private boolean retrieveMsgId;
  private String transformation;
  
  public enum VisibilityOption
  {
    ON_COMMIT(2),



    
    IMMEDIATE(1);
    private final int mode;
    
    VisibilityOption(int param1Int1) {
      this.mode = param1Int1;
    }



    
    public final int getCode() {
      return this.mode;
    }
  }



  
  public enum SequenceDeviationOption
  {
    BOTTOM(0),



    
    BEFORE(2),


    
    TOP(3);
    private final int mode;
    
    SequenceDeviationOption(int param1Int1) {
      this.mode = param1Int1;
    }



    
    public final int getCode() {
      return this.mode;
    }
  }




  
  public enum DeliveryMode
  {
    PERSISTENT(AQDequeueOptions.DeliveryFilter.PERSISTENT.getCode()),



    
    BUFFERED(AQDequeueOptions.DeliveryFilter.BUFFERED.getCode());
    private final int mode;
    
    DeliveryMode(int param1Int1) {
      this.mode = param1Int1;
    }



    
    public final int getCode() {
      return this.mode;
    }
  }


















  
  public AQEnqueueOptions() {
    this.attrRelativeMessageId = null;
    this.attrSequenceDeviation = SequenceDeviationOption.BOTTOM;
    this.attrVisibility = VisibilityOption.ON_COMMIT;
    this.attrDeliveryMode = DeliveryMode.PERSISTENT;


    
    this.retrieveMsgId = false;
  }














  
  public void setRelativeMessageId(byte[] paramArrayOfbyte) throws SQLException {
    this.attrRelativeMessageId = paramArrayOfbyte;
  }








  
  public byte[] getRelativeMessageId() {
    return this.attrRelativeMessageId;
  }
















  
  public void setSequenceDeviation(SequenceDeviationOption paramSequenceDeviationOption) throws SQLException {
    this.attrSequenceDeviation = paramSequenceDeviationOption;
  }








  
  public SequenceDeviationOption getSequenceDeviation() {
    return this.attrSequenceDeviation;
  }












  
  public void setVisibility(VisibilityOption paramVisibilityOption) throws SQLException {
    this.attrVisibility = paramVisibilityOption;
  }








  
  public VisibilityOption getVisibility() {
    return this.attrVisibility;
  }














  
  public void setDeliveryMode(DeliveryMode paramDeliveryMode) throws SQLException {
    this.attrDeliveryMode = paramDeliveryMode;
  }








  
  public DeliveryMode getDeliveryMode() {
    return this.attrDeliveryMode;
  }











  
  public void setRetrieveMessageId(boolean paramBoolean) {
    this.retrieveMsgId = paramBoolean;
  }








  
  public boolean getRetrieveMessageId() {
    return this.retrieveMsgId;
  }

















  
  public void setTransformation(String paramString) {
    this.transformation = paramString;
  }








  
  public String getTransformation() {
    return this.transformation;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
