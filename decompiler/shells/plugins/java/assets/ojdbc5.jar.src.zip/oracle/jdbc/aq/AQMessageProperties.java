package oracle.jdbc.aq;

import java.sql.SQLException;
import java.sql.Timestamp;




















public interface AQMessageProperties
{
  public static final int MESSAGE_NO_DELAY = 0;
  public static final int MESSAGE_NO_EXPIRATION = -1;
  
  int getDequeueAttemptsCount();
  
  void setCorrelation(String paramString) throws SQLException;
  
  String getCorrelation();
  
  void setDelay(int paramInt) throws SQLException;
  
  int getDelay();
  
  Timestamp getEnqueueTime();
  
  void setExceptionQueue(String paramString) throws SQLException;
  
  String getExceptionQueue();
  
  void setExpiration(int paramInt) throws SQLException;
  
  int getExpiration();
  
  MessageState getState();
  
  void setPriority(int paramInt) throws SQLException;
  
  int getPriority();
  
  void setRecipientList(AQAgent[] paramArrayOfAQAgent) throws SQLException;
  
  AQAgent[] getRecipientList();
  
  void setSender(AQAgent paramAQAgent) throws SQLException;
  
  AQAgent getSender();
  
  String getTransactionGroup();
  
  byte[] getPreviousQueueMessageId();
  
  DeliveryMode getDeliveryMode();
  
  String toString();
  
  public enum MessageState
  {
    WAITING(1),


    
    READY(0),


    
    PROCESSED(2),


    
    EXPIRED(3);
    private final int code;
    
    MessageState(int param1Int1) {
      this.code = param1Int1;
    }




    
    public final int getCode() {
      return this.code;
    }




    
    public static final MessageState getMessageState(int param1Int) {
      if (param1Int == WAITING.getCode())
        return WAITING; 
      if (param1Int == READY.getCode())
        return READY; 
      if (param1Int == PROCESSED.getCode()) {
        return PROCESSED;
      }
      return EXPIRED;
    }
  }




  
  public enum DeliveryMode
  {
    PERSISTENT(1),


    
    BUFFERED(2);
    private final int code;
    
    DeliveryMode(int param1Int1) {
      this.code = param1Int1;
    }




    
    public final int getCode() {
      return this.code;
    }




    
    public static final DeliveryMode getDeliveryMode(int param1Int) {
      if (param1Int == BUFFERED.getCode()) {
        return BUFFERED;
      }
      return PERSISTENT;
    }
  }
}
