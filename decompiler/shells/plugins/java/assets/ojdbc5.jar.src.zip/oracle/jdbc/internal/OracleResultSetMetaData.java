package oracle.jdbc.internal;

import oracle.jdbc.OracleResultSetMetaData;

public interface OracleResultSetMetaData extends OracleResultSetMetaData {}
