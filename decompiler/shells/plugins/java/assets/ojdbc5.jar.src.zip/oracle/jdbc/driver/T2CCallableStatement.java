package oracle.jdbc.driver;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.CharBuffer;
import java.nio.ShortBuffer;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.oracore.OracleType;
import oracle.jdbc.oracore.OracleTypeADT;



























class T2CCallableStatement
  extends OracleCallableStatement
{
  T2CConnection connection = null;
  int userResultSetType = -1;
  int userResultSetConcur = -1;




  
  static int T2C_EXTEND_BUFFER = -3;













  
  long[] t2cOutput = new long[10];


  
  static final int T2C_OUTPUT_USE_NIO = 5;


  
  static final int T2C_OUTPUT_STMT_LOB_PREFETCH_SIZE = 6;


  
  int extractedCharOffset;


  
  int extractedByteOffset;


  
  static final byte T2C_LOB_PREFETCH_SIZE_THIS_COLUMN_OFFSET = 0;


  
  static final byte T2C_LOB_PREFETCH_LOB_LENGTH_OFFSET = 1;


  
  static final byte T2C_LOB_PREFETCH_FORM_OFFSET = 2;

  
  static final byte T2C_LOB_PREFETCH_CHUNK_OFFSET = 3;

  
  static final byte T2C_LOB_PREFETCH_DATA_OFFSET = 4;


  
  T2CCallableStatement(T2CConnection paramT2CConnection, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
    super(paramT2CConnection, paramString, paramInt1, paramInt2, paramInt3, paramInt4);

    
    this.userResultSetType = paramInt3;
    this.userResultSetConcur = paramInt4;

    
    this.connection = paramT2CConnection;
  }












  
  String bytes2String(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
    byte[] arrayOfByte = new byte[paramInt2];
    
    System.arraycopy(paramArrayOfbyte, paramInt1, arrayOfByte, 0, paramInt2);
    
    return this.connection.conversion.CharBytesToString(arrayOfByte, paramInt2);
  }












  
  void processDescribeData() throws SQLException {
    this.described = true;
    this.describedWithNames = true;









    
    if (this.accessors == null || this.numberOfDefinePositions > this.accessors.length) {
      this.accessors = new Accessor[this.numberOfDefinePositions];
    }













    
    int i = this.connection.queryMetaData1Offset;
    int j = this.connection.queryMetaData2Offset;
    short[] arrayOfShort = this.connection.queryMetaData1;
    byte[] arrayOfByte = this.connection.queryMetaData2;
    
    for (byte b = 0; b < this.numberOfDefinePositions; 
      b++, i += 13) {
      
      short s1 = arrayOfShort[i + 0];
      short s2 = arrayOfShort[i + 1];
      short s3 = arrayOfShort[i + 11];
      boolean bool1 = (arrayOfShort[i + 2] != 0) ? true : false;
      short s4 = arrayOfShort[i + 3];
      short s5 = arrayOfShort[i + 4];
      boolean bool2 = false;
      boolean bool3 = false;
      boolean bool4 = false;
      short s6 = arrayOfShort[i + 5];
      short s7 = arrayOfShort[i + 6];
      String str1 = bytes2String(arrayOfByte, j, s7);
      short s8 = arrayOfShort[i + 12];
      String str2 = null;
      OracleTypeADT oracleTypeADT = null;
      
      j += s7;
      
      if (s8 > 0) {
        
        str2 = bytes2String(arrayOfByte, j, s8);
        j += s8;
        oracleTypeADT = new OracleTypeADT(str2, (Connection)this.connection);
        oracleTypeADT.tdoCState = (arrayOfShort[i + 7] & 0xFFFFL) << 48L | (arrayOfShort[i + 8] & 0xFFFFL) << 32L | (arrayOfShort[i + 9] & 0xFFFFL) << 16L | arrayOfShort[i + 10] & 0xFFFFL;
      } 





      
      Accessor accessor = this.accessors[b];
      
      if (accessor != null && !accessor.useForDescribeIfPossible(s1, s2, bool1, bool2, s4, s5, bool3, bool4, s6, str2))
      {

        
        accessor = null;
      }
      
      if (accessor == null) {
        SQLException sQLException;
        switch (s1) {

          
          case 1:
            accessor = new VarcharAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);


            
            if (s3 > 0) {
              accessor.setDisplaySize(s3);
            }
            break;
          
          case 96:
            accessor = new CharAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);


            
            if (s3 > 0) {
              accessor.setDisplaySize(s3);
            }
            break;
          
          case 2:
            accessor = new NumberAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
            break;



          
          case 23:
            accessor = new RawAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
            break;



          
          case 100:
            accessor = new BinaryFloatAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
            break;



          
          case 101:
            accessor = new BinaryDoubleAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
            break;



          
          case 8:
            accessor = new LongAccessor(this, b + 1, s2, bool1, bool2, s4, s5, bool3, bool4, s6);





            
            this.rowPrefetch = 1;
            break;

          
          case 24:
            accessor = new LongRawAccessor(this, b + 1, s2, bool1, bool2, s4, s5, bool3, bool4, s6);





            
            this.rowPrefetch = 1;
            break;

          
          case 104:
            accessor = new RowidAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
            break;




          
          case 102:
          case 116:
            accessor = new T2CResultSetAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
            break;



          
          case 12:
            accessor = new DateAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
            break;



          
          case 180:
            accessor = new TimestampAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
            break;



          
          case 181:
            accessor = new TimestamptzAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
            break;



          
          case 231:
            accessor = new TimestampltzAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
            break;



          
          case 182:
            accessor = new IntervalymAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
            break;



          
          case 183:
            accessor = new IntervaldsAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
            break;



          
          case 112:
            accessor = new ClobAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
            break;



          
          case 113:
            accessor = new BlobAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
            break;



          
          case 114:
            accessor = new BfileAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6);
            break;



          
          case 109:
            accessor = new NamedTypeAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6, str2, (OracleType)oracleTypeADT);
            break;




          
          case 111:
            accessor = new RefTypeAccessor(this, s2, bool1, bool2, s4, s5, bool3, bool4, s6, str2, (OracleType)oracleTypeADT);
            break;





          
          default:
            sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Unknown or unimplemented accessor type: " + s1);
            
            sQLException.fillInStackTrace();
            throw sQLException;
        } 


        
        this.accessors[b] = accessor;
      }
      else if (oracleTypeADT != null) {


        
        accessor.describeOtype = (OracleType)oracleTypeADT;
        accessor.initMetadata();
      } 
      
      accessor.columnName = str1;
    } 
  }



































  
  void executeForDescribe() throws SQLException {
    boolean bool3;
    this.t2cOutput[0] = 0L;
    this.t2cOutput[2] = 0L;


    
    this.lobPrefetchMetaData = null;
    
    boolean bool1 = !this.described ? true : false;
    boolean bool2 = false;


    
    do {
      bool3 = false;

      
      if (this.connection.endToEndAnyChanged) {
        
        pushEndToEndValues();
        
        this.connection.endToEndAnyChanged = false;
      } 

      
      byte[] arrayOfByte = this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals);
      
      int i = 0;
      
      try {
        i = T2CStatement.t2cParseExecuteDescribe(this, this.c_state, this.numberOfBindPositions, this.numberOfBindRowsAllocated, this.firstRowInBatch, (this.currentRowBindAccessors != null), this.needToParse, bool1, bool2, arrayOfByte, arrayOfByte.length, T2CStatement.convertSqlKindEnumToByte(this.sqlKind), this.rowPrefetch, this.batch, this.bindIndicators, this.bindIndicatorOffset, this.bindBytes, this.bindChars, this.bindByteOffset, this.bindCharOffset, this.ibtBindIndicators, this.ibtBindIndicatorOffset, this.ibtBindIndicatorSize, this.ibtBindBytes, this.ibtBindChars, this.ibtBindByteOffset, this.ibtBindCharOffset, this.returnParamMeta, this.connection.queryMetaData1, this.connection.queryMetaData2, this.connection.queryMetaData1Offset, this.connection.queryMetaData2Offset, this.connection.queryMetaData1Size, this.connection.queryMetaData2Size, this.preparedAllBinds, this.preparedCharBinds, this.outBindAccessors, this.parameterDatum, this.t2cOutput, this.defineBytes, this.accessorByteOffset, this.defineChars, this.accessorCharOffset, this.defineIndicators, this.accessorShortOffset, this.connection.plsqlCompilerWarnings);












































      
      }
      catch (IOException iOException) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 266);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 


      
      this.validRows = (int)this.t2cOutput[1];

      
      if (i == -1 || i == -4) {
        
        this.connection.checkError(i);
      }
      else if (i == T2C_EXTEND_BUFFER) {
        
        i = this.connection.queryMetaData1Size * 2;
      } 


      
      if (this.t2cOutput[3] != 0L) {
        
        foundPlsqlCompilerWarning();
      }
      else if (this.t2cOutput[2] != 0L) {
        
        this.sqlWarning = this.connection.checkError(1, this.sqlWarning);
      } 


      
      this.connection.endToEndECIDSequenceNumber = (short)(int)this.t2cOutput[4];

      
      this.needToParse = false;
      bool2 = true;
      
      if (this.sqlKind.isSELECT())
      {
        this.numberOfDefinePositions = i;
        
        if (this.numberOfDefinePositions > this.connection.queryMetaData1Size)
        {
          bool3 = true;
          bool2 = true;

          
          this.connection.reallocateQueryMetaData(this.numberOfDefinePositions, this.numberOfDefinePositions * 8);
        
        }
      
      }
      else
      {
        this.numberOfDefinePositions = 0;
        this.validRows = i;
      }
    
    } while (bool3);
    
    processDescribeData();
  }



  
  void pushEndToEndValues() throws SQLException {
    T2CConnection t2CConnection = this.connection;
    byte[] arrayOfByte1 = new byte[0];
    byte[] arrayOfByte2 = new byte[0];
    byte[] arrayOfByte3 = new byte[0];
    byte[] arrayOfByte4 = new byte[0];
    
    if (t2CConnection.endToEndValues != null) {
      
      if (t2CConnection.endToEndHasChanged[0]) {
        
        String str = t2CConnection.endToEndValues[0];
        
        if (str != null) {
          arrayOfByte1 = DBConversion.stringToDriverCharBytes(str, t2CConnection.m_clientCharacterSet);
        }
        
        t2CConnection.endToEndHasChanged[0] = false;
      } 
      
      if (t2CConnection.endToEndHasChanged[1]) {
        
        String str = t2CConnection.endToEndValues[1];
        
        if (str != null) {
          arrayOfByte2 = DBConversion.stringToDriverCharBytes(str, t2CConnection.m_clientCharacterSet);
        }
        
        t2CConnection.endToEndHasChanged[1] = false;
      } 
      
      if (t2CConnection.endToEndHasChanged[2]) {
        
        String str = t2CConnection.endToEndValues[2];
        
        if (str != null) {
          arrayOfByte3 = DBConversion.stringToDriverCharBytes(str, t2CConnection.m_clientCharacterSet);
        }
        
        t2CConnection.endToEndHasChanged[2] = false;
      } 
      
      if (t2CConnection.endToEndHasChanged[3]) {
        
        String str = t2CConnection.endToEndValues[3];
        
        if (str != null) {
          arrayOfByte4 = DBConversion.stringToDriverCharBytes(str, t2CConnection.m_clientCharacterSet);
        }
        
        t2CConnection.endToEndHasChanged[3] = false;
      } 
      
      T2CStatement.t2cEndToEndUpdate(this.c_state, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, t2CConnection.endToEndECIDSequenceNumber);
    } 
  }
















































  
  void executeForRows(boolean paramBoolean) throws SQLException {
    if (this.connection.endToEndAnyChanged) {
      
      pushEndToEndValues();
      
      this.connection.endToEndAnyChanged = false;
    } 

    
    if (!paramBoolean) {






      
      if (this.numberOfDefinePositions > 0)
      {
        doDefineExecuteFetch();
      }
      else
      {
        executeForDescribe();
      }
    
    } else if (this.numberOfDefinePositions > 0) {
      doDefineFetch();
    } 

    
    this.needToPrepareDefineBuffer = false;
  }






  
  void setupForDefine() throws SQLException {
    if (this.numberOfDefinePositions > this.connection.queryMetaData1Size) {
      
      int j = this.numberOfDefinePositions / 100 + 1;
      
      this.connection.reallocateQueryMetaData(this.connection.queryMetaData1Size * j, this.connection.queryMetaData2Size * j * 8);
    } 


    
    short[] arrayOfShort = this.connection.queryMetaData1;
    int i = this.connection.queryMetaData1Offset;

    
    for (byte b = 0; b < this.numberOfDefinePositions; 
      b++, i += 13) {
      
      Accessor accessor = this.accessors[b];
      
      if (accessor == null) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      arrayOfShort[i + 0] = (short)accessor.defineType;
      
      arrayOfShort[i + 11] = (short)accessor.charLength;
      
      arrayOfShort[i + 1] = (short)accessor.byteLength;
      
      arrayOfShort[i + 5] = accessor.formOfUse;

      
      if (accessor.internalOtype != null) {
        
        long l = ((OracleTypeADT)accessor.internalOtype).getTdoCState();

        
        arrayOfShort[i + 7] = (short)(int)((l & 0xFFFF000000000000L) >> 48L);
        
        arrayOfShort[i + 8] = (short)(int)((l & 0xFFFF00000000L) >> 32L);
        
        arrayOfShort[i + 9] = (short)(int)((l & 0xFFFF0000L) >> 16L);
        
        arrayOfShort[i + 10] = (short)(int)(l & 0xFFFFL);
      } 

      
      switch (accessor.internalType) {


        
        case 112:
        case 113:
          if (accessor.lobPrefetchSizeForThisColumn == -1) {
            accessor.lobPrefetchSizeForThisColumn = this.defaultLobPrefetchSize;
          }
          
          arrayOfShort[i + 7] = (short)accessor.lobPrefetchSizeForThisColumn;
          break;
      } 
    } 
  }













  
  Object[] getLobPrefetchMetaData() {
    Object[] arrayOfObject = null;
    Object object = null;
    int[] arrayOfInt = null;
    byte b1 = 0;
    byte b2 = 0;
    
    if (this.accessors != null) {
      for (byte b = 0; b < this.numberOfDefinePositions; b++) {
        
        switch ((this.accessors[b]).internalType) {



          
          case 8:
          case 24:
            b2 = b;
            break;


          
          case 112:
          case 113:
            if (arrayOfInt == null)
            {
              arrayOfInt = new int[this.accessors.length];
            }
            
            if ((this.accessors[b]).lobPrefetchSizeForThisColumn != -1) {
              
              b1++;
              
              arrayOfInt[b] = (this.accessors[b]).lobPrefetchSizeForThisColumn;
              
              break;
            } 
            arrayOfInt[b] = -1;
            break;
        } 


      
      } 
    }
    if (b1 > 0) {
      
      if (arrayOfObject == null)
      {
        arrayOfObject = new Object[] { null, new long[this.rowPrefetch * b1], new byte[this.accessors.length], new int[this.accessors.length], new Object[this.rowPrefetch * b1] };
      }



















      
      for (byte b = 0; b < b2; b++) {
        
        switch ((this.accessors[b]).internalType) {
          
          case 112:
          case 113:
            (this.accessors[b]).lobPrefetchSizeForThisColumn = -1;
            arrayOfInt[b] = -1;
            break;
        } 
      
      } 
      arrayOfObject[0] = arrayOfInt;
    } 

    
    return arrayOfObject;
  }



  
  void processLobPrefetchMetaData(Object[] paramArrayOfObject) {
    byte b1 = 0;
    byte b2 = (this.validRows == -2) ? 1 : this.validRows;
    
    byte[] arrayOfByte = (byte[])paramArrayOfObject[2];
    int[] arrayOfInt1 = (int[])paramArrayOfObject[3];
    long[] arrayOfLong = (long[])paramArrayOfObject[1];
    Object[] arrayOfObject = (Object[])paramArrayOfObject[4];
    int[] arrayOfInt2 = (int[])paramArrayOfObject[0];
    
    if (this.accessors != null) {
      for (byte b = 0; b < this.numberOfDefinePositions; b++) {
        
        switch ((this.accessors[b]).internalType) {

          
          case 112:
          case 113:
            if ((this.accessors[b]).lobPrefetchSizeForThisColumn >= 0) {
              
              Accessor accessor = this.accessors[b];
              
              if (accessor.prefetchedLobDataL == null || accessor.prefetchedLobDataL.length < this.rowPrefetch) {

                
                if (accessor.internalType == 112) {
                  accessor.prefetchedLobCharData = new char[this.rowPrefetch][];
                } else {
                  accessor.prefetchedLobData = new byte[this.rowPrefetch][];
                } 
                accessor.prefetchedLobChunkSize = new int[this.rowPrefetch];
                accessor.prefetchedClobFormOfUse = new byte[this.rowPrefetch];
                accessor.prefetchedLobDataL = new int[this.rowPrefetch];
                accessor.prefetchedLobSize = new long[this.rowPrefetch];
              } 
              
              int i = b2 * b1;
              for (byte b3 = 0; b3 < b2; b3++) {
                
                accessor.prefetchedLobChunkSize[b3] = arrayOfInt1[b];
                
                accessor.prefetchedClobFormOfUse[b3] = arrayOfByte[b];

                
                accessor.prefetchedLobSize[b3] = arrayOfLong[i + b3];

                
                accessor.prefetchedLobDataL[b3] = 0;
                if (arrayOfInt2[b] > 0 && arrayOfLong[i + b3] > 0L)
                {
                  
                  if (accessor.internalType == 112) {
                    
                    accessor.prefetchedLobCharData[b3] = (char[])arrayOfObject[i + b3];
                    
                    if (accessor.prefetchedLobCharData[b3] != null) {
                      accessor.prefetchedLobDataL[b3] = (accessor.prefetchedLobCharData[b3]).length;
                    }
                  }
                  else {
                    
                    accessor.prefetchedLobData[b3] = (byte[])arrayOfObject[i + b3];
                    
                    if (accessor.prefetchedLobData[b3] != null) {
                      accessor.prefetchedLobDataL[b3] = (accessor.prefetchedLobData[b3]).length;
                    }
                  } 
                }
              } 
              b1++;
            } 
            break;
        } 
      } 
    }
  }




  
  void doDefineFetch() throws SQLException {
    if (!this.needToPrepareDefineBuffer) {
      throw new Error("doDefineFetch called when needToPrepareDefineBuffer=false " + this.sqlObject.getSql(this.processEscapes, this.convertNcharLiterals));
    }
    
    setupForDefine();
    
    this.t2cOutput[2] = 0L;
    this.t2cOutput[5] = (this.connection.useNio ? 1L : 0L);
    this.t2cOutput[6] = this.defaultLobPrefetchSize;
    if (this.connection.useNio) {
      resetNioAttributesBeforeFetch();
      allocateNioBuffersIfRequired((this.defineChars == null) ? 0 : this.defineChars.length, (this.defineBytes == null) ? 0 : this.defineBytes.length, (this.defineIndicators == null) ? 0 : this.defineIndicators.length);
    } 



    
    if (this.lobPrefetchMetaData == null) {
      this.lobPrefetchMetaData = getLobPrefetchMetaData();
    }
    this.validRows = T2CStatement.t2cDefineFetch(this, this.c_state, this.rowPrefetch, this.connection.queryMetaData1, this.connection.queryMetaData2, this.connection.queryMetaData1Offset, this.connection.queryMetaData2Offset, this.accessors, this.defineBytes, this.accessorByteOffset, this.defineChars, this.accessorCharOffset, this.defineIndicators, this.accessorShortOffset, this.t2cOutput, this.nioBuffers, this.lobPrefetchMetaData);











    
    if (this.validRows == -1 || this.validRows == -4) {
      this.connection.checkError(this.validRows);
    }
    
    if (this.t2cOutput[2] != 0L)
    {
      this.sqlWarning = this.connection.checkError(1, this.sqlWarning);
    }

    
    if (this.connection.useNio && (this.validRows > 0 || this.validRows == -2))
    {
      extractNioDefineBuffers(0);
    }
    if (this.lobPrefetchMetaData != null)
    {
      processLobPrefetchMetaData(this.lobPrefetchMetaData);
    }
  }





  
  void allocateNioBuffersIfRequired(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
    if (this.nioBuffers == null) {
      this.nioBuffers = new ByteBuffer[4];
    }
    if (paramInt2 > 0)
    {
      if (this.nioBuffers[0] == null || this.nioBuffers[0].capacity() < paramInt2) {

        
        this.nioBuffers[0] = ByteBuffer.allocateDirect(paramInt2);
      } else if (this.nioBuffers[0] != null) {
        
        this.nioBuffers[0].rewind();
      } 
    }



    
    paramInt1 *= 2;
    if (paramInt1 > 0)
    {
      if (this.nioBuffers[1] == null || this.nioBuffers[1].capacity() < paramInt1) {

        
        this.nioBuffers[1] = ByteBuffer.allocateDirect(paramInt1);
      } else if (this.nioBuffers[1] != null) {
        
        this.nioBuffers[1].rewind();
      } 
    }



    
    paramInt3 *= 2;
    if (paramInt3 > 0)
    {
      if (this.nioBuffers[2] == null || this.nioBuffers[2].capacity() < paramInt3) {

        
        this.nioBuffers[2] = ByteBuffer.allocateDirect(paramInt3);
      } else if (this.nioBuffers[2] != null) {
        
        this.nioBuffers[2].rewind();
      } 
    }
  }



  
  void doDefineExecuteFetch() throws SQLException {
    short[] arrayOfShort = null;
    
    if (this.needToPrepareDefineBuffer || this.needToParse) {
      
      setupForDefine();
      
      arrayOfShort = this.connection.queryMetaData1;
    } 
    
    this.t2cOutput[0] = 0L;
    this.t2cOutput[2] = 0L;
    
    byte[] arrayOfByte = this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals);
    this.t2cOutput[5] = (this.connection.useNio ? 1L : 0L);
    this.t2cOutput[6] = this.defaultLobPrefetchSize;
    if (this.connection.useNio) {
      resetNioAttributesBeforeFetch();
      allocateNioBuffersIfRequired((this.defineChars == null) ? 0 : this.defineChars.length, (this.defineBytes == null) ? 0 : this.defineBytes.length, (this.defineIndicators == null) ? 0 : this.defineIndicators.length);
    } 



    
    if (this.lobPrefetchMetaData == null) {
      this.lobPrefetchMetaData = getLobPrefetchMetaData();
    }
    try {
      this.validRows = T2CStatement.t2cDefineExecuteFetch(this, this.c_state, this.numberOfDefinePositions, this.numberOfBindPositions, this.numberOfBindRowsAllocated, this.firstRowInBatch, (this.currentRowBindAccessors != null), this.needToParse, arrayOfByte, arrayOfByte.length, T2CStatement.convertSqlKindEnumToByte(this.sqlKind), this.rowPrefetch, this.batch, this.bindIndicators, this.bindIndicatorOffset, this.bindBytes, this.bindChars, this.bindByteOffset, this.bindCharOffset, arrayOfShort, this.connection.queryMetaData2, this.connection.queryMetaData1Offset, this.connection.queryMetaData2Offset, this.preparedAllBinds, this.preparedCharBinds, this.outBindAccessors, this.parameterDatum, this.t2cOutput, this.defineBytes, this.accessorByteOffset, this.defineChars, this.accessorCharOffset, this.defineIndicators, this.accessorShortOffset, this.nioBuffers, this.lobPrefetchMetaData);



































    
    }
    catch (IOException iOException) {
      
      this.validRows = 0;
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    if (this.validRows == -1) {
      this.connection.checkError(this.validRows);
    }
    if (this.t2cOutput[2] != 0L) {
      this.sqlWarning = this.connection.checkError(1, this.sqlWarning);
    }


    
    this.connection.endToEndECIDSequenceNumber = (short)(int)this.t2cOutput[4];
    
    if (this.connection.useNio && (this.validRows > 0 || this.validRows == -2))
    {
      extractNioDefineBuffers(0);
    }
    if (this.lobPrefetchMetaData != null)
    {
      processLobPrefetchMetaData(this.lobPrefetchMetaData);
    }
    
    this.needToParse = false;
  }







































  
  void fetch() throws SQLException {
    if (this.numberOfDefinePositions > 0)
    {
      if (this.needToPrepareDefineBuffer) {
        doDefineFetch();
      } else {
        
        this.t2cOutput[2] = 0L;
        this.t2cOutput[5] = (this.connection.useNio ? 1L : 0L);
        this.t2cOutput[6] = this.defaultLobPrefetchSize;
        if (this.connection.useNio) {
          resetNioAttributesBeforeFetch();
          allocateNioBuffersIfRequired((this.defineChars == null) ? 0 : this.defineChars.length, (this.defineBytes == null) ? 0 : this.defineBytes.length, (this.defineIndicators == null) ? 0 : this.defineIndicators.length);
        } 




        
        if (this.lobPrefetchMetaData == null) {
          this.lobPrefetchMetaData = getLobPrefetchMetaData();
        }
        this.validRows = T2CStatement.t2cFetch(this.c_state, this.needToPrepareDefineBuffer, this.rowPrefetch, this.accessors, this.defineBytes, this.accessorByteOffset, this.defineChars, this.accessorCharOffset, this.defineIndicators, this.accessorShortOffset, this.t2cOutput, this.nioBuffers, this.lobPrefetchMetaData);






        
        if (this.validRows == -1 || this.validRows == -4) {
          this.connection.checkError(this.validRows);
        }
        if (this.t2cOutput[2] != 0L)
        {
          this.sqlWarning = this.connection.checkError(1, this.sqlWarning);
        }
        
        if (this.lobPrefetchMetaData != null)
        {
          processLobPrefetchMetaData(this.lobPrefetchMetaData);
        }
        if (this.connection.useNio && (this.validRows > 0 || this.validRows == -2))
        {
          extractNioDefineBuffers(0);
        }
      } 
    }
  }


  
  void resetNioAttributesBeforeFetch() {
    this.extractedCharOffset = 0;
    this.extractedByteOffset = 0;
  }





  
  void extractNioDefineBuffers(int paramInt) throws SQLException {
    if (this.accessors == null || this.defineIndicators == null || paramInt == this.numberOfDefinePositions) {
      return;
    }

    
    int i = 0;
    int j = 0;
    int k = 0;
    int m = 0;
    int n = 0;

    
    if (!this.hasStream) {
      
      i = (this.defineBytes != null) ? this.defineBytes.length : 0;
      j = (this.defineChars != null) ? this.defineChars.length : 0;
      k = this.defineIndicators.length;
    }
    else {
      
      if (this.numberOfDefinePositions > paramInt) {
        
        n = (this.accessors[paramInt]).indicatorIndex;
        m = (this.accessors[paramInt]).lengthIndex;
      } 


      
      for (int i1 = paramInt; i1 < this.numberOfDefinePositions; i1++) {
        
        switch ((this.accessors[i1]).internalType) {
          case 8:
          case 24:
            break;
        } 
        
        i += (this.accessors[i1]).byteLength;
        j += (this.accessors[i1]).charLength;
        k++;
      } 
    } 

    
    ByteBuffer byteBuffer = this.nioBuffers[0];
    if (byteBuffer != null && this.defineBytes != null)
    {
      if (i > 0) {
        
        byteBuffer.position(this.extractedByteOffset);
        byteBuffer.get(this.defineBytes, this.extractedByteOffset, i);
        this.extractedByteOffset += i;
      } 
    }











    
    if (this.nioBuffers[1] != null && this.defineChars != null) {
      
      byteBuffer = this.nioBuffers[1].order(ByteOrder.LITTLE_ENDIAN);
      CharBuffer charBuffer = byteBuffer.asCharBuffer();
      
      if (j > 0) {
        
        charBuffer.position(this.extractedCharOffset);
        charBuffer.get(this.defineChars, this.extractedCharOffset, j);
        this.extractedCharOffset += j;
      } 
    } 















    
    if (this.nioBuffers[2] != null) {
      byteBuffer = this.nioBuffers[2].order(ByteOrder.LITTLE_ENDIAN);
      ShortBuffer shortBuffer = byteBuffer.asShortBuffer();
      if (this.hasStream) {
        
        if (k > 0) {
          
          shortBuffer.position(n);
          shortBuffer.get(this.defineIndicators, n, k);
          shortBuffer.position(m);
          shortBuffer.get(this.defineIndicators, m, k);
        } 
      } else {
        
        shortBuffer.get(this.defineIndicators);
      } 
    } 
  }










































  
  void doClose() throws SQLException {
    if (this.defineBytes != null) {
      
      this.defineBytes = null;
      this.accessorByteOffset = 0;
    } 
    
    if (this.defineChars != null) {
      
      this.defineChars = null;
      this.accessorCharOffset = 0;
    } 
    
    if (this.defineIndicators != null) {
      
      this.defineIndicators = null;
      this.accessorShortOffset = 0;
    } 

    
    int i = T2CStatement.t2cCloseStatement(this.c_state);
    
    this.nioBuffers = null;
    
    if (i != 0) {
      this.connection.checkError(i);
    }
    this.t2cOutput = null;
  }














  
  void closeQuery() throws SQLException {
    if (this.streamList != null)
    {
      while (this.nextStream != null) {

        
        try {
          this.nextStream.close();
        }
        catch (IOException iOException) {

          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 

        
        this.nextStream = this.nextStream.nextStream;
      } 
    }
  }











  
  Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean) throws SQLException {
    if (paramInt1 == 116 || paramInt1 == 102) {

      
      if (paramBoolean && paramString != null) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      return new T2CResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
    } 



    
    return super.allocateAccessor(paramInt1, paramInt2, paramInt3, paramInt4, paramShort, paramString, paramBoolean);
  }




  
  void closeUsedStreams(int paramInt) throws SQLException {
    while (this.nextStream != null && this.nextStream.columnIndex < paramInt) {

      
      try {

        
        this.nextStream.close();
      }
      catch (IOException iOException) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      this.nextStream = this.nextStream.nextStream;
    } 
    
    if (this.nextStream != null) {
      
      try {
        this.nextStream.needBytes();
      }
      catch (IOException iOException) {
        
        interalCloseOnIOException(iOException);
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    }
  }



  
  void interalCloseOnIOException(IOException paramIOException) throws SQLException {
    this.closed = true;
    
    if (this.currentResultSet != null) {
      this.currentResultSet.closed = true;
    }
    doClose();
  }



  
  void fetchDmlReturnParams() throws SQLException {
    this.rowsDmlReturned = T2CStatement.t2cGetRowsDmlReturned(this.c_state);
    
    if (this.rowsDmlReturned != 0) {
      
      allocateDmlReturnStorage();
      
      int i = T2CStatement.t2cFetchDmlReturnParams(this.c_state, this.returnParamAccessors, this.returnParamBytes, this.returnParamChars, this.returnParamIndicators);






      
      if (i == -1 || i == -4) {
        this.connection.checkError(i);
      }
      
      if (this.t2cOutput[2] != 0L)
      {
        this.sqlWarning = this.connection.checkError(1, this.sqlWarning);
      }

      
      if (this.connection.useNio && (i > 0 || i == -2))
      {
        extractNioDefineBuffers(0);
      }
    } 
    this.returnParamsFetched = true;
  }








  
  static int PREAMBLE_PER_POSITION = 5;



  
  void initializeIndicatorSubRange() {
    this.bindIndicatorSubRange = this.numberOfBindPositions * PREAMBLE_PER_POSITION;
  }



  
  int calculateIndicatorSubRangeSize() {
    return this.numberOfBindPositions * PREAMBLE_PER_POSITION;
  }



  
  short getInoutIndicator(int paramInt) {
    return this.bindIndicators[paramInt * PREAMBLE_PER_POSITION];
  }









  
  void prepareBindPreambles(int paramInt1, int paramInt2) {
    int i = calculateIndicatorSubRangeSize();
    int j = this.bindIndicatorSubRange - i;
    OracleTypeADT[] arrayOfOracleTypeADT = (this.parameterOtype == null) ? null : this.parameterOtype[this.firstRowInBatch];


    
    for (byte b = 0; b < this.numberOfBindPositions; b++) {
      short s;
      OracleTypeADT oracleTypeADT;
      Binder binder = this.lastBinders[b];

      
      if (binder == this.theReturnParamBinder) {
        
        oracleTypeADT = (OracleTypeADT)(this.returnParamAccessors[b]).internalOtype;
        s = 0;
      }
      else {
        
        oracleTypeADT = (arrayOfOracleTypeADT == null) ? null : arrayOfOracleTypeADT[b];
        
        if (this.outBindAccessors == null) {
          s = 0;
        } else {
          
          Accessor accessor = this.outBindAccessors[b];
          
          if (accessor == null) {
            s = 0;
          } else if (binder == this.theOutBinder) {
            
            s = 1;
            
            if (oracleTypeADT == null) {
              oracleTypeADT = (OracleTypeADT)accessor.internalOtype;
            }
          } else {
            s = 2;
          } 
        }  s = binder.updateInoutIndicatorValue(s);
      } 
      
      this.bindIndicators[j++] = s;
      
      if (oracleTypeADT != null) {
        
        long l = oracleTypeADT.getTdoCState();
        
        this.bindIndicators[j + 0] = (short)(int)(l >> 48L & 0xFFFFL);
        
        this.bindIndicators[j + 1] = (short)(int)(l >> 32L & 0xFFFFL);
        
        this.bindIndicators[j + 2] = (short)(int)(l >> 16L & 0xFFFFL);
        
        this.bindIndicators[j + 3] = (short)(int)(l & 0xFFFFL);
      } 
      
      j += 4;
    } 
  }



  
  void releaseBuffers() {
    super.releaseBuffers();
  }














  
  void doDescribe(boolean paramBoolean) throws SQLException {
    boolean bool;
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.described == true) {
      return;
    }

    
    if (!this.isOpen) {


      
      this.connection.open(this);
      this.isOpen = true;
    } 




    
    do {
      bool = false;







      
      boolean bool1 = (this.sqlKind.isSELECT() && this.needToParse && (!this.described || !this.serverCursor)) ? true : false;
      byte[] arrayOfByte = bool1 ? this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals) : PhysicalConnection.EMPTY_BYTE_ARRAY;
      this.numberOfDefinePositions = T2CStatement.t2cDescribe(this.c_state, this.connection.queryMetaData1, this.connection.queryMetaData2, this.connection.queryMetaData1Offset, this.connection.queryMetaData2Offset, this.connection.queryMetaData1Size, this.connection.queryMetaData2Size, arrayOfByte, arrayOfByte.length, bool1);









      
      if (!this.described) {
        this.described = true;
      }




      
      if (this.numberOfDefinePositions == -1)
      {
        this.connection.checkError(this.numberOfDefinePositions);
      }

      
      if (this.numberOfDefinePositions != T2C_EXTEND_BUFFER)
        continue; 
      bool = true;


      
      this.connection.reallocateQueryMetaData(this.connection.queryMetaData1Size * 2, this.connection.queryMetaData2Size * 2);

    
    }
    while (bool);
    
    processDescribeData();
  }





  
  void registerOutParameterInternal(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString) throws SQLException {
    int i = paramInt1 - 1;
    
    if (i < 0 || paramInt1 > this.numberOfBindPositions) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    int j = getInternalType(paramInt2);
    
    if (j == 995) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    resetBatch();
    
    this.currentRowNeedToPrepareBinds = true;
    
    if (this.currentRowBindAccessors == null) {
      this.currentRowBindAccessors = new Accessor[this.numberOfBindPositions];
    }
    
    switch (paramInt2) {
      case -4:
      case -3:
      case -1:
      case 1:
      case 12:
      case 70:
        break;




      
      default:
        paramInt4 = 0;
        break;
    } 
    
    this.currentRowBindAccessors[i] = allocateAccessor(j, paramInt2, paramInt1, paramInt4, this.currentRowFormOfUse[i], paramString, true);
  }



  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
