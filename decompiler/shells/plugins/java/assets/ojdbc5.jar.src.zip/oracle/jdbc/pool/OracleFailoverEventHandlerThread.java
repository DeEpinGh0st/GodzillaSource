package oracle.jdbc.pool;

import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.sql.SQLException;
import oracle.ons.Notification;
import oracle.ons.ONSException;
import oracle.ons.Subscriber;
import oracle.ons.SubscriptionException;



























class OracleFailoverEventHandlerThread
  extends Thread
{
  private Notification event = null;
  private OracleConnectionCacheManager cacheManager = null;



  
  OracleFailoverEventHandlerThread() throws SQLException {
    this.cacheManager = OracleConnectionCacheManager.getConnectionCacheManagerInstance();
  }





  
  public void run() {
    Subscriber subscriber = null;



    
    while (this.cacheManager.failoverEnabledCacheExists()) {

      
      try {
        
        subscriber = AccessController.<Subscriber>doPrivileged(new PrivilegedExceptionAction<Subscriber>()
            {



              
              public Object run()
              {
                try {
                  return new Subscriber("(%\"eventType=database/event/service\")|(%\"eventType=database/event/host\")", "", 30000L);
                }
                catch (SubscriptionException subscriptionException) {

                  
                  return null;
                }
              
              }
            });
      } catch (PrivilegedActionException privilegedActionException) {}



      
      if (subscriber != null) {
        
        try {
          
          while (this.cacheManager.failoverEnabledCacheExists()) {

            
            if ((this.event = subscriber.receive(true)) != null) {
              handleEvent(this.event);
            }
          } 
        } catch (ONSException oNSException) {
          
          subscriber.close();
        } 
      }



      
      try {
        Thread.currentThread(); Thread.sleep(10000L);
      }
      catch (InterruptedException interruptedException) {}
    } 
  }









  
  void handleEvent(Notification paramNotification) {
    try {
      char c = Character.MIN_VALUE;
      
      if (paramNotification.type().equalsIgnoreCase("database/event/service")) {
        c = 'Ā';
      } else if (paramNotification.type().equalsIgnoreCase("database/event/host")) {
        c = 'Ȁ';
      } 
      if (c != '\000') {
        this.cacheManager.verifyAndHandleEvent(c, paramNotification.body());
      }
    } catch (SQLException sQLException) {}
  }





  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
