package oracle.jdbc.xa.client;

import java.sql.Connection;
import javax.transaction.xa.XAException;
import javax.transaction.xa.XAResource;
import oracle.jdbc.xa.OracleXAConnection;
import oracle.jdbc.xa.OracleXAResource;















































public class OracleXAConnection
  extends OracleXAConnection
{
  protected boolean isXAResourceTransLoose = false;
  
  public OracleXAConnection() throws XAException {}
  
  public OracleXAConnection(Connection paramConnection) throws XAException {
    super(paramConnection);
  }













  
  public synchronized XAResource getXAResource() {
    try {
      if (this.xaResource == null)
      {
        this.xaResource = (XAResource)new OracleXAResource((Connection)this.physicalConn, this);
        ((OracleXAResource)this.xaResource).isTransLoose = this.isXAResourceTransLoose;
        
        if (this.logicalHandle != null)
        {

          
          ((OracleXAResource)this.xaResource).setLogicalConnection((Connection)this.logicalHandle);
        }
      }
    
    } catch (XAException xAException) {
      
      this.xaResource = null;
    } 
    
    return this.xaResource;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
