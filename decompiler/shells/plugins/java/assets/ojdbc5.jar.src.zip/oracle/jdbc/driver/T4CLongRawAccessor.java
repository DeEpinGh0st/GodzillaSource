package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;
import oracle.net.ns.BreakNetException;
























class T4CLongRawAccessor
  extends LongRawAccessor
{
  T4CMAREngine mare;
  byte[][] data = (byte[][])null;
  int[] nbBytesRead = null;
  int[] bytesReadSoFar = null;
  final int[] escapeSequenceArr;
  final boolean[] readHeaderArr;
  final boolean[] readAsNonStreamArr;
  
  T4CLongRawAccessor(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, short paramShort, int paramInt3, T4CMAREngine paramT4CMAREngine) throws SQLException {
    super(paramOracleStatement, paramInt1, paramInt2, paramShort, paramInt3);











































































    
    this.escapeSequenceArr = new int[1];
    this.readHeaderArr = new boolean[1];
    this.readAsNonStreamArr = new boolean[1]; this.mare = paramT4CMAREngine; if (paramOracleStatement.connection.useFetchSizeWithLongColumn) { this.data = new byte[paramOracleStatement.rowPrefetch][]; for (byte b = 0; b < paramOracleStatement.rowPrefetch; b++) this.data[b] = new byte[4080];  this.nbBytesRead = new int[paramOracleStatement.rowPrefetch]; this.bytesReadSoFar = new int[paramOracleStatement.rowPrefetch]; }  } T4CLongRawAccessor(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, short paramShort, int paramInt8, int paramInt9, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, paramInt1, paramInt2, paramBoolean, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramShort); this.escapeSequenceArr = new int[1]; this.readHeaderArr = new boolean[1]; this.readAsNonStreamArr = new boolean[1]; this.mare = paramT4CMAREngine; this.definedColumnType = paramInt8; this.definedColumnSize = paramInt9; if (paramOracleStatement.connection.useFetchSizeWithLongColumn) {
      this.data = new byte[paramOracleStatement.rowPrefetch][]; for (byte b = 0; b < paramOracleStatement.rowPrefetch; b++)
        this.data[b] = new byte[4080]; 
      this.nbBytesRead = new int[paramOracleStatement.rowPrefetch];
      this.bytesReadSoFar = new int[paramOracleStatement.rowPrefetch];
    }  }
  void processIndicator(int paramInt) throws IOException, SQLException { if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
      this.mare.unmarshalUB2();
      this.mare.unmarshalUB2();
    } else if (this.statement.connection.versionNumber < 9200) {
      this.mare.unmarshalSB2();
      if (!this.statement.sqlKind.isPlsqlOrCall())
        this.mare.unmarshalSB2(); 
    } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) {
      this.mare.processIndicator((paramInt <= 0), paramInt);
    }  } boolean unmarshalOneRow() throws SQLException, IOException { if (this.isUseLess) {
      
      this.lastRowProcessed++;
      
      return false;
    } 
    
    boolean bool = false;
    int i = this.indicatorIndex + this.lastRowProcessed;




    
    this.escapeSequenceArr[0] = this.mare.unmarshalUB1();

    
    if (this.mare.escapeSequenceNull(this.escapeSequenceArr[0])) {


      
      this.rowSpaceIndicator[i] = -1;
      
      this.mare.processIndicator(false, 0);
      
      int j = (int)this.mare.unmarshalUB4();
      
      bool = false;
      
      this.escapeSequenceArr[0] = 0;
      this.lastRowProcessed++;
    
    }
    else {

      
      this.rowSpaceIndicator[i] = 0;
      this.readHeaderArr[0] = true;
      this.readAsNonStreamArr[0] = false;

      
      if (this.statement.connection.useFetchSizeWithLongColumn) {



        
        int j = 0;
        
        while (j != -1) {


          
          if ((this.data[this.lastRowProcessed]).length < this.nbBytesRead[this.lastRowProcessed] + 255) {

            
            byte[] arrayOfByte = new byte[(this.data[this.lastRowProcessed]).length * 4];
            
            System.arraycopy(this.data[this.lastRowProcessed], 0, arrayOfByte, 0, this.nbBytesRead[this.lastRowProcessed]);

            
            this.data[this.lastRowProcessed] = arrayOfByte;
          } 
          
          j = readStreamFromWire(this.data[this.lastRowProcessed], this.nbBytesRead[this.lastRowProcessed], 255, this.escapeSequenceArr, this.readHeaderArr, this.readAsNonStreamArr, this.mare, ((T4CConnection)this.statement.connection).oer);




          
          if (this.statement.connection.calculateChecksum && j != -1) {
            
            long l = CRC64.updateChecksum(this.statement.checkSum, this.data[this.lastRowProcessed], this.nbBytesRead[this.lastRowProcessed], j);


            
            this.statement.checkSum = l;
          } 
          
          if (j != -1)
          {
            this.nbBytesRead[this.lastRowProcessed] = this.nbBytesRead[this.lastRowProcessed] + j;
          }
        } 
        
        this.lastRowProcessed++;
      }
      else {
        
        bool = true;
      } 
    } 
    
    return bool; }











  
  void fetchNextColumns() throws SQLException {
    this.statement.continueReadRow(this.columnPosition);
  }















  
  int readStream(byte[] paramArrayOfbyte, int paramInt) throws SQLException, IOException {
    int i = this.statement.currentRow;
    
    if (this.statement.connection.useFetchSizeWithLongColumn) {
      
      byte[] arrayOfByte = this.data[i];
      int k = this.nbBytesRead[i];
      int m = this.bytesReadSoFar[i];
      
      if (m == k) {
        return -1;
      }
      
      int n = 0;
      
      if (paramInt <= k - m) {
        n = paramInt;
      } else {
        n = k - m;
      } 
      System.arraycopy(arrayOfByte, m, paramArrayOfbyte, 0, n);
      
      this.bytesReadSoFar[i] = this.bytesReadSoFar[i] + n;
      
      return n;
    } 


    
    int j = readStreamFromWire(paramArrayOfbyte, 0, paramInt, this.escapeSequenceArr, this.readHeaderArr, this.readAsNonStreamArr, this.mare, ((T4CConnection)this.statement.connection).oer);

    
    if (this.statement.connection.calculateChecksum && j != -1) {
      
      long l = CRC64.updateChecksum(this.statement.checkSum, paramArrayOfbyte, 0, j);



      
      this.statement.checkSum = l;
    } 

    
    return j;
  }
























  
  protected static final int readStreamFromWire(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int[] paramArrayOfint, boolean[] paramArrayOfboolean1, boolean[] paramArrayOfboolean2, T4CMAREngine paramT4CMAREngine, T4CTTIoer paramT4CTTIoer) throws SQLException, IOException {
    int i = -1;

    
    try {
      if (!paramArrayOfboolean2[0]) {


        
        if (paramInt2 > 255 || paramInt2 < 0) {





          
          SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 433);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 

        
        if (paramArrayOfboolean1[0])
        {


          
          if (paramArrayOfint[0] == 254) {
            
            i = paramT4CMAREngine.unmarshalUB1();
          }
          else {
            
            if (paramArrayOfint[0] == 0) {

              
              paramT4CTTIoer.connection.internalClose();
              
              SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 401);
              sQLException.fillInStackTrace();
              throw sQLException;
            } 



            
            paramArrayOfboolean2[0] = true;
            i = paramArrayOfint[0];
          } 
          
          paramArrayOfboolean1[0] = false;
          paramArrayOfint[0] = 0;
        }
        else
        {
          i = paramT4CMAREngine.unmarshalUB1();
        
        }
      
      }
      else {
        
        paramArrayOfboolean2[0] = false;
      } 

      
      if (i > 0) {


        
        paramT4CMAREngine.unmarshalNBytes(paramArrayOfbyte, paramInt1, i);
      }
      else {
        
        i = -1;
      } 
    } catch (BreakNetException breakNetException) {





      
      i = paramT4CMAREngine.unmarshalUB1();
      if (i == 4) {
        
        paramT4CTTIoer.init();
        paramT4CTTIoer.processError();
      } 
    } 

    
    if (i == -1) {
      
      paramArrayOfboolean1[0] = true;


      
      paramT4CMAREngine.unmarshalUB2();
      paramT4CMAREngine.unmarshalUB2();
    } 
    
    return i;
  }






  
  String getString(int paramInt) throws SQLException {
    String str = super.getString(paramInt);


    
    if (str != null && this.definedColumnSize > 0 && str.length() > this.definedColumnSize * 2)
    {
      str = str.substring(0, this.definedColumnSize * 2);
    }
    return str;
  }



  
  long updateChecksum(long paramLong, int paramInt) throws SQLException {
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1)
    {
      paramLong = CRC64.updateChecksum(paramLong, NULL_DATA_BYTES, 0, NULL_DATA_BYTES.length);
    }



    
    return paramLong;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
