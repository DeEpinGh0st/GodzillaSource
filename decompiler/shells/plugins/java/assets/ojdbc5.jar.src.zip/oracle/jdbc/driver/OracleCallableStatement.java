package oracle.jdbc.driver;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;
import oracle.jdbc.OracleDataFactory;
import oracle.jdbc.internal.OracleCallableStatement;
import oracle.sql.ANYDATA;
import oracle.sql.ARRAY;
import oracle.sql.BFILE;
import oracle.sql.BINARY_DOUBLE;
import oracle.sql.BINARY_FLOAT;
import oracle.sql.BLOB;
import oracle.sql.CHAR;
import oracle.sql.CLOB;
import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import oracle.sql.DATE;
import oracle.sql.Datum;
import oracle.sql.INTERVALDS;
import oracle.sql.INTERVALYM;
import oracle.sql.NUMBER;
import oracle.sql.OPAQUE;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.RAW;
import oracle.sql.REF;
import oracle.sql.ROWID;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;




abstract class OracleCallableStatement
  extends OraclePreparedStatement
  implements OracleCallableStatement
{
  boolean atLeastOneOrdinalParameter = false;
  boolean atLeastOneNamedParameter = false;
  String[] namedParameters = new String[8];

  
  int parameterCount = 0;

  
  final String errMsgMixedBind = "Ordinal binding and Named binding cannot be combined!";


















  
  OracleCallableStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2) throws SQLException {
    this(paramPhysicalConnection, paramString, paramInt1, paramInt2, 1003, 1007);
  }














  
  OracleCallableStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
    super(paramPhysicalConnection, paramString, 1, paramInt2, paramInt3, paramInt4);

    
    this.statementType = 2;
  }









  
  void registerOutParameterInternal(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString) throws SQLException {
    int i = paramInt1 - 1;
    if (i < 0 || paramInt1 > this.numberOfBindPositions) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (paramInt2 == 0) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    int j = getInternalType(paramInt2);
    
    resetBatch();
    this.currentRowNeedToPrepareBinds = true;
    
    if (this.currentRowBindAccessors == null) {
      this.currentRowBindAccessors = new Accessor[this.numberOfBindPositions];
    }
    
    switch (paramInt2) {
      case -4:
      case -3:
      case -1:
      case 1:
      case 12:
      case 70:
        break;




      
      default:
        paramInt4 = 0;
        break;
    } 
    
    this.currentRowBindAccessors[i] = allocateAccessor(j, paramInt2, i + 1, paramInt4, this.currentRowFormOfUse[i], paramString, true);
  }






























  
  public void registerOutParameter(int paramInt1, int paramInt2, String paramString) throws SQLException {
    if (paramString == null || paramString.length() == 0) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "empty Object name");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    synchronized (this.connection) {
      registerOutParameterInternal(paramInt1, paramInt2, 0, 0, paramString);
    } 
  }
























  
  public void registerOutParameterBytes(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
    synchronized (this.connection) {
      
      registerOutParameterInternal(paramInt1, paramInt2, paramInt3, paramInt4, (String)null);
    } 
  }
























  
  public void registerOutParameterChars(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
    synchronized (this.connection) {
      
      registerOutParameterInternal(paramInt1, paramInt2, paramInt3, paramInt4, (String)null);
    } 
  }












  
  public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
    synchronized (this.connection) {
      
      registerOutParameterInternal(paramInt1, paramInt2, paramInt3, paramInt4, (String)null);
    } 
  }












  
  public void registerOutParameter(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
    synchronized (this.connection) {
      
      registerOutParameterInternal(paramString, paramInt1, paramInt2, paramInt3, (String)null);
    } 
  }




  
  boolean isOracleBatchStyle() {
    return false;
  }






  
  void resetBatch() {
    this.batch = 1;
  }












  
  public void setExecuteBatch(int paramInt) throws SQLException {}











  
  public int sendBatch() throws SQLException {
    synchronized (this.connection) {

      
      return this.validRows;
    } 
  }














  
  public void registerOutParameter(int paramInt1, int paramInt2) throws SQLException {
    registerOutParameter(paramInt1, paramInt2, 0, -1);
  }








  
  public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
    registerOutParameter(paramInt1, paramInt2, paramInt3, -1);
  }




  
  public boolean wasNull() throws SQLException {
    return wasNullValue();
  }






  
  public String getString(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getString(this.currentRank);
  }






  
  public Datum getOracleObject(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getOracleObject(this.currentRank);
  }






  
  public ROWID getROWID(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getROWID(this.currentRank);
  }






  
  public NUMBER getNUMBER(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getNUMBER(this.currentRank);
  }






  
  public DATE getDATE(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getDATE(this.currentRank);
  }






  
  public INTERVALYM getINTERVALYM(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getINTERVALYM(this.currentRank);
  }






  
  public INTERVALDS getINTERVALDS(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getINTERVALDS(this.currentRank);
  }






  
  public TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getTIMESTAMP(this.currentRank);
  }






  
  public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getTIMESTAMPTZ(this.currentRank);
  }






  
  public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getTIMESTAMPLTZ(this.currentRank);
  }






  
  public REF getREF(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getREF(this.currentRank);
  }






  
  public ARRAY getARRAY(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getARRAY(this.currentRank);
  }






  
  public STRUCT getSTRUCT(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getSTRUCT(this.currentRank);
  }






  
  public OPAQUE getOPAQUE(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getOPAQUE(this.currentRank);
  }






  
  public CHAR getCHAR(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getCHAR(this.currentRank);
  }







  
  public Reader getCharacterStream(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getCharacterStream(this.currentRank);
  }






  
  public RAW getRAW(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getRAW(this.currentRank);
  }







  
  public BLOB getBLOB(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getBLOB(this.currentRank);
  }






  
  public CLOB getCLOB(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getCLOB(this.currentRank);
  }






  
  public BFILE getBFILE(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getBFILE(this.currentRank);
  }






  
  public BFILE getBfile(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getBFILE(this.currentRank);
  }






  
  public boolean getBoolean(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getBoolean(this.currentRank);
  }






  
  public byte getByte(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getByte(this.currentRank);
  }






  
  public short getShort(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getShort(this.currentRank);
  }






  
  public int getInt(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getInt(this.currentRank);
  }






  
  public long getLong(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getLong(this.currentRank);
  }






  
  public float getFloat(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getFloat(this.currentRank);
  }






  
  public double getDouble(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getDouble(this.currentRank);
  }






  
  public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt1 <= 0 || paramInt1 > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt1 - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt1;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt1);
    }
    
    return accessor.getBigDecimal(this.currentRank);
  }






  
  public byte[] getBytes(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getBytes(this.currentRank);
  }






  
  public byte[] privateGetBytes(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.privateGetBytes(this.currentRank);
  }






  
  public Date getDate(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getDate(this.currentRank);
  }






  
  public Time getTime(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getTime(this.currentRank);
  }






  
  public Timestamp getTimestamp(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getTimestamp(this.currentRank);
  }






  
  public InputStream getAsciiStream(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getAsciiStream(this.currentRank);
  }






  
  public InputStream getUnicodeStream(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getUnicodeStream(this.currentRank);
  }






  
  public InputStream getBinaryStream(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getBinaryStream(this.currentRank);
  }






  
  public Object getObject(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getObject(this.currentRank);
  }





  
  public Object getAnyDataEmbeddedObject(int paramInt) throws SQLException {
    Object object1 = null;
    Object object2 = getObject(paramInt);
    if (object2 instanceof ANYDATA) {
      
      Datum datum = ((ANYDATA)object2).accessDatum();
      if (datum != null) object1 = datum.toJdbc(); 
    } 
    return object1;
  }






  
  public Object getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getCustomDatum(this.currentRank, paramCustomDatumFactory);
  }





  
  public Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    return accessor.getObject(this.currentRank, paramOracleDataFactory);
  }






  
  public Object getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getORAData(this.currentRank, paramORADataFactory);
  }






  
  public ResultSet getCursor(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getCursor(this.currentRank);
  }



  
  public void clearParameters() throws SQLException {
    synchronized (this.connection) {

      
      super.clearParameters();
    } 
  }
















  
  public Object getObject(int paramInt, Map paramMap) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getObject(this.currentRank, paramMap);
  }






  
  public Ref getRef(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return (Ref)accessor.getREF(this.currentRank);
  }






  
  public Blob getBlob(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return (Blob)accessor.getBLOB(this.currentRank);
  }






  
  public Clob getClob(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return (Clob)accessor.getCLOB(this.currentRank);
  }






  
  public Array getArray(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return (Array)accessor.getARRAY(this.currentRank);
  }






  
  public BigDecimal getBigDecimal(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getBigDecimal(this.currentRank);
  }






  
  public Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getDate(this.currentRank, paramCalendar);
  }






  
  public Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getTime(this.currentRank, paramCalendar);
  }






  
  public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getTimestamp(this.currentRank, paramCalendar);
  }










































  
  public void addBatch() throws SQLException {
    if (this.currentRowBindAccessors != null) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Stored procedure with out or inout parameters cannot be batched");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    super.addBatch();
  }






  
  protected void alwaysOnClose() throws SQLException {
    this.sqlObject.resetNamedParameters();

    
    this.namedParameters = new String[8];
    this.parameterCount = 0;
    this.atLeastOneOrdinalParameter = false;
    this.atLeastOneNamedParameter = false;
    
    super.alwaysOnClose();
  }

































  
  public void registerOutParameter(String paramString, int paramInt) throws SQLException {
    registerOutParameterInternal(paramString, paramInt, 0, -1, (String)null);
  }





























  
  public void registerOutParameter(String paramString, int paramInt1, int paramInt2) throws SQLException {
    registerOutParameterInternal(paramString, paramInt1, paramInt2, -1, (String)null);
  }









































  
  public void registerOutParameter(String paramString1, int paramInt, String paramString2) throws SQLException {
    registerOutParameterInternal(paramString1, paramInt, 0, -1, paramString2);
  }




  
  void registerOutParameterInternal(String paramString1, int paramInt1, int paramInt2, int paramInt3, String paramString2) throws SQLException {
    int i = addNamedPara(paramString1);
    registerOutParameterInternal(i, paramInt1, paramInt2, paramInt3, paramString2);
  }





















  
  public URL getURL(int paramInt) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Accessor accessor = null;
    if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = paramInt;
    
    if (this.streamList != null) {
      closeUsedStreams(paramInt);
    }
    
    return accessor.getURL(this.currentRank);
  }























  
  public void setStringForClob(String paramString1, String paramString2) throws SQLException {
    int i = addNamedPara(paramString1);
    if (paramString2 == null || paramString2.length() == 0) {
      
      setNull(i, 2005);
      return;
    } 
    setStringForClob(i, paramString2);
  }















  
  public void setStringForClob(int paramInt, String paramString) throws SQLException {
    if (paramString == null || paramString.length() == 0) {
      
      setNull(paramInt, 2005);
      return;
    } 
    synchronized (this.connection) {
      setStringForClobCritical(paramInt, paramString);
    } 
  }




















  
  public void setBytesForBlob(String paramString, byte[] paramArrayOfbyte) throws SQLException {
    int i = addNamedPara(paramString);
    setBytesForBlob(i, paramArrayOfbyte);
  }














  
  public void setBytesForBlob(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
    if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
      
      setNull(paramInt, 2004);
      return;
    } 
    synchronized (this.connection) {
      setBytesForBlobCritical(paramInt, paramArrayOfbyte);
    } 
  }
























  
  public String getString(String paramString) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return accessor.getString(this.currentRank);
  }

















  
  public boolean getBoolean(String paramString) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return accessor.getBoolean(this.currentRank);
  }

















  
  public byte getByte(String paramString) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return accessor.getByte(this.currentRank);
  }

















  
  public short getShort(String paramString) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return accessor.getShort(this.currentRank);
  }


















  
  public int getInt(String paramString) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return accessor.getInt(this.currentRank);
  }


















  
  public long getLong(String paramString) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return accessor.getLong(this.currentRank);
  }

















  
  public float getFloat(String paramString) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return accessor.getFloat(this.currentRank);
  }

















  
  public double getDouble(String paramString) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return accessor.getDouble(this.currentRank);
  }


















  
  public byte[] getBytes(String paramString) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return accessor.getBytes(this.currentRank);
  }

















  
  public Date getDate(String paramString) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return accessor.getDate(this.currentRank);
  }

















  
  public Time getTime(String paramString) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return accessor.getTime(this.currentRank);
  }

















  
  public Timestamp getTimestamp(String paramString) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return accessor.getTimestamp(this.currentRank);
  }
























  
  public Object getObject(String paramString) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return accessor.getObject(this.currentRank);
  }


















  
  public BigDecimal getBigDecimal(String paramString) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return accessor.getBigDecimal(this.currentRank);
  }





  
  public BigDecimal getBigDecimal(String paramString, int paramInt) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return accessor.getBigDecimal(this.currentRank, paramInt);
  }
























  
  public Object getObject(String paramString, Map paramMap) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return accessor.getObject(this.currentRank, paramMap);
  }


















  
  public Ref getRef(String paramString) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return (Ref)accessor.getREF(this.currentRank);
  }


















  
  public Blob getBlob(String paramString) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return (Blob)accessor.getBLOB(this.currentRank);
  }

















  
  public Clob getClob(String paramString) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return (Clob)accessor.getCLOB(this.currentRank);
  }


















  
  public Array getArray(String paramString) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return (Array)accessor.getARRAY(this.currentRank);
  }


























  
  public Date getDate(String paramString, Calendar paramCalendar) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return accessor.getDate(this.currentRank, paramCalendar);
  }


























  
  public Time getTime(String paramString, Calendar paramCalendar) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return accessor.getTime(this.currentRank, paramCalendar);
  }



























  
  public Timestamp getTimestamp(String paramString, Calendar paramCalendar) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return accessor.getTimestamp(this.currentRank, paramCalendar);
  }




















  
  public URL getURL(String paramString) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return accessor.getURL(this.currentRank);
  }






  
  public InputStream getAsciiStream(String paramString) throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }



































  
  public void registerIndexTableOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
    synchronized (this.connection) {

      
      int i = paramInt1 - 1;
      if (i < 0 || paramInt1 > this.numberOfBindPositions) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      int j = getInternalType(paramInt3);
      
      resetBatch();
      this.currentRowNeedToPrepareBinds = true;
      
      if (this.currentRowBindAccessors == null) {
        this.currentRowBindAccessors = new Accessor[this.numberOfBindPositions];
      }
      this.currentRowBindAccessors[i] = allocateIndexTableAccessor(paramInt3, j, paramInt4, paramInt2, this.currentRowFormOfUse[i], true);






      
      this.hasIbtBind = true;
    } 
  }












  
  PlsqlIndexTableAccessor allocateIndexTableAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, boolean paramBoolean) throws SQLException {
    return new PlsqlIndexTableAccessor(this, paramInt1, paramInt2, paramInt3, paramInt4, paramShort, paramBoolean);
  }




















  
  public Object getPlsqlIndexTable(int paramInt) throws SQLException {
    synchronized (this.connection) {
      BigDecimal[] arrayOfBigDecimal;
      SQLException sQLException;
      Datum[] arrayOfDatum = getOraclePlsqlIndexTable(paramInt);
      
      PlsqlIndexTableAccessor plsqlIndexTableAccessor = (PlsqlIndexTableAccessor)this.outBindAccessors[paramInt - 1];

      
      int i = plsqlIndexTableAccessor.elementInternalType;
      
      String[] arrayOfString = null;
      
      switch (i) {
        
        case 9:
          arrayOfString = new String[arrayOfDatum.length];
          break;
        case 6:
          arrayOfBigDecimal = new BigDecimal[arrayOfDatum.length];
          break;
        
        default:
          sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid column type");
          sQLException.fillInStackTrace();
          throw sQLException;
      } 

      
      for (byte b = 0; b < arrayOfBigDecimal.length; b++) {
        arrayOfBigDecimal[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? (BigDecimal)arrayOfDatum[b].toJdbc() : null;
      }


      
      return arrayOfBigDecimal;
    } 
  }















  
  public Object getPlsqlIndexTable(int paramInt, Class paramClass) throws SQLException {
    synchronized (this.connection) {
      
      Datum[] arrayOfDatum = getOraclePlsqlIndexTable(paramInt);
      
      if (paramClass == null || !paramClass.isPrimitive()) {
        
        SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
        sQLException1.fillInStackTrace();
        throw sQLException1;
      } 
      
      String str = paramClass.getName();
      
      if (str.equals("byte")) {
        
        byte[] arrayOfByte = new byte[arrayOfDatum.length];
        for (byte b = 0; b < arrayOfDatum.length; b++)
          arrayOfByte[b] = (arrayOfDatum[b] != null) ? arrayOfDatum[b].byteValue() : 0; 
        return arrayOfByte;
      } 
      if (str.equals("char")) {
        
        char[] arrayOfChar = new char[arrayOfDatum.length];
        for (byte b = 0; b < arrayOfDatum.length; b++) {
          arrayOfChar[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? (char)arrayOfDatum[b].intValue() : Character.MIN_VALUE;
        }
        return arrayOfChar;
      } 
      if (str.equals("double")) {
        
        double[] arrayOfDouble = new double[arrayOfDatum.length];
        for (byte b = 0; b < arrayOfDatum.length; b++) {
          arrayOfDouble[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? arrayOfDatum[b].doubleValue() : 0.0D;
        }
        return arrayOfDouble;
      } 
      if (str.equals("float")) {
        
        float[] arrayOfFloat = new float[arrayOfDatum.length];
        for (byte b = 0; b < arrayOfDatum.length; b++) {
          arrayOfFloat[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? arrayOfDatum[b].floatValue() : 0.0F;
        }
        return arrayOfFloat;
      } 
      if (str.equals("int")) {
        
        int[] arrayOfInt = new int[arrayOfDatum.length];
        for (byte b = 0; b < arrayOfDatum.length; b++) {
          arrayOfInt[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? arrayOfDatum[b].intValue() : 0;
        }
        return arrayOfInt;
      } 
      if (str.equals("long")) {
        
        long[] arrayOfLong = new long[arrayOfDatum.length];
        for (byte b = 0; b < arrayOfDatum.length; b++) {
          arrayOfLong[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? arrayOfDatum[b].longValue() : 0L;
        }
        return arrayOfLong;
      } 
      if (str.equals("short")) {
        
        short[] arrayOfShort = new short[arrayOfDatum.length];
        for (byte b = 0; b < arrayOfDatum.length; b++) {
          arrayOfShort[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? (short)arrayOfDatum[b].intValue() : 0;
        }
        return arrayOfShort;
      } 
      if (str.equals("boolean")) {
        
        boolean[] arrayOfBoolean = new boolean[arrayOfDatum.length];
        for (byte b = 0; b < arrayOfDatum.length; b++) {
          arrayOfBoolean[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? arrayOfDatum[b].booleanValue() : false;
        }
        return arrayOfBoolean;
      } 

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }













  
  public Datum[] getOraclePlsqlIndexTable(int paramInt) throws SQLException {
    synchronized (this.connection) {


      
      if (this.closed) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      if (this.atLeastOneNamedParameter) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      Accessor accessor = null;
      if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {



        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      this.lastIndex = paramInt;
      
      if (this.streamList != null) {
        closeUsedStreams(paramInt);
      }
      
      return accessor.getOraclePlsqlIndexTable(this.currentRank);
    } 
  }










  
  public boolean execute() throws SQLException {
    synchronized (this.connection) {
      ensureOpen();
      if (this.atLeastOneNamedParameter && this.atLeastOneOrdinalParameter) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      if (this.sqlObject.setNamedParameters(this.parameterCount, this.namedParameters))
        this.needToParse = true; 
      return super.execute();
    } 
  }









  
  public int executeUpdate() throws SQLException {
    synchronized (this.connection) {
      
      ensureOpen();
      if (this.atLeastOneNamedParameter && this.atLeastOneOrdinalParameter) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      if (this.sqlObject.setNamedParameters(this.parameterCount, this.namedParameters))
        this.needToParse = true; 
      return super.executeUpdate();
    } 
  }


  
  void releaseBuffers() {
    if (this.outBindAccessors != null) {
      
      int i = this.outBindAccessors.length;
      
      for (byte b = 0; b < i; b++) {
        
        if (this.outBindAccessors[b] != null) {
          
          (this.outBindAccessors[b]).rowSpaceByte = null;
          (this.outBindAccessors[b]).rowSpaceChar = null;
        } 
      } 
    } 
    
    super.releaseBuffers();
  }



  
  void doLocalInitialization() {
    if (this.outBindAccessors != null) {
      
      int i = this.outBindAccessors.length;
      
      for (byte b = 0; b < i; b++) {
        
        if (this.outBindAccessors[b] != null) {
          
          (this.outBindAccessors[b]).rowSpaceByte = this.bindBytes;
          (this.outBindAccessors[b]).rowSpaceChar = this.bindChars;
        } 
      } 
    } 
  }








  
  public void setArray(int paramInt, Array paramArray) throws SQLException {
    this.atLeastOneOrdinalParameter = true;
    setArrayInternal(paramInt, paramArray);
  }



  
  public void setBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setBigDecimalInternal(paramInt, paramBigDecimal);
    } 
  }



  
  public void setBlob(int paramInt, Blob paramBlob) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setBlobInternal(paramInt, paramBlob);
    } 
  }



  
  public void setBoolean(int paramInt, boolean paramBoolean) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setBooleanInternal(paramInt, paramBoolean);
    } 
  }



  
  public void setByte(int paramInt, byte paramByte) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setByteInternal(paramInt, paramByte);
    } 
  }



  
  public void setBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setBytesInternal(paramInt, paramArrayOfbyte);
    } 
  }



  
  public void setClob(int paramInt, Clob paramClob) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setClobInternal(paramInt, paramClob);
    } 
  }



  
  public void setDate(int paramInt, Date paramDate) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setDateInternal(paramInt, paramDate);
    } 
  }



  
  public void setDate(int paramInt, Date paramDate, Calendar paramCalendar) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setDateInternal(paramInt, paramDate, paramCalendar);
    } 
  }



  
  public void setDouble(int paramInt, double paramDouble) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setDoubleInternal(paramInt, paramDouble);
    } 
  }



  
  public void setFloat(int paramInt, float paramFloat) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setFloatInternal(paramInt, paramFloat);
    } 
  }



  
  public void setInt(int paramInt1, int paramInt2) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setIntInternal(paramInt1, paramInt2);
    } 
  }



  
  public void setLong(int paramInt, long paramLong) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setLongInternal(paramInt, paramLong);
    } 
  }




  
  public void setObject(int paramInt, Object paramObject) throws SQLException {
    this.atLeastOneOrdinalParameter = true;
    setObjectInternal(paramInt, paramObject);
  }




  
  public void setObject(int paramInt1, Object paramObject, int paramInt2) throws SQLException {
    this.atLeastOneOrdinalParameter = true;
    setObjectInternal(paramInt1, paramObject, paramInt2);
  }




  
  public void setRef(int paramInt, Ref paramRef) throws SQLException {
    this.atLeastOneOrdinalParameter = true;
    setRefInternal(paramInt, paramRef);
  }



  
  public void setShort(int paramInt, short paramShort) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setShortInternal(paramInt, paramShort);
    } 
  }



  
  public void setString(int paramInt, String paramString) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setStringInternal(paramInt, paramString);
    } 
  }



  
  public void setTime(int paramInt, Time paramTime) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setTimeInternal(paramInt, paramTime);
    } 
  }



  
  public void setTime(int paramInt, Time paramTime, Calendar paramCalendar) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setTimeInternal(paramInt, paramTime, paramCalendar);
    } 
  }



  
  public void setTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setTimestampInternal(paramInt, paramTimestamp);
    } 
  }



  
  public void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setTimestampInternal(paramInt, paramTimestamp, paramCalendar);
    } 
  }



  
  public void setURL(int paramInt, URL paramURL) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setURLInternal(paramInt, paramURL);
    } 
  }




  
  public void setARRAY(int paramInt, ARRAY paramARRAY) throws SQLException {
    this.atLeastOneOrdinalParameter = true;
    setARRAYInternal(paramInt, paramARRAY);
  }



  
  public void setBFILE(int paramInt, BFILE paramBFILE) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setBFILEInternal(paramInt, paramBFILE);
    } 
  }



  
  public void setBfile(int paramInt, BFILE paramBFILE) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setBfileInternal(paramInt, paramBFILE);
    } 
  }



  
  public void setBinaryFloat(int paramInt, float paramFloat) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setBinaryFloatInternal(paramInt, paramFloat);
    } 
  }



  
  public void setBinaryFloat(int paramInt, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setBinaryFloatInternal(paramInt, paramBINARY_FLOAT);
    } 
  }



  
  public void setBinaryDouble(int paramInt, double paramDouble) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setBinaryDoubleInternal(paramInt, paramDouble);
    } 
  }



  
  public void setBinaryDouble(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setBinaryDoubleInternal(paramInt, paramBINARY_DOUBLE);
    } 
  }



  
  public void setBLOB(int paramInt, BLOB paramBLOB) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setBLOBInternal(paramInt, paramBLOB);
    } 
  }



  
  public void setCHAR(int paramInt, CHAR paramCHAR) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setCHARInternal(paramInt, paramCHAR);
    } 
  }



  
  public void setCLOB(int paramInt, CLOB paramCLOB) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setCLOBInternal(paramInt, paramCLOB);
    } 
  }



  
  public void setCursor(int paramInt, ResultSet paramResultSet) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setCursorInternal(paramInt, paramResultSet);
    } 
  }




  
  public void setCustomDatum(int paramInt, CustomDatum paramCustomDatum) throws SQLException {
    this.atLeastOneOrdinalParameter = true;
    setCustomDatumInternal(paramInt, paramCustomDatum);
  }



  
  public void setDATE(int paramInt, DATE paramDATE) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setDATEInternal(paramInt, paramDATE);
    } 
  }



  
  public void setFixedCHAR(int paramInt, String paramString) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setFixedCHARInternal(paramInt, paramString);
    } 
  }



  
  public void setINTERVALDS(int paramInt, INTERVALDS paramINTERVALDS) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setINTERVALDSInternal(paramInt, paramINTERVALDS);
    } 
  }



  
  public void setINTERVALYM(int paramInt, INTERVALYM paramINTERVALYM) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setINTERVALYMInternal(paramInt, paramINTERVALYM);
    } 
  }



  
  public void setNUMBER(int paramInt, NUMBER paramNUMBER) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setNUMBERInternal(paramInt, paramNUMBER);
    } 
  }




  
  public void setOPAQUE(int paramInt, OPAQUE paramOPAQUE) throws SQLException {
    this.atLeastOneOrdinalParameter = true;
    setOPAQUEInternal(paramInt, paramOPAQUE);
  }




  
  public void setOracleObject(int paramInt, Datum paramDatum) throws SQLException {
    this.atLeastOneOrdinalParameter = true;
    setOracleObjectInternal(paramInt, paramDatum);
  }




  
  public void setORAData(int paramInt, ORAData paramORAData) throws SQLException {
    this.atLeastOneOrdinalParameter = true;
    setORADataInternal(paramInt, paramORAData);
  }



  
  public void setRAW(int paramInt, RAW paramRAW) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setRAWInternal(paramInt, paramRAW);
    } 
  }




  
  public void setREF(int paramInt, REF paramREF) throws SQLException {
    this.atLeastOneOrdinalParameter = true;
    setREFInternal(paramInt, paramREF);
  }




  
  public void setRefType(int paramInt, REF paramREF) throws SQLException {
    this.atLeastOneOrdinalParameter = true;
    setRefTypeInternal(paramInt, paramREF);
  }



  
  public void setROWID(int paramInt, ROWID paramROWID) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setROWIDInternal(paramInt, paramROWID);
    } 
  }




  
  public void setSTRUCT(int paramInt, STRUCT paramSTRUCT) throws SQLException {
    this.atLeastOneOrdinalParameter = true;
    setSTRUCTInternal(paramInt, paramSTRUCT);
  }



  
  public void setTIMESTAMPLTZ(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setTIMESTAMPLTZInternal(paramInt, paramTIMESTAMPLTZ);
    } 
  }



  
  public void setTIMESTAMPTZ(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setTIMESTAMPTZInternal(paramInt, paramTIMESTAMPTZ);
    } 
  }



  
  public void setTIMESTAMP(int paramInt, TIMESTAMP paramTIMESTAMP) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setTIMESTAMPInternal(paramInt, paramTIMESTAMP);
    } 
  }



  
  public void setAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setAsciiStreamInternal(paramInt1, paramInputStream, paramInt2);
    } 
  }



  
  public void setBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setBinaryStreamInternal(paramInt1, paramInputStream, paramInt2);
    } 
  }



  
  public void setCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setCharacterStreamInternal(paramInt1, paramReader, paramInt2);
    } 
  }



  
  public void setUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
    synchronized (this.connection) {


      
      this.atLeastOneOrdinalParameter = true;
      setUnicodeStreamInternal(paramInt1, paramInputStream, paramInt2);
    } 
  }







  
  public void setArray(String paramString, Array paramArray) throws SQLException {
    int i = addNamedPara(paramString);
    setArrayInternal(i, paramArray);
  }






  
  public void setBigDecimal(String paramString, BigDecimal paramBigDecimal) throws SQLException {
    int i = addNamedPara(paramString);
    setBigDecimalInternal(i, paramBigDecimal);
  }






  
  public void setBlob(String paramString, Blob paramBlob) throws SQLException {
    int i = addNamedPara(paramString);
    setBlobInternal(i, paramBlob);
  }






  
  public void setBoolean(String paramString, boolean paramBoolean) throws SQLException {
    int i = addNamedPara(paramString);
    setBooleanInternal(i, paramBoolean);
  }






  
  public void setByte(String paramString, byte paramByte) throws SQLException {
    int i = addNamedPara(paramString);
    setByteInternal(i, paramByte);
  }






  
  public void setBytes(String paramString, byte[] paramArrayOfbyte) throws SQLException {
    int i = addNamedPara(paramString);
    setBytesInternal(i, paramArrayOfbyte);
  }






  
  public void setClob(String paramString, Clob paramClob) throws SQLException {
    int i = addNamedPara(paramString);
    setClobInternal(i, paramClob);
  }






  
  public void setDate(String paramString, Date paramDate) throws SQLException {
    int i = addNamedPara(paramString);
    setDateInternal(i, paramDate);
  }






  
  public void setDate(String paramString, Date paramDate, Calendar paramCalendar) throws SQLException {
    int i = addNamedPara(paramString);
    setDateInternal(i, paramDate, paramCalendar);
  }






  
  public void setDouble(String paramString, double paramDouble) throws SQLException {
    int i = addNamedPara(paramString);
    setDoubleInternal(i, paramDouble);
  }






  
  public void setFloat(String paramString, float paramFloat) throws SQLException {
    int i = addNamedPara(paramString);
    setFloatInternal(i, paramFloat);
  }






  
  public void setInt(String paramString, int paramInt) throws SQLException {
    int i = addNamedPara(paramString);
    setIntInternal(i, paramInt);
  }






  
  public void setLong(String paramString, long paramLong) throws SQLException {
    int i = addNamedPara(paramString);
    setLongInternal(i, paramLong);
  }






  
  public void setObject(String paramString, Object paramObject) throws SQLException {
    int i = addNamedPara(paramString);
    setObjectInternal(i, paramObject);
  }






  
  public void setObject(String paramString, Object paramObject, int paramInt) throws SQLException {
    int i = addNamedPara(paramString);
    setObjectInternal(i, paramObject, paramInt);
  }






  
  public void setRef(String paramString, Ref paramRef) throws SQLException {
    int i = addNamedPara(paramString);
    setRefInternal(i, paramRef);
  }






  
  public void setShort(String paramString, short paramShort) throws SQLException {
    int i = addNamedPara(paramString);
    setShortInternal(i, paramShort);
  }






  
  public void setString(String paramString1, String paramString2) throws SQLException {
    int i = addNamedPara(paramString1);
    setStringInternal(i, paramString2);
  }






  
  public void setTime(String paramString, Time paramTime) throws SQLException {
    int i = addNamedPara(paramString);
    setTimeInternal(i, paramTime);
  }






  
  public void setTime(String paramString, Time paramTime, Calendar paramCalendar) throws SQLException {
    int i = addNamedPara(paramString);
    setTimeInternal(i, paramTime, paramCalendar);
  }






  
  public void setTimestamp(String paramString, Timestamp paramTimestamp) throws SQLException {
    int i = addNamedPara(paramString);
    setTimestampInternal(i, paramTimestamp);
  }






  
  public void setTimestamp(String paramString, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
    int i = addNamedPara(paramString);
    setTimestampInternal(i, paramTimestamp, paramCalendar);
  }






  
  public void setURL(String paramString, URL paramURL) throws SQLException {
    int i = addNamedPara(paramString);
    setURLInternal(i, paramURL);
  }






  
  public void setARRAY(String paramString, ARRAY paramARRAY) throws SQLException {
    int i = addNamedPara(paramString);
    setARRAYInternal(i, paramARRAY);
  }






  
  public void setBFILE(String paramString, BFILE paramBFILE) throws SQLException {
    int i = addNamedPara(paramString);
    setBFILEInternal(i, paramBFILE);
  }






  
  public void setBfile(String paramString, BFILE paramBFILE) throws SQLException {
    int i = addNamedPara(paramString);
    setBfileInternal(i, paramBFILE);
  }






  
  public void setBinaryFloat(String paramString, float paramFloat) throws SQLException {
    int i = addNamedPara(paramString);
    setBinaryFloatInternal(i, paramFloat);
  }






  
  public void setBinaryFloat(String paramString, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
    int i = addNamedPara(paramString);
    setBinaryFloatInternal(i, paramBINARY_FLOAT);
  }






  
  public void setBinaryDouble(String paramString, double paramDouble) throws SQLException {
    int i = addNamedPara(paramString);
    setBinaryDoubleInternal(i, paramDouble);
  }






  
  public void setBinaryDouble(String paramString, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
    int i = addNamedPara(paramString);
    setBinaryDoubleInternal(i, paramBINARY_DOUBLE);
  }






  
  public void setBLOB(String paramString, BLOB paramBLOB) throws SQLException {
    int i = addNamedPara(paramString);
    setBLOBInternal(i, paramBLOB);
  }






  
  public void setCHAR(String paramString, CHAR paramCHAR) throws SQLException {
    int i = addNamedPara(paramString);
    setCHARInternal(i, paramCHAR);
  }






  
  public void setCLOB(String paramString, CLOB paramCLOB) throws SQLException {
    int i = addNamedPara(paramString);
    setCLOBInternal(i, paramCLOB);
  }






  
  public void setCursor(String paramString, ResultSet paramResultSet) throws SQLException {
    int i = addNamedPara(paramString);
    setCursorInternal(i, paramResultSet);
  }






  
  public void setCustomDatum(String paramString, CustomDatum paramCustomDatum) throws SQLException {
    int i = addNamedPara(paramString);
    setCustomDatumInternal(i, paramCustomDatum);
  }






  
  public void setDATE(String paramString, DATE paramDATE) throws SQLException {
    int i = addNamedPara(paramString);
    setDATEInternal(i, paramDATE);
  }






  
  public void setFixedCHAR(String paramString1, String paramString2) throws SQLException {
    int i = addNamedPara(paramString1);
    setFixedCHARInternal(i, paramString2);
  }






  
  public void setINTERVALDS(String paramString, INTERVALDS paramINTERVALDS) throws SQLException {
    int i = addNamedPara(paramString);
    setINTERVALDSInternal(i, paramINTERVALDS);
  }






  
  public void setINTERVALYM(String paramString, INTERVALYM paramINTERVALYM) throws SQLException {
    int i = addNamedPara(paramString);
    setINTERVALYMInternal(i, paramINTERVALYM);
  }






  
  public void setNUMBER(String paramString, NUMBER paramNUMBER) throws SQLException {
    int i = addNamedPara(paramString);
    setNUMBERInternal(i, paramNUMBER);
  }






  
  public void setOPAQUE(String paramString, OPAQUE paramOPAQUE) throws SQLException {
    int i = addNamedPara(paramString);
    setOPAQUEInternal(i, paramOPAQUE);
  }






  
  public void setOracleObject(String paramString, Datum paramDatum) throws SQLException {
    int i = addNamedPara(paramString);
    setOracleObjectInternal(i, paramDatum);
  }






  
  public void setORAData(String paramString, ORAData paramORAData) throws SQLException {
    int i = addNamedPara(paramString);
    setORADataInternal(i, paramORAData);
  }






  
  public void setRAW(String paramString, RAW paramRAW) throws SQLException {
    int i = addNamedPara(paramString);
    setRAWInternal(i, paramRAW);
  }






  
  public void setREF(String paramString, REF paramREF) throws SQLException {
    int i = addNamedPara(paramString);
    setREFInternal(i, paramREF);
  }






  
  public void setRefType(String paramString, REF paramREF) throws SQLException {
    int i = addNamedPara(paramString);
    setRefTypeInternal(i, paramREF);
  }






  
  public void setROWID(String paramString, ROWID paramROWID) throws SQLException {
    int i = addNamedPara(paramString);
    setROWIDInternal(i, paramROWID);
  }






  
  public void setSTRUCT(String paramString, STRUCT paramSTRUCT) throws SQLException {
    int i = addNamedPara(paramString);
    setSTRUCTInternal(i, paramSTRUCT);
  }






  
  public void setTIMESTAMPLTZ(String paramString, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
    int i = addNamedPara(paramString);
    setTIMESTAMPLTZInternal(i, paramTIMESTAMPLTZ);
  }






  
  public void setTIMESTAMPTZ(String paramString, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
    int i = addNamedPara(paramString);
    setTIMESTAMPTZInternal(i, paramTIMESTAMPTZ);
  }






  
  public void setTIMESTAMP(String paramString, TIMESTAMP paramTIMESTAMP) throws SQLException {
    int i = addNamedPara(paramString);
    setTIMESTAMPInternal(i, paramTIMESTAMP);
  }






  
  public void setAsciiStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
    int i = addNamedPara(paramString);
    setAsciiStreamInternal(i, paramInputStream, paramInt);
  }






  
  public void setBinaryStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
    int i = addNamedPara(paramString);
    setBinaryStreamInternal(i, paramInputStream, paramInt);
  }






  
  public void setCharacterStream(String paramString, Reader paramReader, int paramInt) throws SQLException {
    int i = addNamedPara(paramString);
    setCharacterStreamInternal(i, paramReader, paramInt);
  }






  
  public void setUnicodeStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
    int i = addNamedPara(paramString);
    setUnicodeStreamInternal(i, paramInputStream, paramInt);
  }







  
  public void setNull(String paramString1, int paramInt, String paramString2) throws SQLException {
    int i = addNamedPara(paramString1);
    setNullInternal(i, paramInt, paramString2);
  }







  
  public void setNull(String paramString, int paramInt) throws SQLException {
    int i = addNamedPara(paramString);
    setNullInternal(i, paramInt);
  }





  
  public void setStructDescriptor(String paramString, StructDescriptor paramStructDescriptor) throws SQLException {
    int i = addNamedPara(paramString);
    setStructDescriptorInternal(i, paramStructDescriptor);
  }







  
  public void setObject(String paramString, Object paramObject, int paramInt1, int paramInt2) throws SQLException {
    int i = addNamedPara(paramString);
    setObjectInternal(i, paramObject, paramInt1, paramInt2);
  }








  
  public void setPlsqlIndexTable(int paramInt1, Object paramObject, int paramInt2, int paramInt3, int paramInt4, int paramInt5) throws SQLException {
    synchronized (this.connection) {
      
      this.atLeastOneOrdinalParameter = true;
      setPlsqlIndexTableInternal(paramInt1, paramObject, paramInt2, paramInt3, paramInt4, paramInt5);
    } 
  }













  
  int addNamedPara(String paramString) throws SQLException {
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    String str = paramString.toUpperCase().intern();
    
    for (byte b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b]) {
        return b + 1;
      }
    } 
    if (this.parameterCount >= this.namedParameters.length) {
      
      String[] arrayOfString = new String[this.namedParameters.length * 2];
      System.arraycopy(this.namedParameters, 0, arrayOfString, 0, this.namedParameters.length);
      this.namedParameters = arrayOfString;
    } 
    
    this.namedParameters[this.parameterCount++] = str;
    
    this.atLeastOneNamedParameter = true;
    return this.parameterCount;
  }






  
  public Reader getCharacterStream(String paramString) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return accessor.getCharacterStream(this.currentRank);
  }




  
  public InputStream getUnicodeStream(String paramString) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return accessor.getUnicodeStream(this.currentRank);
  }




  
  public InputStream getBinaryStream(String paramString) throws SQLException {
    if (!this.atLeastOneNamedParameter) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str = paramString.toUpperCase().intern();
    
    byte b;
    for (b = 0; b < this.parameterCount; b++) {
      
      if (str == this.namedParameters[b])
        break; 
    } 
    b++;
    
    Accessor accessor = null;
    if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.lastIndex = b;
    
    if (this.streamList != null) {
      closeUsedStreams(b);
    }
    
    return accessor.getBinaryStream(this.currentRank);
  }






  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
