package oracle.jdbc.driver;

import oracle.jdbc.OracleResultSet;
import oracle.sql.Datum;




































class CachedRowElement
{
  private final int row;
  private final int col;
  private final OracleResultSet.AuthorizationIndicator securityIndicator;
  private final byte[] data;
  private Datum dataAsDatum;
  
  CachedRowElement(int paramInt1, int paramInt2, OracleResultSet.AuthorizationIndicator paramAuthorizationIndicator, byte[] paramArrayOfbyte) {
    this.row = paramInt1;
    this.col = paramInt2;
    this.securityIndicator = paramAuthorizationIndicator;
    this.data = paramArrayOfbyte;
    this.dataAsDatum = null;
  }



  
  OracleResultSet.AuthorizationIndicator getIndicator() {
    return this.securityIndicator;
  }



  
  void setData(Datum paramDatum) {
    this.dataAsDatum = paramDatum;
  }


  
  byte[] getData() {
    return this.data;
  }


  
  Datum getDataAsDatum() {
    return this.dataAsDatum;
  }

  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
