package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.KeywordValueLong;
import oracle.jdbc.internal.XSEvent;


































class NTFXSEvent
  extends XSEvent
{
  private final byte[] sid_kpuzxsss;
  private final KeywordValueLongI[] sess_kpuzxsss;
  private final int flg_kpuzxsss;
  
  NTFXSEvent(T4CConnection paramT4CConnection) throws SQLException, IOException {
    super(paramT4CConnection);












    
    T4CMAREngine t4CMAREngine = paramT4CConnection.getMarshalEngine();
    
    this.sid_kpuzxsss = t4CMAREngine.unmarshalDALC();
    int i = (int)t4CMAREngine.unmarshalUB4();
    byte b = (byte)t4CMAREngine.unmarshalUB1();
    this.sess_kpuzxsss = new KeywordValueLongI[i];
    for (byte b1 = 0; b1 < i; b1++)
    {
      this.sess_kpuzxsss[b1] = KeywordValueLongI.unmarshal(t4CMAREngine);
    }
    this.flg_kpuzxsss = (int)t4CMAREngine.unmarshalUB4();
  }


  
  public byte[] getSessionId() {
    return this.sid_kpuzxsss;
  }



  
  public KeywordValueLong[] getDetails() {
    return (KeywordValueLong[])this.sess_kpuzxsss;
  }



  
  public int getFlags() {
    return this.flg_kpuzxsss;
  }



  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("sid_kpuzxsss  : " + NTFAQEvent.byteBufferToHexString(this.sid_kpuzxsss, 50) + "\n");
    stringBuffer.append("sess_kpuzxsss : \n");
    stringBuffer.append("  size : " + this.sess_kpuzxsss.length + "\n");
    for (byte b = 0; b < this.sess_kpuzxsss.length; b++) {
      
      stringBuffer.append("  sess_kpuzxsss #" + b + " : \n");
      if (this.sess_kpuzxsss[b] == null) {
        stringBuffer.append("null\n");
      } else {
        stringBuffer.append(this.sess_kpuzxsss[b].toString());
      } 
    }  stringBuffer.append("flg_kpuzxsss  : " + this.flg_kpuzxsss + "\n");
    return stringBuffer.toString();
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
