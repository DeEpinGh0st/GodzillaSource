package oracle.jdbc.internal;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.sql.SQLException;
import oracle.jdbc.OracleCallableStatement;

public interface OracleCallableStatement extends OracleCallableStatement, OraclePreparedStatement {
  byte[] privateGetBytes(int paramInt) throws SQLException;
  
  BigDecimal getBigDecimal(String paramString, int paramInt) throws SQLException;
  
  InputStream getAsciiStream(String paramString) throws SQLException;
  
  Reader getCharacterStream(String paramString) throws SQLException;
}
