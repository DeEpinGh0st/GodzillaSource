package oracle.jdbc.driver;



















class ByteArrayKey
{
  private byte[] theBytes;
  private int cachedHashCode = -1;

  
  public ByteArrayKey(byte[] paramArrayOfbyte) {
    this.theBytes = paramArrayOfbyte;
    for (byte b : this.theBytes) {
      this.cachedHashCode = this.cachedHashCode << 1 & ((this.cachedHashCode < 0) ? 1 : 0) ^ b;
    }
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this) {
      return true;
    }
    if (!(paramObject instanceof ByteArrayKey))
    {
      
      return false;
    }
    
    byte[] arrayOfByte = ((ByteArrayKey)paramObject).theBytes;
    
    if (this.theBytes.length != arrayOfByte.length) {
      return false;
    }
    for (byte b = 0; b < this.theBytes.length; b++) {
      if (this.theBytes[b] != arrayOfByte[b])
        return false; 
    } 
    return true;
  }

  
  public int hashCode() {
    return this.cachedHashCode;
  }

  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
