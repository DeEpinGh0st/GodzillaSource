package oracle.jdbc.xa.client;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import javax.transaction.xa.XAException;
import javax.transaction.xa.Xid;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.oracore.Util;
import oracle.jdbc.xa.OracleXAConnection;
import oracle.jdbc.xa.OracleXAException;
import oracle.jdbc.xa.OracleXAResource;


















public class OracleXAResource
  extends OracleXAResource
{
  private short m_version = 0;

  
  private boolean needStackingForCommitRollbackPrepare = false;

  
  private static String xa_start_816 = "begin ? := JAVA_XA.xa_start(?,?,?,?); end;";
  
  private static String xa_start_post_816 = "begin ? := JAVA_XA.xa_start_new(?,?,?,?,?); end;";


  
  private static String xa_end_816 = "begin ? := JAVA_XA.xa_end(?,?); end;";
  private static String xa_end_post_816 = "begin ? := JAVA_XA.xa_end_new(?,?,?,?); end;";

  
  private static String xa_commit_816 = "begin ? := JAVA_XA.xa_commit (?,?,?); end;";
  
  private static String xa_commit_post_816 = "begin ? := JAVA_XA.xa_commit_new (?,?,?,?); end;";

  
  private static String xa_prepare_816 = "begin ? := JAVA_XA.xa_prepare (?,?); end;";
  
  private static String xa_prepare_post_816 = "begin ? := JAVA_XA.xa_prepare_new (?,?,?); end;";

  
  private static String xa_rollback_816 = "begin ? := JAVA_XA.xa_rollback (?,?); end;";
  
  private static String xa_rollback_post_816 = "begin ? := JAVA_XA.xa_rollback_new (?,?,?); end;";

  
  private static String xa_forget_816 = "begin ? := JAVA_XA.xa_forget (?,?); end;";
  
  private static String xa_forget_post_816 = "begin ? := JAVA_XA.xa_forget_new (?,?,?); end;";





  
  boolean isTransLoose = false;






  
  public OracleXAResource() {}






  
  public OracleXAResource(Connection paramConnection, OracleXAConnection paramOracleXAConnection) throws XAException {
    super(paramConnection, paramOracleXAConnection);



    
    try {
      this.m_version = ((OracleConnection)paramConnection).getVersionNumber();
      this.needStackingForCommitRollbackPrepare = (this.m_version < 9000);
    }
    catch (SQLException sQLException) {}



    
    if (this.m_version < 8170)
    {



      
      throw new XAException(-6);
    }
  }

































  
  public void start(Xid paramXid, int paramInt) throws XAException {
    synchronized (this.connection) {



      
      int i = -1;




      
      try {
        if (paramXid == null)
        {

          
          throw new XAException(-5);
        }

        
        int j = paramInt & 0xFF00;
        
        paramInt &= 0xFFFF00FF;
        
        int k = paramInt & 0x10000 | (this.isTransLoose ? 65536 : 0);
        
        paramInt &= 0xFFFEFFFF;





        
        if ((paramInt & 0x8200002) != paramInt || (k != 0 && (k & 0x10000) != 65536))
        {



          
          throw new XAException(-5);
        }








        
        if ((j & 0xFF00) != 0 && j != 256 && j != 512 && j != 1024)
        {


          
          throw new XAException(-5);
        }


        
        if ((paramInt & 0x8200000) != 0 && ((j & 0xFF00) != 0 || (k & 0x10000) != 0))
        {



          
          throw new XAException(-5);
        }

        
        paramInt |= j | k;
        
        saveAndAlterAutoCommitModeForGlobalTransaction();



        
        try {
          i = doStart(paramXid, paramInt);
        }
        catch (SQLException sQLException) {

          
          checkError(sQLException, -3);
        } 




        
        checkError(i);


        
        boolean[] arrayOfBoolean = { false };
        createOrUpdateXid(paramXid, false, arrayOfBoolean);

      
      }
      catch (XAException xAException) {
        
        restoreAutoCommitModeForGlobalTransaction();
        
        throw xAException;
      } 
    } 
  }






  
  protected int doStart(Xid paramXid, int paramInt) throws XAException, SQLException {
    int i = -1;
    CallableStatement callableStatement = null;

    
    try {
      callableStatement = this.connection.prepareCall(xa_start_post_816);
      
      callableStatement.registerOutParameter(1, 2);
      callableStatement.setInt(2, paramXid.getFormatId());
      callableStatement.setBytes(3, paramXid.getGlobalTransactionId());
      callableStatement.setBytes(4, paramXid.getBranchQualifier());
      callableStatement.setInt(5, this.timeout);
      callableStatement.setInt(6, paramInt);
      
      callableStatement.execute();
      
      i = callableStatement.getInt(1);
    }
    catch (SQLException sQLException) {
      
      i = sQLException.getErrorCode();





      
      if (i == 0) {
        throw new XAException(-6);
      }
      
      throw sQLException;
    } finally {

      
      try {
        
        if (callableStatement != null) {
          callableStatement.close();
        }
      } catch (SQLException sQLException) {}
      
      callableStatement = null;
    } 
    
    return i;
  }


























  
  public void end(Xid paramXid, int paramInt) throws XAException {
    synchronized (this.connection) {
      
      int i = -1;
      boolean bool1 = false;
      boolean bool2 = false;

      
      try {
        if (paramXid == null)
        {

          
          throw new XAException(-5);
        }

        
        int j = 638582786;
        if ((paramInt & j) != paramInt)
        {

          
          throw new XAException(-5);
        }








        
        Xid xid = null;
        bool1 = ((paramInt & 0x4000000) != 0) ? true : false;
        bool2 = ((paramInt & 0x20000000) != 0) ? true : false;


        
        if (bool1 || bool2) {
          xid = suspendStacked(paramXid);
        }
        
        try {
          boolean bool = false;
          if (bool1 || bool2) {

            
            bool = isXidSuspended(paramXid);









            
            if (bool) {
              resumeStacked(paramXid);
            }
            
            removeXidFromList(paramXid);
          } else if (paramInt == 33554432) {
            
            boolean[] arrayOfBoolean = { false };
            createOrUpdateXid(paramXid, true, arrayOfBoolean);

            
            bool = arrayOfBoolean[0];
          } 

          
          i = doEnd(paramXid, paramInt, bool);
        }
        catch (SQLException sQLException) {

          
          checkError(sQLException, -3);
        } 
        
        if (xid != null) {

          
          resumeStacked(xid);
        } else if (isXidListEmpty()) {


          
          exitGlobalTxnMode();
          this.activeXid = null;
        } 



        
        checkError(i);
        
        if ((bool1 && paramInt != 67108864) || (bool2 && paramInt != 536870912))
        {
          
          throw new XAException(-5);
        }
      }
      finally {
        
        restoreAutoCommitModeForGlobalTransaction();
      } 
    } 
  }







  
  protected int doEnd(Xid paramXid, int paramInt, boolean paramBoolean) throws XAException, SQLException {
    CallableStatement callableStatement = null;
    int i = -1;



    
    try {
      callableStatement = this.connection.prepareCall(xa_end_post_816);
      
      callableStatement.registerOutParameter(1, 2);
      callableStatement.setInt(2, paramXid.getFormatId());
      callableStatement.setBytes(3, paramXid.getGlobalTransactionId());
      callableStatement.setBytes(4, paramXid.getBranchQualifier());
      callableStatement.setInt(5, paramInt);
      callableStatement.execute();
      
      i = callableStatement.getInt(1);
    }
    catch (SQLException sQLException) {
      
      i = sQLException.getErrorCode();





      
      if (i == 0) {
        throw new XAException(-6);
      }
      
      throw sQLException;
    } finally {

      
      try {
        
        if (callableStatement != null) {
          callableStatement.close();
        }
      } catch (SQLException sQLException) {}
      
      callableStatement = null;
    } 
    
    return i;
  }






















  
  public void commit(Xid paramXid, boolean paramBoolean) throws XAException {
    synchronized (this.connection) {
      
      if (paramXid == null)
      {

        
        throw new XAException(-5);
      }

      
      Xid xid = null;
      if (this.needStackingForCommitRollbackPrepare) {
        xid = suspendStacked(paramXid);

      
      }
      else {


        
        removeXidFromList(paramXid);
        
        if (this.activeXid == null) {
          exitGlobalTxnMode();
        }
      } 

      
      try {
        try {
          doCommit(paramXid, paramBoolean);
        }
        catch (SQLException sQLException) {

          
          checkError(sQLException, -3);
        }
      
      } catch (XAException xAException) {
        
        if (xAException.errorCode == -7) {

          
          try {
            this.connection.close();
          } catch (SQLException sQLException) {}

        
        }
        else if (this.needStackingForCommitRollbackPrepare) {
          resumeStacked(xid);
        } 
        throw xAException;
      } 
      
      if (this.needStackingForCommitRollbackPrepare) {
        resumeStacked(xid);
      }
    } 
  }





  
  protected void doCommit(Xid paramXid, boolean paramBoolean) throws XAException, SQLException {
    CallableStatement callableStatement = null;



    
    try {
      callableStatement = this.connection.prepareCall(xa_commit_post_816);
      
      callableStatement.registerOutParameter(1, 2);
      callableStatement.setInt(2, paramXid.getFormatId());
      callableStatement.setBytes(3, paramXid.getGlobalTransactionId());
      callableStatement.setBytes(4, paramXid.getBranchQualifier());
      callableStatement.setInt(5, paramBoolean ? 1 : 0);
      
      callableStatement.execute();
      
      int i = callableStatement.getInt(1);
      checkError(i, -7);
    }
    catch (SQLException sQLException) {
      
      int i = sQLException.getErrorCode();





      
      if (i == 0) {
        throw new XAException(-6);
      }
      
      throw sQLException;
    } finally {

      
      try {
        
        if (callableStatement != null) {
          callableStatement.close();
        }
      } catch (SQLException sQLException) {}
      
      callableStatement = null;
    } 
  }




















  
  public int prepare(Xid paramXid) throws XAException {
    synchronized (this.connection) {
      
      int i = 0;
      
      if (paramXid == null)
      {

        
        throw new XAException(-5);
      }

      
      Xid xid = null;
      if (this.needStackingForCommitRollbackPrepare) {
        xid = suspendStacked(paramXid);
      }

      
      try {
        try {
          i = doPrepare(paramXid);
          if (i != 0 && i != 3)
          {





            
            int j = OracleXAException.errorConvert(i);
            
            if (j != 0 && j != 3) {
              
              XAException xAException = OracleXAException.newXAException(getConnectionDuringExceptionHandling(), i);
              xAException.fillInStackTrace();
              throw xAException;
            } 
            
            i = j;
          }
        
        } catch (SQLException sQLException) {

          
          checkError(sQLException, -3);
        }
      
      } catch (XAException xAException) {
        
        if (xAException.errorCode == -7) {

          
          try {
            this.connection.close();
          } catch (SQLException sQLException) {}

        
        }
        else if (this.needStackingForCommitRollbackPrepare) {
          resumeStacked(xid);
        } 
        throw xAException;
      } 

      
      if (this.needStackingForCommitRollbackPrepare) {
        resumeStacked(xid);
      }
      return i;
    } 
  }





  
  protected int doPrepare(Xid paramXid) throws XAException, SQLException {
    int i = 0;
    CallableStatement callableStatement = null;



    
    try {
      callableStatement = this.connection.prepareCall(xa_prepare_post_816);
      
      callableStatement.registerOutParameter(1, 2);
      callableStatement.setInt(2, paramXid.getFormatId());
      callableStatement.setBytes(3, paramXid.getGlobalTransactionId());
      callableStatement.setBytes(4, paramXid.getBranchQualifier());
      
      callableStatement.execute();
      
      i = callableStatement.getInt(1);
    }
    catch (SQLException sQLException) {


      
      int j = sQLException.getErrorCode();





      
      if (j == 0) {
        throw new XAException(-6);
      }
      
      throw sQLException;
    } finally {

      
      try {
        
        if (callableStatement != null) {
          callableStatement.close();
        }
      } catch (SQLException sQLException) {}
      
      callableStatement = null;
    } 
    return i;
  }











  
  public void forget(Xid paramXid) throws XAException {
    synchronized (this.connection) {


      
      int i = 0;
      
      if (paramXid == null)
      {

        
        throw new XAException(-5);
      }

      
      removeXidFromList(paramXid);

      
      try {
        i = doForget(paramXid);
      }
      catch (SQLException sQLException) {

        
        checkError(sQLException, -3);
      } 



      
      checkError(i);
    } 
  }






  
  protected int doForget(Xid paramXid) throws XAException, SQLException {
    int i = 0;
    CallableStatement callableStatement = null;



    
    try {
      callableStatement = this.connection.prepareCall(xa_forget_post_816);
      
      callableStatement.registerOutParameter(1, 2);
      callableStatement.setInt(2, paramXid.getFormatId());
      callableStatement.setBytes(3, paramXid.getGlobalTransactionId());
      callableStatement.setBytes(4, paramXid.getBranchQualifier());
      
      callableStatement.execute();
      
      i = callableStatement.getInt(1);
    }
    catch (SQLException sQLException) {
      
      i = sQLException.getErrorCode();





      
      if (i == 0) {
        throw new XAException(-6);
      }
      
      throw sQLException;
    } finally {

      
      try {
        
        if (callableStatement != null) {
          callableStatement.close();
        }
      } catch (SQLException sQLException) {}
      
      callableStatement = null;
    } 
    
    return i;
  }














  
  public void rollback(Xid paramXid) throws XAException {
    synchronized (this.connection) {
      
      boolean bool = false;
      
      if (paramXid == null)
      {

        
        throw new XAException(-5);
      }

      
      Xid xid = null;
      if (this.needStackingForCommitRollbackPrepare) {
        xid = suspendStacked(paramXid);

      
      }
      else {


        
        removeXidFromList(paramXid);
        
        if (this.activeXid == null) {
          exitGlobalTxnMode();
        }
      } 
      try {
        doRollback(paramXid);
      }
      catch (SQLException sQLException) {

        
        checkError(sQLException, -3);
      } 

      
      if (this.needStackingForCommitRollbackPrepare) {
        resumeStacked(xid);
      }


      
      checkError(bool);
    } 
  }






  
  protected void doRollback(Xid paramXid) throws XAException, SQLException {
    CallableStatement callableStatement = null;



    
    try {
      callableStatement = this.connection.prepareCall(xa_rollback_post_816);
      
      callableStatement.registerOutParameter(1, 2);
      callableStatement.setInt(2, paramXid.getFormatId());
      callableStatement.setBytes(3, paramXid.getGlobalTransactionId());
      callableStatement.setBytes(4, paramXid.getBranchQualifier());
      
      callableStatement.execute();
      
      int i = callableStatement.getInt(1);
      
      checkError(i, -7);
    }
    catch (SQLException sQLException) {
      
      int i = sQLException.getErrorCode();


      
      if (i == 0) {
        throw new XAException(-6);
      }
      
      throw sQLException;
    } finally {

      
      try {
        
        if (callableStatement != null) {
          callableStatement.close();
        }
      } catch (SQLException sQLException) {}
      
      callableStatement = null;
    } 
  }





  
  public void doTwoPhaseAction(int paramInt1, int paramInt2, String[] paramArrayOfString, Xid[] paramArrayOfXid) throws XAException {
    synchronized (this.connection) {
      
      doDoTwoPhaseAction(paramInt1, paramInt2, paramArrayOfString, paramArrayOfXid);
    } 
  }





  
  protected int doDoTwoPhaseAction(int paramInt1, int paramInt2, String[] paramArrayOfString, Xid[] paramArrayOfXid) throws XAException {
    throw new XAException(-6);
  }











  
  private static byte[] getSerializedBytes(Xid paramXid) {
    try {
      return Util.serializeObject(paramXid);
    }
    catch (IOException iOException) {



      
      return null;
    } 
  }



  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
