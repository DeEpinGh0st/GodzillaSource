package oracle.jdbc.internal;

public interface XSCacheOutput {}
