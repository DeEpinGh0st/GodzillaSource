package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.jdbc.aq.AQAgent;






































class AQAgentI
  implements AQAgent
{
  private String attrAgentName = null;
  private String attrAgentAddress = null;
  private int attrAgentProtocol = 0;





  
  public void setAddress(String paramString) throws SQLException {
    this.attrAgentAddress = paramString;
  }



  
  public String getAddress() {
    return this.attrAgentAddress;
  }




  
  public void setName(String paramString) throws SQLException {
    this.attrAgentName = paramString;
  }



  
  public String getName() {
    return this.attrAgentName;
  }



  
  public void setProtocol(int paramInt) throws SQLException {
    this.attrAgentProtocol = paramInt;
  }



  
  public int getProtocol() {
    return this.attrAgentProtocol;
  }



  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("Name=\"");
    stringBuffer.append(getName());
    stringBuffer.append("\" ");
    stringBuffer.append("Address=\"");
    stringBuffer.append(getAddress());
    stringBuffer.append("\" ");
    stringBuffer.append("Protocol=\"");
    stringBuffer.append(getProtocol());
    stringBuffer.append("\"");
    return stringBuffer.toString();
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
