package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;

































final class T4CTTIoping
  extends T4CTTIfun
{
  T4CTTIoping(T4CConnection paramT4CConnection) {
    super(paramT4CConnection, (byte)3);
    
    setFunCode((short)147);
  }



  
  void doOPING() throws IOException, SQLException {
    doRPC();
  }








  
  void marshal() throws IOException {}







  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return this.connection;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
