package oracle.jdbc.connector;

import javax.resource.ResourceException;
import javax.resource.spi.ConnectionManager;
import javax.resource.spi.ConnectionRequestInfo;
import javax.resource.spi.ManagedConnection;
import javax.resource.spi.ManagedConnectionFactory;



















































public class OracleConnectionManager
  implements ConnectionManager
{
  public Object allocateConnection(ManagedConnectionFactory paramManagedConnectionFactory, ConnectionRequestInfo paramConnectionRequestInfo) throws ResourceException {
    ManagedConnection managedConnection = paramManagedConnectionFactory.createManagedConnection(null, paramConnectionRequestInfo);
    
    return managedConnection.getConnection(null, paramConnectionRequestInfo);
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
