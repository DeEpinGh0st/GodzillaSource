package oracle.jdbc.driver;

import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.aq.AQMessage;
import oracle.jdbc.aq.AQMessageProperties;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.oracore.OracleTypeADT;
import oracle.sql.ANYDATA;
import oracle.sql.OPAQUE;
import oracle.sql.OpaqueDescriptor;
import oracle.sql.RAW;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;
import oracle.sql.TypeDescriptor;
import oracle.xdb.XMLType;











































class AQMessageI
  implements AQMessage
{
  private byte[] id = null;
  private AQMessagePropertiesI properties = null;
  private byte[] toid = null;
  
  private byte[] payload;
  
  private STRUCT payLoadSTRUCT;
  
  private ANYDATA payLoadANYDATA;
  
  private RAW payLoadRAW;
  private XMLType payLoadXMLType;
  private Connection conn;
  private String typeName;
  private TypeDescriptor sd;
  
  AQMessageI(AQMessagePropertiesI paramAQMessagePropertiesI, Connection paramConnection) {
    this.properties = paramAQMessagePropertiesI;
    this.conn = paramConnection;
  }




  
  AQMessageI(AQMessagePropertiesI paramAQMessagePropertiesI) throws SQLException {
    this.properties = paramAQMessagePropertiesI;
  }



  
  void setTypeName(String paramString) {
    this.typeName = paramString;
  }



  
  void setTypeDescriptor(TypeDescriptor paramTypeDescriptor) {
    this.sd = paramTypeDescriptor;
  }



  
  public byte[] getMessageId() {
    return this.id;
  }



  
  void setMessageId(byte[] paramArrayOfbyte) throws SQLException {
    this.id = paramArrayOfbyte;
  }



  
  public AQMessageProperties getMessageProperties() {
    return this.properties;
  }



  
  AQMessagePropertiesI getMessagePropertiesI() {
    return this.properties;
  }









  
  public void setPayload(byte[] paramArrayOfbyte) throws SQLException {
    this.payload = paramArrayOfbyte;
    this.toid = TypeDescriptor.RAWTOID;
  }




  
  public void setPayload(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) throws SQLException {
    this.payload = paramArrayOfbyte1;
    this.toid = paramArrayOfbyte2;
  }




  
  public void setPayload(STRUCT paramSTRUCT) throws SQLException {
    this.payload = paramSTRUCT.toBytes();
    this.payLoadSTRUCT = paramSTRUCT;
    this.toid = paramSTRUCT.getDescriptor().getOracleTypeADT().getTOID();
  }




  
  public void setPayload(ANYDATA paramANYDATA) throws SQLException {
    this.payload = paramANYDATA.toDatum(this.conn).shareBytes();
    this.payLoadANYDATA = paramANYDATA;
    this.toid = TypeDescriptor.ANYDATATOID;
  }



  
  public void setPayload(RAW paramRAW) throws SQLException {
    this.payload = paramRAW.shareBytes();
    this.payLoadRAW = paramRAW;
    this.toid = TypeDescriptor.RAWTOID;
  }



  
  public void setPayload(XMLType paramXMLType) throws SQLException {
    this.payload = paramXMLType.toBytes();
    this.payLoadXMLType = paramXMLType;
    this.toid = TypeDescriptor.XMLTYPETOID;
  }



  
  public byte[] getPayload() {
    return this.payload;
  }



  
  public RAW getRAWPayload() throws SQLException {
    RAW rAW = null;
    if (this.payLoadRAW != null) {
      rAW = this.payLoadRAW;
    } else if (isRAWPayload()) {
      
      this.payLoadRAW = new RAW(this.payload);
      rAW = this.payLoadRAW;
    }
    else {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 193);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    return rAW;
  }




  
  public boolean isRAWPayload() throws SQLException {
    if (this.toid == null || this.toid.length != 16) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 252);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (compareToid(this.toid, TypeDescriptor.RAWTOID)) {
      return true;
    }
    return false;
  }




  
  public STRUCT getSTRUCTPayload() throws SQLException {
    STRUCT sTRUCT = null;
    
    if (!isSTRUCTPayload()) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 193);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.payLoadSTRUCT != null) {
      sTRUCT = this.payLoadSTRUCT;
    } else {
      
      if (this.sd == null) {
        
        this.typeName = OracleTypeADT.toid2typename(this.conn, this.toid);
        this.sd = TypeDescriptor.getTypeDescriptor(this.typeName, (OracleConnection)this.conn);
      } 
      
      if (this.sd instanceof StructDescriptor) {



        
        sTRUCT = new STRUCT((StructDescriptor)this.sd, this.payload, this.conn);
        this.payLoadSTRUCT = sTRUCT;
      }
      else {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 193);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    } 
    
    return sTRUCT;
  }



  
  public boolean isSTRUCTPayload() throws SQLException {
    if (this.toid == null || this.toid.length != 16) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 252);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    boolean bool1 = true;
    
    boolean bool2 = true;
    for (byte b = 0; b < 15; b++) {
      if (this.toid[b] != 0) {
        
        bool2 = false;
        break;
      } 
    } 
    if (bool2 || isRAWPayload() || isANYDATAPayload()) {
      bool1 = false;
    }
    return bool1;
  }



  
  public ANYDATA getANYDATAPayload() throws SQLException {
    ANYDATA aNYDATA = null;
    
    if (this.payLoadANYDATA != null) {
      aNYDATA = this.payLoadANYDATA;
    } else if (isANYDATAPayload()) {
      
      OpaqueDescriptor opaqueDescriptor = OpaqueDescriptor.createDescriptor("SYS.ANYDATA", this.conn);
      
      OPAQUE oPAQUE = new OPAQUE(opaqueDescriptor, this.payload, this.conn);
      this.payLoadANYDATA = new ANYDATA(oPAQUE);
      aNYDATA = this.payLoadANYDATA;
    }
    else {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 193);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    return aNYDATA;
  }



  
  public boolean isANYDATAPayload() throws SQLException {
    if (this.toid == null || this.toid.length != 16) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 252);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    if ((this.typeName != null && this.typeName.equals("SYS.ANYDATA")) || compareToid(this.toid, TypeDescriptor.ANYDATATOID))
    {
      return true;
    }
    return false;
  }



  
  public XMLType getXMLTypePayload() throws SQLException {
    XMLType xMLType = null;
    
    if (this.payLoadXMLType != null) {
      xMLType = this.payLoadXMLType;
    } else if (isXMLTypePayload()) {
      
      OpaqueDescriptor opaqueDescriptor = OpaqueDescriptor.createDescriptor("SYS.XMLTYPE", this.conn);
      
      OPAQUE oPAQUE = new OPAQUE(opaqueDescriptor, this.payload, this.conn);
      this.payLoadXMLType = XMLType.createXML(oPAQUE);
      xMLType = this.payLoadXMLType;
    }
    else {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 193);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    return xMLType;
  }



  
  public boolean isXMLTypePayload() throws SQLException {
    if (this.toid == null || this.toid.length != 16) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 252);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    if ((this.typeName != null && this.typeName.equals("SYS.XMLTYPE")) || compareToid(this.toid, TypeDescriptor.XMLTYPETOID))
    {
      return true;
    }
    return false;
  }



  
  public byte[] getPayloadTOID() {
    return this.toid;
  }



  
  static boolean compareToid(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    boolean bool = false;
    
    if (paramArrayOfbyte1 != null)
    {
      if (paramArrayOfbyte1 == paramArrayOfbyte2) {
        bool = true;
      } else if (paramArrayOfbyte1.length == paramArrayOfbyte2.length) {
        
        boolean bool1 = true;
        for (byte b = 0; b < paramArrayOfbyte1.length; b++) {
          if (paramArrayOfbyte1[b] != paramArrayOfbyte2[b]) {
            
            bool1 = false; break;
          } 
        } 
        if (bool1)
          bool = true; 
      } 
    }
    return bool;
  }



  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("Message Properties={");
    stringBuffer.append(this.properties);
    stringBuffer.append("} ");
    return stringBuffer.toString();
  }











  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
