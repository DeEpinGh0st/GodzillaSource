package oracle.jdbc.driver;

import oracle.jdbc.dcn.RowChangeDescription;
import oracle.sql.ROWID;


























class NTFDCNRowChanges
  implements RowChangeDescription
{
  RowChangeDescription.RowOperation opcode;
  int rowidLength;
  byte[] rowid;
  ROWID rowidObj;
  
  NTFDCNRowChanges(RowChangeDescription.RowOperation paramRowOperation, int paramInt, byte[] paramArrayOfbyte) {
    this.opcode = paramRowOperation;
    this.rowidLength = paramInt;
    this.rowid = paramArrayOfbyte;
    this.rowidObj = null;
  }



  
  public ROWID getRowid() {
    if (this.rowidObj == null)
      this.rowidObj = new ROWID(this.rowid); 
    return this.rowidObj;
  }


  
  public RowChangeDescription.RowOperation getRowOperation() {
    return this.opcode;
  }



  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("      ROW:  operation=" + getRowOperation() + ", ROWID=" + new String(this.rowid) + "\n");
    return stringBuffer.toString();
  }

  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
