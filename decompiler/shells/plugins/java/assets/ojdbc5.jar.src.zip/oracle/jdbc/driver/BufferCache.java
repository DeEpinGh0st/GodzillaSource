package oracle.jdbc.driver;

import java.lang.ref.SoftReference;
import java.lang.reflect.Array;
import oracle.jdbc.internal.OracleConnection;








































































































































class BufferCache<T>
{
  private static final double ln2 = Math.log(2.0D);


  
  private static final int BUFFERS_PER_BUCKET = 8;


  
  private static final int MIN_INDEX = 12;

  
  private final InternalStatistics stats;

  
  private final int[] bufferSize;

  
  private final SoftReference<T>[][] buckets;

  
  private final int[] top;


  
  BufferCache(int paramInt) {
    int i;
    if (paramInt < 31) {
      i = paramInt;
    
    }
    else {
      
      i = (int)Math.ceil(Math.log(paramInt) / ln2);
    } 
    
    int j = Math.max(0, i - 12 + 1);
    
    this.buckets = (SoftReference<T>[][])new SoftReference[j][8];
    this.top = new int[j];
    
    this.bufferSize = new int[j];
    int k = 4096;
    for (byte b = 0; b < this.bufferSize.length; b++) {
      this.bufferSize[b] = k;
      k <<= 1;
    } 
    this.stats = new InternalStatistics(this.bufferSize);
  }














  
  T get(Class<?> paramClass, int paramInt) {
    int i = bufferIndex(paramInt);
    
    if (i >= this.buckets.length) {
      this.stats.requestTooBig();
      return (T)Array.newInstance(paramClass, paramInt);
    } 
    
    while (this.top[i] > 0) {
      this.top[i] = this.top[i] - 1; SoftReference<T> softReference = this.buckets[i][this.top[i] - 1];
      this.buckets[i][this.top[i]] = null;
      T t = softReference.get();
      if (t != null) {
        this.stats.cacheHit(i);
        return t;
      } 
    } 
    
    this.stats.cacheMiss(i);
    return (T)Array.newInstance(paramClass, this.bufferSize[i]);
  }










  
  void put(T paramT) {
    int i = Array.getLength(paramT);
    
    int j = bufferIndex(i);

    
    if (j >= this.buckets.length || i != this.bufferSize[j]) {
      this.stats.cacheTooBig();
      
      return;
    } 
    if (this.top[j] < 8) {
      this.stats.bufferCached(j);
      this.top[j] = this.top[j] + 1; this.buckets[j][this.top[j]] = new SoftReference<T>(paramT);
    
    }
    else {

      
      for (int k = this.top[j]; k > 0;) {
        if (this.buckets[j][--k].get() == null) {
          
          this.stats.refCleared(j);
          this.buckets[j][k] = new SoftReference<T>(paramT);
          return;
        } 
      } 
      this.stats.bucketFull(j);
    } 
  }



  
  OracleConnection.BufferCacheStatistics getStatistics() {
    return this.stats;
  }




  
  private int bufferIndex(int paramInt) {
    for (byte b = 0; b < this.bufferSize.length; b++) {
      if (paramInt <= this.bufferSize[b]) return b; 
    } 
    return Integer.MAX_VALUE;
  }
  
  private static final class InternalStatistics
    implements OracleConnection.BufferCacheStatistics {
    private static int CACHE_COUNT = 0;
    
    private final int cacheId = ++CACHE_COUNT;
    
    private final int[] sizes;
    
    private final int[] nCacheHit;
    
    private final int[] nCacheMiss;
    private int nRequestTooBig;
    private final int[] nBufferCached;
    private final int[] nBucketFull;
    private final int[] nRefCleared;
    private int nCacheTooBig;
    
    InternalStatistics(int[] param1ArrayOfint) {
      this.sizes = param1ArrayOfint;
      int i = param1ArrayOfint.length;
      this.nCacheHit = new int[i];
      this.nCacheMiss = new int[i];
      this.nRequestTooBig = 0;
      this.nBufferCached = new int[i];
      this.nBucketFull = new int[i];
      this.nRefCleared = new int[i];
      this.nCacheTooBig = 0;
    }
    
    void cacheHit(int param1Int) { this.nCacheHit[param1Int] = this.nCacheHit[param1Int] + 1; }
    void cacheMiss(int param1Int) { this.nCacheMiss[param1Int] = this.nCacheMiss[param1Int] + 1; }
    void requestTooBig() { this.nRequestTooBig++; }
    void bufferCached(int param1Int) { this.nBufferCached[param1Int] = this.nBufferCached[param1Int] + 1; }
    void bucketFull(int param1Int) { this.nBucketFull[param1Int] = this.nBucketFull[param1Int] + 1; }
    void refCleared(int param1Int) { this.nRefCleared[param1Int] = this.nRefCleared[param1Int] + 1; } void cacheTooBig() {
      this.nCacheTooBig++;
    }
    public int getId() {
      return this.cacheId;
    } public int[] getBufferSizes() {
      int[] arrayOfInt = new int[this.sizes.length];
      System.arraycopy(this.sizes, 0, arrayOfInt, 0, this.sizes.length);
      return arrayOfInt;
    }
    public int getCacheHits(int param1Int) { return this.nCacheHit[param1Int]; }
    public int getCacheMisses(int param1Int) { return this.nCacheMiss[param1Int]; }
    public int getRequestsTooBig() { return this.nRequestTooBig; }
    public int getBuffersCached(int param1Int) { return this.nBufferCached[param1Int]; }
    public int getBucketsFull(int param1Int) { return this.nBucketFull[param1Int]; }
    public int getReferencesCleared(int param1Int) { return this.nRefCleared[param1Int]; } public int getTooBigToCache() {
      return this.nCacheTooBig;
    }
    public String toString() {
      int i = 0;
      int j = 0;
      int k = 0;
      int m = 0;
      int n = 0;
      for (byte b = 0; b < this.sizes.length; b++) {
        i += this.nCacheHit[b];
        j += this.nCacheMiss[b];
        k += this.nBufferCached[b];
        m += this.nBucketFull[b];
        n += this.nRefCleared[b];
      } 
      return "oracle.jdbc.driver.BufferCache<" + this.cacheId + ">\n" + "\tTotal Hits   :\t" + i + "\n" + "\tTotal Misses :\t" + (j + this.nRequestTooBig) + "\n" + "\tTotal Cached :\t" + k + "\n" + "\tTotal Dropped:\t" + (m + this.nCacheTooBig) + "\n" + "\tTotal Cleared:\t" + n + "\n";
    }
  }







  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
