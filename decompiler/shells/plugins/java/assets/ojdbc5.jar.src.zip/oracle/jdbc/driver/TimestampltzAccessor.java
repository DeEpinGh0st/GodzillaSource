package oracle.jdbc.driver;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;
import java.util.TimeZone;
import oracle.sql.DATE;
import oracle.sql.Datum;
import oracle.sql.OffsetDST;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;
import oracle.sql.TIMEZONETAB;
import oracle.sql.ZONEIDMAP;










class TimestampltzAccessor
  extends DateTimeCommonAccessor
{
  TimestampltzAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean) throws SQLException {
    init(paramOracleStatement, 231, 231, paramShort, paramBoolean);
    initForDataAccess(paramInt2, paramInt1, (String)null);
  }





  
  TimestampltzAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort) throws SQLException {
    init(paramOracleStatement, 231, 231, paramShort, false);
    initForDescribe(231, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, null);
    
    initForDataAccess(0, paramInt1, (String)null);
  }




  
  void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
    if (paramInt1 != 0) {
      this.externalType = paramInt1;
    }
    this.internalTypeMaxLength = 11;
    
    if (paramInt2 > 0 && paramInt2 < this.internalTypeMaxLength) {
      this.internalTypeMaxLength = paramInt2;
    }
    this.byteLength = this.internalTypeMaxLength;
  }




  
  String getString(int paramInt) throws SQLException {
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
      return null;
    }
    
    Calendar calendar1 = this.statement.connection.getDbTzCalendar();


    
    String str1 = this.statement.connection.getSessionTimeZone();
    
    if (str1 == null) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 198);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    TimeZone timeZone = TimeZone.getTimeZone(str1);
    
    Calendar calendar2 = Calendar.getInstance(timeZone);
    
    int i = this.columnIndex + this.byteLength * paramInt;
    short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
    
    int j = oracleYear(i);
    
    calendar1.set(1, j);
    calendar1.set(2, oracleMonth(i));
    calendar1.set(5, oracleDay(i));
    calendar1.set(11, oracleHour(i));
    calendar1.set(12, oracleMin(i));
    calendar1.set(13, oracleSec(i));
    calendar1.set(14, 0);

    
    TimeZoneAdjust(calendar1, calendar2);

    
    j = calendar2.get(1);
    
    int k = calendar2.get(2) + 1;
    int m = calendar2.get(5);
    int n = calendar2.get(11);
    int i1 = calendar2.get(12);
    int i2 = calendar2.get(13);
    int i3 = 0;
    boolean bool = (n < 12) ? true : false;
    String str2 = calendar2.getTimeZone().getID();
    if (str2.length() > 3 && str2.startsWith("GMT")) {
      str2 = str2.substring(3);
    }
    if (s == 11)
    {
      i3 = oracleNanos(i);
    }
    
    return toText(j, k, m, n, i1, i2, i3, bool, str2);
  }







  
  Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
    return getDate(paramInt);
  }


  
  Date getDate(int paramInt) throws SQLException {
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
      return null;
    }
    
    Calendar calendar1 = this.statement.connection.getDbTzCalendar();


    
    String str = this.statement.connection.getSessionTimeZone();
    
    if (str == null) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 198);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    TimeZone timeZone = TimeZone.getTimeZone(str);
    
    Calendar calendar2 = Calendar.getInstance(timeZone);
    
    int i = this.columnIndex + this.byteLength * paramInt;
    int j = oracleYear(i);
    
    calendar1.set(1, j);
    calendar1.set(2, oracleMonth(i));
    calendar1.set(5, oracleDay(i));
    calendar1.set(11, oracleHour(i));
    calendar1.set(12, oracleMin(i));
    calendar1.set(13, oracleSec(i));
    calendar1.set(14, 0);
    
    long l = TimeZoneAdjustUTC(calendar1);
    
    return new Date(l);
  }





  
  Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
    return getTime(paramInt);
  }


  
  Time getTime(int paramInt) throws SQLException {
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
      return null;
    }
    
    Calendar calendar1 = this.statement.connection.getDbTzCalendar();


    
    String str = this.statement.connection.getSessionTimeZone();
    
    if (str == null) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 198);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    TimeZone timeZone = TimeZone.getTimeZone(str);
    
    Calendar calendar2 = Calendar.getInstance(timeZone);
    
    int i = this.columnIndex + this.byteLength * paramInt;
    int j = oracleYear(i);
    
    calendar1.set(1, j);
    calendar1.set(2, oracleMonth(i));
    calendar1.set(5, oracleDay(i));
    calendar1.set(11, oracleHour(i));
    calendar1.set(12, oracleMin(i));
    calendar1.set(13, oracleSec(i));
    calendar1.set(14, 0);

    
    long l = TimeZoneAdjustUTC(calendar1);
    
    return new Time(l);
  }






  
  Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
    return getTimestamp(paramInt);
  }



  
  Timestamp getTimestamp(int paramInt) throws SQLException {
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
      return null;
    }
    
    Calendar calendar1 = this.statement.connection.getDbTzCalendar();


    
    String str = this.statement.connection.getSessionTimeZone();
    
    if (str == null) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 198);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    TimeZone timeZone = TimeZone.getTimeZone(str);
    Calendar calendar2 = Calendar.getInstance(timeZone);
    
    int i = this.columnIndex + this.byteLength * paramInt;
    short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
    
    int j = oracleYear(i);
    
    calendar1.set(1, j);
    calendar1.set(2, oracleMonth(i));
    calendar1.set(5, oracleDay(i));
    calendar1.set(11, oracleHour(i));
    calendar1.set(12, oracleMin(i));
    calendar1.set(13, oracleSec(i));
    calendar1.set(14, 0);

    
    long l = TimeZoneAdjustUTC(calendar1);
    
    Timestamp timestamp = new Timestamp(l);
    
    if (s == 11)
    {
      timestamp.setNanos(oracleNanos(i));
    }
    
    return timestamp;
  }




  
  Object getObject(int paramInt) throws SQLException {
    return getTIMESTAMPLTZ(paramInt);
  }




  
  Datum getOracleObject(int paramInt) throws SQLException {
    return (Datum)getTIMESTAMPLTZ(paramInt);
  }




  
  Object getObject(int paramInt, Map paramMap) throws SQLException {
    return getTIMESTAMPLTZ(paramInt);
  }




  
  TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
    TIMESTAMPLTZ tIMESTAMPLTZ = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
      int i = this.columnIndex + this.byteLength * paramInt;
      byte[] arrayOfByte = new byte[s];
      
      System.arraycopy(this.rowSpaceByte, i, arrayOfByte, 0, s);
      
      tIMESTAMPLTZ = new TIMESTAMPLTZ(arrayOfByte);
    } 
    
    return tIMESTAMPLTZ;
  }



  
  TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
    TIMESTAMPTZ tIMESTAMPTZ = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
      int i = this.columnIndex + this.byteLength * paramInt;
      byte[] arrayOfByte = new byte[s];
      
      System.arraycopy(this.rowSpaceByte, i, arrayOfByte, 0, s);
      
      tIMESTAMPTZ = TIMESTAMPLTZ.toTIMESTAMPTZ((Connection)this.statement.connection, arrayOfByte);
    } 
    
    return tIMESTAMPTZ;
  }


  
  TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
    TIMESTAMPTZ tIMESTAMPTZ = getTIMESTAMPTZ(paramInt);
    return TIMESTAMPTZ.toTIMESTAMP((Connection)this.statement.connection, tIMESTAMPTZ.getBytes());
  }

  
  DATE getDATE(int paramInt) throws SQLException {
    TIMESTAMPTZ tIMESTAMPTZ = getTIMESTAMPTZ(paramInt);
    return TIMESTAMPTZ.toDATE((Connection)this.statement.connection, tIMESTAMPTZ.getBytes());
  }






  
  void TimeZoneAdjust(Calendar paramCalendar1, Calendar paramCalendar2) throws SQLException {
    String str1 = paramCalendar1.getTimeZone().getID();
    String str2 = paramCalendar2.getTimeZone().getID();

    
    if (!str2.equals(str1)) {
      int i3;
      OffsetDST offsetDST = new OffsetDST();

      
      byte b = getZoneOffset(paramCalendar1, offsetDST);
      
      int i4 = offsetDST.getOFFSET();

      
      paramCalendar1.add(11, -(i4 / 3600000));
      paramCalendar1.add(12, -(i4 % 3600000) / 60000);




      
      if (str2.equals("Custom") || (str2.startsWith("GMT") && str2.length() > 3)) {


        
        i3 = paramCalendar2.getTimeZone().getRawOffset();
      
      }
      else {
        
        int i5 = ZONEIDMAP.getID(str2);
        
        if (!ZONEIDMAP.isValidID(i5)) {
          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 199);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 
        
        TIMEZONETAB tIMEZONETAB = this.statement.connection.getTIMEZONETAB();
        if (tIMEZONETAB.checkID(i5))
        {
          tIMEZONETAB.updateTable((Connection)this.statement.connection, i5);
        }
        
        Calendar calendar = this.statement.getGMTCalendar();
        
        calendar.set(1, paramCalendar1.get(1));
        calendar.set(2, paramCalendar1.get(2));
        calendar.set(5, paramCalendar1.get(5));
        calendar.set(11, paramCalendar1.get(11));
        calendar.set(12, paramCalendar1.get(12));
        calendar.set(13, paramCalendar1.get(13));
        calendar.set(14, paramCalendar1.get(14));

        
        i3 = tIMEZONETAB.getOffset(calendar, i5);
      } 

      
      paramCalendar1.add(11, i3 / 3600000);
      paramCalendar1.add(12, i3 % 3600000 / 60000);
    } 




    
    if ((str2.equals("Custom") && str1.equals("Custom")) || (str2.startsWith("GMT") && str2.length() > 3 && str1.startsWith("GMT") && str1.length() > 3)) {



      
      int i3 = paramCalendar1.getTimeZone().getRawOffset();
      int i4 = paramCalendar2.getTimeZone().getRawOffset();
      int i5 = 0;

      
      if (i3 != i4) {

        
        i5 = i3 - i4;
        i5 = (i5 > 0) ? i5 : -i5;
      } 
      
      if (i3 > i4) {
        i5 = -i5;
      }
      paramCalendar1.add(11, i5 / 3600000);
      paramCalendar1.add(12, i5 % 3600000 / 60000);
    } 

    
    int i = paramCalendar1.get(1);
    int j = paramCalendar1.get(2);
    int k = paramCalendar1.get(5);
    int m = paramCalendar1.get(11);
    int n = paramCalendar1.get(12);
    int i1 = paramCalendar1.get(13);
    int i2 = paramCalendar1.get(14);

    
    paramCalendar2.set(1, i);
    paramCalendar2.set(2, j);
    paramCalendar2.set(5, k);
    paramCalendar2.set(11, m);
    paramCalendar2.set(12, n);
    paramCalendar2.set(13, i1);
    paramCalendar2.set(14, i2);
  }






  
  long TimeZoneAdjustUTC(Calendar paramCalendar) throws SQLException {
    String str = paramCalendar.getTimeZone().getID();
    
    if (str.equals("Custom") || (str.startsWith("GMT") && str.length() > 3)) {


      
      int i3 = paramCalendar.getTimeZone().getRawOffset();
      paramCalendar.add(11, -(i3 / 3600000));
      paramCalendar.add(12, -(i3 % 3600000) / 60000);
    }
    else if (!str.equals("GMT") && !str.equals("UTC")) {
      
      OffsetDST offsetDST = new OffsetDST();

      
      byte b = getZoneOffset(paramCalendar, offsetDST);
      
      int i3 = offsetDST.getOFFSET();


      
      paramCalendar.add(11, -(i3 / 3600000));
      paramCalendar.add(12, -(i3 % 3600000) / 60000);
    } 





    
    int i = paramCalendar.get(1);
    int j = paramCalendar.get(2);
    int k = paramCalendar.get(5);
    int m = paramCalendar.get(11);
    int n = paramCalendar.get(12);
    int i1 = paramCalendar.get(13);
    int i2 = paramCalendar.get(14);
    
    Calendar calendar = this.statement.getGMTCalendar();

    
    calendar.set(1, i);
    calendar.set(2, j);
    calendar.set(5, k);
    calendar.set(11, m);
    calendar.set(12, n);
    calendar.set(13, i1);
    calendar.set(14, i2);
    
    return calendar.getTimeInMillis();
  }






  
  byte getZoneOffset(Calendar paramCalendar, OffsetDST paramOffsetDST) throws SQLException {
    byte b = 0;

    
    String str = paramCalendar.getTimeZone().getID();

    
    if (str == "Custom" || (str.startsWith("GMT") && str.length() > 3)) {



      
      paramOffsetDST.setOFFSET(paramCalendar.getTimeZone().getRawOffset());
    
    }
    else {

      
      int i = ZONEIDMAP.getID(str);
      
      if (!ZONEIDMAP.isValidID(i)) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 199);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      TIMEZONETAB tIMEZONETAB = this.statement.connection.getTIMEZONETAB();
      if (tIMEZONETAB.checkID(i)) {
        tIMEZONETAB.updateTable((Connection)this.statement.connection, i);
      }

      
      b = tIMEZONETAB.getLocalOffset(paramCalendar, i, paramOffsetDST);
    } 
    
    return b;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
