package oracle.jdbc.pool;

import java.sql.SQLException;
import javax.sql.DataSource;
import javax.sql.PooledConnection;

public interface OracleConnectionCache extends DataSource {
  void reusePooledConnection(PooledConnection paramPooledConnection) throws SQLException;
  
  void closePooledConnection(PooledConnection paramPooledConnection) throws SQLException;
  
  void close() throws SQLException;
}
