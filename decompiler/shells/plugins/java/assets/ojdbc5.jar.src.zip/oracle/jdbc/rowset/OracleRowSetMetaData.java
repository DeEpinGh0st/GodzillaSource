package oracle.jdbc.rowset;

import java.io.Serializable;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import javax.sql.RowSetMetaData;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
















































































































public class OracleRowSetMetaData
  implements RowSetMetaData, Serializable
{
  private int columnCount;
  private int[] nullable;
  private int[] columnDisplaySize;
  private int[] precision;
  private int[] scale;
  private int[] columnType;
  private boolean[] searchable;
  private boolean[] caseSensitive;
  private boolean[] readOnly;
  private boolean[] writable;
  private boolean[] definatelyWritable;
  private boolean[] currency;
  private boolean[] autoIncrement;
  private boolean[] signed;
  private String[] columnLabel;
  private String[] schemaName;
  private String[] columnName;
  private String[] tableName;
  private String[] columnTypeName;
  private String[] catalogName;
  private String[] columnClassName;
  
  OracleRowSetMetaData(int paramInt) throws SQLException {
    this.columnCount = paramInt;
    this.searchable = new boolean[this.columnCount];
    this.caseSensitive = new boolean[this.columnCount];
    this.readOnly = new boolean[this.columnCount];
    this.nullable = new int[this.columnCount];
    this.signed = new boolean[this.columnCount];
    this.columnDisplaySize = new int[this.columnCount];
    this.columnType = new int[this.columnCount];
    this.columnLabel = new String[this.columnCount];
    this.columnName = new String[this.columnCount];
    this.schemaName = new String[this.columnCount];
    this.precision = new int[this.columnCount];
    this.scale = new int[this.columnCount];
    this.tableName = new String[this.columnCount];
    this.columnTypeName = new String[this.columnCount];
    this.writable = new boolean[this.columnCount];
    this.definatelyWritable = new boolean[this.columnCount];
    this.currency = new boolean[this.columnCount];
    this.autoIncrement = new boolean[this.columnCount];
    this.catalogName = new String[this.columnCount];
    this.columnClassName = new String[this.columnCount];
    
    for (byte b = 0; b < this.columnCount; b++) {
      
      this.searchable[b] = false;
      this.caseSensitive[b] = false;
      this.readOnly[b] = false;
      this.nullable[b] = 1;
      this.signed[b] = false;
      this.columnDisplaySize[b] = 0;
      this.columnType[b] = 0;
      this.columnLabel[b] = "";
      this.columnName[b] = "";
      this.schemaName[b] = "";
      this.precision[b] = 0;
      this.scale[b] = 0;
      this.tableName[b] = "";
      this.columnTypeName[b] = "";
      this.writable[b] = false;
      this.definatelyWritable[b] = false;
      this.currency[b] = false;
      this.autoIncrement[b] = true;
      this.catalogName[b] = "";
      this.columnClassName[b] = "";
    } 
  }






  
  OracleRowSetMetaData(ResultSetMetaData paramResultSetMetaData) throws SQLException {
    this.columnCount = paramResultSetMetaData.getColumnCount();
    this.searchable = new boolean[this.columnCount];
    this.caseSensitive = new boolean[this.columnCount];
    this.readOnly = new boolean[this.columnCount];
    this.nullable = new int[this.columnCount];
    this.signed = new boolean[this.columnCount];
    this.columnDisplaySize = new int[this.columnCount];
    this.columnType = new int[this.columnCount];
    this.columnLabel = new String[this.columnCount];
    this.columnName = new String[this.columnCount];
    this.schemaName = new String[this.columnCount];
    this.precision = new int[this.columnCount];
    this.scale = new int[this.columnCount];
    this.tableName = new String[this.columnCount];
    this.columnTypeName = new String[this.columnCount];
    this.writable = new boolean[this.columnCount];
    this.definatelyWritable = new boolean[this.columnCount];
    this.currency = new boolean[this.columnCount];
    this.autoIncrement = new boolean[this.columnCount];
    this.catalogName = new String[this.columnCount];
    this.columnClassName = new String[this.columnCount];
    
    for (byte b = 0; b < this.columnCount; b++) {
      
      this.searchable[b] = paramResultSetMetaData.isSearchable(b + 1);
      this.caseSensitive[b] = paramResultSetMetaData.isCaseSensitive(b + 1);
      this.readOnly[b] = paramResultSetMetaData.isReadOnly(b + 1);
      this.nullable[b] = paramResultSetMetaData.isNullable(b + 1);
      this.signed[b] = paramResultSetMetaData.isSigned(b + 1);
      this.columnDisplaySize[b] = paramResultSetMetaData.getColumnDisplaySize(b + 1);
      this.columnType[b] = paramResultSetMetaData.getColumnType(b + 1);
      this.columnLabel[b] = paramResultSetMetaData.getColumnLabel(b + 1);
      this.columnName[b] = paramResultSetMetaData.getColumnName(b + 1);
      this.schemaName[b] = paramResultSetMetaData.getSchemaName(b + 1);
      
      if (this.columnType[b] == 2 || this.columnType[b] == 2 || this.columnType[b] == -5 || this.columnType[b] == 3 || this.columnType[b] == 8 || this.columnType[b] == 6 || this.columnType[b] == 4) {






        
        this.precision[b] = paramResultSetMetaData.getPrecision(b + 1);
        this.scale[b] = paramResultSetMetaData.getScale(b + 1);
      }
      else {
        
        this.precision[b] = 0;
        this.scale[b] = 0;
      } 
      
      this.tableName[b] = paramResultSetMetaData.getTableName(b + 1);
      this.columnTypeName[b] = paramResultSetMetaData.getColumnTypeName(b + 1);
      this.writable[b] = paramResultSetMetaData.isWritable(b + 1);
      this.definatelyWritable[b] = paramResultSetMetaData.isDefinitelyWritable(b + 1);
      this.currency[b] = paramResultSetMetaData.isCurrency(b + 1);
      this.autoIncrement[b] = paramResultSetMetaData.isAutoIncrement(b + 1);
      this.catalogName[b] = paramResultSetMetaData.getCatalogName(b + 1);
      this.columnClassName[b] = paramResultSetMetaData.getColumnClassName(b + 1);
    } 
  }






  
  private void validateColumnIndex(int paramInt) throws SQLException {
    if (paramInt < 1 || paramInt > this.columnCount) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3, "" + paramInt);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }











  
  public int getColumnCount() throws SQLException {
    return this.columnCount;
  }












  
  public boolean isAutoIncrement(int paramInt) throws SQLException {
    validateColumnIndex(paramInt);
    return this.autoIncrement[paramInt - 1];
  }












  
  public boolean isCaseSensitive(int paramInt) throws SQLException {
    validateColumnIndex(paramInt);
    return this.caseSensitive[paramInt - 1];
  }












  
  public boolean isSearchable(int paramInt) throws SQLException {
    validateColumnIndex(paramInt);
    return this.searchable[paramInt - 1];
  }












  
  public boolean isCurrency(int paramInt) throws SQLException {
    validateColumnIndex(paramInt);
    return this.currency[paramInt - 1];
  }













  
  public int isNullable(int paramInt) throws SQLException {
    validateColumnIndex(paramInt);
    return this.nullable[paramInt - 1];
  }











  
  public boolean isSigned(int paramInt) throws SQLException {
    validateColumnIndex(paramInt);
    return this.signed[paramInt - 1];
  }













  
  public int getColumnDisplaySize(int paramInt) throws SQLException {
    validateColumnIndex(paramInt);
    return this.columnDisplaySize[paramInt - 1];
  }













  
  public String getColumnLabel(int paramInt) throws SQLException {
    validateColumnIndex(paramInt);
    return this.columnLabel[paramInt - 1];
  }












  
  public String getColumnName(int paramInt) throws SQLException {
    validateColumnIndex(paramInt);
    return this.columnName[paramInt - 1];
  }












  
  public String getSchemaName(int paramInt) throws SQLException {
    validateColumnIndex(paramInt);
    return this.schemaName[paramInt - 1];
  }












  
  public int getPrecision(int paramInt) throws SQLException {
    validateColumnIndex(paramInt);
    return this.precision[paramInt - 1];
  }












  
  public int getScale(int paramInt) throws SQLException {
    validateColumnIndex(paramInt);
    return this.scale[paramInt - 1];
  }












  
  public String getTableName(int paramInt) throws SQLException {
    validateColumnIndex(paramInt);
    return this.tableName[paramInt - 1];
  }












  
  public String getCatalogName(int paramInt) throws SQLException {
    validateColumnIndex(paramInt);
    return this.catalogName[paramInt - 1];
  }













  
  public int getColumnType(int paramInt) throws SQLException {
    validateColumnIndex(paramInt);
    return this.columnType[paramInt - 1];
  }













  
  public String getColumnTypeName(int paramInt) throws SQLException {
    validateColumnIndex(paramInt);
    return this.columnTypeName[paramInt - 1];
  }












  
  public boolean isReadOnly(int paramInt) throws SQLException {
    validateColumnIndex(paramInt);
    return this.readOnly[paramInt - 1];
  }












  
  public boolean isWritable(int paramInt) throws SQLException {
    validateColumnIndex(paramInt);
    return this.writable[paramInt - 1];
  }












  
  public boolean isDefinitelyWritable(int paramInt) throws SQLException {
    validateColumnIndex(paramInt);
    return this.definatelyWritable[paramInt - 1];
  }






















  
  public String getColumnClassName(int paramInt) throws SQLException {
    validateColumnIndex(paramInt);
    return this.columnClassName[paramInt - 1];
  }









  
  public void setAutoIncrement(int paramInt, boolean paramBoolean) throws SQLException {
    validateColumnIndex(paramInt);
    this.autoIncrement[paramInt - 1] = paramBoolean;
  }






  
  public void setCaseSensitive(int paramInt, boolean paramBoolean) throws SQLException {
    validateColumnIndex(paramInt);
    this.caseSensitive[paramInt - 1] = paramBoolean;
  }






  
  public void setCatalogName(int paramInt, String paramString) throws SQLException {
    validateColumnIndex(paramInt);
    this.catalogName[paramInt - 1] = paramString;
  }






  
  public void setColumnCount(int paramInt) throws SQLException {
    this.columnCount = paramInt;
  }






  
  public void setColumnDisplaySize(int paramInt1, int paramInt2) throws SQLException {
    validateColumnIndex(paramInt1);
    this.columnDisplaySize[paramInt1 - 1] = paramInt2;
  }






  
  public void setColumnLabel(int paramInt, String paramString) throws SQLException {
    validateColumnIndex(paramInt);
    this.columnLabel[paramInt - 1] = paramString;
  }






  
  public void setColumnName(int paramInt, String paramString) throws SQLException {
    validateColumnIndex(paramInt);
    this.columnName[paramInt - 1] = paramString;
  }






  
  public void setColumnType(int paramInt1, int paramInt2) throws SQLException {
    validateColumnIndex(paramInt1);
    this.columnType[paramInt1 - 1] = paramInt2;
  }






  
  public void setColumnTypeName(int paramInt, String paramString) throws SQLException {
    validateColumnIndex(paramInt);
    this.columnTypeName[paramInt - 1] = paramString;
  }






  
  public void setCurrency(int paramInt, boolean paramBoolean) throws SQLException {
    validateColumnIndex(paramInt);
    this.currency[paramInt - 1] = paramBoolean;
  }






  
  public void setNullable(int paramInt1, int paramInt2) throws SQLException {
    validateColumnIndex(paramInt1);
    this.nullable[paramInt1 - 1] = paramInt2;
  }






  
  public void setPrecision(int paramInt1, int paramInt2) throws SQLException {
    validateColumnIndex(paramInt1);
    this.precision[paramInt1 - 1] = paramInt2;
  }






  
  public void setScale(int paramInt1, int paramInt2) throws SQLException {
    validateColumnIndex(paramInt1);
    this.scale[paramInt1 - 1] = paramInt2;
  }






  
  public void setSchemaName(int paramInt, String paramString) throws SQLException {
    validateColumnIndex(paramInt);
    this.schemaName[paramInt - 1] = paramString;
  }






  
  public void setSearchable(int paramInt, boolean paramBoolean) throws SQLException {
    validateColumnIndex(paramInt);
    this.searchable[paramInt - 1] = paramBoolean;
  }






  
  public void setSigned(int paramInt, boolean paramBoolean) throws SQLException {
    validateColumnIndex(paramInt);
    this.signed[paramInt - 1] = paramBoolean;
  }






  
  public void setTableName(int paramInt, String paramString) throws SQLException {
    validateColumnIndex(paramInt);
    this.tableName[paramInt - 1] = paramString;
  }
















  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
