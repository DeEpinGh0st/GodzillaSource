package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;

public interface OracleCloseCallback {
  void beforeClose(OracleConnection paramOracleConnection, Object paramObject);
  
  void afterClose(Object paramObject);
}
