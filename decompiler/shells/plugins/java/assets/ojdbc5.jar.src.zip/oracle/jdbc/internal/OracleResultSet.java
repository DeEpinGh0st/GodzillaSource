package oracle.jdbc.internal;

import java.sql.SQLException;
import oracle.jdbc.OracleResultSet;

public interface OracleResultSet extends OracleResultSet {
  void closeStatementOnClose() throws SQLException;
}
