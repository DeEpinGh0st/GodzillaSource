package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.OracleResultSetMetaData;
import oracle.jdbc.oracore.OracleType;
import oracle.jdbc.oracore.OracleTypeADT;





























































































class T4CTTIdcb
  extends T4CTTIMsg
{
  static final int DCBRXFR = 1;
  static final int DCBFIOT = 2;
  static final int DCBFHAVECOOKIE = 4;
  static final int DCBFNEWCOOKIE = 8;
  static final int DCBFREM = 16;
  int numuds;
  int colOffset;
  byte[] ignoreBuff;
  OracleStatement statement = null;


  
  T4CTTIdcb(T4CConnection paramT4CConnection) {
    super(paramT4CConnection, (byte)16);
    
    this.ignoreBuff = new byte[40];
  }



  
  void init(OracleStatement paramOracleStatement, int paramInt) {
    this.statement = paramOracleStatement;
    this.colOffset = paramInt;
  }






  
  Accessor[] receive(Accessor[] paramArrayOfAccessor) throws SQLException, IOException {
    short s = this.meg.unmarshalUB1();
    
    if (this.ignoreBuff.length < s) {
      this.ignoreBuff = new byte[s];
    }
    this.meg.unmarshalNBytes(this.ignoreBuff, 0, s);
    
    int i = (int)this.meg.unmarshalUB4();
    
    paramArrayOfAccessor = receiveCommon(paramArrayOfAccessor, false);
    
    return paramArrayOfAccessor;
  }




  
  Accessor[] receiveFromRefCursor(Accessor[] paramArrayOfAccessor) throws SQLException, IOException {
    short s = this.meg.unmarshalUB1();
    int i = (int)this.meg.unmarshalUB4();
    
    paramArrayOfAccessor = receiveCommon(paramArrayOfAccessor, false);
    
    return paramArrayOfAccessor;
  }





  
  Accessor[] receiveCommon(Accessor[] paramArrayOfAccessor, boolean paramBoolean) throws SQLException, IOException {
    if (paramBoolean) {
      this.numuds = this.meg.unmarshalUB2();
    } else {
      
      this.numuds = (int)this.meg.unmarshalUB4();
      if (this.numuds > 0)
      {

        
        short s = this.meg.unmarshalUB1();
      }
    } 
    
    if (this.statement.needToPrepareDefineBuffer)
    {

      
      if (paramArrayOfAccessor == null || paramArrayOfAccessor.length != this.numuds + this.colOffset) {
        
        Accessor[] arrayOfAccessor = new Accessor[this.numuds + this.colOffset];
        if (paramArrayOfAccessor != null && paramArrayOfAccessor.length == this.colOffset)
        {
          System.arraycopy(paramArrayOfAccessor, 0, arrayOfAccessor, 0, this.colOffset);
        }
        paramArrayOfAccessor = arrayOfAccessor;
      } 
    }
    
    T4C8TTIuds t4C8TTIuds = new T4C8TTIuds((T4CConnection)this.statement.connection);
    
    long l = this.statement.checkSum;
    for (byte b = 0; b < this.numuds; b++) {
      
      t4C8TTIuds.unmarshal();
      String str = this.meg.conv.CharBytesToString(t4C8TTIuds.getColumName(), t4C8TTIuds.getColumNameByteLength());

      
      if (this.statement.needToPrepareDefineBuffer)
        l = fillupAccessors(paramArrayOfAccessor, this.colOffset + b, t4C8TTIuds, str, l); 
      this.statement.checkSum = l;
    } 
    
    if (!paramBoolean) {

      
      byte[] arrayOfByte = this.meg.unmarshalDALC();

      
      if (this.connection.getTTCVersion() >= 3) {
        
        int i = (int)this.meg.unmarshalUB4();
        int j = (int)this.meg.unmarshalUB4();

        
        if (this.connection.getTTCVersion() >= 4) {
          
          int k = (int)this.meg.unmarshalUB4();
          int m = (int)this.meg.unmarshalUB4();
          
          if (this.connection.getTTCVersion() >= 5)
          {



            
            byte[] arrayOfByte1 = this.meg.unmarshalDALC();
          }
        } 
      } 
    } 



















    
    if (this.statement.needToPrepareDefineBuffer)
    {



      
      if (!paramBoolean) {
        
        this.statement.rowPrefetchInLastFetch = -1;
        this.statement.describedWithNames = true;
        this.statement.described = true;
        this.statement.numberOfDefinePositions = this.numuds;
        this.statement.accessors = paramArrayOfAccessor;



        
        this.statement.prepareAccessors();

        
        this.statement.allocateTmpByteArray();
      } 
    }
    
    return paramArrayOfAccessor;
  }






  
  long fillupAccessors(Accessor[] paramArrayOfAccessor, int paramInt, T4C8TTIuds paramT4C8TTIuds, String paramString, long paramLong) throws SQLException {
    int j;
    short s;
    int[] arrayOfInt1 = this.statement.definedColumnType;
    int[] arrayOfInt2 = this.statement.definedColumnSize;
    int[] arrayOfInt3 = this.statement.definedColumnFormOfUse;
    byte b = this.statement.sqlObject.includeRowid ? 1 : 0;

    
    String str1 = null;
    String str2 = null;
    String str3 = null;





    
    int k = 0;
    int m = 0;
    int n = 0;



    
    if (paramInt >= b) {
      
      int i1 = paramInt - b;
      if (arrayOfInt1 != null && arrayOfInt1.length > i1 && arrayOfInt1[i1] != 0)
      {
        
        k = arrayOfInt1[i1];
      }
      if (arrayOfInt2 != null && arrayOfInt2.length > i1 && arrayOfInt2[i1] > 0)
      {
        
        m = arrayOfInt2[i1];
      }
      if (arrayOfInt3 != null && arrayOfInt3.length > i1 && arrayOfInt3[i1] > 0)
      {
        
        n = arrayOfInt3[i1];
      }
    } 
    int i = paramT4C8TTIuds.udsoac.oacmxl;
    
    switch (paramT4C8TTIuds.udsoac.oacdty) {











      
      case 96:
        if (paramT4C8TTIuds.udsoac.oacmxlc != 0 && paramT4C8TTIuds.udsoac.oacmxlc < i)
        {



          
          i = 2 * paramT4C8TTIuds.udsoac.oacmxlc;
        }


        
        j = i;



        
        if ((k == 1 || k == 12) && m > 0 && m < i)
        {


          
          j = m;
        }
        paramArrayOfAccessor[paramInt] = new T4CCharAccessor(this.statement, j, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, i, k, m, this.meg);













        
        if ((paramT4C8TTIuds.udsoac.oacfl2 & 0x1000) == 4096 || paramT4C8TTIuds.udsoac.oacmxlc != 0)
        {
          paramArrayOfAccessor[paramInt].setDisplaySize(paramT4C8TTIuds.udsoac.oacmxlc);
        }
        break;

      
      case 2:
        paramArrayOfAccessor[paramInt] = new T4CNumberAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
        break;















      
      case 1:
        if (paramT4C8TTIuds.udsoac.oacmxlc != 0 && paramT4C8TTIuds.udsoac.oacmxlc < i) {
          i = 2 * paramT4C8TTIuds.udsoac.oacmxlc;
        }
        j = i;
        
        if ((k == 1 || k == 12) && m > 0 && m < i)
        {

          
          j = m;
        }
        paramArrayOfAccessor[paramInt] = new T4CVarcharAccessor(this.statement, j, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, i, k, m, this.meg);













        
        if ((paramT4C8TTIuds.udsoac.oacfl2 & 0x1000) == 4096 || paramT4C8TTIuds.udsoac.oacmxlc != 0)
        {
          paramArrayOfAccessor[paramInt].setDisplaySize(paramT4C8TTIuds.udsoac.oacmxlc);
        }
        break;
      
      case 8:
        if ((k == 1 || k == 12) && this.connection.versionNumber >= 9000 && m < 4001) {












          
          if (m > 0) {
            j = m;
          }
          else {
            
            j = 4000;
          } 



          
          i = -1;
          paramArrayOfAccessor[paramInt] = new T4CVarcharAccessor(this.statement, j, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, i, k, m, this.meg);












          
          (paramArrayOfAccessor[paramInt]).describeType = 8;

          
          break;
        } 

        
        i = 0;
        
        paramArrayOfAccessor[paramInt] = new T4CLongAccessor(this.statement, paramInt + 1, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
        break;















      
      case 6:
        paramArrayOfAccessor[paramInt] = new T4CVarnumAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
        break;













      
      case 100:
        paramArrayOfAccessor[paramInt] = new T4CBinaryFloatAccessor(this.statement, 4, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
        break;


















      
      case 101:
        paramArrayOfAccessor[paramInt] = new T4CBinaryDoubleAccessor(this.statement, 8, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
        break;














      
      case 23:
        paramArrayOfAccessor[paramInt] = new T4CRawAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
        break;














      
      case 24:
        if (k == -2 && m < 2001 && this.connection.versionNumber >= 9000) {





          
          i = -1;
          paramArrayOfAccessor[paramInt] = new T4CRawAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);











          
          (paramArrayOfAccessor[paramInt]).describeType = 24;
          break;
        } 
        paramArrayOfAccessor[paramInt] = new T4CLongRawAccessor(this.statement, paramInt + 1, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
        break;














      
      case 11:
      case 104:
      case 208:
        paramArrayOfAccessor[paramInt] = new T4CRowidAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);












        
        if (paramT4C8TTIuds.udsoac.oacdty == 208) {
          (paramArrayOfAccessor[paramInt]).describeType = 208;
        }
        break;
      
      case 102:
        paramArrayOfAccessor[paramInt] = new T4CResultSetAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
        break;













      
      case 12:
        paramArrayOfAccessor[paramInt] = new T4CDateAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
        break;













      
      case 113:
        if (k == -4 && this.connection.versionNumber >= 9000) {



          
          paramArrayOfAccessor[paramInt] = new T4CLongRawAccessor(this.statement, paramInt + 1, 2147483647, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);













          
          (paramArrayOfAccessor[paramInt]).describeType = 113; break;
        } 
        if (k == -3 && this.connection.versionNumber >= 9000) {



          
          paramArrayOfAccessor[paramInt] = new T4CRawAccessor(this.statement, 4000, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);











          
          (paramArrayOfAccessor[paramInt]).describeType = 113;
          
          break;
        } 
        paramArrayOfAccessor[paramInt] = new T4CBlobAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);












        
        if (this.connection.useLobPrefetch && k == 2004) {
          
          (paramArrayOfAccessor[paramInt]).lobPrefetchSizeForThisColumn = m;
          
          break;
        } 
        (paramArrayOfAccessor[paramInt]).lobPrefetchSizeForThisColumn = -1;
        break;

      
      case 112:
        s = 1;
        if (n != 0) {
          s = (short)n;
        }
        if (k == -1 && this.connection.versionNumber >= 9000) {






          
          i = 0;
          paramArrayOfAccessor[paramInt] = new T4CLongAccessor(this.statement, paramInt + 1, 2147483647, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, s, k, m, this.meg);














          
          (paramArrayOfAccessor[paramInt]).describeType = 112; break;
        } 
        if ((k == 12 || k == 1) && this.connection.versionNumber >= 9000) {







          
          j = 4000;
          if (m > 0 && m < j)
          {
            j = m;
          }
          paramArrayOfAccessor[paramInt] = new T4CVarcharAccessor(this.statement, j, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, s, 4000, k, m, this.meg);













          
          (paramArrayOfAccessor[paramInt]).describeType = 112;
          break;
        } 
        paramArrayOfAccessor[paramInt] = new T4CClobAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);











        
        if (this.connection.useLobPrefetch && k == 2005) {







          
          (paramArrayOfAccessor[paramInt]).lobPrefetchSizeForThisColumn = m; break;
        } 
        (paramArrayOfAccessor[paramInt]).lobPrefetchSizeForThisColumn = -1;
        break;

      
      case 114:
        paramArrayOfAccessor[paramInt] = new T4CBfileAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);











        
        if (this.connection.useLobPrefetch && k == -13) {

          
          (paramArrayOfAccessor[paramInt]).lobPrefetchSizeForThisColumn = m; break;
        } 
        (paramArrayOfAccessor[paramInt]).lobPrefetchSizeForThisColumn = -1;
        break;
      
      case 109:
        str1 = this.meg.conv.CharBytesToString(paramT4C8TTIuds.getTypeName(), paramT4C8TTIuds.getTypeCharLength());


        
        str2 = this.meg.conv.CharBytesToString(paramT4C8TTIuds.getSchemaName(), paramT4C8TTIuds.getSchemaCharLength());

        
        str3 = str2 + "." + str1;
        
        paramArrayOfAccessor[paramInt] = new T4CNamedTypeAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, str3, k, m, this.meg);
        break;














      
      case 111:
        str1 = this.meg.conv.CharBytesToString(paramT4C8TTIuds.getTypeName(), paramT4C8TTIuds.getTypeCharLength());


        
        str2 = this.meg.conv.CharBytesToString(paramT4C8TTIuds.getSchemaName(), paramT4C8TTIuds.getSchemaCharLength());

        
        str3 = str2 + "." + str1;
        
        paramArrayOfAccessor[paramInt] = new T4CRefTypeAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, str3, k, m, this.meg);
        break;














      
      case 180:
        paramArrayOfAccessor[paramInt] = new T4CTimestampAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
        break;













      
      case 181:
        paramArrayOfAccessor[paramInt] = new T4CTimestamptzAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
        break;













      
      case 231:
        paramArrayOfAccessor[paramInt] = new T4CTimestampltzAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
        break;













      
      case 182:
        paramArrayOfAccessor[paramInt] = new T4CIntervalymAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
        break;













      
      case 183:
        paramArrayOfAccessor[paramInt] = new T4CIntervaldsAccessor(this.statement, i, paramT4C8TTIuds.udsnull, paramT4C8TTIuds.udsoac.oacflg, paramT4C8TTIuds.udsoac.oacpre, paramT4C8TTIuds.udsoac.oacscl, paramT4C8TTIuds.udsoac.oacfl2, paramT4C8TTIuds.udsoac.oacmal, paramT4C8TTIuds.udsoac.oaccsfrm, k, m, this.meg);
        break;















      
      default:
        paramArrayOfAccessor[paramInt] = null;
        break;
    } 


    
    if (paramT4C8TTIuds.udsoac.oactoid.length > 0) {
      
      (paramArrayOfAccessor[paramInt]).internalOtype = (OracleType)new OracleTypeADT(paramT4C8TTIuds.udsoac.oactoid, paramT4C8TTIuds.udsoac.oacvsn, paramT4C8TTIuds.udsoac.oaccsi, paramT4C8TTIuds.udsoac.oaccsfrm, str2 + "." + str1);
    
    }
    else {
      
      (paramArrayOfAccessor[paramInt]).internalOtype = null;
    } 
    
    (paramArrayOfAccessor[paramInt]).columnName = paramString;

    
    (paramArrayOfAccessor[paramInt]).securityAttribute = OracleResultSetMetaData.SecurityAttribute.NONE;
    
    if ((paramT4C8TTIuds.udsflg & 0x1) != 0) {
      (paramArrayOfAccessor[paramInt]).securityAttribute = OracleResultSetMetaData.SecurityAttribute.ENABLED;
    }
    else if ((paramT4C8TTIuds.udsflg & 0x2) != 0) {
      (paramArrayOfAccessor[paramInt]).securityAttribute = OracleResultSetMetaData.SecurityAttribute.UNKNOWN;
    } 


    
    if (paramT4C8TTIuds.udsoac.oacmxl == 0) {
      (paramArrayOfAccessor[paramInt]).isNullByDescribe = true;
    }
    (paramArrayOfAccessor[paramInt]).udskpos = paramT4C8TTIuds.getKernelPosition();















    
    if (this.connection.calculateChecksum) {
      
      paramLong = CRC64.updateChecksum(paramLong, paramT4C8TTIuds.udsoac.oacdty);
      
      paramLong = CRC64.updateChecksum(paramLong, paramT4C8TTIuds.udsoac.oacmxl);
      
      paramLong = CRC64.updateChecksum(paramLong, paramT4C8TTIuds.udsoac.oacpre);
      
      paramLong = CRC64.updateChecksum(paramLong, paramT4C8TTIuds.udsoac.oacscl);
      
      paramLong = CRC64.updateChecksum(paramLong, paramT4C8TTIuds.udsoac.oaccsfrm);
      
      if (str1 != null)
      {
        paramLong = CRC64.updateChecksum(paramLong, str2 + "." + str1);
      }

      
      paramLong = CRC64.updateChecksum(paramLong, paramString);
    } 
    
    return paramLong;
  }




  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
