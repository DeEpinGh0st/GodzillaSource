package oracle.jdbc.driver;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import oracle.sql.OPAQUE;

































public class ClassRef
{
  static final XMLTypeClassRef XMLTYPE = XMLTypeClassRef.newInstance();
  public static final Locale LOCALE = Locale.newInstance();


  
  private final String className;



  
  static final ClassRef newInstance(String paramString) throws ClassNotFoundException {
    return new ClassRef(paramString);
  }















  
  private ClassRef(String paramString) throws ClassNotFoundException {
    this.className = paramString;
  }















  
  Class get() {
    try {
      return Class.forName(this.className, true, Thread.currentThread().getContextClassLoader());
    }
    catch (ClassNotFoundException classNotFoundException) {
      NoClassDefFoundError noClassDefFoundError = new NoClassDefFoundError(classNotFoundException.getMessage());
      noClassDefFoundError.initCause(classNotFoundException);
      throw noClassDefFoundError;
    } 
  }

  
  static class XMLTypeClassRef
    extends ClassRef
  {
    protected final Method CREATEXML;
    
    static final XMLTypeClassRef newInstance() {
      
      try { return new XMLTypeClassRef(); }
      
      catch (ClassNotFoundException classNotFoundException) {  }
      catch (NoClassDefFoundError noClassDefFoundError) {}
      return null;
    }
    
    private XMLTypeClassRef() throws ClassNotFoundException {
      super("oracle.xdb.XMLType");
      Method method = null;
      try {
        method = get().getDeclaredMethod("createXML", new Class[] { OPAQUE.class });
      }
      catch (NoSuchMethodException noSuchMethodException) {}
      this.CREATEXML = method;
    }

    
    OPAQUE createXML(OPAQUE param1OPAQUE) throws SQLException {
      get();
      
      try { return (OPAQUE)this.CREATEXML.invoke(null, new Object[] { param1OPAQUE }); }
      
      catch (IllegalAccessException illegalAccessException) {  }
      catch (InvocationTargetException invocationTargetException) {}
      return null;
    }
  }






  
  public static class LocaleCategoryClassRef
    extends ClassRef
  {
    static final LocaleCategoryClassRef newInstance() {
      
      try { return new LocaleCategoryClassRef(); }
      
      catch (ClassNotFoundException classNotFoundException) {  }
      catch (NoClassDefFoundError noClassDefFoundError) {}
      return null;
    }
    
    private LocaleCategoryClassRef() throws ClassNotFoundException {
      super("java.util.Locale$Category");
    }
  }


  
  public static class Locale
  {
    protected final Method localeJDK7getDefault;

    
    protected final Object localeCategoryEnumFORMAT;


    
    static final Locale newInstance() {
      try {
        return new Locale();
      }
      catch (Exception exception) {
        return null;
      } 
    }
    
    private Locale() {
      ClassRef.LocaleCategoryClassRef localeCategoryClassRef = ClassRef.LocaleCategoryClassRef.newInstance();
      Method method = null;
      Object object = null;
      
      if (localeCategoryClassRef != null) {
        
        try {

          
          Object[] arrayOfObject = localeCategoryClassRef.get().getEnumConstants();
          for (Object object1 : arrayOfObject) { if (((Enum)object1).name() == "FORMAT") { object = object1; break; }  }
           method = java.util.Locale.class.getDeclaredMethod("getDefault", new Class[] { localeCategoryClassRef.get() });
        }
        catch (Throwable throwable) {
          method = null;
          object = null;
        } 
      }
      this.localeJDK7getDefault = method;
      this.localeCategoryEnumFORMAT = object;
    }
    
    public java.util.Locale getDefault() {
      
      try { if (this.localeJDK7getDefault == null) {
          return java.util.Locale.getDefault();
        }
        return (java.util.Locale)this.localeJDK7getDefault.invoke(null, new Object[] { this.localeCategoryEnumFORMAT }); }
      
      catch (IllegalAccessException illegalAccessException) {  }
      catch (InvocationTargetException invocationTargetException) {}
      return null;
    }
  }

  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
