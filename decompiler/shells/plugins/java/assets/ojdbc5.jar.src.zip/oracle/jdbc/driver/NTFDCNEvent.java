package oracle.jdbc.driver;

import java.io.IOException;
import java.nio.ByteBuffer;
import oracle.jdbc.dcn.DatabaseChangeEvent;
import oracle.jdbc.dcn.QueryChangeDescription;
import oracle.jdbc.dcn.TableChangeDescription;







































class NTFDCNEvent
  extends DatabaseChangeEvent
{
  private int notifVersion = 0;
  private int notifRegid = 0;
  private DatabaseChangeEvent.EventType eventType;
  private DatabaseChangeEvent.AdditionalEventType additionalEventType = DatabaseChangeEvent.AdditionalEventType.NONE;
  private String databaseName = null;
  private byte[] notifXid = new byte[8];
  private int notifScn1 = 0;
  private int notifScn2 = 0;
  
  private int numberOfTables = 0;
  private NTFDCNTableChanges[] tcdesc = null;

  
  private int numberOfQueries = 0;
  private NTFDCNQueryChanges[] qdesc = null;
  
  private long registrationId;
  
  private NTFConnection conn;
  
  private int csid;
  
  private boolean isReady = false;
  
  private ByteBuffer dataBuffer;
  private boolean isDeregistrationEvent = false;
  private short databaseVersion;
  
  NTFDCNEvent(NTFConnection paramNTFConnection, short paramShort) throws IOException, InterruptedException {
    super(paramNTFConnection);
    
    this.conn = paramNTFConnection;
    this.csid = this.conn.charset.getOracleId();

    
    int i = this.conn.readInt();
    byte[] arrayOfByte = new byte[i];
    this.conn.readBuffer(arrayOfByte, 0, i);
    this.dataBuffer = ByteBuffer.wrap(arrayOfByte);
    this.databaseVersion = paramShort;
  }




  
  private void initEvent() {
    byte b1 = this.dataBuffer.get();
    int i = this.dataBuffer.getInt();
    byte[] arrayOfByte1 = new byte[i];
    this.dataBuffer.get(arrayOfByte1, 0, i);


    
    String str = null;
    try {
      str = new String(arrayOfByte1, "UTF-8");
    } catch (Exception exception) {}
    
    str = str.replaceFirst("CHNF", "");
    this.registrationId = Long.parseLong(str);

    
    byte b2 = this.dataBuffer.get();
    int j = this.dataBuffer.getInt();
    byte[] arrayOfByte2 = new byte[j];
    this.dataBuffer.get(arrayOfByte2, 0, j);

    
    byte b3 = this.dataBuffer.get();
    int k = this.dataBuffer.getInt();
    if (this.dataBuffer.hasRemaining()) {


      
      this.notifVersion = this.dataBuffer.getShort();
      this.notifRegid = this.dataBuffer.getInt();
      this.eventType = DatabaseChangeEvent.EventType.getEventType(this.dataBuffer.getInt());
      short s = this.dataBuffer.getShort();
      byte[] arrayOfByte = new byte[s];
      this.dataBuffer.get(arrayOfByte, 0, s);
      try {
        this.databaseName = new String(arrayOfByte, "UTF-8");
      } catch (Exception exception) {}






      
      this.dataBuffer.get(this.notifXid);
      
      this.notifScn1 = this.dataBuffer.getInt();
      this.notifScn2 = this.dataBuffer.getShort();
      
      if (this.eventType == DatabaseChangeEvent.EventType.OBJCHANGE) {
        
        this.numberOfTables = this.dataBuffer.getShort();
        this.tcdesc = new NTFDCNTableChanges[this.numberOfTables];
        for (byte b = 0; b < this.tcdesc.length; b++) {
          this.tcdesc[b] = new NTFDCNTableChanges(this.dataBuffer, this.csid);
        }
      } else if (this.eventType == DatabaseChangeEvent.EventType.QUERYCHANGE) {
        
        this.numberOfQueries = this.dataBuffer.getShort();
        this.qdesc = new NTFDCNQueryChanges[this.numberOfQueries];







        
        for (byte b = 0; b < this.numberOfQueries; b++)
        {
          this.qdesc[b] = new NTFDCNQueryChanges(this.dataBuffer, this.csid);
        }
      } 
    } 
    this.isReady = true;
  }




  
  public String getDatabaseName() {
    if (!this.isReady)
      initEvent(); 
    return this.databaseName;
  }



  
  public TableChangeDescription[] getTableChangeDescription() {
    if (!this.isReady)
      initEvent(); 
    if (this.eventType == DatabaseChangeEvent.EventType.OBJCHANGE)
    {
      return (TableChangeDescription[])this.tcdesc;
    }
    
    return null;
  }



  
  public QueryChangeDescription[] getQueryChangeDescription() {
    if (!this.isReady)
      initEvent(); 
    if (this.eventType == DatabaseChangeEvent.EventType.QUERYCHANGE)
    {
      return (QueryChangeDescription[])this.qdesc;
    }
    
    return null;
  }



  
  public byte[] getTransactionId() {
    if (!this.isReady)
      initEvent(); 
    return this.notifXid;
  }

  
  public String getTransactionId(boolean paramBoolean) {
    int i;
    int j;
    long l;
    if (!this.isReady) {
      initEvent();
    }
    
    if (!paramBoolean) {



      
      i = (this.notifXid[0] & 0xFF) << 8 | this.notifXid[1] & 0xFF;

      
      j = (this.notifXid[2] & 0xFF) << 8 | this.notifXid[3] & 0xFF;

      
      l = (((this.notifXid[4] & 0xFF) << 24 | (this.notifXid[5] & 0xFF) << 16 | (this.notifXid[6] & 0xFF) << 8 | this.notifXid[7] & 0xFF) & 0xFFFFFFFF);


    
    }
    else {


      
      i = (this.notifXid[1] & 0xFF) << 8 | this.notifXid[0] & 0xFF;
      
      j = (this.notifXid[3] & 0xFF) << 8 | this.notifXid[2] & 0xFF;
      
      l = (((this.notifXid[7] & 0xFF) << 24 | (this.notifXid[6] & 0xFF) << 16 | (this.notifXid[5] & 0xFF) << 8 | this.notifXid[4] & 0xFF) & 0xFFFFFFFF);
    } 




    
    return "" + i + "." + j + "." + l;
  }





  
  void setEventType(DatabaseChangeEvent.EventType paramEventType) throws IOException {
    if (!this.isReady)
      initEvent(); 
    this.eventType = paramEventType;
    if (this.eventType == DatabaseChangeEvent.EventType.DEREG) {
      this.isDeregistrationEvent = true;
    }
  }


  
  void setAdditionalEventType(DatabaseChangeEvent.AdditionalEventType paramAdditionalEventType) {
    this.additionalEventType = paramAdditionalEventType;
  }



  
  public DatabaseChangeEvent.EventType getEventType() {
    if (!this.isReady)
      initEvent(); 
    return this.eventType;
  }



  
  public DatabaseChangeEvent.AdditionalEventType getAdditionalEventType() {
    return this.additionalEventType;
  }





  
  boolean isDeregistrationEvent() {
    return this.isDeregistrationEvent;
  }



  
  public String getConnectionInformation() {
    return this.conn.connectionDescription;
  }



  
  public int getRegistrationId() {
    if (!this.isReady)
      initEvent(); 
    return (int)this.registrationId;
  }


  
  public long getRegId() {
    if (!this.isReady)
      initEvent(); 
    return this.registrationId;
  }



  
  public String toString() {
    if (!this.isReady)
      initEvent(); 
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("Connection information  : " + this.conn.connectionDescription + "\n");
    stringBuffer.append("Registration ID         : " + this.registrationId + "\n");
    stringBuffer.append("Notification version    : " + this.notifVersion + "\n");
    stringBuffer.append("Event type              : " + this.eventType + "\n");
    if (this.additionalEventType != DatabaseChangeEvent.AdditionalEventType.NONE)
      stringBuffer.append("Additional event type   : " + this.additionalEventType + "\n"); 
    if (this.databaseName != null) {
      stringBuffer.append("Database name           : " + this.databaseName + "\n");
    }

    
    TableChangeDescription[] arrayOfTableChangeDescription = getTableChangeDescription();
    if (arrayOfTableChangeDescription != null) {
      
      stringBuffer.append("Table Change Description (length=" + this.numberOfTables + ")\n");
      for (byte b = 0; b < arrayOfTableChangeDescription.length; b++)
        stringBuffer.append(arrayOfTableChangeDescription[b].toString()); 
    } 
    QueryChangeDescription[] arrayOfQueryChangeDescription = getQueryChangeDescription();
    if (arrayOfQueryChangeDescription != null) {
      
      stringBuffer.append("Query Change Description (length=" + this.numberOfQueries + ")\n");
      for (byte b = 0; b < arrayOfQueryChangeDescription.length; b++) {
        stringBuffer.append(arrayOfQueryChangeDescription[b].toString());
      }
    } 
    return stringBuffer.toString();
  }

  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
