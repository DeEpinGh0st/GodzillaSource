package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormatSymbols;
import java.util.TimeZone;































class T4CDateAccessor
  extends DateAccessor
{
  T4CMAREngine mare;
  boolean underlyingLongRaw = false;
  final int[] meta;
  
  T4CDateAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException {
    super(paramOracleStatement, paramInt1, paramShort, paramInt2, paramBoolean);






























































    
    this.meta = new int[1]; this.mare = paramT4CMAREngine; } T4CDateAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, (paramInt1 == -1) ? paramInt8 : paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort); this.meta = new int[1];
    this.mare = paramT4CMAREngine;
    if (paramOracleStatement != null && paramOracleStatement.implicitDefineForLobPrefetchDone) {
      this.definedColumnType = 0;
      this.definedColumnSize = 0;
    } else {
      this.definedColumnType = paramInt7;
      this.definedColumnSize = paramInt8;
    } 
    if (paramInt1 == -1) {
      this.underlyingLongRaw = true;
    } }

  
  boolean unmarshalOneRow() throws SQLException, IOException {
    if (this.isUseLess) {
      
      this.lastRowProcessed++;
      
      return false;
    } 


    
    if (this.rowSpaceIndicator == null) {


      
      byte[] arrayOfByte = new byte[16000];
      
      this.mare.unmarshalCLR(arrayOfByte, 0, this.meta);
      processIndicator(this.meta[0]);
      
      this.lastRowProcessed++;
      
      return false;
    } 

    
    int i = this.indicatorIndex + this.lastRowProcessed;
    int j = this.lengthIndex + this.lastRowProcessed;


    
    if (this.isNullByDescribe) {
      
      this.rowSpaceIndicator[i] = -1;
      this.rowSpaceIndicator[j] = 0;
      this.lastRowProcessed++;
      
      if (this.statement.connection.versionNumber < 9200) {
        processIndicator(0);
      }
      return false;
    } 
    
    int k = this.columnIndex + this.lastRowProcessed * this.byteLength;


    
    this.mare.unmarshalCLR(this.rowSpaceByte, k, this.meta, this.byteLength);
    
    processIndicator(this.meta[0]);
    
    if (this.meta[0] == 0) {


      
      this.rowSpaceIndicator[i] = -1;
      this.rowSpaceIndicator[j] = 0;
    }
    else {
      
      this.rowSpaceIndicator[j] = (short)this.meta[0];
      this.rowSpaceIndicator[i] = 0;
    } 
    
    this.lastRowProcessed++;
    
    return false;
  }





  
  void copyRow() throws SQLException, IOException {
    int i;
    if (this.lastRowProcessed == 0) {
      i = this.statement.rowPrefetchInLastFetch - 1;
    } else {
      i = this.lastRowProcessed - 1;
    } 
    
    int j = this.columnIndex + this.lastRowProcessed * this.byteLength;
    int k = this.columnIndex + i * this.byteLength;
    int m = this.indicatorIndex + this.lastRowProcessed;
    int n = this.indicatorIndex + i;
    int i1 = this.lengthIndex + this.lastRowProcessed;
    int i2 = this.lengthIndex + i;
    short s = this.rowSpaceIndicator[i2];
    int i3 = this.metaDataIndex + this.lastRowProcessed * 1;
    
    int i4 = this.metaDataIndex + i * 1;


    
    this.rowSpaceIndicator[i1] = (short)s;
    this.rowSpaceIndicator[m] = this.rowSpaceIndicator[n];

    
    if (!this.isNullByDescribe)
    {
      System.arraycopy(this.rowSpaceByte, k, this.rowSpaceByte, j, s);
    }


    
    System.arraycopy(this.rowSpaceMetaData, i4, this.rowSpaceMetaData, i3, 1);

    
    this.lastRowProcessed++; } void processIndicator(int paramInt) throws IOException, SQLException {
    if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
      this.mare.unmarshalUB2();
      this.mare.unmarshalUB2();
    } else if (this.statement.connection.versionNumber < 9200) {
      this.mare.unmarshalSB2();
      if (!this.statement.sqlKind.isPlsqlOrCall())
        this.mare.unmarshalSB2(); 
    } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) {
      this.mare.processIndicator((paramInt <= 0), paramInt);
    } 
  } void saveDataFromOldDefineBuffers(byte[] paramArrayOfbyte, char[] paramArrayOfchar, short[] paramArrayOfshort, int paramInt1, int paramInt2) throws SQLException {
    int i = this.columnIndex + (paramInt2 - 1) * this.byteLength;
    
    int j = this.columnIndexLastRow + (paramInt1 - 1) * this.byteLength;
    
    int k = this.indicatorIndex + paramInt2 - 1;
    int m = this.indicatorIndexLastRow + paramInt1 - 1;
    int n = this.lengthIndex + paramInt2 - 1;
    int i1 = this.lengthIndexLastRow + paramInt1 - 1;
    short s = paramArrayOfshort[i1];
    
    this.rowSpaceIndicator[n] = (short)s;
    this.rowSpaceIndicator[k] = paramArrayOfshort[m];

    
    if (s != 0)
    {
      System.arraycopy(paramArrayOfbyte, j, this.rowSpaceByte, i, s);
    }
  }























  
  String toText(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean, String paramString) throws SQLException {
    if (this.definedColumnType == 0 || this.definedColumnType == 91)
    {
      
      return super.toText(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramBoolean, paramString);
    }





    
    String str = (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCDATEFM");
    return nlsFormatToText(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramBoolean, paramString, str);
  }






















  
  private static final String nlsFormatToText(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean, String paramString1, String paramString2) throws SQLException {
    char[] arrayOfChar = (paramString2 + "      ").toCharArray();
    int i = paramString2.length();
    
    StringBuffer stringBuffer = new StringBuffer(i + 25);
    String[] arrayOfString1 = null;
    String[] arrayOfString2 = null;
    TimeZone timeZone = null;

    
    for (byte b = 0; b < i; b++) {
      
      switch (arrayOfChar[b]) {
        
        case 'R':
        case 'r':
          if (arrayOfChar[b + 1] == 'R' || arrayOfChar[b + 1] == 'r') {
            
            if ((arrayOfChar[b + 2] == 'R' || arrayOfChar[b + 2] == 'r') && (arrayOfChar[b + 3] == 'R' || arrayOfChar[b + 3] == 'r')) {

              
              if (paramInt1 < 1000) {
                stringBuffer.append("0" + paramInt1);
              } else if (paramInt1 < 100) {
                stringBuffer.append("00" + paramInt1);
              } else if (paramInt1 < 10) {
                stringBuffer.append("000" + paramInt1);
              } else {
                stringBuffer.append(paramInt1);
              } 
              b += 3;
              
              break;
            } 
            if (paramInt1 >= 100) {
              paramInt1 %= 100;
            }
            if (paramInt1 < 10) {
              stringBuffer.append("0" + paramInt1);
            } else {
              stringBuffer.append(paramInt1);
            } 
            b++;
          } 
          break;

        
        case 'Y':
        case 'y':
          if (arrayOfChar[b + 1] == 'Y' || arrayOfChar[b + 1] == 'y') {
            
            if ((arrayOfChar[b + 2] == 'Y' || arrayOfChar[b + 2] == 'y') && (arrayOfChar[b + 3] == 'Y' || arrayOfChar[b + 3] == 'y')) {

              
              if (paramInt1 < 1000) {
                stringBuffer.append("0" + paramInt1);
              } else if (paramInt1 < 100) {
                stringBuffer.append("00" + paramInt1);
              } else if (paramInt1 < 10) {
                stringBuffer.append("000" + paramInt1);
              } else {
                stringBuffer.append(paramInt1);
              } 
              b += 3;
              
              break;
            } 
            if (paramInt1 >= 100) {
              paramInt1 %= 100;
            }
            if (paramInt1 < 10) {
              stringBuffer.append("0" + paramInt1);
            } else {
              stringBuffer.append(paramInt1);
            } 
            b++;
          } 
          break;

        
        case 'D':
        case 'd':
          if (arrayOfChar[b + 1] == 'D' || arrayOfChar[b + 1] == 'd') {
            
            stringBuffer.append(((paramInt3 < 10) ? "0" : "") + paramInt3);
            b++;
          } 
          break;
        
        case 'M':
        case 'm':
          if (arrayOfChar[b + 1] == 'M' || arrayOfChar[b + 1] == 'm') {
            
            stringBuffer.append(((paramInt2 < 10) ? "0" : "") + paramInt2);
            b++; break;
          } 
          if (arrayOfChar[b + 1] == 'I' || arrayOfChar[b + 1] == 'i') {
            
            stringBuffer.append(((paramInt5 < 10) ? "0" : "") + paramInt5);
            b++; break;
          } 
          if ((arrayOfChar[b + 1] == 'O' || arrayOfChar[b + 1] == 'o') && (arrayOfChar[b + 2] == 'N' || arrayOfChar[b + 2] == 'n')) {

            
            if ((arrayOfChar[b + 3] == 'T' || arrayOfChar[b + 3] == 't') && (arrayOfChar[b + 4] == 'H' || arrayOfChar[b + 4] == 'h')) {


              
              if (arrayOfString2 == null) {
                arrayOfString2 = (new DateFormatSymbols()).getMonths();
              }




              
              if (arrayOfChar[b] == 'm') {

                
                stringBuffer.append(arrayOfString2[paramInt2 - 1].toLowerCase());
              }
              else if (arrayOfChar[b + 1] == 'O') {

                
                stringBuffer.append(arrayOfString2[paramInt2 - 1].toUpperCase());
              
              }
              else {
                
                stringBuffer.append(arrayOfString2[paramInt2 - 1]);
              } 
              b += 4;
              
              break;
            } 
            
            if (arrayOfString1 == null) {
              arrayOfString1 = (new DateFormatSymbols()).getShortMonths();
            }




            
            if (arrayOfChar[b] == 'm') {

              
              stringBuffer.append(arrayOfString1[paramInt2 - 1].toLowerCase());
            }
            else if (arrayOfChar[b + 1] == 'O') {

              
              stringBuffer.append(arrayOfString1[paramInt2 - 1].toUpperCase());
            
            }
            else {
              
              stringBuffer.append(arrayOfString1[paramInt2 - 1]);
            } 
            b += 2;
          } 
          break;

        
        case 'H':
        case 'h':
          if (arrayOfChar[b + 1] == 'H' || arrayOfChar[b + 1] == 'h') {
            
            if (arrayOfChar[b + 2] == '2' || arrayOfChar[b + 3] == '4') {
              
              stringBuffer.append(((paramInt4 < 10) ? "0" : "") + paramInt4);
              b += 3;
              break;
            } 
            if (paramInt4 > 12)
              paramInt4 -= 12; 
            stringBuffer.append(((paramInt4 < 10) ? "0" : "") + paramInt4);
            b++;
          } 
          break;

        
        case 'S':
        case 's':
          if (arrayOfChar[b + 1] == 'S' || arrayOfChar[b + 1] == 's') {
            
            stringBuffer.append(((paramInt6 < 10) ? "0" : "") + paramInt6);
            b++;
            if ((arrayOfChar[b + 1] == 'X' || arrayOfChar[b + 1] == 'x') && (arrayOfChar[b + 2] == 'F' || arrayOfChar[b + 2] == 'f') && (arrayOfChar[b + 3] == 'F' || arrayOfChar[b + 3] == 'f')) {


              
              stringBuffer.append(".");
              b++;
            } 
          } 
          break;

        
        case 'F':
        case 'f':
          if (arrayOfChar[b + 1] == 'F' || arrayOfChar[b + 1] == 'f') {
            
            if (paramInt7 >= 0) {
              
              stringBuffer.append(paramInt7);
            }
            else {
              
              stringBuffer.append(0);
            } 
            b++;
          } 
          break;
        
        case 'T':
        case 't':
          if (arrayOfChar[b + 1] == 'Z' || arrayOfChar[b + 1] == 'z') {
            
            if (arrayOfChar[b + 2] == 'R' || arrayOfChar[b + 2] == 'r') {
              
              if (paramString1.length() > 3 && paramString1.startsWith("GMT")) {
                
                stringBuffer.append(paramString1.substring(3));
              
              }
              else {
                
                stringBuffer.append(paramString1.toUpperCase());
              } 
              b += 2; break;
            }  if (arrayOfChar[b + 2] == 'H' || arrayOfChar[b + 2] == 'h') {
              
              if (timeZone == null)
                timeZone = TimeZone.getTimeZone(paramString1); 
              long l = (timeZone.getRawOffset() / 3600000);
              stringBuffer.append(l);
              b += 2; break;
            }  if (arrayOfChar[b + 2] == 'M' || arrayOfChar[b + 2] == 'm') {
              
              if (timeZone == null)
                timeZone = TimeZone.getTimeZone(paramString1); 
              long l = (Math.abs(timeZone.getRawOffset()) % 3600000 / 60000);
              stringBuffer.append(((l < 10L) ? "0" : "") + l);
              b += 2;
            } 
          } 
          break;
        
        case 'A':
        case 'P':
        case 'a':
        case 'p':
          if (arrayOfChar[b + 1] == 'M' || arrayOfChar[b + 1] == 'm') {
            
            stringBuffer.append(paramBoolean ? "AM" : "PM");
            b++;
          } 
          break;
        
        default:
          stringBuffer.append(arrayOfChar[b]);
          break;
      } 

    
    } 
    return stringBuffer.substring(0, stringBuffer.length());
  }











  
  String getString(int paramInt) throws SQLException {
    String str = null;
    
    if (this.definedColumnType == 0) {
      
      str = super.getString(paramInt);
    }
    else {
      
      if (this.rowSpaceIndicator == null) {


        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 


      
      if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
        
        int i = this.columnIndex + this.byteLength * paramInt;
        int j = oracleYear(i);
        int k = 0;
        str = toText(j, this.rowSpaceByte[2 + i], this.rowSpaceByte[3 + i], k = this.rowSpaceByte[4 + i] - 1, this.rowSpaceByte[5 + i] - 1, this.rowSpaceByte[6 + i] - 1, -1, (k < 12), (String)null);
      } 
    } 








    
    if (str != null && this.definedColumnSize > 0 && str.length() > this.definedColumnSize)
    {
      str = str.substring(0, this.definedColumnSize);
    }
    return str;
  }


  
  Object getObject(int paramInt) throws SQLException {
    if (this.definedColumnType == 0) {
      return super.getObject(paramInt);
    }
    
    Object object = null;
    
    if (this.rowSpaceIndicator == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      switch (this.definedColumnType) {






        
        case -1:
        case 1:
        case 12:
          return getString(paramInt);
        
        case 91:
          return getDate(paramInt);
        
        case 92:
          return getTime(paramInt);
        
        case 93:
          return getTimestamp(paramInt);


        
        case -4:
        case -3:
        case -2:
          return getBytes(paramInt);
      } 

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    return object;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
