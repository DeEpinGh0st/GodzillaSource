package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;

















































class T4CTTIidc
  extends T4CTTIMsg
{
  T4CTTIkscn kpdqidcscn;
  T4CTTIqcinv[] kpdqidccinv;
  T4CTTIqcinv[] kpdqidcusr;
  long kpdqidcflg;
  
  T4CTTIidc(T4CConnection paramT4CConnection) {
    super(paramT4CConnection, (byte)0);
  }
  
  void unmarshal() throws SQLException, IOException {
    this.kpdqidcscn = new T4CTTIkscn(this.connection);
    this.kpdqidcscn.unmarshal();
    int i = this.meg.unmarshalSWORD();
    byte b = (byte)this.meg.unmarshalUB1();
    if (i > 0) {
      
      this.kpdqidccinv = new T4CTTIqcinv[i];
      for (byte b1 = 0; b1 < i; b1++) {
        
        this.kpdqidccinv[b1] = new T4CTTIqcinv(this.connection);
        this.kpdqidccinv[b1].unmarshal();
      } 
    } else {
      
      this.kpdqidccinv = null;
    } 
    int j = this.meg.unmarshalSWORD();
    if (j > 0) {
      
      this.kpdqidcusr = new T4CTTIqcinv[j];
      for (byte b1 = 0; b1 < j; b1++) {
        
        this.kpdqidcusr[b1] = new T4CTTIqcinv(this.connection);
        this.kpdqidcusr[b1].unmarshal();
      } 
    } else {
      
      this.kpdqidcusr = null;
    }  this.kpdqidcflg = this.meg.unmarshalUB4();
  }
}
