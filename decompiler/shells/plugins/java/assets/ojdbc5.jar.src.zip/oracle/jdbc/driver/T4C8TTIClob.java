package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.OracleConnection;
import oracle.sql.CLOB;
import oracle.sql.CharacterSet;
import oracle.sql.Datum;
import oracle.sql.NCLOB;



































































































































final class T4C8TTIClob
  extends T4C8TTILob
{
  int[] nBytes;
  
  T4C8TTIClob(T4CConnection paramT4CConnection) {
    super(paramT4CConnection);
    
    this.nBytes = new int[1];
  }































  
  long read(byte[] paramArrayOfbyte, long paramLong1, long paramLong2, boolean paramBoolean, char[] paramArrayOfchar, int paramInt) throws SQLException, IOException {
    long l1 = 0L;
    long l2 = paramLong2;
    boolean bool = false;










    
    byte[] arrayOfByte = null;


    
    try {
      initializeLobdef();






      
      if ((paramArrayOfbyte[6] & 0x80) == 128) {
        bool = true;
      }




      
      int i = 0;
      if (bool == true) {
        i = (int)paramLong2 * 2;
      } else {
        i = (int)paramLong2 * 3;
      } 
      
      arrayOfByte = this.connection.getByteBuffer(i);






      
      if ((paramArrayOfbyte[7] & 0x40) > 0) {
        this.littleEndianClob = true;
      }

      
      this.lobops = 2L;
      this.sourceLobLocator = paramArrayOfbyte;
      this.sourceOffset = paramLong1;
      this.lobamt = paramLong2;
      this.sendLobamt = true;
      this.outBuffer = arrayOfByte;
      
      doRPC();
      
      l2 = this.lobamt;




      
      long l = 0L;



      
      if (bool == true)
      {
        if (this.connection.versionNumber < 10101)
        {

          
          DBConversion.ucs2BytesToJavaChars(this.outBuffer, (int)this.lobBytesRead, paramArrayOfchar);
        
        }
        else if (this.littleEndianClob)
        {
          CharacterSet.convertAL16UTF16LEBytesToJavaChars(this.outBuffer, 0, paramArrayOfchar, paramInt, (int)this.lobBytesRead, true);
        
        }
        else
        {
          CharacterSet.convertAL16UTF16BytesToJavaChars(this.outBuffer, 0, paramArrayOfchar, paramInt, (int)this.lobBytesRead, true);

        
        }


      
      }
      else if (!paramBoolean)
      {


        
        this.nBytes[0] = (int)this.lobBytesRead;
        
        this.meg.conv.CHARBytesToJavaChars(this.outBuffer, 0, paramArrayOfchar, paramInt, this.nBytes, paramArrayOfchar.length);



      
      }
      else
      {


        
        this.nBytes[0] = (int)this.lobBytesRead;
        
        this.meg.conv.NCHARBytesToJavaChars(this.outBuffer, 0, paramArrayOfchar, paramInt, this.nBytes, paramArrayOfchar.length);
      
      }
    
    }
    finally {
      
      this.outBuffer = null;
      this.connection.cacheBuffer(arrayOfByte);
    } 
    
    return l2;
  }






































  
  long write(byte[] paramArrayOfbyte, long paramLong1, boolean paramBoolean, char[] paramArrayOfchar, long paramLong2, long paramLong3) throws SQLException, IOException {
    boolean bool = false;
    if ((paramArrayOfbyte[6] & 0x80) == 128) {
      bool = true;
    }
    if ((paramArrayOfbyte[7] & 0x40) == 64) {
      this.littleEndianClob = true;
    }

    
    long l = 0L;
    byte[] arrayOfByte = null;




    
    if (bool == true) {



      
      arrayOfByte = new byte[(int)paramLong3 * 2];
      
      if (this.connection.versionNumber < 10101)
      {
        DBConversion.javaCharsToUcs2Bytes(paramArrayOfchar, (int)paramLong2, arrayOfByte, 0, (int)paramLong3);
      }
      else if (this.littleEndianClob)
      {
        CharacterSet.convertJavaCharsToAL16UTF16LEBytes(paramArrayOfchar, (int)paramLong2, arrayOfByte, 0, (int)paramLong3);
      }
      else
      {
        CharacterSet.convertJavaCharsToAL16UTF16Bytes(paramArrayOfchar, (int)paramLong2, arrayOfByte, 0, (int)paramLong3);
      
      }

    
    }
    else {
      
      arrayOfByte = new byte[(int)paramLong3 * 3];
      
      if (!paramBoolean) {



        
        l = this.meg.conv.javaCharsToCHARBytes(paramArrayOfchar, (int)paramLong2, arrayOfByte, 0, (int)paramLong3);

      
      }
      else {


        
        l = this.meg.conv.javaCharsToNCHARBytes(paramArrayOfchar, (int)paramLong2, arrayOfByte, 0, (int)paramLong3);
      } 
    } 



    
    initializeLobdef();

    
    this.lobops = 64L;
    this.sourceLobLocator = paramArrayOfbyte;
    this.sourceOffset = paramLong1;
    this.lobamt = paramLong3;
    this.sendLobamt = true;
    this.inBuffer = arrayOfByte;
    this.inBufferOffset = 0L;


    
    if (bool == true) {



      
      if (this.connection.versionNumber < 10101) {
        this.inBufferNumBytes = paramLong3;
      } else {
        this.inBufferNumBytes = paramLong3 * 2L;
      
      }
    
    }
    else {
      
      this.inBufferNumBytes = l;
    } 
    doRPC();
    
    return this.lobamt;
  }


















  
  Datum createTemporaryLob(Connection paramConnection, boolean paramBoolean, int paramInt) throws SQLException, IOException {
    return createTemporaryLob(paramConnection, paramBoolean, paramInt, (short)1);
  }










  
  Datum createTemporaryLob(Connection paramConnection, boolean paramBoolean, int paramInt, short paramShort) throws SQLException, IOException {
    NCLOB nCLOB;
    if (paramInt == 12) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 158);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    CLOB cLOB = null;

    
    initializeLobdef();

    
    this.lobops = 272L;
    this.sourceLobLocator = new byte[40];
    this.sourceLobLocator[1] = 84;

    
    if (paramShort == 1) {
      this.sourceOffset = 1L;
    } else {
      this.sourceOffset = 2L;
    } 

    
    this.destinationOffset = 112L;







    
    this.destinationLength = paramInt;
    
    this.lobamt = paramInt;
    this.sendLobamt = true;

    
    this.nullO2U = true;



    
    this.characterSet = (paramShort == 2) ? this.meg.conv.getNCharSetId() : this.meg.conv.getServerCharSetId();
    
    if (this.connection.versionNumber >= 9000) {
      
      this.lobscn = new int[1];
      this.lobscn[0] = paramBoolean ? 1 : 0;
      this.lobscnl = 1;
    } 
    
    doRPC();


    
    if (this.sourceLobLocator != null)
    {
      if (paramShort == 1) {
        cLOB = new CLOB((OracleConnection)paramConnection, this.sourceLobLocator);
      }
      else {
        
        nCLOB = new NCLOB((OracleConnection)paramConnection, this.sourceLobLocator);
      } 
    }
    
    return (Datum)nCLOB;
  }















  
  boolean open(byte[] paramArrayOfbyte, int paramInt) throws SQLException, IOException {
    boolean bool = false;


    
    byte b = 2;
    
    if (paramInt == 0) {
      b = 1;
    }
    bool = _open(paramArrayOfbyte, b, 32768);
    
    return bool;
  }














  
  boolean close(byte[] paramArrayOfbyte) throws SQLException, IOException {
    boolean bool = false;
    
    bool = _close(paramArrayOfbyte, 65536);
    
    return bool;
  }















  
  boolean isOpen(byte[] paramArrayOfbyte) throws SQLException, IOException {
    boolean bool = false;
    
    bool = _isOpen(paramArrayOfbyte, 69632);
    
    return bool;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
