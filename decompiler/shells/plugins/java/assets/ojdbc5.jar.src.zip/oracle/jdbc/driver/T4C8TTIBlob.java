package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.OracleConnection;
import oracle.sql.BLOB;
import oracle.sql.Datum;







































































































final class T4C8TTIBlob
  extends T4C8TTILob
{
  T4C8TTIBlob(T4CConnection paramT4CConnection) {
    super(paramT4CConnection);
  }




















  
  Datum createTemporaryLob(Connection paramConnection, boolean paramBoolean, int paramInt) throws SQLException, IOException {
    if (paramInt == 12) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 158);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    BLOB bLOB = null;

    
    initializeLobdef();

    
    this.lobops = 272L;
    this.sourceLobLocator = new byte[40];
    this.sourceLobLocator[1] = 84;

    
    this.characterSet = 1;


    
    this.destinationOffset = 113L;



    
    this.destinationLength = paramInt;
    
    this.lobamt = paramInt;
    this.sendLobamt = true;

    
    this.nullO2U = true;
    
    if (this.connection.versionNumber >= 9000) {
      
      this.lobscn = new int[1];
      this.lobscn[0] = paramBoolean ? 1 : 0;
      this.lobscnl = 1;
    } 
    
    doRPC();


    
    if (this.sourceLobLocator != null)
    {
      bLOB = new BLOB((OracleConnection)paramConnection, this.sourceLobLocator);
    }

    
    return (Datum)bLOB;
  }














  
  boolean open(byte[] paramArrayOfbyte, int paramInt) throws SQLException, IOException {
    boolean bool = false;


    
    byte b = 2;
    
    if (paramInt == 0) {
      b = 1;
    }
    bool = _open(paramArrayOfbyte, b, 32768);
    
    return bool;
  }














  
  boolean close(byte[] paramArrayOfbyte) throws SQLException, IOException {
    boolean bool = false;
    
    bool = _close(paramArrayOfbyte, 65536);
    
    return bool;
  }














  
  boolean isOpen(byte[] paramArrayOfbyte) throws SQLException, IOException {
    boolean bool = false;
    
    bool = _isOpen(paramArrayOfbyte, 69632);
    
    return bool;
  }

  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
