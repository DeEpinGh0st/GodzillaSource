package oracle.jdbc.pool;

import oracle.jdbc.OracleConnection;

public interface OracleConnectionCacheCallback {
  boolean handleAbandonedConnection(OracleConnection paramOracleConnection, Object paramObject);
  
  void releaseConnection(OracleConnection paramOracleConnection, Object paramObject);
}
