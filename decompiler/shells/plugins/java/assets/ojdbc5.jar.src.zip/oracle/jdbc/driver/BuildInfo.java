package oracle.jdbc.driver;















































public class BuildInfo
{
  public static final boolean isDMS() {
    return false;
  }













  
  public static final boolean isInServer() {
    return false;
  }











  
  public static final boolean isJDK14() {
    return true;
  }










  
  public static final boolean isDebug() {
    return false;
  }











  
  public static final boolean isPrivateDebug() {
    return false;
  }









  
  public static final String getJDBCVersion() {
    return "JDBC 3.0";
  }











  
  public static final String getDriverVersion() {
    return "11.2.0.4.0";
  }








  
  public static final String getBuildDate() {
    return "Thu_Jul_03_18:16:49_PDT_2014";
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
