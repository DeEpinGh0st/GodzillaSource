package oracle.jdbc.internal;

import oracle.jdbc.OracleNClob;

public interface OracleNClob extends OracleDatumWithConnection, OracleNClob, OracleClob {}
