package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.internal.XSNamespace;

















































class T4CTTIxsnsop
  extends T4CTTIfun
{
  private OracleConnection.XSOperationCode operationCode;
  private byte[] sessionId;
  private XSNamespace[] namespaces;
  private XSNamespace[] outNamespaces;
  
  T4CTTIxsnsop(T4CConnection paramT4CConnection) {
    super(paramT4CConnection, (byte)3);
    
    setFunCode((short)172);
  }














  
  void doOXSNS(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace, boolean paramBoolean) throws IOException, SQLException {
    if (paramBoolean) {
      setTTCCode((byte)3);
    } else {
      setTTCCode((byte)17);
    }  this.operationCode = paramXSOperationCode;
    this.sessionId = paramArrayOfbyte;
    this.namespaces = paramArrayOfXSNamespace;
    
    if (this.namespaces != null)
      for (byte b = 0; b < this.namespaces.length; b++) {
        ((XSNamespaceI)this.namespaces[b]).doCharConversion(this.meg.conv);
      } 
    if (paramBoolean) {
      doRPC();
    } else {
      doPigRPC();
    } 
  }



  
  void marshal() throws IOException {
    this.meg.marshalUB4(this.operationCode.getCode());
    boolean bool1 = false;
    if (this.sessionId != null && this.sessionId.length > 0) {
      
      bool1 = true;
      this.meg.marshalPTR();
      this.meg.marshalUB4(this.sessionId.length);
    }
    else {
      
      this.meg.marshalNULLPTR();
      this.meg.marshalUB4(0L);
    } 
    
    boolean bool2 = false;
    this.meg.marshalPTR();
    if (this.namespaces != null && this.namespaces.length > 0) {
      
      bool2 = true;
      this.meg.marshalUB4(this.namespaces.length);
    }
    else {
      
      this.meg.marshalUB4(0L);
    } 
    this.meg.marshalPTR();
    
    if (bool1)
      this.meg.marshalB1Array(this.sessionId); 
    if (bool2) {
      for (byte b = 0; b < this.namespaces.length; b++) {
        ((XSNamespaceI)this.namespaces[b]).marshal(this.meg);
      }
    }
  }



  
  void readRPA() throws SQLException, IOException {
    this.outNamespaces = null;
    int i = (int)this.meg.unmarshalUB4();
    if (i > 0) {
      
      this.outNamespaces = new XSNamespace[i];
      for (byte b = 0; b < i; b++) {
        this.outNamespaces[b] = XSNamespaceI.unmarshal(this.meg);
      }
    } 
  }


  
  XSNamespace[] getNamespaces() throws SQLException {
    return this.outNamespaces;
  }











  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return this.connection;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
