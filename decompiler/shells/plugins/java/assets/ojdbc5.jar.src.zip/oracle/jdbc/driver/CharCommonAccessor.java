package oracle.jdbc.driver;

import java.io.ByteArrayInputStream;
import java.io.CharArrayReader;
import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Map;
import oracle.sql.CHAR;
import oracle.sql.CharacterSet;
import oracle.sql.Datum;
















abstract class CharCommonAccessor
  extends Accessor
{
  int internalMaxLengthNewer;
  int internalMaxLengthOlder;
  static final int MAX_NB_CHAR_PLSQL = 32766;
  
  void setOffsets(int paramInt) {
    this.columnIndex = this.statement.defineCharSubRange;
    this.statement.defineCharSubRange = this.columnIndex + paramInt * this.charLength;
  }





  
  void init(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, int paramInt3, short paramShort, int paramInt4, boolean paramBoolean, int paramInt5, int paramInt6) throws SQLException {
    if (paramBoolean) {
      
      if (paramInt1 != 23) {
        paramInt1 = 1;
      }
      if (paramOracleStatement.maxFieldSize > 0 && (paramInt3 == -1 || paramInt3 < paramOracleStatement.maxFieldSize)) {
        paramInt3 = paramOracleStatement.maxFieldSize;
      }
    } 
    init(paramOracleStatement, paramInt1, paramInt2, paramShort, paramBoolean);

    
    if (paramBoolean && paramOracleStatement.connection.defaultnchar) {
      this.formOfUse = 2;
    }
    this.internalMaxLengthNewer = paramInt5;
    this.internalMaxLengthOlder = paramInt6;
    
    initForDataAccess(paramInt4, paramInt3, (String)null);
  }






  
  void init(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, short paramShort, int paramInt9, int paramInt10) throws SQLException {
    init(paramOracleStatement, paramInt1, paramInt2, paramShort, false);
    initForDescribe(paramInt1, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramShort, null);

    
    int i = paramOracleStatement.maxFieldSize;
    
    if (i != 0 && i <= paramInt3) {
      paramInt3 = i;
    }
    this.internalMaxLengthNewer = paramInt9;
    this.internalMaxLengthOlder = paramInt10;
    
    initForDataAccess(0, paramInt3, (String)null);
  }




  
  void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
    if (paramInt1 != 0) {
      this.externalType = paramInt1;
    }
    if (this.statement.connection.getVersionNumber() >= 8000) {
      this.internalTypeMaxLength = this.internalMaxLengthNewer;
    } else {
      this.internalTypeMaxLength = this.internalMaxLengthOlder;
    } 
    if (paramInt2 == 0) {
      this.internalTypeMaxLength = 0;
    }
    else if (paramInt2 > 0 && paramInt2 < this.internalTypeMaxLength) {
      this.internalTypeMaxLength = paramInt2;
    } 
    
    this.charLength = this.isNullByDescribe ? 0 : (this.internalTypeMaxLength + 1);
  }




  
  int getInt(int paramInt) throws SQLException {
    int i = 0;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      try {
        
        i = Integer.parseInt(getString(paramInt).trim());
      }
      catch (NumberFormatException numberFormatException) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    }

    
    return i;
  }













  
  boolean getBoolean(int paramInt) throws SQLException {
    String str = getString(paramInt);
    if (str == null)
    {
      return false;
    }
    str = str.trim();
    
    try {
      BigDecimal bigDecimal = new BigDecimal(str);
      return (bigDecimal.signum() != 0);
    }
    catch (NumberFormatException numberFormatException) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }






  
  short getShort(int paramInt) throws SQLException {
    short s = 0;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      try {
        
        s = Short.parseShort(getString(paramInt).trim());
      }
      catch (NumberFormatException numberFormatException) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    }

    
    return s;
  }




  
  byte getByte(int paramInt) throws SQLException {
    byte b = 0;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      try {
        
        b = Byte.parseByte(getString(paramInt).trim());
      }
      catch (NumberFormatException numberFormatException) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    }

    
    return b;
  }




  
  long getLong(int paramInt) throws SQLException {
    long l = 0L;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      try {
        
        l = Long.parseLong(getString(paramInt).trim());
      }
      catch (NumberFormatException numberFormatException) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    }

    
    return l;
  }




  
  float getFloat(int paramInt) throws SQLException {
    float f = 0.0F;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      try {
        
        f = Float.parseFloat(getString(paramInt).trim());
      }
      catch (NumberFormatException numberFormatException) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    }

    
    return f;
  }




  
  double getDouble(int paramInt) throws SQLException {
    double d = 0.0D;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      try {
        
        d = Double.parseDouble(getString(paramInt).trim());
      }
      catch (NumberFormatException numberFormatException) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    }

    
    return d;
  }




  
  BigDecimal getBigDecimal(int paramInt) throws SQLException {
    BigDecimal bigDecimal = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      try {
        
        String str = getString(paramInt);
        
        if (str != null) {
          bigDecimal = new BigDecimal(str.trim());
        }
      } catch (NumberFormatException numberFormatException) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    }

    
    return bigDecimal;
  }




  
  BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
    BigDecimal bigDecimal = getBigDecimal(paramInt1);
    
    if (bigDecimal != null) {
      bigDecimal.setScale(paramInt2, 6);
    }
    return bigDecimal;
  }




  
  String getString(int paramInt) throws SQLException {
    String str = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      int i = this.columnIndex + this.charLength * paramInt;
      int j = this.rowSpaceChar[i] >> 1;
      
      if (j > this.internalTypeMaxLength) {
        j = this.internalTypeMaxLength;
      }
      str = new String(this.rowSpaceChar, i + 1, j);
    } 
    
    return str;
  }




  
  Date getDate(int paramInt) throws SQLException {
    Date date = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1)
    {
      date = Date.valueOf(getString(paramInt).trim());
    }
    
    return date;
  }




  
  Time getTime(int paramInt) throws SQLException {
    Time time = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1)
    {
      time = Time.valueOf(getString(paramInt).trim());
    }
    
    return time;
  }




  
  Timestamp getTimestamp(int paramInt) throws SQLException {
    Timestamp timestamp = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1)
    {
      timestamp = Timestamp.valueOf(getString(paramInt).trim());
    }
    
    return timestamp;
  }









  
  byte[] getBytes(int paramInt) throws SQLException {
    return getBytesInternal(paramInt);
  }

  
  byte[] getBytesInternal(int paramInt) throws SQLException {
    byte[] arrayOfByte = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      int i = this.columnIndex + this.charLength * paramInt;
      int j = this.rowSpaceChar[i] >> 1;
      
      if (j > this.internalTypeMaxLength) {
        j = this.internalTypeMaxLength;
      }
      DBConversion dBConversion = this.statement.connection.conversion;


      
      byte[] arrayOfByte1 = new byte[j * 6];
      int k = (this.formOfUse == 2) ? dBConversion.javaCharsToNCHARBytes(this.rowSpaceChar, i + 1, arrayOfByte1, 0, j) : dBConversion.javaCharsToCHARBytes(this.rowSpaceChar, i + 1, arrayOfByte1, 0, j);




      
      arrayOfByte = new byte[k];
      
      System.arraycopy(arrayOfByte1, 0, arrayOfByte, 0, k);
    } 
    
    return arrayOfByte;
  }













  
  InputStream getAsciiStream(int paramInt) throws SQLException {
    InputStream inputStream = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      int i = this.columnIndex + this.charLength * paramInt;
      int j = this.rowSpaceChar[i] >> 1;
      
      if (j > this.internalTypeMaxLength) {
        j = this.internalTypeMaxLength;
      }
      PhysicalConnection physicalConnection = this.statement.connection;
      
      inputStream = physicalConnection.conversion.CharsToStream(this.rowSpaceChar, i + 1, j, 10);
    } 

    
    return inputStream;
  }










  
  InputStream getUnicodeStream(int paramInt) throws SQLException {
    InputStream inputStream = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      int i = this.columnIndex + this.charLength * paramInt;
      int j = this.rowSpaceChar[i] >> 1;
      
      if (j > this.internalTypeMaxLength) {
        j = this.internalTypeMaxLength;
      }
      PhysicalConnection physicalConnection = this.statement.connection;
      
      inputStream = physicalConnection.conversion.CharsToStream(this.rowSpaceChar, i + 1, j << 1, 11);
    } 


    
    return inputStream;
  }










  
  Reader getCharacterStream(int paramInt) throws SQLException {
    CharArrayReader charArrayReader = null;
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      int i = this.columnIndex + this.charLength * paramInt;
      int j = this.rowSpaceChar[i] >> 1;
      
      if (j > this.internalTypeMaxLength) {
        j = this.internalTypeMaxLength;
      }
      charArrayReader = new CharArrayReader(this.rowSpaceChar, i + 1, j);
    } 
    return charArrayReader;
  }










  
  InputStream getBinaryStream(int paramInt) throws SQLException {
    ByteArrayInputStream byteArrayInputStream = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      int i = this.columnIndex + this.charLength * paramInt;
      int j = this.rowSpaceChar[i] >> 1;
      
      if (j > this.internalTypeMaxLength) {
        j = this.internalTypeMaxLength;
      }
      DBConversion dBConversion = this.statement.connection.conversion;


      
      byte[] arrayOfByte = new byte[j * 6];
      int k = (this.formOfUse == 2) ? dBConversion.javaCharsToNCHARBytes(this.rowSpaceChar, i + 1, arrayOfByte, 0, j) : dBConversion.javaCharsToCHARBytes(this.rowSpaceChar, i + 1, arrayOfByte, 0, j);




      
      byteArrayInputStream = new ByteArrayInputStream(arrayOfByte, 0, k);
    } 
    
    return byteArrayInputStream;
  }










  
  Object getObject(int paramInt) throws SQLException {
    return getString(paramInt);
  }











  
  Object getObject(int paramInt, Map paramMap) throws SQLException {
    return getString(paramInt);
  }










  
  Datum getOracleObject(int paramInt) throws SQLException {
    return (Datum)getCHAR(paramInt);
  }









  
  CHAR getCHAR(int paramInt) throws SQLException {
    CharacterSet characterSet;
    byte[] arrayOfByte = getBytesInternal(paramInt);

    
    if (arrayOfByte == null || arrayOfByte.length == 0)
    {
      return null;
    }
    
    if (this.formOfUse == 2) {
      
      characterSet = this.statement.connection.conversion.getDriverNCharSetObj();
    }
    else {
      
      characterSet = this.statement.connection.conversion.getDriverCharSetObj();
    } 
    
    return new CHAR(arrayOfByte, characterSet);
  }










  
  URL getURL(int paramInt) throws SQLException {
    URL uRL = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      try {
        
        uRL = new URL(getString(paramInt));
      }
      catch (MalformedURLException malformedURLException) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 136);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    }

    
    return uRL;
  }



  
  byte[] getBytesFromHexChars(int paramInt) throws SQLException {
    byte[] arrayOfByte = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      int i = this.columnIndex + this.charLength * paramInt;
      int j = this.rowSpaceChar[i] >> 1;
      
      if (j > this.internalTypeMaxLength) {
        j = this.internalTypeMaxLength;
      }
      arrayOfByte = this.statement.connection.conversion.hexChars2Bytes(this.rowSpaceChar, i + 1, j);
    } 
    
    return arrayOfByte;
  }


  
  long updateChecksum(long paramLong, int paramInt) throws SQLException {
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
      
      paramLong = CRC64.updateChecksum(paramLong, NULL_DATA_BYTES, 0, NULL_DATA_BYTES.length);
    
    }
    else {

      
      int i = this.columnIndex + this.charLength * paramInt;
      int j = this.rowSpaceChar[i] >> 1;
      
      paramLong = CRC64.updateChecksum(paramLong, this.rowSpaceChar, i + 1, j);
    } 



    
    return paramLong;
  }

  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
