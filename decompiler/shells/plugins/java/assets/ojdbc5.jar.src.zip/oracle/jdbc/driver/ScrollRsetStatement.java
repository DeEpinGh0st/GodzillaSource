package oracle.jdbc.driver;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

interface ScrollRsetStatement {
  Connection getConnection() throws SQLException;
  
  void notifyCloseRset() throws SQLException;
  
  int copyBinds(Statement paramStatement, int paramInt) throws SQLException;
  
  String getOriginalSql() throws SQLException;
  
  OracleResultSetCache getResultSetCache() throws SQLException;
  
  int getMaxFieldSize() throws SQLException;
}
