package oracle.jdbc.driver;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Locale;
import java.util.TimeZone;
import java.util.Vector;
import oracle.jdbc.OracleResultSetCache;
import oracle.jdbc.dcn.DatabaseChangeRegistration;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.internal.OracleStatement;
import oracle.sql.BLOB;
import oracle.sql.CLOB;

























































































































































































































































abstract class OracleStatement
  implements OracleStatement, ScrollRsetStatement
{
  static final int PLAIN_STMT = 0;
  static final int PREP_STMT = 1;
  static final int CALL_STMT = 2;
  int cursorId;
  int numberOfDefinePositions;
  int definesBatchSize;
  Accessor[] accessors;
  int defineByteSubRange;
  int defineCharSubRange;
  int defineIndicatorSubRange;
  int defineLengthSubRange;
  byte[] defineBytes;
  char[] defineChars;
  short[] defineIndicators;
  
  void continueReadRow(int paramInt) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "continueReadRow is only implemented by the T4C statements.");
    sQLException.fillInStackTrace();
    throw sQLException;
  }
































  
  public int cursorIfRefCursor() throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "cursorIfRefCursor not implemented");
    sQLException.fillInStackTrace();
    throw sQLException;
  }





  
  void closeCursorOnPlainStatement() throws SQLException {}





  
  boolean described = false;




  
  boolean describedWithNames = false;




  
  byte[] defineMetaData;




  
  int defineMetaDataSubRange;




  
  static final int METADATALENGTH = 1;



  
  int rowsProcessed;



  
  int cachedDefineByteSize = 0;
  int cachedDefineCharSize = 0;
  int cachedDefineIndicatorSize = 0;
  int cachedDefineMetaDataSize = 0;

  
  OracleStatement children = null;
  OracleStatement parent = null;

  
  OracleStatement nextChild = null;

  
  OracleStatement next;

  
  OracleStatement prev;

  
  long c_state;

  
  int numberOfBindPositions;

  
  byte[] bindBytes;

  
  char[] bindChars;

  
  short[] bindIndicators;

  
  int bindByteOffset;

  
  int bindCharOffset;

  
  int bindIndicatorOffset;

  
  int bindByteSubRange;

  
  int bindCharSubRange;

  
  int bindIndicatorSubRange;

  
  Accessor[] outBindAccessors;
  
  InputStream[][] parameterStream;
  
  Object[][] userStream;
  
  int firstRowInBatch;
  
  boolean hasIbtBind = false;
  
  byte[] ibtBindBytes;
  
  char[] ibtBindChars;
  
  short[] ibtBindIndicators;
  
  int ibtBindByteOffset;
  
  int ibtBindCharOffset;
  
  int ibtBindIndicatorOffset;
  
  int ibtBindIndicatorSize;
  
  ByteBuffer[] nioBuffers = null;
  Object[] lobPrefetchMetaData = null;


  
  boolean hasStream;


  
  byte[] tmpByteArray;

  
  int sizeTmpByteArray = 0;



  
  byte[] tmpBindsByteArray;



  
  boolean needToSendOalToFetch = false;



  
  int[] definedColumnType = null;
  int[] definedColumnSize = null;
  int[] definedColumnFormOfUse = null;




  
  T4CTTIoac[] oacdefSent = null;





  
  int[] nbPostPonedColumns = null;
  int[][] indexOfPostPonedColumn = (int[][])null;



  
  boolean aFetchWasDoneDuringDescribe = false;


  
  boolean implicitDefineForLobPrefetchDone = false;


  
  long checkSum = 0L;










  
  boolean checkSumComputationFailure = false;









  
  int accessorByteOffset = 0;
  int accessorCharOffset = 0;
  int accessorShortOffset = 0;


  
  static final int VALID_ROWS_UNINIT = -999;


  
  PhysicalConnection connection;

  
  OracleInputStream streamList;

  
  OracleInputStream nextStream;

  
  OracleResultSetImpl currentResultSet;

  
  boolean processEscapes;

  
  boolean convertNcharLiterals;

  
  int queryTimeout;

  
  int batch;

  
  int numberOfExecutedElementsInBatch = -1;
  
  int currentRank;
  
  boolean bsendBatchInProgress = false;
  
  int currentRow;
  
  int validRows;
  
  int maxFieldSize;
  
  int maxRows;
  
  int totalRowsVisited;
  
  int rowPrefetch;
  int rowPrefetchInLastFetch = -1;



  
  int defaultRowPrefetch;



  
  boolean rowPrefetchChanged;



  
  int defaultLobPrefetchSize;


  
  boolean gotLastBatch;


  
  boolean clearParameters;


  
  boolean closed;


  
  boolean sqlStringChanged;


  
  OracleSql sqlObject;


  
  boolean needToParse;


  
  boolean needToPrepareDefineBuffer;


  
  boolean columnsDefinedByUser;


  
  OracleStatement.SqlKind sqlKind = OracleStatement.SqlKind.SELECT;
  byte sqlKindByte = 1;


  
  int autoRollback;


  
  int defaultFetchDirection;


  
  boolean serverCursor;

  
  boolean fixedString = false;

  
  boolean noMoreUpdateCounts = false;

  
  protected CancelLock cancelLock = new CancelLock();
  
  OracleStatementWrapper wrapper;
  
  static final byte EXECUTE_NONE = -1;
  
  static final byte EXECUTE_QUERY = 1;
  
  static final byte EXECUTE_UPDATE = 2;
  
  static final byte EXECUTE_NORMAL = 3;
  byte executionType = -1;

  
  OracleResultSet scrollRset;

  
  OracleResultSetCache rsetCache;
  
  int userRsetType;
  
  int realRsetType;
  
  boolean needToAddIdentifier;
  
  SQLWarning sqlWarning;
  
  int cacheState = 3;

  
  int creationState = 0;

  
  boolean isOpen = false;

  
  int statementType = 0;
  
  boolean columnSetNull = false;
  
  int[] returnParamMeta;
  
  static final int DMLR_METADATA_PREFIX_SIZE = 3;
  
  static final int DMLR_METADATA_NUM_OF_RETURN_PARAMS = 0;
  
  static final int DMLR_METADATA_ROW_BIND_BYTES = 1;
  
  static final int DMLR_METADATA_ROW_BIND_CHARS = 2;
  
  static final int DMLR_METADATA_TYPE_OFFSET = 0;
  
  static final int DMLR_METADATA_IS_CHAR_TYPE_OFFSET = 1;
  
  static final int DMLR_METADATA_BIND_SIZE_OFFSET = 2;
  
  static final int DMLR_METADATA_FORM_OF_USE_OFFSET = 3;
  
  static final int DMLR_METADATA_PER_POSITION_SIZE = 4;
  
  Accessor[] returnParamAccessors;
  
  boolean returnParamsFetched;
  
  int rowsDmlReturned;
  
  int numReturnParams;
  
  byte[] returnParamBytes;
  
  char[] returnParamChars;
  
  short[] returnParamIndicators;
  
  int returnParamRowBytes;
  
  int returnParamRowChars;
  OracleReturnResultSet returnResultSet;
  boolean isAutoGeneratedKey;
  AutoKeyInfo autoKeyInfo;
  TimeZone defaultTimeZone = null;
  String defaultTimeZoneName = null;
  
  Calendar defaultCalendar = null;
  Calendar gmtCalendar = null;










  
  long inScn = 0L; int lastIndex; Vector m_batchItems; ArrayList tempClobsToFree; ArrayList tempBlobsToFree; ArrayList oldTempClobsToFree; ArrayList oldTempBlobsToFree; NTFDCNRegistration registration; String[] dcnTableName; long dcnQueryId; long _checkSum; static final byte IS_UNINITIALIZED = 0; static final byte IS_SELECT = 1; static final byte IS_DELETE = 2; static final byte IS_INSERT = 4; static final byte IS_MERGE = 8; static final byte IS_UPDATE = 16; static final byte IS_PLSQL_BLOCK = 32; static final byte IS_CALL_BLOCK = 64; static final byte IS_OTHER = -128; static final byte IS_DML = 30;
  static final byte IS_PLSQL = 96;
  
  public void setSnapshotSCN(long paramLong) throws SQLException {
    doSetSnapshotSCN(paramLong);
  }


  
  void doSetSnapshotSCN(long paramLong) throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }


















  
  OracleStatement(PhysicalConnection paramPhysicalConnection, int paramInt1, int paramInt2) throws SQLException {
    this(paramPhysicalConnection, paramInt1, paramInt2, -1, -1);
  }
































































































  
  void initializeDefineSubRanges() {
    this.defineByteSubRange = 0;
    this.defineCharSubRange = 0;
    this.defineIndicatorSubRange = 0;
    this.defineMetaDataSubRange = 0;
  }














  
  void prepareDefinePreambles() {}













  
  void prepareAccessors() throws SQLException {
    byte[] arrayOfByte1 = null;
    char[] arrayOfChar = null;
    short[] arrayOfShort = null;
    boolean bool = false;
    byte[] arrayOfByte2 = null;
    
    if (this.accessors == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    int i = 0;
    int j = 0;
    int k = 0; int m;
    for (m = 0; m < this.numberOfDefinePositions; m++) {
      
      Accessor accessor = this.accessors[m];
      
      if (accessor == null) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      switch (accessor.internalType) {
        
        case 8:
        case 24:
          this.hasStream = true;
          break;
      } 
      
      i += accessor.byteLength;
      j += accessor.charLength;
      k++;
    } 


    
    if (this.streamList != null && !this.connection.useFetchSizeWithLongColumn) {
      this.rowPrefetch = 1;
    }
    m = this.rowPrefetch;
    
    this.definesBatchSize = m;






    
    initializeDefineSubRanges();

    
    int n = k * m;
    if (this.defineMetaData == null || this.defineMetaData.length < n) {
      
      if (this.defineMetaData != null)
        arrayOfByte2 = this.defineMetaData; 
      this.defineMetaData = new byte[n];
    } 

    
    this.cachedDefineByteSize = this.defineByteSubRange + i * m;
    
    if (this.defineBytes == null || this.defineBytes.length < this.cachedDefineByteSize) {
      
      if (this.defineBytes != null) arrayOfByte1 = this.defineBytes; 
      this.defineBytes = this.connection.getByteBuffer(this.cachedDefineByteSize);
    } 
    
    this.defineByteSubRange += this.accessorByteOffset;

    
    this.cachedDefineCharSize = this.defineCharSubRange + j * m;
    
    if ((this.defineChars == null || this.defineChars.length < this.cachedDefineCharSize) && this.cachedDefineCharSize > 0) {

      
      if (this.defineChars != null) arrayOfChar = this.defineChars;
      
      this.defineChars = this.connection.getCharBuffer(this.cachedDefineCharSize);
    } 
    
    this.defineCharSubRange += this.accessorCharOffset;


    
    int i1 = this.numberOfDefinePositions * m;
    int i2 = this.defineIndicatorSubRange + i1 + i1;

    
    if (this.defineIndicators == null || this.defineIndicators.length < i2) {

      
      if (this.defineIndicators != null) arrayOfShort = this.defineIndicators; 
      this.defineIndicators = new short[i2];
    } else if (this.defineIndicators.length >= i2) {
      
      bool = true;
      arrayOfShort = this.defineIndicators;
    } 
    
    this.defineIndicatorSubRange += this.accessorShortOffset;
    
    int i3 = this.defineIndicatorSubRange + i1;




    
    for (byte b = 0; b < this.numberOfDefinePositions; b++) {
      
      Accessor accessor = this.accessors[b];
      
      accessor.lengthIndexLastRow = accessor.lengthIndex;
      accessor.indicatorIndexLastRow = accessor.indicatorIndex;
      accessor.columnIndexLastRow = accessor.columnIndex;
      
      accessor.setOffsets(m);
      
      accessor.lengthIndex = i3;
      accessor.indicatorIndex = this.defineIndicatorSubRange;
      accessor.metaDataIndex = this.defineMetaDataSubRange;
      accessor.rowSpaceByte = this.defineBytes;
      accessor.rowSpaceChar = this.defineChars;
      accessor.rowSpaceIndicator = this.defineIndicators;
      accessor.rowSpaceMetaData = this.defineMetaData;
      this.defineIndicatorSubRange += m;
      i3 += m;
      this.defineMetaDataSubRange += m * 1;
    } 
    
    prepareDefinePreambles();






    
    if (this.rowPrefetchInLastFetch != -1 && this.rowPrefetch != this.rowPrefetchInLastFetch) {
      
      if (arrayOfChar == null) arrayOfChar = this.defineChars; 
      if (arrayOfByte1 == null) arrayOfByte1 = this.defineBytes; 
      if (arrayOfShort == null) arrayOfShort = this.defineIndicators; 
      saveDefineBuffersIfRequired(arrayOfChar, arrayOfByte1, arrayOfShort, bool);
    } 
  }











  
  boolean checkAccessorsUsable() throws SQLException {
    int i = this.accessors.length;
    
    if (i < this.numberOfDefinePositions) {
      return false;
    }
    boolean bool1 = true;
    boolean bool2 = false;
    boolean bool3 = false;
    
    for (byte b = 0; b < this.numberOfDefinePositions; b++) {
      
      Accessor accessor = this.accessors[b];
      
      if (accessor == null || accessor.externalType == 0) {
        bool1 = false;
      } else {
        bool2 = true;
      } 
    } 
    if (bool1)
    
    { 
      bool3 = true; }
    else { if (bool2) {


        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 



      
      this.columnsDefinedByUser = false; }
    
    return bool3;
  }





  
  void executeMaybeDescribe() throws SQLException {
    boolean bool1 = true;
    
    if (this.rowPrefetchChanged) {
      
      if (this.streamList == null && this.rowPrefetch != this.definesBatchSize) {
        this.needToPrepareDefineBuffer = true;
      }
      this.rowPrefetchChanged = false;
    } 
    
    if (!this.needToPrepareDefineBuffer)
    {

      
      if (this.accessors == null) {


        
        this.needToPrepareDefineBuffer = true;
      } else if (this.columnsDefinedByUser) {
        this.needToPrepareDefineBuffer = !checkAccessorsUsable();
      } 
    }
    boolean bool2 = false;


    
    try {
      this.cancelLock.enterExecuting();
      
      if (this.needToPrepareDefineBuffer) {

        
        if (!this.columnsDefinedByUser) {
          
          executeForDescribe();
          
          bool2 = true;


          
          if (this.aFetchWasDoneDuringDescribe) {
            bool1 = false;
          }
        } 


        
        if (this.needToPrepareDefineBuffer)
        {

          
          prepareAccessors();
        }
      } 

      
      int i = this.accessors.length;
      
      for (int j = this.numberOfDefinePositions; j < i; j++) {
        
        Accessor accessor = this.accessors[j];
        
        if (accessor != null)
          accessor.rowSpaceIndicator = null; 
      } 
      if (bool1) {
        executeForRows(bool2);
      }
    }
    catch (SQLException sQLException) {
      
      this.needToParse = true;
      throw sQLException;
    }
    finally {
      
      this.cancelLock.exitExecuting();
    } 
  }














  
  void adjustGotLastBatch() {}














  
  void doExecuteWithTimeout() throws SQLException {
    try {
      cleanOldTempLobs();





      
      this.connection.registerHeartbeat();

      
      this.rowsProcessed = 0;
      
      if (this.sqlKind.isSELECT()) {
        
        if (this.connection.j2ee13Compliant && this.executionType == 2) {
          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 129);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 
        
        this.connection.needLine();
        
        if (!this.isOpen) {
          
          this.connection.open(this);
          
          this.isOpen = true;
        } 
        
        if (this.queryTimeout != 0) {

          
          try {
            this.connection.getTimeout().setTimeout((this.queryTimeout * 1000), this);
            executeMaybeDescribe();
          }
          finally {
            
            this.connection.getTimeout().cancelTimeout();
          } 
        } else {
          
          executeMaybeDescribe();
        } 
        checkValidRowsStatus();



        
        if (this.serverCursor) {
          adjustGotLastBatch();
        }
      } else {
        
        if (this.connection.j2ee13Compliant && !this.sqlKind.isPlsqlOrCall() && this.executionType == 1) {

          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 128);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 
        
        this.currentRank++;
        
        if (this.currentRank >= this.batch) {
          try
          {
            
            this.connection.needLine();
            
            this.cancelLock.enterExecuting();
            
            if (!this.isOpen) {
              
              this.connection.open(this);
              
              this.isOpen = true;
            } 
            
            if (this.queryTimeout != 0) {
              this.connection.getTimeout().setTimeout((this.queryTimeout * 1000), this);
            }
            executeForRows(false);
          }
          catch (SQLException sQLException)
          {
            this.needToParse = true;
            if (this.batch > 1) {
              int[] arrayOfInt;
              clearBatch();




              
              if (this.numberOfExecutedElementsInBatch != -1 && this.numberOfExecutedElementsInBatch < this.batch) {

                
                arrayOfInt = new int[this.numberOfExecutedElementsInBatch];
                for (byte b = 0; b < arrayOfInt.length; b++) {
                  arrayOfInt[b] = -2;
                }
              } else {
                
                arrayOfInt = new int[this.batch];
                for (byte b = 0; b < arrayOfInt.length; b++) {
                  arrayOfInt[b] = -3;
                }
              } 
              BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(sQLException, arrayOfInt.length, arrayOfInt);
              batchUpdateException.fillInStackTrace();
              throw batchUpdateException;
            } 
            
            resetCurrentRowBinders();
            
            throw sQLException;
          }
          finally
          {
            if (this.queryTimeout != 0) {
              this.connection.getTimeout().cancelTimeout();
            }
            this.currentRank = 0;
            this.cancelLock.exitExecuting();
            
            checkValidRowsStatus();

          
          }


        
        }
      
      }

    
    }
    catch (SQLException sQLException) {



      
      resetOnExceptionDuringExecute();
      throw sQLException;
    } 







    
    this.connection.registerHeartbeat();
  }





  
  void resetOnExceptionDuringExecute() {
    this.needToParse = true;
  }








  
  void resetCurrentRowBinders() {}








  
  void open() throws SQLException {
    if (!this.isOpen) {
      
      this.connection.needLine();
      this.connection.open(this);
      
      this.isOpen = true;
    } 
  }














  
  public ResultSet executeQuery(String paramString) throws SQLException {
    synchronized (this.connection) {
      
      OracleResultSet oracleResultSet = null;





      
      try {
        this.executionType = 1;


        
        this.noMoreUpdateCounts = false;
        
        ensureOpen();
        checkIfJdbcBatchExists();
        
        sendBatch();

        
        this.hasStream = false;

        
        this.sqlObject.initialize(paramString);
        
        this.sqlKind = this.sqlObject.getSqlKind();
        this.needToParse = true;
        
        prepareForNewResults(true, true);
        
        if (this.userRsetType == 1) {
          
          doExecuteWithTimeout();
          
          this.currentResultSet = new OracleResultSetImpl(this.connection, this);
          oracleResultSet = this.currentResultSet;
        }
        else {
          
          oracleResultSet = doScrollStmtExecuteQuery();
          
          if (oracleResultSet == null)
          {
            this.currentResultSet = new OracleResultSetImpl(this.connection, this);
            oracleResultSet = this.currentResultSet;
          }
        
        } 
      } finally {
        
        this.executionType = -1;
      } 
      
      return (ResultSet)oracleResultSet;
    } 
  }








  
  public void closeWithKey(String paramString) throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }




























  
  public void close() throws SQLException {
    synchronized (this.connection) {


      
      closeOrCache(null);
    } 
  }



  
  protected void closeOrCache(String paramString) throws SQLException {
    if (this.closed) {
      return;
    }
    
    if (this.connection.lifecycle == 2) {
      this.connection.needLineUnchecked();
    } else {
      this.connection.needLine();
    } 






    
    if (this.statementType != 0 && this.cacheState != 0 && this.cacheState != 3 && this.connection.isStatementCacheInitialized()) {









      
      if (paramString == null)
      {
        if (this.connection.getImplicitCachingEnabled())
        {
          this.connection.cacheImplicitStatement((OraclePreparedStatement)this, this.sqlObject.getOriginalSql(), this.statementType, this.userRsetType);


        
        }
        else
        {

          
          this.cacheState = 0;
          
          hardClose();
        
        }

      
      }
      else if (this.connection.getExplicitCachingEnabled())
      {
        this.connection.cacheExplicitStatement((OraclePreparedStatement)this, paramString);

      
      }
      else
      {

        
        this.cacheState = 0;
        
        hardClose();
      
      }

    
    }
    else {

      
      hardClose();
    } 
  }





  
  protected void hardClose() throws SQLException {
    hardClose(true);
  }







  
  private void hardClose(boolean paramBoolean) throws SQLException {
    alwaysOnClose();
    
    this.describedWithNames = false;
    this.described = false;

    
    this.connection.removeStatement(this);
    
    cleanupDefines();
    
    if (this.isOpen && paramBoolean && (this.connection.lifecycle == 1 || this.connection.lifecycle == 16 || this.connection.lifecycle == 2)) {







      
      this.connection.registerHeartbeat();

      
      doClose();
      
      this.isOpen = false;
    } 
    
    this.sqlObject = null;
  }













  
  protected void alwaysOnClose() throws SQLException {
    OracleStatement oracleStatement = this.children;
    
    while (oracleStatement != null) {
      
      OracleStatement oracleStatement1 = oracleStatement.nextChild;
      
      oracleStatement.close();
      
      oracleStatement = oracleStatement1;
    } 
    
    if (this.parent != null)
    {
      this.parent.removeChild(this);
    }
    
    this.closed = true;

    
    if (this.connection.lifecycle == 1 || this.connection.lifecycle == 2) {


      
      if (this.currentResultSet != null) {
        
        this.currentResultSet.internal_close(false);
        
        this.currentResultSet = null;
      } 
      
      if (this.scrollRset != null) {
        
        this.scrollRset.close();
        
        this.scrollRset = null;
      } 
      
      if (this.returnResultSet != null) {
        
        this.returnResultSet.close();
        this.returnResultSet = null;
      } 
    } 
    
    clearWarnings();
    
    this.m_batchItems = null;
  }












  
  void closeLeaveCursorOpen() throws SQLException {
    synchronized (this.connection) {




      
      if (this.closed) {
        return;
      }

      
      hardClose(false);
    } 
  }














  
  public int executeUpdate(String paramString) throws SQLException {
    synchronized (this.connection) {



      
      setNonAutoKey();
      return executeUpdateInternal(paramString);
    } 
  }





  
  int executeUpdateInternal(String paramString) throws SQLException {
    try {
      if (this.executionType == -1) {
        this.executionType = 2;
      }
      
      this.noMoreUpdateCounts = false;
      
      ensureOpen();
      checkIfJdbcBatchExists();
      
      sendBatch();

      
      this.hasStream = false;

      
      this.sqlObject.initialize(paramString);
      
      this.sqlKind = this.sqlObject.getSqlKind();
      this.needToParse = true;
      
      prepareForNewResults(true, true);
      
      if (this.userRsetType == 1) {
        
        doExecuteWithTimeout();
      }
      else {
        
        doScrollStmtExecuteQuery();
      } 
      
      return this.validRows;
    }
    finally {
      
      this.executionType = -1;
    } 
  }











  
  public boolean execute(String paramString) throws SQLException {
    synchronized (this.connection) {



      
      setNonAutoKey();
      return executeInternal(paramString);
    } 
  }





  
  boolean executeInternal(String paramString) throws SQLException {
    try {
      this.executionType = 3;
      
      this.checkSum = 0L;
      this.checkSumComputationFailure = false;

      
      this.noMoreUpdateCounts = false;
      
      ensureOpen();
      checkIfJdbcBatchExists();
      
      sendBatch();


      
      this.hasStream = false;

      
      this.sqlObject.initialize(paramString);
      
      this.sqlKind = this.sqlObject.getSqlKind();
      this.needToParse = true;
      
      prepareForNewResults(true, true);
      
      if (this.userRsetType == 1) {
        
        doExecuteWithTimeout();
      }
      else {
        
        doScrollStmtExecuteQuery();
      } 
      
      return this.sqlKind.isSELECT();
    }
    finally {
      
      this.executionType = -1;
    } 
  }



  
  int getNumberOfColumns() throws SQLException {
    ensureOpen();
    if (!this.described)
    {
      synchronized (this.connection) {
        doDescribe(false);
        
        this.described = true;
      } 
    }
    
    return this.numberOfDefinePositions;
  }



  
  Accessor[] getDescription() throws SQLException {
    ensureOpen();
    if (!this.described)
    {
      synchronized (this.connection) {
        doDescribe(false);
        
        this.described = true;
      } 
    }
    
    return this.accessors;
  }



  
  Accessor[] getDescriptionWithNames() throws SQLException {
    ensureOpen();
    if (!this.describedWithNames)
    {
      synchronized (this.connection) {
        doDescribe(true);
        
        this.described = true;
        this.describedWithNames = true;
      } 
    }
    
    return this.accessors;
  }









  
  public OracleStatement.SqlKind getSqlKind() throws SQLException {
    return this.sqlObject.getSqlKind();
  }
















  
  public void clearDefines() throws SQLException {
    synchronized (this.connection) {

      
      freeLine();
      
      this.streamList = null;





      
      this.columnsDefinedByUser = false;
      this.needToPrepareDefineBuffer = true;

      
      this.numberOfDefinePositions = 0;
      this.definesBatchSize = 0;
      
      this.described = false;
      this.describedWithNames = false;
      
      cleanupDefines();
    } 
  }








  
  void reparseOnRedefineIfNeeded() throws SQLException {}







  
  void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, String paramString) throws SQLException {
    defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, (short)1, paramBoolean, paramString);
  }







  
  void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, short paramShort, boolean paramBoolean, String paramString) throws SQLException {
    if (this.connection.disableDefinecolumntype) {
      return;
    }

    
    if (paramInt1 < 1) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (paramInt2 == 0) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    int i = paramInt1 - 1;
    int j = (this.maxFieldSize > 0) ? this.maxFieldSize : -1;
    
    if (paramBoolean) {


      
      if (paramInt2 == 1 || paramInt2 == 12)
      {


        
        this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 108);
      
      }
    
    }
    else {
      
      if (paramInt3 < 0) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      if ((j == -1 && paramInt3 > 0) || (j && paramInt3 < j))
      {
        j = paramInt3;
      }
    } 
    if (this.currentResultSet != null && !this.currentResultSet.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 28);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (!this.columnsDefinedByUser) {


      
      clearDefines();
      
      this.columnsDefinedByUser = true;
    } 
    
    if (this.numberOfDefinePositions < paramInt1) {
      
      if (this.accessors == null || this.accessors.length < paramInt1) {
        
        Accessor[] arrayOfAccessor = new Accessor[paramInt1 << 1];
        
        if (this.accessors != null) {
          System.arraycopy(this.accessors, 0, arrayOfAccessor, 0, this.numberOfDefinePositions);
        }
        this.accessors = arrayOfAccessor;
      } 
      
      this.numberOfDefinePositions = paramInt1;
    } 




    
    int k = getInternalType(paramInt2);
    
    if ((k == 109 || k == 111) && (paramString == null || paramString.equals(""))) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "Invalid arguments");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    Accessor accessor = this.accessors[i];
    boolean bool = true;
    
    if (accessor != null) {



      
      int m = accessor.useForDataAccessIfPossible(k, paramInt2, j, paramString);

      
      if (m == 0) {
        
        paramShort = accessor.formOfUse;
        accessor = null;
        
        reparseOnRedefineIfNeeded();
      }
      else if (m == 1) {
        
        accessor = null;
        
        reparseOnRedefineIfNeeded();
      }
      else if (m == 2) {
        bool = false;
      } 
    } 
    if (bool) {
      this.needToPrepareDefineBuffer = true;
    }
    if (accessor == null) {
      
      this.accessors[i] = allocateAccessor(k, paramInt2, paramInt1, j, paramShort, paramString, false);
      
      this.described = false;
      this.describedWithNames = false;
    } 
  }
































  
  Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean) throws SQLException {
    BlobAccessor blobAccessor;
    ClobAccessor clobAccessor;
    BfileAccessor bfileAccessor;
    NamedTypeAccessor namedTypeAccessor;
    RefTypeAccessor refTypeAccessor;
    switch (paramInt1) {

      
      case 96:
        if (paramBoolean && paramString != null) {
          
          SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
          sQLException1.fillInStackTrace();
          throw sQLException1;
        } 
        
        return new CharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
      
      case 8:
        if (paramBoolean && paramString != null) {
          
          SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
          sQLException1.fillInStackTrace();
          throw sQLException1;
        } 
        
        if (!paramBoolean) {
          return new LongAccessor(this, paramInt3, paramInt4, paramShort, paramInt2);
        }

      
      case 1:
        if (paramBoolean && paramString != null) {
          
          SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
          sQLException1.fillInStackTrace();
          throw sQLException1;
        } 
        
        return new VarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
      
      case 2:
        if (paramBoolean && paramString != null) {
          
          SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
          sQLException1.fillInStackTrace();
          throw sQLException1;
        } 
        
        return new NumberAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
      
      case 6:
        if (paramBoolean && paramString != null) {
          
          SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
          sQLException1.fillInStackTrace();
          throw sQLException1;
        } 
        
        return new VarnumAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
      
      case 24:
        if (paramBoolean && paramString != null) {
          
          SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
          sQLException1.fillInStackTrace();
          throw sQLException1;
        } 
        
        if (!paramBoolean) {
          return new LongRawAccessor(this, paramInt3, paramInt4, paramShort, paramInt2);
        }


      
      case 23:
        if (paramBoolean && paramString != null) {
          
          SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
          sQLException1.fillInStackTrace();
          throw sQLException1;
        } 
        
        if (paramBoolean) {
          return new OutRawAccessor(this, paramInt4, paramShort, paramInt2);
        }
        return new RawAccessor(this, paramInt4, paramShort, paramInt2, false);
      
      case 100:
        if (paramBoolean && paramString != null) {
          
          SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
          sQLException1.fillInStackTrace();
          throw sQLException1;
        } 
        
        return new BinaryFloatAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);

      
      case 101:
        if (paramBoolean && paramString != null) {
          
          SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
          sQLException1.fillInStackTrace();
          throw sQLException1;
        } 
        
        return new BinaryDoubleAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);

      
      case 104:
        if (paramBoolean && paramString != null) {
          
          SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
          sQLException1.fillInStackTrace();
          throw sQLException1;
        } 
        if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) {
          
          paramInt4 = 18;
          VarcharAccessor varcharAccessor = new VarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
          varcharAccessor.definedColumnType = -8;
          return varcharAccessor;
        } 
        return new RowidAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
      
      case 102:
        if (paramBoolean && paramString != null) {
          
          SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
          sQLException1.fillInStackTrace();
          throw sQLException1;
        } 
        
        return new ResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
      
      case 12:
        if (paramBoolean && paramString != null) {
          
          SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
          sQLException1.fillInStackTrace();
          throw sQLException1;
        } 
        
        return new DateAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
      
      case 113:
        if (paramBoolean && paramString != null) {
          
          SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
          sQLException1.fillInStackTrace();
          throw sQLException1;
        } 
        
        blobAccessor = new BlobAccessor(this, -1, paramShort, paramInt2, paramBoolean);
        if (!paramBoolean)
          blobAccessor.lobPrefetchSizeForThisColumn = paramInt4; 
        return blobAccessor;
      
      case 112:
        if (paramBoolean && paramString != null) {
          
          SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
          sQLException1.fillInStackTrace();
          throw sQLException1;
        } 
        
        clobAccessor = new ClobAccessor(this, -1, paramShort, paramInt2, paramBoolean);
        if (!paramBoolean)
          clobAccessor.lobPrefetchSizeForThisColumn = paramInt4; 
        return clobAccessor;
      
      case 114:
        if (paramBoolean && paramString != null) {
          
          SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
          sQLException1.fillInStackTrace();
          throw sQLException1;
        } 
        
        return new BfileAccessor(this, -1, paramShort, paramInt2, paramBoolean);




      
      case 109:
        if (paramString == null) {
          if (paramBoolean) {
            
            SQLException sQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
            sQLException2.fillInStackTrace();
            throw sQLException2;
          } 

          
          SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "Unable to resolve type \"null\"");
          sQLException1.fillInStackTrace();
          throw sQLException1;
        } 
        
        namedTypeAccessor = new NamedTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean);

        
        namedTypeAccessor.initMetadata();
        
        return namedTypeAccessor;
      
      case 111:
        if (paramString == null) {
          if (paramBoolean) {
            
            SQLException sQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
            sQLException2.fillInStackTrace();
            throw sQLException2;
          } 

          
          SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "Unable to resolve type \"null\"");
          sQLException1.fillInStackTrace();
          throw sQLException1;
        } 
        
        refTypeAccessor = new RefTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean);

        
        refTypeAccessor.initMetadata();
        
        return refTypeAccessor;


      
      case 180:
        if (paramBoolean && paramString != null) {
          
          SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
          sQLException1.fillInStackTrace();
          throw sQLException1;
        } 
        
        return new TimestampAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);

      
      case 181:
        if (paramBoolean && paramString != null) {
          
          SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
          sQLException1.fillInStackTrace();
          throw sQLException1;
        } 
        
        return new TimestamptzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);

      
      case 231:
        if (paramBoolean && paramString != null) {
          
          SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
          sQLException1.fillInStackTrace();
          throw sQLException1;
        } 
        
        return new TimestampltzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);

      
      case 182:
        if (paramBoolean && paramString != null) {
          
          SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
          sQLException1.fillInStackTrace();
          throw sQLException1;
        } 
        
        return new IntervalymAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);

      
      case 183:
        if (paramBoolean && paramString != null) {
          
          SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
          sQLException1.fillInStackTrace();
          throw sQLException1;
        } 
        
        return new IntervaldsAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
















      
      case 995:
        sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
        sQLException.fillInStackTrace();
        throw sQLException;
    } 


    
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
    sQLException.fillInStackTrace();
    throw sQLException;
  }
















































  
  public void defineColumnType(int paramInt1, int paramInt2) throws SQLException {
    synchronized (this.connection) {
      
      defineColumnTypeInternal(paramInt1, paramInt2, -1, true, null);
    } 
  }











  
  public void defineColumnType(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
    defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, false, null);
  }















  
  public void defineColumnType(int paramInt1, int paramInt2, int paramInt3, short paramShort) throws SQLException {
    defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, paramShort, false, null);
  }



































































  
  public void defineColumnTypeBytes(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
    synchronized (this.connection) {

      
      defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, false, null);
    } 
  }


































































  
  public void defineColumnTypeChars(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
    defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, false, null);
  }




































  
  public void defineColumnType(int paramInt1, int paramInt2, String paramString) throws SQLException {
    synchronized (this.connection) {




      
      defineColumnTypeInternal(paramInt1, paramInt2, -1, true, paramString);
    } 
  }











  
  void setCursorId(int paramInt) throws SQLException {
    this.cursorId = paramInt;
  }











  
  void setPrefetchInternal(int paramInt, boolean paramBoolean1, boolean paramBoolean2) throws SQLException {
    if (paramBoolean1) {
      
      if (paramInt <= 0)
      {
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 20);
        sQLException.fillInStackTrace();
        throw sQLException;
      }
    
    } else {
      
      if (paramInt < 0) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setFetchSize");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      if (paramInt == 0) {
        paramInt = this.connection.getDefaultRowPrefetch();
      }
    } 
    
    if (paramBoolean2) {
      
      if (paramInt != this.defaultRowPrefetch)
      {
        this.defaultRowPrefetch = paramInt;


        
        if (this.currentResultSet == null || this.currentResultSet.closed) {
          this.rowPrefetchChanged = true;
        
        }
      
      }
    
    }
    else if (paramInt != this.rowPrefetch && this.streamList == null) {

      
      this.rowPrefetch = paramInt;
      this.rowPrefetchChanged = true;
    } 
  }






















  
  public void setRowPrefetch(int paramInt) throws SQLException {
    synchronized (this.connection) {


      
      setPrefetchInternal(paramInt, true, true);
    } 
  }








  
  public void setLobPrefetchSize(int paramInt) throws SQLException {
    synchronized (this.connection) {
      
      if (paramInt < -1) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 267);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      this.defaultLobPrefetchSize = paramInt;
    } 
  }



  
  public int getLobPrefetchSize() {
    return this.defaultLobPrefetchSize;
  }













  
  int getPrefetchInternal(boolean paramBoolean) {
    return paramBoolean ? this.defaultRowPrefetch : this.rowPrefetch;
  }













  
  public int getRowPrefetch() {
    synchronized (this.connection) {

      
      return getPrefetchInternal(true);
    } 
  }






















  
  public void setFixedString(boolean paramBoolean) {
    this.fixedString = paramBoolean;
  }





















  
  public boolean getFixedString() {
    return this.fixedString;
  }











  
  void check_row_prefetch_changed() throws SQLException {
    if (this.rowPrefetchChanged) {
      
      if (this.streamList == null) {
        
        prepareAccessors();
        
        this.needToPrepareDefineBuffer = true;
      } 
      
      this.rowPrefetchChanged = false;
    } 
  }










  
  void setDefinesInitialized(boolean paramBoolean) {}









  
  void printState(String paramString) throws SQLException {}









  
  void checkValidRowsStatus() throws SQLException {
    if (this.validRows == -2) {


      
      this.validRows = 1;
      this.connection.holdLine(this);

      
      OracleInputStream oracleInputStream = this.streamList;
      
      while (oracleInputStream != null) {
        
        if (oracleInputStream.hasBeenOpen) {
          oracleInputStream = oracleInputStream.accessor.initForNewRow();
        }




        
        oracleInputStream.closed = false;
        oracleInputStream.hasBeenOpen = true;


        
        oracleInputStream = oracleInputStream.nextStream;
      } 


      
      this.nextStream = this.streamList;
    
    }
    else if (this.sqlKind.isSELECT()) {
      
      if (this.validRows < this.rowPrefetch) {
        this.gotLastBatch = true;
      }
    } else if (!this.sqlKind.isPlsqlOrCall()) {
      
      this.rowsProcessed = this.validRows;
    } 
  }



  
  void cleanupDefines() {
    if (this.accessors != null)
      for (byte b = 0; b < this.accessors.length; b++) {
        this.accessors[b] = null;
      } 
    this.accessors = null;

    
    this.connection.cacheBuffer(this.defineBytes);
    this.defineBytes = null;
    this.connection.cacheBuffer(this.defineChars);
    this.defineChars = null;
    this.defineIndicators = null;
    this.defineMetaData = null;
  }



  
  public int getMaxFieldSize() throws SQLException {
    synchronized (this.connection) {
      
      return this.maxFieldSize;
    } 
  }


  
  public void setMaxFieldSize(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      if (paramInt < 0) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      this.maxFieldSize = paramInt;
    } 
  }



  
  public int getMaxRows() throws SQLException {
    return this.maxRows;
  }


  
  public void setMaxRows(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      if (paramInt < 0) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      this.maxRows = paramInt;
    } 
  }



  
  public void setEscapeProcessing(boolean paramBoolean) throws SQLException {
    synchronized (this.connection) {
      
      this.processEscapes = paramBoolean;
    } 
  }









  
  public int getQueryTimeout() throws SQLException {
    synchronized (this.connection) {
      
      return this.queryTimeout;
    } 
  }










  
  public void setQueryTimeout(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      if (paramInt < 0) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      this.queryTimeout = paramInt;
    } 
  }








  
  public void cancel() throws SQLException {
    doCancel();
  }



  
  boolean doCancel() throws SQLException {
    boolean bool = false;



    
    if (this.closed) {
      return bool;
    }









    
    if (this.connection.statementHoldingLine != null) {
      freeLine();
    } else if (this.cancelLock.enterCanceling()) {
      
      try {
        bool = true;
        this.connection.cancelOperationOnServer(true);
      } finally {
        
        this.cancelLock.exitCanceling();
      } 
    } else {
      
      return bool;
    } 
    OracleStatement oracleStatement = this.children;
    while (oracleStatement != null) {
      bool = (bool || oracleStatement.doCancel()) ? true : false;
      oracleStatement = oracleStatement.nextChild;
    } 
    
    this.connection.releaseLineForCancel();
    return bool;
  }













  
  public SQLWarning getWarnings() throws SQLException {
    return this.sqlWarning;
  }






  
  public void clearWarnings() throws SQLException {
    this.sqlWarning = null;
  }




  
  void foundPlsqlCompilerWarning() throws SQLException {
    SQLWarning sQLWarning = DatabaseError.addSqlWarning(this.sqlWarning, "Found Plsql compiler warnings.", 24439);
    
    if (this.sqlWarning != null) {
      
      this.sqlWarning.setNextWarning(sQLWarning);
    }
    else {
      
      this.sqlWarning = sQLWarning;
    } 
  }







  
  public void setCursorName(String paramString) throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }









  
  public ResultSet getResultSet() throws SQLException {
    synchronized (this.connection) {

      
      if (this.userRsetType == 1) {
        
        if (this.sqlKind.isSELECT())
        {
          if (this.currentResultSet == null) {
            this.currentResultSet = new OracleResultSetImpl(this.connection, this);
          }
          return (ResultSet)this.currentResultSet;
        }
      
      } else {
        
        return (ResultSet)this.scrollRset;
      } 
      
      return null;
    } 
  }












  
  public int getUpdateCount() throws SQLException {
    synchronized (this.connection) {
      
      int i = -1;
      
      switch (this.sqlKind) {







        
        case ALTER_SESSION:
        case OTHER:
          if (!this.noMoreUpdateCounts) {
            i = this.rowsProcessed;
          }
          this.noMoreUpdateCounts = true;
          break;



        
        case PLSQL_BLOCK:
        case CALL_BLOCK:
          this.noMoreUpdateCounts = true;
          break;



        
        case DELETE:
        case INSERT:
        case MERGE:
        case UPDATE:
          if (!this.noMoreUpdateCounts) {
            i = this.rowsProcessed;
          }
          this.noMoreUpdateCounts = true;
          break;
      } 

      
      return i;
    } 
  }







  
  public boolean getMoreResults() throws SQLException {
    return false;
  }







  
  public int sendBatch() throws SQLException {
    return 0;
  }







  
  void prepareForNewResults(boolean paramBoolean1, boolean paramBoolean2) throws SQLException {
    clearWarnings();
    
    if (this.streamList != null) {


      
      while (this.nextStream != null) {

        
        try {
          this.nextStream.close();
        }
        catch (IOException iOException) {

          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 

        
        this.nextStream = this.nextStream.nextStream;
      } 
      
      if (paramBoolean2) {

        
        OracleInputStream oracleInputStream1 = this.streamList;
        OracleInputStream oracleInputStream2 = null;
        
        this.streamList = null;
        
        while (oracleInputStream1 != null) {
          
          if (!oracleInputStream1.hasBeenOpen) {
            
            if (oracleInputStream2 == null) {
              this.streamList = oracleInputStream1;
            } else {
              oracleInputStream2.nextStream = oracleInputStream1;
            } 
            oracleInputStream2 = oracleInputStream1;
          } 
          
          oracleInputStream1 = oracleInputStream1.nextStream;
        } 
      } 
    } 
    
    if (this.currentResultSet != null) {
      
      this.currentResultSet.internal_close(true);
      
      this.currentResultSet = null;
    } 
    
    this.currentRow = -1;
    this.checkSum = 0L;
    this.checkSumComputationFailure = false;
    this.validRows = 0;
    if (paramBoolean1)
      this.totalRowsVisited = 0; 
    this.gotLastBatch = false;
    
    if (this.needToParse && !this.columnsDefinedByUser) {
      
      if (paramBoolean2 && this.numberOfDefinePositions != 0) {
        this.numberOfDefinePositions = 0;
      }
      this.needToPrepareDefineBuffer = true;
    } 

    
    if (paramBoolean1 && this.rowPrefetch != this.defaultRowPrefetch && this.streamList == null) {


      
      this.rowPrefetch = this.defaultRowPrefetch;
      this.rowPrefetchChanged = true;
    } 
  }









  
  void reopenStreams() throws SQLException {
    OracleInputStream oracleInputStream = this.streamList;
    
    while (oracleInputStream != null) {
      
      if (oracleInputStream.hasBeenOpen) {
        oracleInputStream = oracleInputStream.accessor.initForNewRow();
      }
      oracleInputStream.closed = false;
      oracleInputStream.hasBeenOpen = true;
      oracleInputStream = oracleInputStream.nextStream;
    } 
    
    this.nextStream = this.streamList;
  }








  
  void endOfResultSet(boolean paramBoolean) throws SQLException {
    if (!paramBoolean)
    {
      
      prepareForNewResults(false, false);
    }


    
    clearDefines();
    this.rowPrefetchInLastFetch = -1;
  }





















  
  boolean wasNullValue() throws SQLException {
    if (this.lastIndex == 0) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 24);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.sqlKind.isSELECT()) {
      return this.accessors[this.lastIndex - 1].isNull(this.currentRow);
    }
    return this.outBindAccessors[this.lastIndex - 1].isNull(this.currentRank);
  }










  
  int getColumnIndex(String paramString) throws SQLException {
    ensureOpen();
    if (!this.describedWithNames)
    {
      synchronized (this.connection) {
        doDescribe(true);
        
        this.described = true;
        this.describedWithNames = true;
      } 
    }
    
    for (byte b = 0; b < this.numberOfDefinePositions; b++) {
      if ((this.accessors[b]).columnName.equalsIgnoreCase(paramString)) {
        return b + 1;
      }
    } 
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  int getJDBCType(int paramInt) throws SQLException {
    int i = 0;
    switch (paramInt)
    
    { case 6:
        i = 2;









































































        
        return i;case 100: i = 100; return i;case 101: i = 101; return i;case 999: i = 999; return i;case 96: i = 1; return i;case 1: i = 12; return i;case 8: i = -1; return i;case 12: i = 91; return i;case 180: i = 93; return i;case 181: i = -101; return i;case 231: i = -102; return i;case 182: i = -103; return i;case 183: i = -104; return i;case 23: i = -2; return i;case 24: i = -4; return i;case 104: i = -8; return i;case 113: i = 2004; return i;case 112: i = 2005; return i;case 114: i = -13; return i;case 102: i = -10; return i;case 109: i = 2002; return i;case 111: i = 2006; return i;case 998: i = -14; return i;case 995: i = 0; return i; }  i = paramInt; return i;
  }



  
  int getInternalType(int paramInt) throws SQLException {
    char c = Character.MIN_VALUE;
    
    switch (paramInt) {
      
      case -7:
      case -6:
      case -5:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
        c = '\006';




























































































































        
        return c;case 100: c = 'd'; return c;case 101: c = 'e'; return c;case 999: c = 'ϧ'; return c;case 1: c = '`'; return c;case 12: c = '\001'; return c;case -1: c = '\b'; return c;case 91: case 92: c = '\f'; return c;case -100: case 93: c = '´'; return c;case -101: c = 'µ'; return c;case -102: c = 'ç'; return c;case -103: c = '¶'; return c;case -104: c = '·'; return c;case -3: case -2: c = '\027'; return c;case -4: c = '\030'; return c;case -8: c = 'h'; return c;case 2004: c = 'q'; return c;case 2005: c = 'p'; return c;case -13: c = 'r'; return c;case -10: c = 'f'; return c;case 2002: case 2003: case 2007: case 2008: c = 'm'; return c;case 2006: c = 'o'; return c;case -14: c = 'Ϧ'; return c;case 70: c = '\001'; return c;case 0: c = 'ϣ'; return c;
    } 
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, Integer.toString(paramInt));
    sQLException.fillInStackTrace();
    throw sQLException;
  }










  
  void describe() throws SQLException {
    synchronized (this.connection) {
      
      ensureOpen();
      if (!this.described)
      {
        doDescribe(false);
      }
    } 
  }



  
  void freeLine() throws SQLException {
    if (this.streamList != null)
    {

      
      while (this.nextStream != null) {

        
        try {
          this.nextStream.close();
        }
        catch (IOException iOException) {

          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 

        
        this.nextStream = this.nextStream.nextStream;
      } 
    }
  }







  
  void closeUsedStreams(int paramInt) throws SQLException {
    while (this.nextStream != null && this.nextStream.columnIndex < paramInt) {

      
      try {

        
        this.nextStream.close();
      }
      catch (IOException iOException) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      this.nextStream = this.nextStream.nextStream;
    } 
  }







  
  final void ensureOpen() throws SQLException {
    if (this.connection.lifecycle != 1) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    if (this.closed) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }














  
  void allocateTmpByteArray() {}













  
  public void setFetchDirection(int paramInt) throws SQLException {
    synchronized (this.connection) {
      
      if (paramInt == 1000) {

        
        this.defaultFetchDirection = paramInt;
      }
      else if (paramInt == 1001 || paramInt == 1002) {

        
        this.defaultFetchDirection = 1000;
        this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 87);
      
      }
      else {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setFetchDirection");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    } 
  }

















  
  public int getFetchDirection() throws SQLException {
    return this.defaultFetchDirection;
  }















  
  public void setFetchSize(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      setPrefetchInternal(paramInt, false, true);
    } 
  }


















  
  public int getFetchSize() throws SQLException {
    return getPrefetchInternal(true);
  }








  
  public int getResultSetConcurrency() throws SQLException {
    return ResultSetUtil.getUpdateConcurrency(this.userRsetType);
  }








  
  public int getResultSetType() throws SQLException {
    return ResultSetUtil.getScrollType(this.userRsetType);
  }











  
  public Connection getConnection() throws SQLException {
    return (Connection)this.connection.getWrapper();
  }









  
  public void setResultSetCache(OracleResultSetCache paramOracleResultSetCache) throws SQLException {
    synchronized (this.connection) {

      
      try {
        if (paramOracleResultSetCache == null) {
          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 
        
        if (this.rsetCache != null) {
          this.rsetCache.close();
        }
        this.rsetCache = paramOracleResultSetCache;
      }
      catch (IOException iOException) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    } 
  }











  
  public void setResultSetCache(OracleResultSetCache paramOracleResultSetCache) throws SQLException {
    synchronized (this.connection) {
      
      setResultSetCache((OracleResultSetCache)paramOracleResultSetCache);
    } 
  }






  
  public OracleResultSetCache getResultSetCache() throws SQLException {
    synchronized (this.connection) {
      
      return (OracleResultSetCache)this.rsetCache;
    } 
  }




  
  boolean isOracleBatchStyle() {
    return false;
  }
  void initBatch() {}
  int getBatchSize() { if (this.m_batchItems == null) return 0;  return this.m_batchItems.size(); }
  void addBatchItem(String paramString) { if (this.m_batchItems == null) this.m_batchItems = new Vector();  this.m_batchItems.addElement(paramString); }
  String getBatchItem(int paramInt) { return this.m_batchItems.elementAt(paramInt); }
  void clearBatchItems() { this.m_batchItems.removeAllElements(); }
  void checkIfJdbcBatchExists() throws SQLException { if (getBatchSize() > 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 81, "batch must be either executed or cleared"); sQLException.fillInStackTrace(); throw sQLException; }  }
  public void addBatch(String paramString) throws SQLException { synchronized (this.connection) { addBatchItem(paramString); }  }
  public void clearBatch() throws SQLException { synchronized (this.connection) { clearBatchItems(); }  }
  public int[] executeBatch() throws SQLException { synchronized (this.connection) { cleanOldTempLobs(); byte b = 0; int i = getBatchSize(); this.checkSum = 0L; this.checkSumComputationFailure = false; if (i <= 0) return new int[0];  int[] arrayOfInt = new int[i]; ensureOpen(); prepareForNewResults(true, true); int j = this.numberOfDefinePositions; String str = this.sqlObject.getOriginalSql(); OracleStatement.SqlKind sqlKind = this.sqlKind; this.noMoreUpdateCounts = false; int k = 0; try { this.connection.registerHeartbeat(); this.connection.needLine(); for (b = 0; b < i; b++) { this.sqlObject.initialize(getBatchItem(b)); this.sqlKind = this.sqlObject.getSqlKind(); this.needToParse = true; this.numberOfDefinePositions = 0; this.rowsProcessed = 0; this.currentRank = 1; if (this.sqlKind.isSELECT()) { BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(80, "invalid SELECT batch command " + b, b, arrayOfInt); batchUpdateException.fillInStackTrace(); throw batchUpdateException; }  if (!this.isOpen) { this.connection.open(this); this.isOpen = true; }  int m = -1; try { if (this.queryTimeout != 0) this.connection.getTimeout().setTimeout((this.queryTimeout * 1000), this);  this.cancelLock.enterExecuting(); executeForRows(false); if (this.validRows > 0) k += this.validRows;  m = this.validRows; } catch (SQLException sQLException) { this.needToParse = true; resetCurrentRowBinders(); throw sQLException; } finally { if (this.queryTimeout != 0) this.connection.getTimeout().cancelTimeout();  this.validRows = k; this.cancelLock.exitExecuting(); checkValidRowsStatus(); }  arrayOfInt[b] = m; if (arrayOfInt[b] < 0) { BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(81, "command return value " + arrayOfInt[b], b, arrayOfInt); batchUpdateException.fillInStackTrace(); throw batchUpdateException; }  }  } catch (SQLException sQLException) { if (sQLException instanceof BatchUpdateException) throw sQLException;  BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(81, sQLException.getMessage(), b, arrayOfInt); batchUpdateException.fillInStackTrace(); throw batchUpdateException; } finally { clearBatchItems(); this.numberOfDefinePositions = j; if (str != null) { this.sqlObject.initialize(str); this.sqlKind = sqlKind; }  this.currentRank = 0; }  this.connection.registerHeartbeat(); return arrayOfInt; }  }
  public int copyBinds(Statement paramStatement, int paramInt) throws SQLException { return 0; }
  public void notifyCloseRset() throws SQLException { this.scrollRset = null; endOfResultSet(false); }
  public String getOriginalSql() throws SQLException { return this.sqlObject.getOriginalSql(); }
  void doScrollExecuteCommon() throws SQLException { if (this.scrollRset != null) { this.scrollRset.close(); this.scrollRset = null; }  if (!this.sqlKind.isSELECT()) { doExecuteWithTimeout(); return; }  if (!this.needToAddIdentifier) { doExecuteWithTimeout(); this.currentResultSet = new OracleResultSetImpl(this.connection, this); this.realRsetType = this.userRsetType; } else { try { this.sqlObject.setIncludeRowid(true); this.needToParse = true; prepareForNewResults(true, false); if (this.columnsDefinedByUser) { Accessor[] arrayOfAccessor = this.accessors; if (this.accessors == null || this.accessors.length <= this.numberOfDefinePositions) this.accessors = new Accessor[this.numberOfDefinePositions + 1];  if (arrayOfAccessor != null) for (int i = this.numberOfDefinePositions; i > 0; i--) { Accessor accessor = arrayOfAccessor[i - 1]; this.accessors[i] = accessor; if (accessor.isColumnNumberAware) accessor.updateColumnNumber(i);  }   allocateRowidAccessor(); this.numberOfDefinePositions++; }  doExecuteWithTimeout(); this.currentResultSet = new OracleResultSetImpl(this.connection, this); this.realRsetType = this.userRsetType; } catch (SQLException sQLException) { if (this.userRsetType > 3) { this.realRsetType = 3; } else { this.realRsetType = 1; }  this.sqlObject.setIncludeRowid(false); this.needToParse = true; prepareForNewResults(true, false); if (this.columnsDefinedByUser) { this.needToPrepareDefineBuffer = true; this.numberOfDefinePositions--; System.arraycopy(this.accessors, 1, this.accessors, 0, this.numberOfDefinePositions); this.accessors[this.numberOfDefinePositions] = null; for (byte b = 0; b < this.numberOfDefinePositions; b++) { Accessor accessor = this.accessors[b]; if (accessor.isColumnNumberAware) accessor.updateColumnNumber(b);  }  }  moveAllTempLobsToFree(); doExecuteWithTimeout(); this.currentResultSet = new OracleResultSetImpl(this.connection, this); this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 91, sQLException.getMessage()); }  }  this.scrollRset = ResultSetUtil.createScrollResultSet(this, this.currentResultSet, this.realRsetType); }
  void allocateRowidAccessor() throws SQLException { this.accessors[0] = new RowidAccessor(this, 128, (short)1, -8, false); }
  OracleResultSet doScrollStmtExecuteQuery() throws SQLException { doScrollExecuteCommon(); return this.scrollRset; }
  void processDmlReturningBind() throws SQLException { if (this.returnResultSet != null) this.returnResultSet.close();  this.returnParamsFetched = false; this.returnParamRowBytes = 0; this.returnParamRowChars = 0; byte b1 = 0; for (byte b2 = 0; b2 < this.numberOfBindPositions; b2++) { Accessor accessor = this.returnParamAccessors[b2]; if (accessor != null) { b1++; if (accessor.charLength > 0) { this.returnParamRowChars += accessor.charLength; } else { this.returnParamRowBytes += accessor.byteLength; }  }  }  if (this.isAutoGeneratedKey) { this.numReturnParams = b1; } else { if (this.numReturnParams <= 0) this.numReturnParams = this.sqlObject.getReturnParameterCount();  if (this.numReturnParams != b1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 173); sQLException.fillInStackTrace(); throw sQLException; }  }  this.returnParamMeta[0] = this.numReturnParams; this.returnParamMeta[1] = this.returnParamRowBytes; this.returnParamMeta[2] = this.returnParamRowChars; }
  void allocateDmlReturnStorage() { if (this.rowsDmlReturned == 0) return;  int i = this.returnParamRowBytes * this.rowsDmlReturned; int j = this.returnParamRowChars * this.rowsDmlReturned; int k = 2 * this.numReturnParams * this.rowsDmlReturned; this.returnParamBytes = new byte[i]; this.returnParamChars = new char[j]; this.returnParamIndicators = new short[k]; for (byte b = 0; b < this.numberOfBindPositions; b++) { Accessor accessor = this.returnParamAccessors[b]; if (accessor != null && (accessor.internalType == 111 || accessor.internalType == 109)) { TypeAccessor typeAccessor = (TypeAccessor)accessor; if (typeAccessor.pickledBytes == null || typeAccessor.pickledBytes.length < this.rowsDmlReturned) typeAccessor.pickledBytes = new byte[this.rowsDmlReturned][];  }  }  }
  void fetchDmlReturnParams() throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
  void setupReturnParamAccessors() { if (this.rowsDmlReturned == 0) return;  int i = 0; int j = 0; int k = 0; int m = this.numReturnParams * this.rowsDmlReturned; for (byte b = 0; b < this.numberOfBindPositions; b++) { Accessor accessor = this.returnParamAccessors[b]; if (accessor != null) { if (accessor.charLength > 0) { accessor.rowSpaceChar = this.returnParamChars; accessor.columnIndex = j; j += this.rowsDmlReturned * accessor.charLength; } else { accessor.rowSpaceByte = this.returnParamBytes; accessor.columnIndex = i; i += this.rowsDmlReturned * accessor.byteLength; }  accessor.rowSpaceIndicator = this.returnParamIndicators; accessor.indicatorIndex = k; k += this.rowsDmlReturned; accessor.lengthIndex = m; m += this.rowsDmlReturned; }  }  }
  void registerReturnParameterInternal(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString) throws SQLException { if (this.returnParamAccessors == null) this.returnParamAccessors = new Accessor[this.numberOfBindPositions];  if (this.returnParamMeta == null) this.returnParamMeta = new int[3 + this.numberOfBindPositions * 4];  Accessor accessor = allocateAccessor(paramInt2, paramInt3, paramInt1 + 1, paramInt4, paramShort, paramString, true); accessor.isDMLReturnedParam = true; this.returnParamAccessors[paramInt1] = accessor; boolean bool = (accessor.charLength > 0) ? true : false; this.returnParamMeta[3 + paramInt1 * 4 + 0] = accessor.defineType; this.returnParamMeta[3 + paramInt1 * 4 + 1] = bool ? 1 : 0; this.returnParamMeta[3 + paramInt1 * 4 + 2] = bool ? accessor.charLength : accessor.byteLength; this.returnParamMeta[3 + paramInt1 * 4 + 3] = paramShort; }
  public int creationState() { synchronized (this.connection) { return this.creationState; }  }
  public boolean isColumnSetNull(int paramInt) { return this.columnSetNull; } public boolean isNCHAR(int paramInt) throws SQLException { if (!this.described)
      describe();  int i = paramInt - 1; if (i < 0 || i >= this.numberOfDefinePositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  return ((this.accessors[i]).formOfUse == 2); } void addChild(OracleStatement paramOracleStatement) { paramOracleStatement.nextChild = this.children; this.children = paramOracleStatement; paramOracleStatement.parent = this; } OracleStatement(PhysicalConnection paramPhysicalConnection, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException { this.m_batchItems = null;





















































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































    
    this.tempClobsToFree = null;
    this.tempBlobsToFree = null;
    
    this.oldTempClobsToFree = null;
    this.oldTempBlobsToFree = null;







































































































































































































    
    this.registration = null;
    this.dcnTableName = null;
    this.dcnQueryId = -1L;

































































































































    
    this._checkSum = 0L; this.connection = paramPhysicalConnection; this.connection.needLine(); this.connection.registerHeartbeat(); this.connection.addStatement(this); this.sqlObject = new OracleSql(this.connection.conversion); this.processEscapes = this.connection.processEscapes; this.convertNcharLiterals = this.connection.convertNcharLiterals; this.autoRollback = 2; this.gotLastBatch = false; this.closed = false; this.clearParameters = true; this.serverCursor = false; this.needToAddIdentifier = false; this.defaultFetchDirection = 1000; this.fixedString = this.connection.getDefaultFixedString(); this.rowPrefetchChanged = false; this.rowPrefetch = paramInt2; this.defaultRowPrefetch = paramInt2; if (this.connection.getVersionNumber() >= 11000) { this.defaultLobPrefetchSize = this.connection.defaultLobPrefetchSize; } else { this.defaultLobPrefetchSize = -1; }  this.batch = paramInt1; this.sqlStringChanged = true; this.needToParse = true; this.needToPrepareDefineBuffer = true; this.columnsDefinedByUser = false; if (paramInt3 != -1 || paramInt4 != -1) { this.realRsetType = 0; this.userRsetType = ResultSetUtil.getRsetTypeCode(paramInt3, paramInt4); this.needToAddIdentifier = ResultSetUtil.needIdentifier(this.userRsetType); } else { this.userRsetType = 1; this.realRsetType = 1; }  }
  void removeChild(OracleStatement paramOracleStatement) { if (paramOracleStatement == this.children) { this.children = paramOracleStatement.nextChild; } else { OracleStatement oracleStatement = this.children; while (oracleStatement.nextChild != paramOracleStatement) oracleStatement = oracleStatement.nextChild;  oracleStatement.nextChild = paramOracleStatement.nextChild; }  paramOracleStatement.parent = null; paramOracleStatement.nextChild = null; }
  public boolean getMoreResults(int paramInt) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
  public ResultSet getGeneratedKeys() throws SQLException { if (this.closed) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9); sQLException.fillInStackTrace(); throw sQLException; }  if (!this.isAutoGeneratedKey) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90); sQLException.fillInStackTrace(); throw sQLException; }  if (this.returnParamAccessors == null || this.numReturnParams == 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 144); sQLException.fillInStackTrace(); throw sQLException; }  if (this.returnResultSet == null) this.returnResultSet = new OracleReturnResultSet(this);  return (ResultSet)this.returnResultSet; } public int executeUpdate(String paramString, int paramInt) throws SQLException { this.autoKeyInfo = new AutoKeyInfo(paramString); if (paramInt == 2 || !this.autoKeyInfo.isInsertSqlStmt()) { this.autoKeyInfo = null; return executeUpdate(paramString); }  if (paramInt != 1) { this.autoKeyInfo = null; SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  synchronized (this.connection) { this.isAutoGeneratedKey = true; String str = this.autoKeyInfo.getNewSql(); this.numberOfBindPositions = 1; autoKeyRegisterReturnParams(); processDmlReturningBind(); return executeUpdateInternal(str); }  } public int executeUpdate(String paramString, int[] paramArrayOfint) throws SQLException { if (paramArrayOfint == null || paramArrayOfint.length == 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  this.autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfint); if (!this.autoKeyInfo.isInsertSqlStmt()) { this.autoKeyInfo = null; return executeUpdate(paramString); }  synchronized (this.connection) { this.isAutoGeneratedKey = true; this.connection.doDescribeTable(this.autoKeyInfo); String str = this.autoKeyInfo.getNewSql(); this.numberOfBindPositions = paramArrayOfint.length; autoKeyRegisterReturnParams(); processDmlReturningBind(); return executeUpdateInternal(str); }  } public int executeUpdate(String paramString, String[] paramArrayOfString) throws SQLException { if (paramArrayOfString == null || paramArrayOfString.length == 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  this.autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfString); if (!this.autoKeyInfo.isInsertSqlStmt()) { this.autoKeyInfo = null; return executeUpdate(paramString); }  synchronized (this.connection) { this.isAutoGeneratedKey = true; this.connection.doDescribeTable(this.autoKeyInfo); String str = this.autoKeyInfo.getNewSql(); this.numberOfBindPositions = paramArrayOfString.length; autoKeyRegisterReturnParams(); processDmlReturningBind(); return executeUpdateInternal(str); }  } public boolean execute(String paramString, int paramInt) throws SQLException { this.autoKeyInfo = new AutoKeyInfo(paramString); if (paramInt == 2 || !this.autoKeyInfo.isInsertSqlStmt()) { this.autoKeyInfo = null; return execute(paramString); }  if (paramInt != 1) { this.autoKeyInfo = null; SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  synchronized (this.connection) { this.isAutoGeneratedKey = true; String str = this.autoKeyInfo.getNewSql(); this.numberOfBindPositions = 1; autoKeyRegisterReturnParams(); processDmlReturningBind(); return executeInternal(str); }  } public boolean execute(String paramString, int[] paramArrayOfint) throws SQLException { if (paramArrayOfint == null || paramArrayOfint.length == 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  this.autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfint); if (!this.autoKeyInfo.isInsertSqlStmt()) { this.autoKeyInfo = null; return execute(paramString); }  synchronized (this.connection) { this.isAutoGeneratedKey = true; this.connection.doDescribeTable(this.autoKeyInfo); String str = this.autoKeyInfo.getNewSql(); this.numberOfBindPositions = paramArrayOfint.length; autoKeyRegisterReturnParams(); processDmlReturningBind(); return executeInternal(str); }  } void calculateCheckSum() throws SQLException { if (!this.connection.calculateChecksum) {
      return;
    }
    this._checkSum = this.checkSum;
    if (this.accessors != null) {
      accessorChecksum(this.accessors);
    }
    if (this.outBindAccessors != null) {
      accessorChecksum(this.outBindAccessors);
    }
    if (this.returnParamAccessors != null && this.returnParamsFetched) {
      accessorChecksum(this.returnParamAccessors);
    }
    this._checkSum = CRC64.updateChecksum(this._checkSum, this.validRows);
    this.checkSum = this._checkSum;
    this._checkSum = 0L; } public boolean execute(String paramString, String[] paramArrayOfString) throws SQLException { if (paramArrayOfString == null || paramArrayOfString.length == 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  this.autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfString); if (!this.autoKeyInfo.isInsertSqlStmt()) { this.autoKeyInfo = null; return execute(paramString); }  synchronized (this.connection) { this.isAutoGeneratedKey = true; this.connection.doDescribeTable(this.autoKeyInfo); String str = this.autoKeyInfo.getNewSql(); this.numberOfBindPositions = paramArrayOfString.length; autoKeyRegisterReturnParams(); processDmlReturningBind(); return executeInternal(str); }  } public int getResultSetHoldability() throws SQLException { return 1; } public int getcacheState() { return this.cacheState; } public int getstatementType() { return this.statementType; } public boolean getserverCursor() { return this.serverCursor; } void initializeIndicatorSubRange() { this.bindIndicatorSubRange = 0; } private void autoKeyRegisterReturnParams() throws SQLException { initializeIndicatorSubRange(); int i = this.bindIndicatorSubRange + 5 + this.numberOfBindPositions * 10; int j = i + 2 * this.numberOfBindPositions; this.bindIndicators = new short[j]; int k = this.bindIndicatorSubRange; this.bindIndicators[k + 0] = (short)this.numberOfBindPositions; this.bindIndicators[k + 1] = 0; this.bindIndicators[k + 2] = 1; this.bindIndicators[k + 3] = 0; this.bindIndicators[k + 4] = 1; k += 5; short[] arrayOfShort = this.autoKeyInfo.tableFormOfUses; int[] arrayOfInt = this.autoKeyInfo.columnIndexes; for (byte b = 0; b < this.numberOfBindPositions; b++) { this.bindIndicators[k + 0] = 994; byte b1 = this.connection.defaultnchar ? 2 : 1; if (arrayOfShort != null && arrayOfInt != null) if (arrayOfShort[arrayOfInt[b] - 1] == 2) { b1 = 2; this.bindIndicators[k + 9] = b1; }   k += 10; checkTypeForAutoKey(this.autoKeyInfo.returnTypes[b]); String str = null; if (this.autoKeyInfo.returnTypes[b] == 111) str = this.autoKeyInfo.tableTypeNames[arrayOfInt[b] - 1];  registerReturnParameterInternal(b, this.autoKeyInfo.returnTypes[b], this.autoKeyInfo.returnTypes[b], -1, b1, str); }  } private final void setNonAutoKey() { this.isAutoGeneratedKey = false; this.numberOfBindPositions = 0; this.bindIndicators = null; this.returnParamMeta = null; } void saveDefineBuffersIfRequired(char[] paramArrayOfchar, byte[] paramArrayOfbyte, short[] paramArrayOfshort, boolean paramBoolean) throws SQLException { if (paramArrayOfchar != this.defineChars) this.connection.cacheBuffer(paramArrayOfchar);  if (paramArrayOfbyte != this.defineBytes) this.connection.cacheBuffer(paramArrayOfbyte);  } final void checkTypeForAutoKey(int paramInt) throws SQLException { if (paramInt == 109) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 5); sQLException.fillInStackTrace(); throw sQLException; }  } void moveAllTempLobsToFree() { if (this.oldTempClobsToFree != null) { if (this.tempClobsToFree == null) { this.tempClobsToFree = this.oldTempClobsToFree; } else { this.tempClobsToFree.add(this.oldTempClobsToFree); }  this.oldTempClobsToFree = null; }  if (this.oldTempBlobsToFree != null) { if (this.tempBlobsToFree == null) { this.tempBlobsToFree = this.oldTempBlobsToFree; } else { this.tempBlobsToFree.add(this.oldTempBlobsToFree); }  this.oldTempBlobsToFree = null; }  } void moveTempLobsToFree(CLOB paramCLOB) { int i; if (this.oldTempClobsToFree != null && (i = this.oldTempClobsToFree.indexOf(paramCLOB)) != -1) { addToTempLobsToFree(paramCLOB); this.oldTempClobsToFree.remove(i); }  } void moveTempLobsToFree(BLOB paramBLOB) { int i; if (this.oldTempBlobsToFree != null && (i = this.oldTempBlobsToFree.indexOf(paramBLOB)) != -1) { addToTempLobsToFree(paramBLOB); this.oldTempBlobsToFree.remove(i); }  } void addToTempLobsToFree(CLOB paramCLOB) { if (this.tempClobsToFree == null) this.tempClobsToFree = new ArrayList();  this.tempClobsToFree.add(paramCLOB); } void addToTempLobsToFree(BLOB paramBLOB) { if (this.tempBlobsToFree == null) this.tempBlobsToFree = new ArrayList();  this.tempBlobsToFree.add(paramBLOB); } void addToOldTempLobsToFree(CLOB paramCLOB) { if (this.oldTempClobsToFree == null) this.oldTempClobsToFree = new ArrayList();  this.oldTempClobsToFree.add(paramCLOB); } void addToOldTempLobsToFree(BLOB paramBLOB) { if (this.oldTempBlobsToFree == null) this.oldTempBlobsToFree = new ArrayList();  this.oldTempBlobsToFree.add(paramBLOB); } void cleanAllTempLobs() { cleanTempClobs(this.tempClobsToFree); this.tempClobsToFree = null; cleanTempBlobs(this.tempBlobsToFree); this.tempBlobsToFree = null; cleanTempClobs(this.oldTempClobsToFree); this.oldTempClobsToFree = null; cleanTempBlobs(this.oldTempBlobsToFree); this.oldTempBlobsToFree = null; } void cleanOldTempLobs() { cleanTempClobs(this.oldTempClobsToFree); cleanTempBlobs(this.oldTempBlobsToFree); this.oldTempClobsToFree = this.tempClobsToFree; this.tempClobsToFree = null; this.oldTempBlobsToFree = this.tempBlobsToFree; this.tempBlobsToFree = null; } void cleanTempClobs(ArrayList paramArrayList) { if (paramArrayList != null) { Iterator<CLOB> iterator = paramArrayList.iterator(); while (iterator.hasNext()) { try { ((CLOB)iterator.next()).freeTemporary(); } catch (SQLException sQLException) {} }  }  } void cleanTempBlobs(ArrayList paramArrayList) { if (paramArrayList != null) { Iterator<BLOB> iterator = paramArrayList.iterator(); while (iterator.hasNext()) { try { ((BLOB)iterator.next()).freeTemporary(); } catch (SQLException sQLException) {} }  }  } TimeZone getDefaultTimeZone() throws SQLException { return getDefaultTimeZone(false); } TimeZone getDefaultTimeZone(boolean paramBoolean) throws SQLException { if (this.defaultTimeZone == null) { try { this.defaultTimeZone = this.connection.getDefaultTimeZone(); } catch (SQLException sQLException) {} if (this.defaultTimeZone == null) this.defaultTimeZone = TimeZone.getDefault();  }  return this.defaultTimeZone; } public void setDatabaseChangeRegistration(DatabaseChangeRegistration paramDatabaseChangeRegistration) throws SQLException { this.registration = (NTFDCNRegistration)paramDatabaseChangeRegistration; } public String[] getRegisteredTableNames() throws SQLException { return this.dcnTableName; } public long getRegisteredQueryId() throws SQLException { return this.dcnQueryId; } Calendar getDefaultCalendar() throws SQLException { if (this.defaultCalendar == null) this.defaultCalendar = Calendar.getInstance(getDefaultTimeZone(), Locale.US);  return this.defaultCalendar; } void releaseBuffers() { this.cachedDefineIndicatorSize = (this.defineIndicators != null) ? this.defineIndicators.length : 0; this.cachedDefineMetaDataSize = (this.defineMetaData != null) ? this.defineMetaData.length : 0; this.connection.cacheBuffer(this.defineChars); this.defineChars = null; this.connection.cacheBuffer(this.defineBytes); this.defineBytes = null; this.defineIndicators = null; this.defineMetaData = null; } protected OracleConnection getConnectionDuringExceptionHandling() { return this.connection; }
  Calendar getGMTCalendar() { if (this.gmtCalendar == null) this.gmtCalendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"), Locale.US);  return this.gmtCalendar; }
  void extractNioDefineBuffers(int paramInt) throws SQLException {}
  void processLobPrefetchMetaData(Object[] paramArrayOfObject) {}
  void internalClose() throws SQLException { this.closed = true; if (this.currentResultSet != null) this.currentResultSet.closed = true;  cleanupDefines(); this.bindBytes = null; this.bindChars = null; this.bindIndicators = null; this.outBindAccessors = null; this.parameterStream = (InputStream[][])null; this.userStream = (Object[][])null; this.ibtBindBytes = null; this.ibtBindChars = null; this.ibtBindIndicators = null; this.lobPrefetchMetaData = null; this.tmpByteArray = null; this.definedColumnType = null; this.definedColumnSize = null; this.definedColumnFormOfUse = null; if (this.wrapper != null) this.wrapper.close();  }
  void accessorChecksum(Accessor[] paramArrayOfAccessor) throws SQLException { byte b = 0;
    boolean bool = false;

    
    for (Accessor accessor : paramArrayOfAccessor) {
      
      if (accessor != null) {
        byte b1;
        switch (accessor.internalType) {
          
          case 112:
          case 113:
          case 114:
            if (!b) {
              bool = true;
            }
            break;

          
          case 8:
          case 24:
            bool = false;
            break;

          
          default:
            bool = false;


            
            b++;
            for (b1 = 0; b1 < this.validRows; b1++) {
              
              if (accessor.rowSpaceIndicator != null)
                this._checkSum = accessor.updateChecksum(this._checkSum, b1); 
            }  break;
        } 
      } 
    } 
    if (bool) {
      this.checkSumComputationFailure = true;
    } }




  
  public long getChecksum() throws SQLException {
    if (this.checkSumComputationFailure) {
      
      SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    return this.checkSum;
  }













  
  static final byte convertSqlKindEnumToByte(OracleStatement.SqlKind paramSqlKind) {
    switch (paramSqlKind) {
      
      case DELETE:
        return 2;
      
      case INSERT:
        return 4;
      
      case MERGE:
        return 8;
      
      case UPDATE:
        return 16;
      
      case ALTER_SESSION:
      case OTHER:
        return Byte.MIN_VALUE;
      
      case PLSQL_BLOCK:
        return 32;
      
      case CALL_BLOCK:
        return 64;
      
      case SELECT_FOR_UPDATE:
      case SELECT:
        return 1;
    } 
    
    if (paramSqlKind.isPlsqlOrCall())
      return 96; 
    if (paramSqlKind.isDML()) {
      return 30;
    }
    return 0;
  }

  
  static final OracleStatement.SqlKind convertSqlKindByteToEnum(byte paramByte) {
    switch (paramByte) {
      
      case 2:
        return OracleStatement.SqlKind.DELETE;
      
      case 4:
        return OracleStatement.SqlKind.INSERT;
      
      case 8:
        return OracleStatement.SqlKind.MERGE;
      
      case 16:
        return OracleStatement.SqlKind.UPDATE;
      
      case -128:
        return OracleStatement.SqlKind.OTHER;
      
      case 32:
        return OracleStatement.SqlKind.PLSQL_BLOCK;
      
      case 64:
        return OracleStatement.SqlKind.CALL_BLOCK;
      
      case 1:
        return OracleStatement.SqlKind.SELECT;
    } 

    
    return OracleStatement.SqlKind.UNINITIALIZED;
  }

  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
  
  abstract void doDescribe(boolean paramBoolean) throws SQLException;
  
  abstract void executeForDescribe() throws SQLException;
  
  abstract void executeForRows(boolean paramBoolean) throws SQLException;
  
  abstract void fetch() throws SQLException;
  
  abstract void doClose() throws SQLException;
  
  abstract void closeQuery() throws SQLException;
}
