package oracle.jdbc.driver;

import java.sql.SQLException;
















class OutRawAccessor
  extends RawCommonAccessor
{
  static final int MAXLENGTH_NEW = 32767;
  static final int MAXLENGTH_OLD = 32767;
  
  OutRawAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2) throws SQLException {
    init(paramOracleStatement, 23, 23, paramShort, true);
    initForDataAccess(paramInt2, paramInt1, (String)null);
  }




  
  void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
    if (paramInt1 != 0) {
      this.externalType = paramInt1;
    }
    if (this.statement.connection.getVersionNumber() >= 8000) {
      this.internalTypeMaxLength = 32767;
    } else {
      this.internalTypeMaxLength = 32767;
    } 
    if (paramInt2 > 0 && paramInt2 < this.internalTypeMaxLength) {
      this.internalTypeMaxLength = paramInt2;
    }
    this.byteLength = this.internalTypeMaxLength;
  }



  
  byte[] getBytes(int paramInt) throws SQLException {
    byte[] arrayOfByte = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
      int i = this.columnIndex + this.byteLength * paramInt;
      
      arrayOfByte = new byte[s];
      
      System.arraycopy(this.rowSpaceByte, i, arrayOfByte, 0, s);
    } 
    
    return arrayOfByte;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
