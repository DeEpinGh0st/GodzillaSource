package oracle.jdbc.driver;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.SQLException;
import java.util.Map;
import oracle.sql.BINARY_DOUBLE;
import oracle.sql.Datum;
import oracle.sql.NUMBER;











class BinaryDoubleAccessor
  extends Accessor
{
  static final int MAXLENGTH = 8;
  
  BinaryDoubleAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean) throws SQLException {
    init(paramOracleStatement, 101, 101, paramShort, paramBoolean);
    initForDataAccess(paramInt2, paramInt1, (String)null);
  }





  
  BinaryDoubleAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort) throws SQLException {
    init(paramOracleStatement, 101, 101, paramShort, false);
    initForDescribe(101, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, null);

    
    int i = paramOracleStatement.maxFieldSize;
    
    if (i > 0 && (paramInt1 == 0 || i < paramInt1)) {
      paramInt1 = i;
    }
    initForDataAccess(0, paramInt1, (String)null);
  }




  
  void init(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, int paramInt3, short paramShort, int paramInt4) throws SQLException {
    init(paramOracleStatement, paramInt1, paramInt2, paramShort, false);
    initForDataAccess(paramInt4, paramInt3, (String)null);
  }





  
  void init(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, short paramShort) throws SQLException {
    init(paramOracleStatement, paramInt1, paramInt2, paramShort, false);
    initForDescribe(paramInt1, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramShort, null);

    
    int i = paramOracleStatement.maxFieldSize;
    
    if (i > 0 && (paramInt3 == 0 || i < paramInt3)) {
      paramInt3 = i;
    }
    initForDataAccess(0, paramInt3, (String)null);
  }




  
  void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
    if (paramInt1 != 0) {
      this.externalType = paramInt1;
    }
    this.internalTypeMaxLength = 8;
    
    if (paramInt2 > 0 && paramInt2 < this.internalTypeMaxLength) {
      this.internalTypeMaxLength = paramInt2;
    }
    this.byteLength = this.internalTypeMaxLength;
  }





























  
  double getDouble(int paramInt) throws SQLException {
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
      return 0.0D;
    }
    int i = this.columnIndex + this.byteLength * paramInt;
    int j = this.rowSpaceByte[i];
    int k = this.rowSpaceByte[i + 1];
    int m = this.rowSpaceByte[i + 2];
    int n = this.rowSpaceByte[i + 3];
    int i1 = this.rowSpaceByte[i + 4];
    int i2 = this.rowSpaceByte[i + 5];
    int i3 = this.rowSpaceByte[i + 6];
    int i4 = this.rowSpaceByte[i + 7];
    
    if ((j & 0x80) != 0) {
      
      j = j & 0x7F;
      k = k & 0xFF;
      m = m & 0xFF;
      n = n & 0xFF;
      i1 = i1 & 0xFF;
      i2 = i2 & 0xFF;
      i3 = i3 & 0xFF;
      i4 = i4 & 0xFF;
    }
    else {
      
      j = (j ^ 0xFFFFFFFF) & 0xFF;
      k = (k ^ 0xFFFFFFFF) & 0xFF;
      m = (m ^ 0xFFFFFFFF) & 0xFF;
      n = (n ^ 0xFFFFFFFF) & 0xFF;
      i1 = (i1 ^ 0xFFFFFFFF) & 0xFF;
      i2 = (i2 ^ 0xFFFFFFFF) & 0xFF;
      i3 = (i3 ^ 0xFFFFFFFF) & 0xFF;
      i4 = (i4 ^ 0xFFFFFFFF) & 0xFF;
    } 
    
    int i5 = j << 24 | k << 16 | m << 8 | n;
    int i6 = i1 << 24 | i2 << 16 | i3 << 8 | i4;
    long l = i5 << 32L | i6 & 0xFFFFFFFFL;
    
    return Double.longBitsToDouble(l);
  }










  
  String getString(int paramInt) throws SQLException {
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      return Double.toString(getDouble(paramInt));
    }
    return null;
  }










  
  Object getObject(int paramInt) throws SQLException {
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      return new Double(getDouble(paramInt));
    }
    return null;
  }











  
  Object getObject(int paramInt, Map paramMap) throws SQLException {
    return new Double(getDouble(paramInt));
  }










  
  Datum getOracleObject(int paramInt) throws SQLException {
    return (Datum)getBINARY_DOUBLE(paramInt);
  }










  
  BINARY_DOUBLE getBINARY_DOUBLE(int paramInt) throws SQLException {
    BINARY_DOUBLE bINARY_DOUBLE = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
      int i = this.columnIndex + this.byteLength * paramInt;
      byte[] arrayOfByte = new byte[s];
      
      System.arraycopy(this.rowSpaceByte, i, arrayOfByte, 0, s);
      
      bINARY_DOUBLE = new BINARY_DOUBLE(arrayOfByte);
    } 
    
    return bINARY_DOUBLE;
  }



  
  NUMBER getNUMBER(int paramInt) throws SQLException {
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      return new NUMBER(getDouble(paramInt));
    }
    return null;
  }



  
  BigInteger getBigInteger(int paramInt) throws SQLException {
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      return new BigInteger(getString(paramInt));
    }
    return null;
  }



  
  BigDecimal getBigDecimal(int paramInt) throws SQLException {
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      return new BigDecimal(getString(paramInt));
    }
    return null;
  }



  
  byte getByte(int paramInt) throws SQLException {
    return (byte)(int)getDouble(paramInt);
  }



  
  short getShort(int paramInt) throws SQLException {
    return (short)(int)getDouble(paramInt);
  }



  
  int getInt(int paramInt) throws SQLException {
    return (int)getDouble(paramInt);
  }



  
  long getLong(int paramInt) throws SQLException {
    return (long)getDouble(paramInt);
  }



  
  float getFloat(int paramInt) throws SQLException {
    return (float)getDouble(paramInt);
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
