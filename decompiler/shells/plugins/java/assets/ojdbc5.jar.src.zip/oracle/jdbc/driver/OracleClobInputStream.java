package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.CLOB;




















class OracleClobInputStream
  extends OracleBufferedStream
{
  protected long lobOffset;
  protected CLOB clob;
  protected long markedByte;
  protected boolean endOfStream;
  protected char[] charBuf;
  
  public OracleClobInputStream(CLOB paramCLOB) throws SQLException {
    this(paramCLOB, ((PhysicalConnection)paramCLOB.getJavaSqlConnection()).getDefaultStreamChunkSize(), 1L);
  }











  
  public OracleClobInputStream(CLOB paramCLOB, int paramInt) throws SQLException {
    this(paramCLOB, paramInt, 1L);
  }










  
  public OracleClobInputStream(CLOB paramCLOB, int paramInt, long paramLong) throws SQLException {
    super(paramInt);

    
    if (paramCLOB == null || paramInt <= 0 || paramLong < 1L)
    {
      throw new IllegalArgumentException();
    }
    
    this.lobOffset = paramLong;
    this.clob = paramCLOB;
    this.markedByte = -1L;
    this.endOfStream = false;
  }









  
  public boolean needBytes(int paramInt) throws IOException {
    ensureOpen();
    
    if (this.pos >= this.count) {
      
      if (!this.endOfStream) {
        
        try {
          
          if (paramInt > this.currentBufferSize) {
            
            this.currentBufferSize = Math.max(paramInt, this.initialBufferSize);
            PhysicalConnection physicalConnection = (PhysicalConnection)this.clob.getInternalConnection();
            
            synchronized (physicalConnection) {
              this.resizableBuffer = physicalConnection.getByteBuffer(this.currentBufferSize);
              this.charBuf = physicalConnection.getCharBuffer(this.currentBufferSize);
            } 
          } 
          this.count = this.clob.getChars(this.lobOffset, this.currentBufferSize, this.charBuf);

          
          for (byte b = 0; b < this.count; b++) {
            this.resizableBuffer[b] = (byte)this.charBuf[b];
          }
          if (this.count < this.currentBufferSize) {
            this.endOfStream = true;
          }
          if (this.count > 0)
          {
            this.pos = 0;
            this.lobOffset += this.count;
            
            return true;
          }
        
        } catch (SQLException sQLException) {

          
          IOException iOException = DatabaseError.createIOException(sQLException);
          iOException.fillInStackTrace();
          throw iOException;
        } 
      }

      
      return false;
    } 
    
    return true;
  }










  
  protected void ensureOpen() throws IOException {
    try {
      if (this.closed)
      {
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 57, (Object)null);
        sQLException.fillInStackTrace();
        throw sQLException;
      }
    
    } catch (SQLException sQLException) {

      
      IOException iOException = DatabaseError.createIOException(sQLException);
      iOException.fillInStackTrace();
      throw iOException;
    } 
  }











  
  public boolean markSupported() {
    return true;
  }














  
  public void mark(int paramInt) {
    if (paramInt < 0) {
      throw new IllegalArgumentException(DatabaseError.findMessage(196, null));
    }
    this.markedByte = this.lobOffset - this.count + this.pos;
  }





  
  public void markInternal(int paramInt) {}





  
  public void reset() throws IOException {
    ensureOpen();
    
    if (this.markedByte < 0L) {
      throw new IOException(DatabaseError.findMessage(195, null));
    }
    this.lobOffset = this.markedByte;
    this.pos = this.count;
    this.endOfStream = false;
  }















  
  public long skip(long paramLong) throws IOException {
    ensureOpen();
    
    long l = 0L;
    
    if ((this.count - this.pos) >= paramLong) {
      
      this.pos = (int)(this.pos + paramLong);
      l += paramLong;
    }
    else {
      
      l += (this.count - this.pos);
      this.pos = this.count;

      
      try {
        long l1 = 0L;
        
        l1 = this.clob.length() - this.lobOffset + 1L;
        
        if (l1 >= paramLong - l)
        {
          this.lobOffset += paramLong - l;
          l += paramLong - l;
        }
        else
        {
          this.lobOffset += l1;
          l += l1;
        }
      
      } catch (SQLException sQLException) {

        
        IOException iOException = DatabaseError.createIOException(sQLException);
        iOException.fillInStackTrace();
        throw iOException;
      } 
    } 

    
    return l;
  }




  
  public void close() throws IOException {
    if (this.closed) {
      return;
    }
    try {
      super.close();
    } finally {

      
      try {
        PhysicalConnection physicalConnection = (PhysicalConnection)this.clob.getInternalConnection();
        
        synchronized (physicalConnection) {
          
          if (this.charBuf != null) {
            
            physicalConnection.cacheBuffer(this.charBuf);
            this.charBuf = null;
          } 
          if (this.resizableBuffer != null) {
            
            physicalConnection.cacheBuffer(this.resizableBuffer);
            this.resizableBuffer = null;
          } 
          this.currentBufferSize = 0;
        } 
      } catch (SQLException sQLException) {

        
        IOException iOException = DatabaseError.createIOException(sQLException);
        iOException.fillInStackTrace();
        throw iOException;
      } 
    } 
  }
















  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    try {
      return this.clob.getInternalConnection();
    }
    catch (Exception exception) {
      
      return null;
    } 
  }



  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
