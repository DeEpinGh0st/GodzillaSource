package oracle.jdbc.oracore;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Map;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.DATE;
import oracle.sql.Datum;
import oracle.sql.TIMESTAMPLTZ;





































public class OracleTypeTIMESTAMPLTZ
  extends OracleType
  implements Serializable
{
  static final long serialVersionUID = 1615519855865602397L;
  int precision = 0;




  
  transient OracleConnection connection;





  
  protected OracleTypeTIMESTAMPLTZ() {}





  
  public OracleTypeTIMESTAMPLTZ(OracleConnection paramOracleConnection) {
    this.connection = paramOracleConnection;
  }







  
  public int getTypeCode() {
    return -102;
  }




  
  public void parseTDSrec(TDSReader paramTDSReader) throws SQLException {
    this.precision = paramTDSReader.readByte();
  }



  
  public int getScale() throws SQLException {
    return 0;
  }



  
  public int getPrecision() throws SQLException {
    return this.precision;
  }





  
  private void readObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {
    this.precision = paramObjectInputStream.readByte();
  }




  
  private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
    paramObjectOutputStream.writeByte(this.precision);
  }




  
  protected Object toObject(byte[] paramArrayOfbyte, int paramInt, Map paramMap) throws SQLException {
    if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
      return null;
    }
    switch (paramInt) {

      
      case 1:
        return new TIMESTAMPLTZ(paramArrayOfbyte);
      
      case 2:
        return TIMESTAMPLTZ.toTimestamp((Connection)this.connection, paramArrayOfbyte);
      
      case 3:
        return paramArrayOfbyte;
    } 

    
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
    sQLException.fillInStackTrace();
    throw sQLException;
  }














  
  public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection) throws SQLException {
    TIMESTAMPLTZ tIMESTAMPLTZ = null;
    
    if (paramObject != null) {
      
      try {
        
        if (paramObject instanceof TIMESTAMPLTZ) {
          tIMESTAMPLTZ = (TIMESTAMPLTZ)paramObject;
        } else if (paramObject instanceof byte[]) {
          tIMESTAMPLTZ = new TIMESTAMPLTZ((byte[])paramObject);
        } else if (paramObject instanceof Timestamp) {
          tIMESTAMPLTZ = new TIMESTAMPLTZ((Connection)paramOracleConnection, (Timestamp)paramObject);
        } else if (paramObject instanceof DATE) {
          tIMESTAMPLTZ = new TIMESTAMPLTZ((Connection)paramOracleConnection, (DATE)paramObject);
        } else if (paramObject instanceof String) {
          tIMESTAMPLTZ = new TIMESTAMPLTZ((Connection)paramOracleConnection, (String)paramObject);
        } else if (paramObject instanceof Date) {
          tIMESTAMPLTZ = new TIMESTAMPLTZ((Connection)paramOracleConnection, (Date)paramObject);
        } else if (paramObject instanceof Time) {
          tIMESTAMPLTZ = new TIMESTAMPLTZ((Connection)paramOracleConnection, (Time)paramObject);
        } else {
          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject);
          sQLException.fillInStackTrace();
          throw sQLException;
        }
      
      } catch (Exception exception) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    }

    
    return (Datum)tIMESTAMPLTZ;
  }









  
  protected Object unpickle81rec(UnpickleContext paramUnpickleContext, int paramInt1, int paramInt2, Map paramMap) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
    sQLException.fillInStackTrace();
    throw sQLException;
  }












  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return this.connection;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
