package oracle.jdbc.oracore;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.CHAR;
import oracle.sql.CharacterSet;
import oracle.sql.Datum;
import oracle.sql.converter.CharacterSetMetaData;


































public class OracleTypeCHAR
  extends OracleType
  implements Serializable
{
  static final long serialVersionUID = -6899444518695804629L;
  int form;
  int charset;
  int length;
  int characterSemantic;
  private transient OracleConnection connection;
  private short pickleCharaterSetId;
  private transient CharacterSet pickleCharacterSet;
  private short pickleNcharCharacterSet;
  static final int SQLCS_IMPLICIT = 1;
  static final int SQLCS_NCHAR = 2;
  static final int SQLCS_EXPLICIT = 3;
  static final int SQLCS_FLEXIBLE = 4;
  static final int SQLCS_LIT_NULL = 5;
  
  protected OracleTypeCHAR() {}
  
  public OracleTypeCHAR(OracleConnection paramOracleConnection) {
    this.form = 0;
    this.charset = 0;
    this.length = 0;
    this.connection = paramOracleConnection;
    this.pickleCharaterSetId = 0;
    this.pickleNcharCharacterSet = 0;
    this.pickleCharacterSet = null;

    
    try {
      this.pickleCharaterSetId = this.connection.getStructAttrCsId();
    }
    catch (SQLException sQLException) {

      
      this.pickleCharaterSetId = -1;
    } 
    
    this.pickleCharacterSet = CharacterSet.make(this.pickleCharaterSetId);
  }


  
  protected OracleTypeCHAR(OracleConnection paramOracleConnection, int paramInt) {
    super(paramInt);
    
    this.form = 0;
    this.charset = 0;
    this.length = 0;
    this.connection = paramOracleConnection;
    this.pickleCharaterSetId = 0;
    this.pickleNcharCharacterSet = 0;
    this.pickleCharacterSet = null;

    
    try {
      this.pickleCharaterSetId = this.connection.getStructAttrCsId();
    }
    catch (SQLException sQLException) {


      
      this.pickleCharaterSetId = -1;
    } 
    
    this.pickleCharacterSet = CharacterSet.make(this.pickleCharaterSetId);
  }





















  
  public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection) throws SQLException {
    CHAR cHAR;
    if (paramObject == null) {
      return null;
    }
    if (paramObject instanceof CHAR) {
      return (Datum)paramObject;
    }


    
    if (this.typeCode == 1 && paramObject instanceof String) {
      
      if (this.characterSemantic != 0) {
        
        int i = CharacterSetMetaData.getRatio(this.pickleCharaterSetId, 1);
        
        String str = (String)paramObject;
        for (int j = str.length(); j < this.length / i; ) { str = str + " "; j++; }
         paramObject = str;
        cHAR = new CHAR(paramObject, this.pickleCharacterSet);
      }
      else {
        
        cHAR = new CHAR((String)paramObject, this.pickleCharacterSet, this.length);
      } 
    } else {
      cHAR = new CHAR(paramObject, this.pickleCharacterSet);
    }  return (Datum)cHAR;
  }



















  
  public Datum[] toDatumArray(Object paramObject, OracleConnection paramOracleConnection, long paramLong, int paramInt) throws SQLException {
    Datum[] arrayOfDatum = null;
    
    if (paramObject != null) {
      
      if (paramObject instanceof Object[] && !(paramObject instanceof char[][])) {
        return super.toDatumArray(paramObject, paramOracleConnection, paramLong, paramInt);
      }
      arrayOfDatum = cArrayToDatumArray(paramObject, paramOracleConnection, paramLong, paramInt);
    } 
    
    return arrayOfDatum;
  }











  
  public void parseTDSrec(TDSReader paramTDSReader) throws SQLException {
    super.parseTDSrec(paramTDSReader);


    
    try {
      this.length = paramTDSReader.readUB2();
      this.form = paramTDSReader.readByte();
      this.characterSemantic = this.form & 0x80;
      this.form &= 0x7F;
      this.charset = paramTDSReader.readUB2();
    }
    catch (SQLException sQLException1) {

      
      SQLException sQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 47, "parseTDS");
      sQLException2.fillInStackTrace();
      throw sQLException2;
    } 

    
    if (this.form != 2 || this.pickleNcharCharacterSet != 0) {
      return;
    }




    
    try {
      this.pickleNcharCharacterSet = this.connection.getStructAttrNCsId();
    }
    catch (SQLException sQLException) {


      
      this.pickleNcharCharacterSet = 2000;
    } 
    
    this.pickleCharaterSetId = this.pickleNcharCharacterSet;
    this.pickleCharacterSet = CharacterSet.make(this.pickleCharaterSetId);
  }






















  
  protected int pickle81(PickleContext paramPickleContext, Datum paramDatum) throws SQLException {
    CHAR cHAR = getDbCHAR(paramDatum);
    
    if (this.characterSemantic != 0 && this.form != 2) {


      
      if (cHAR.getStringWithReplacement().length() > this.length)
      {
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 72, "\"" + cHAR.getStringWithReplacement() + "\"");
        sQLException.fillInStackTrace();
        throw sQLException;

      
      }

    
    }
    else if (cHAR.getLength() > this.length) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 72, "\"" + cHAR.getStringWithReplacement() + "\"");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    return super.pickle81(paramPickleContext, (Datum)cHAR);
  }








  
  protected Object toObject(byte[] paramArrayOfbyte, int paramInt, Map paramMap) throws SQLException {
    if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
      return null;
    }

    
    CHAR cHAR = null;
    
    switch (this.form) {




      
      case 1:
      case 2:
        cHAR = new CHAR(paramArrayOfbyte, this.pickleCharacterSet);
        break;



      
      case 3:
      case 4:
      case 5:
        cHAR = new CHAR(paramArrayOfbyte, null);
        break;
    } 

    
    if (paramInt == 1)
      return cHAR; 
    if (paramInt == 2)
      return cHAR.stringValue(); 
    if (paramInt == 3) {
      return paramArrayOfbyte;
    }
    
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramArrayOfbyte);
    sQLException.fillInStackTrace();
    throw sQLException;
  }










  
  private CHAR getDbCHAR(Datum paramDatum) {
    CHAR cHAR1 = (CHAR)paramDatum;
    CHAR cHAR2 = null;
    
    if (cHAR1.getCharacterSet().getOracleId() == this.pickleCharaterSetId) {
      
      cHAR2 = cHAR1;
    } else {

      
      try {
        
        cHAR2 = new CHAR(cHAR1.toString(), this.pickleCharacterSet);
      }
      catch (SQLException sQLException) {


        
        cHAR2 = cHAR1;
      } 
    } 
    return cHAR2;
  }

























  
  private Datum[] cArrayToDatumArray(Object paramObject, OracleConnection paramOracleConnection, long paramLong, int paramInt) throws SQLException {
    Datum[] arrayOfDatum = null;
    
    if (paramObject != null)
    {
      if (paramObject instanceof char[][]) {
        
        char[][] arrayOfChar = (char[][])paramObject;
        int i = (int)((paramInt == -1) ? arrayOfChar.length : Math.min(arrayOfChar.length - paramLong + 1L, paramInt));

        
        arrayOfDatum = new Datum[i];
        
        for (byte b = 0; b < i; b++) {
          arrayOfDatum[b] = (Datum)new CHAR(new String(arrayOfChar[(int)paramLong + b - 1]), this.pickleCharacterSet);
        }
      }
      else if (paramObject instanceof boolean[]) {
        
        boolean[] arrayOfBoolean = (boolean[])paramObject;
        int i = (int)((paramInt == -1) ? arrayOfBoolean.length : Math.min(arrayOfBoolean.length - paramLong + 1L, paramInt));

        
        arrayOfDatum = new Datum[i];
        
        for (byte b = 0; b < i; b++) {
          arrayOfDatum[b] = (Datum)new CHAR(Boolean.valueOf(arrayOfBoolean[(int)paramLong + b - 1]), this.pickleCharacterSet);
        }
      }
      else if (paramObject instanceof short[]) {
        
        short[] arrayOfShort = (short[])paramObject;
        int i = (int)((paramInt == -1) ? arrayOfShort.length : Math.min(arrayOfShort.length - paramLong + 1L, paramInt));

        
        arrayOfDatum = new Datum[i];


        
        for (byte b = 0; b < i; b++) {
          arrayOfDatum[b] = (Datum)new CHAR(Integer.valueOf(arrayOfShort[(int)paramLong + b - 1]), this.pickleCharacterSet);
        
        }
      }
      else if (paramObject instanceof int[]) {
        
        int[] arrayOfInt = (int[])paramObject;
        int i = (int)((paramInt == -1) ? arrayOfInt.length : Math.min(arrayOfInt.length - paramLong + 1L, paramInt));

        
        arrayOfDatum = new Datum[i];
        
        for (byte b = 0; b < i; b++) {
          arrayOfDatum[b] = (Datum)new CHAR(Integer.valueOf(arrayOfInt[(int)paramLong + b - 1]), this.pickleCharacterSet);
        }
      }
      else if (paramObject instanceof long[]) {
        
        long[] arrayOfLong = (long[])paramObject;
        int i = (int)((paramInt == -1) ? arrayOfLong.length : Math.min(arrayOfLong.length - paramLong + 1L, paramInt));

        
        arrayOfDatum = new Datum[i];
        
        for (byte b = 0; b < i; b++) {
          arrayOfDatum[b] = (Datum)new CHAR(new Long(arrayOfLong[(int)paramLong + b - 1]), this.pickleCharacterSet);
        }
      }
      else if (paramObject instanceof float[]) {
        
        float[] arrayOfFloat = (float[])paramObject;
        int i = (int)((paramInt == -1) ? arrayOfFloat.length : Math.min(arrayOfFloat.length - paramLong + 1L, paramInt));

        
        arrayOfDatum = new Datum[i];
        
        for (byte b = 0; b < i; b++) {
          arrayOfDatum[b] = (Datum)new CHAR(new Float(arrayOfFloat[(int)paramLong + b - 1]), this.pickleCharacterSet);
        }
      }
      else if (paramObject instanceof double[]) {
        
        double[] arrayOfDouble = (double[])paramObject;
        int i = (int)((paramInt == -1) ? arrayOfDouble.length : Math.min(arrayOfDouble.length - paramLong + 1L, paramInt));

        
        arrayOfDatum = new Datum[i];
        
        for (byte b = 0; b < i; b++) {
          arrayOfDatum[b] = (Datum)new CHAR(new Double(arrayOfDouble[(int)paramLong + b - 1]), this.pickleCharacterSet);
        
        }
      }
      else {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    }

    
    return arrayOfDatum;
  }



  
  public int getLength() {
    return this.length;
  }







  
  private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
    paramObjectOutputStream.writeInt(this.form);
    paramObjectOutputStream.writeInt(this.charset);
    paramObjectOutputStream.writeInt(this.length);
    paramObjectOutputStream.writeInt(this.characterSemantic);
    paramObjectOutputStream.writeShort(this.pickleCharaterSetId);
    paramObjectOutputStream.writeShort(this.pickleNcharCharacterSet);
  }




  
  private void readObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {
    this.form = paramObjectInputStream.readInt();
    this.charset = paramObjectInputStream.readInt();
    this.length = paramObjectInputStream.readInt();
    this.characterSemantic = paramObjectInputStream.readInt();
    this.pickleCharaterSetId = paramObjectInputStream.readShort();
    this.pickleNcharCharacterSet = paramObjectInputStream.readShort();
    
    if (this.pickleNcharCharacterSet != 0) {
      this.pickleCharacterSet = CharacterSet.make(this.pickleNcharCharacterSet);
    } else {
      this.pickleCharacterSet = CharacterSet.make(this.pickleCharaterSetId);
    } 
  }


  
  public void setConnection(OracleConnection paramOracleConnection) throws SQLException {
    this.connection = paramOracleConnection;
  }










  
  public boolean isNCHAR() throws SQLException {
    return (this.form == 2);
  }











  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return this.connection;
  }












































  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
