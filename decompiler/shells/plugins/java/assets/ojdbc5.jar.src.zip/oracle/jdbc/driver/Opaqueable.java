package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.sql.OPAQUE;

public interface Opaqueable {
  OPAQUE toOpaque() throws SQLException;
}
