package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;















class T4CRowidAccessor
  extends RowidAccessor
{
  T4CMAREngine mare;
  static final int maxLength = 128;
  final int[] meta;
  static final int KGRD_EXTENDED_OBJECT = 6;
  static final int KGRD_EXTENDED_BLOCK = 6;
  static final int KGRD_EXTENDED_FILE = 3;
  static final int KGRD_EXTENDED_SLOT = 3;
  static final int kd4_ubridtype_physical = 1;
  static final int kd4_ubridtype_logical = 2;
  static final int kd4_ubridtype_remote = 3;
  static final int kd4_ubridtype_exttab = 4;
  static final int kd4_ubridtype_future2 = 5;
  static final int kd4_ubridtype_max = 5;
  static final int kd4_ubridlen_typeind = 1;
  
  T4CRowidAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException {
    super(paramOracleStatement, paramInt1, paramShort, paramInt2, paramBoolean);





















































    
    this.meta = new int[1]; this.mare = paramT4CMAREngine; this.defineType = 104; } T4CRowidAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort); this.meta = new int[1];
    this.mare = paramT4CMAREngine;
    this.definedColumnType = paramInt7;
    this.definedColumnSize = paramInt8;
    this.defineType = 104; }
  void processIndicator(int paramInt) throws IOException, SQLException { if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
      this.mare.unmarshalUB2();
      this.mare.unmarshalUB2();
    } else if (this.statement.connection.versionNumber < 9200) {
      this.mare.unmarshalSB2();
      if (!this.statement.sqlKind.isPlsqlOrCall())
        this.mare.unmarshalSB2(); 
    } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) {
      this.mare.processIndicator((paramInt <= 0), paramInt);
    }  } boolean unmarshalOneRow() throws SQLException, IOException {
    if (this.isUseLess) {
      
      this.lastRowProcessed++;
      
      return false;
    } 


    
    if (this.rowSpaceIndicator == null) {
      
      short s = this.mare.unmarshalUB1();
      long l1 = 0L;
      int m = 0;
      short s1 = 0;
      long l2 = 0L;
      int n = 0;


      
      if (s > 0) {
        
        l1 = this.mare.unmarshalUB4();
        m = this.mare.unmarshalUB2();
        s1 = this.mare.unmarshalUB1();
        l2 = this.mare.unmarshalUB4();
        n = this.mare.unmarshalUB2();
      } 
      
      processIndicator(this.meta[0]);
      
      this.lastRowProcessed++;
      
      return false;
    } 

    
    int i = this.indicatorIndex + this.lastRowProcessed;
    int j = this.lengthIndex + this.lastRowProcessed;
    
    if (this.isNullByDescribe) {
      
      this.rowSpaceIndicator[i] = -1;
      this.rowSpaceIndicator[j] = 0;
      this.lastRowProcessed++;
      
      if (this.statement.connection.versionNumber < 9200) {
        processIndicator(0);
      }
      return false;
    } 
    
    int k = this.columnIndex + this.lastRowProcessed * this.byteLength;



    
    if (this.describeType != 208) {
      
      short s = this.mare.unmarshalUB1();
      long l1 = 0L;
      int m = 0;
      short s1 = 0;
      long l2 = 0L;
      int n = 0;


      
      if (s > 0) {
        
        l1 = this.mare.unmarshalUB4();
        m = this.mare.unmarshalUB2();
        s1 = this.mare.unmarshalUB1();
        l2 = this.mare.unmarshalUB4();
        n = this.mare.unmarshalUB2();
      } 

      
      if (l1 == 0L && m == 0 && s1 == 0 && l2 == 0L && n == 0) {
        
        this.meta[0] = 0;
      } else {
        
        long[] arrayOfLong = { l1, m, l2, n };


        
        byte[] arrayOfByte = rowidToString(arrayOfLong);
        int i1 = 18;
        
        if (this.byteLength - 2 < 18) {
          i1 = this.byteLength - 2;
        }
        System.arraycopy(arrayOfByte, 0, this.rowSpaceByte, k + 2, i1);

        
        this.meta[0] = i1;
      }
    
    } else {
      
      this.meta[0] = (int)this.mare.unmarshalUB4(); if ((int)this.mare.unmarshalUB4() > 0) {
        
        byte[] arrayOfByte = new byte[this.meta[0]];
        this.mare.unmarshalCLR(arrayOfByte, 0, this.meta);
        this.meta[0] = kgrdub2c(arrayOfByte, this.meta[0], 0, this.rowSpaceByte, k + 2);
      } 
    } 
    
    this.rowSpaceByte[k] = (byte)((this.meta[0] & 0xFF00) >> 8);
    this.rowSpaceByte[k + 1] = (byte)(this.meta[0] & 0xFF);






    
    processIndicator(this.meta[0]);
    
    if (this.meta[0] == 0) {


      
      this.rowSpaceIndicator[i] = -1;
      this.rowSpaceIndicator[j] = 0;
    }
    else {
      
      this.rowSpaceIndicator[j] = (short)this.meta[0];



      
      this.rowSpaceIndicator[i] = 0;
    } 
    
    this.lastRowProcessed++;
    
    return false;
  }







  
  String getString(int paramInt) throws SQLException {
    String str = null;
    
    if (this.rowSpaceIndicator == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      int i = this.columnIndex + this.byteLength * paramInt;


      
      short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
      
      if (this.describeType != 208 || this.rowSpaceByte[i] == 1) {

        
        str = new String(this.rowSpaceByte, i + 2, s);
        
        long[] arrayOfLong = stringToRowid(str.getBytes(), 0, str.length());




        
        str = new String(rowidToString(arrayOfLong));
      }
      else {
        
        str = new String(this.rowSpaceByte, i + 2, s);
      } 
    } 
    
    return str;
  }




  
  Object getObject(int paramInt) throws SQLException {
    if (this.definedColumnType == 0) {
      return super.getObject(paramInt);
    }
    
    Object object = null;
    
    if (this.rowSpaceIndicator == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      switch (this.definedColumnType) {






        
        case -1:
        case 1:
        case 12:
          return getString(paramInt);
        
        case -8:
          return getROWID(paramInt);
      } 

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    return object;
  }








  
  void copyRow() throws SQLException, IOException {
    int i;
    if (this.lastRowProcessed == 0) {
      i = this.statement.rowPrefetchInLastFetch - 1;
    } else {
      i = this.lastRowProcessed - 1;
    } 
    
    int j = this.columnIndex + this.lastRowProcessed * this.byteLength;
    int k = this.columnIndex + i * this.byteLength;
    int m = this.indicatorIndex + this.lastRowProcessed;
    int n = this.indicatorIndex + i;
    int i1 = this.lengthIndex + this.lastRowProcessed;
    int i2 = this.lengthIndex + i;
    short s = this.rowSpaceIndicator[i2];
    int i3 = this.metaDataIndex + this.lastRowProcessed * 1;
    
    int i4 = this.metaDataIndex + i * 1;


    
    this.rowSpaceIndicator[i1] = (short)s;
    this.rowSpaceIndicator[m] = this.rowSpaceIndicator[n];


    
    System.arraycopy(this.rowSpaceByte, k, this.rowSpaceByte, j, s + 2);


    
    System.arraycopy(this.rowSpaceMetaData, i4, this.rowSpaceMetaData, i3, 1);


    
    this.lastRowProcessed++;
  }









  
  void saveDataFromOldDefineBuffers(byte[] paramArrayOfbyte, char[] paramArrayOfchar, short[] paramArrayOfshort, int paramInt1, int paramInt2) throws SQLException {
    int i = this.columnIndex + (paramInt2 - 1) * this.byteLength;
    
    int j = this.columnIndexLastRow + (paramInt1 - 1) * this.byteLength;
    
    int k = this.indicatorIndex + paramInt2 - 1;
    int m = this.indicatorIndexLastRow + paramInt1 - 1;
    int n = this.lengthIndex + paramInt2 - 1;
    int i1 = this.lengthIndexLastRow + paramInt1 - 1;
    short s = paramArrayOfshort[i1];
    
    this.rowSpaceIndicator[n] = (short)s;
    this.rowSpaceIndicator[k] = paramArrayOfshort[m];

    
    if (s != 0)
    {
      System.arraycopy(paramArrayOfbyte, j, this.rowSpaceByte, i, s + 2);
    }
  }









  
  static final byte[] rowidToString(long[] paramArrayOflong) {
    long l1 = paramArrayOflong[0];

    
    long l2 = paramArrayOflong[1];

    
    long l3 = paramArrayOflong[2];

    
    long l4 = paramArrayOflong[3];
    
    byte b = 18;


    
    byte[] arrayOfByte = new byte[b];
    int i = 0;
    
    i = kgrd42b(arrayOfByte, l1, 6, i);

    
    i = kgrd42b(arrayOfByte, l2, 3, i);

    
    i = kgrd42b(arrayOfByte, l3, 6, i);

    
    i = kgrd42b(arrayOfByte, l4, 3, i);


    
    return arrayOfByte;
  }












  
  static final long[] rcToRowid(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
    byte b = 18;
    
    if (paramInt2 != b)
    {
      throw new SQLException("Rowid size incorrect.");
    }
    
    long[] arrayOfLong = new long[3];
    String str = new String(paramArrayOfbyte, paramInt1, paramInt2);

    
    long l1 = Long.parseLong(str.substring(0, 8), 16);
    long l2 = Long.parseLong(str.substring(9, 13), 16);
    long l3 = Long.parseLong(str.substring(14, 8), 16);
    
    arrayOfLong[0] = l3;
    arrayOfLong[1] = l1;
    arrayOfLong[2] = l2;
    
    return arrayOfLong;
  }
















  
  static final void kgrdr2rc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, byte[] paramArrayOfbyte, int paramInt6) throws SQLException {
    paramInt6 = lmx42h(paramArrayOfbyte, paramInt4, 8, paramInt6);
    paramArrayOfbyte[paramInt6++] = 46;
    
    paramInt6 = lmx42h(paramArrayOfbyte, paramInt5, 4, paramInt6);
    paramArrayOfbyte[paramInt6++] = 46;
    
    paramInt6 = lmx42h(paramArrayOfbyte, paramInt2, 4, paramInt6);
  }











  
  static final int lmx42h(byte[] paramArrayOfbyte, long paramLong, int paramInt1, int paramInt2) {
    String str = Long.toHexString(paramLong).toUpperCase();

    
    int i = paramInt1;
    byte b = 0;

    
    do {
      if (b < str.length())
      {
        paramArrayOfbyte[paramInt2 + paramInt1 - 1] = (byte)str.charAt(str.length() - b - 1);
        
        b++;
      }
      else
      {
        paramArrayOfbyte[paramInt2 + paramInt1 - 1] = 48;
      }
    
    } while (--paramInt1 > 0);
    
    return i + paramInt2;
  }













  
  static final int kgrdc2ub(byte[] paramArrayOfbyte1, int paramInt1, byte[] paramArrayOfbyte2, int paramInt2, int paramInt3) throws SQLException {
    byte b = getRowidType(paramArrayOfbyte1, paramInt1);
    byte[] arrayOfByte1 = paramArrayOfbyte2;
    int i = paramInt3 - 1;
    int j = 0;



    
    byte[] arrayOfByte2 = kgrd_index_64;





    
    int k = 1 + 3 * (paramInt3 - 1) / 4 + (((paramInt3 - 1) % 4 != 0) ? ((paramInt3 - 1) % 4 - 1) : 0);




    
    if (i == 0) {

      
      SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    arrayOfByte1[paramInt2 + 0] = b;






    
    j = paramInt1 + 1;
    byte b1 = 1;
    
    while (i > 0) {

      
      if (i == 1) {

        
        SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 


      
      byte b2 = arrayOfByte2[paramArrayOfbyte1[j]];
      if (b2 == -1) {

        
        SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      j++;
      byte b3 = arrayOfByte2[paramArrayOfbyte1[j]];
      if (b3 == -1) {

        
        SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 





      
      arrayOfByte1[paramInt2 + b1] = (byte)((b2 & 0xFF) << 2 | (b3 & 0x30) >> 4);

      
      if (i == 2) {
        break;
      }



      
      b1++;
      b2 = b3;
      j++;
      b3 = arrayOfByte2[paramArrayOfbyte1[j]];
      if (b3 == -1) {

        
        SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      arrayOfByte1[paramInt2 + b1] = (byte)((b2 & 0xFF) << 4 | (b3 & 0x3C) >> 2);

      
      if (i == 3) {
        break;
      }

      
      b1++;
      b2 = b3;
      j++;
      b3 = arrayOfByte2[paramArrayOfbyte1[j]];
      if (b3 == -1) {

        
        SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      arrayOfByte1[paramInt2 + b1] = (byte)((b2 & 0x3) << 6 | b3);


      
      i -= 4;
      j++;
      b1++;
    } 
    
    return k;
  }






  
  static final long[] stringToRowid(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
    byte b = 18;



    
    if (paramInt2 != b)
    {
      throw new SQLException("Rowid size incorrect.");
    }
    
    long[] arrayOfLong = new long[4];



    
    try {
      arrayOfLong[0] = kgrdb42(paramArrayOfbyte, 6, paramInt1);

      
      paramInt1 += 6;

      
      arrayOfLong[1] = kgrdb42(paramArrayOfbyte, 3, paramInt1);

      
      paramInt1 += 3;

      
      arrayOfLong[2] = kgrdb42(paramArrayOfbyte, 6, paramInt1);

      
      paramInt1 += 6;

      
      arrayOfLong[3] = kgrdb42(paramArrayOfbyte, 3, paramInt1);

      
      paramInt1 += 3;
    }
    catch (Exception exception) {
      
      arrayOfLong[0] = 0L;
      arrayOfLong[1] = 0L;
      arrayOfLong[2] = 0L;
      arrayOfLong[3] = 0L;
    } 
    
    return arrayOfLong;
  }








  
  static final int kgrd42b(byte[] paramArrayOfbyte, long paramLong, int paramInt1, int paramInt2) {
    int i = paramInt1;
    long l = paramLong;
    
    for (; paramInt1 > 0; paramInt1--) {
      
      paramArrayOfbyte[paramInt2 + paramInt1 - 1] = kgrd_basis_64[(int)l & 0x3F];
      l = l >>> 6L & 0x3FFFFFFL;
    } 



    
    return i + paramInt2;
  }







  
  static final long kgrdb42(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
    long l = 0L;
    
    for (byte b = 0; b < paramInt1; b++) {
      
      byte b1 = paramArrayOfbyte[paramInt2 + b];
      
      b1 = kgrd_index_64[b1];
      
      if (b1 == -1) {
        throw new SQLException("Char data to rowid conversion failed.");
      }
      l <<= 6L;
      l |= b1;
    } 
    
    return l;
  }









  
  static final void kgrdr2ec(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, byte[] paramArrayOfbyte, int paramInt6) throws SQLException {
    paramInt6 = kgrd42b(paramInt1, paramArrayOfbyte, paramInt6, 6);
    paramInt6 = kgrd42b(paramInt2, paramArrayOfbyte, paramInt6, 3);
    paramInt6 = kgrd42b(paramInt4, paramArrayOfbyte, paramInt6, 6);
    paramInt6 = kgrd42b(paramInt5, paramArrayOfbyte, paramInt6, 3);
  }







  
  static final int kgrd42b(int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int paramInt3) throws SQLException {
    int i = paramInt3;
    while (paramInt3 > 0) {
      
      paramInt3--;
      paramArrayOfbyte[paramInt2 + paramInt3] = kgrd_basis_64[paramInt1 & 0x3F];
      
      paramInt1 >>= 6;
    } 
    
    return paramInt2 + i;
  }









  
  static final int kgrdub2c(byte[] paramArrayOfbyte1, int paramInt1, int paramInt2, byte[] paramArrayOfbyte2, int paramInt3) throws SQLException {
    byte b = -1;
    byte b1 = paramArrayOfbyte1[paramInt2];
    
    if (b1 == 1) {


      
      int[] arrayOfInt = new int[paramArrayOfbyte1.length]; int i;
      for (i = 0; i < paramArrayOfbyte1.length; ) { arrayOfInt[i] = paramArrayOfbyte1[i] & 0xFF; i++; }
      
      i = paramInt2 + 1;






      
      int j = (((arrayOfInt[i + 0] << 8) + arrayOfInt[i + 1] << 8) + arrayOfInt[i + 2] << 8) + arrayOfInt[i + 3];



      
      i = paramInt2 + 5;
      
      int k = (arrayOfInt[i + 0] << 8) + arrayOfInt[i + 1];
      boolean bool = false;

      
      i = paramInt2 + 7;
      int m = (((arrayOfInt[i + 0] << 8) + arrayOfInt[i + 1] << 8) + arrayOfInt[i + 2] << 8) + arrayOfInt[i + 3];



      
      i = paramInt2 + 11;
      
      int n = (arrayOfInt[i + 0] << 8) + arrayOfInt[i + 1];







      
      if (j == 0) {
        kgrdr2rc(j, k, bool, m, n, paramArrayOfbyte2, paramInt3);

      
      }
      else {


        
        kgrdr2ec(j, k, bool, m, n, paramArrayOfbyte2, paramInt3);
      } 





      
      b = 18;
    
    }
    else {

      
      byte b2 = 0;
      int i = paramInt1 - 1;
      int j = 4 * paramInt1 / 3 + ((paramInt1 % 3 == 0) ? (paramInt1 % 3 + 1) : 0);
      
      int k = 1 + j - 1;
      
      if (k != 0) {
        
        paramArrayOfbyte2[paramInt3 + 0] = kgrd_indbyte_char[b1 - 1];












        
        int m = paramInt2 + 1;
        
        b2 = 1;
        
        byte b3 = 0;
        
        while (i > 0) {
          
          paramArrayOfbyte2[paramInt3 + b2++] = kgrd_basis_64[(paramArrayOfbyte1[m] & 0xFF) >> 2];


          
          if (i == 1) {


            
            paramArrayOfbyte2[paramInt3 + b2++] = kgrd_basis_64[(paramArrayOfbyte1[m] & 0x3) << 4];

            
            break;
          } 

          
          b3 = (byte)(paramArrayOfbyte1[m + 1] & 0xFF);
          
          paramArrayOfbyte2[paramInt3 + b2++] = kgrd_basis_64[(paramArrayOfbyte1[m] & 0x3) << 4 | (b3 & 0xF0) >> 4];


          
          if (i == 2) {
            
            paramArrayOfbyte2[paramInt3 + b2++] = kgrd_basis_64[(b3 & 0xF) << 2];



            
            break;
          } 


          
          m += 2;
          paramArrayOfbyte2[paramInt3 + b2++] = kgrd_basis_64[(b3 & 0xF) << 2 | (paramArrayOfbyte1[m] & 0xC0) >> 6];


          
          paramArrayOfbyte2[paramInt3 + b2] = kgrd_basis_64[paramArrayOfbyte1[m] & 0x3F];


          
          i -= 3;
          m++;
          b2++;
        } 
      } 


      
      b = b2;
    } 
    
    return b;
  }


  
  static final boolean isUROWID(byte[] paramArrayOfbyte, int paramInt) {
    return (getRowidType(paramArrayOfbyte, paramInt) == 2);
  }


  
  static final byte getRowidType(byte[] paramArrayOfbyte, int paramInt) {
    byte b = 5;
    switch (paramArrayOfbyte[paramInt]) {
      
      case 65:
        b = 1;
        break;
      
      case 42:
        b = 2;
        break;
      
      case 45:
        b = 3;
        break;
      
      case 40:
        b = 4;
        break;
      
      case 41:
        b = 5;
        break;
    } 
    
    return b;
  }

























  
  static final byte[] kgrd_indbyte_char = new byte[] { 65, 42, 45, 40, 41 };





  
  static final byte[] kgrd_basis_64 = new byte[] { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47 };













  
  static final byte[] kgrd_index_64 = new byte[] { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1 };
























  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
