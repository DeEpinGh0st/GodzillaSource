package oracle.jdbc.oracore;

import java.sql.SQLException;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;

















public class TDSPatch
{
  static final int S_NORMAL_PATCH = 0;
  static final int S_SIMPLE_PATCH = 1;
  int typeId;
  OracleType owner;
  long position;
  int uptCode;
  
  public TDSPatch(int paramInt1, OracleType paramOracleType, long paramLong, int paramInt2) throws SQLException {
    this.typeId = paramInt1;
    this.owner = paramOracleType;
    this.position = paramLong;
    this.uptCode = paramInt2;
  }



  
  int getType() throws SQLException {
    return this.typeId;
  }



  
  OracleNamedType getOwner() throws SQLException {
    return (OracleNamedType)this.owner;
  }



  
  long getPosition() throws SQLException {
    return this.position;
  }



  
  byte getUptTypeCode() throws SQLException {
    return (byte)this.uptCode;
  }



  
  void apply(OracleType paramOracleType) throws SQLException {
    apply(paramOracleType, -1);
  }



  
  void apply(OracleType paramOracleType, int paramInt) throws SQLException {
    if (this.typeId == 0) {


      
      OracleTypeUPT oracleTypeUPT = (OracleTypeUPT)this.owner;
      
      oracleTypeUPT.realType = (OracleTypeADT)paramOracleType;

      
      if (paramOracleType instanceof OracleNamedType)
      {
        OracleNamedType oracleNamedType = (OracleNamedType)paramOracleType;
        
        oracleNamedType.setParent(oracleTypeUPT.getParent());
        oracleNamedType.setOrder(oracleTypeUPT.getOrder());
      }
    
    } else if (this.typeId == 1) {


      
      OracleTypeCOLLECTION oracleTypeCOLLECTION = (OracleTypeCOLLECTION)this.owner;
      
      oracleTypeCOLLECTION.opcode = paramInt;
      oracleTypeCOLLECTION.elementType = paramOracleType;

      
      if (paramOracleType instanceof OracleNamedType)
      {
        OracleNamedType oracleNamedType = (OracleNamedType)paramOracleType;
        
        oracleNamedType.setParent(oracleTypeCOLLECTION);
        oracleNamedType.setOrder(1);
      }
    
    } else {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }











  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }

















  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
