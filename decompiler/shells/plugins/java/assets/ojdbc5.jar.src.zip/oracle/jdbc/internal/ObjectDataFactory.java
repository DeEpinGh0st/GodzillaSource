package oracle.jdbc.internal;

public interface ObjectDataFactory {}
