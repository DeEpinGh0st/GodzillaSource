package oracle.jdbc.dcn;

import java.util.EventObject;











































public abstract class DatabaseChangeEvent
  extends EventObject
{
  protected DatabaseChangeEvent(Object paramObject) {
    super(paramObject);
  }





  
  public enum EventType
  {
    NONE(0),


    
    STARTUP(1),


    
    SHUTDOWN(2),


    
    SHUTDOWN_ANY(3),


    
    DEREG(5),


    
    OBJCHANGE(6),


    
    QUERYCHANGE(7);
    
    private final int code;
    
    EventType(int param1Int1) {
      this.code = param1Int1;
    }




    
    public final int getCode() {
      return this.code;
    }



    
    public static final EventType getEventType(int param1Int) {
      if (param1Int == STARTUP.getCode())
        return STARTUP; 
      if (param1Int == SHUTDOWN.getCode())
        return SHUTDOWN; 
      if (param1Int == SHUTDOWN_ANY.getCode())
        return SHUTDOWN_ANY; 
      if (param1Int == DEREG.getCode())
        return DEREG; 
      if (param1Int == OBJCHANGE.getCode())
        return OBJCHANGE; 
      if (param1Int == QUERYCHANGE.getCode()) {
        return QUERYCHANGE;
      }
      return NONE;
    }
  }









  
  public enum AdditionalEventType
  {
    NONE(0),


    
    TIMEOUT(1),


    
    GROUPING(2);
    
    private final int code;

    
    AdditionalEventType(int param1Int1) {
      this.code = param1Int1;
    }




    
    public final int getCode() {
      return this.code;
    }



    
    public static final AdditionalEventType getEventType(int param1Int) {
      if (param1Int == TIMEOUT.getCode())
        return TIMEOUT; 
      if (param1Int == GROUPING.getCode()) {
        return GROUPING;
      }
      return NONE;
    }
  }























































































  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
  
  public abstract EventType getEventType();
  
  public abstract AdditionalEventType getAdditionalEventType();
  
  public abstract TableChangeDescription[] getTableChangeDescription();
  
  public abstract QueryChangeDescription[] getQueryChangeDescription();
  
  public abstract String getConnectionInformation();
  
  public abstract String getDatabaseName();
  
  public abstract int getRegistrationId();
  
  public abstract long getRegId();
  
  public abstract byte[] getTransactionId();
  
  public abstract String getTransactionId(boolean paramBoolean);
  
  public abstract String toString();
}
