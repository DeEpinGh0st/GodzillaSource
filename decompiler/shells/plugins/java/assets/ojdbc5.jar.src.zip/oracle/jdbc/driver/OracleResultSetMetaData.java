package oracle.jdbc.driver;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.OracleArray;
import oracle.jdbc.OracleBfile;
import oracle.jdbc.OracleBlob;
import oracle.jdbc.OracleClob;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleOpaque;
import oracle.jdbc.OracleRef;
import oracle.jdbc.OracleStruct;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.internal.OracleResultSetMetaData;
import oracle.jdbc.oracore.OracleNamedType;
import oracle.jdbc.oracore.OracleTypeADT;
import oracle.sql.StructDescriptor;
import oracle.sql.TypeDescriptor;






















class OracleResultSetMetaData
  implements OracleResultSetMetaData
{
  PhysicalConnection connection;
  OracleStatement statement;
  int m_beginColumnIndex;
  
  public OracleResultSetMetaData() {}
  
  public OracleResultSetMetaData(PhysicalConnection paramPhysicalConnection, OracleStatement paramOracleStatement) throws SQLException {
    this.connection = paramPhysicalConnection;
    this.statement = paramOracleStatement;
    
    paramOracleStatement.describe();
    
    this.m_beginColumnIndex = 0;
  }








  
  OracleResultSetMetaData(PhysicalConnection paramPhysicalConnection, OracleStatement paramOracleStatement, int paramInt) throws SQLException {
    this.connection = paramPhysicalConnection;
    this.statement = paramOracleStatement;
    
    paramOracleStatement.describe();
    
    this.m_beginColumnIndex = paramInt;
  }







  
  public OracleResultSetMetaData(OracleResultSet paramOracleResultSet) throws SQLException {
    this.statement = (OracleStatement)((OracleStatementWrapper)paramOracleResultSet.getStatement()).statement;
    this.connection = (PhysicalConnection)this.statement.getConnection();
    
    this.statement.describe();
    
    this.m_beginColumnIndex = paramOracleResultSet.getFirstUserColumnIndex();
  }










  
  public int getColumnCount() throws SQLException {
    return this.statement.getNumberOfColumns() - this.m_beginColumnIndex;
  }









  
  public boolean isAutoIncrement(int paramInt) throws SQLException {
    return false;
  }












  
  int getValidColumnIndex(int paramInt) throws SQLException {
    int i = paramInt + this.m_beginColumnIndex - 1;
    
    if (i < 0 || i >= this.statement.getNumberOfColumns()) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3, "getValidColumnIndex");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    return i;
  }









  
  public boolean isCaseSensitive(int paramInt) throws SQLException {
    int i = getColumnType(paramInt);
    
    return (i == 1 || i == 12 || i == -1);
  }














  
  public boolean isSearchable(int paramInt) throws SQLException {
    int i = getColumnType(paramInt);

    
    return (i != -4 && i != -1 && i != 2004 && i != 2005 && i != -13 && i != 2002 && i != 2008 && i != 2007 && i != 2003 && i != 2006 && i != -10);
  }


















  
  public boolean isCurrency(int paramInt) throws SQLException {
    int i = getColumnType(paramInt);
    
    return (i == 2 || i == 6);
  }









  
  public int isNullable(int paramInt) throws SQLException {
    int i = getValidColumnIndex(paramInt);
    
    return (getDescription()[i]).nullable ? 1 : 0;
  }










  
  public boolean isSigned(int paramInt) throws SQLException {
    return true;
  }









  
  public int getColumnDisplaySize(int paramInt) throws SQLException {
    int k, m, i = getValidColumnIndex(paramInt);

    
    int j = (getDescription()[i]).describeType;
    
    switch (j) {

      
      case 2:
        k = getPrecision(paramInt);
        m = (getDescription()[i]).scale;
        
        if (k != 0 && m == -127) {


          
          k = (int)(k / 3.32193D);
          m = 1;
        }
        else {
          
          if (k == 0) {
            k = 38;
          }
          if (m == -127) {
            m = 0;
          }
        } 
        return k + ((m != 0) ? 1 : 0) + 1;
    } 



    
    return (getDescription()[i]).describeMaxLength;
  }











  
  public String getColumnLabel(int paramInt) throws SQLException {
    return getColumnName(paramInt);
  }









  
  public String getColumnName(int paramInt) throws SQLException {
    int i = getValidColumnIndex(paramInt);
    
    return (this.statement.getDescriptionWithNames()[i]).columnName;
  }










  
  public String getSchemaName(int paramInt) throws SQLException {
    return "";
  }









  
  public int getPrecision(int paramInt) throws SQLException {
    int i = getValidColumnIndex(paramInt);

    
    int j = (getDescription()[i]).describeType;
    
    switch (j) {
      
      case 112:
      case 113:
        return -1;
      
      case 8:
      case 24:
        return Integer.MAX_VALUE;
      
      case 1:
      case 96:
        return (getDescription()[i]).describeMaxLength;
    } 
    
    return (getDescription()[i]).precision;
  }





  
  public oracle.jdbc.OracleResultSetMetaData.SecurityAttribute getSecurityAttribute(int paramInt) throws SQLException {
    int i = getValidColumnIndex(paramInt);
    return (getDescription()[i]).securityAttribute;
  }









  
  public int getScale(int paramInt) throws SQLException {
    int i = getValidColumnIndex(paramInt);
    int j = (getDescription()[i]).scale;
    
    return (j == -127 && this.statement.connection.j2ee13Compliant) ? 0 : j;
  }










  
  public String getTableName(int paramInt) throws SQLException {
    return "";
  }










  
  public String getCatalogName(int paramInt) throws SQLException {
    return "";
  }











  
  public int getColumnType(int paramInt) throws SQLException {
    OracleNamedType oracleNamedType;
    TypeDescriptor typeDescriptor;
    SQLException sQLException;
    int i = getValidColumnIndex(paramInt);

    
    int j = (getDescription()[i]).describeType;


    
    switch (j) {



      
      case 96:
        return 1;




      
      case 1:
        return 12;

      
      case 8:
        return -1;
      
      case 2:
      case 6:
        if (this.statement.connection.j2ee13Compliant && (getDescription()[i]).precision != 0 && (getDescription()[i]).scale == -127)
        {
          
          return 6;
        }
        return 2;
      
      case 100:
        return 100;
      
      case 101:
        return 101;
      
      case 23:
        return -3;
      
      case 24:
        return -4;
      
      case 104:
      case 208:
        return -8;
      
      case 102:
        return -10;



      
      case 12:
        return this.connection.mapDateToTimestamp ? 93 : 91;

      
      case 180:
        return 93;
      
      case 181:
        return -101;
      
      case 231:
        return -102;
      
      case 113:
        return 2004;



      
      case 112:
        return 2005;

      
      case 114:
        return -13;

      
      case 109:
        oracleNamedType = (OracleNamedType)(getDescription()[i]).describeOtype;

        
        typeDescriptor = TypeDescriptor.getTypeDescriptor(oracleNamedType.getFullName(), (OracleConnection)this.connection);


        
        if (typeDescriptor != null) {
          return typeDescriptor.getTypeCode();
        }
        
        sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60);
        sQLException.fillInStackTrace();
        throw sQLException;


      
      case 111:
        return 2006;
      
      case 182:
        return -103;
      
      case 183:
        return -104;
    } 
    
    return 1111;
  }









  
  public String getColumnTypeName(int paramInt) throws SQLException {
    OracleTypeADT oracleTypeADT;
    int i = getValidColumnIndex(paramInt);

    
    int j = (getDescription()[i]).describeType;


    
    switch (j) {



      
      case 96:
        return "CHAR";




      
      case 1:
        return "VARCHAR2";

      
      case 8:
        return "LONG";
      
      case 2:
      case 6:
        if (this.statement.connection.j2ee13Compliant && (getDescription()[i]).precision != 0 && (getDescription()[i]).scale == -127)
        {
          
          return "FLOAT";
        }
        return "NUMBER";
      
      case 100:
        return "BINARY_FLOAT";
      
      case 101:
        return "BINARY_DOUBLE";
      
      case 23:
        return "RAW";
      
      case 24:
        return "LONG RAW";
      
      case 104:
      case 208:
        return "ROWID";
      
      case 102:
        return "REFCURSOR";



      
      case 12:
        return "DATE";
      
      case 180:
        return "TIMESTAMP";
      
      case 181:
        return "TIMESTAMP WITH TIME ZONE";
      
      case 231:
        return "TIMESTAMP WITH LOCAL TIME ZONE";
      
      case 113:
        return "BLOB";



      
      case 112:
        return "CLOB";

      
      case 114:
        return "BFILE";

      
      case 109:
        oracleTypeADT = (OracleTypeADT)(getDescription()[i]).describeOtype;

        
        return oracleTypeADT.getFullName();


      
      case 111:
        oracleTypeADT = (OracleTypeADT)(getDescription()[i]).describeOtype;

        
        return oracleTypeADT.getFullName();

      
      case 182:
        return "INTERVALYM";
      
      case 183:
        return "INTERVALDS";
    } 
    
    return null;
  }











  
  public boolean isReadOnly(int paramInt) throws SQLException {
    return false;
  }










  
  public boolean isWritable(int paramInt) throws SQLException {
    return true;
  }










  
  public boolean isDefinitelyWritable(int paramInt) throws SQLException {
    return false;
  }














  
  public String getColumnClassName(int paramInt) throws SQLException {
    OracleNamedType oracleNamedType;
    Map map1;
    SQLException sQLException;
    Map map2;
    int i = getValidColumnIndex(paramInt);

    
    int j = (getDescription()[i]).describeType;
    
    switch (j) {
      
      case 1:
      case 8:
      case 96:
      case 999:
        return "java.lang.String";
      
      case 2:
      case 6:
        if ((getDescription()[i]).precision != 0 && (getDescription()[i]).scale == -127)
        {
          return "java.lang.Double";
        }
        return "java.math.BigDecimal";
      
      case 23:
      case 24:
        return "byte[]";
      
      case 12:
        return "java.sql.Timestamp";
      
      case 180:
        if (this.statement.connection.j2ee13Compliant) {
          return "java.sql.Timestamp";
        }
        return "oracle.sql.TIMESTAMP";
      
      case 181:
        return "oracle.sql.TIMESTAMPTZ";
      
      case 231:
        return "oracle.sql.TIMESTAMPLTZ";
      
      case 182:
        return "oracle.sql.INTERVALYM";
      
      case 183:
        return "oracle.sql.INTERVALDS";
      
      case 104:
      case 208:
        return "oracle.sql.ROWID";
      
      case 113:
        return OracleBlob.class.getName();



      
      case 112:
        return OracleClob.class.getName();

      
      case 114:
        return OracleBfile.class.getName();
      
      case 102:
        return "OracleResultSet";

      
      case 109:
        switch (getColumnType(paramInt)) {
          
          case 2003:
            return OracleArray.class.getName();
          
          case 2007:
            return OracleOpaque.class.getName();

          
          case 2008:
            oracleNamedType = (OracleNamedType)(getDescription()[i]).describeOtype;

            
            map2 = this.connection.getJavaObjectTypeMap();
            
            if (map2 != null) {
              
              Class clazz = (Class)map2.get(oracleNamedType.getFullName());
              
              if (clazz != null) {
                return clazz.getName();
              }
            } 
            return StructDescriptor.getJavaObjectClassName((Connection)this.connection, oracleNamedType.getSchemaName(), oracleNamedType.getSimpleName());



          
          case 2002:
            map1 = this.connection.getTypeMap();
            
            if (map1 != null) {
              
              Class clazz = (Class)map1.get(((OracleNamedType)(getDescription()[i]).describeOtype).getFullName());

              
              if (clazz != null) {
                return clazz.getName();
              }
            } 
            return OracleStruct.class.getName();
        } 






        
        sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
        sQLException.fillInStackTrace();
        throw sQLException;



      
      case 111:
        return OracleRef.class.getName();

      
      case 101:
        return "oracle.sql.BINARY_DOUBLE";
      
      case 100:
        return "oracle.sql.BINARY_FLOAT";
    } 
    
    return null;
  }















  
  public boolean isNCHAR(int paramInt) throws SQLException {
    int i = getValidColumnIndex(paramInt);
    
    return ((getDescription()[i]).formOfUse == 2);
  }






  
  Accessor[] getDescription() throws SQLException {
    return this.statement.getDescription();
  }















  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return this.connection;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
