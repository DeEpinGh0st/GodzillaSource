package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;



























































































































































class T4CTTIoer
  extends T4CTTIMsg
{
  final int MAXERRBUF = 512;
  
  long curRowNumber;
  
  int retCode;
  
  int arrayElemWError;
  int arrayElemErrno;
  int currCursorID;
  short errorPosition;
  short sqlType;
  byte oerFatal;
  short flags;
  short userCursorOpt;
  short upiParam;
  short warningFlag;
  int osError;
  short stmtNumber;
  short callNumber;
  int pad1;
  long successIters;
  int partitionId;
  int tableId;
  int slotNumber;
  long rba;
  long blockNumber;
  int warnLength = 0;
  int warnFlag = 0;


  
  int[] errorLength = new int[1];


  
  byte[] errorMsg;


  
  static final int ORA1403 = 1403;



  
  T4CTTIoer(T4CConnection paramT4CConnection) {
    super(paramT4CConnection, (byte)4);
  }




  
  void init() {
    this.retCode = 0;
    this.errorMsg = null;
  }











  
  int unmarshal() throws IOException, SQLException {
    if (this.connection.getTTCVersion() >= 3) {
      
      short s = (short)this.meg.unmarshalUB2();
      
      this.connection.endToEndECIDSequenceNumber = s;
    } 
    
    this.curRowNumber = this.meg.unmarshalUB4();
    this.retCode = this.meg.unmarshalUB2();
    this.arrayElemWError = this.meg.unmarshalUB2();
    this.arrayElemErrno = this.meg.unmarshalUB2();
    this.currCursorID = this.meg.unmarshalUB2();
    this.errorPosition = this.meg.unmarshalSB2();
    this.sqlType = this.meg.unmarshalUB1();
    this.oerFatal = this.meg.unmarshalSB1();
    this.flags = (short)this.meg.unmarshalSB1();
    this.userCursorOpt = (short)this.meg.unmarshalSB1();
    this.upiParam = this.meg.unmarshalUB1();
    this.warningFlag = this.meg.unmarshalUB1();

    
    this.rba = this.meg.unmarshalUB4();
    this.partitionId = this.meg.unmarshalUB2();
    this.tableId = this.meg.unmarshalUB1();
    this.blockNumber = this.meg.unmarshalUB4();
    this.slotNumber = this.meg.unmarshalUB2();
    
    this.osError = this.meg.unmarshalSWORD();
    this.stmtNumber = this.meg.unmarshalUB1();
    this.callNumber = this.meg.unmarshalUB1();
    this.pad1 = this.meg.unmarshalUB2();
    this.successIters = this.meg.unmarshalUB4();









    
    byte[] arrayOfByte = this.meg.unmarshalDALC();













    
    int i = this.meg.unmarshalUB2(); int j;
    for (j = 0; j < i; j++)
      this.meg.unmarshalUB2(); 
    j = (int)this.meg.unmarshalUB4(); int k;
    for (k = 0; k < j; k++)
      this.meg.unmarshalUB4(); 
    k = this.meg.unmarshalUB2();

    
    if (this.retCode != 0) {
      
      this.errorMsg = this.meg.unmarshalCLRforREFS();
      this.errorLength[0] = this.errorMsg.length;
    } 

    
    return this.currCursorID;
  }




  
  void unmarshalWarning() throws IOException, SQLException {
    this.retCode = this.meg.unmarshalUB2();
    this.warnLength = this.meg.unmarshalUB2();
    this.warnFlag = this.meg.unmarshalUB2();

    
    if (this.retCode != 0 && this.warnLength > 0) {
      
      this.errorMsg = this.meg.unmarshalCHR(this.warnLength);
      this.errorLength[0] = this.warnLength;
    } 
  }







































  
  void print() throws SQLException {
    if (this.retCode == 0)
    {


      
      if (this.warnFlag != 0);
    }
  }






  
  void processError() throws SQLException {
    processError(true);
  }



  
  void processError(boolean paramBoolean) throws SQLException {
    processError(paramBoolean, (OracleStatement)null);
  }



  
  void processError(OracleStatement paramOracleStatement) throws SQLException {
    processError(true, paramOracleStatement);
  }










  
  void processError(boolean paramBoolean, OracleStatement paramOracleStatement) throws SQLException {
    if (paramOracleStatement != null) {
      paramOracleStatement.numberOfExecutedElementsInBatch = (int)this.successIters;
    }
    if (this.retCode != 0) {



      
      switch (this.retCode) {







        
        case 28:
        case 600:
        case 1012:
        case 1041:
        case 3113:
        case 3114:
          this.connection.internalClose();
          break;

        
        case 902:
          this.connection.removeAllDescriptor();
          break;
      } 
      
      if (paramBoolean) {


        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), this.meg.conv.CharBytesToString(this.errorMsg, this.errorLength[0], true), this.retCode);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 


      
      return;
    } 

    
    if (!paramBoolean) {
      return;
    }






    
    if ((this.warningFlag & 0x1) == 1) {
      
      int i = this.warningFlag & 0xFFFFFFFE;

      
      if ((i & 0x20) == 32 || (i & 0x4) == 4) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 110);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    } 

    
    if (this.connection != null && this.connection.plsqlCompilerWarnings)
    {
      if ((this.flags & 0x4) == 4) {
        paramOracleStatement.foundPlsqlCompilerWarning();
      }
    }
  }










  
  void processWarning() throws SQLException {
    if (this.retCode != 0)
    {

      
      throw DatabaseError.newSqlWarning(this.meg.conv.CharBytesToString(this.errorMsg, this.errorLength[0], true), this.retCode);
    }
  }








  
  int getCurRowNumber() throws SQLException {
    return (int)this.curRowNumber;
  }







  
  int getRetCode() {
    return this.retCode;
  }











  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return this.connection;
  }



  
  long updateChecksum(long paramLong) throws SQLException {
    paramLong = CRC64.updateChecksum(paramLong, this.retCode);
    paramLong = CRC64.updateChecksum(paramLong, this.curRowNumber);
    paramLong = CRC64.updateChecksum(paramLong, this.errorPosition);
    paramLong = CRC64.updateChecksum(paramLong, this.sqlType);
    paramLong = CRC64.updateChecksum(paramLong, this.oerFatal);
    paramLong = CRC64.updateChecksum(paramLong, this.flags);
    paramLong = CRC64.updateChecksum(paramLong, this.userCursorOpt);
    paramLong = CRC64.updateChecksum(paramLong, this.upiParam);
    paramLong = CRC64.updateChecksum(paramLong, this.warningFlag);
    paramLong = CRC64.updateChecksum(paramLong, this.osError);
    paramLong = CRC64.updateChecksum(paramLong, this.successIters);
    paramLong = CRC64.updateChecksum(paramLong, this.errorMsg, 0, this.errorMsg.length);
    return paramLong;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
