package oracle.jdbc;

import java.sql.DatabaseMetaData;
import java.sql.SQLException;

public interface AdditionalDatabaseMetaData extends DatabaseMetaData {
  OracleTypeMetaData getOracleTypeMetaData(String paramString) throws SQLException;
  
  long getLobMaxLength() throws SQLException;
}
