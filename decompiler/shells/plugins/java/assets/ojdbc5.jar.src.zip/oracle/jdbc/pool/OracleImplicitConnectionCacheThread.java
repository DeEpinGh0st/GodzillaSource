package oracle.jdbc.pool;

import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.internal.OracleConnection;

























class OracleImplicitConnectionCacheThread
  extends Thread
{
  private OracleImplicitConnectionCache implicitCache = null;

  
  protected boolean timeToLive = true;

  
  protected boolean isSleeping = false;

  
  OracleImplicitConnectionCacheThread(OracleImplicitConnectionCache paramOracleImplicitConnectionCache) throws SQLException {
    this.implicitCache = paramOracleImplicitConnectionCache;
  }




  
  public void run() {
    long l1 = 0L;
    long l2 = 0L;
    long l3 = 0L;



    
    while (this.timeToLive) {

      
      try {


        
        if (this.timeToLive && (l1 = this.implicitCache.getCacheTimeToLiveTimeout()) > 0L)
        {
          
          runTimeToLiveTimeout(l1);
        }

        
        if (this.timeToLive && (l2 = this.implicitCache.getCacheInactivityTimeout()) > 0L)
        {
          runInactivityTimeout();
        }

        
        if (this.timeToLive && (l3 = this.implicitCache.getCacheAbandonedTimeout()) > 0L)
        {
          runAbandonedTimeout(l3);
        }

        
        if (this.timeToLive) {
          
          this.isSleeping = true;


          
          try {
            sleep((this.implicitCache.getCachePropertyCheckInterval() * 1000));
          }
          catch (InterruptedException interruptedException) {}



          
          this.isSleeping = false;
        } 

        
        if (this.implicitCache == null || (l1 <= 0L && l2 <= 0L && l3 <= 0L))
        {
          
          this.timeToLive = false;
        }
      } catch (SQLException sQLException) {}
    } 
  }









  
  private void runTimeToLiveTimeout(long paramLong) throws SQLException {
    long l1 = 0L;
    long l2 = 0L;

    
    if (this.implicitCache.getNumberOfCheckedOutConnections() > 0) {
      
      OraclePooledConnection oraclePooledConnection = null;



      
      synchronized (this.implicitCache) {


        
        Object[] arrayOfObject = this.implicitCache.checkedOutConnectionList.toArray();
        int i = this.implicitCache.checkedOutConnectionList.size();
        
        for (byte b = 0; b < i; b++) {
          
          oraclePooledConnection = (OraclePooledConnection)arrayOfObject[b];
          
          Connection connection = oraclePooledConnection.getLogicalHandle();
          
          if (connection != null) {
            
            l2 = ((OracleConnection)connection).getStartTime();
            
            l1 = System.currentTimeMillis();

            
            if (l1 - l2 > paramLong * 1000L) {
              
              try {


                
                this.implicitCache.closeCheckedOutConnection(oraclePooledConnection, true);
              }
              catch (SQLException sQLException) {}
            }
          } 
        } 
      } 
    } 
  }










  
  private void runInactivityTimeout() {
    try {
      this.implicitCache.doForEveryCachedConnection(4);
    }
    catch (SQLException sQLException) {}
  }












  
  private void runAbandonedTimeout(long paramLong) throws SQLException {
    if (this.implicitCache.getNumberOfCheckedOutConnections() > 0) {
      
      OraclePooledConnection oraclePooledConnection = null;



      
      synchronized (this.implicitCache) {
        
        Object[] arrayOfObject = this.implicitCache.checkedOutConnectionList.toArray();

        
        for (byte b = 0; b < arrayOfObject.length; b++) {
          
          oraclePooledConnection = (OraclePooledConnection)arrayOfObject[b];
          
          OracleConnection oracleConnection = (OracleConnection)oraclePooledConnection.getLogicalHandle();
          
          if (oracleConnection != null) {


            
            OracleConnectionCacheCallback oracleConnectionCacheCallback = oracleConnection.getConnectionCacheCallbackObj();


            
            if ((oracleConnection.getHeartbeatNoChangeCount() * this.implicitCache.getCachePropertyCheckInterval()) > paramLong) {
              
              try {




                
                boolean bool = true;
                if (oracleConnectionCacheCallback != null && (oracleConnection.getConnectionCacheCallbackFlag() == 4 || oracleConnection.getConnectionCacheCallbackFlag() == 1))
                {








                  
                  bool = oracleConnectionCacheCallback.handleAbandonedConnection((OracleConnection)oracleConnection, oracleConnection.getConnectionCacheCallbackPrivObj());
                }


                
                if (bool) {
                  
                  this.implicitCache.closeCheckedOutConnection(oraclePooledConnection, true);
                  this.implicitCache.checkedOutConnectionList.remove(oraclePooledConnection);
                  this.implicitCache.storeCacheConnection(oraclePooledConnection.cachedConnectionAttributes, oraclePooledConnection);
                } 
              } catch (SQLException sQLException) {}
            }
          } 
        } 
      } 
    } 
  }









  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
