package oracle.jdbc.driver;

class OracleSQLXML {}
