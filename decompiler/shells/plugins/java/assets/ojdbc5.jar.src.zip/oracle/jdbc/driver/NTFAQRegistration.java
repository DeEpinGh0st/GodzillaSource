package oracle.jdbc.driver;

import java.sql.SQLException;
import java.util.EventListener;
import java.util.Properties;
import java.util.concurrent.Executor;
import oracle.jdbc.aq.AQNotificationListener;
import oracle.jdbc.aq.AQNotificationRegistration;













































class NTFAQRegistration
  extends NTFRegistration
  implements AQNotificationRegistration
{
  private final String name;
  
  NTFAQRegistration(int paramInt1, boolean paramBoolean, String paramString1, String paramString2, String paramString3, int paramInt2, Properties paramProperties, String paramString4, short paramShort) {
    super(paramInt1, 1, paramBoolean, paramString1, paramString3, paramInt2, paramProperties, paramString2, paramShort);








    
    this.name = paramString4;
  }






  
  public void addListener(AQNotificationListener paramAQNotificationListener, Executor paramExecutor) throws SQLException {
    NTFEventListener nTFEventListener = new NTFEventListener(paramAQNotificationListener);
    nTFEventListener.setExecutor(paramExecutor);
    addListener(nTFEventListener);
  }





  
  public void addListener(AQNotificationListener paramAQNotificationListener) throws SQLException {
    NTFEventListener nTFEventListener = new NTFEventListener(paramAQNotificationListener);
    addListener(nTFEventListener);
  }




  
  public void removeListener(AQNotificationListener paramAQNotificationListener) throws SQLException {
    removeListener((EventListener)paramAQNotificationListener);
  }



  
  public String getQueueName() {
    return this.name;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
