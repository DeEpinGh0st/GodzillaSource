package oracle.jdbc.driver;

import java.sql.SQLException;
import java.sql.Timestamp;
import oracle.jdbc.aq.AQAgent;
import oracle.jdbc.aq.AQMessageProperties;
























































class AQMessagePropertiesI
  implements AQMessageProperties
{
  private int attrAttempts = -1;
  private String attrCorrelation = null;
  private int attrDelay = 0;
  private Timestamp attrEnqTime = null;
  private String attrExceptionQueue = null;
  private int attrExpiration = -1;
  private AQMessageProperties.MessageState attrMsgState = null;
  private int attrPriority = 0;
  private AQAgentI[] attrRecipientList = null;
  private AQAgentI attrSenderId = null;
  private String attrTransactionGroup = null;
  private byte[] attrPreviousQueueMsgId = null;
  private AQMessageProperties.DeliveryMode deliveryMode = null;





  
  public int getDequeueAttemptsCount() {
    return this.attrAttempts;
  }




  
  public void setCorrelation(String paramString) throws SQLException {
    this.attrCorrelation = paramString;
  }



  
  public String getCorrelation() {
    return this.attrCorrelation;
  }



  
  public void setDelay(int paramInt) throws SQLException {
    this.attrDelay = paramInt;
  }



  
  public int getDelay() {
    return this.attrDelay;
  }



  
  public Timestamp getEnqueueTime() {
    return this.attrEnqTime;
  }




  
  public void setExceptionQueue(String paramString) throws SQLException {
    this.attrExceptionQueue = paramString;
  }



  
  public String getExceptionQueue() {
    return this.attrExceptionQueue;
  }




  
  public void setExpiration(int paramInt) throws SQLException {
    this.attrExpiration = paramInt;
  }



  
  public int getExpiration() {
    return this.attrExpiration;
  }



  
  public AQMessageProperties.MessageState getState() {
    return this.attrMsgState;
  }



  
  public void setPriority(int paramInt) throws SQLException {
    this.attrPriority = paramInt;
  }



  
  public int getPriority() {
    return this.attrPriority;
  }




  
  public void setRecipientList(AQAgent[] paramArrayOfAQAgent) throws SQLException {
    this.attrRecipientList = new AQAgentI[paramArrayOfAQAgent.length];
    for (byte b = 0; b < paramArrayOfAQAgent.length; b++) {
      this.attrRecipientList[b] = (AQAgentI)paramArrayOfAQAgent[b];
    }
  }


  
  public AQAgent[] getRecipientList() {
    return (AQAgent[])this.attrRecipientList;
  }



  
  public void setSender(AQAgent paramAQAgent) throws SQLException {
    this.attrSenderId = (AQAgentI)paramAQAgent;
  }



  
  public AQAgent getSender() {
    return this.attrSenderId;
  }



  
  public String getTransactionGroup() {
    return this.attrTransactionGroup;
  }



  
  void setTransactionGroup(String paramString) {
    this.attrTransactionGroup = paramString;
  }



  
  void setPreviousQueueMessageId(byte[] paramArrayOfbyte) {
    this.attrPreviousQueueMsgId = paramArrayOfbyte;
  }



  
  public byte[] getPreviousQueueMessageId() {
    return this.attrPreviousQueueMsgId;
  }



  
  public AQMessageProperties.DeliveryMode getDeliveryMode() {
    return this.deliveryMode;
  }



  
  void setDeliveryMode(AQMessageProperties.DeliveryMode paramDeliveryMode) {
    this.deliveryMode = paramDeliveryMode;
  }


































  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("Correlation             : " + getCorrelation() + "\n");
    Timestamp timestamp = getEnqueueTime();
    if (timestamp != null)
      stringBuffer.append("Enqueue time            : " + timestamp + "\n"); 
    stringBuffer.append("Exception Queue         : " + getExceptionQueue() + "\n");
    stringBuffer.append("Sender                  : (" + getSender() + ")\n");
    int i = getDequeueAttemptsCount();
    if (i != -1)
      stringBuffer.append("Attempts                : " + i + "\n"); 
    stringBuffer.append("Delay                   : " + getDelay() + "\n");
    stringBuffer.append("Expiration              : " + getExpiration() + "\n");
    AQMessageProperties.MessageState messageState = getState();
    
    if (messageState != null)
      stringBuffer.append("State                   : " + messageState + "\n"); 
    stringBuffer.append("Priority                : " + getPriority() + "\n");
    AQMessageProperties.DeliveryMode deliveryMode = getDeliveryMode();
    
    if (deliveryMode != null)
      stringBuffer.append("Delivery Mode           : " + deliveryMode + "\n"); 
    stringBuffer.append("Recipient List          : {");
    AQAgent[] arrayOfAQAgent = getRecipientList();
    if (arrayOfAQAgent != null)
    {
      for (byte b = 0; b < arrayOfAQAgent.length; b++) {
        
        stringBuffer.append(arrayOfAQAgent[b]);
        if (b != arrayOfAQAgent.length - 1)
          stringBuffer.append("; "); 
      } 
    }
    stringBuffer.append("}");
    
    return stringBuffer.toString();
  }



  
  void setAttempts(int paramInt) throws SQLException {
    this.attrAttempts = paramInt;
  }





  
  void setEnqueueTime(Timestamp paramTimestamp) throws SQLException {
    this.attrEnqTime = paramTimestamp;
  }




  
  void setMessageState(AQMessageProperties.MessageState paramMessageState) throws SQLException {
    this.attrMsgState = paramMessageState;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
