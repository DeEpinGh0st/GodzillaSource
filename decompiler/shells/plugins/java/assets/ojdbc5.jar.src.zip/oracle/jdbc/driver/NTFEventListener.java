package oracle.jdbc.driver;

import java.sql.SQLException;
import java.util.EventListener;
import java.util.concurrent.Executor;
import oracle.jdbc.aq.AQNotificationListener;
import oracle.jdbc.dcn.DatabaseChangeListener;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.internal.XSEventListener;





































class NTFEventListener
{
  private final AQNotificationListener aqlistener;
  private final DatabaseChangeListener dcnlistener;
  private final XSEventListener xslistener;
  private Executor executor = null;



  
  NTFEventListener(DatabaseChangeListener paramDatabaseChangeListener) throws SQLException {
    if (paramDatabaseChangeListener == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 246);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.dcnlistener = paramDatabaseChangeListener;
    this.aqlistener = null;
    this.xslistener = null;
  }




  
  NTFEventListener(AQNotificationListener paramAQNotificationListener) throws SQLException {
    if (paramAQNotificationListener == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 246);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.aqlistener = paramAQNotificationListener;
    this.dcnlistener = null;
    this.xslistener = null;
  }




  
  NTFEventListener(XSEventListener paramXSEventListener) throws SQLException {
    if (paramXSEventListener == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 246);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.aqlistener = null;
    this.dcnlistener = null;
    this.xslistener = paramXSEventListener;
  }



  
  void setExecutor(Executor paramExecutor) {
    this.executor = paramExecutor;
  }


  
  Executor getExecutor() {
    return this.executor;
  }


  
  EventListener getListener() {
    AQNotificationListener aQNotificationListener;
    DatabaseChangeListener databaseChangeListener = this.dcnlistener;
    if (databaseChangeListener == null)
      aQNotificationListener = this.aqlistener; 
    return (EventListener)aQNotificationListener;
  }



  
  AQNotificationListener getAQListener() {
    return this.aqlistener;
  }



  
  DatabaseChangeListener getDCNListener() {
    return this.dcnlistener;
  }


  
  XSEventListener getXSEventListener() {
    return this.xslistener;
  }













  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
