package oracle.jdbc.driver;

import java.io.IOException;
import oracle.net.ns.BreakNetException;
import oracle.net.ns.NetException;
import oracle.net.ns.NetInputStream;








































class T4CSocketInputStreamWrapper
  extends NetInputStream
{
  static final int MAX_BUFFER_SIZE = 2048;
  NetInputStream is = null;
  T4CSocketOutputStreamWrapper os = null;
  
  boolean eof = false;
  byte[] buffer = new byte[2048];
  
  int bIndex = 0;

  
  int bytesAvailable;


  
  T4CSocketInputStreamWrapper(NetInputStream paramNetInputStream, T4CSocketOutputStreamWrapper paramT4CSocketOutputStreamWrapper) throws IOException {
    this.is = paramNetInputStream;
    this.os = paramT4CSocketOutputStreamWrapper;
  }





  
  public final int read() throws IOException {
    if (this.eof) {
      return -1;
    }
    if (this.bytesAvailable < 1) {
      
      readNextPacket();
      if (this.eof)
        return -1; 
    } 
    this.bytesAvailable--;
    return this.buffer[this.bIndex++] & 0xFF;
  }


  
  public final int read(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
    if (this.eof) {
      return 0;
    }
    if (this.bytesAvailable < paramInt2) {
      
      int i = this.bytesAvailable;

      
      System.arraycopy(this.buffer, this.bIndex, paramArrayOfbyte, paramInt1, i);
      paramInt1 += i;
      this.bIndex += i;
      this.bytesAvailable -= i;

      
      this.is.read(paramArrayOfbyte, paramInt1, paramInt2 - i);
    } else {
      
      System.arraycopy(this.buffer, this.bIndex, paramArrayOfbyte, paramInt1, paramInt2);
      this.bIndex += paramInt2;
      this.bytesAvailable -= paramInt2;
    } 
    
    return paramInt2;
  }



  
  void readNextPacket() throws IOException {
    this.os.flush();


    
    int i = this.is.read();

    
    if (i == -1) {
      
      this.eof = true;
      
      return;
    } 
    this.buffer[0] = (byte)i;
    
    this.bytesAvailable = this.is.available() + 1;


    
    this.bytesAvailable = (this.bytesAvailable > 2048) ? 2048 : this.bytesAvailable;

    
    if (this.bytesAvailable > 1) {
      this.is.read(this.buffer, 1, this.bytesAvailable - 1);
    }
    
    this.bIndex = 0;
  }

  
  public int readB1() throws IOException {
    return read();
  }

  
  public long readLongLSB(int paramInt) throws IOException {
    long l = 0L;
    boolean bool = false;
    
    if ((paramInt & 0x80) > 0) {
      
      paramInt &= 0x7F;
      bool = true;
    } 
    
    int i;
    byte b;
    for (i = paramInt, b = 0; i > 0; i--, b++) {
      
      if (this.bytesAvailable < 1)
      {
        readNextPacket();
      }
      l |= (this.buffer[this.bIndex++] & 0xFFL) << 8 * b;
      this.bytesAvailable--;
    } 

    
    return (bool ? -1L : 1L) * l;
  }

  
  public long readLongMSB(int paramInt) throws IOException {
    long l = 0L;
    boolean bool = false;

    
    if ((paramInt & 0x80) > 0) {
      
      paramInt &= 0x7F;
      bool = true;
    } 


    
    for (int i = paramInt; i > 0; i--) {
      
      if (this.bytesAvailable < 1)
      {
        readNextPacket();
      }
      l |= (this.buffer[this.bIndex++] & 0xFFL) << 8 * (i - 1);
      
      this.bytesAvailable--;
    } 

    
    return (bool ? -1L : 1L) * l;
  }


  
  public boolean readZeroCopyIO(byte[] paramArrayOfbyte, int paramInt, int[] paramArrayOfint) throws IOException, NetException, BreakNetException {
    this.os.flush();
    return this.is.readZeroCopyIO(paramArrayOfbyte, paramInt, paramArrayOfint);
  }
}
