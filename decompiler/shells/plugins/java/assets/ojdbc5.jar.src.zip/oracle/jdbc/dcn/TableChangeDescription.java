package oracle.jdbc.dcn;

import java.util.EnumSet;











































public interface TableChangeDescription
{
  EnumSet<TableOperation> getTableOperations();
  
  String getTableName();
  
  int getObjectNumber();
  
  RowChangeDescription[] getRowChangeDescription();
  
  public enum TableOperation
  {
    ALL_ROWS(1),


    
    INSERT(2),


    
    UPDATE(4),


    
    DELETE(8),


    
    ALTER(16),


    
    DROP(32);
    private final int code;
    
    TableOperation(int param1Int1) {
      this.code = param1Int1;
    }



    
    public final int getCode() {
      return this.code;
    }



    
    public static final EnumSet<TableOperation> getTableOperations(int param1Int) {
      EnumSet<TableOperation> enumSet = EnumSet.noneOf(TableOperation.class);
      if ((param1Int & ALL_ROWS.getCode()) != 0)
        enumSet.add(ALL_ROWS); 
      if ((param1Int & INSERT.getCode()) != 0)
        enumSet.add(INSERT); 
      if ((param1Int & UPDATE.getCode()) != 0)
        enumSet.add(UPDATE); 
      if ((param1Int & DELETE.getCode()) != 0)
        enumSet.add(DELETE); 
      if ((param1Int & ALTER.getCode()) != 0)
        enumSet.add(ALTER); 
      if ((param1Int & DROP.getCode()) != 0)
        enumSet.add(DROP); 
      return enumSet;
    }
  }
}
