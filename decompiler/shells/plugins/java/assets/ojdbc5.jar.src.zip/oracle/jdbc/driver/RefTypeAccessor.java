package oracle.jdbc.driver;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.oracore.OracleType;
import oracle.jdbc.oracore.OracleTypeADT;
import oracle.sql.Datum;
import oracle.sql.REF;
import oracle.sql.StructDescriptor;
import oracle.sql.TypeDescriptor;












class RefTypeAccessor
  extends TypeAccessor
{
  RefTypeAccessor(OracleStatement paramOracleStatement, String paramString, short paramShort, int paramInt, boolean paramBoolean) throws SQLException {
    init(paramOracleStatement, 111, 111, paramShort, paramBoolean);
    initForDataAccess(paramInt, 0, paramString);
  }






  
  RefTypeAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, String paramString) throws SQLException {
    init(paramOracleStatement, 111, 111, paramShort, false);
    initForDescribe(111, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, paramString);
    
    initForDataAccess(0, paramInt1, paramString);
  }






  
  RefTypeAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, String paramString, OracleType paramOracleType) throws SQLException {
    init(paramOracleStatement, 111, 111, paramShort, false);
    
    this.describeOtype = paramOracleType;
    
    initForDescribe(111, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, paramString);

    
    this.internalOtype = paramOracleType;
    
    initForDataAccess(0, paramInt1, paramString);
  }



  
  OracleType otypeFromName(String paramString) throws SQLException {
    if (!this.outBind) {
      return (OracleType)TypeDescriptor.getTypeDescriptor(paramString, (OracleConnection)this.statement.connection).getPickler();
    }
    
    return (OracleType)StructDescriptor.createDescriptor(paramString, (Connection)this.statement.connection).getOracleTypeADT();
  }





  
  void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
    super.initForDataAccess(paramInt1, paramInt2, paramString);
    
    this.byteLength = this.statement.connection.refTypeAccessorByteLen;
  }












  
  REF getREF(int paramInt) throws SQLException {
    REF rEF = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      byte[] arrayOfByte = pickledBytes(paramInt);
      OracleTypeADT oracleTypeADT = (OracleTypeADT)this.internalOtype;
      
      rEF = new REF(oracleTypeADT.getFullName(), (Connection)this.statement.connection, arrayOfByte);
    } 
    
    return rEF;
  }




  
  Object getObject(int paramInt) throws SQLException {
    return getREF(paramInt);
  }




  
  Datum getOracleObject(int paramInt) throws SQLException {
    return (Datum)getREF(paramInt);
  }




  
  Object getObject(int paramInt, Map paramMap) throws SQLException {
    return getREF(paramInt);
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
