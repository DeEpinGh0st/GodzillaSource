package oracle.jdbc.oracore;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.BINARY_FLOAT;
import oracle.sql.Datum;
































public class OracleTypeBINARY_FLOAT
  extends OracleType
  implements Serializable
{
  public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection) throws SQLException {
    BINARY_FLOAT bINARY_FLOAT = null;
    
    if (paramObject != null)
    {
      if (paramObject instanceof BINARY_FLOAT) {
        bINARY_FLOAT = (BINARY_FLOAT)paramObject;
      } else if (paramObject instanceof Float) {
        bINARY_FLOAT = new BINARY_FLOAT((Float)paramObject);
      } else if (paramObject instanceof byte[]) {
        bINARY_FLOAT = new BINARY_FLOAT((byte[])paramObject);
      } else {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    }
    
    return (Datum)bINARY_FLOAT;
  }










  
  public Datum[] toDatumArray(Object paramObject, OracleConnection paramOracleConnection, long paramLong, int paramInt) throws SQLException {
    Datum[] arrayOfDatum = null;
    
    if (paramObject != null)
    {
      if (paramObject instanceof Object[]) {
        
        Object[] arrayOfObject = (Object[])paramObject;
        
        int i = (int)((paramInt == -1) ? arrayOfObject.length : Math.min(arrayOfObject.length - paramLong + 1L, paramInt));

        
        arrayOfDatum = new Datum[i];
        
        for (byte b = 0; b < i; b++) {
          
          Object object = arrayOfObject[(int)paramLong + b - 1];
          
          if (object != null) {
            
            if (object instanceof Float) {
              arrayOfDatum[b] = (Datum)new BINARY_FLOAT(((Float)object).floatValue());
            }
            else if (object instanceof BINARY_FLOAT) {
              arrayOfDatum[b] = (Datum)object;
            } else {
              
              SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
              sQLException.fillInStackTrace();
              throw sQLException;
            }
          
          }
          else {
            
            arrayOfDatum[b] = null;
          } 
        } 
      } 
    }
    
    return arrayOfDatum;
  }






  
  public int getTypeCode() {
    return 100;
  }






















  
  protected Object toObject(byte[] paramArrayOfbyte, int paramInt, Map paramMap) throws SQLException {
    if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
      return null;
    }
    if (paramInt == 1)
      return new BINARY_FLOAT(paramArrayOfbyte); 
    if (paramInt == 2)
      return (new BINARY_FLOAT(paramArrayOfbyte)).toJdbc(); 
    if (paramInt == 3) {
      return paramArrayOfbyte;
    }
    
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramArrayOfbyte);
    sQLException.fillInStackTrace();
    throw sQLException;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
