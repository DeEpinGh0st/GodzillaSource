package oracle.jdbc.rowset;

import java.sql.SQLException;
import oracle.jdbc.driver.OracleSql;




























class OracleSqlForRowSet
  extends OracleSql
{
  OracleSqlForRowSet(String paramString) throws SQLException {
    super(null);
    
    initialize(paramString);
  }












  
  protected void initialize(String paramString) throws SQLException {
    super.initialize(paramString);
  }











  
  protected int getParameterCount() throws SQLException {
    return super.getParameterCount();
  }













  
  protected String[] getParameterList() throws SQLException {
    return super.getParameterList();
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
