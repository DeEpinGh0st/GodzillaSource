package oracle.jdbc.driver;

import java.sql.SQLException;
































abstract class OracleTimeout
{
  static OracleTimeout newTimeout(String paramString) throws SQLException {
    return new OracleTimeoutThreadPerVM(paramString);
  }
































  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
  
  abstract void setTimeout(long paramLong, OracleStatement paramOracleStatement) throws SQLException;
  
  abstract void cancelTimeout() throws SQLException;
  
  abstract void close() throws SQLException;
}
