package oracle.jdbc.driver;

import java.sql.Connection;
import javax.transaction.xa.XAException;
import javax.transaction.xa.XAResource;
import oracle.jdbc.xa.OracleXAConnection;
import oracle.jdbc.xa.OracleXAResource;
import oracle.jdbc.xa.client.OracleXAConnection;
















public class T4CXAConnection
  extends OracleXAConnection
{
  T4CTTIOtxen otxen;
  T4CTTIOtxse otxse;
  T4CConnection physicalConnection;
  
  public T4CXAConnection(Connection paramConnection) throws XAException {
    super(paramConnection);
    
    this.physicalConnection = (T4CConnection)paramConnection;
    this.xaResource = null;
  }




  
  public synchronized XAResource getXAResource() {
    try {
      if (this.xaResource == null)
      {
        this.xaResource = (XAResource)new T4CXAResource(this.physicalConnection, (OracleXAConnection)this, this.isXAResourceTransLoose);

        
        if (this.logicalHandle != null)
        {

          
          ((OracleXAResource)this.xaResource).setLogicalConnection((Connection)this.logicalHandle);
        }
      }
    
    } catch (Exception exception) {

      
      this.xaResource = null;
    } 
    return this.xaResource;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
