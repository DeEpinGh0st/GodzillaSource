package oracle.jdbc.driver;

public interface DiagnosabilityMXBean {
  boolean stateManageable();
  
  boolean statisticsProvider();
  
  boolean getLoggingEnabled();
  
  void setLoggingEnabled(boolean paramBoolean);
}
