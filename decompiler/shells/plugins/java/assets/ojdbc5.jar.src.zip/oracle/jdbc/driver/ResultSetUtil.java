package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;


















class ResultSetUtil
{
  static final int[][] allRsetTypes = new int[][] { { 0, 0 }, { 1003, 1007 }, { 1003, 1008 }, { 1004, 1007 }, { 1004, 1008 }, { 1005, 1007 }, { 1005, 1008 } };
































  
  static OracleResultSet createScrollResultSet(ScrollRsetStatement paramScrollRsetStatement, OracleResultSet paramOracleResultSet, int paramInt) throws SQLException {
    ScrollableResultSet scrollableResultSet;
    SensitiveScrollableResultSet sensitiveScrollableResultSet;
    switch (paramInt) {

      
      case 1:
        return paramOracleResultSet;
      
      case 2:
        return new UpdatableResultSet(paramScrollRsetStatement, (OracleResultSetImpl)paramOracleResultSet, getScrollType(paramInt), getUpdateConcurrency(paramInt));



      
      case 3:
        return new ScrollableResultSet(paramScrollRsetStatement, (OracleResultSetImpl)paramOracleResultSet, getScrollType(paramInt), getUpdateConcurrency(paramInt));



      
      case 4:
        scrollableResultSet = new ScrollableResultSet(paramScrollRsetStatement, (OracleResultSetImpl)paramOracleResultSet, getScrollType(paramInt), getUpdateConcurrency(paramInt));


        
        return new UpdatableResultSet(paramScrollRsetStatement, scrollableResultSet, getScrollType(paramInt), getUpdateConcurrency(paramInt));

      
      case 5:
        return new SensitiveScrollableResultSet(paramScrollRsetStatement, (OracleResultSetImpl)paramOracleResultSet, getScrollType(paramInt), getUpdateConcurrency(paramInt));



      
      case 6:
        sensitiveScrollableResultSet = new SensitiveScrollableResultSet(paramScrollRsetStatement, (OracleResultSetImpl)paramOracleResultSet, getScrollType(paramInt), getUpdateConcurrency(paramInt));


        
        return new UpdatableResultSet(paramScrollRsetStatement, sensitiveScrollableResultSet, getScrollType(paramInt), getUpdateConcurrency(paramInt));
    } 


    
    SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 23, (Object)null);
    sQLException.fillInStackTrace();
    throw sQLException;
  }










  
  static int getScrollType(int paramInt) {
    return allRsetTypes[paramInt][0];
  }







  
  static int getUpdateConcurrency(int paramInt) {
    return allRsetTypes[paramInt][1];
  }









  
  static int getRsetTypeCode(int paramInt1, int paramInt2) throws SQLException {
    for (byte b = 0; b < allRsetTypes.length; b++) {
      
      if (allRsetTypes[b][0] == paramInt1 && allRsetTypes[b][1] == paramInt2)
      {

        
        return b;
      }
    } 

    
    SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 68);
    sQLException.fillInStackTrace();
    throw sQLException;
  }











  
  static boolean needIdentifier(int paramInt) throws SQLException {
    return (paramInt != 1 && paramInt != 3);
  }




  
  static boolean needIdentifier(int paramInt1, int paramInt2) throws SQLException {
    return needIdentifier(getRsetTypeCode(paramInt1, paramInt2));
  }








  
  static boolean needCache(int paramInt) throws SQLException {
    return (paramInt >= 3);
  }



  
  static boolean needCache(int paramInt1, int paramInt2) throws SQLException {
    return needCache(getRsetTypeCode(paramInt1, paramInt2));
  }







  
  static boolean supportRefreshRow(int paramInt) throws SQLException {
    return (paramInt >= 4);
  }




  
  static boolean supportRefreshRow(int paramInt1, int paramInt2) throws SQLException {
    return supportRefreshRow(getRsetTypeCode(paramInt1, paramInt2));
  }











  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
