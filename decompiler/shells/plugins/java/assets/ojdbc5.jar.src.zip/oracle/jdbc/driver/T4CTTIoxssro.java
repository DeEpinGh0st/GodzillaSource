package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.KeywordValueLong;
import oracle.jdbc.internal.OracleConnection;













































final class T4CTTIoxssro
  extends T4CTTIfun
{
  private int functionId;
  private byte[] sessionId;
  private KeywordValueLong[] inKV;
  private int inFlags;
  private KeywordValueLong[] outKV;
  private int outFlags;
  
  T4CTTIoxssro(T4CConnection paramT4CConnection) {
    super(paramT4CConnection, (byte)3);




    
    this.sessionId = null;
    this.inKV = null;

    
    this.outKV = null;
    this.outFlags = -1;
    setFunCode((short)156);
  }




  
  void doOXSSRO(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2) throws IOException, SQLException {
    this.functionId = paramInt1;
    this.sessionId = paramArrayOfbyte;
    this.inKV = paramArrayOfKeywordValueLong;
    this.inFlags = paramInt2;
    this.outKV = null;
    this.outFlags = -1;
    
    if (this.inKV != null)
      for (byte b = 0; b < this.inKV.length; b++)
        ((KeywordValueLongI)this.inKV[b]).doCharConversion(this.meg.conv);  
    doRPC();
  }


  
  void marshal() throws IOException {
    this.meg.marshalUB4(this.functionId);
    boolean bool1 = false;
    if (this.sessionId != null && this.sessionId.length > 0) {
      
      bool1 = true;
      this.meg.marshalPTR();
      this.meg.marshalUB4(this.sessionId.length);
    }
    else {
      
      this.meg.marshalNULLPTR();
      this.meg.marshalUB4(0L);
    } 
    boolean bool2 = false;
    if (this.inKV != null && this.inKV.length > 0) {
      
      bool2 = true;
      this.meg.marshalPTR();
      this.meg.marshalUB4(this.inKV.length);
    }
    else {
      
      this.meg.marshalNULLPTR();
      this.meg.marshalUB4(0L);
    } 
    this.meg.marshalUB4(this.inFlags);
    this.meg.marshalPTR();
    this.meg.marshalPTR();
    this.meg.marshalPTR();
    
    if (bool1)
      this.meg.marshalB1Array(this.sessionId); 
    if (bool2) {
      for (byte b = 0; b < this.inKV.length; b++) {
        ((KeywordValueLongI)this.inKV[b]).marshal(this.meg);
      }
    }
  }


  
  KeywordValueLong[] getOutKV() {
    return this.outKV;
  }


  
  int getOutFlags() {
    return this.outFlags;
  }


  
  void readRPA() throws SQLException, IOException {
    int i = (int)this.meg.unmarshalUB4();
    this.outKV = new KeywordValueLong[i];
    for (byte b = 0; b < i; b++)
      this.outKV[b] = KeywordValueLongI.unmarshal(this.meg); 
    this.outFlags = (int)this.meg.unmarshalUB4();
  }











  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return this.connection;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
