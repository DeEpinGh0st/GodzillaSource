package oracle.jdbc.oracore;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.Datum;
import oracle.sql.OPAQUE;
import oracle.sql.OpaqueDescriptor;
import oracle.sql.StructDescriptor;






















public class OracleTypeOPAQUE
  extends OracleTypeADT
  implements Serializable
{
  static final long KOLOFLLB = 1L;
  static final long KOLOFLCL = 2L;
  static final long KOLOFLUB = 4L;
  static final long KOLOFLFX = 8L;
  static final long serialVersionUID = -7279638692691669378L;
  long flagBits;
  long maxLen;
  
  public OracleTypeOPAQUE(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, short paramShort, String paramString, long paramLong) throws SQLException {
    super(paramArrayOfbyte, paramInt1, paramInt2, paramShort, paramString);
    
    this.flagBits = paramLong;
    this.flattenedAttrNum = 1;
  }



  
  public OracleTypeOPAQUE(String paramString, OracleConnection paramOracleConnection) throws SQLException {
    super(paramString, (Connection)paramOracleConnection);
  }




  
  public OracleTypeOPAQUE(OracleTypeADT paramOracleTypeADT, int paramInt, OracleConnection paramOracleConnection) throws SQLException {
    super(paramOracleTypeADT, paramInt, (Connection)paramOracleConnection);
  }











  
  public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection) throws SQLException {
    if (paramObject != null) {
      
      if (paramObject instanceof OPAQUE) {
        return (Datum)paramObject;
      }
      
      OpaqueDescriptor opaqueDescriptor = createOpaqueDescriptor();
      
      return (Datum)new OPAQUE(opaqueDescriptor, (Connection)this.connection, paramObject);
    } 

    
    return null;
  }








  
  public int getTypeCode() {
    return 2007;
  }







  
  public boolean isInHierarchyOf(OracleType paramOracleType) throws SQLException {
    if (paramOracleType == null)
      return false; 
    if (!(paramOracleType instanceof OracleTypeOPAQUE)) {
      return false;
    }
    OpaqueDescriptor opaqueDescriptor = (OpaqueDescriptor)paramOracleType.getTypeDescriptor();

    
    return this.descriptor.isInHierarchyOf(opaqueDescriptor.getName());
  }




  
  public boolean isInHierarchyOf(StructDescriptor paramStructDescriptor) throws SQLException {
    return false;
  }



  
  public boolean isObjectType() {
    return false;
  }








  
  public void parseTDSrec(TDSReader paramTDSReader) throws SQLException {
    paramTDSReader.skipBytes(5);
    
    this.flagBits = paramTDSReader.readLong();
    this.maxLen = paramTDSReader.readLong();
  }








  
  public Datum unlinearize(byte[] paramArrayOfbyte, long paramLong, Datum paramDatum, int paramInt, Map paramMap) throws SQLException {
    if (paramArrayOfbyte == null) {
      return null;
    }
    if ((paramArrayOfbyte[0] & 0x80) > 0) {
      
      PickleContext pickleContext = new PickleContext(paramArrayOfbyte, paramLong);
      
      return (Datum)unpickle81(pickleContext, (OPAQUE)paramDatum, paramInt, paramMap);
    } 



    
    return null;
  }








  
  public byte[] linearize(Datum paramDatum) throws SQLException {
    return pickle81(paramDatum);
  }







  
  protected int pickle81(PickleContext paramPickleContext, Datum paramDatum) throws SQLException {
    OPAQUE oPAQUE = (OPAQUE)paramDatum;
    byte[] arrayOfByte = oPAQUE.getBytesValue();
    int i = 0;
    
    i += paramPickleContext.writeOpaqueImageHeader(arrayOfByte.length);
    i += paramPickleContext.writeData(arrayOfByte);
    
    return i;
  }








  
  OPAQUE unpickle81(PickleContext paramPickleContext, OPAQUE paramOPAQUE, int paramInt, Map paramMap) throws SQLException {
    return unpickle81datum(paramPickleContext, paramOPAQUE, paramInt);
  }



  
  protected Object unpickle81rec(PickleContext paramPickleContext, int paramInt, Map paramMap) throws SQLException {
    Object object;
    byte b = paramPickleContext.readByte();
    OPAQUE oPAQUE = null;
    
    if (PickleContext.isElementNull(b)) {
      return null;
    }
    paramPickleContext.skipRestOfLength(b);
    
    switch (paramInt) {

      
      case 1:
        oPAQUE = unpickle81datum(paramPickleContext, (OPAQUE)null);























        
        return oPAQUE;case 2: object = unpickle81datum(paramPickleContext, (OPAQUE)null).toJdbc(); return object;case 3: object = new OPAQUE(createOpaqueDescriptor(), paramPickleContext.readDataValue(), (Connection)this.connection); return object;case 9: paramPickleContext.skipDataValue(); return object;
    } 
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
    sQLException.fillInStackTrace();
    throw sQLException;
  }





  
  private OPAQUE unpickle81datum(PickleContext paramPickleContext, OPAQUE paramOPAQUE) throws SQLException {
    return unpickle81datum(paramPickleContext, paramOPAQUE, 1);
  }






  
  private OPAQUE unpickle81datum(PickleContext paramPickleContext, OPAQUE paramOPAQUE, int paramInt) throws SQLException {
    paramPickleContext.skipBytes(2);
    
    long l = (paramPickleContext.readLength(true) - 2);


    
    if (paramOPAQUE == null) {
      
      if (paramInt == 2)
      {

        
        return new OPAQUE(createOpaqueDescriptor(), (Connection)this.connection, paramPickleContext.readBytes((int)l));
      }




      
      return new OPAQUE(createOpaqueDescriptor(), (Connection)this.connection, paramPickleContext.readBytes((int)l));
    } 



    
    paramOPAQUE.setValue(paramPickleContext.readBytes((int)l));
    
    return paramOPAQUE;
  }




  
  OpaqueDescriptor createOpaqueDescriptor() throws SQLException {
    if (this.sqlName == null) {
      return new OpaqueDescriptor(this, (Connection)this.connection);
    }
    return OpaqueDescriptor.createDescriptor(this.sqlName, (Connection)this.connection);
  }



  
  public long getMaxLength() throws SQLException {
    return this.maxLen;
  }



  
  public boolean isTrustedLibrary() throws SQLException {
    return ((this.flagBits & 0x1L) != 0L);
  }



  
  public boolean isModeledInC() throws SQLException {
    return ((this.flagBits & 0x2L) != 0L);
  }



  
  public boolean isUnboundedSized() throws SQLException {
    return ((this.flagBits & 0x4L) != 0L);
  }



  
  public boolean isFixedSized() throws SQLException {
    return ((this.flagBits & 0x8L) != 0L);
  }






  
  private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {}





  
  private void readObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {}





  
  public void setConnection(OracleConnection paramOracleConnection) throws SQLException {
    this.connection = paramOracleConnection;
  }



























  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
