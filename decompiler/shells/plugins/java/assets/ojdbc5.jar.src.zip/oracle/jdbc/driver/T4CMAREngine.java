package oracle.jdbc.driver;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicReference;
import oracle.jdbc.internal.OracleConnection;
import oracle.net.ns.BreakNetException;
import oracle.net.ns.Communication;
import oracle.net.ns.NetException;
import oracle.net.ns.NetInputStream;
import oracle.net.ns.NetOutputStream;









































































































class T4CMAREngine
{
  static final int TTCC_MXL = 252;
  static final int TTCC_ESC = 253;
  static final int TTCC_LNG = 254;
  static final int TTCC_ERR = 255;
  static final int TTCC_MXIN = 64;
  static final byte TTCLXMULTI = 1;
  static final byte TTCLXMCONV = 2;
  T4CTypeRep types;
  Communication net;
  DBConversion conv;
  short proSvrVer;
  NetInputStream inStream;
  NetOutputStream outStream;
  final byte[] ignored = new byte[255];
  final byte[] tmpBuffer1 = new byte[1];
  final byte[] tmpBuffer2 = new byte[2];
  final byte[] tmpBuffer3 = new byte[3];
  final byte[] tmpBuffer4 = new byte[4];
  final byte[] tmpBuffer5 = new byte[5];
  final byte[] tmpBuffer6 = new byte[6];
  final byte[] tmpBuffer7 = new byte[7];
  final byte[] tmpBuffer8 = new byte[8];
  final int[] retLen = new int[1];

  
  AtomicReference<OracleConnection> connForException = new AtomicReference<OracleConnection>();



  
  ArrayList refVector;




  
  static String toHex(long paramLong, int paramInt) {
    String str;
    switch (paramInt) {

      
      case 1:
        str = "00" + Long.toString(paramLong & 0xFFL, 16);








































        
        return "0x" + str.substring(str.length() - 2 * paramInt);case 2: str = "0000" + Long.toString(paramLong & 0xFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 3: str = "000000" + Long.toString(paramLong & 0xFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 4: str = "00000000" + Long.toString(paramLong & 0xFFFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 5: str = "0000000000" + Long.toString(paramLong & 0xFFFFFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 6: str = "000000000000" + Long.toString(paramLong & 0xFFFFFFFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 7: str = "00000000000000" + Long.toString(paramLong & 0xFFFFFFFFFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);
      case 8:
        return toHex(paramLong >> 32L, 4) + toHex(paramLong, 4).substring(2);
    } 
    return "more than 8 bytes"; } static String toHex(byte paramByte) {
    String str = "00" + Integer.toHexString(paramByte & 0xFF);
    return "0x" + str.substring(str.length() - 2);
  }

  
  static String toHex(short paramShort) {
    return toHex(paramShort, 2);
  }

  
  static String toHex(int paramInt) {
    return toHex(paramInt, 4);
  }

  
  static String toHex(byte[] paramArrayOfbyte, int paramInt) {
    if (paramArrayOfbyte == null) {
      return "null";
    }
    if (paramInt > paramArrayOfbyte.length) {
      return "byte array not long enough";
    }
    String str = "[";
    int i = Math.min(64, paramInt);
    
    for (byte b = 0; b < i; b++)
    {
      str = str + toHex(paramArrayOfbyte[b]) + " ";
    }
    
    if (i < paramInt) {
      str = str + "...";
    }
    return str + "]";
  }

  
  static String toHex(byte[] paramArrayOfbyte) {
    if (paramArrayOfbyte == null) {
      return "null";
    }
    return toHex(paramArrayOfbyte, paramArrayOfbyte.length);
  }



  
  T4CMAREngine(Communication paramCommunication) throws SQLException, IOException {
    this(paramCommunication, false);
  }














































  
  void initBuffers() {}














































  
  final void marshalSB1(byte paramByte) throws IOException {
    try {
      marshalSB2((short)paramByte);
    } finally {}
  }













  
  final void marshalUB1(short paramShort) throws IOException {
    try {
      this.outStream.write((byte)(paramShort & 0xFF));
    } finally {}
  }
















  
  final void marshalSB2(short paramShort) throws IOException {
    byte b = value2Buffer(paramShort, this.tmpBuffer2, (byte)1);
    
    if (b != 0) {
      
      try {
        
        this.outStream.write(this.tmpBuffer2, 0, b);
      } finally {}
    }
  }












  
  final void marshalUB2(int paramInt) throws IOException {
    marshalSB2((short)(paramInt & 0xFFFF));
  }













  
  final void marshalSB4(int paramInt) throws IOException {
    byte b = value2Buffer(paramInt, this.tmpBuffer4, (byte)2);

    
    if (b != 0) {
      
      try {
        
        this.outStream.write(this.tmpBuffer4, 0, b);
      } finally {}
    }
  }











  
  final void marshalUB4(long paramLong) throws IOException {
    marshalSB4((int)(paramLong & 0xFFFFFFFFFFFFFFFFL));
  }












  
  final void marshalSB8(long paramLong) throws IOException {
    byte b = value2Buffer(paramLong, this.tmpBuffer8, (byte)3);

    
    if (b != 0) {
      
      try {
        
        this.outStream.write(this.tmpBuffer8, 0, b);
      } finally {}
    }
  }











  
  final void marshalSWORD(int paramInt) throws IOException {
    marshalSB4(paramInt);
  }








  
  final void marshalUWORD(long paramLong) throws IOException {
    marshalSB4((int)(paramLong & 0xFFFFFFFFFFFFFFFFL));
  }









  
  final void marshalB1Array(byte[] paramArrayOfbyte) throws IOException {
    if (paramArrayOfbyte.length > 0) {
      
      try {
        
        this.outStream.write(paramArrayOfbyte);
      } finally {}
    }
  }















  
  final void marshalB1Array(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
    if (paramArrayOfbyte.length > 0) {
      
      try {
        
        this.outStream.write(paramArrayOfbyte, paramInt1, paramInt2);
      } finally {}
    }
  }











  
  final void marshalUB4Array(long[] paramArrayOflong) throws IOException {
    for (byte b = 0; b < paramArrayOflong.length; b++) {
      marshalSB4((int)(paramArrayOflong[b] & 0xFFFFFFFFFFFFFFFFL));
    }
  }





































  
  final void marshalO2U(boolean paramBoolean) throws IOException {
    if (paramBoolean) {
      addPtr((byte)1);
    } else {
      addPtr((byte)0);
    } 
  }











  
  final void marshalNULLPTR() throws IOException {
    addPtr((byte)0);
  }














  
  final void marshalPTR() throws IOException {
    addPtr((byte)1);
  }











  
  final void marshalCHR(byte[] paramArrayOfbyte) throws IOException {
    marshalCHR(paramArrayOfbyte, 0, paramArrayOfbyte.length);
  }





  
  final void marshalCHR(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
    if (paramInt2 > 0)
    {
      if (this.types.isConvNeeded()) {
        marshalCLR(paramArrayOfbyte, paramInt1, paramInt2);
      } else {

        
        try {
          this.outStream.write(paramArrayOfbyte, paramInt1, paramInt2);
        } finally {}
      } 
    }
  }












  
  final void marshalCLR(byte[] paramArrayOfbyte, int paramInt) throws IOException {
    marshalCLR(paramArrayOfbyte, 0, paramInt);
  }







  
  final void marshalCLR(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
    try {
      if (paramInt2 > 64) {
        
        int i = 0;

        
        this.outStream.write(-2);

        
        do {
          int j = paramInt2 - i;
          byte b = (j > 64) ? 64 : j;

          
          this.outStream.write((byte)(b & 0xFF));
          this.outStream.write(paramArrayOfbyte, paramInt1 + i, b);

          
          i += b;
        }
        while (i < paramInt2);
        
        this.outStream.write(0);
      }
      else {
        
        this.outStream.write((byte)(paramInt2 & 0xFF));





        
        if (paramArrayOfbyte.length != 0) {
          this.outStream.write(paramArrayOfbyte, paramInt1, paramInt2);
        }
      } 
    } finally {}
  }











  
  final void marshalKEYVAL(byte[][] paramArrayOfbyte1, int[] paramArrayOfint1, byte[][] paramArrayOfbyte2, int[] paramArrayOfint2, byte[] paramArrayOfbyte, int paramInt) throws IOException {
    for (byte b = 0; b < paramInt; b++) {
      
      if (paramArrayOfbyte1[b] != null && paramArrayOfint1[b] > 0) {
        
        marshalUB4(paramArrayOfint1[b]);
        marshalCLR(paramArrayOfbyte1[b], 0, paramArrayOfint1[b]);
      } else {
        
        marshalUB4(0L);
      } 
      if (paramArrayOfbyte2[b] != null && paramArrayOfint2[b] > 0) {
        
        marshalUB4(paramArrayOfint2[b]);
        marshalCLR(paramArrayOfbyte2[b], 0, paramArrayOfint2[b]);
      } else {
        
        marshalUB4(0L);
      } 
      
      if (paramArrayOfbyte[b] != 0) {
        marshalUB4(1L);
      } else {
        marshalUB4(0L);
      } 
    } 
  }





  
  final void marshalKEYVAL(byte[][] paramArrayOfbyte1, byte[][] paramArrayOfbyte2, byte[] paramArrayOfbyte, int paramInt) throws IOException {
    int[] arrayOfInt1 = new int[paramInt];
    int[] arrayOfInt2 = new int[paramInt];
    for (byte b = 0; b < paramInt; b++) {
      
      if (paramArrayOfbyte1[b] != null)
        arrayOfInt1[b] = (paramArrayOfbyte1[b]).length; 
      if (paramArrayOfbyte2[b] != null)
        arrayOfInt2[b] = (paramArrayOfbyte2[b]).length; 
    } 
    marshalKEYVAL(paramArrayOfbyte1, arrayOfInt1, paramArrayOfbyte2, arrayOfInt2, paramArrayOfbyte, paramInt);
  }














  
  final void marshalDALC(byte[] paramArrayOfbyte) throws IOException {
    if (paramArrayOfbyte == null || paramArrayOfbyte.length < 1) {

      
      try {
        this.outStream.write(0);
      
      }
      finally {}
    
    }
    else {
      
      marshalSB4(0xFFFFFFFF & paramArrayOfbyte.length);
      marshalCLR(paramArrayOfbyte, paramArrayOfbyte.length);
    } 
  }







  
  final void marshalKPDKV(byte[][] paramArrayOfbyte1, byte[][] paramArrayOfbyte2, int[] paramArrayOfint) throws IOException {
    for (byte b = 0; b < paramArrayOfbyte1.length; b++) {
      
      if (paramArrayOfbyte1[b] != null) {
        
        marshalUB4((paramArrayOfbyte1[b]).length);
        marshalCLR(paramArrayOfbyte1[b], 0, (paramArrayOfbyte1[b]).length);
      } else {
        
        marshalUB4(0L);
      }  if (paramArrayOfbyte2[b] != null) {
        
        marshalUB4((paramArrayOfbyte2[b]).length);
        marshalCLR(paramArrayOfbyte2[b], 0, (paramArrayOfbyte2[b]).length);
      } else {
        
        marshalUB4(0L);
      }  marshalUB2(paramArrayOfint[b]);
    } 
  }







  
  final void unmarshalKPDKV(byte[][] paramArrayOfbyte1, int[] paramArrayOfint1, byte[][] paramArrayOfbyte2, int[] paramArrayOfint2) throws IOException, SQLException {
    int i = 0;
    int[] arrayOfInt = new int[1];
    
    for (byte b = 0; b < paramArrayOfbyte1.length; b++) {
      
      i = (int)unmarshalUB4();
      if (i > 0) {
        
        paramArrayOfbyte1[b] = new byte[i];
        unmarshalCLR(paramArrayOfbyte1[b], 0, arrayOfInt, i);
        paramArrayOfint1[b] = arrayOfInt[0];
      } 
      i = (int)unmarshalUB4();
      if (i > 0) {
        
        paramArrayOfbyte2[b] = new byte[i];
        unmarshalCLR(paramArrayOfbyte2[b], 0, arrayOfInt, i);
      } 
      paramArrayOfint2[b] = unmarshalUB2();
    } 
  }

















  
  final void addPtr(byte paramByte) throws IOException {
    try {
      if ((this.types.rep[4] & 0x1) > 0) {
        this.outStream.write(paramByte);
      
      }
      else {

        
        byte b = value2Buffer(paramByte, this.tmpBuffer4, (byte)4);

        
        if (b != 0) {
          this.outStream.write(this.tmpBuffer4, 0, b);
        }
      } 
    } finally {}
  }




















  
  final byte value2Buffer(int paramInt, byte[] paramArrayOfbyte, byte paramByte) throws IOException {
    boolean bool1 = ((this.types.rep[paramByte] & 0x1) > 0) ? true : false;
    boolean bool2 = true;
    byte b = 0;


    
    for (int i = paramArrayOfbyte.length - 1; i >= 0; i--) {
      
      paramArrayOfbyte[b] = (byte)(paramInt >>> 8 * i & 0xFF);


      
      if (bool1) {
        
        if (!bool2 || paramArrayOfbyte[b] != 0) {
          
          bool2 = false;
          b = (byte)(b + 1);
        } 
      } else {
        
        b = (byte)(b + 1);
      } 
    } 
    
    if (bool1) {
      
      try {
        
        this.outStream.write(b);
      } finally {}
    }






    
    if ((this.types.rep[paramByte] & 0x2) > 0) {
      reverseArray(paramArrayOfbyte, b);
    }
    return b;
  }





  
  final byte value2Buffer(long paramLong, byte[] paramArrayOfbyte, byte paramByte) throws IOException {
    boolean bool1 = ((this.types.rep[paramByte] & 0x1) > 0) ? true : false;
    boolean bool2 = true;
    byte b = 0;


    
    for (int i = paramArrayOfbyte.length - 1; i >= 0; i--) {
      
      paramArrayOfbyte[b] = (byte)(int)(paramLong >>> 8 * i & 0xFFL);


      
      if (bool1) {
        
        if (!bool2 || paramArrayOfbyte[b] != 0) {
          
          bool2 = false;
          b = (byte)(b + 1);
        } 
      } else {
        
        b = (byte)(b + 1);
      } 
    } 
    
    if (bool1) {
      
      try {
        
        this.outStream.write(b);
      } finally {}
    }






    
    if ((this.types.rep[paramByte] & 0x2) > 0) {
      reverseArray(paramArrayOfbyte, b);
    }
    return b;
  }











  
  final void reverseArray(byte[] paramArrayOfbyte, byte paramByte) {
    int i = paramByte / 2;
    
    for (byte b = 0; b < i; b++) {
      
      byte b1 = paramArrayOfbyte[b];
      paramArrayOfbyte[b] = paramArrayOfbyte[paramByte - 1 - b];
      paramArrayOfbyte[paramByte - 1 - b] = b1;
    } 
  }



































  
  final byte unmarshalSB1() throws SQLException, IOException {
    return (byte)unmarshalSB2();
  }















  
  final short unmarshalUB1() throws SQLException, IOException {
    short s = 0;


    
    try {
      s = (short)this.inStream.read();
    
    }
    catch (BreakNetException breakNetException) {

      
      this.net.sendReset();
      throw breakNetException;
    } finally {}





    
    if (s < 0) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 






    
    return s;
  }














  
  final short unmarshalSB2() throws SQLException, IOException {
    return (short)unmarshalUB2();
  }


















  
  final int unmarshalUB2() throws SQLException, IOException {
    int i = (int)buffer2Value((byte)1);






    
    return i & 0xFFFF;
  }














  
  final int unmarshalUCS2(byte[] paramArrayOfbyte, long paramLong) throws SQLException, IOException {
    int i = unmarshalUB2();
    
    this.tmpBuffer2[0] = (byte)((i & 0xFF00) >> 8);
    this.tmpBuffer2[1] = (byte)(i & 0xFF);

    
    if (paramLong + 1L < paramArrayOfbyte.length) {


      
      paramArrayOfbyte[(int)paramLong] = this.tmpBuffer2[0];
      paramArrayOfbyte[(int)paramLong + 1] = this.tmpBuffer2[1];
    } 























    
    return (this.tmpBuffer2[0] == 0) ? ((this.tmpBuffer2[1] == 0) ? 1 : 2) : 3;
  }














  
  final int unmarshalSB4() throws SQLException, IOException {
    return (int)unmarshalUB4();
  }


















  
  final long unmarshalUB4() throws SQLException, IOException {
    return buffer2Value((byte)2);
  }





















  
  final int unmarshalSB4(byte[] paramArrayOfbyte) throws SQLException, IOException {
    long l = buffer2Value((byte)2, new ByteArrayInputStream(paramArrayOfbyte));
    
    return (int)l;
  }

















  
  final long unmarshalSB8() throws SQLException, IOException {
    return buffer2Value((byte)3);
  }







  
  final int unmarshalRefCursor(byte[] paramArrayOfbyte) throws SQLException, IOException {
    return unmarshalSB4(paramArrayOfbyte);
  }

















  
  int unmarshalSWORD() throws SQLException, IOException {
    return (int)unmarshalUB4();
  }
















  
  long unmarshalUWORD() throws SQLException, IOException {
    return unmarshalUB4();
  }














  
  byte[] unmarshalNBytes(int paramInt) throws SQLException, IOException {
    byte[] arrayOfByte = new byte[paramInt];
    
    if (paramInt > 0) {
      
      try {

        
        if (this.inStream.read(arrayOfByte) < 0)
        {

          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
          sQLException.fillInStackTrace();
          throw sQLException;
        
        }

      
      }
      catch (BreakNetException breakNetException) {

        
        this.net.sendReset();
        throw breakNetException;
      } finally {}
    }



    
    return arrayOfByte;
  }















  
  int unmarshalNBytes(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException, IOException {
    if (paramInt1 + paramInt2 > paramArrayOfbyte.length)
    {
      paramInt2 = paramArrayOfbyte.length - paramInt1;
    }
    
    int i = 0;
    
    while (i < paramInt2) {
      i += getNBytes(paramArrayOfbyte, paramInt1 + i, paramInt2 - i);
    }
    return i;
  }















  
  int getNBytes(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException, IOException {
    if (paramInt1 + paramInt2 > paramArrayOfbyte.length)
    {
      paramInt2 = paramArrayOfbyte.length - paramInt1;
    }
    
    int i = 0;



    
    try {
      if ((i = this.inStream.read(paramArrayOfbyte, paramInt1, paramInt2)) < 0)
      {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
        sQLException.fillInStackTrace();
        throw sQLException;
      
      }

    
    }
    catch (BreakNetException breakNetException) {


      
      this.net.sendReset();
      throw breakNetException;
    } finally {}




    
    return i;
  }












  
  byte[] getNBytes(int paramInt) throws SQLException, IOException {
    byte[] arrayOfByte = new byte[paramInt];



    
    try {
      if (this.inStream.read(arrayOfByte) < 0)
      {


        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
        sQLException.fillInStackTrace();
        throw sQLException;
      
      }

    
    }
    catch (BreakNetException breakNetException) {


      
      this.net.sendReset();
      throw breakNetException;
    } finally {}




    
    return arrayOfByte;
  }
















  
  byte[] unmarshalTEXT(int paramInt) throws SQLException, IOException {
    byte[] arrayOfByte2;
    byte b = 0;


    
    byte[] arrayOfByte1 = new byte[paramInt];

    
    while (b < paramInt) {

      
      try {

        
        if (this.inStream.read(arrayOfByte1, b, 1) < 0)
        {


          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
          sQLException.fillInStackTrace();
          throw sQLException;
        
        }

      
      }
      catch (BreakNetException breakNetException) {


        
        this.net.sendReset();
        throw breakNetException;
      } finally {}




      
      if (arrayOfByte1[b++] == 0) {
        break;
      }
    } 
    
    if (arrayOfByte1.length == --b) {
      
      arrayOfByte2 = arrayOfByte1;
    }
    else {
      
      arrayOfByte2 = new byte[b];
      
      System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, b);
    } 
    
    return arrayOfByte2;
  }















  
  byte[] unmarshalCHR(int paramInt) throws SQLException, IOException {
    byte[] arrayOfByte = null;
    
    if (this.types.isConvNeeded()) {
      
      arrayOfByte = unmarshalCLR(paramInt, this.retLen);
      
      if (arrayOfByte.length != this.retLen[0])
      {
        byte[] arrayOfByte1 = new byte[this.retLen[0]];
        
        System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, this.retLen[0]);
        
        arrayOfByte = arrayOfByte1;
      }
    
    } else {
      
      arrayOfByte = getNBytes(paramInt);
    } 
    
    return arrayOfByte;
  }





  
  void unmarshalCLR(byte[] paramArrayOfbyte, int paramInt, int[] paramArrayOfint) throws SQLException, IOException {
    unmarshalCLR(paramArrayOfbyte, paramInt, paramArrayOfint, 2147483647);
  }



  
  void unmarshalCLR(byte[] paramArrayOfbyte, int paramInt1, int[] paramArrayOfint, int paramInt2) throws SQLException, IOException {
    unmarshalCLR(paramArrayOfbyte, paramInt1, paramArrayOfint, paramInt2, 0);
  }



















  
  void unmarshalCLR(byte[] paramArrayOfbyte, int paramInt1, int[] paramArrayOfint, int paramInt2, int paramInt3) throws SQLException, IOException {
    int i = 0;
    int j = 0;
    int k = paramInt1;
    boolean bool = false;
    int m = 0;
    int n = 0;
    int i1 = 0;




    
    byte b = -1;
    
    i = unmarshalUB1();

    
    if (i < 0) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    if (i == 0) {
      
      paramArrayOfint[0] = 0;
      
      return;
    } 
    if (escapeSequenceNull(i)) {
      
      paramArrayOfint[0] = 0;
      
      return;
    } 
    if (i != 254) {
      
      if (paramInt3 - i1 >= i) {

        
        unmarshalBuffer(this.ignored, 0, i);
        i1 += i;
        
        i = 0;
      }
      else if (paramInt3 - i1 > 0) {


        
        unmarshalBuffer(this.ignored, 0, paramInt3 - i1);
        
        i -= paramInt3 - i1;
        i1 += paramInt3 - i1;
      } 
      
      if (i > 0) {

        
        n = Math.min(paramInt2 - m, i);
        k = unmarshalBuffer(paramArrayOfbyte, k, n);
        m += n;

        
        int i2 = i - n;
        
        if (i2 > 0) {
          unmarshalBuffer(this.ignored, 0, i2);
        }
      } 
    } else {
      
      b = -1;




      
      while (true) {
        if (b != -1) {
          
          i = unmarshalUB1();

          
          if (i <= 0) {
            break;
          }
        } 
        if (i == 254)
        {
          switch (b) {

            
            case -1:
              b = 1;
              continue;

            
            case 1:
              b = 0;
              break;

            
            case 0:
              if (bool) {
                
                b = 0;

                
                break;
              } 
              
              b = 0;
              continue;
          } 

        
        }
        if (k == -1) {
          
          unmarshalBuffer(this.ignored, 0, i);
        
        }
        else {
          
          j = i;
          if (paramInt3 - i1 >= j) {

            
            unmarshalBuffer(this.ignored, 0, j);
            i1 += j;
            
            j = 0;
          }
          else if (paramInt3 - i1 > 0) {


            
            unmarshalBuffer(this.ignored, 0, paramInt3 - i1);
            
            j -= paramInt3 - i1;
            i1 += paramInt3 - i1;
          } 
          
          if (j > 0) {

            
            n = Math.min(paramInt2 - m, j);
            k = unmarshalBuffer(paramArrayOfbyte, k, n);
            m += n;

            
            int i2 = j - n;
            
            if (i2 > 0) {
              unmarshalBuffer(this.ignored, 0, i2);
            }
          } 
        } 
        
        b = 0;
        
        if (i > 252) {
          bool = true;
        }
      } 
    } 

    
    if (paramArrayOfint != null)
    {
      if (k != -1) {
        paramArrayOfint[0] = m;
      } else {
        
        paramArrayOfint[0] = paramArrayOfbyte.length - paramInt1;
      } 
    }
  }








  
  final byte[] unmarshalCLR(int paramInt, int[] paramArrayOfint) throws SQLException, IOException {
    byte[] arrayOfByte = new byte[paramInt * this.conv.c2sNlsRatio];
    
    unmarshalCLR(arrayOfByte, 0, paramArrayOfint, paramInt);
    return arrayOfByte;
  }






































  
  final int[] unmarshalKEYVAL(byte[][] paramArrayOfbyte1, byte[][] paramArrayOfbyte2, int paramInt) throws SQLException, IOException {
    byte[] arrayOfByte = new byte[1000];
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[paramInt];

    
    for (byte b = 0; b < paramInt; b++) {
      
      int i = unmarshalSB4();
      
      if (i > 0) {
        
        unmarshalCLR(arrayOfByte, 0, arrayOfInt1);
        
        paramArrayOfbyte1[b] = new byte[arrayOfInt1[0]];
        
        System.arraycopy(arrayOfByte, 0, paramArrayOfbyte1[b], 0, arrayOfInt1[0]);
      } 
      
      i = unmarshalSB4();
      
      if (i > 0) {
        
        unmarshalCLR(arrayOfByte, 0, arrayOfInt1);
        
        paramArrayOfbyte2[b] = new byte[arrayOfInt1[0]];
        
        System.arraycopy(arrayOfByte, 0, paramArrayOfbyte2[b], 0, arrayOfInt1[0]);
      } 
      
      arrayOfInt2[b] = unmarshalSB4();
    } 
    
    arrayOfByte = null;

    
    return arrayOfInt2;
  }





  
  final int unmarshalBuffer(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException, IOException {
    if (paramInt2 <= 0) {
      return paramInt1;
    }
    if (paramArrayOfbyte.length < paramInt1 + paramInt2) {
      
      unmarshalNBytes(paramArrayOfbyte, paramInt1, paramArrayOfbyte.length - paramInt1);

      
      unmarshalNBytes(this.ignored, 0, paramInt1 + paramInt2 - paramArrayOfbyte.length);
      
      paramInt1 = -1;
    
    }
    else {

      
      unmarshalNBytes(paramArrayOfbyte, paramInt1, paramInt2);
      
      paramInt1 += paramInt2;
    } 
    return paramInt1;
  }

  
  T4CMAREngine(Communication paramCommunication, boolean paramBoolean) throws SQLException, IOException {
    this.refVector = null; if (paramCommunication == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 433); sQLException.fillInStackTrace(); throw sQLException; }
     this.net = paramCommunication; try { if (paramBoolean) { this.outStream = paramCommunication.getNetOutputStream(); this.inStream = paramCommunication.getNetInputStream(); }
      else { this.outStream = new T4CSocketOutputStreamWrapper((NetOutputStream)paramCommunication.getOutputStream()); this.inStream = new T4CSocketInputStreamWrapper((NetInputStream)paramCommunication.getInputStream(), (T4CSocketOutputStreamWrapper)this.outStream); }
       }
    catch (NetException netException) { throw new IOException(netException.getMessage()); }
     this.types = new T4CTypeRep(); this.types.setRep((byte)1, (byte)2); } final byte[] unmarshalCLRforREFS() throws SQLException, IOException { short s1 = 0;
    short s2 = 0;
    byte[] arrayOfByte = null;

    
    short s = unmarshalUB1();


    
    if (s < 0) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    if (s == 0)
    {
      return null;
    }

    
    boolean bool = escapeSequenceNull(s);
    if (!bool)
    {
      if (this.refVector == null) {
        this.refVector = new ArrayList(10);
      } else {
        this.refVector.clear();
      } 
    }
    if (!bool) {
      
      if (s == 254) {


        
        while ((s1 = unmarshalUB1()) > 0)
        {



          
          if (s1 == 254)
          {
            if (this.types.isServerConversion()) {
              continue;
            }
          }
          s2 = (short)(s2 + s1);
          byte[] arrayOfByte1 = new byte[s1];
          
          unmarshalBuffer(arrayOfByte1, 0, s1);
          this.refVector.add(arrayOfByte1);
        }
      
      } else {
        
        s2 = s;
        
        byte[] arrayOfByte1 = new byte[s];
        
        unmarshalBuffer(arrayOfByte1, 0, s);
        this.refVector.add(arrayOfByte1);
      } 

      
      arrayOfByte = new byte[s2];
      
      int i = 0;
      
      while (this.refVector.size() > 0)
      {
        int j = ((byte[])this.refVector.get(0)).length;
        
        System.arraycopy(this.refVector.get(0), 0, arrayOfByte, i, j);

        
        i += j;


        
        this.refVector.remove(0);
      }
    
    }
    else {
      
      arrayOfByte = null;
    } 
    return arrayOfByte; }









  
  final boolean escapeSequenceNull(int paramInt) throws SQLException {
    SQLException sQLException;
    boolean bool = false;
    
    switch (paramInt) {



      
      case 0:
        bool = true;
        break;



      
      case 253:
        sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
        sQLException.fillInStackTrace();
        throw sQLException;







      
      case 255:
        bool = true;
        break;
    } 














    
    return bool;
  }









  
  final int processIndicator(boolean paramBoolean, int paramInt) throws SQLException, IOException {
    short s = unmarshalSB2();
    int i = 0;
    
    if (!paramBoolean)
    {
      if (s == 0) {
        i = paramInt;
      } else if (s == -2 || s > 0) {
        i = s;
      }
      else {
        
        i = 65536 + s;
      }  } 
    return i;
  }



























  
  final long unmarshalDALC(byte[] paramArrayOfbyte, int paramInt, int[] paramArrayOfint) throws SQLException, IOException {
    long l = unmarshalUB4();
    
    if (l > 0L)
      unmarshalCLR(paramArrayOfbyte, paramInt, paramArrayOfint); 
    return l;
  }




  
  final byte[] unmarshalDALC() throws SQLException, IOException {
    long l = unmarshalUB4();
    byte[] arrayOfByte = new byte[(int)(0xFFFFFFFFFFFFFFFFL & l)];
    
    if (arrayOfByte.length > 0) {
      
      arrayOfByte = unmarshalCLR(arrayOfByte.length, this.retLen);
      
      if (arrayOfByte == null)
      {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
        sQLException.fillInStackTrace();
        throw sQLException;
      }
    
    } else {
      
      arrayOfByte = new byte[0];
    }  return arrayOfByte;
  }




  
  final byte[] unmarshalDALC(int[] paramArrayOfint) throws SQLException, IOException {
    long l = unmarshalUB4();
    byte[] arrayOfByte = new byte[(int)(0xFFFFFFFFFFFFFFFFL & l)];

    
    if (arrayOfByte.length > 0) {
      
      arrayOfByte = unmarshalCLR(arrayOfByte.length, paramArrayOfint);
      
      if (arrayOfByte == null)
      {


        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
        sQLException.fillInStackTrace();
        throw sQLException;
      }
    
    } else {
      
      arrayOfByte = new byte[0];
    }  return arrayOfByte;
  }
























  
  final long buffer2Value(byte paramByte) throws SQLException, IOException {
    long l = 0L;
    int i = 1;

    
    try {
      if ((this.types.rep[paramByte] & 0x1) > 0) {
        
        i = this.inStream.readB1();
      } else {
        
        switch (paramByte) {
          
          case 1:
            i = 2;
            break;
          case 2:
            i = 4;
            break;
          case 3:
            i = 8;
            break;
        } 
      
      } 
      if ((this.types.rep[paramByte] & 0x2) > 0) {
        l = this.inStream.readLongLSB(i);
      } else {
        l = this.inStream.readLongMSB(i);
      } 
      return l;
    }
    catch (BreakNetException breakNetException) {

      
      this.net.sendReset();
      throw breakNetException;
    } 
  }




















  
  final long buffer2Value(byte paramByte, ByteArrayInputStream paramByteArrayInputStream) throws SQLException, IOException {
    int i = 0;
    
    long l = 0L;
    boolean bool = false;

    
    if ((this.types.rep[paramByte] & 0x1) > 0) {
      
      i = paramByteArrayInputStream.read();

      
      if ((i & 0x80) > 0) {
        
        i &= 0x7F;
        bool = true;
      } 
      
      if (i < 0) {



        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 




      
      if (i == 0)
      {
        
        return 0L;
      }

      
      if ((paramByte == 1 && i > 2) || (paramByte == 2 && i > 4))
      {



        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 412);
        sQLException.fillInStackTrace();
        throw sQLException;

      
      }

    
    }
    else if (paramByte == 1) {
      i = 2;
    } else if (paramByte == 2) {
      i = 4;
    } 





    
    byte[] arrayOfByte = new byte[i];
    
    if (paramByteArrayInputStream.read(arrayOfByte) < 0) {



      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    for (byte b = 0; b < arrayOfByte.length; b++) {
      short s;
      
      if ((this.types.rep[paramByte] & 0x2) > 0) {
        s = (short)(arrayOfByte[arrayOfByte.length - 1 - b] & 0xFF);
      } else {
        s = (short)(arrayOfByte[b] & 0xFF);
      } 
      l |= (s << 8 * (arrayOfByte.length - 1 - b));
    } 

    
    l &= 0xFFFFFFFFFFFFFFFFL;
    
    if (bool) {
      l = -l;
    }
    return l;
  }











  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return this.connForException.get();
  }







  
  protected void setConnectionDuringExceptionHandling(OracleConnection paramOracleConnection) {
    this.connForException.set(paramOracleConnection);
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
