package oracle.jdbc.driver;

import java.io.IOException;
import java.net.BindException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.channels.ServerSocketChannel;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Hashtable;
import oracle.jdbc.internal.OracleConnection;








































class NTFManager
{
  private Hashtable<Integer, NTFListener> nsListeners = new Hashtable<Integer, NTFListener>();



  
  private Hashtable<Integer, NTFRegistration> ntfRegistrations = new Hashtable<Integer, NTFRegistration>();








  
  private byte[] listOfJdbcRegId = new byte[20];
































  
  synchronized boolean listenOnPortT4C(int[] paramArrayOfint, boolean paramBoolean) throws SQLException {
    int i = paramArrayOfint[0];
    boolean bool = false;


    
    while (this.nsListeners.get(Integer.valueOf(i)) == null) {

      
      try {



        
        ServerSocketChannel serverSocketChannel = ServerSocketChannel.open();
        serverSocketChannel.configureBlocking(false);
        
        ServerSocket serverSocket = serverSocketChannel.socket();
        
        InetSocketAddress inetSocketAddress = new InetSocketAddress(i);

        
        try {
          serverSocket.bind(inetSocketAddress);
          
          bool = true;
          NTFListener nTFListener = new NTFListener(this, serverSocketChannel, i);
          this.nsListeners.put(Integer.valueOf(i), nTFListener);
          nTFListener.start();
          
          break;
        } catch (BindException bindException) {
          
          if (!paramBoolean) {
            
            SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 250);
            sQLException.fillInStackTrace();
            throw sQLException;
          } 
          
          i++;
        }
        catch (IOException iOException) {
          
          if (!paramBoolean) {
            
            SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 250);
            sQLException.fillInStackTrace();
            throw sQLException;
          } 
          
          i++;
        }
      
      } catch (IOException iOException) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    } 
    
    paramArrayOfint[0] = i;
    return bool;
  }







  
  synchronized int getNextJdbcRegId() {
    byte b = 1;
    for (; b < this.listOfJdbcRegId.length; b++) {
      
      if (this.listOfJdbcRegId[b] == 0)
        break; 
    } 
    if (b == this.listOfJdbcRegId.length - 1) {
      
      byte[] arrayOfByte = new byte[this.listOfJdbcRegId.length * 2];
      System.arraycopy(this.listOfJdbcRegId, 0, arrayOfByte, 0, this.listOfJdbcRegId.length);
      this.listOfJdbcRegId = arrayOfByte;
    } 
    this.listOfJdbcRegId[b] = 2;
    return b;
  }






  
  synchronized void addRegistration(NTFRegistration paramNTFRegistration) {
    Integer integer = Integer.valueOf(paramNTFRegistration.getJdbcRegId());
    Hashtable<Integer, NTFRegistration> hashtable = (Hashtable)this.ntfRegistrations.clone();
    hashtable.put(integer, paramNTFRegistration);





    
    this.ntfRegistrations = hashtable;
  }








  
  synchronized boolean removeRegistration(NTFRegistration paramNTFRegistration) {
    Integer integer = Integer.valueOf(paramNTFRegistration.getJdbcRegId());
    Hashtable<Integer, NTFRegistration> hashtable = (Hashtable)this.ntfRegistrations.clone();
    Object object = hashtable.remove(integer);





    
    this.ntfRegistrations = hashtable;



    
    boolean bool = false;
    
    if (object != null)
      bool = true; 
    return bool;
  }




  
  synchronized void freeJdbcRegId(int paramInt) {
    if (this.listOfJdbcRegId != null && this.listOfJdbcRegId.length > paramInt) {
      this.listOfJdbcRegId[paramInt] = 0;
    }
  }














  
  synchronized void cleanListenersT4C(int paramInt) {
    Enumeration<Integer> enumeration = this.ntfRegistrations.keys();
    boolean bool = false;
    while (!bool && enumeration.hasMoreElements()) {
      
      Object object = enumeration.nextElement();
      NTFRegistration nTFRegistration = this.ntfRegistrations.get(object);
      if (nTFRegistration.getClientTCPPort() == paramInt)
        bool = true; 
    } 
    if (!bool) {
      
      NTFListener nTFListener = this.nsListeners.get(Integer.valueOf(paramInt));
      if (nTFListener != null) {
        
        nTFListener.closeThisListener();
        nTFListener.interrupt();
        this.nsListeners.remove(Integer.valueOf(paramInt));
      } 
    } 
  }










  
  NTFRegistration getRegistration(int paramInt) {
    Integer integer = Integer.valueOf(paramInt);
    
    Hashtable<Integer, NTFRegistration> hashtable = this.ntfRegistrations;
    return hashtable.get(integer);
  }












  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
