package oracle.jdbc.xa;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Vector;

















public class OracleMultiPhaseArgs
{
  int action = 0;
  int nsites = 0;
  Vector dbLinks = null;
  Vector xids = null;





  
  public OracleMultiPhaseArgs() {}




  
  public OracleMultiPhaseArgs(int paramInt1, int paramInt2, Vector paramVector1, Vector paramVector2) {
    if (paramInt2 <= 1) {
      
      this.action = 0;
      this.nsites = 0;
      this.dbLinks = null;
      this.xids = null;



    
    }
    else if (!paramVector1.isEmpty() && !paramVector2.isEmpty() && paramVector2.size() == paramInt2 && paramVector1.size() == 3 * paramInt2) {





      
      this.action = paramInt1;
      this.nsites = paramInt2;
      this.xids = paramVector1;
      this.dbLinks = paramVector2;
    } 
  }








  
  public OracleMultiPhaseArgs(byte[] paramArrayOfbyte) {
    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(paramArrayOfbyte);
    DataInputStream dataInputStream = new DataInputStream(byteArrayInputStream);
    
    this.xids = new Vector();
    this.dbLinks = new Vector();

    
    try {
      this.action = dataInputStream.readInt();
      this.nsites = dataInputStream.readInt();
      
      int i = dataInputStream.readInt();
      int j = dataInputStream.readInt();
      byte[] arrayOfByte = new byte[j];
      int k = dataInputStream.read(arrayOfByte, 0, j);
      
      for (byte b = 0; b < this.nsites; b++)
      {
        int m = dataInputStream.readInt();
        byte[] arrayOfByte1 = new byte[m];
        int n = dataInputStream.read(arrayOfByte1, 0, m);

        
        this.xids.addElement(Integer.valueOf(i));
        this.xids.addElement(arrayOfByte);
        this.xids.addElement(arrayOfByte1);
        
        String str = dataInputStream.readUTF();

        
        this.dbLinks.addElement(str);
      }
    
    } catch (IOException iOException) {
      
      iOException.printStackTrace();
    } 
  }







  
  public byte[] toByteArray() {
    return toByteArrayOS().toByteArray();
  }


  
  public ByteArrayOutputStream toByteArrayOS() {
    byte[] arrayOfByte = null;
    int i = 0;


    
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    DataOutputStream dataOutputStream = new DataOutputStream(byteArrayOutputStream);

    
    try {
      dataOutputStream.writeInt(this.action);
      dataOutputStream.writeInt(this.nsites);
      
      for (byte b = 0; b < this.nsites; b++)
      {
        String str = this.dbLinks.elementAt(b);
        int j = ((Integer)this.xids.elementAt(b * 3)).intValue();
        byte[] arrayOfByte1 = this.xids.elementAt(b * 3 + 1);
        byte[] arrayOfByte2 = this.xids.elementAt(b * 3 + 2);
        
        if (b == 0) {
          
          i = j;
          arrayOfByte = arrayOfByte1;
          
          dataOutputStream.writeInt(j);
          dataOutputStream.writeInt(arrayOfByte1.length);
          dataOutputStream.write(arrayOfByte1, 0, arrayOfByte1.length);
        } 








        
        dataOutputStream.writeInt(arrayOfByte2.length);
        dataOutputStream.write(arrayOfByte2, 0, arrayOfByte2.length);
        dataOutputStream.writeUTF(str);
      }
    
    } catch (IOException iOException) {
      
      iOException.printStackTrace();
    } 


    
    return byteArrayOutputStream;
  }




  
  public int getAction() {
    return this.action;
  }




  
  public int getnsite() {
    return this.nsites;
  }




  
  public Vector getdbLinks() {
    return this.dbLinks;
  }




  
  public Vector getXids() {
    return this.xids;
  }









  
  public void printMPArgs() {
    for (byte b = 0; b < this.nsites; b++) {
      
      String str = this.dbLinks.elementAt(b);
      int i = ((Integer)this.xids.elementAt(b * 3)).intValue();
      byte[] arrayOfByte1 = this.xids.elementAt(b * 3 + 1);
      byte[] arrayOfByte2 = this.xids.elementAt(b * 3 + 2);


      
      printByteArray(arrayOfByte1);

      
      printByteArray(arrayOfByte2);
    } 
  }







  
  private void printByteArray(byte[] paramArrayOfbyte) {
    StringBuffer stringBuffer = new StringBuffer();
    
    for (byte b = 0; b < paramArrayOfbyte.length; b++) {
      stringBuffer.append(paramArrayOfbyte[b] + " ");
    }
  }




  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
