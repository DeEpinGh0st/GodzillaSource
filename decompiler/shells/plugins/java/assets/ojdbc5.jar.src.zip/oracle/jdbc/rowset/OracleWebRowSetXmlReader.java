package oracle.jdbc.rowset;

import javax.sql.rowset.spi.XmlReader;

public interface OracleWebRowSetXmlReader extends XmlReader {}
