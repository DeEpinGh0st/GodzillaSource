package oracle.jdbc.driver;

import java.nio.ByteBuffer;
import java.util.EnumSet;
import oracle.jdbc.dcn.RowChangeDescription;
import oracle.jdbc.dcn.TableChangeDescription;
import oracle.sql.CharacterSet;



























class NTFDCNTableChanges
  implements TableChangeDescription
{
  final EnumSet<TableChangeDescription.TableOperation> opcode;
  String tableName;
  final int objectNumber;
  final int numberOfRows;
  final RowChangeDescription.RowOperation[] rowOpcode;
  final int[] rowIdLength;
  final byte[][] rowid;
  final CharacterSet charset;
  NTFDCNRowChanges[] rowsDescription = null;
  
  private static final byte OPERATION_ANY = 0;
  
  private static final byte OPERATION_UNKNOWN = 64;

  
  NTFDCNTableChanges(ByteBuffer paramByteBuffer, int paramInt) {
    this.charset = CharacterSet.make(paramInt);
    this.opcode = TableChangeDescription.TableOperation.getTableOperations(paramByteBuffer.getInt());
    short s = paramByteBuffer.getShort();
    byte[] arrayOfByte = new byte[s];
    paramByteBuffer.get(arrayOfByte, 0, s);
    this.tableName = this.charset.toStringWithReplacement(arrayOfByte, 0, s);

    
    this.objectNumber = paramByteBuffer.getInt();
    if (!this.opcode.contains(TableChangeDescription.TableOperation.ALL_ROWS)) {
      
      this.numberOfRows = paramByteBuffer.getShort();
      this.rowOpcode = new RowChangeDescription.RowOperation[this.numberOfRows];
      this.rowIdLength = new int[this.numberOfRows];
      this.rowid = new byte[this.numberOfRows][];
      for (byte b = 0; b < this.numberOfRows; b++)
      {
        this.rowOpcode[b] = RowChangeDescription.RowOperation.getRowOperation(paramByteBuffer.getInt());
        this.rowIdLength[b] = paramByteBuffer.getShort();
        this.rowid[b] = new byte[this.rowIdLength[b]];
        paramByteBuffer.get(this.rowid[b], 0, this.rowIdLength[b]);
      }
    
    } else {
      
      this.numberOfRows = 0;
      this.rowid = (byte[][])null;
      this.rowOpcode = null;
      this.rowIdLength = null;
    } 
  }



  
  public String getTableName() {
    return this.tableName;
  }


  
  public int getObjectNumber() {
    return this.objectNumber;
  }


  
  public RowChangeDescription[] getRowChangeDescription() {
    if (this.rowsDescription == null)
    {
      synchronized (this) {
        
        if (this.rowsDescription == null) {
          
          this.rowsDescription = new NTFDCNRowChanges[this.numberOfRows];
          for (byte b = 0; b < this.rowsDescription.length; b++)
            this.rowsDescription[b] = new NTFDCNRowChanges(this.rowOpcode[b], this.rowIdLength[b], this.rowid[b]); 
        } 
      } 
    }
    return (RowChangeDescription[])this.rowsDescription;
  }


  
  public EnumSet<TableChangeDescription.TableOperation> getTableOperations() {
    return this.opcode;
  }







  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("    operation=" + getTableOperations() + ", tableName=" + this.tableName + ", objectNumber=" + this.objectNumber + "\n");
    RowChangeDescription[] arrayOfRowChangeDescription = getRowChangeDescription();
    if (arrayOfRowChangeDescription != null && arrayOfRowChangeDescription.length > 0) {
      
      stringBuffer.append("    Row Change Description (length=" + arrayOfRowChangeDescription.length + "):\n");
      for (byte b = 0; b < arrayOfRowChangeDescription.length; b++)
        stringBuffer.append(arrayOfRowChangeDescription[b].toString()); 
    } 
    return stringBuffer.toString();
  }

  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
