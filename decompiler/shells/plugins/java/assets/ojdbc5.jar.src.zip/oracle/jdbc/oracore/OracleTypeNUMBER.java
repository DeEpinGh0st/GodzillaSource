package oracle.jdbc.oracore;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.Datum;
import oracle.sql.NUMBER;



















public class OracleTypeNUMBER
  extends OracleType
  implements Serializable
{
  static final long serialVersionUID = -7182242886677299812L;
  int precision;
  int scale;
  
  protected OracleTypeNUMBER() {}
  
  protected OracleTypeNUMBER(int paramInt) {
    super(paramInt);
  }












  
  public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection) throws SQLException {
    return (Datum)toNUMBER(paramObject, paramOracleConnection);
  }










  
  public Datum[] toDatumArray(Object paramObject, OracleConnection paramOracleConnection, long paramLong, int paramInt) throws SQLException {
    return toNUMBERArray(paramObject, paramOracleConnection, paramLong, paramInt);
  }







  
  public void parseTDSrec(TDSReader paramTDSReader) throws SQLException {
    this.precision = paramTDSReader.readUnsignedByte();

    
    this.scale = paramTDSReader.readByte();
  }


  
  protected static Object unpickle81NativeArray(PickleContext paramPickleContext, long paramLong, int paramInt1, int paramInt2) throws SQLException {
    int[] arrayOfInt;
    double[] arrayOfDouble;
    long[] arrayOfLong;
    float[] arrayOfFloat;
    short[] arrayOfShort;
    byte b2;
    for (byte b1 = 1; b1 < paramLong && paramInt1 > 0; b1++) {
      paramPickleContext.skipDataValue();
    }
    byte[] arrayOfByte = null;
    
    switch (paramInt2) {






      
      case 4:
        arrayOfInt = new int[paramInt1];
        
        for (b2 = 0; b2 < paramInt1; b2++) {


















          
          if ((arrayOfByte = paramPickleContext.readDataValue()) != null) {
            arrayOfInt[b2] = NUMBER.toInt(arrayOfByte);
          }
        } 

        
        return arrayOfInt;


      
      case 5:
        arrayOfDouble = new double[paramInt1];
        
        for (b2 = 0; b2 < paramInt1; b2++) {
          
          if ((arrayOfByte = paramPickleContext.readDataValue()) != null) {
            arrayOfDouble[b2] = NUMBER.toDouble(arrayOfByte);
          }
        } 
        return arrayOfDouble;


      
      case 7:
        arrayOfLong = new long[paramInt1];
        
        for (b2 = 0; b2 < paramInt1; b2++) {
          
          if ((arrayOfByte = paramPickleContext.readDataValue()) != null) {
            arrayOfLong[b2] = NUMBER.toLong(arrayOfByte);
          }
        } 
        return arrayOfLong;


      
      case 6:
        arrayOfFloat = new float[paramInt1];
        
        for (b2 = 0; b2 < paramInt1; b2++) {
          
          if ((arrayOfByte = paramPickleContext.readDataValue()) != null) {
            arrayOfFloat[b2] = NUMBER.toFloat(arrayOfByte);
          }
        } 
        return arrayOfFloat;


      
      case 8:
        arrayOfShort = new short[paramInt1];
        
        for (b2 = 0; b2 < paramInt1; b2++) {
          
          if ((arrayOfByte = paramPickleContext.readDataValue()) != null) {
            arrayOfShort[b2] = NUMBER.toShort(arrayOfByte);
          }
        } 
        return arrayOfShort;
    } 


    
    SQLException sQLException = DatabaseError.createSqlException(null, 23);
    sQLException.fillInStackTrace();
    throw sQLException;
  }










  
  protected Object toObject(byte[] paramArrayOfbyte, int paramInt, Map paramMap) throws SQLException {
    return toNumericObject(paramArrayOfbyte, paramInt, paramMap);
  }




  
  static Object toNumericObject(byte[] paramArrayOfbyte, int paramInt, Map paramMap) throws SQLException {
    if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
      return null;
    }
    switch (paramInt) {

      
      case 1:
        return new NUMBER(paramArrayOfbyte);
      
      case 2:
        return NUMBER.toBigDecimal(paramArrayOfbyte);
      
      case 3:
        return paramArrayOfbyte;
    } 

    
    SQLException sQLException = DatabaseError.createSqlException(null, 23);
    sQLException.fillInStackTrace();
    throw sQLException;
  }










  
  public static NUMBER toNUMBER(Object paramObject, OracleConnection paramOracleConnection) throws SQLException {
    NUMBER nUMBER = null;
    
    if (paramObject != null) {
      
      try {
        
        if (paramObject instanceof NUMBER) {
          nUMBER = (NUMBER)paramObject;
        } else {
          nUMBER = new NUMBER(paramObject);
        } 
      } catch (SQLException sQLException1) {

        
        SQLException sQLException2 = DatabaseError.createSqlException(null, 59, paramObject);
        sQLException2.fillInStackTrace();
        throw sQLException2;
      } 
    }
    
    return nUMBER;
  }











  
  public static Datum[] toNUMBERArray(Object paramObject, OracleConnection paramOracleConnection, long paramLong, int paramInt) throws SQLException {
    Datum[] arrayOfDatum = null;
    
    if (paramObject != null)
    {
      if (paramObject instanceof Object[] && !(paramObject instanceof char[][])) {
        
        Object[] arrayOfObject = (Object[])paramObject;
        
        int i = (int)((paramInt == -1) ? arrayOfObject.length : Math.min(arrayOfObject.length - paramLong + 1L, paramInt));

        
        arrayOfDatum = new Datum[i];
        
        for (byte b = 0; b < i; b++) {
          arrayOfDatum[b] = (Datum)toNUMBER(arrayOfObject[(int)paramLong + b - 1], paramOracleConnection);
        }
      } else {
        arrayOfDatum = cArrayToNUMBERArray(paramObject, paramOracleConnection, paramLong, paramInt);
      }  } 
    return arrayOfDatum;
  }












  
  static Datum[] cArrayToNUMBERArray(Object paramObject, OracleConnection paramOracleConnection, long paramLong, int paramInt) throws SQLException {
    Datum[] arrayOfDatum = null;
    
    if (paramObject != null)
    {
      if (paramObject instanceof short[]) {
        
        short[] arrayOfShort = (short[])paramObject;
        int i = (int)((paramInt == -1) ? arrayOfShort.length : Math.min(arrayOfShort.length - paramLong + 1L, paramInt));

        
        arrayOfDatum = new Datum[i];
        
        for (byte b = 0; b < i; b++) {
          arrayOfDatum[b] = (Datum)new NUMBER(arrayOfShort[(int)paramLong + b - 1]);
        }
      } else if (paramObject instanceof int[]) {
        
        int[] arrayOfInt = (int[])paramObject;
        int i = (int)((paramInt == -1) ? arrayOfInt.length : Math.min(arrayOfInt.length - paramLong + 1L, paramInt));

        
        arrayOfDatum = new Datum[i];
        
        for (byte b = 0; b < i; b++) {
          arrayOfDatum[b] = (Datum)new NUMBER(arrayOfInt[(int)paramLong + b - 1]);
        }
      } else if (paramObject instanceof long[]) {
        
        long[] arrayOfLong = (long[])paramObject;
        int i = (int)((paramInt == -1) ? arrayOfLong.length : Math.min(arrayOfLong.length - paramLong + 1L, paramInt));

        
        arrayOfDatum = new Datum[i];
        
        for (byte b = 0; b < i; b++) {
          arrayOfDatum[b] = (Datum)new NUMBER(arrayOfLong[(int)paramLong + b - 1]);
        }
      } else if (paramObject instanceof float[]) {
        
        float[] arrayOfFloat = (float[])paramObject;
        int i = (int)((paramInt == -1) ? arrayOfFloat.length : Math.min(arrayOfFloat.length - paramLong + 1L, paramInt));

        
        arrayOfDatum = new Datum[i];
        
        for (byte b = 0; b < i; b++) {
          arrayOfDatum[b] = (Datum)new NUMBER(arrayOfFloat[(int)paramLong + b - 1]);
        }
      } else if (paramObject instanceof double[]) {
        
        double[] arrayOfDouble = (double[])paramObject;
        int i = (int)((paramInt == -1) ? arrayOfDouble.length : Math.min(arrayOfDouble.length - paramLong + 1L, paramInt));

        
        arrayOfDatum = new Datum[i];
        
        for (byte b = 0; b < i; b++) {
          arrayOfDatum[b] = (Datum)new NUMBER(arrayOfDouble[(int)paramLong + b - 1]);
        }
      } else if (paramObject instanceof boolean[]) {
        
        boolean[] arrayOfBoolean = (boolean[])paramObject;
        int i = (int)((paramInt == -1) ? arrayOfBoolean.length : Math.min(arrayOfBoolean.length - paramLong + 1L, paramInt));

        
        arrayOfDatum = new Datum[i];
        
        for (byte b = 0; b < i; b++) {
          arrayOfDatum[b] = (Datum)new NUMBER(Boolean.valueOf(arrayOfBoolean[(int)paramLong + b - 1]));
        }
      }
      else if (paramObject instanceof char[][]) {
        
        char[][] arrayOfChar = (char[][])paramObject;
        int i = (int)((paramInt == -1) ? arrayOfChar.length : Math.min(arrayOfChar.length - paramLong + 1L, paramInt));

        
        arrayOfDatum = new Datum[i];
        
        for (byte b = 0; b < i; b++) {
          arrayOfDatum[b] = (Datum)new NUMBER(new String(arrayOfChar[(int)paramLong + b - 1]));
        
        }
      }
      else {
        
        SQLException sQLException = DatabaseError.createSqlException(null, 59, paramObject);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    }
    
    return arrayOfDatum;
  }



  
  public int getPrecision() {
    return this.precision;
  }



  
  public int getScale() {
    return this.scale;
  }







  
  private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
    paramObjectOutputStream.writeInt(this.scale);
    paramObjectOutputStream.writeInt(this.precision);
  }




  
  private void readObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {
    this.scale = paramObjectInputStream.readInt();
    this.precision = paramObjectInputStream.readInt();
  }




































  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
