package oracle.jdbc.driver;

import java.io.IOException;
import java.io.Reader;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.CLOB;



















class OracleClobReader
  extends Reader
{
  CLOB clob;
  DBConversion dbConversion;
  long lobOffset;
  long markedChar;
  char[] resizableBuffer;
  int initialBufferSize;
  int currentBufferSize;
  int pos;
  int count;
  long maxPosition = Long.MAX_VALUE;


  
  boolean isClosed;

  
  boolean endOfStream;


  
  public OracleClobReader(CLOB paramCLOB) throws SQLException {
    this(paramCLOB, ((PhysicalConnection)paramCLOB.getInternalConnection()).getDefaultStreamChunkSize() / 3);
  }











  
  public OracleClobReader(CLOB paramCLOB, int paramInt) throws SQLException {
    this(paramCLOB, paramInt, 1L);
  }













  
  public OracleClobReader(CLOB paramCLOB, int paramInt, long paramLong) throws SQLException {
    if (paramCLOB == null || paramInt <= 0 || paramCLOB.getInternalConnection() == null || paramLong < 1L)
    {
      
      throw new IllegalArgumentException();
    }
    
    this.dbConversion = ((PhysicalConnection)paramCLOB.getInternalConnection()).conversion;

    
    this.clob = paramCLOB;
    this.lobOffset = paramLong;
    this.markedChar = -1L;
    
    this.resizableBuffer = null;
    this.initialBufferSize = paramInt;
    this.currentBufferSize = 0;
    this.pos = this.count = 0;
    
    this.isClosed = false;
  }










  
  public OracleClobReader(CLOB paramCLOB, int paramInt, long paramLong1, long paramLong2) throws SQLException {
    this(paramCLOB, paramInt, paramLong1);
    this.maxPosition = paramLong1 + paramLong2;
  }

















  
  public int read(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws IOException {
    ensureOpen();
    
    int i = paramInt1;
    int j = i + Math.min(paramInt2, paramArrayOfchar.length - paramInt1);
    
    if (!needChars(j - i)) {
      return -1;
    }
    
    i += writeChars(paramArrayOfchar, i, j - i);
    
    while (i < j && needChars(j - i))
    {
      i += writeChars(paramArrayOfchar, i, j - i);
    }
    
    return i - paramInt1;
  }









  
  protected boolean needChars(int paramInt) throws IOException {
    ensureOpen();
    
    if (this.pos >= this.count) {
      
      if (!this.endOfStream) {
        
        try {
          
          if (paramInt > this.currentBufferSize) {
            
            this.currentBufferSize = Math.max(paramInt, this.initialBufferSize);
            PhysicalConnection physicalConnection = (PhysicalConnection)this.clob.getInternalConnection();
            
            synchronized (physicalConnection) {
              this.resizableBuffer = physicalConnection.getCharBuffer(this.currentBufferSize);
            } 
          } 
          
          int i = this.currentBufferSize;
          if (this.maxPosition - this.lobOffset < this.currentBufferSize) i = (int)(this.maxPosition - this.lobOffset);
          
          this.count = this.clob.getChars(this.lobOffset, i, this.resizableBuffer);

          
          if (this.count < this.currentBufferSize) {
            this.endOfStream = true;
          }
          if (this.count > 0)
          {
            this.pos = 0;
            this.lobOffset += this.count;
            if (this.lobOffset >= this.maxPosition) this.endOfStream = true;
            
            return true;
          }
        
        } catch (SQLException sQLException) {

          
          IOException iOException = DatabaseError.createIOException(sQLException);
          iOException.fillInStackTrace();
          throw iOException;
        } 
      }

      
      return false;
    } 
    
    return true;
  }











  
  protected int writeChars(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
    int i = Math.min(paramInt2, this.count - this.pos);
    
    System.arraycopy(this.resizableBuffer, this.pos, paramArrayOfchar, paramInt1, i);
    
    this.pos += i;
    
    return i;
  }













  
  public boolean ready() throws IOException {
    ensureOpen();
    
    return (this.pos < this.count);
  }










  
  public void close() throws IOException {
    if (this.isClosed) {
      return;
    }
    
    try {
      this.isClosed = true;
      
      PhysicalConnection physicalConnection = (PhysicalConnection)this.clob.getInternalConnection();
      synchronized (physicalConnection) {
        
        if (this.resizableBuffer != null) {
          
          physicalConnection.cacheBuffer(this.resizableBuffer);
          this.resizableBuffer = null;
        } 
      } 
    } catch (SQLException sQLException) {

      
      IOException iOException = DatabaseError.createIOException(sQLException);
      iOException.fillInStackTrace();
      throw iOException;
    } 
  }












  
  void ensureOpen() throws IOException {
    try {
      if (this.isClosed)
      {
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 57, (Object)null);
        sQLException.fillInStackTrace();
        throw sQLException;
      }
    
    } catch (SQLException sQLException) {

      
      IOException iOException = DatabaseError.createIOException(sQLException);
      iOException.fillInStackTrace();
      throw iOException;
    } 
  }








  
  public boolean markSupported() {
    return true;
  }

















  
  public void mark(int paramInt) throws IOException {
    if (paramInt < 0) {
      throw new IllegalArgumentException(DatabaseError.findMessage(195, null));
    }
    this.markedChar = this.lobOffset - this.count + this.pos;
  }

















  
  public void reset() throws IOException {
    ensureOpen();
    
    if (this.markedChar < 0L) {
      throw new IOException(DatabaseError.findMessage(195, null));
    }
    this.lobOffset = this.markedChar;
    this.pos = this.count;
    this.endOfStream = false;
  }














  
  public long skip(long paramLong) throws IOException {
    ensureOpen();
    
    long l = 0L;
    
    if ((this.count - this.pos) >= paramLong) {
      
      this.pos = (int)(this.pos + paramLong);
      l += paramLong;
    }
    else {
      
      l += (this.count - this.pos);
      this.pos = this.count;

      
      try {
        long l1 = this.clob.length() - this.lobOffset + 1L;
        
        if (l1 >= paramLong - l)
        {
          this.lobOffset += paramLong - l;
          l += paramLong - l;
        }
        else
        {
          this.lobOffset += l1;
          l += l1;
        }
      
      } catch (SQLException sQLException) {

        
        IOException iOException = DatabaseError.createIOException(sQLException);
        iOException.fillInStackTrace();
        throw iOException;
      } 
    } 

    
    return l;
  }













  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    try {
      return this.clob.getInternalConnection();
    }
    catch (Exception exception) {
      
      return null;
    } 
  }



  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
