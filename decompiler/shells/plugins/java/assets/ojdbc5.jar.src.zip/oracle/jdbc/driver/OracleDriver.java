package oracle.jdbc.driver;

import java.io.IOException;
import java.io.InputStream;
import java.lang.management.ManagementFactory;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.DriverPropertyInfo;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.management.InstanceAlreadyExistsException;
import javax.management.JMException;
import javax.management.MBeanServer;
import javax.management.ObjectName;
import oracle.jdbc.OracleDatabaseMetaData;
import oracle.jdbc.internal.OracleConnection;
























































public class OracleDriver
  implements Driver
{
  public static final String oracle_string = "oracle";
  public static final String jdbc_string = "jdbc";
  public static final String protocol_string = "protocol";
  public static final String user_string = "user";
  public static final String password_string = "password";
  public static final String database_string = "database";
  public static final String server_string = "server";
  public static final String access_string = "access";
  public static final String protocolFullName_string = "protocolFullName";
  public static final String logon_as_internal_str = "internal_logon";
  public static final String proxy_client_name = "oracle.jdbc.proxyClientName";
  public static final String prefetch_string = "prefetch";
  public static final String row_prefetch_string = "rowPrefetch";
  public static final String default_row_prefetch_string = "defaultRowPrefetch";
  public static final String batch_string = "batch";
  public static final String execute_batch_string = "executeBatch";
  public static final String default_execute_batch_string = "defaultExecuteBatch";
  public static final String process_escapes_string = "processEscapes";
  public static final String accumulate_batch_result = "AccumulateBatchResult";
  public static final String j2ee_compliance = "oracle.jdbc.J2EE13Compliant";
  public static final String v8compatible_string = "V8Compatible";
  public static final String permit_timestamp_date_mismatch_string = "oracle.jdbc.internal.permitBindDateDefineTimestampMismatch";
  public static final String StreamChunkSize_string = "oracle.jdbc.StreamChunkSize";
  public static final String prelim_auth_string = "prelim_auth";
  public static final String SetFloatAndDoubleUseBinary_string = "SetFloatAndDoubleUseBinary";
  public static final String xa_trans_loose = "oracle.jdbc.XATransLoose";
  public static final String tcp_no_delay = "oracle.jdbc.TcpNoDelay";
  public static final String read_timeout = "oracle.jdbc.ReadTimeout";
  public static final String defaultnchar_string = "oracle.jdbc.defaultNChar";
  public static final String defaultncharprop_string = "defaultNChar";
  public static final String useFetchSizeWithLongColumn_prop_string = "useFetchSizeWithLongColumn";
  public static final String useFetchSizeWithLongColumn_string = "oracle.jdbc.useFetchSizeWithLongColumn";
  public static final String remarks_string = "remarks";
  public static final String report_remarks_string = "remarksReporting";
  public static final String synonyms_string = "synonyms";
  public static final String include_synonyms_string = "includeSynonyms";
  public static final String restrict_getTables_string = "restrictGetTables";
  public static final String fixed_string_string = "fixedString";
  public static final String dll_string = "oracle.jdbc.ocinativelibrary";
  public static final String nls_lang_backdoor = "oracle.jdbc.ociNlsLangBackwardCompatible";
  public static final String disable_defineColumnType_string = "disableDefineColumnType";
  public static final String convert_nchar_literals_string = "oracle.jdbc.convertNcharLiterals";
  public static final String dataSizeUnitsPropertyName = "";
  public static final String dataSizeBytes = "";
  public static final String dataSizeChars = "";
  public static final String set_new_password_string = "OCINewPassword";
  public static final String retain_v9_bind_behavior_string = "oracle.jdbc.RetainV9LongBindBehavior";
  public static final String no_caching_buffers = "oracle.jdbc.FreeMemoryOnEnterImplicitCache";
  static final int EXTENSION_TYPE_ORACLE_ERROR = -3;
  static final int EXTENSION_TYPE_GEN_ERROR = -2;
  static final int EXTENSION_TYPE_TYPE4_CLIENT = 0;
  static final int EXTENSION_TYPE_TYPE4_SERVER = 1;
  static final int EXTENSION_TYPE_TYPE2_CLIENT = 2;
  static final int EXTENSION_TYPE_TYPE2_SERVER = 3;
  private static final int NUMBER_OF_EXTENSION_TYPES = 4;
  private OracleDriverExtension[] driverExtensions = new OracleDriverExtension[4];






  
  private static final String DRIVER_PACKAGE_STRING = "driver";






  
  private static final String[] driverExtensionClassNames = new String[] { "oracle.jdbc.driver.T4CDriverExtension", "oracle.jdbc.driver.T4CDriverExtension", "oracle.jdbc.driver.T2CDriverExtension", "oracle.jdbc.driver.T2SDriverExtension" };








  
  private static Properties driverAccess;







  
  protected static Connection defaultConn = null;
  private static OracleDriver defaultDriver = null;



  
  static {
    try {
      if (defaultDriver == null) {
        
        defaultDriver = (OracleDriver)new oracle.jdbc.OracleDriver();
        DriverManager.registerDriver(defaultDriver);
      } 




      
      AccessController.doPrivileged(new PrivilegedAction()
          {
            public Object run()
            {
              OracleDriver.registerMBeans();
              return null;
            }
          });












      
      Timestamp timestamp = Timestamp.valueOf("2000-01-01 00:00:00.0");

    
    }
    catch (SQLException sQLException) {
      Logger.getLogger("oracle.jdbc.driver").log(Level.SEVERE, "SQLException in static block.", sQLException);


    
    }
    catch (RuntimeException runtimeException) {
      Logger.getLogger("oracle.jdbc.driver").log(Level.SEVERE, "RuntimeException in static block.", runtimeException);
    } 










    
    try {
      ClassRef classRef = ClassRef.newInstance("oracle.security.pki.OraclePKIProvider");
      Object object = classRef.get().newInstance();
    }
    catch (Throwable throwable) {}
  }






  
  public static final Map<String, ClassRef> systemTypeMap = new Hashtable<String, ClassRef>(3);
  
  private static final String DEFAULT_CONNECTION_PROPERTIES_RESOURCE_NAME = "/oracle/jdbc/defaultConnectionProperties.properties";

  
  static {
    try {
      systemTypeMap.put("SYS.XMLTYPE", ClassRef.newInstance("oracle.xdb.XMLTypeFactory"));
    }
    catch (ClassNotFoundException classNotFoundException) {}





    
    try {
      systemTypeMap.put("SYS.ANYDATA", ClassRef.newInstance("oracle.sql.AnyDataFactory"));
      systemTypeMap.put("SYS.ANYTYPE", ClassRef.newInstance("oracle.sql.TypeDescriptorFactory"));
    }
    catch (ClassNotFoundException classNotFoundException) {}
  }










  
  protected static final Properties DEFAULT_CONNECTION_PROPERTIES = new Properties();
  static {
    try {
      InputStream inputStream = PhysicalConnection.class.getResourceAsStream("/oracle/jdbc/defaultConnectionProperties.properties");
      if (inputStream != null) DEFAULT_CONNECTION_PROPERTIES.load(inputStream);
    
    } catch (IOException iOException) {}
  }











  
  public static void registerMBeans() {
    try {
      MBeanServer mBeanServer = null;
      
      try {
        ClassRef classRef = ClassRef.newInstance("oracle.as.jmx.framework.PortableMBeanFactory");
        Constructor<Object> constructor = classRef.get().getConstructor(new Class[0]);
        Object object = constructor.newInstance(new Object[0]);
        Method method = classRef.get().getMethod("getMBeanServer", new Class[0]);
        mBeanServer = (MBeanServer)method.invoke(object, new Object[0]);
      }
      catch (NoClassDefFoundError noClassDefFoundError) {

        
        mBeanServer = ManagementFactory.getPlatformMBeanServer();
      }
      catch (ClassNotFoundException classNotFoundException) {

        
        mBeanServer = ManagementFactory.getPlatformMBeanServer();
      }
      catch (NoSuchMethodException noSuchMethodException) {
        Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Found Oracle Apps MBeanServer but not the getMBeanServer method.", noSuchMethodException);


        
        mBeanServer = ManagementFactory.getPlatformMBeanServer();
      }
      catch (InstantiationException instantiationException) {
        Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Found Oracle Apps MBeanServer but could not create an instance.", instantiationException);


        
        mBeanServer = ManagementFactory.getPlatformMBeanServer();
      }
      catch (IllegalAccessException illegalAccessException) {
        Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Found Oracle Apps MBeanServer but could not access the getMBeanServer method.", illegalAccessException);


        
        mBeanServer = ManagementFactory.getPlatformMBeanServer();
      }
      catch (InvocationTargetException invocationTargetException) {
        Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Found Oracle Apps MBeanServer but the getMBeanServer method threw an exception.", invocationTargetException);


        
        mBeanServer = ManagementFactory.getPlatformMBeanServer();
      } 
      if (mBeanServer != null) {
        ClassLoader classLoader = OracleDriver.class.getClassLoader();
        String str = (classLoader == null) ? "nullLoader" : classLoader.getClass().getName();
        byte b = 0;
        while (true) {
          String str1 = str + "@" + Integer.toHexString(((classLoader == null) ? 0 : classLoader.hashCode()) + b++);
          
          ObjectName objectName = new ObjectName("com.oracle.jdbc:type=diagnosability,name=" + str1);
          
          try {
            mBeanServer.registerMBean(new OracleDiagnosabilityMBean(), objectName);
            
            break;
          } catch (InstanceAlreadyExistsException instanceAlreadyExistsException) {}
        }
      
      } else {
        
        Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Unable to find an MBeanServer so no MBears are registered.");
      }
    
    }
    catch (JMException jMException) {
      Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Error while registering Oracle JDBC Diagnosability MBean.", jMException);


    
    }
    catch (Throwable throwable) {
      Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Error while registering Oracle JDBC Diagnosability MBean.", throwable);
    } 
  }





























  
  public Connection connect(String paramString, Properties paramProperties) throws SQLException {
    if (paramString.regionMatches(0, "jdbc:default:connection", 0, 23)) {
      
      String str = "jdbc:oracle:kprb";
      int j = paramString.length();
      
      if (j > 23) {
        paramString = str.concat(paramString.substring(23, paramString.length()));
      } else {
        paramString = str.concat(":");
      } 
      str = null;
    } 







    
    int i = oracleDriverExtensionTypeFromURL(paramString);
    
    if (i == -2) {
      return null;
    }
    if (i == -3) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    OracleDriverExtension oracleDriverExtension = null;
    
    oracleDriverExtension = this.driverExtensions[i];
    
    if (oracleDriverExtension == null) {
      
      try {

        
        synchronized (this)
        {
          if (oracleDriverExtension == null)
          {



            
            oracleDriverExtension = (OracleDriverExtension)Class.forName(driverExtensionClassNames[i]).newInstance();
            
            this.driverExtensions[i] = oracleDriverExtension;
          }
          else
          {
            oracleDriverExtension = this.driverExtensions[i];
          }
        
        }
      
      } catch (Exception exception) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), exception);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    }



    
    if (paramProperties == null) {
      paramProperties = new Properties();
    }








    
    Enumeration<Driver> enumeration = DriverManager.getDrivers();

    
    while (enumeration.hasMoreElements()) {
      
      Driver driver = enumeration.nextElement();
      
      if (driver instanceof OracleDriver) {
        break;
      }
    } 
    
    while (enumeration.hasMoreElements()) {
      
      Driver driver = enumeration.nextElement();
      
      if (driver instanceof OracleDriver) {
        DriverManager.deregisterDriver(driver);
      }
    } 



    
    PhysicalConnection physicalConnection = (PhysicalConnection)oracleDriverExtension.getConnection(paramString, paramProperties);

    
    physicalConnection.protocolId = i;
    
    return (Connection)physicalConnection;
  }









  
  public Connection defaultConnection() throws SQLException {
    if (defaultConn == null || defaultConn.isClosed())
    {
      synchronized (OracleDriver.class) {
        
        if (defaultConn == null || defaultConn.isClosed())
        {
          defaultConn = connect("jdbc:oracle:kprb:", new Properties());
        }
      } 
    }
    
    return defaultConn;
  }





















  
  static final int oracleDriverExtensionTypeFromURL(String paramString) {
    int i = paramString.indexOf(':');
    
    if (i == -1) {
      return -2;
    }
    if (!paramString.regionMatches(true, 0, "jdbc", 0, i)) {
      return -2;
    }
    i++;
    
    int j = paramString.indexOf(':', i);
    
    if (j == -1) {
      return -2;
    }
    if (!paramString.regionMatches(true, i, "oracle", 0, j - i))
    {
      return -2;
    }
    j++;
    
    int k = paramString.indexOf(':', j);
    
    String str = null;





    
    if (k == -1) {
      return -3;
    }
    str = paramString.substring(j, k);
    
    if (str.equals("thin")) {
      return 0;
    }
    if (str.equals("oci8") || str.equals("oci")) {
      return 2;
    }

    
    return -3;
  }
















  
  public boolean acceptsURL(String paramString) {
    if (paramString.startsWith("jdbc:oracle:"))
    {
      return (oracleDriverExtensionTypeFromURL(paramString) > -2);
    }
    
    return false;
  }




  
  public DriverPropertyInfo[] getPropertyInfo(String paramString, Properties paramProperties) throws SQLException {
    Class clazz = null;
    
    try {
      clazz = ClassRef.newInstance("oracle.jdbc.OracleConnection").get();
    
    }
    catch (ClassNotFoundException classNotFoundException) {}
    
    byte b1 = 0;
    String[] arrayOfString1 = new String[150];
    String[] arrayOfString2 = new String[150];
    
    Field[] arrayOfField = clazz.getFields();
    for (byte b2 = 0; b2 < arrayOfField.length; b2++) {
      
      if (arrayOfField[b2].getName().startsWith("CONNECTION_PROPERTY_") && !arrayOfField[b2].getName().endsWith("_DEFAULT") && !arrayOfField[b2].getName().endsWith("_ACCESSMODE")) {
        
        try {


          
          String str1 = (String)arrayOfField[b2].get(null);
          Field field = clazz.getField(arrayOfField[b2].getName() + "_DEFAULT");
          String str2 = (String)field.get(null);
          if (b1 == arrayOfString1.length) {
            
            String[] arrayOfString3 = new String[arrayOfString1.length * 2];
            String[] arrayOfString4 = new String[arrayOfString1.length * 2];
            System.arraycopy(arrayOfString1, 0, arrayOfString3, 0, arrayOfString1.length);
            System.arraycopy(arrayOfString2, 0, arrayOfString4, 0, arrayOfString1.length);
            arrayOfString1 = arrayOfString3;
            arrayOfString2 = arrayOfString4;
          } 
          arrayOfString1[b1] = str1;
          arrayOfString2[b1] = str2;
          b1++;
        }
        catch (IllegalAccessException illegalAccessException) {
        
        } catch (NoSuchFieldException noSuchFieldException) {}
      }
    } 
    
    DriverPropertyInfo[] arrayOfDriverPropertyInfo = new DriverPropertyInfo[b1];
    for (byte b3 = 0; b3 < b1; b3++)
      arrayOfDriverPropertyInfo[b3] = new DriverPropertyInfo(arrayOfString1[b3], arrayOfString2[b3]); 
    return arrayOfDriverPropertyInfo;
  }



  
  public int getMajorVersion() {
    return OracleDatabaseMetaData.getDriverMajorVersionInfo();
  }



  
  public int getMinorVersion() {
    return OracleDatabaseMetaData.getDriverMinorVersionInfo();
  }



  
  public boolean jdbcCompliant() {
    return true;
  }











  
  public String processSqlEscapes(String paramString) throws SQLException {
    OracleSql oracleSql = new OracleSql(null);


    
    oracleSql.initialize(paramString);
    
    return oracleSql.parse(paramString);
  }











  
  public static String getCompileTime() {
    return BuildInfo.getBuildDate();
  }



  
  public static String getSystemPropertyFastConnectionFailover(String paramString) {
    return PhysicalConnection.getSystemPropertyFastConnectionFailover(paramString);
  }











  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
