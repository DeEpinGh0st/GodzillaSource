package oracle.jdbc.driver;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;
import java.util.Vector;
import oracle.jdbc.OracleDataFactory;
import oracle.jdbc.OracleResultSet;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.ARRAY;
import oracle.sql.BFILE;
import oracle.sql.BLOB;
import oracle.sql.CHAR;
import oracle.sql.CLOB;
import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import oracle.sql.DATE;
import oracle.sql.Datum;
import oracle.sql.INTERVALDS;
import oracle.sql.INTERVALYM;
import oracle.sql.NUMBER;
import oracle.sql.OPAQUE;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.RAW;
import oracle.sql.REF;
import oracle.sql.ROWID;
import oracle.sql.STRUCT;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;




class ScrollableResultSet
  extends BaseResultSet
{
  PhysicalConnection connection;
  OracleResultSetImpl resultSet;
  ScrollRsetStatement scrollStmt;
  ResultSetMetaData metadata;
  private int rsetType;
  private int rsetConcurency;
  private int beginColumnIndex;
  private int columnCount;
  private int wasNull;
  OracleResultSetCache rsetCache;
  int currentRow;
  private int numRowsCached;
  private boolean allRowsCached;
  private int lastRefetchSz;
  private Vector refetchRowids;
  private OraclePreparedStatement refetchStmt;
  private int usrFetchDirection;
  
  ScrollableResultSet(ScrollRsetStatement paramScrollRsetStatement, OracleResultSetImpl paramOracleResultSetImpl, int paramInt1, int paramInt2) throws SQLException {
    this.connection = ((OracleStatement)paramScrollRsetStatement).connection;
    this.resultSet = paramOracleResultSetImpl;
    this.metadata = null;
    this.scrollStmt = paramScrollRsetStatement;
    this.rsetType = paramInt1;
    this.rsetConcurency = paramInt2;
    this.beginColumnIndex = needIdentifier(paramInt1, paramInt2) ? 1 : 0;
    this.columnCount = 0;
    this.wasNull = -1;
    this.rsetCache = paramScrollRsetStatement.getResultSetCache();
    
    if (this.rsetCache == null) {
      
      this.rsetCache = new OracleResultSetCacheImpl();
    } else {

      
      try {
        
        this.rsetCache.clear();
      }
      catch (IOException iOException) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    } 

    
    this.currentRow = 0;
    this.numRowsCached = 0;
    this.allRowsCached = false;
    this.lastRefetchSz = 0;
    this.refetchRowids = null;
    this.refetchStmt = null;
    this.usrFetchDirection = 1000;
    getInternalMetadata();
  }









  
  public void close() throws SQLException {
    synchronized (this.connection) {
      
      if (this.closed)
        return;  super.close();
      if (this.resultSet != null)
        this.resultSet.close(); 
      if (this.refetchStmt != null)
        this.refetchStmt.close(); 
      if (this.scrollStmt != null)
        this.scrollStmt.notifyCloseRset(); 
      if (this.refetchRowids != null) {
        this.refetchRowids.removeAllElements();
      }
      this.resultSet = null;
      this.scrollStmt = null;
      this.refetchStmt = null;
      this.refetchRowids = null;
      this.metadata = null;

      
      try {
        if (this.rsetCache != null)
        {
          this.rsetCache.clear();
          this.rsetCache.close();
        }
      
      } catch (IOException iOException) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
        sQLException.fillInStackTrace();
        throw sQLException;
      }
      finally {
        
        this.rsetCache = null;
      } 
    } 
  }


  
  public boolean wasNull() throws SQLException {
    synchronized (this.connection) {

      
      if (this.wasNull == -1) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 24);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      return (this.wasNull == 1);
    } 
  }



  
  public Statement getStatement() throws SQLException {
    synchronized (this.connection) {

      
      return (Statement)this.scrollStmt;
    } 
  }





  
  void resetBeginColumnIndex() {
    synchronized (this.connection) {

      
      this.beginColumnIndex = 0;
    } 
  }





  
  ResultSet getResultSet() {
    synchronized (this.connection) {

      
      return (ResultSet)this.resultSet;
    } 
  }


  
  int removeRowInCache(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      if (!isEmptyResultSet() && isValidRow(paramInt)) {
        
        removeCachedRowAt(paramInt);
        
        this.numRowsCached--;
        
        if (paramInt >= this.currentRow) {
          this.currentRow--;
        }
        return 1;
      } 
      
      return 0;
    } 
  }






  
  int refreshRowsInCache(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
    synchronized (this.connection) {

      
      OracleResultSetImpl oracleResultSetImpl = null;
      int i = 0;

      
      i = get_refetch_size(paramInt1, paramInt2, paramInt3);

      
      try {
        if (i > 0)
        {

          
          if (i != this.lastRefetchSz) {
            
            if (this.refetchStmt != null) {
              this.refetchStmt.close();
            }
            this.refetchStmt = prepare_refetch_statement(i);
            this.refetchStmt.setQueryTimeout(((OracleStatement)this.scrollStmt).getQueryTimeout());
            this.lastRefetchSz = i;
          } 

          
          prepare_refetch_binds(this.refetchStmt, i);

          
          oracleResultSetImpl = (OracleResultSetImpl)this.refetchStmt.executeQuery();

          
          save_refetch_results(oracleResultSetImpl, paramInt1, i, paramInt3);
        }
      
      }
      finally {
        
        if (oracleResultSetImpl != null) {
          oracleResultSetImpl.close();
        }
      } 
      return i;
    } 
  }






  
  public boolean next() throws SQLException {
    synchronized (this.connection) {

      
      if (this.closed) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      if (isEmptyResultSet())
      {
        return false;
      }

      
      if (this.currentRow < 1) {
        
        this.currentRow = 1;
      }
      else {
        
        this.currentRow++;
      } 
      
      return isValidRow(this.currentRow);
    } 
  }



  
  public boolean isBeforeFirst() throws SQLException {
    synchronized (this.connection) {

      
      if (this.closed) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      return (!isEmptyResultSet() && this.currentRow < 1);
    } 
  }


  
  public boolean isAfterLast() throws SQLException {
    synchronized (this.connection) {

      
      if (this.closed) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      return (!isEmptyResultSet() && this.currentRow > 0 && !isValidRow(this.currentRow));
    } 
  }


  
  public boolean isFirst() throws SQLException {
    synchronized (this.connection) {

      
      if (this.closed) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      return (this.currentRow == 1);
    } 
  }


  
  public boolean isLast() throws SQLException {
    synchronized (this.connection) {

      
      if (this.closed) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      return (!isEmptyResultSet() && isValidRow(this.currentRow) && !isValidRow(this.currentRow + 1));
    } 
  }



  
  public void beforeFirst() throws SQLException {
    synchronized (this.connection) {

      
      if (this.closed) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      if (!isEmptyResultSet()) {
        this.currentRow = 0;
      }
    } 
  }

  
  public void afterLast() throws SQLException {
    synchronized (this.connection) {
      if (this.closed) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      if (!isEmptyResultSet()) {
        this.currentRow = getLastRow() + 1;
      }
    } 
  }

  
  public boolean first() throws SQLException {
    synchronized (this.connection) {

      
      if (this.closed) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      if (isEmptyResultSet())
      {
        return false;
      }

      
      this.currentRow = 1;
      
      return isValidRow(this.currentRow);
    } 
  }



  
  public boolean last() throws SQLException {
    synchronized (this.connection) {

      
      if (this.closed) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      if (isEmptyResultSet())
      {
        return false;
      }

      
      this.currentRow = getLastRow();
      
      return isValidRow(this.currentRow);
    } 
  }



  
  public int getRow() throws SQLException {
    synchronized (this.connection) {

      
      if (this.closed) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      if (isValidRow(this.currentRow)) {
        return this.currentRow;
      }
      return 0;
    } 
  }


  
  public boolean absolute(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      if (this.closed) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      if (paramInt == 0) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "absolute(" + paramInt + ")");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      if (isEmptyResultSet())
      {
        return false;
      }
      if (paramInt > 0) {
        
        this.currentRow = paramInt;
      }
      else if (paramInt < 0) {
        
        this.currentRow = getLastRow() + 1 + paramInt;
      } 
      
      return isValidRow(this.currentRow);
    } 
  }


  
  public boolean relative(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      if (this.closed) {
        
        SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
        sQLException1.fillInStackTrace();
        throw sQLException1;
      } 
      if (isEmptyResultSet())
      {
        return false;
      }
      if (isValidRow(this.currentRow)) {
        
        this.currentRow += paramInt;
        
        return isValidRow(this.currentRow);
      } 


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82, "relative");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }




  
  public boolean previous() throws SQLException {
    synchronized (this.connection) {

      
      if (this.closed) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      if (isEmptyResultSet())
      {
        return false;
      }
      if (isAfterLast()) {
        
        this.currentRow = getLastRow();
      }
      else {
        
        this.currentRow--;
      } 
      
      return isValidRow(this.currentRow);
    } 
  }






  
  public Datum getOracleObject(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      if (this.closed) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      this.wasNull = -1;
      
      if (!isValidRow(this.currentRow)) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      if (paramInt < 1 || paramInt > getColumnCount()) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      Datum datum = getCachedDatumValueAt(this.currentRow, paramInt + this.beginColumnIndex);

      
      this.wasNull = (datum == null) ? 1 : 0;
      
      return datum;
    } 
  }


  
  public String getString(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        CLOB cLOB;
        switch (getInternalMetadata().getColumnType(paramInt + this.beginColumnIndex)) {





          
          case 2005:
            cLOB = (CLOB)datum;
            return cLOB.getSubString(1L, (int)cLOB.length());


          
          case 91:
            if (this.connection.mapDateToTimestamp) {
              return datum.toJdbc().toString();
            }
            return datum.dateValue().toString();


          
          case 93:
            if (datum instanceof DATE) {
              
              if (this.connection.mapDateToTimestamp) {
                return datum.toJdbc().toString();
              }
              return datum.dateValue().toString();
            } 

            
            if (this.connection.j2ee13Compliant)
            {
              
              return datum.toJdbc().toString();
            }

            
            return datum.stringValue((Connection)this.connection);
        } 




        
        return datum.stringValue((Connection)this.connection);
      } 


      
      return null;
    } 
  }


  
  public boolean getBoolean(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null)
      {
        return datum.booleanValue();
      }
      
      return false;
    } 
  }


  
  public OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(int paramInt) throws SQLException {
    synchronized (this.connection) {
      
      if (!isValidRow(this.currentRow)) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      if (paramInt < 1 || paramInt > getColumnCount()) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      CachedRowElement cachedRowElement = null;
      OracleResultSet.AuthorizationIndicator authorizationIndicator = null;

      
      try {
        cachedRowElement = (CachedRowElement)this.rsetCache.get(this.currentRow, paramInt);
      }
      catch (IOException iOException) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      if (cachedRowElement != null) {
        authorizationIndicator = cachedRowElement.getIndicator();
      }
      return authorizationIndicator;
    } 
  }


  
  public byte getByte(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        return datum.byteValue();
      }
      return 0;
    } 
  }


  
  public short getShort(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      long l = getLong(paramInt);
      
      if (l > 65537L || l < -65538L) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 26, "getShort");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      return (short)(int)l;
    } 
  }


  
  public int getInt(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null)
      {
        return datum.intValue();
      }
      
      return 0;
    } 
  }


  
  public long getLong(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null)
      {
        return datum.longValue();
      }
      
      return 0L;
    } 
  }


  
  public float getFloat(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null)
      {
        return datum.floatValue();
      }
      
      return 0.0F;
    } 
  }


  
  public double getDouble(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null)
      {
        return datum.doubleValue();
      }
      
      return 0.0D;
    } 
  }



  
  public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt1);
      
      if (datum != null)
      {
        return datum.bigDecimalValue();
      }
      
      return null;
    } 
  }


  
  public byte[] getBytes(int paramInt) throws SQLException {
    synchronized (this.connection) {
      
      byte[] arrayOfByte = null;
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null)
      {
        if (datum instanceof RAW) {
          arrayOfByte = ((RAW)datum).shareBytes();
        } else if (datum instanceof BLOB) {
          
          BLOB bLOB = (BLOB)datum;
          long l = bLOB.length();
          if (l > 2147483647L) {

            
            SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 151);
            sQLException.fillInStackTrace();
            throw sQLException;
          } 
          
          arrayOfByte = bLOB.getBytes(1L, (int)l);
          if (bLOB.isTemporary()) this.resultSet.statement.addToTempLobsToFree(bLOB);
        
        } else {
          
          arrayOfByte = datum.getBytes();
        } 
      }
      return arrayOfByte;
    } 
  }


  
  public Date getDate(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      Date date = null;
      
      if (datum != null)
      
      { ResultSetMetaData resultSetMetaData = getInternalMetadata();
        switch (resultSetMetaData.getColumnType(paramInt + this.beginColumnIndex))
        
        { 
          
          case -101:
            date = ((TIMESTAMPTZ)datum).dateValue((Connection)this.connection);











            
            return date;case -102: date = ((TIMESTAMPLTZ)datum).dateValue((Connection)this.connection); return date; }  date = datum.dateValue(); }  return date;
    } 
  }


  
  public Time getTime(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      Time time = null;
      
      if (datum != null)
      
      { ResultSetMetaData resultSetMetaData = getInternalMetadata();
        switch (resultSetMetaData.getColumnType(paramInt + this.beginColumnIndex))
        
        { case -101:
            time = ((TIMESTAMPTZ)datum).timeValue((Connection)this.connection);












            
            return time;case -102: time = ((TIMESTAMPLTZ)datum).timeValue((Connection)this.connection, this.connection.getDbTzCalendar()); return time; }  time = datum.timeValue(); }  return time;
    } 
  }



  
  public Timestamp getTimestamp(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      Timestamp timestamp = null;
      
      if (datum != null)
      
      { ResultSetMetaData resultSetMetaData = getInternalMetadata();
        switch (resultSetMetaData.getColumnType(paramInt + this.beginColumnIndex))
        
        { case -101:
            timestamp = ((TIMESTAMPTZ)datum).timestampValue((Connection)this.connection);












            
            return timestamp;case -102: timestamp = ((TIMESTAMPLTZ)datum).timestampValue((Connection)this.connection, this.connection.getDbTzCalendar()); return timestamp; }  timestamp = datum.timestampValue(); }  return timestamp;
    } 
  }



  
  public InputStream getAsciiStream(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null)
      {


        
        return datum.asciiStreamValue();
      }
      
      return null;
    } 
  }



  
  public InputStream getUnicodeStream(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        DBConversion dBConversion = this.connection.conversion;
        byte[] arrayOfByte = datum.shareBytes();
        
        if (datum instanceof RAW)
        {
          return dBConversion.ConvertStream(new ByteArrayInputStream(arrayOfByte), 3);
        }
        
        if (datum instanceof CHAR)
        {
          return dBConversion.ConvertStream(new ByteArrayInputStream(arrayOfByte), 1);
        }


        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getUnicodeStream");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }



  
  public InputStream getBinaryStream(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null)
      {
        return datum.binaryStreamValue();
      }
      
      return null;
    } 
  }





  
  public Object getObject(int paramInt) throws SQLException {
    return getObject(paramInt, this.connection.getTypeMap());
  }




  
  public Reader getCharacterStream(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null)
      {
        return datum.characterStreamValue();
      }
      
      return null;
    } 
  }





  
  public BigDecimal getBigDecimal(int paramInt) throws SQLException {
    return getBigDecimal(paramInt, 0);
  }








  
  public Object getObject(int paramInt, Map paramMap) throws SQLException {
    synchronized (this.connection) {

      
      Object object = null;
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null)
      
      { int i = getInternalMetadata().getColumnType(paramInt + this.beginColumnIndex);
        
        switch (i)
        
        { case 2002:
            object = ((STRUCT)datum).toJdbc(paramMap);








































            
            return object;case 91: if (this.connection.mapDateToTimestamp) { object = datum.toJdbc(); } else { object = datum.dateValue(); }  return object;case 93: if (datum instanceof DATE) { if (this.connection.mapDateToTimestamp) { object = datum.toJdbc(); } else { object = datum.dateValue(); }  } else if (this.connection.j2ee13Compliant) { object = datum.toJdbc(); } else { object = datum; }  return object;case -102: case -101: object = datum; return object; }  object = datum.toJdbc(); }  return object;
    } 
  }



  
  public Ref getRef(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      return (Ref)getREF(paramInt);
    } 
  }



  
  public Blob getBlob(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      return (Blob)getBLOB(paramInt);
    } 
  }



  
  public Clob getClob(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      return (Clob)getCLOB(paramInt);
    } 
  }




  
  public Array getArray(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      return (Array)getARRAY(paramInt);
    } 
  }




  
  public Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      Date date = null;
      
      if (datum != null)
      { Calendar calendar;
        ResultSetMetaData resultSetMetaData = getInternalMetadata();
        switch (resultSetMetaData.getColumnType(paramInt + this.beginColumnIndex))
        
        { case -101:
            date = new Date(((TIMESTAMPTZ)datum).timestampValue((Connection)this.connection).getTime());















            
            return date;case -102: calendar = this.connection.getDbTzCalendar(); date = new Date(((TIMESTAMPLTZ)datum).timestampValue((Connection)this.connection, (calendar == null) ? paramCalendar : calendar).getTime()); return date; }  date = new Date(datum.timestampValue(paramCalendar).getTime()); }  return date;
    } 
  }




  
  public Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      Time time = null;
      
      if (datum != null)
      { Calendar calendar;
        ResultSetMetaData resultSetMetaData = getInternalMetadata();
        switch (resultSetMetaData.getColumnType(paramInt + this.beginColumnIndex))
        
        { case -101:
            time = new Time(((TIMESTAMPTZ)datum).timestampValue((Connection)this.connection).getTime());












            
            return time;case -102: calendar = this.connection.getDbTzCalendar(); time = new Time(((TIMESTAMPLTZ)datum).timestampValue((Connection)this.connection, (calendar == null) ? paramCalendar : calendar).getTime()); return time; }  time = new Time(datum.timestampValue(paramCalendar).getTime()); }  return time;
    } 
  }




  
  public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      Timestamp timestamp = null;
      
      if (datum != null)
      { Calendar calendar;
        ResultSetMetaData resultSetMetaData = getInternalMetadata();
        switch (resultSetMetaData.getColumnType(paramInt + this.beginColumnIndex))
        
        { case -101:
            timestamp = ((TIMESTAMPTZ)datum).timestampValue((Connection)this.connection);












            
            return timestamp;case -102: calendar = this.connection.getDbTzCalendar(); timestamp = ((TIMESTAMPLTZ)datum).timestampValue((Connection)this.connection, (calendar == null) ? paramCalendar : calendar); return timestamp; }  timestamp = datum.timestampValue(paramCalendar); }  return timestamp;
    } 
  }



  
  public URL getURL(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      URL uRL = null;
      
      int i = getInternalMetadata().getColumnType(paramInt + this.beginColumnIndex);
      int j = SQLUtil.getInternalType(i);

      
      if (j == 96 || j == 1 || j == 8) {

        
        try {
          
          String str = getString(paramInt);
          if (str == null) { uRL = null; }
          else { uRL = new URL(str); }
        
        } catch (MalformedURLException malformedURLException) {

          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 136);
          sQLException.fillInStackTrace();
          throw sQLException;
        
        }
      
      }
      else {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Conversion to java.net.URL not supported.");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return uRL;
    } 
  }



  
  public ResultSet getCursor(int paramInt) throws SQLException {
    synchronized (this.connection) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCursor");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }





  
  public ROWID getROWID(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof ROWID) {
          return (ROWID)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getROWID");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }



  
  public NUMBER getNUMBER(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof NUMBER) {
          return (NUMBER)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getNUMBER");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }



  
  public DATE getDATE(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof DATE)
          return (DATE)datum; 
        if (datum instanceof TIMESTAMP)
          return TIMESTAMP.toDATE(datum.getBytes()); 
        if (datum instanceof TIMESTAMPLTZ)
          return TIMESTAMPLTZ.toDATE((Connection)this.connection, datum.getBytes()); 
        if (datum instanceof TIMESTAMPTZ) {
          return TIMESTAMPTZ.toDATE((Connection)this.connection, datum.getBytes());
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getDATE");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }



  
  public TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof TIMESTAMP)
          return (TIMESTAMP)datum; 
        if (datum instanceof TIMESTAMPLTZ)
          return TIMESTAMPLTZ.toTIMESTAMP((Connection)this.connection, datum.getBytes()); 
        if (datum instanceof TIMESTAMPTZ)
          return TIMESTAMPTZ.toTIMESTAMP((Connection)this.connection, datum.getBytes()); 
        if (datum instanceof DATE) {
          return new TIMESTAMP((DATE)datum);
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMP");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }



  
  public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof TIMESTAMPTZ)
          return (TIMESTAMPTZ)datum; 
        if (datum instanceof TIMESTAMPLTZ) {
          return TIMESTAMPLTZ.toTIMESTAMPTZ((Connection)this.connection, datum.getBytes());
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPTZ");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }



  
  public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof TIMESTAMPLTZ) {
          return (TIMESTAMPLTZ)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPLTZ");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }



  
  public INTERVALDS getINTERVALDS(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof INTERVALDS) {
          return (INTERVALDS)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getINTERVALDS");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }



  
  public INTERVALYM getINTERVALYM(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof INTERVALYM) {
          return (INTERVALYM)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getINTERVALYM");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }



  
  public ARRAY getARRAY(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof ARRAY) {
          return (ARRAY)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getARRAY");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }



  
  public STRUCT getSTRUCT(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof STRUCT) {
          return (STRUCT)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getSTRUCT");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }



  
  public OPAQUE getOPAQUE(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof OPAQUE) {
          return (OPAQUE)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getOPAQUE");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }



  
  public REF getREF(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof REF) {
          return (REF)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getREF");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }



  
  public CHAR getCHAR(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof CHAR) {
          return (CHAR)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCHAR");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }



  
  public RAW getRAW(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof RAW) {
          return (RAW)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getRAW");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }



  
  public BLOB getBLOB(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof BLOB) {
          return (BLOB)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBLOB");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }



  
  public CLOB getCLOB(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof CLOB) {
          return (CLOB)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCLOB");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }







  
  public BFILE getBFILE(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);
      
      if (datum != null) {
        
        if (datum instanceof BFILE) {
          return (BFILE)datum;
        }
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBFILE");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      return null;
    } 
  }




  
  public BFILE getBfile(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      return getBFILE(paramInt);
    } 
  }




  
  public CustomDatum getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);



      
      return paramCustomDatumFactory.create(datum, 0);
    } 
  }




  
  public ORAData getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException {
    synchronized (this.connection) {

      
      Datum datum = getOracleObject(paramInt);



      
      return paramORADataFactory.create(datum, 0);
    } 
  }



  
  public Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory) throws SQLException {
    synchronized (this.connection) {




      
      return paramOracleDataFactory.create(getObject(paramInt), 0);
    } 
  }












  
  public ResultSetMetaData getMetaData() throws SQLException {
    synchronized (this.connection) {

      
      return (ResultSetMetaData)new OracleResultSetMetaData(this.connection, (OracleStatement)this.scrollStmt, this.beginColumnIndex);
    } 
  }




  
  public int findColumn(String paramString) throws SQLException {
    synchronized (this.connection) {
      
      if (this.closed) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      return this.resultSet.findColumn(paramString) - this.beginColumnIndex;
    } 
  }






  
  public void setFetchDirection(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      if (paramInt == 1000) {
        
        this.usrFetchDirection = paramInt;
      }
      else if (paramInt == 1001 || paramInt == 1002) {

        
        this.usrFetchDirection = paramInt;
        
        this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 87);

      
      }
      else {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setFetchDirection");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    } 
  }






  
  public int getFetchDirection() throws SQLException {
    return 1000;
  }


  
  public void setFetchSize(int paramInt) throws SQLException {
    synchronized (this.connection) {

      
      this.resultSet.setFetchSize(paramInt);
    } 
  }


  
  public int getFetchSize() throws SQLException {
    synchronized (this.connection) {

      
      return this.resultSet.getFetchSize();
    } 
  }




  
  public int getType() throws SQLException {
    return this.rsetType;
  }




  
  public int getConcurrency() throws SQLException {
    return this.rsetConcurency;
  }











  
  public void refreshRow() throws SQLException {
    if (!needIdentifier(this.rsetType, this.rsetConcurency)) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "refreshRow");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (isValidRow(this.currentRow)) {
      
      int i = getFetchDirection();

      
      try {
        refreshRowsInCache(this.currentRow, getFetchSize(), i);
      }
      catch (SQLException sQLException1) {

        
        SQLException sQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), sQLException1, 90, "Unsupported syntax for refreshRow()");
        sQLException2.fillInStackTrace();
        throw sQLException2;
      }
    
    }
    else {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82, "refreshRow");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }











  
  private boolean isEmptyResultSet() throws SQLException {
    if (this.numRowsCached != 0)
    {
      return false;
    }
    if (this.numRowsCached == 0 && this.allRowsCached)
    {
      return true;
    }

    
    return !isValidRow(1);
  }









  
  boolean isValidRow(int paramInt) throws SQLException {
    if (paramInt > 0 && paramInt <= this.numRowsCached)
    {
      return true;
    }
    if (paramInt <= 0)
    {
      return false;
    }

    
    return cacheRowAt(paramInt);
  }







  
  private void cacheCurrentRow(OracleResultSetImpl paramOracleResultSetImpl, int paramInt) throws SQLException {
    for (byte b = 0; b < getColumnCount(); b++) {

      
      byte[] arrayOfByte = paramOracleResultSetImpl.privateGetBytes(b + 1);
      OracleResultSet.AuthorizationIndicator authorizationIndicator = paramOracleResultSetImpl.getAuthorizationIndicator(b + 1);
      
      CachedRowElement cachedRowElement = new CachedRowElement(paramInt, b + 1, authorizationIndicator, arrayOfByte);



      
      int i = (paramOracleResultSetImpl.statement.accessors[b]).internalType;
      
      if (i == 112) {
        
        CLOB cLOB = paramOracleResultSetImpl.getCLOB(b + 1);
        cachedRowElement.setData((Datum)cLOB);
      }
      else if (i == 113) {
        
        BLOB bLOB = paramOracleResultSetImpl.getBLOB(b + 1);
        cachedRowElement.setData((Datum)bLOB);
      } 
      
      putCachedValueAt(paramInt, b + 1, cachedRowElement);
    } 
  }











  
  private boolean cacheRowAt(int paramInt) throws SQLException {
    while (this.numRowsCached < paramInt && this.resultSet.next()) {
      cacheCurrentRow(this.resultSet, ++this.numRowsCached);
    }
    if (this.numRowsCached < paramInt) {
      
      this.allRowsCached = true;
      
      return false;
    } 

    
    return true;
  }








  
  private int cacheAllRows() throws SQLException {
    while (this.resultSet.next()) {
      cacheCurrentRow(this.resultSet, ++this.numRowsCached);
    }
    this.allRowsCached = true;
    
    return this.numRowsCached;
  }







  
  int getColumnCount() throws SQLException {
    if (this.columnCount == 0) {


      
      int i = this.resultSet.statement.numberOfDefinePositions;
      
      if (this.resultSet.statement.accessors != null && i > 0) {
        this.columnCount = i;
      } else {
        this.columnCount = getInternalMetadata().getColumnCount();
      } 
    } 
    return this.columnCount;
  }







  
  private ResultSetMetaData getInternalMetadata() throws SQLException {
    if (this.metadata == null) {
      this.metadata = this.resultSet.getMetaData();
    }
    return this.metadata;
  }







  
  private int getLastRow() throws SQLException {
    if (!this.allRowsCached) {
      cacheAllRows();
    }
    return this.numRowsCached;
  }









  
  private int get_refetch_size(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
    byte b1 = (paramInt3 == 1001) ? -1 : 1;

    
    byte b2 = 0;
    
    if (this.refetchRowids == null) {
      this.refetchRowids = new Vector(10);
    } else {
      this.refetchRowids.removeAllElements();
    } 
    
    while (b2 < paramInt2 && isValidRow(paramInt1 + b2 * b1)) {
      
      this.refetchRowids.addElement(getCachedDatumValueAt(paramInt1 + b2 * b1, 1));

      
      b2++;
    } 
    
    return b2;
  }













  
  private OraclePreparedStatement prepare_refetch_statement(int paramInt) throws SQLException {
    if (paramInt < 1) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    PreparedStatement preparedStatement = this.connection.prepareStatement(((OracleStatement)this.scrollStmt).sqlObject.getRefetchSqlForScrollableResultSet(this, paramInt));

    
    return (OraclePreparedStatement)((OraclePreparedStatementWrapper)preparedStatement).preparedStatement;
  }










  
  private void prepare_refetch_binds(OraclePreparedStatement paramOraclePreparedStatement, int paramInt) throws SQLException {
    int i = this.scrollStmt.copyBinds((Statement)paramOraclePreparedStatement, 0);


















    
    for (byte b = 0; b < paramInt; b++)
    {
      paramOraclePreparedStatement.setROWID(i + b + 1, this.refetchRowids.elementAt(b));
    }
  }










  
  private void save_refetch_results(OracleResultSetImpl paramOracleResultSetImpl, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
    byte b = (paramInt3 == 1001) ? -1 : 1;
    
    while (paramOracleResultSetImpl.next()) {
      
      ROWID rOWID = paramOracleResultSetImpl.getROWID(1);
      
      boolean bool = false;
      int i = paramInt1;
      
      while (!bool && i < paramInt1 + paramInt2 * b) {
        
        if (((ROWID)getCachedDatumValueAt(i, 1)).stringValue((Connection)this.connection).equals(rOWID.stringValue((Connection)this.connection))) {
          
          bool = true; continue;
        } 
        i += b;
      } 
      
      if (bool) {
        cacheCurrentRow(paramOracleResultSetImpl, i);
      }
    } 
  }



  
  private Datum getCachedDatumValueAt(int paramInt1, int paramInt2) throws SQLException {
    CachedRowElement cachedRowElement = null;

    
    try {
      cachedRowElement = (CachedRowElement)this.rsetCache.get(paramInt1, paramInt2);
    }
    catch (IOException iOException) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    Datum datum = null;
    
    if (cachedRowElement != null) {
      
      datum = cachedRowElement.getDataAsDatum();
      byte[] arrayOfByte = cachedRowElement.getData();
      
      if (datum == null && arrayOfByte != null && arrayOfByte.length > 0) {

        
        int i = getInternalMetadata().getColumnType(paramInt2);
        int j = getInternalMetadata().getColumnDisplaySize(paramInt2);
        
        int k = (((OracleResultSetMetaData)getInternalMetadata()).getDescription()[paramInt2 - 1]).internalType;


        
        int m = this.scrollStmt.getMaxFieldSize();
        
        if (m > 0 && m < j) {
          j = m;
        }
        String str = null;
        
        if (i == 2006 || i == 2002 || i == 2008 || i == 2007 || i == 2003)
        {




          
          str = getInternalMetadata().getColumnTypeName(paramInt2);
        }
        
        short s = (this.resultSet.statement.accessors[paramInt2 - 1]).formOfUse;
        
        if (s == 2 && (k == 96 || k == 1 || k == 8 || k == 112)) {







          
          datum = SQLUtil.makeNDatum(this.connection, arrayOfByte, k, str, s, j);
        
        }
        else {

          
          datum = SQLUtil.makeDatum(this.connection, arrayOfByte, k, str, j);
        } 

        
        cachedRowElement.setData(datum);
      } 
    } 
    
    return datum;
  }






  
  private void putCachedValueAt(int paramInt1, int paramInt2, CachedRowElement paramCachedRowElement) throws SQLException {
    try {
      this.rsetCache.put(paramInt1, paramInt2, paramCachedRowElement);
    }
    catch (IOException iOException) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }






  
  private void removeCachedRowAt(int paramInt) throws SQLException {
    try {
      this.rsetCache.remove(paramInt);
    }
    catch (IOException iOException) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }








  
  public static boolean needIdentifier(int paramInt1, int paramInt2) {
    if ((paramInt1 == 1003 && paramInt2 == 1007) || (paramInt1 == 1004 && paramInt2 == 1007))
    {
      
      return false;
    }
    return true;
  }





  
  public static boolean needCache(int paramInt1, int paramInt2) {
    if (paramInt1 == 1003 || (paramInt1 == 1004 && paramInt2 == 1007))
    {
      
      return false;
    }
    return true;
  }





  
  public static boolean supportRefreshRow(int paramInt1, int paramInt2) {
    if (paramInt1 == 1003 || (paramInt1 == 1004 && paramInt2 == 1007))
    {
      
      return false;
    }
    return true;
  }















  
  int getFirstUserColumnIndex() {
    return this.beginColumnIndex;
  }


  
  public String getCursorName() throws SQLException {
    synchronized (this.connection) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "getCursorName");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }












  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return this.connection;
  }







  
  OracleStatement getOracleStatement() throws SQLException {
    return (this.resultSet == null) ? null : this.resultSet.getOracleStatement();
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
