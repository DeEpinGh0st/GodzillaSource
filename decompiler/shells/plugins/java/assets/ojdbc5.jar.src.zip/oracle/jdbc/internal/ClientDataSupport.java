package oracle.jdbc.internal;

public interface ClientDataSupport {
  Object getClientData(Object paramObject);
  
  Object setClientData(Object paramObject1, Object paramObject2);
  
  Object removeClientData(Object paramObject);
}
