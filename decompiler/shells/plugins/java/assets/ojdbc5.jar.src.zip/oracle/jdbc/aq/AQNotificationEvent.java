package oracle.jdbc.aq;

import java.sql.SQLException;
import java.util.EventObject;








































public abstract class AQNotificationEvent
  extends EventObject
{
  public enum EventType
  {
    REGULAR(0),


    
    DEREG(1);
    
    private final int code;
    
    EventType(int param1Int1) {
      this.code = param1Int1;
    }




    
    public final int getCode() {
      return this.code;
    }
  }








  
  public enum AdditionalEventType
  {
    NONE(0),


    
    TIMEOUT(1),


    
    GROUPING(2);
    
    private final int code;

    
    AdditionalEventType(int param1Int1) {
      this.code = param1Int1;
    }




    
    public final int getCode() {
      return this.code;
    }



    
    public static final AdditionalEventType getEventType(int param1Int) {
      if (param1Int == TIMEOUT.getCode())
        return TIMEOUT; 
      if (param1Int == GROUPING.getCode()) {
        return GROUPING;
      }
      return NONE;
    }
  }
  
  protected AQNotificationEvent(Object paramObject) {
    super(paramObject);
  }






























































  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
  
  public abstract AQMessageProperties getMessageProperties() throws SQLException;
  
  public abstract String getRegistration() throws SQLException;
  
  public abstract byte[] getPayload() throws SQLException;
  
  public abstract String getQueueName() throws SQLException;
  
  public abstract byte[] getMessageId() throws SQLException;
  
  public abstract String getConsumerName() throws SQLException;
  
  public abstract String getConnectionInformation();
  
  public abstract EventType getEventType();
  
  public abstract AdditionalEventType getAdditionalEventType();
  
  public abstract String toString();
}
