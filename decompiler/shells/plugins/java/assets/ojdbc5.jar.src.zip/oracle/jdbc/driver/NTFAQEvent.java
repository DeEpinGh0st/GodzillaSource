package oracle.jdbc.driver;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.sql.SQLException;
import oracle.jdbc.aq.AQMessageProperties;
import oracle.jdbc.aq.AQNotificationEvent;
import oracle.sql.TIMESTAMP;



































class NTFAQEvent
  extends AQNotificationEvent
{
  private String registrationString;
  private int namespace;
  private byte[] payload;
  private String queueName = null;
  private byte[] messageId = null;
  private String consumerName = null;
  private NTFConnection conn;
  private AQMessagePropertiesI msgProp;
  private AQNotificationEvent.EventType eventType = AQNotificationEvent.EventType.REGULAR;
  private AQNotificationEvent.AdditionalEventType additionalEventType = AQNotificationEvent.AdditionalEventType.NONE;
  
  private ByteBuffer dataBuffer;
  
  private boolean isReady = false;
  
  private short databaseVersion;
  
  NTFAQEvent(NTFConnection paramNTFConnection, short paramShort) throws IOException, InterruptedException {
    super(paramNTFConnection);
    
    this.conn = paramNTFConnection;
    int i = this.conn.readInt();
    byte[] arrayOfByte = new byte[i];
    this.conn.readBuffer(arrayOfByte, 0, i);
    this.dataBuffer = ByteBuffer.wrap(arrayOfByte);
    this.databaseVersion = paramShort;
  }



  
  private void initEvent() throws SQLException {
    byte b1 = this.dataBuffer.get();
    int i = this.dataBuffer.getInt();
    byte[] arrayOfByte1 = new byte[i];
    this.dataBuffer.get(arrayOfByte1, 0, i);
    this.registrationString = this.conn.charset.toString(arrayOfByte1, 0, i);


    
    byte b2 = this.dataBuffer.get();
    int j = this.dataBuffer.getInt();
    byte[] arrayOfByte2 = new byte[j];
    this.dataBuffer.get(arrayOfByte2, 0, j);
    this.namespace = arrayOfByte2[0];

    
    byte b3 = this.dataBuffer.get();
    int k = this.dataBuffer.getInt();
    if (k > 0) {
      
      this.payload = new byte[k];
      this.dataBuffer.get(this.payload, 0, k);
    } else {
      
      this.payload = null;
    } 
    if (this.dataBuffer.hasRemaining()) {
      
      int m = 0;
      if (this.databaseVersion >= 10200) {

        
        byte b = this.dataBuffer.get();
        int i23 = this.dataBuffer.getInt();
        m = this.dataBuffer.getInt();
      } 

      
      byte b4 = this.dataBuffer.get();
      int n = this.dataBuffer.getInt();
      byte[] arrayOfByte3 = new byte[n];
      this.dataBuffer.get(arrayOfByte3, 0, n);
      this.queueName = this.conn.charset.toString(arrayOfByte3, 0, n);


      
      byte b5 = this.dataBuffer.get();
      int i1 = this.dataBuffer.getInt();
      this.messageId = new byte[i1];
      this.dataBuffer.get(this.messageId, 0, i1);

      
      byte b6 = this.dataBuffer.get();
      int i2 = this.dataBuffer.getInt();
      byte[] arrayOfByte4 = new byte[i2];
      this.dataBuffer.get(arrayOfByte4, 0, i2);
      this.consumerName = this.conn.charset.toString(arrayOfByte4, 0, i2);


      
      byte b7 = this.dataBuffer.get();
      int i3 = this.dataBuffer.getInt();
      byte[] arrayOfByte5 = new byte[i3];
      this.dataBuffer.get(arrayOfByte5, 0, i3);

      
      byte b8 = this.dataBuffer.get();
      int i4 = this.dataBuffer.getInt();
      int i5 = this.dataBuffer.getInt();
      if (arrayOfByte5[0] == 1)
        i5 = -i5; 
      int i6 = i5;

      
      byte b9 = this.dataBuffer.get();
      int i7 = this.dataBuffer.getInt();
      int i8 = this.dataBuffer.getInt();

      
      byte b10 = this.dataBuffer.get();
      int i9 = this.dataBuffer.getInt();
      byte[] arrayOfByte6 = new byte[i9];
      this.dataBuffer.get(arrayOfByte6, 0, i9);

      
      byte b11 = this.dataBuffer.get();
      int i10 = this.dataBuffer.getInt();
      int i11 = this.dataBuffer.getInt();
      if (arrayOfByte6[0] == 1)
        i11 = -i11; 
      int i12 = i11;

      
      byte b12 = this.dataBuffer.get();
      int i13 = this.dataBuffer.getInt();
      int i14 = this.dataBuffer.getInt();

      
      byte b13 = this.dataBuffer.get();
      int i15 = this.dataBuffer.getInt();
      byte[] arrayOfByte7 = new byte[i15];
      this.dataBuffer.get(arrayOfByte7, 0, i15);
      TIMESTAMP tIMESTAMP = new TIMESTAMP(arrayOfByte7);

      
      byte b14 = this.dataBuffer.get();
      int i16 = this.dataBuffer.getInt();
      byte[] arrayOfByte8 = new byte[i16];
      this.dataBuffer.get(arrayOfByte8, 0, i16);
      byte b15 = arrayOfByte8[0];

      
      byte b16 = this.dataBuffer.get();
      int i17 = this.dataBuffer.getInt();
      byte[] arrayOfByte9 = new byte[i17];
      this.dataBuffer.get(arrayOfByte9, 0, i17);
      String str1 = this.conn.charset.toString(arrayOfByte9, 0, i17);


      
      byte b17 = this.dataBuffer.get();
      int i18 = this.dataBuffer.getInt();
      byte[] arrayOfByte10 = new byte[i18];
      this.dataBuffer.get(arrayOfByte10, 0, i18);
      String str2 = this.conn.charset.toString(arrayOfByte10, 0, i18);


      
      byte b18 = this.dataBuffer.get();
      int i19 = this.dataBuffer.getInt();
      byte[] arrayOfByte11 = null;
      if (i19 > 0) {
        
        arrayOfByte11 = new byte[i19];
        this.dataBuffer.get(arrayOfByte11, 0, i19);
      } 

      
      byte b19 = this.dataBuffer.get();
      int i20 = this.dataBuffer.getInt();
      byte[] arrayOfByte12 = new byte[i20];
      this.dataBuffer.get(arrayOfByte12, 0, i20);
      String str3 = this.conn.charset.toString(arrayOfByte12, 0, i20);


      
      byte b20 = this.dataBuffer.get();
      int i21 = this.dataBuffer.getInt();
      byte[] arrayOfByte13 = new byte[i21];
      this.dataBuffer.get(arrayOfByte13, 0, i21);
      String str4 = this.conn.charset.toString(arrayOfByte13, 0, i21);


      
      byte b21 = this.dataBuffer.get();
      int i22 = this.dataBuffer.getInt();
      byte b22 = this.dataBuffer.get();



      
      this.msgProp = new AQMessagePropertiesI();
      this.msgProp.setAttempts(i14);
      this.msgProp.setCorrelation(str2);
      this.msgProp.setDelay(i8);
      this.msgProp.setEnqueueTime(tIMESTAMP.timestampValue());
      this.msgProp.setMessageState(AQMessageProperties.MessageState.getMessageState(b15));
      if (this.databaseVersion >= 10200)
        this.msgProp.setDeliveryMode(AQMessageProperties.DeliveryMode.getDeliveryMode(m)); 
      this.msgProp.setPreviousQueueMessageId(arrayOfByte11);
      AQAgentI aQAgentI = new AQAgentI();
      aQAgentI.setAddress(str4);
      aQAgentI.setName(str3);
      aQAgentI.setProtocol(b22);
      this.msgProp.setSender(aQAgentI);
      
      this.msgProp.setPriority(i6);
      this.msgProp.setExpiration(i12);
      this.msgProp.setExceptionQueue(str1);
    } 
    this.isReady = true;
  }



  
  public AQMessageProperties getMessageProperties() throws SQLException {
    if (!this.isReady)
      initEvent(); 
    return this.msgProp;
  }



  
  public String getRegistration() throws SQLException {
    if (!this.isReady)
      initEvent(); 
    return this.registrationString;
  }



  
  public AQNotificationEvent.EventType getEventType() {
    return this.eventType;
  }



  
  public AQNotificationEvent.AdditionalEventType getAdditionalEventType() {
    return this.additionalEventType;
  }



  
  void setEventType(AQNotificationEvent.EventType paramEventType) throws IOException {
    this.eventType = paramEventType;
  }



  
  void setAdditionalEventType(AQNotificationEvent.AdditionalEventType paramAdditionalEventType) {
    this.additionalEventType = paramAdditionalEventType;
  }



  
  public byte[] getPayload() throws SQLException {
    if (!this.isReady)
      initEvent(); 
    return this.payload;
  }



  
  public String getQueueName() throws SQLException {
    if (!this.isReady)
      initEvent(); 
    return this.queueName;
  }



  
  public byte[] getMessageId() throws SQLException {
    if (!this.isReady)
      initEvent(); 
    return this.messageId;
  }



  
  public String getConsumerName() throws SQLException {
    if (!this.isReady)
      initEvent(); 
    return this.consumerName;
  }



  
  public String getConnectionInformation() {
    return this.conn.connectionDescription;
  }




  
  public String toString() {
    if (!this.isReady) {
      
      try {
        
        initEvent();
      }
      catch (SQLException sQLException) {
        
        return sQLException.getMessage();
      } 
    }
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("Connection information  : " + this.conn.connectionDescription + "\n");
    stringBuffer.append("Event type              : " + this.eventType + "\n");
    if (this.additionalEventType != AQNotificationEvent.AdditionalEventType.NONE)
      stringBuffer.append("Additional event type   : " + this.additionalEventType + "\n"); 
    stringBuffer.append("Namespace               : " + this.namespace + "\n");
    stringBuffer.append("Registration            : " + this.registrationString + "\n");
    stringBuffer.append("Queue name              : " + this.queueName + "\n");
    stringBuffer.append("Consumer name           : " + this.consumerName + "\n");
    if (this.payload != null) {
      
      stringBuffer.append("Payload length          : " + this.payload.length + "\n");
      stringBuffer.append("Payload (first 50 bytes): " + byteBufferToHexString(this.payload, 50) + "\n");
    } else {
      
      stringBuffer.append("Payload                 : null\n");
    }  stringBuffer.append("Message ID              : " + byteBufferToHexString(this.messageId, 50) + "\n");
    if (this.msgProp != null)
      stringBuffer.append(this.msgProp.toString()); 
    return stringBuffer.toString();
  }


  
  static final String byteBufferToHexString(byte[] paramArrayOfbyte, int paramInt) {
    if (paramArrayOfbyte == null) {
      return null;
    }
    byte b = 0;
    boolean bool = true;
    StringBuffer stringBuffer = new StringBuffer();
    while (b < paramArrayOfbyte.length && b < paramInt) {
      
      if (!bool) {
        stringBuffer.append(' ');
      } else {
        bool = false;
      }  String str = Integer.toHexString(paramArrayOfbyte[b] & 0xFF);
      if (str.length() == 1)
        str = "0" + str; 
      stringBuffer.append(str);
      b++;
    } 
    return stringBuffer.toString();
  }



  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
