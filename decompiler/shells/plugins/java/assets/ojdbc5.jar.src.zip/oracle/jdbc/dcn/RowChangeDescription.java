package oracle.jdbc.dcn;

import oracle.sql.ROWID;





































public interface RowChangeDescription
{
  RowOperation getRowOperation();
  
  ROWID getRowid();
  
  public enum RowOperation
  {
    INSERT(TableChangeDescription.TableOperation.INSERT.getCode()),


    
    UPDATE(TableChangeDescription.TableOperation.UPDATE.getCode()),


    
    DELETE(TableChangeDescription.TableOperation.DELETE.getCode());
    private final int code;
    
    RowOperation(int param1Int1) {
      this.code = param1Int1;
    }



    
    public final int getCode() {
      return this.code;
    }



    
    public static final RowOperation getRowOperation(int param1Int) {
      if (param1Int == INSERT.getCode())
        return INSERT; 
      if (param1Int == UPDATE.getCode()) {
        return UPDATE;
      }
      return DELETE;
    }
  }
}
