package oracle.jdbc.driver;

import java.nio.ByteBuffer;
import oracle.jdbc.dcn.QueryChangeDescription;
import oracle.jdbc.dcn.TableChangeDescription;






































class NTFDCNQueryChanges
  implements QueryChangeDescription
{
  private final long queryId;
  private final QueryChangeDescription.QueryChangeEventType queryopflags;
  private final int numberOfTables;
  private final NTFDCNTableChanges[] tcdesc;
  
  NTFDCNQueryChanges(ByteBuffer paramByteBuffer, int paramInt) {
    long l1 = (paramByteBuffer.getInt() & 0xFFFFFFFF);
    long l2 = (paramByteBuffer.getInt() & 0xFFFFFFFF);
    this.queryId = l1 | l2 << 32L;
    this.queryopflags = QueryChangeDescription.QueryChangeEventType.getQueryChangeEventType(paramByteBuffer.getInt());
    this.numberOfTables = paramByteBuffer.getShort();
    this.tcdesc = new NTFDCNTableChanges[this.numberOfTables];
    for (byte b = 0; b < this.tcdesc.length; b++) {
      this.tcdesc[b] = new NTFDCNTableChanges(paramByteBuffer, paramInt);
    }
  }


  
  public long getQueryId() {
    return this.queryId;
  }



  
  public QueryChangeDescription.QueryChangeEventType getQueryChangeEventType() {
    return this.queryopflags;
  }



  
  public TableChangeDescription[] getTableChangeDescription() {
    return (TableChangeDescription[])this.tcdesc;
  }



  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("  query ID=" + this.queryId + ", query change event type=" + this.queryopflags + "\n");
    TableChangeDescription[] arrayOfTableChangeDescription = getTableChangeDescription();
    if (arrayOfTableChangeDescription != null) {
      
      stringBuffer.append("  Table Change Description (length=" + arrayOfTableChangeDescription.length + "):");
      for (byte b = 0; b < arrayOfTableChangeDescription.length; b++)
        stringBuffer.append(arrayOfTableChangeDescription[b].toString()); 
    } 
    return stringBuffer.toString();
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
