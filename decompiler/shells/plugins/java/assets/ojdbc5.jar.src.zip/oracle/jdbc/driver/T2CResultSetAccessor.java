package oracle.jdbc.driver;

import java.sql.SQLException;












class T2CResultSetAccessor
  extends ResultSetAccessor
{
  T2CResultSetAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean) throws SQLException {
    super(paramOracleStatement, paramInt1 * 2, paramShort, paramInt2, paramBoolean);
  }



  
  T2CResultSetAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort) throws SQLException {
    super(paramOracleStatement, paramInt1 * 2, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort);
  }










  
  byte[] getBytes(int paramInt) throws SQLException {
    byte[] arrayOfByte = null;
    
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
      byte b = ((T2CConnection)this.statement.connection).byteAlign;
      int i = this.columnIndex + b - 1 & (b - 1 ^ 0xFFFFFFFF);
      
      int j = i + s * paramInt;
      
      arrayOfByte = new byte[s];
      System.arraycopy(this.rowSpaceByte, j, arrayOfByte, 0, s);
    } 
    
    return arrayOfByte;
  }

  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
