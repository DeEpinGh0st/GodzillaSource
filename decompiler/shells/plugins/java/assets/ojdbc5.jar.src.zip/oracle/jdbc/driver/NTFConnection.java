package oracle.jdbc.driver;

import java.io.EOFException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import oracle.jdbc.aq.AQNotificationEvent;
import oracle.jdbc.dcn.DatabaseChangeEvent;
import oracle.sql.CharacterSet;
























































class NTFConnection
  extends Thread
{
  private static final int NS_HEADER_SIZE = 10;
  private SocketChannel channel;
  private ByteBuffer inBuffer = null;
  private ByteBuffer outBuffer = null;

  
  private int currentNSPacketLength;

  
  private int currentNSPacketType;

  
  private ByteBuffer currentNSPacketDataBuffer;
  
  private boolean needsToBeClosed = false;
  
  private NTFManager ntfManager;
  
  private Selector selector = null;
  private Iterator iterator = null;
  private SelectionKey aKey = null;
  
  int remotePort;
  
  String remoteAddress;
  
  String remoteName;
  int localPort;
  String localAddress;
  String localName;
  String connectionDescription;
  CharacterSet charset = null;
  
  static final int NSPTCN = 1;
  
  static final int NSPTAC = 2;
  
  static final int NSPTAK = 3;
  
  static final int NSPTRF = 4;
  
  static final int NSPTRD = 5;
  
  static final int NSPTDA = 6;
  static final int NSPTNL = 7;
  static final int NSPTAB = 9;
  static final int NSPTRS = 11;
  static final int NSPTMK = 12;
  static final int NSPTAT = 13;
  static final int NSPTCNL = 14;
  static final int NSPTHI = 19;
  static final short KPDNFY_TIMEOUT = 1;
  static final short KPDNFY_GROUPING = 2;
  
  NTFConnection(NTFManager paramNTFManager, SocketChannel paramSocketChannel) {
    try {
      this.ntfManager = paramNTFManager;
      this.channel = paramSocketChannel;
      this.channel.configureBlocking(false);














      
      this.inBuffer = ByteBuffer.allocate(4096);
      this.outBuffer = ByteBuffer.allocate(2048);
      Socket socket = this.channel.socket();
      InetAddress inetAddress1 = socket.getInetAddress();
      InetAddress inetAddress2 = socket.getLocalAddress();
      this.remotePort = socket.getPort();
      this.localPort = socket.getLocalPort();
      this.remoteAddress = inetAddress1.getHostAddress();
      this.remoteName = inetAddress1.getHostName();
      this.localAddress = inetAddress2.getHostAddress();
      this.localName = inetAddress2.getHostName();
      this.connectionDescription = "local=" + this.localName + "/" + this.localAddress + ":" + this.localPort + ", remote=" + this.remoteName + "/" + this.remoteAddress + ":" + this.remotePort;


    
    }
    catch (IOException iOException) {}
  }






  
  public void run() {
    
    try { this.selector = Selector.open();
      this.channel.register(this.selector, 1);
      
      int i = 0;

      
      this.inBuffer.limit(0);
      
      while (!this.needsToBeClosed) {

        
        if (!this.inBuffer.hasRemaining()) {
          do {
            i = readFromNetwork();
          }
          while (i == 0);
        }
        unmarshalOneNSPacket();
      }  }
    catch (IOException iOException)
    
    { 
      try {



        
        this.selector.close();
        this.channel.close();
      } catch (IOException iOException1) {} } catch (InterruptedException interruptedException) { try { this.selector.close(); this.channel.close(); } catch (IOException iOException) {} } finally { try { this.selector.close(); this.channel.close(); } catch (IOException iOException) {} }
  
  }

























  
  private int readFromNetwork() throws IOException, InterruptedException {
    this.inBuffer.compact();
    
    while (true) {
      if (this.iterator == null || !this.iterator.hasNext()) {





        
        this.selector.select();


        
        if (this.needsToBeClosed)
        {
          throw new InterruptedException();
        }
        this.iterator = this.selector.selectedKeys().iterator(); continue;
      } 
      this.aKey = this.iterator.next();
      
      if ((this.aKey.readyOps() & 0x1) == 1) {
        break;
      }
    } 






    
    int i = this.channel.read(this.inBuffer);
    
    if (i < 0)
    {
      throw new EOFException(); } 
    if (i > 0)
    {
      
      this.inBuffer.flip();
    }

    
    this.iterator.remove();
    
    return i;
  }













  
  private void getNextNSPacket() throws IOException, InterruptedException {
    while (!this.inBuffer.hasRemaining() || this.inBuffer.remaining() < 10) {
      int k = readFromNetwork();
    }
    
    this.currentNSPacketLength = this.inBuffer.getShort();

    
    if (this.currentNSPacketLength <= 0) {
      throw new IOException("Invalid NS packet length.");
    }

    
    this.inBuffer.position(this.inBuffer.position() + 2);
    
    this.currentNSPacketType = this.inBuffer.get();

    
    validatePacketType();
    
    this.inBuffer.position(this.inBuffer.position() + 5);


    
    while (this.inBuffer.remaining() < this.currentNSPacketLength - 10)
    {
      int k = readFromNetwork();
    }

    
    int i = this.inBuffer.limit();
    int j = this.inBuffer.position() + this.currentNSPacketLength - 10;


    
    this.inBuffer.limit(j);
    this.currentNSPacketDataBuffer = this.inBuffer.slice();
    this.inBuffer.limit(i);
    
    this.inBuffer.position(j);
  }















  
  private void unmarshalOneNSPacket() throws IOException, InterruptedException {
    getNextNSPacket();


    
    if (this.currentNSPacketDataBuffer.hasRemaining()) {
      byte[] arrayOfByte;
      switch (this.currentNSPacketType) {

        
        case 1:
          arrayOfByte = new byte[] { 0, 24, 0, 0, 2, 0, 0, 0, 1, 52, 0, 0, 8, 0, Byte.MAX_VALUE, -1, 1, 0, 0, 0, 0, 24, 65, 1 };






          
          this.outBuffer.clear();
          this.outBuffer.put(arrayOfByte);
          this.outBuffer.limit(24);
          this.outBuffer.rewind();
          this.channel.write(this.outBuffer);
          break;
        
        case 6:
          if (this.currentNSPacketDataBuffer.get(0) == -34 && this.currentNSPacketDataBuffer.get(1) == -83) {

            
            byte[] arrayOfByte1 = { 0, Byte.MAX_VALUE, 0, 0, 6, 0, 0, 0, 0, 0, -34, -83, -66, -17, 0, 117, 10, 32, 1, 0, 0, 4, 0, 0, 4, 0, 3, 0, 0, 0, 0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 2, 0, 6, 0, 31, 0, 14, 0, 1, -34, -83, -66, -17, 0, 3, 0, 0, 0, 2, 0, 4, 0, 1, 0, 1, 0, 2, 0, 0, 0, 0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 2, 0, 6, -5, -1, 0, 2, 0, 2, 0, 0, 0, 0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 1, 0, 2, 0, 0, 3, 0, 2, 0, 0, 0, 0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 1, 0, 2, 0 };
































            
            this.outBuffer.clear();
            this.outBuffer.put(arrayOfByte1);
            this.outBuffer.limit(arrayOfByte1.length);
            this.outBuffer.rewind();
            this.channel.write(this.outBuffer);




















            
            break;
          } 




















          
          unmarshalNSDataPacket();
          break;
      } 
    } 
  }









































































  
  private void unmarshalNSDataPacket() throws IOException, InterruptedException {
    short s1 = readShort();

    
    int i = readInt();
    
    byte b1 = readByte();
    int j = readInt();
    short s2 = readShort();
    if (this.charset == null || this.charset.getOracleId() != s2) {
      this.charset = CharacterSet.make(s2);
    }

    
    byte b2 = readByte();
    int k = readInt();
    short s3 = readShort();

    
    byte b3 = readByte();
    int m = readInt();
    short s4 = readShort();




    
    int n = (i - 21) / 9;
    int[] arrayOfInt = new int[n];
    
    for (byte b = 0; b < n; b++) {
      byte b4 = readByte();
      int i2 = readInt();
      byte[] arrayOfByte = new byte[i2];
      readBuffer(arrayOfByte, 0, i2);



      
      for (byte b5 = 0; b5 < i2; b5++) {
        if (b5 < 4) {
          arrayOfInt[b] = arrayOfInt[b] | (arrayOfByte[b5] & 0xFF) << 8 * (i2 - b5 - 1);
        }
      } 
    } 

    
    NTFDCNEvent nTFDCNEvent = null;
    NTFAQEvent nTFAQEvent = null;
    int i1 = 0;
    short s5 = 0;
    NTFRegistration[] arrayOfNTFRegistration = null;

    
    if (s1 >= 2) {
      
      short s = readShort();
      arrayOfNTFRegistration = new NTFRegistration[arrayOfInt.length];
      for (byte b4 = 0; b4 < arrayOfInt.length; b4++) {
        arrayOfNTFRegistration[b4] = this.ntfManager.getRegistration(arrayOfInt[b4]);
        if (arrayOfNTFRegistration[b4] != null) {
          i1 = arrayOfNTFRegistration[b4].getNamespace();
          s5 = arrayOfNTFRegistration[b4].getDatabaseVersion();
        } 
      } 
      
      if (i1 == 2) {
        
        nTFDCNEvent = new NTFDCNEvent(this, s5);
      }
      else if (i1 == 1) {
        
        nTFAQEvent = new NTFAQEvent(this, s5);
      }
      else if (i1 == 0) {
      
      } 
    } 






    
    short s6 = 0;
    if (s1 >= 3) {
      
      short s = readShort();
      int i2 = readInt();
      byte b4 = readByte();
      int i3 = readInt();
      s6 = readShort();
      if (i1 == 2 && nTFDCNEvent != null) {
        
        nTFDCNEvent.setAdditionalEventType(DatabaseChangeEvent.AdditionalEventType.getEventType(s6));

        
        if (s6 == 1) {
          nTFDCNEvent.setEventType(DatabaseChangeEvent.EventType.DEREG);
        
        }
      }
      else if (i1 == 1 && nTFAQEvent != null) {
        
        nTFAQEvent.setAdditionalEventType(AQNotificationEvent.AdditionalEventType.getEventType(s6));

        
        if (s6 == 1) {
          nTFAQEvent.setEventType(AQNotificationEvent.EventType.DEREG);
        }
      } 
    } 

    
    if (s1 > 3);


    
    if (arrayOfNTFRegistration != null) {
      if (i1 == 2) {
        for (byte b4 = 0; b4 < arrayOfNTFRegistration.length; b4++) {
          if (arrayOfNTFRegistration[b4] != null && nTFDCNEvent != null) {
            arrayOfNTFRegistration[b4].notify(nTFDCNEvent);
          }
        }
      
      } else if (i1 == 1) {
        for (byte b4 = 0; b4 < arrayOfNTFRegistration.length; b4++) {
          if (arrayOfNTFRegistration[b4] != null && nTFAQEvent != null) {
            arrayOfNTFRegistration[b4].notify(nTFAQEvent);
          }
        } 
      } 
    }
  }











  
  void closeThisConnection() {
    this.needsToBeClosed = true;
  }








  
  byte readByte() throws IOException, InterruptedException {
    byte b = 0;
    if (this.currentNSPacketDataBuffer.hasRemaining()) {
      b = this.currentNSPacketDataBuffer.get();
    } else {
      
      getNextNSPacket();
      b = this.currentNSPacketDataBuffer.get();
    } 
    return b;
  }







  
  short readShort() throws IOException, InterruptedException {
    short s = 0;
    if (this.currentNSPacketDataBuffer.remaining() >= 2) {
      s = this.currentNSPacketDataBuffer.getShort();
    
    }
    else {

      
      int i = readByte() & 0xFF;
      int j = readByte() & 0xFF;
      s = (short)(i << 8 | j);
    } 
    return s;
  }







  
  int readInt() throws IOException, InterruptedException {
    int i = 0;
    if (this.currentNSPacketDataBuffer.remaining() >= 4) {
      i = this.currentNSPacketDataBuffer.getInt();
    
    }
    else {

      
      int j = readByte() & 0xFF;
      int k = readByte() & 0xFF;
      int m = readByte() & 0xFF;
      int n = readByte() & 0xFF;
      i = j << 24 | k << 16 | m << 8 | n;
    } 
    return i;
  }







  
  long readLong() throws IOException, InterruptedException {
    long l = 0L;
    if (this.currentNSPacketDataBuffer.remaining() >= 8) {
      l = this.currentNSPacketDataBuffer.getLong();
    
    }
    else {

      
      long l1 = (readByte() & 0xFF);
      long l2 = (readByte() & 0xFF);
      long l3 = (readByte() & 0xFF);
      long l4 = (readByte() & 0xFF);
      long l5 = (readByte() & 0xFF);
      long l6 = (readByte() & 0xFF);
      long l7 = (readByte() & 0xFF);
      long l8 = (readByte() & 0xFF);
      l = l1 << 56L | l2 << 48L | l3 << 40L | l4 << 32L | l5 << 24L | l6 << 16L | l7 << 8L | l8;
    } 
    
    return l;
  }










  
  void readBuffer(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException, InterruptedException {
    if (this.currentNSPacketDataBuffer.remaining() >= paramInt2) {
      this.currentNSPacketDataBuffer.get(paramArrayOfbyte, paramInt1, paramInt2);
    } else {
      
      boolean bool = false;
      int i = 0;
      int j = 0;
      int k = this.currentNSPacketDataBuffer.remaining();
      
      this.currentNSPacketDataBuffer.get(paramArrayOfbyte, paramInt1, k);
      
      paramInt1 += k;
      i += k;
      
      while (!bool) {
        
        getNextNSPacket();
        k = this.currentNSPacketDataBuffer.remaining();
        j = Math.min(k, paramInt2 - i);

        
        this.currentNSPacketDataBuffer.get(paramArrayOfbyte, paramInt1, j);
        paramInt1 += j;
        i += j;
        if (i == paramInt2) {
          bool = true;
        }
      } 
    } 
  }







  
  private String packetToString(ByteBuffer paramByteBuffer) throws IOException {
    byte b = 0;
    
    char[] arrayOfChar = new char[8];
    StringBuffer stringBuffer = new StringBuffer();
    int i = paramByteBuffer.position();
    
    while (paramByteBuffer.hasRemaining()) {
      byte b1 = paramByteBuffer.get();
      String str = Integer.toHexString(b1 & 0xFF);
      str = str.toUpperCase();
      if (str.length() == 1) {
        str = "0" + str;
      }
      stringBuffer.append(str);
      stringBuffer.append(' ');
      if (b1 > 32 && b1 < Byte.MAX_VALUE) {
        arrayOfChar[b] = (char)b1;
      } else {
        
        arrayOfChar[b] = '.';
      } 
      b++;
      if (b == 8) {
        stringBuffer.append('|');
        stringBuffer.append(arrayOfChar);
        stringBuffer.append('|');
        stringBuffer.append('\n');
        b = 0;
      } 
    } 
    if (b != 0) {
      int j = 8 - b; byte b1;
      for (b1 = 0; b1 < j * 3; b1++) {
        stringBuffer.append(' ');
      }
      stringBuffer.append('|');
      stringBuffer.append(arrayOfChar, 0, b);
      for (b1 = 0; b1 < j; b1++) {
        stringBuffer.append(' ');
      }
      stringBuffer.append('|');
      stringBuffer.append('\n');
    } 
    stringBuffer.append("\nEnd of Packet\n\n");
    paramByteBuffer.position(i);
    return stringBuffer.toString();
  }




  
  private void validatePacketType() throws IOException {
    if (this.currentNSPacketType < 1 || this.currentNSPacketType > 19)
    {
      throw new IOException("Invalid NS packet type.");
    }
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
