package oracle.jdbc.rowset;

import java.io.Reader;
import java.sql.SQLException;
import javax.sql.RowSetInternal;
import javax.sql.rowset.WebRowSet;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXParseException;
import org.xml.sax.XMLReader;






















































class OracleWebRowSetXmlReaderImpl
  implements OracleWebRowSetXmlReader
{
  private static final String JAVA_SAXPARSER_PROPERTY = "javax.xml.parsers.SAXParserFactory";
  private static final String JAVA_DOMPARSER_PROPERTY = "javax.xml.parsers.DocumentBuilderFactory";
  private static final String ORACLE_JAXP_SAXPARSER_FACTORY = "oracle.xml.jaxp.JXSAXParserFactory";
  private static final String ORACLE_JAXP_DOMPARSER_FACTORY = "oracle.xml.jaxp.JXDocumentBuilderFactory";
  private static final String JAXP_SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
  private static final String JAXP_SCHEMA_SOURCE = "http://java.sun.com/xml/jaxp/properties/schemaSource";
  private static final String W3C_XML_SCHEMA = "http://www.w3.org/2001/XMLSchema";
  private static final String WEBROWSET_SCHEMA = "http://java.sun.com/xml/ns/jdbc/webrowset.xsd";
  private Document document = null;
  private String parserStr = null;


























  
  public void readXML(WebRowSet paramWebRowSet, Reader paramReader) throws SQLException {
    this.parserStr = getSystemProperty("javax.xml.parsers.SAXParserFactory");
    if (this.parserStr != null) {
      
      readXMLSax((OracleWebRowSet)paramWebRowSet, paramReader);
    }
    else {
      
      this.parserStr = getSystemProperty("javax.xml.parsers.DocumentBuilderFactory");
      if (this.parserStr != null) {
        
        readXMLDom((OracleWebRowSet)paramWebRowSet, paramReader);
      } else {
        
        throw new SQLException("No valid JAXP parser property specified");
      } 
    } 
  }






  
  public void readData(RowSetInternal paramRowSetInternal) throws SQLException {}






  
  private void readXMLSax(OracleWebRowSet paramOracleWebRowSet, Reader paramReader) throws SQLException {
    try {
      InputSource inputSource = new InputSource(paramReader);
      OracleWebRowSetXmlReaderContHandler oracleWebRowSetXmlReaderContHandler = new OracleWebRowSetXmlReaderContHandler(paramOracleWebRowSet);

      
      SAXParserFactory sAXParserFactory = SAXParserFactory.newInstance();

      
      sAXParserFactory.setNamespaceAware(true);
      sAXParserFactory.setValidating(true);
      SAXParser sAXParser = sAXParserFactory.newSAXParser();

      
      sAXParser.setProperty("http://java.sun.com/xml/jaxp/properties/schemaLanguage", "http://www.w3.org/2001/XMLSchema");
      sAXParser.setProperty("http://java.sun.com/xml/jaxp/properties/schemaSource", "http://java.sun.com/xml/ns/jdbc/webrowset.xsd");
      
      XMLReader xMLReader = sAXParser.getXMLReader();
      xMLReader.setContentHandler(oracleWebRowSetXmlReaderContHandler);












      
      xMLReader.parse(inputSource);
    }
    catch (SAXParseException sAXParseException) {
      
      System.out.println("** Parsing error, line " + sAXParseException.getLineNumber() + ", uri " + sAXParseException.getSystemId());

      
      System.out.println("   " + sAXParseException.getMessage());
      sAXParseException.printStackTrace();
      throw new SQLException(sAXParseException.getMessage());
    
    }
    catch (SAXNotRecognizedException sAXNotRecognizedException) {
      
      sAXNotRecognizedException.printStackTrace();
      throw new SQLException("readXMLSax: SAXNotRecognizedException: " + sAXNotRecognizedException.getMessage());
    }
    catch (SAXException sAXException) {
      
      sAXException.printStackTrace();
      throw new SQLException("readXMLSax: SAXException: " + sAXException.getMessage());
    }
    catch (FactoryConfigurationError factoryConfigurationError) {
      
      factoryConfigurationError.printStackTrace();
      throw new SQLException("readXMLSax: Parser factory config: " + factoryConfigurationError.getMessage());
    }
    catch (ParserConfigurationException parserConfigurationException) {
      
      parserConfigurationException.printStackTrace();
      throw new SQLException("readXMLSax: Parser config: " + parserConfigurationException.getMessage());
    }
    catch (Exception exception) {
      
      exception.printStackTrace();
      throw new SQLException("readXMLSax: " + exception.getMessage());
    } 
  }




  
  private void readXMLDom(OracleWebRowSet paramOracleWebRowSet, Reader paramReader) throws SQLException {
    try {
      InputSource inputSource = new InputSource(paramReader);
      OracleWebRowSetXmlReaderDomHandler oracleWebRowSetXmlReaderDomHandler = new OracleWebRowSetXmlReaderDomHandler(paramOracleWebRowSet);


















      
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();


      
      documentBuilderFactory.setNamespaceAware(true);
      documentBuilderFactory.setValidating(true);

      
      documentBuilderFactory.setAttribute("http://java.sun.com/xml/jaxp/properties/schemaLanguage", "http://www.w3.org/2001/XMLSchema");
      documentBuilderFactory.setAttribute("http://java.sun.com/xml/jaxp/properties/schemaSource", "http://java.sun.com/xml/ns/jdbc/webrowset.xsd");
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      
      this.document = documentBuilder.parse(inputSource);

      
      oracleWebRowSetXmlReaderDomHandler.readXMLDocument(this.document);
    }
    catch (SAXException sAXException) {
      
      sAXException.printStackTrace();
      throw new SQLException("readXMLDom: SAXException: " + sAXException.getMessage());
    
    }
    catch (FactoryConfigurationError factoryConfigurationError) {
      
      factoryConfigurationError.printStackTrace();
      throw new SQLException("readXMLDom: Parser factory config: " + factoryConfigurationError.getMessage());
    }
    catch (ParserConfigurationException parserConfigurationException) {
      
      parserConfigurationException.printStackTrace();
      throw new SQLException("readXMLDom: Parser config: " + parserConfigurationException.getMessage());
    }
    catch (Exception exception) {
      
      exception.printStackTrace();
      throw new SQLException("readXMLDom: " + exception.getMessage());
    } 
  }


  
  private String getSystemProperty(String paramString) {
    String str = null;
    
    try {
      str = System.getProperty(paramString);
    }
    catch (SecurityException securityException) {
      
      str = null;
    } 
    
    return str;
  }

  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
