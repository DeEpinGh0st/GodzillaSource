package oracle.jdbc.driver;

import java.math.BigDecimal;
import java.sql.SQLException;
import oracle.sql.CHAR;
import oracle.sql.CharacterSet;
import oracle.sql.Datum;
import oracle.sql.NUMBER;





















class PlsqlIndexTableAccessor
  extends Accessor
{
  int elementInternalType;
  int maxNumberOfElements;
  int elementMaxLen;
  int ibtValueIndex;
  int ibtIndicatorIndex;
  int ibtLengthIndex;
  int ibtMetaIndex;
  int ibtByteLength;
  int ibtCharLength;
  
  PlsqlIndexTableAccessor(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, boolean paramBoolean) throws SQLException {
    init(paramOracleStatement, 998, 998, paramShort, paramBoolean);
    this.elementInternalType = paramInt2;
    this.maxNumberOfElements = paramInt4;



    
    this.elementMaxLen = paramInt3;

    
    initForDataAccess(paramInt1, paramInt3, (String)null);
  }




  
  void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
    if (paramInt1 != 0) {
      this.externalType = paramInt1;
    }
    switch (this.elementInternalType) {


      
      case 1:
      case 96:
        this.internalTypeMaxLength = ((OraclePreparedStatement)this.statement).maxIbtVarcharElementLength;

        
        if (paramInt2 > this.internalTypeMaxLength) {
          
          SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
          sQLException1.fillInStackTrace();
          throw sQLException1;
        } 



        
        this.elementMaxLen = ((paramInt2 == 0) ? this.internalTypeMaxLength : paramInt2) + 1;



        
        this.ibtCharLength = this.elementMaxLen * this.maxNumberOfElements;
        
        this.elementInternalType = 9;
        return;

      
      case 6:
        this.internalTypeMaxLength = 21;
        this.elementMaxLen = this.internalTypeMaxLength + 1;
        this.ibtByteLength = this.elementMaxLen * this.maxNumberOfElements;
        return;
    } 


    
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97);
    sQLException.fillInStackTrace();
    throw sQLException;
  }









  
  Object[] getPlsqlIndexTable(int paramInt) throws SQLException {
    BigDecimal[] arrayOfBigDecimal;
    char[] arrayOfChar;
    byte b1;
    byte[] arrayOfByte;
    byte b2;
    String[] arrayOfString = null;
    short[] arrayOfShort = this.statement.ibtBindIndicators;
    int i = ((arrayOfShort[this.ibtMetaIndex + 4] & 0xFFFF) << 16) + (arrayOfShort[this.ibtMetaIndex + 5] & 0xFFFF);

    
    int j = this.ibtValueIndex;

    
    switch (this.elementInternalType) {

      
      case 9:
        arrayOfString = new String[i];
        arrayOfChar = this.statement.ibtBindChars;
        
        for (b1 = 0; b1 < i; b1++) {
          
          if (arrayOfShort[this.ibtIndicatorIndex + b1] == -1) {
            
            arrayOfString[b1] = null;
          }
          else {
            
            arrayOfString[b1] = new String(arrayOfChar, j + 1, arrayOfChar[j] >> 1);
          } 


          
          j += this.elementMaxLen;
        } 



































        
        return (Object[])arrayOfString;case 6: arrayOfBigDecimal = new BigDecimal[i]; arrayOfByte = this.statement.ibtBindBytes; for (b2 = 0; b2 < i; b2++) { if (arrayOfShort[this.ibtIndicatorIndex + b2] == -1) { arrayOfBigDecimal[b2] = null; } else { byte b = arrayOfByte[j]; byte[] arrayOfByte1 = new byte[b]; System.arraycopy(arrayOfByte, j + 1, arrayOfByte1, 0, b); arrayOfBigDecimal[b2] = NUMBER.toBigDecimal(arrayOfByte1); }  j += this.elementMaxLen; }  return (Object[])arrayOfBigDecimal;
    } 
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97);
    sQLException.fillInStackTrace();
    throw sQLException;
  }


  
  Datum[] getOraclePlsqlIndexTable(int paramInt) throws SQLException {
    NUMBER[] arrayOfNUMBER;
    CharacterSet characterSet;
    char[] arrayOfChar;
    byte b1;
    byte[] arrayOfByte;
    byte b2;
    CHAR[] arrayOfCHAR = null;
    short[] arrayOfShort = this.statement.ibtBindIndicators;
    int i = ((arrayOfShort[this.ibtMetaIndex + 4] & 0xFFFF) << 16) + (arrayOfShort[this.ibtMetaIndex + 5] & 0xFFFF);

    
    int j = this.ibtValueIndex;

    
    switch (this.elementInternalType) {

      
      case 9:
        arrayOfCHAR = new CHAR[i];
        
        characterSet = CharacterSet.make(2000);
        arrayOfChar = this.statement.ibtBindChars;
        
        for (b1 = 0; b1 < i; b1++) {
          
          if (arrayOfShort[this.ibtIndicatorIndex + b1] == -1) {
            
            arrayOfCHAR[b1] = null;
          }
          else {
            
            char c = arrayOfChar[j];
            byte[] arrayOfByte1 = new byte[c];
            
            DBConversion.javaCharsToUcs2Bytes(arrayOfChar, j + 1, arrayOfByte1, 0, c >> 1);

            
            arrayOfCHAR[b1] = new CHAR(arrayOfByte1, characterSet);
          } 
          
          j += this.elementMaxLen;
        } 



































        
        return (Datum[])arrayOfCHAR;case 6: arrayOfNUMBER = new NUMBER[i]; arrayOfByte = this.statement.ibtBindBytes; for (b2 = 0; b2 < i; b2++) { if (arrayOfShort[this.ibtIndicatorIndex + b2] == -1) { arrayOfNUMBER[b2] = null; } else { byte b = arrayOfByte[j]; byte[] arrayOfByte1 = new byte[b]; System.arraycopy(arrayOfByte, j + 1, arrayOfByte1, 0, b); arrayOfNUMBER[b2] = new NUMBER(arrayOfByte1); }  j += this.elementMaxLen; }  return (Datum[])arrayOfNUMBER;
    } 
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97);
    sQLException.fillInStackTrace();
    throw sQLException;
  } private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
