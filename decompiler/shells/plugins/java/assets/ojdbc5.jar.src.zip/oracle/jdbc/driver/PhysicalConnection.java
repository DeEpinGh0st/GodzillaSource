package oracle.jdbc.driver;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.security.Permission;
import java.security.PrivilegedAction;
import java.sql.Array;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Savepoint;
import java.sql.Statement;
import java.sql.Struct;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.EnumSet;
import java.util.Enumeration;
import java.util.GregorianCalendar;
import java.util.Hashtable;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;
import java.util.Vector;
import java.util.regex.Pattern;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.OracleSQLPermission;
import oracle.jdbc.OracleSavepoint;
import oracle.jdbc.OracleStatement;
import oracle.jdbc.aq.AQDequeueOptions;
import oracle.jdbc.aq.AQEnqueueOptions;
import oracle.jdbc.aq.AQMessage;
import oracle.jdbc.aq.AQNotificationRegistration;
import oracle.jdbc.dcn.DatabaseChangeRegistration;
import oracle.jdbc.internal.KeywordValueLong;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.internal.OracleStatement;
import oracle.jdbc.internal.XSEventListener;
import oracle.jdbc.internal.XSNamespace;
import oracle.jdbc.oracore.OracleTypeADT;
import oracle.jdbc.pool.OracleConnectionCacheCallback;
import oracle.jdbc.pool.OraclePooledConnection;
import oracle.net.nt.CustomSSLSocketFactory;
import oracle.security.pki.OracleSecretStore;
import oracle.security.pki.OracleWallet;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.BFILE;
import oracle.sql.BINARY_DOUBLE;
import oracle.sql.BINARY_FLOAT;
import oracle.sql.BLOB;
import oracle.sql.BfileDBAccess;
import oracle.sql.BlobDBAccess;
import oracle.sql.CLOB;
import oracle.sql.CharacterSet;
import oracle.sql.CustomDatum;
import oracle.sql.DATE;
import oracle.sql.Datum;
import oracle.sql.INTERVALDS;
import oracle.sql.INTERVALYM;
import oracle.sql.NCLOB;
import oracle.sql.NUMBER;
import oracle.sql.SQLName;
import oracle.sql.StructDescriptor;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;
import oracle.sql.TIMEZONETAB;
import oracle.sql.TypeDescriptor;

abstract class PhysicalConnection extends OracleConnection {
  public static final String SECRET_STORE_CONNECT = "oracle.security.client.connect_string";
  public static final String SECRET_STORE_USERNAME = "oracle.security.client.username";
  public static final String SECRET_STORE_PASSWORD = "oracle.security.client.password";
  public static final String SECRET_STORE_DEFAULT_USERNAME = "oracle.security.client.default_username";
  public static final String SECRET_STORE_DEFAULT_PASSWORD = "oracle.security.client.default_password";
  static final CRC64 CHECKSUM = new CRC64();
  public static final char slash_character = '/';
  public static final char at_sign_character = '@';
  public static final char left_square_bracket_character = '[';
  public static final char right_square_bracket_character = ']';
  static final byte[] EMPTY_BYTE_ARRAY = new byte[0];



  
  long outScn = 0L;
  
  char[][] charOutput = new char[1][];
  byte[][] byteOutput = new byte[1][];
  short[][] shortOutput = new short[1][];




  
  Properties sessionProperties = null;
  
  boolean retainV9BindBehavior;
  
  String userName;
  
  String database;
  
  boolean autocommit;
  
  String protocol;
  
  int streamChunkSize;
  
  boolean setFloatAndDoubleUseBinary;
  String thinVsessionTerminal;
  String thinVsessionMachine;
  String thinVsessionOsuser;
  String thinVsessionProgram;
  String thinVsessionProcess;
  String thinVsessionIname;
  String thinVsessionEname;
  String thinNetProfile;
  String thinNetAuthenticationServices;
  String thinNetAuthenticationKrb5Mutual;
  String thinNetAuthenticationKrb5CcName;
  String thinNetEncryptionLevel;
  String thinNetEncryptionTypes;
  String thinNetChecksumLevel;
  String thinNetChecksumTypes;
  String thinNetCryptoSeed;
  boolean thinTcpNoDelay;
  String thinReadTimeout;
  String thinNetConnectTimeout;
  boolean thinNetDisableOutOfBandBreak;
  boolean thinNetUseZeroCopyIO;
  boolean thinNetEnableSDP;
  boolean use1900AsYearForTime;
  boolean timestamptzInGmt;
  boolean timezoneAsRegion;
  String thinSslServerDnMatch;
  String thinSslVersion;
  String thinSslCipherSuites;
  String thinJavaxNetSslKeystore;
  String thinJavaxNetSslKeystoretype;
  String thinJavaxNetSslKeystorepassword;
  String thinJavaxNetSslTruststore;
  String thinJavaxNetSslTruststoretype;
  String thinJavaxNetSslTruststorepassword;
  String thinSslKeymanagerfactoryAlgorithm;
  String thinSslTrustmanagerfactoryAlgorithm;
  String thinNetOldsyntax;
  String thinNamingContextInitial;
  String thinNamingProviderUrl;
  String thinNamingSecurityAuthentication;
  String thinNamingSecurityPrincipal;
  String thinNamingSecurityCredentials;
  String walletLocation;
  String walletPassword;
  String proxyClientName;
  boolean useNio;
  String ociDriverCharset;
  String editionName;
  String logonCap;
  String internalLogon;
  boolean createDescriptorUseCurrentSchemaForSchemaName;
  long ociSvcCtxHandle;
  long ociEnvHandle;
  long ociErrHandle;
  boolean prelimAuth;
  boolean nlsLangBackdoor;
  String setNewPassword;
  boolean spawnNewThreadToCancel;
  int defaultExecuteBatch;
  int defaultRowPrefetch;
  int defaultLobPrefetchSize;
  boolean enableDataInLocator;
  boolean enableReadDataInLocator;
  boolean overrideEnableReadDataInLocator;
  boolean reportRemarks;
  boolean includeSynonyms;
  boolean restrictGettables;
  boolean accumulateBatchResult;
  boolean useFetchSizeWithLongColumn;
  boolean processEscapes;
  boolean fixedString;
  boolean defaultnchar;
  boolean permitTimestampDateMismatch;
  String resourceManagerId;
  boolean disableDefinecolumntype;
  boolean convertNcharLiterals;
  boolean j2ee13Compliant;
  boolean mapDateToTimestamp;
  boolean useThreadLocalBufferCache;
  String driverNameAttribute;
  int maxCachedBufferSize;
  int implicitStatementCacheSize;
  boolean lobStreamPosStandardCompliant;
  boolean isStrictAsciiConversion;
  boolean isQuickAsciiConversion;
  boolean thinForceDnsLoadBalancing;
  boolean enableJavaNetFastPath;
  boolean enableTempLobRefCnt;
  boolean plsqlVarcharParameter4KOnly;
  boolean keepAlive;
  public boolean calculateChecksum;
  String url;
  String savedUser;
  int commitOption;
  int ociConnectionPoolMinLimit = 0;
  int ociConnectionPoolMaxLimit = 0;
  int ociConnectionPoolIncrement = 0;
  int ociConnectionPoolTimeout = 0;
  boolean ociConnectionPoolNoWait = false;
  boolean ociConnectionPoolTransactionDistributed = false;
  String ociConnectionPoolLogonMode = null;
  boolean ociConnectionPoolIsPooling = false;
  Object ociConnectionPoolObject = null;
  Object ociConnectionPoolConnID = null;
  String ociConnectionPoolProxyType = null;
  Integer ociConnectionPoolProxyNumRoles = Integer.valueOf(0);
  Object ociConnectionPoolProxyRoles = null;
  String ociConnectionPoolProxyUserName = null;
  String ociConnectionPoolProxyPassword = null;
  String ociConnectionPoolProxyDistinguishedName = null;
  Object ociConnectionPoolProxyCertificate = null;
  
  static NTFManager ntfManager = new NTFManager();









  
  public int protocolId = -3;



  
  OracleTimeout timeout;



  
  DBConversion conversion;



  
  boolean xaWantsError;



  
  boolean usingXA;



  
  int txnMode = 0;



  
  byte[] fdo;



  
  Boolean bigEndian;



  
  OracleStatement statements;



  
  int lifecycle;



  
  static final int OPEN = 1;



  
  static final int CLOSING = 2;


  
  static final int CLOSED = 4;


  
  static final int ABORTED = 8;


  
  static final int BLOCKED = 16;


  
  boolean clientIdSet = false;


  
  String clientId = null;


  
  int txnLevel;


  
  Map map;


  
  Map javaObjectMap;


  
  final Hashtable[] descriptorCacheStack = new Hashtable[2];
  
  int dci = 0;




  
  OracleStatement statementHoldingLine;




  
  OracleDatabaseMetaData databaseMetaData = null;



  
  LogicalConnection logicalConnectionAttached;



  
  boolean isProxy = false;



  
  OracleSql sqlObj = null;

  
  SQLWarning sqlWarning = null;


  
  boolean readOnly = false;


  
  LRUStatementCache statementCache = null;



  
  boolean clearStatementMetaData = false;


  
  OracleCloseCallback closeCallback = null;
  Object privateData = null;

  
  Statement savepointStatement = null;

  
  boolean isUsable = true;
  
  TimeZone defaultTimeZone = null;























  
  final int[] endToEndMaxLength = new int[4];
  
  boolean endToEndAnyChanged = false;
  final boolean[] endToEndHasChanged = new boolean[4];
  short endToEndECIDSequenceNumber = Short.MIN_VALUE;

  
  static final int DMS_NONE = 0;

  
  static final int DMS_10G = 1;
  
  static final int DMS_11 = 2;
  
  String[] endToEndValues = null;
  final int whichDMS = 0;


  
  OracleConnection wrapper = null;





  
  int minVcsBindSize;





  
  int maxRawBytesSql;





  
  int maxRawBytesPlsql;





  
  int maxVcsCharsSql;





  
  int maxVcsNCharsSql;




  
  int maxVcsBytesPlsql;




  
  int maxIbtVarcharElementLength;




  
  String instanceName = null;
  OracleDriverExtension driverExtension;
  static final String uninitializedMarker = "";
  String databaseProductVersion = "";
  short versionNumber = -1;

























  
  int namedTypeAccessorByteLen;

























  
  int refTypeAccessorByteLen;

























  
  CharacterSet setCHARCharSetObj;

























  
  CharacterSet setCHARNCharSetObj;

























  
  protected final Object cancelInProgressLockForThin;

























  
  boolean plsqlCompilerWarnings = false;

























  
  private static final String propertyVariableName(String paramString) {
    char[] arrayOfChar = new char[paramString.length()];
    paramString.getChars(0, paramString.length(), arrayOfChar, 0);
    String str = "";
    for (byte b = 0; b < arrayOfChar.length; b++) {
      
      if (Character.isUpperCase(arrayOfChar[b]))
        str = str + "_"; 
      str = str + Character.toUpperCase(arrayOfChar[b]);
    } 
    return str;
  }































  
  private void readConnectionProperties(String paramString, Properties paramProperties) throws SQLException {
    String str1 = null;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.RetainV9LongBindBehavior");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.RetainV9LongBindBehavior", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.retainV9BindBehavior = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("user");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.user"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.user", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.userName = str1;

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("database");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.database"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.database", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.database = str1;

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("autoCommit");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.autoCommit"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.autoCommit", (String)null); 
    if (str1 == null) {
      str1 = "true";
    }
    
    this.autocommit = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("protocol");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.protocol"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.protocol", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.protocol = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.StreamChunkSize");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.StreamChunkSize", (String)null); 
    if (str1 == null) {
      str1 = "16384";
    }
    try {
      this.streamChunkSize = Integer.parseInt(str1);
    } catch (NumberFormatException numberFormatException) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'streamChunkSize'");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("SetFloatAndDoubleUseBinary");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.SetFloatAndDoubleUseBinary"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.SetFloatAndDoubleUseBinary", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.setFloatAndDoubleUseBinary = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("v$session.terminal");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.v$session.terminal"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.v$session.terminal", (String)null); 
    if (str1 == null) {
      str1 = "unknown";
    }
    
    this.thinVsessionTerminal = str1;

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("v$session.machine");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.v$session.machine"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.v$session.machine", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinVsessionMachine = str1;

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("v$session.osuser");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.v$session.osuser"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.v$session.osuser", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinVsessionOsuser = str1;

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("v$session.program");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.v$session.program"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.v$session.program", (String)null); 
    if (str1 == null) {
      str1 = "JDBC Thin Client";
    }
    
    this.thinVsessionProgram = str1;

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("v$session.process");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.v$session.process"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.v$session.process", (String)null); 
    if (str1 == null) {
      str1 = "1234";
    }
    
    this.thinVsessionProcess = str1;

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("v$session.iname");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.v$session.iname"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.v$session.iname", (String)null); 
    if (str1 == null) {
      str1 = "jdbc_ttc_impl";
    }
    
    this.thinVsessionIname = str1;

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("v$session.ename");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.v$session.ename"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.v$session.ename", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinVsessionEname = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.net.profile");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.net.profile", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinNetProfile = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.net.authentication_services");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.net.authentication_services", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinNetAuthenticationServices = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.net.kerberos5_mutual_authentication");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.net.kerberos5_mutual_authentication", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinNetAuthenticationKrb5Mutual = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.net.kerberos5_cc_name");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.net.kerberos5_cc_name", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinNetAuthenticationKrb5CcName = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.net.encryption_client");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.net.encryption_client", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinNetEncryptionLevel = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.net.encryption_types_client");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.net.encryption_types_client", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinNetEncryptionTypes = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.net.crypto_checksum_client");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.net.crypto_checksum_client", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinNetChecksumLevel = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.net.crypto_checksum_types_client");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.net.crypto_checksum_types_client", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinNetChecksumTypes = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.net.crypto_seed");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.net.crypto_seed", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinNetCryptoSeed = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.TcpNoDelay");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.TcpNoDelay", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.thinTcpNoDelay = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.ReadTimeout");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.ReadTimeout", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinReadTimeout = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.net.CONNECT_TIMEOUT");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.net.CONNECT_TIMEOUT", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinNetConnectTimeout = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.net.disableOob");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.net.disableOob", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.thinNetDisableOutOfBandBreak = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.net.useZeroCopyIO");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.net.useZeroCopyIO", (String)null); 
    if (str1 == null) {
      str1 = "true";
    }
    
    this.thinNetUseZeroCopyIO = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.net.SDP");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.net.SDP", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.thinNetEnableSDP = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.use1900AsYearForTime");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.use1900AsYearForTime", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.use1900AsYearForTime = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.timestampTzInGmt");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.timestampTzInGmt", (String)null); 
    if (str1 == null) {
      str1 = "true";
    }
    
    this.timestamptzInGmt = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.timezoneAsRegion");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.timezoneAsRegion", (String)null); 
    if (str1 == null) {
      str1 = "true";
    }
    
    this.timezoneAsRegion = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.net.ssl_server_dn_match");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.net.ssl_server_dn_match", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinSslServerDnMatch = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.net.ssl_version");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.net.ssl_version", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinSslVersion = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.net.ssl_cipher_suites");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.net.ssl_cipher_suites", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinSslCipherSuites = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("javax.net.ssl.keyStore");
    }
    if (str1 == null)
      str1 = getSystemProperty("javax.net.ssl.keyStore", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinJavaxNetSslKeystore = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("javax.net.ssl.keyStoreType");
    }
    if (str1 == null)
      str1 = getSystemProperty("javax.net.ssl.keyStoreType", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinJavaxNetSslKeystoretype = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("javax.net.ssl.keyStorePassword");
    }
    if (str1 == null)
      str1 = getSystemProperty("javax.net.ssl.keyStorePassword", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinJavaxNetSslKeystorepassword = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("javax.net.ssl.trustStore");
    }
    if (str1 == null)
      str1 = getSystemProperty("javax.net.ssl.trustStore", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinJavaxNetSslTruststore = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("javax.net.ssl.trustStoreType");
    }
    if (str1 == null)
      str1 = getSystemProperty("javax.net.ssl.trustStoreType", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinJavaxNetSslTruststoretype = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("javax.net.ssl.trustStorePassword");
    }
    if (str1 == null)
      str1 = getSystemProperty("javax.net.ssl.trustStorePassword", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinJavaxNetSslTruststorepassword = str1;

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("ssl.keyManagerFactory.algorithm");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.ssl.keyManagerFactory.algorithm"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.ssl.keyManagerFactory.algorithm", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinSslKeymanagerfactoryAlgorithm = str1;

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("ssl.trustManagerFactory.algorithm");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.ssl.trustManagerFactory.algorithm"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.ssl.trustManagerFactory.algorithm", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinSslTrustmanagerfactoryAlgorithm = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.net.oldSyntax");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.net.oldSyntax", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinNetOldsyntax = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("java.naming.factory.initial");
    }
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinNamingContextInitial = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("java.naming.provider.url");
    }
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinNamingProviderUrl = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("java.naming.security.authentication");
    }
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinNamingSecurityAuthentication = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("java.naming.security.principal");
    }
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinNamingSecurityPrincipal = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("java.naming.security.credentials");
    }
    if (str1 == null) {
      str1 = null;
    }
    
    this.thinNamingSecurityCredentials = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.net.wallet_location");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.net.wallet_location", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.walletLocation = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.net.wallet_password");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.net.wallet_password", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.walletPassword = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.proxyClientName");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.proxyClientName", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.proxyClientName = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.useNio");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.useNio", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.useNio = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("JDBCDriverCharSetId");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.JDBCDriverCharSetId"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.JDBCDriverCharSetId", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.ociDriverCharset = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.editionName");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.editionName", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.editionName = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.thinLogonCapability");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.thinLogonCapability", (String)null); 
    if (str1 == null) {
      str1 = "o5";
    }
    
    this.logonCap = str1;

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("internal_logon");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.internal_logon"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.internal_logon", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.internalLogon = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.createDescriptorUseCurrentSchemaForSchemaName");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.createDescriptorUseCurrentSchemaForSchemaName", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.createDescriptorUseCurrentSchemaForSchemaName = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("OCISvcCtxHandle");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.OCISvcCtxHandle"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.OCISvcCtxHandle", (String)null); 
    if (str1 == null) {
      str1 = "0";
    }
    try {
      this.ociSvcCtxHandle = Long.parseLong(str1);
    } catch (NumberFormatException numberFormatException) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'ociSvcCtxHandle'");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("OCIEnvHandle");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.OCIEnvHandle"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.OCIEnvHandle", (String)null); 
    if (str1 == null) {
      str1 = "0";
    }
    try {
      this.ociEnvHandle = Long.parseLong(str1);
    } catch (NumberFormatException numberFormatException) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'ociEnvHandle'");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("OCIErrHandle");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.OCIErrHandle"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.OCIErrHandle", (String)null); 
    if (str1 == null) {
      str1 = "0";
    }
    try {
      this.ociErrHandle = Long.parseLong(str1);
    } catch (NumberFormatException numberFormatException) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'ociErrHandle'");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("prelim_auth");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.prelim_auth"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.prelim_auth", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.prelimAuth = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.ociNlsLangBackwardCompatible");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.ociNlsLangBackwardCompatible", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.nlsLangBackdoor = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("OCINewPassword");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.OCINewPassword"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.OCINewPassword", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.setNewPassword = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.spawnNewThreadToCancel");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.spawnNewThreadToCancel", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.spawnNewThreadToCancel = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("defaultExecuteBatch");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.defaultExecuteBatch"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.defaultExecuteBatch", (String)null); 
    if (str1 == null) {
      str1 = "1";
    }
    try {
      this.defaultExecuteBatch = Integer.parseInt(str1);
    } catch (NumberFormatException numberFormatException) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'defaultExecuteBatch'");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("defaultRowPrefetch");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.defaultRowPrefetch"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.defaultRowPrefetch", (String)null); 
    if (str1 == null) {
      str1 = "10";
    }
    try {
      this.defaultRowPrefetch = Integer.parseInt(str1);
    } catch (NumberFormatException numberFormatException) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'defaultRowPrefetch'");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.defaultLobPrefetchSize");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.defaultLobPrefetchSize", (String)null); 
    if (str1 == null) {
      str1 = "4000";
    }
    try {
      this.defaultLobPrefetchSize = Integer.parseInt(str1);
    } catch (NumberFormatException numberFormatException) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'defaultLobPrefetchSize'");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.enableDataInLocator");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.enableDataInLocator", (String)null); 
    if (str1 == null) {
      str1 = "true";
    }
    
    this.enableDataInLocator = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.enableReadDataInLocator");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.enableReadDataInLocator", (String)null); 
    if (str1 == null) {
      str1 = "true";
    }
    
    this.enableReadDataInLocator = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.overrideEnableReadDataInLocator");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.overrideEnableReadDataInLocator", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.overrideEnableReadDataInLocator = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("remarksReporting");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.remarksReporting"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.remarksReporting", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.reportRemarks = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("includeSynonyms");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.includeSynonyms"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.includeSynonyms", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.includeSynonyms = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("restrictGetTables");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.restrictGetTables"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.restrictGetTables", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.restrictGettables = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("AccumulateBatchResult");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.AccumulateBatchResult"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.AccumulateBatchResult", (String)null); 
    if (str1 == null) {
      str1 = "true";
    }
    
    this.accumulateBatchResult = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("useFetchSizeWithLongColumn");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.useFetchSizeWithLongColumn"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.useFetchSizeWithLongColumn", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.useFetchSizeWithLongColumn = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("processEscapes");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.processEscapes"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.processEscapes", (String)null); 
    if (str1 == null) {
      str1 = "true";
    }
    
    this.processEscapes = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("fixedString");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.fixedString"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.fixedString", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.fixedString = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("defaultNChar");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.defaultNChar"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.defaultNChar", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.defaultnchar = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.internal.permitBindDateDefineTimestampMismatch");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.internal.permitBindDateDefineTimestampMismatch", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.permitTimestampDateMismatch = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("RessourceManagerId");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.RessourceManagerId"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.RessourceManagerId", (String)null); 
    if (str1 == null) {
      str1 = "0000";
    }
    
    this.resourceManagerId = str1;

    
    str1 = null;
    if (paramProperties != null) {
      
      str1 = paramProperties.getProperty("disableDefineColumnType");
      if (str1 == null)
        str1 = paramProperties.getProperty("oracle.jdbc.disableDefineColumnType"); 
    } 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.disableDefineColumnType", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.disableDefinecolumntype = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.convertNcharLiterals");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.convertNcharLiterals", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.convertNcharLiterals = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.J2EE13Compliant");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.J2EE13Compliant", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.j2ee13Compliant = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.mapDateToTimestamp");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.mapDateToTimestamp", (String)null); 
    if (str1 == null) {
      str1 = "true";
    }
    
    this.mapDateToTimestamp = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.useThreadLocalBufferCache");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.useThreadLocalBufferCache", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.useThreadLocalBufferCache = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.driverNameAttribute");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.driverNameAttribute", (String)null); 
    if (str1 == null) {
      str1 = null;
    }
    
    this.driverNameAttribute = str1;

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.maxCachedBufferSize");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.maxCachedBufferSize", (String)null); 
    if (str1 == null) {
      str1 = "30";
    }
    try {
      this.maxCachedBufferSize = Integer.parseInt(str1);
    } catch (NumberFormatException numberFormatException) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'maxCachedBufferSize'");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.implicitStatementCacheSize");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.implicitStatementCacheSize", (String)null); 
    if (str1 == null) {
      str1 = "0";
    }
    try {
      this.implicitStatementCacheSize = Integer.parseInt(str1);
    } catch (NumberFormatException numberFormatException) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'implicitStatementCacheSize'");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.LobStreamPosStandardCompliant");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.LobStreamPosStandardCompliant", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.lobStreamPosStandardCompliant = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.strictASCIIConversion");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.strictASCIIConversion", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.isStrictAsciiConversion = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.quickASCIIConversion");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.quickASCIIConversion", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.isQuickAsciiConversion = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.thinForceDNSLoadBalancing");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.thinForceDNSLoadBalancing", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.thinForceDnsLoadBalancing = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.enableJavaNetFastPath");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.enableJavaNetFastPath", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.enableJavaNetFastPath = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.enableTempLobRefCnt");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.enableTempLobRefCnt", (String)null); 
    if (str1 == null) {
      str1 = "true";
    }
    
    this.enableTempLobRefCnt = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.plsqlVarcharParameter4KOnly");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.plsqlVarcharParameter4KOnly", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.plsqlVarcharParameter4KOnly = (str1 != null && str1.equalsIgnoreCase("true"));

    
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.net.keepAlive");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.net.keepAlive", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.keepAlive = (str1 != null && str1.equalsIgnoreCase("true"));


    
    str1 = null;
    if (paramProperties != null)
      str1 = paramProperties.getProperty("oracle.jdbc.commitOption"); 
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.commitOption", (String)null); 
    if (str1 != null) {
      
      this.commitOption = 0;
      String[] arrayOfString = str1.split(",");
      if (arrayOfString != null && arrayOfString.length > 0)
      {
        for (String str : arrayOfString) {
          if (str.trim() != "") {
            this.commitOption |= OracleConnection.CommitOption.valueOf(str.trim()).getCode();
          }
        } 
      }
    } 
    str1 = null;
    if (paramProperties != null)
    {
      str1 = paramProperties.getProperty("oracle.jdbc.calculateChecksum");
    }
    if (str1 == null)
      str1 = getSystemProperty("oracle.jdbc.calculateChecksum", (String)null); 
    if (str1 == null) {
      str1 = "false";
    }
    
    this.calculateChecksum = (str1 != null && str1.equalsIgnoreCase("true"));



    
    this.includeSynonyms = parseConnectionProperty_boolean(paramProperties, "synonyms", (byte)3, this.includeSynonyms);

    
    this.reportRemarks = parseConnectionProperty_boolean(paramProperties, "remarks", (byte)3, this.reportRemarks);

    
    this.defaultRowPrefetch = parseConnectionProperty_int(paramProperties, "prefetch", (byte)3, this.defaultRowPrefetch);

    
    this.defaultRowPrefetch = parseConnectionProperty_int(paramProperties, "rowPrefetch", (byte)3, this.defaultRowPrefetch);

    
    this.defaultExecuteBatch = parseConnectionProperty_int(paramProperties, "batch", (byte)3, this.defaultExecuteBatch);

    
    this.defaultExecuteBatch = parseConnectionProperty_int(paramProperties, "executeBatch", (byte)3, this.defaultExecuteBatch);

    
    this.proxyClientName = parseConnectionProperty_String(paramProperties, "PROXY_CLIENT_NAME", (byte)1, this.proxyClientName);




    
    if (this.defaultRowPrefetch <= 0) {
      this.defaultRowPrefetch = Integer.parseInt("10");
    }
    if (this.defaultExecuteBatch <= 0) {
      this.defaultExecuteBatch = Integer.parseInt("1");
    }
    if (this.defaultLobPrefetchSize < -1) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 267);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 




    
    if (this.streamChunkSize > 0) {
      this.streamChunkSize = Math.max(4096, this.streamChunkSize);
    } else {
      this.streamChunkSize = Integer.parseInt("16384");
    } 

    
    if (this.thinVsessionOsuser == null) {
      
      this.thinVsessionOsuser = getSystemProperty("user.name", (String)null);
      if (this.thinVsessionOsuser == null) {
        this.thinVsessionOsuser = "jdbcuser";
      }
    } 



    
    if (this.thinNetConnectTimeout == CONNECTION_PROPERTY_THIN_NET_CONNECT_TIMEOUT_DEFAULT) {
      
      int i = DriverManager.getLoginTimeout();
      if (i != 0) {
        this.thinNetConnectTimeout = "" + (i * 1000);
      }
    } 




    
    this.url = paramString;
    Hashtable hashtable = parseUrl(this.url, this.walletLocation, this.walletPassword);
    
    if (this.userName == CONNECTION_PROPERTY_USER_NAME_DEFAULT)
      this.userName = (String)hashtable.get("user"); 
    String[] arrayOfString1 = new String[1];
    String[] arrayOfString2 = new String[1];
    this.userName = parseLoginOption(this.userName, paramProperties, arrayOfString1, arrayOfString2);
    if (arrayOfString1[0] != null)
      this.internalLogon = arrayOfString1[0]; 
    if (arrayOfString2[0] != null) {
      this.proxyClientName = arrayOfString2[0];
    }
    String str2 = paramProperties.getProperty("password", CONNECTION_PROPERTY_PASSWORD_DEFAULT);
    
    if (str2 == CONNECTION_PROPERTY_PASSWORD_DEFAULT)
      str2 = (String)hashtable.get("password"); 
    initializePassword(str2);
    
    if (this.database == CONNECTION_PROPERTY_DATABASE_DEFAULT) {
      this.database = paramProperties.getProperty("server", CONNECTION_PROPERTY_DATABASE_DEFAULT);
    }
    if (this.database == CONNECTION_PROPERTY_DATABASE_DEFAULT) {
      this.database = (String)hashtable.get("database");
    }
    this.protocol = (String)hashtable.get("protocol");

    
    if (this.protocol == null) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 40, "Protocol is not specified in URL");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.protocol.equals("oci8") || this.protocol.equals("oci")) {
      this.database = translateConnStr(this.database);
    }
    
    if (paramProperties.getProperty("is_connection_pooling") == "true")
    {
      
      if (this.database == null) {
        this.database = "";
      }
    }
    if (this.userName != null && !this.userName.startsWith("\"")) {

      
      char[] arrayOfChar = this.userName.toCharArray();
      for (byte b = 0; b < arrayOfChar.length; b++)
        arrayOfChar[b] = Character.toUpperCase(arrayOfChar[b]); 
      this.userName = String.copyValueOf(arrayOfChar);
    } 

    
    this.xaWantsError = false;
    this.usingXA = false;
    
    readOCIConnectionPoolProperties(paramProperties);
    validateConnectionProperties();
  }





  
  private void readOCIConnectionPoolProperties(Properties paramProperties) throws SQLException {
    this.ociConnectionPoolMinLimit = parseConnectionProperty_int(paramProperties, "connpool_min_limit", (byte)1, 0);

    
    this.ociConnectionPoolMaxLimit = parseConnectionProperty_int(paramProperties, "connpool_max_limit", (byte)1, 0);

    
    this.ociConnectionPoolIncrement = parseConnectionProperty_int(paramProperties, "connpool_increment", (byte)1, 0);

    
    this.ociConnectionPoolTimeout = parseConnectionProperty_int(paramProperties, "connpool_timeout", (byte)1, 0);

    
    this.ociConnectionPoolNoWait = parseConnectionProperty_boolean(paramProperties, "connpool_nowait", (byte)1, false);

    
    this.ociConnectionPoolTransactionDistributed = parseConnectionProperty_boolean(paramProperties, "transactions_distributed", (byte)1, false);

    
    this.ociConnectionPoolLogonMode = parseConnectionProperty_String(paramProperties, "connection_pool", (byte)1, (String)null);

    
    this.ociConnectionPoolIsPooling = parseConnectionProperty_boolean(paramProperties, "is_connection_pooling", (byte)1, false);

    
    this.ociConnectionPoolObject = parseConnectionProperty_Object(paramProperties, "connpool_object", (Object)null);
    
    this.ociConnectionPoolConnID = parseConnectionProperty_Object(paramProperties, "connection_id", (Object)null);
    
    this.ociConnectionPoolProxyType = parseConnectionProperty_String(paramProperties, "proxytype", (byte)1, (String)null);

    
    this.ociConnectionPoolProxyNumRoles = (Integer)parseConnectionProperty_Object(paramProperties, "proxy_num_roles", Integer.valueOf(0));
    
    this.ociConnectionPoolProxyRoles = parseConnectionProperty_Object(paramProperties, "proxy_roles", (Object)null);
    
    this.ociConnectionPoolProxyUserName = parseConnectionProperty_String(paramProperties, "proxy_user_name", (byte)1, (String)null);

    
    this.ociConnectionPoolProxyPassword = parseConnectionProperty_String(paramProperties, "proxy_password", (byte)1, (String)null);

    
    this.ociConnectionPoolProxyDistinguishedName = parseConnectionProperty_String(paramProperties, "proxy_distinguished_name", (byte)1, (String)null);

    
    this.ociConnectionPoolProxyCertificate = parseConnectionProperty_Object(paramProperties, "proxy_certificate", (Object)null);
  }




  
  private static final Pattern driverNameAttributePattern = Pattern.compile("[\\x20-\\x7e]{0,8}");







  
  void validateConnectionProperties() throws SQLException {
    if (this.driverNameAttribute != null && !driverNameAttributePattern.matcher(this.driverNameAttribute).matches()) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 257);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }












  
  private static final Object parseConnectionProperty_Object(Properties paramProperties, String paramString, Object paramObject) throws SQLException {
    Object object = paramObject;
    if (paramProperties != null) {
      
      Object object1 = paramProperties.get(paramString);
      if (object1 != null)
        object = object1; 
    } 
    return object;
  }

























  
  private static final String parseConnectionProperty_String(Properties paramProperties, String paramString1, byte paramByte, String paramString2) throws SQLException {
    String str = null;
    if ((paramByte == 1 || paramByte == 3) && paramProperties != null) {

      
      str = paramProperties.getProperty(paramString1);
      if (str == null && !paramString1.startsWith("oracle.") && !paramString1.startsWith("java.") && !paramString1.startsWith("javax."))
        str = paramProperties.getProperty("oracle.jdbc." + paramString1); 
    } 
    if (str == null && (paramByte == 2 || paramByte == 3))
    {
      
      if (paramString1.startsWith("oracle.") || paramString1.startsWith("java.") || paramString1.startsWith("javax.")) {
        str = getSystemProperty(paramString1, (String)null);
      } else {
        str = getSystemProperty("oracle.jdbc." + paramString1, (String)null);
      }  } 
    if (str == null)
      str = paramString2; 
    return str;
  }







  
  private static final int parseConnectionProperty_int(Properties paramProperties, String paramString, byte paramByte, int paramInt) throws SQLException {
    int i = paramInt;
    String str = parseConnectionProperty_String(paramProperties, paramString, paramByte, (String)null);



    
    if (str != null) {
      
      try {
        
        i = Integer.parseInt(str);
      }
      catch (NumberFormatException numberFormatException) {


        
        SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is '" + paramString + "' and value is '" + str + "'");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    }

    
    return i;
  }







  
  private static final long parseConnectionProperty_long(Properties paramProperties, String paramString, byte paramByte, long paramLong) throws SQLException {
    long l = paramLong;
    String str = parseConnectionProperty_String(paramProperties, paramString, paramByte, (String)null);



    
    if (str != null) {
      
      try {
        
        l = Long.parseLong(str);
      }
      catch (NumberFormatException numberFormatException) {


        
        SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is '" + paramString + "' and value is '" + str + "'");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    }

    
    return l;
  }







  
  private static final boolean parseConnectionProperty_boolean(Properties paramProperties, String paramString, byte paramByte, boolean paramBoolean) throws SQLException {
    boolean bool = paramBoolean;
    String str = parseConnectionProperty_String(paramProperties, paramString, paramByte, (String)null);



    
    if (str != null)
    {
      if (str.equalsIgnoreCase("false")) {
        bool = false;
      } else if (str.equalsIgnoreCase("true")) {
        bool = true;
      }  } 
    return bool;
  }
















  
  private static String parseLoginOption(String paramString, Properties paramProperties, String[] paramArrayOfString1, String[] paramArrayOfString2) {
    int j = 0;
    String str1 = null;
    String str2 = null;

    
    if (paramString == null) {
      return null;
    }
    int k = paramString.length();
    
    if (k == 0) {
      return null;
    }
    
    int i = paramString.indexOf('[');
    if (i > 0) {
      j = paramString.indexOf(']');
      str2 = paramString.substring(i + 1, j);
      str2 = str2.trim();
      
      if (str2.length() > 0) {
        paramArrayOfString2[0] = str2;
      }
      
      paramString = paramString.substring(0, i) + paramString.substring(j + 1, k);
    } 


    
    String str3 = paramString.toLowerCase();

    
    i = str3.lastIndexOf(" as ");
    
    if (i == -1 || i < str3.lastIndexOf("\"")) {
      return paramString;
    }


    
    str1 = paramString.substring(0, i);
    
    i += 4;

    
    while (i < k && str3.charAt(i) == ' ') {
      i++;
    }
    if (i == k) {
      return paramString;
    }
    String str4 = str3.substring(i).trim();
    
    if (str4.length() > 0) {
      paramArrayOfString1[0] = str4;
    }
    return str1;
  }

















  
  private static final Hashtable parseUrl(String paramString1, String paramString2, String paramString3) throws SQLException {
    Hashtable<Object, Object> hashtable = new Hashtable<Object, Object>(5);
    int i = paramString1.indexOf(':', paramString1.indexOf(':') + 1) + 1;
    int j = paramString1.length();

    
    if (i == j) {
      return hashtable;
    }
    int k = paramString1.indexOf(':', i);

    
    if (k == -1)
    {



      
      return hashtable;
    }

    
    hashtable.put("protocol", paramString1.substring(i, k));
    
    int m = k + 1;
    int n = paramString1.indexOf('/', m);
    
    int i1 = paramString1.indexOf('@', m);



    
    if (i1 > m && m > i && n == -1) {

      
      SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 67);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    if (i1 == -1) {
      i1 = j;
    }
    if (n == -1) {
      n = i1;
    }
    if (n < i1 && n != m && i1 != m) {
      
      hashtable.put("user", paramString1.substring(m, n));
      hashtable.put("password", paramString1.substring(n + 1, i1));
    } 



    
    if (n <= i1 && (n == m || i1 == m))
    {




      
      if (i1 < j) {
        
        String str = paramString1.substring(i1 + 1);
        String[] arrayOfString = getSecretStoreCredentials(str, paramString2, paramString3);
        if (arrayOfString[0] != null || arrayOfString[1] != null) {
          
          hashtable.put("user", arrayOfString[0]);
          hashtable.put("password", arrayOfString[1]);
        } 
      } 
    }

    
    if (i1 < j) {
      hashtable.put("database", paramString1.substring(i1 + 1));
    }
    return hashtable;
  }






























































































































































  
  private static final synchronized String[] getSecretStoreCredentials(String paramString1, String paramString2, String paramString3) throws SQLException {
    String[] arrayOfString = new String[2];
    arrayOfString[0] = null;
    arrayOfString[1] = null;
    
    if (paramString2 != null) {
      
      try {
        
        if (paramString2.startsWith("(")) {
          paramString2 = "file:" + CustomSSLSocketFactory.processWalletLocation(paramString2);
        }
        OracleWallet oracleWallet = new OracleWallet();
        if (oracleWallet.exists(paramString2)) {


          
          char[] arrayOfChar = null;
          if (paramString3 != null) {
            arrayOfChar = paramString3.toCharArray();
          }

          
          oracleWallet.open(paramString2, arrayOfChar);
          OracleSecretStore oracleSecretStore = oracleWallet.getSecretStore();


          
          if (oracleSecretStore.containsAlias("oracle.security.client.default_username")) {
            arrayOfString[0] = new String(oracleSecretStore.getSecret("oracle.security.client.default_username"));
          }
          if (oracleSecretStore.containsAlias("oracle.security.client.default_password")) {
            arrayOfString[1] = new String(oracleSecretStore.getSecret("oracle.security.client.default_password"));
          }
          
          Enumeration<String> enumeration = oracleWallet.getSecretStore().internalAliases();
          
          String str = null;
          while (enumeration.hasMoreElements()) {
            
            str = enumeration.nextElement();
            if (str.startsWith("oracle.security.client.connect_string"))
            {
              if (paramString1.equalsIgnoreCase(new String(oracleSecretStore.getSecret(str)))) {

                
                String str1 = str.substring("oracle.security.client.connect_string".length());
                arrayOfString[0] = new String(oracleSecretStore.getSecret("oracle.security.client.username" + str1));
                
                arrayOfString[1] = new String(oracleSecretStore.getSecret("oracle.security.client.password" + str1));

                
                break;
              } 
            }
          } 
        } 
      } catch (NoClassDefFoundError noClassDefFoundError) {

        
        SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 167, noClassDefFoundError);
        sQLException.fillInStackTrace();
        throw sQLException;
      
      }
      catch (Exception exception) {
        
        if (exception instanceof RuntimeException) throw (RuntimeException)exception;








        
        SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 168, exception);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    }

    
    return arrayOfString;
  }















  
  private String translateConnStr(String paramString) throws SQLException {
    int i = 0;
    int j = 0;
    
    if (paramString == null || paramString.equals("")) {
      return paramString;
    }
    
    if (paramString.indexOf(')') != -1) {
      return paramString;
    }
    boolean bool = false;
    if (paramString.indexOf('[') != -1) {

      
      i = paramString.indexOf(']');
      if (i == -1) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67, paramString);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      bool = true;
    } 
    
    i = paramString.indexOf(':', i);
    if (i == -1)
      return paramString; 
    j = paramString.indexOf(':', i + 1);
    if (j == -1) {
      return paramString;
    }
    
    if (paramString.indexOf(':', j + 1) != -1) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67, paramString);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    String str1 = null;
    if (bool) {
      str1 = paramString.substring(1, i - 1);
    } else {
      str1 = paramString.substring(0, i);
    } 
    String str2 = paramString.substring(i + 1, j);
    String str3 = paramString.substring(j + 1, paramString.length());
    
    return "(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=" + str1 + ")(PORT=" + str2 + "))(CONNECT_DATA=(SID=" + str3 + ")))";
  }









  
  protected static String getSystemPropertyPollInterval() {
    return getSystemProperty("oracle.jdbc.TimeoutPollInterval", "1000");
  }





  
  static String getSystemPropertyFastConnectionFailover(String paramString) {
    return getSystemProperty("oracle.jdbc.FastConnectionFailover", paramString);
  }




  
  static String getSystemPropertyJserverVersion() {
    return getSystemProperty("oracle.jserver.version", (String)null);
  }



  
  private static String getSystemProperty(String paramString1, String paramString2) {
    if (paramString1 != null) {
      
      final String fstr = paramString1;
      final String fdefaultValue = paramString2;
      final String[] rets = { paramString2 };
      AccessController.doPrivileged(new PrivilegedAction()
          {
            public Object run()
            {
              rets[0] = System.getProperty(fstr, fdefaultValue);
              return null;
            }
          });
      return arrayOfString[0];
    } 
    
    return paramString2;
  }







  
  public Properties getProperties() {
    Properties properties = new Properties();
    
    try {
      Class clazz1 = null;
      Class clazz2 = null;
      
      try {
        clazz1 = ClassRef.newInstance("oracle.jdbc.OracleConnection").get();
        clazz2 = ClassRef.newInstance("oracle.jdbc.driver.PhysicalConnection").get();
      }
      catch (ClassNotFoundException classNotFoundException) {}





      
      Field[] arrayOfField = clazz2.getDeclaredFields();
      for (byte b = 0; b < arrayOfField.length; b++) {
        
        int i = arrayOfField[b].getModifiers();
        if (!Modifier.isStatic(i)) {

          
          String str1 = arrayOfField[b].getName();

          
          String str2 = "CONNECTION_PROPERTY_" + propertyVariableName(str1);


          
          Field field = null;

          
          try {
            field = clazz1.getField(str2);
          }
          catch (NoSuchFieldException noSuchFieldException) {}




          
          if (!str2.matches(".*PASSWORD.*")) {

            
            String str3 = (String)field.get(null);
            String str4 = arrayOfField[b].getType().getName();
            if (str4.equals("boolean"))
            
            { boolean bool = arrayOfField[b].getBoolean(this);
              if (bool) {
                properties.setProperty(str3, "true");
              } else {
                properties.setProperty(str3, "false");
              }  }
            else if (str4.equals("int"))
            
            { int j = arrayOfField[b].getInt(this);
              properties.setProperty(str3, Integer.toString(j)); }
            
            else if (str4.equals("long"))
            
            { long l = arrayOfField[b].getLong(this);
              properties.setProperty(str3, Long.toString(l)); }
            
            else if (str4.equals("java.lang.String"))
            
            { String str = (String)arrayOfField[b].get(this);
              if (str != null)
                properties.setProperty(str3, str);  } 
          } 
        } 
      } 
    } catch (IllegalAccessException illegalAccessException) {}



    
    return properties;
  }

















  
  public synchronized Connection _getPC() {
    return null;
  }












  
  public synchronized OracleConnection getPhysicalConnection() {
    return this;
  }









  
  public synchronized boolean isLogicalConnection() {
    return false;
  }









  
  void initialize(Hashtable paramHashtable, Map paramMap1, Map paramMap2) throws SQLException {
    this.clearStatementMetaData = false;




    
    if (paramHashtable != null) {
      this.descriptorCacheStack[this.dci] = paramHashtable;
    } else {
      this.descriptorCacheStack[this.dci] = new Hashtable<Object, Object>(10);
    } 
    this.map = paramMap1;
    
    if (paramMap2 != null) {
      this.javaObjectMap = paramMap2;
    } else {
      this.javaObjectMap = new Hashtable<Object, Object>(10);
    } 
    this.lifecycle = 1;
    this.txnLevel = 2;

    
    this.clientIdSet = false;
  }




  
  void initializeSetCHARCharSetObjs() {
    this.setCHARNCharSetObj = this.conversion.getDriverNCharSetObj();
    this.setCHARCharSetObj = this.conversion.getDriverCharSetObj();
  }










  
  OracleTimeout getTimeout() throws SQLException {
    if (this.timeout == null)
    {
      this.timeout = OracleTimeout.newTimeout(this.url);
    }
    
    return this.timeout;
  }















  
  public synchronized Statement createStatement() throws SQLException {
    return createStatement(-1, -1);
  }


















  
  public synchronized Statement createStatement(int paramInt1, int paramInt2) throws SQLException {
    if (this.lifecycle != 1) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    OracleStatement oracleStatement = null;




    
    oracleStatement = this.driverExtension.allocateStatement(this, paramInt1, paramInt2);





    
    return (Statement)new OracleStatementWrapper((OracleStatement)oracleStatement);
  }

















  
  public synchronized PreparedStatement prepareStatement(String paramString) throws SQLException {
    return prepareStatement(paramString, -1, -1);
  }
















  
  public synchronized PreparedStatement prepareStatementWithKey(String paramString) throws SQLException {
    OraclePreparedStatementWrapper oraclePreparedStatementWrapper;
    if (this.lifecycle != 1) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (paramString == null) {
      return null;
    }
    if (!isStatementCacheInitialized()) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 




    
    OraclePreparedStatement oraclePreparedStatement = null;
    
    oraclePreparedStatement = (OraclePreparedStatement)this.statementCache.searchExplicitCache(paramString);









    
    if (oraclePreparedStatement != null) {
      oraclePreparedStatementWrapper = new OraclePreparedStatementWrapper((OraclePreparedStatement)oraclePreparedStatement);
    }
    return (PreparedStatement)oraclePreparedStatementWrapper;
  }



























  
  public synchronized PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2) throws SQLException {
    if (paramString == null || paramString.length() == 0) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 104);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.lifecycle != 1) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    OraclePreparedStatement oraclePreparedStatement = null;

    
    if (this.statementCache != null) {
      oraclePreparedStatement = (OraclePreparedStatement)this.statementCache.searchImplicitCache(paramString, 1, (paramInt1 != -1 || paramInt2 != -1) ? ResultSetUtil.getRsetTypeCode(paramInt1, paramInt2) : 1);
    }



    
    if (oraclePreparedStatement == null) {
      oraclePreparedStatement = this.driverExtension.allocatePreparedStatement(this, paramString, paramInt1, paramInt2);
    }









    
    return (PreparedStatement)new OraclePreparedStatementWrapper((OraclePreparedStatement)oraclePreparedStatement);
  }















  
  public synchronized CallableStatement prepareCall(String paramString) throws SQLException {
    return prepareCall(paramString, -1, -1);
  }

























  
  public synchronized CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2) throws SQLException {
    if (paramString == null || paramString.length() == 0) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 104);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.lifecycle != 1) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    OracleCallableStatement oracleCallableStatement = null;
    
    if (this.statementCache != null) {
      oracleCallableStatement = (OracleCallableStatement)this.statementCache.searchImplicitCache(paramString, 2, (paramInt1 != -1 || paramInt2 != -1) ? ResultSetUtil.getRsetTypeCode(paramInt1, paramInt2) : 1);
    }



    
    if (oracleCallableStatement == null) {
      oracleCallableStatement = this.driverExtension.allocateCallableStatement(this, paramString, paramInt1, paramInt2);
    }








    
    return (CallableStatement)new OracleCallableStatementWrapper((OracleCallableStatement)oracleCallableStatement);
  }















  
  public synchronized CallableStatement prepareCallWithKey(String paramString) throws SQLException {
    OracleCallableStatementWrapper oracleCallableStatementWrapper;
    if (this.lifecycle != 1) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (paramString == null) {
      return null;
    }
    if (!isStatementCacheInitialized()) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 




    
    OracleCallableStatement oracleCallableStatement = null;
    
    oracleCallableStatement = (OracleCallableStatement)this.statementCache.searchExplicitCache(paramString);








    
    if (oracleCallableStatement != null) {
      oracleCallableStatementWrapper = new OracleCallableStatementWrapper((OracleCallableStatement)oracleCallableStatement);
    }
    return (CallableStatement)oracleCallableStatementWrapper;
  }








  
  public String nativeSQL(String paramString) throws SQLException {
    if (this.sqlObj == null)
    {
      this.sqlObj = new OracleSql(this.conversion);
    }
    
    this.sqlObj.initialize(paramString);
    
    return this.sqlObj.getSql(this.processEscapes, this.convertNcharLiterals);
  }








  
  public synchronized void setAutoCommit(boolean paramBoolean) throws SQLException {
    if (paramBoolean) {
      disallowGlobalTxnMode(116);
    }
    if (this.lifecycle != 1) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    needLine();
    doSetAutoCommit(paramBoolean);
  }




  
  public boolean getAutoCommit() throws SQLException {
    return this.autocommit;
  }















  
  public void cancel() throws SQLException {
    OracleStatement oracleStatement = this.statements;
    
    if (this.lifecycle != 1 && this.lifecycle != 16) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    boolean bool = false;
    
    while (oracleStatement != null) {

      
      try {



        
        if (oracleStatement.doCancel()) {
          bool = true;
        }
      } catch (SQLException sQLException) {}


      
      oracleStatement = oracleStatement.next;
    } 

    
    if (!bool) {
      cancelOperationOnServer(false);
    }
  }


  
  public void commit(EnumSet<OracleConnection.CommitOption> paramEnumSet) throws SQLException {
    int i = 0;
    if (paramEnumSet != null) {
      
      if ((paramEnumSet.contains(OracleConnection.CommitOption.WRITEBATCH) && paramEnumSet.contains(OracleConnection.CommitOption.WRITEIMMED)) || (paramEnumSet.contains(OracleConnection.CommitOption.WAIT) && paramEnumSet.contains(OracleConnection.CommitOption.NOWAIT))) {




        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 191);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      for (OracleConnection.CommitOption commitOption : paramEnumSet)
        i |= commitOption.getCode(); 
    } 
    commit(i);
  }







  
  synchronized void commit(int paramInt) throws SQLException {
    disallowGlobalTxnMode(114);
    
    if (this.lifecycle != 1) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    OracleStatement oracleStatement = this.statements;
    
    while (oracleStatement != null) {



      
      if (!oracleStatement.closed) {
        oracleStatement.sendBatch();
      }
      oracleStatement = oracleStatement.next;
    } 
    if (((paramInt & OracleConnection.CommitOption.WRITEBATCH.getCode()) != 0 && (paramInt & OracleConnection.CommitOption.WRITEIMMED.getCode()) != 0) || ((paramInt & OracleConnection.CommitOption.WAIT.getCode()) != 0 && (paramInt & OracleConnection.CommitOption.NOWAIT.getCode()) != 0)) {




      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 191);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 




    
    registerHeartbeat();
    
    needLine();
    doCommit(paramInt);
  }


  
  public void commit() throws SQLException {
    commit(this.commitOption);
  }





  
  public synchronized void rollback() throws SQLException {
    disallowGlobalTxnMode(115);
    
    if (this.lifecycle != 1) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    OracleStatement oracleStatement = this.statements;
    
    while (oracleStatement != null) {
      
      if (oracleStatement.isOracleBatchStyle()) {
        oracleStatement.clearBatch();
      }
      oracleStatement = oracleStatement.next;
    } 




    
    registerHeartbeat();
    
    needLine();
    doRollback();
  }










  
  public synchronized void close() throws SQLException {
    if (this.lifecycle == 2 || this.lifecycle == 4) {
      return;
    }


    
    needLineUnchecked();

    
    try {
      if (this.closeCallback != null) {
        this.closeCallback.beforeClose(this, this.privateData);
      }
      closeStatementCache();
      closeStatements(false);
      
      if (this.lifecycle == 1) this.lifecycle = 2;

      
      if (this.isProxy)
      {
        close(1);
      }
      
      if (this.timeZoneTab != null) {
        this.timeZoneTab.freeInstance();
      }
      logoff();
      cleanup();
      
      if (this.timeout != null) {
        this.timeout.close();
      }
      if (this.closeCallback != null) {
        this.closeCallback.afterClose(this.privateData);
      }
    } finally {
      
      this.lifecycle = 4;
      this.isUsable = false;
    } 
  }






  
  public String getDataIntegrityAlgorithmName() throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }



  
  public String getEncryptionAlgorithmName() throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }



  
  public String getAuthenticationAdaptorName() throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }






  
  public void closeInternal(boolean paramBoolean) throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }







  
  public void cleanupAndClose(boolean paramBoolean) throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }







  
  void cleanupAndClose() throws SQLException {
    if (this.lifecycle != 1) {
      return;
    }


    
    this.lifecycle = 16;

    
    cancel();
  }



  
  synchronized void closeLogicalConnection() throws SQLException {
    if (this.lifecycle == 1 || this.lifecycle == 16 || this.lifecycle == 2) {


      
      this.savepointStatement = null;
      closeStatements(true);
      
      if (this.clientIdSet) {
        clearClientIdentifier(this.clientId);
      }
      this.logicalConnectionAttached = null;
      this.lifecycle = 1;
    } 
  }















  
  public synchronized void close(Properties paramProperties) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
    sQLException.fillInStackTrace();
    throw sQLException;
  }












  
  public synchronized void close(int paramInt) throws SQLException {
    if ((paramInt & 0x1000) != 0) {
      
      close();
      
      return;
    } 
    
    if ((paramInt & 0x1) != 0 && this.isProxy) {
      
      purgeStatementCache();
      closeStatements(false);
      this.descriptorCacheStack[this.dci--] = null;
      
      closeProxySession();
      
      this.isProxy = false;
    } 
  }



  
  private static final OracleSQLPermission CALL_ABORT_PERMISSION = new OracleSQLPermission("callAbort"); static final String DATABASE_NAME = "DATABASE_NAME"; static final String SERVER_HOST = "SERVER_HOST"; static final String INSTANCE_NAME = "INSTANCE_NAME"; static final String SERVICE_NAME = "SERVICE_NAME"; Hashtable clientData; private BufferCacheStore connectionBufferCacheStore; private static ThreadLocal<BufferCacheStore> threadLocalBufferCacheStore; private int pingResult; String sessionTimeZone; String databaseTimeZone; Calendar dbTzCalendar; static final String RAW_STR = "RAW"; static final String SYS_RAW_STR = "SYS.RAW"; static final String SYS_ANYDATA_STR = "SYS.ANYDATA"; static final String SYS_XMLTYPE_STR = "SYS.XMLTYPE";
  int timeZoneVersionNumber;
  TIMEZONETAB timeZoneTab;
  
  public void abort() throws SQLException {
    SecurityManager securityManager = System.getSecurityManager();
    if (securityManager != null) {
      securityManager.checkPermission((Permission)CALL_ABORT_PERMISSION);
    }


    
    if (this.lifecycle == 4 || this.lifecycle == 8) {
      return;
    }
    
    this.lifecycle = 8;

    
    doAbort();
  }









  
  void closeProxySession() throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }













  
  public Properties getServerSessionInfo() throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }









  
  public synchronized void applyConnectionAttributes(Properties paramProperties) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
    sQLException.fillInStackTrace();
    throw sQLException;
  }









  
  public synchronized Properties getConnectionAttributes() throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
    sQLException.fillInStackTrace();
    throw sQLException;
  }









  
  public synchronized Properties getUnMatchedConnectionAttributes() throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
    sQLException.fillInStackTrace();
    throw sQLException;
  }










  
  public synchronized void setAbandonedTimeoutEnabled(boolean paramBoolean) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
    sQLException.fillInStackTrace();
    throw sQLException;
  }









  
  public synchronized void registerConnectionCacheCallback(OracleConnectionCacheCallback paramOracleConnectionCacheCallback, Object paramObject, int paramInt) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
    sQLException.fillInStackTrace();
    throw sQLException;
  }









  
  public OracleConnectionCacheCallback getConnectionCacheCallbackObj() throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
    sQLException.fillInStackTrace();
    throw sQLException;
  }








  
  public Object getConnectionCacheCallbackPrivObj() throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
    sQLException.fillInStackTrace();
    throw sQLException;
  }








  
  public int getConnectionCacheCallbackFlag() throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
    sQLException.fillInStackTrace();
    throw sQLException;
  }









  
  public synchronized void setConnectionReleasePriority(int paramInt) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
    sQLException.fillInStackTrace();
    throw sQLException;
  }








  
  public int getConnectionReleasePriority() throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
    sQLException.fillInStackTrace();
    throw sQLException;
  }









  
  public synchronized boolean isClosed() throws SQLException {
    return (this.lifecycle != 1);
  }



  
  public synchronized boolean isProxySession() {
    return this.isProxy;
  }





  
  public synchronized void openProxySession(int paramInt, Properties paramProperties) throws SQLException {
    boolean bool = true;
    
    if (this.isProxy) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 149);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    String str1 = paramProperties.getProperty("PROXY_USER_NAME");
    String str2 = paramProperties.getProperty("PROXY_USER_PASSWORD");
    String str3 = paramProperties.getProperty("PROXY_DISTINGUISHED_NAME");
    
    Object object = paramProperties.get("PROXY_CERTIFICATE");
    
    if (paramInt == 1) {
      
      if (str1 == null && str2 == null)
      {
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
        sQLException.fillInStackTrace();
        throw sQLException;
      }
    
    } else if (paramInt == 2) {
      
      if (str3 == null)
      {
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
        sQLException.fillInStackTrace();
        throw sQLException;
      }
    
    } else if (paramInt == 3) {
      
      if (object == null) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      try {
        byte[] arrayOfByte = (byte[])object;
      }
      catch (ClassCastException classCastException) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
        sQLException.fillInStackTrace();
        throw sQLException;
      }
    
    }
    else {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    purgeStatementCache();
    closeStatements(false);


    
    try {
      doProxySession(paramInt, paramProperties);
      this.dci++;
      
      bool = false;
    
    }
    finally {
      
      if (bool == true) {
        closeProxySession();
      }
    } 
  }





  
  void doProxySession(int paramInt, Properties paramProperties) throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }






  
  void cleanup() {
    this.fdo = null;
    this.conversion = null;
    this.statements = null;
    this.descriptorCacheStack[this.dci] = null;
    this.map = null;
    this.javaObjectMap = null;
    this.statementHoldingLine = null;
    this.sqlObj = null;
    this.isProxy = false;
  }













  
  public synchronized DatabaseMetaData getMetaData() throws SQLException {
    if (this.lifecycle != 1) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.databaseMetaData == null) {
      this.databaseMetaData = new OracleDatabaseMetaData(this);
    }
    return (DatabaseMetaData)this.databaseMetaData;
  }













  
  public void setReadOnly(boolean paramBoolean) throws SQLException {
    this.readOnly = paramBoolean;
  }












  
  public boolean isReadOnly() throws SQLException {
    return this.readOnly;
  }








  
  public void setCatalog(String paramString) throws SQLException {}








  
  public String getCatalog() throws SQLException {
    return null;
  }






  
  public synchronized void setTransactionIsolation(int paramInt) throws SQLException {
    if (this.txnLevel == paramInt) {
      return;
    }
    Statement statement = createStatement();
    
    try {
      SQLException sQLException;
      switch (paramInt) {


        
        case 2:
          statement.execute("ALTER SESSION SET ISOLATION_LEVEL = READ COMMITTED");
          
          this.txnLevel = 2;
          break;



        
        case 8:
          statement.execute("ALTER SESSION SET ISOLATION_LEVEL = SERIALIZABLE");
          
          this.txnLevel = 8;
          break;



        
        default:
          sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 30);
          sQLException.fillInStackTrace();
          throw sQLException;
      } 




    
    } finally {
      statement.close();
    } 
  }




  
  public int getTransactionIsolation() throws SQLException {
    return this.txnLevel;
  }









  
  public synchronized void setAutoClose(boolean paramBoolean) throws SQLException {
    if (!paramBoolean) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 31);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }







  
  public boolean getAutoClose() throws SQLException {
    return true;
  }






  
  public SQLWarning getWarnings() throws SQLException {
    return this.sqlWarning;
  }



  
  public void clearWarnings() throws SQLException {
    this.sqlWarning = null;
  }



  
  public void setWarnings(SQLWarning paramSQLWarning) {
    this.sqlWarning = paramSQLWarning;
  }








































  
  public void setDefaultRowPrefetch(int paramInt) throws SQLException {
    if (paramInt <= 0) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 20);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.defaultRowPrefetch = paramInt;
  }























  
  public int getDefaultRowPrefetch() {
    return this.defaultRowPrefetch;
  }



  
  public boolean getTimestamptzInGmt() {
    return this.timestamptzInGmt;
  }



  
  public boolean getUse1900AsYearForTime() {
    return this.use1900AsYearForTime;
  }






































  
  public synchronized void setDefaultExecuteBatch(int paramInt) throws SQLException {
    if (paramInt <= 0) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 42);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.defaultExecuteBatch = paramInt;
  }
























  
  public synchronized int getDefaultExecuteBatch() {
    return this.defaultExecuteBatch;
  }



















  
  public synchronized void setRemarksReporting(boolean paramBoolean) {
    this.reportRemarks = paramBoolean;
  }









  
  public synchronized boolean getRemarksReporting() {
    return this.reportRemarks;
  }

















  
  public void setIncludeSynonyms(boolean paramBoolean) {
    this.includeSynonyms = paramBoolean;
  }









  
  public synchronized String[] getEndToEndMetrics() throws SQLException {
    String[] arrayOfString;
    if (this.endToEndValues == null) {
      
      arrayOfString = null;
    }
    else {
      
      arrayOfString = new String[this.endToEndValues.length];
      
      System.arraycopy(this.endToEndValues, 0, arrayOfString, 0, this.endToEndValues.length);
    } 
    return arrayOfString;
  }














  
  public short getEndToEndECIDSequenceNumber() throws SQLException {
    return this.endToEndECIDSequenceNumber;
  }











  
  public synchronized void setEndToEndMetrics(String[] paramArrayOfString, short paramShort) throws SQLException {
    String[] arrayOfString = new String[paramArrayOfString.length];
    
    System.arraycopy(paramArrayOfString, 0, arrayOfString, 0, paramArrayOfString.length);
    setEndToEndMetricsInternal(arrayOfString, paramShort);
  }











  
  void setEndToEndMetricsInternal(String[] paramArrayOfString, short paramShort) throws SQLException {
    if (paramArrayOfString != this.endToEndValues) {
      
      if (paramArrayOfString.length != 4) {


        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 156);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
      
      byte b;
      for (b = 0; b < 4; b++) {
        
        String str = paramArrayOfString[b];
        
        if (str != null && str.length() > this.endToEndMaxLength[b]) {

          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 159, str);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 
      } 

      
      if (this.endToEndValues != null) {
        
        for (b = 0; b < 4; b++) {
          
          String str = paramArrayOfString[b];
          
          if ((str == null && this.endToEndValues[b] != null) || (str != null && !str.equals(this.endToEndValues[b]))) {

            
            this.endToEndHasChanged[b] = true;
            this.endToEndAnyChanged = true;
          } 
        } 

        
        this.endToEndHasChanged[0] = this.endToEndHasChanged[0] | this.endToEndHasChanged[3];
      
      }
      else {
        
        for (b = 0; b < 4; b++)
        {
          this.endToEndHasChanged[b] = true;
        }
        
        this.endToEndAnyChanged = true;
      } 

      
      this.endToEndValues = paramArrayOfString;
    } 
    
    this.endToEndECIDSequenceNumber = paramShort;
  }













  
  void updateSystemContext() throws SQLException {}












  
  void resetSystemContext() {}












  
  void updateSystemContext11() throws SQLException {}












  
  public boolean getIncludeSynonyms() {
    return this.includeSynonyms;
  }





































  
  public void setRestrictGetTables(boolean paramBoolean) {
    this.restrictGettables = paramBoolean;
  }












  
  public boolean getRestrictGetTables() {
    return this.restrictGettables;
  }

























  
  public void setDefaultFixedString(boolean paramBoolean) {
    this.fixedString = paramBoolean;
  }





  
  public void setDefaultNChar(boolean paramBoolean) {
    this.defaultnchar = paramBoolean;
  }
























  
  public boolean getDefaultFixedString() {
    return this.fixedString;
  }









  
  public int getNlsRatio() {
    return 1;
  }



  
  public int getC2SNlsRatio() {
    return 1;
  }





  
  synchronized void addStatement(OracleStatement paramOracleStatement) {
    if (paramOracleStatement.next != null) {
      throw new Error("add_statement called twice on " + paramOracleStatement);
    }
    paramOracleStatement.next = this.statements;
    
    if (this.statements != null) {
      this.statements.prev = paramOracleStatement;
    }
    this.statements = paramOracleStatement;
  }















  
  synchronized void removeStatement(OracleStatement paramOracleStatement) {
    OracleStatement oracleStatement1 = paramOracleStatement.prev;
    OracleStatement oracleStatement2 = paramOracleStatement.next;
    
    if (oracleStatement1 == null) {
      
      if (this.statements != paramOracleStatement) {
        return;
      }
      this.statements = oracleStatement2;
    } else {
      
      oracleStatement1.next = oracleStatement2;
    } 
    if (oracleStatement2 != null) {
      oracleStatement2.prev = oracleStatement1;
    }
    paramOracleStatement.next = null;
    paramOracleStatement.prev = null;
  }


















  
  synchronized void closeStatements(boolean paramBoolean) throws SQLException {
    OracleStatement oracleStatement = this.statements;
    
    while (oracleStatement != null) {
      
      OracleStatement oracleStatement1 = oracleStatement.nextChild;
      
      if (oracleStatement.serverCursor) {
        
        oracleStatement.close();
        removeStatement(oracleStatement);
      } 
      
      oracleStatement = oracleStatement1;
    } 

    
    oracleStatement = this.statements;
    
    while (oracleStatement != null) {
      
      OracleStatement oracleStatement1 = oracleStatement.next;
      
      if (paramBoolean) {
        oracleStatement.close();
      } else {
        oracleStatement.hardClose();
      }  removeStatement(oracleStatement);
      
      oracleStatement = oracleStatement1;
    } 
  }






  
  final void purgeStatementCache() throws SQLException {
    if (isStatementCacheInitialized()) {
      
      this.statementCache.purgeImplicitCache();
      this.statementCache.purgeExplicitCache();
    } 
  }





  
  final void closeStatementCache() throws SQLException {
    if (isStatementCacheInitialized()) {


      
      this.statementCache.close();
      
      this.statementCache = null;
      this.clearStatementMetaData = true;
    } 
  }




  
  void needLine() throws SQLException {
    if (this.lifecycle != 1) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    needLineUnchecked();
  }






  
  synchronized void needLineUnchecked() throws SQLException {
    if (this.statementHoldingLine != null)
    {
      this.statementHoldingLine.freeLine();
    }
  }



  
  synchronized void holdLine(OracleStatement paramOracleStatement) {
    holdLine((OracleStatement)paramOracleStatement);
  }





  
  synchronized void holdLine(OracleStatement paramOracleStatement) {
    this.statementHoldingLine = paramOracleStatement;
  }




  
  synchronized void releaseLine() {
    releaseLineForCancel();
  }





  
  void releaseLineForCancel() {
    this.statementHoldingLine = null;
  }




  
  public synchronized void startup(String paramString, int paramInt) throws SQLException {
    if (this.lifecycle != 1) {
      
      SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
      sQLException1.fillInStackTrace();
      throw sQLException1;
    } 

    
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  public synchronized void startup(OracleConnection.DatabaseStartupMode paramDatabaseStartupMode) throws SQLException {
    if (this.lifecycle != 1) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    if (paramDatabaseStartupMode == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    needLine();
    doStartup(paramDatabaseStartupMode.getMode());
  }





  
  void doStartup(int paramInt) throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }





  
  public synchronized void shutdown(OracleConnection.DatabaseShutdownMode paramDatabaseShutdownMode) throws SQLException {
    if (this.lifecycle != 1) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    if (paramDatabaseShutdownMode == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    needLine();
    doShutdown(paramDatabaseShutdownMode.getMode());
  }





  
  void doShutdown(int paramInt) throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }







  
  public synchronized void archive(int paramInt1, int paramInt2, String paramString) throws SQLException {
    if (this.lifecycle != 1) {
      
      SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
      sQLException1.fillInStackTrace();
      throw sQLException1;
    } 

    
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }










  
  public synchronized void registerSQLType(String paramString1, String paramString2) throws SQLException {
    if (paramString1 == null || paramString2 == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    try {
      registerSQLType(paramString1, Class.forName(paramString2));
    }
    catch (ClassNotFoundException classNotFoundException) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Class not found: " + paramString2);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }






  
  public synchronized void registerSQLType(String paramString, Class<?> paramClass) throws SQLException {
    if (paramString == null || paramClass == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.map == null) this.map = new Hashtable<Object, Object>(10);
    
    this.map.put(paramString, paramClass);
    this.map.put(paramClass.getName(), paramString);
  }




  
  public synchronized String getSQLType(Object paramObject) throws SQLException {
    if (paramObject != null && this.map != null) {
      
      String str = paramObject.getClass().getName();
      
      return (String)this.map.get(str);
    } 
    
    return null;
  }




  
  public synchronized Object getJavaObject(String paramString) throws SQLException {
    Object object = null;

    
    try {
      if (paramString != null && this.map != null)
      {
        Class<Object> clazz = (Class)this.map.get(paramString);
        
        object = clazz.newInstance();
      }
    
    } catch (IllegalAccessException illegalAccessException) {
      
      illegalAccessException.printStackTrace();
    }
    catch (InstantiationException instantiationException) {
      
      instantiationException.printStackTrace();
    } 
    
    return object;
  }









  
  public synchronized void putDescriptor(String paramString, Object paramObject) throws SQLException {
    if (paramString != null && paramObject != null) {
      
      if (this.descriptorCacheStack[this.dci] == null) {
        this.descriptorCacheStack[this.dci] = new Hashtable<Object, Object>(10);
      }
      ((TypeDescriptor)paramObject).fixupConnection(this);
      this.descriptorCacheStack[this.dci].put(paramString, paramObject);
    }
    else {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }







  
  public synchronized Object getDescriptor(String paramString) {
    Object object = null;
    
    if (paramString != null) {
      if (this.descriptorCacheStack[this.dci] != null)
        object = this.descriptorCacheStack[this.dci].get(paramString); 
      if (object == null && this.dci == 1 && this.descriptorCacheStack[0] != null) {
        object = this.descriptorCacheStack[0].get(paramString);
      }
    } 
    return object;
  }








  
  public synchronized void removeDecriptor(String paramString) {
    removeDescriptor(paramString);
  }










  
  public synchronized void removeDescriptor(String paramString) {
    if (paramString != null && this.descriptorCacheStack[this.dci] != null)
      this.descriptorCacheStack[this.dci].remove(paramString); 
    if (paramString != null && this.dci == 1 && this.descriptorCacheStack[0] != null) {
      this.descriptorCacheStack[0].remove(paramString);
    }
  }






  
  public synchronized void removeAllDescriptor() {
    for (byte b = 0; b <= this.dci; b++) {
      if (this.descriptorCacheStack[b] != null) {
        this.descriptorCacheStack[b].clear();
      }
    } 
  }











  
  public int numberOfDescriptorCacheEntries() {
    int i = 0;
    for (byte b = 0; b <= this.dci; b++) {
      if (this.descriptorCacheStack[b] != null)
        i += this.descriptorCacheStack[b].size(); 
    } 
    return i;
  }









  
  public Enumeration descriptorCacheKeys() {
    if (this.dci == 0) {
      if (this.descriptorCacheStack[this.dci] != null) {
        return this.descriptorCacheStack[this.dci].keys();
      }
      return null;
    } 
    if (this.descriptorCacheStack[0] == null && this.descriptorCacheStack[1] != null)
      return this.descriptorCacheStack[1].keys(); 
    if (this.descriptorCacheStack[1] == null && this.descriptorCacheStack[0] != null)
      return this.descriptorCacheStack[0].keys(); 
    if (this.descriptorCacheStack[0] == null && this.descriptorCacheStack[1] == null) {
      return null;
    }
    Vector vector = new Vector(this.descriptorCacheStack[1].keySet());
    vector.addAll(this.descriptorCacheStack[0].keySet());
    return vector.elements();
  }










  
  public synchronized void putDescriptor(byte[] paramArrayOfbyte, Object paramObject) throws SQLException {
    if (paramArrayOfbyte != null && paramObject != null) {
      
      if (this.descriptorCacheStack[this.dci] == null) {
        this.descriptorCacheStack[this.dci] = new Hashtable<Object, Object>(10);
      }
      this.descriptorCacheStack[this.dci].put(new ByteArrayKey(paramArrayOfbyte), paramObject);
    }
    else {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }







  
  public synchronized Object getDescriptor(byte[] paramArrayOfbyte) {
    Object object = null;
    
    if (paramArrayOfbyte != null) {
      ByteArrayKey byteArrayKey = new ByteArrayKey(paramArrayOfbyte);
      if (this.descriptorCacheStack[this.dci] != null)
        object = this.descriptorCacheStack[this.dci].get(byteArrayKey); 
      if (object == null && this.dci == 1 && this.descriptorCacheStack[0] != null) {
        object = this.descriptorCacheStack[0].get(byteArrayKey);
      }
    } 
    return object;
  }








  
  public synchronized void removeDecriptor(byte[] paramArrayOfbyte) {
    if (paramArrayOfbyte != null) {
      ByteArrayKey byteArrayKey = new ByteArrayKey(paramArrayOfbyte);
      if (this.descriptorCacheStack[this.dci] != null)
        this.descriptorCacheStack[this.dci].remove(byteArrayKey); 
      if (this.dci == 1 && this.descriptorCacheStack[0] != null) {
        this.descriptorCacheStack[0].remove(byteArrayKey);
      }
    } 
  }

















  
  public short getJdbcCsId() throws SQLException {
    if (this.conversion == null) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 65);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    return this.conversion.getClientCharSet();
  }











  
  public short getDbCsId() throws SQLException {
    if (this.conversion == null) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 65);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    return this.conversion.getServerCharSetId();
  }



  
  public short getNCsId() throws SQLException {
    if (this.conversion == null) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 65);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    return this.conversion.getNCharSetId();
  }












  
  public short getStructAttrCsId() throws SQLException {
    return getDbCsId();
  }



  
  public short getStructAttrNCsId() throws SQLException {
    return getNCsId();
  }






  
  public synchronized Map getTypeMap() {
    if (this.map == null) this.map = new Hashtable<Object, Object>(10); 
    return this.map;
  }



  
  public synchronized void setTypeMap(Map paramMap) {
    this.map = paramMap;
  }




  
  public synchronized void setUsingXAFlag(boolean paramBoolean) {
    this.usingXA = paramBoolean;
  }



  
  public synchronized boolean getUsingXAFlag() {
    return this.usingXA;
  }




  
  public synchronized void setXAErrorFlag(boolean paramBoolean) {
    this.xaWantsError = paramBoolean;
  }



  
  public synchronized boolean getXAErrorFlag() {
    return this.xaWantsError;
  }




  
  String getPropertyFromDatabase(String paramString) throws SQLException {
    String str = null;
    Statement statement = null;
    ResultSet resultSet = null;
    
    try {
      statement = createStatement();
      statement.setFetchSize(1);
      resultSet = statement.executeQuery(paramString);
      if (resultSet.next()) {
        str = resultSet.getString(1);
      }
    } finally {
      
      if (resultSet != null)
        resultSet.close(); 
      if (statement != null)
        statement.close(); 
    } 
    return str;
  }




  
  public synchronized String getUserName() throws SQLException {
    if (this.userName == null) {
      this.userName = getPropertyFromDatabase("SELECT USER FROM DUAL");
    }
    return this.userName;
  }











  
  public String getCurrentSchema() throws SQLException {
    return getPropertyFromDatabase("SELECT SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA') FROM DUAL");
  }














  
  public String getDefaultSchemaNameForNamedTypes() throws SQLException {
    String str = null;
    
    if (this.createDescriptorUseCurrentSchemaForSchemaName) {
      str = getCurrentSchema();
    } else {
      str = getUserName();
    } 
    return str;
  }














  
  public synchronized void setStartTime(long paramLong) throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
    sQLException.fillInStackTrace();
    throw sQLException;
  }












  
  public synchronized long getStartTime() throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
    sQLException.fillInStackTrace();
    throw sQLException;
  }









  
  void registerHeartbeat() throws SQLException {
    if (this.logicalConnectionAttached != null) {
      this.logicalConnectionAttached.registerHeartbeat();
    }
  }







  
  public int getHeartbeatNoChangeCount() throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
    sQLException.fillInStackTrace();
    throw sQLException;
  }








  
  public synchronized byte[] getFDO(boolean paramBoolean) throws SQLException {
    if (this.fdo == null && paramBoolean) {
      
      CallableStatement callableStatement = null;

      
      try {
        callableStatement = prepareCall("begin :1 := dbms_pickler.get_format (:2); end;");

        
        callableStatement.registerOutParameter(1, 2);
        callableStatement.registerOutParameter(2, -4);
        callableStatement.execute();
        
        this.fdo = callableStatement.getBytes(2);
      }
      finally {
        
        if (callableStatement != null) {
          callableStatement.close();
        }
        callableStatement = null;
      } 
    } 
    
    return this.fdo;
  }







  
  public synchronized void setFDO(byte[] paramArrayOfbyte) throws SQLException {
    this.fdo = paramArrayOfbyte;
  }







  
  public synchronized boolean getBigEndian() throws SQLException {
    if (this.bigEndian == null) {
      
      int[] arrayOfInt = Util.toJavaUnsignedBytes(getFDO(true));


      
      int i = arrayOfInt[6 + arrayOfInt[5] + arrayOfInt[6] + 5];



      
      int j = (byte)(i & 0x10);
      
      if (j < 0) {
        j = j + 256;
      }
      if (j > 0) {
        this.bigEndian = Boolean.TRUE;
      } else {
        this.bigEndian = Boolean.FALSE;
      } 
    } 
    return this.bigEndian.booleanValue();
  }
























  
  public void setHoldability(int paramInt) throws SQLException {}























  
  public int getHoldability() throws SQLException {
    return 1;
  }





  
  public synchronized Savepoint setSavepoint() throws SQLException {
    return (Savepoint)oracleSetSavepoint();
  }






  
  public synchronized Savepoint setSavepoint(String paramString) throws SQLException {
    return (Savepoint)oracleSetSavepoint(paramString);
  }







  
  public synchronized void rollback(Savepoint paramSavepoint) throws SQLException {
    disallowGlobalTxnMode(122);

    
    if (this.autocommit) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 121);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.savepointStatement == null)
    {
      this.savepointStatement = createStatement();
    }
    
    String str = null;

    
    try {
      str = paramSavepoint.getSavepointName();
    }
    catch (SQLException sQLException) {
      
      str = "ORACLE_SVPT_" + paramSavepoint.getSavepointId();
    } 
    
    this.savepointStatement.executeUpdate("ROLLBACK TO " + str);
  }






  
  public synchronized void releaseSavepoint(Savepoint paramSavepoint) throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }










































  
  public Statement createStatement(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
    return createStatement(paramInt1, paramInt2);
  }















































  
  public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
    return prepareStatement(paramString, paramInt1, paramInt2);
  }












































  
  public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
    return prepareCall(paramString, paramInt1, paramInt2);
  }














































  
  public PreparedStatement prepareStatement(String paramString, int paramInt) throws SQLException {
    AutoKeyInfo autoKeyInfo = new AutoKeyInfo(paramString);
    if (paramInt == 2 || !autoKeyInfo.isInsertSqlStmt())
    {
      return prepareStatement(paramString);
    }
    if (paramInt != 1) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    String str = autoKeyInfo.getNewSql();
    OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)prepareStatement(str);
    OraclePreparedStatement oraclePreparedStatement1 = (OraclePreparedStatement)((OraclePreparedStatementWrapper)oraclePreparedStatement).preparedStatement;
    
    oraclePreparedStatement1.isAutoGeneratedKey = true;
    oraclePreparedStatement1.autoKeyInfo = autoKeyInfo;
    oraclePreparedStatement1.registerReturnParamsForAutoKey();
    return (PreparedStatement)oraclePreparedStatement;
  }













































  
  public PreparedStatement prepareStatement(String paramString, int[] paramArrayOfint) throws SQLException {
    AutoKeyInfo autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfint);
    
    if (!autoKeyInfo.isInsertSqlStmt()) return prepareStatement(paramString);
    
    if (paramArrayOfint == null || paramArrayOfint.length == 0) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    doDescribeTable(autoKeyInfo);
    
    String str = autoKeyInfo.getNewSql();
    OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)prepareStatement(str);
    OraclePreparedStatement oraclePreparedStatement1 = (OraclePreparedStatement)((OraclePreparedStatementWrapper)oraclePreparedStatement).preparedStatement;
    
    oraclePreparedStatement1.isAutoGeneratedKey = true;
    oraclePreparedStatement1.autoKeyInfo = autoKeyInfo;
    oraclePreparedStatement1.registerReturnParamsForAutoKey();
    return (PreparedStatement)oraclePreparedStatement;
  }














































  
  public PreparedStatement prepareStatement(String paramString, String[] paramArrayOfString) throws SQLException {
    AutoKeyInfo autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfString);
    if (!autoKeyInfo.isInsertSqlStmt()) return prepareStatement(paramString);
    
    if (paramArrayOfString == null || paramArrayOfString.length == 0) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    doDescribeTable(autoKeyInfo);
    
    String str = autoKeyInfo.getNewSql();
    OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)prepareStatement(str);
    OraclePreparedStatement oraclePreparedStatement1 = (OraclePreparedStatement)((OraclePreparedStatementWrapper)oraclePreparedStatement).preparedStatement;
    
    oraclePreparedStatement1.isAutoGeneratedKey = true;
    oraclePreparedStatement1.autoKeyInfo = autoKeyInfo;
    oraclePreparedStatement1.registerReturnParamsForAutoKey();
    return (PreparedStatement)oraclePreparedStatement;
  }






















  
  public synchronized OracleSavepoint oracleSetSavepoint() throws SQLException {
    disallowGlobalTxnMode(117);

    
    if (this.autocommit) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 120);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.savepointStatement == null)
    {
      this.savepointStatement = createStatement();
    }
    
    OracleSavepoint oracleSavepoint = new OracleSavepoint();
    
    String str = "SAVEPOINT ORACLE_SVPT_" + oracleSavepoint.getSavepointId();
    
    this.savepointStatement.executeUpdate(str);

    
    return oracleSavepoint;
  }























  
  public synchronized OracleSavepoint oracleSetSavepoint(String paramString) throws SQLException {
    disallowGlobalTxnMode(117);

    
    if (this.autocommit) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 120);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.savepointStatement == null)
    {
      this.savepointStatement = createStatement();
    }
    
    OracleSavepoint oracleSavepoint = new OracleSavepoint(paramString);
    
    String str = "SAVEPOINT " + oracleSavepoint.getSavepointName();
    
    this.savepointStatement.executeUpdate(str);

    
    return oracleSavepoint;
  }
























  
  public synchronized void oracleRollback(OracleSavepoint paramOracleSavepoint) throws SQLException {
    disallowGlobalTxnMode(115);

    
    if (this.autocommit) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 121);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.savepointStatement == null)
    {
      this.savepointStatement = createStatement();
    }
    
    String str = null;

    
    try {
      str = paramOracleSavepoint.getSavepointName();
    }
    catch (SQLException sQLException) {
      
      str = "ORACLE_SVPT_" + paramOracleSavepoint.getSavepointId();
    } 
    
    this.savepointStatement.executeUpdate("ROLLBACK TO " + str);
  }
























  
  public synchronized void oracleReleaseSavepoint(OracleSavepoint paramOracleSavepoint) throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }

















  
  void disallowGlobalTxnMode(int paramInt) throws SQLException {
    if (this.txnMode == 1) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), paramInt);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }









  
  public void setTxnMode(int paramInt) {
    this.txnMode = paramInt;
  }



  
  public int getTxnMode() {
    return this.txnMode;
  }

























  
  public synchronized Object getClientData(Object paramObject) {
    if (this.clientData == null)
    {
      return null;
    }
    
    return this.clientData.get(paramObject);
  }























  
  public synchronized Object setClientData(Object paramObject1, Object paramObject2) {
    if (this.clientData == null)
    {
      this.clientData = new Hashtable<Object, Object>();
    }
    
    return this.clientData.put(paramObject1, paramObject2);
  }

















  
  public synchronized Object removeClientData(Object paramObject) {
    if (this.clientData == null)
    {
      return null;
    }
    
    return this.clientData.remove(paramObject);
  }




  
  public BlobDBAccess createBlobDBAccess() throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }





  
  public ClobDBAccess createClobDBAccess() throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }





  
  public BfileDBAccess createBfileDBAccess() throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }





















  
  public void printState() {
    try {
      short s1 = getJdbcCsId();

      
      short s2 = getDbCsId();

      
      short s3 = getStructAttrCsId();
    
    }
    catch (SQLException sQLException) {
      
      sQLException.printStackTrace();
    } 
  }







  
  public String getProtocolType() {
    return this.protocol;
  }







  
  public String getURL() {
    return this.url;
  }










  
  public synchronized void setStmtCacheSize(int paramInt) throws SQLException {
    setStatementCacheSize(paramInt);
    setImplicitCachingEnabled(true);
    setExplicitCachingEnabled(true);
  }











  
  public synchronized void setStmtCacheSize(int paramInt, boolean paramBoolean) throws SQLException {
    setStatementCacheSize(paramInt);
    setImplicitCachingEnabled(true);

    
    setExplicitCachingEnabled(true);
    
    this.clearStatementMetaData = paramBoolean;
  }










  
  public synchronized int getStmtCacheSize() {
    int i = 0;

    
    try {
      i = getStatementCacheSize();
    }
    catch (SQLException sQLException) {}




    
    if (i == -1)
    {


      
      i = 0;
    }
    
    return i;
  }

















  
  public synchronized void setStatementCacheSize(int paramInt) throws SQLException {
    if (this.statementCache == null) {
      
      this.statementCache = new LRUStatementCache(paramInt);

    
    }
    else {

      
      this.statementCache.resize(paramInt);
    } 
  }














  
  public synchronized int getStatementCacheSize() throws SQLException {
    if (this.statementCache == null) {
      return -1;
    }
    return this.statementCache.getCacheSize();
  }



















  
  public synchronized void setImplicitCachingEnabled(boolean paramBoolean) throws SQLException {
    if (this.statementCache == null)
    {


      
      this.statementCache = new LRUStatementCache(0);
    }




    
    this.statementCache.setImplicitCachingEnabled(paramBoolean);
  }















  
  public synchronized boolean getImplicitCachingEnabled() throws SQLException {
    if (this.statementCache == null) {
      return false;
    }
    return this.statementCache.getImplicitCachingEnabled();
  }



















  
  public synchronized void setExplicitCachingEnabled(boolean paramBoolean) throws SQLException {
    if (this.statementCache == null)
    {


      
      this.statementCache = new LRUStatementCache(0);
    }




    
    this.statementCache.setExplicitCachingEnabled(paramBoolean);
  }















  
  public synchronized boolean getExplicitCachingEnabled() throws SQLException {
    if (this.statementCache == null) {
      return false;
    }
    return this.statementCache.getExplicitCachingEnabled();
  }















  
  public synchronized void purgeImplicitCache() throws SQLException {
    if (this.statementCache != null) {
      this.statementCache.purgeImplicitCache();
    }
  }














  
  public synchronized void purgeExplicitCache() throws SQLException {
    if (this.statementCache != null) {
      this.statementCache.purgeExplicitCache();
    }
  }

















  
  public synchronized PreparedStatement getStatementWithKey(String paramString) throws SQLException {
    if (this.statementCache != null) {
      
      OracleStatement oracleStatement = this.statementCache.searchExplicitCache(paramString);

      
      if (oracleStatement == null || oracleStatement.statementType == 1) {
        return (PreparedStatement)oracleStatement;
      }

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 125);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    return null;
  }


















  
  public synchronized CallableStatement getCallWithKey(String paramString) throws SQLException {
    if (this.statementCache != null) {
      
      OracleStatement oracleStatement = this.statementCache.searchExplicitCache(paramString);

      
      if (oracleStatement == null || oracleStatement.statementType == 2) {
        return (CallableStatement)oracleStatement;
      }

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 125);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    return null;
  }












  
  public synchronized void cacheImplicitStatement(OraclePreparedStatement paramOraclePreparedStatement, String paramString, int paramInt1, int paramInt2) throws SQLException {
    if (this.statementCache == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.statementCache.addToImplicitCache(paramOraclePreparedStatement, paramString, paramInt1, paramInt2);
  }













  
  public synchronized void cacheExplicitStatement(OraclePreparedStatement paramOraclePreparedStatement, String paramString) throws SQLException {
    if (this.statementCache == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.statementCache.addToExplicitCache(paramOraclePreparedStatement, paramString);
  }











  
  public synchronized boolean isStatementCacheInitialized() {
    if (this.statementCache == null)
      return false; 
    if (this.statementCache.getCacheSize() == 0) {
      return false;
    }
    return true;
  }































  
  private static final class BufferCacheStore
  {
    static int MAX_CACHED_BUFFER_SIZE = Integer.MAX_VALUE;
    final BufferCache<byte[]> byteBufferCache;
    final BufferCache<char[]> charBufferCache;
    
    BufferCacheStore() {
      this(MAX_CACHED_BUFFER_SIZE);
    }
    
    BufferCacheStore(int param1Int) {
      this.byteBufferCache = (BufferCache)new BufferCache<byte>(param1Int);
      this.charBufferCache = (BufferCache)new BufferCache<char>(param1Int);
    }
  }






  
  private BufferCacheStore getBufferCacheStore() {
    if (this.useThreadLocalBufferCache) {
      if (threadLocalBufferCacheStore == null) {











        
        BufferCacheStore.MAX_CACHED_BUFFER_SIZE = this.maxCachedBufferSize;
        threadLocalBufferCacheStore = new ThreadLocal<BufferCacheStore>()
          {
            protected PhysicalConnection.BufferCacheStore initialValue()
            {
              return new PhysicalConnection.BufferCacheStore();
            }
          };
      } 
      return threadLocalBufferCacheStore.get();
    } 
    
    if (this.connectionBufferCacheStore == null)
    {
      this.connectionBufferCacheStore = new BufferCacheStore(this.maxCachedBufferSize);
    }
    return this.connectionBufferCacheStore;
  }







  
  void cacheBuffer(byte[] paramArrayOfbyte) {
    if (paramArrayOfbyte != null) {
      BufferCacheStore bufferCacheStore = getBufferCacheStore();
      bufferCacheStore.byteBufferCache.put(paramArrayOfbyte);
    } 
  }







  
  void cacheBuffer(char[] paramArrayOfchar) {
    if (paramArrayOfchar != null) {
      BufferCacheStore bufferCacheStore = getBufferCacheStore();
      bufferCacheStore.charBufferCache.put(paramArrayOfchar);
    } 
  }

  
  public void cacheBufferSync(char[] paramArrayOfchar) {
    synchronized (this) {
      cacheBuffer(paramArrayOfchar);
    } 
  }







  
  byte[] getByteBuffer(int paramInt) {
    BufferCacheStore bufferCacheStore = getBufferCacheStore();
    return bufferCacheStore.byteBufferCache.get(byte.class, paramInt);
  }








  
  char[] getCharBuffer(int paramInt) {
    BufferCacheStore bufferCacheStore = getBufferCacheStore();
    return bufferCacheStore.charBufferCache.get(char.class, paramInt);
  }

  
  public char[] getCharBufferSync(int paramInt) {
    synchronized (this) {
      return getCharBuffer(paramInt);
    } 
  }






  
  public OracleConnection.BufferCacheStatistics getByteBufferCacheStatistics() {
    BufferCacheStore bufferCacheStore = getBufferCacheStore();
    return bufferCacheStore.byteBufferCache.getStatistics();
  }







  
  public OracleConnection.BufferCacheStatistics getCharBufferCacheStatistics() {
    BufferCacheStore bufferCacheStore = getBufferCacheStore();
    return bufferCacheStore.charBufferCache.getStatistics();
  }



















  
  public synchronized void registerTAFCallback(OracleOCIFailover paramOracleOCIFailover, Object paramObject) throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }









  
  public String getDatabaseProductVersion() throws SQLException {
    if (this.databaseProductVersion == "") {
      
      needLine();
      
      this.databaseProductVersion = doGetDatabaseProductVersion();
    } 
    
    return this.databaseProductVersion;
  }



  
  public synchronized boolean getReportRemarks() {
    return this.reportRemarks;
  }



  
  public short getVersionNumber() throws SQLException {
    if (this.versionNumber == -1)
    {
      synchronized (this) {
        
        if (this.versionNumber == -1) {
          
          needLine();
          
          this.versionNumber = doGetVersionNumber();
        } 
      } 
    }
    
    return this.versionNumber;
  }




  
  public synchronized void registerCloseCallback(OracleCloseCallback paramOracleCloseCallback, Object paramObject) {
    this.closeCallback = paramOracleCloseCallback;
    this.privateData = paramObject;
  }





















  
  public void setCreateStatementAsRefCursor(boolean paramBoolean) {}





















  
  public boolean getCreateStatementAsRefCursor() {
    return false;
  }







  
  public int pingDatabase() throws SQLException {
    if (this.lifecycle != 1)
      return -1; 
    return doPingDatabase();
  }









  
  public int pingDatabase(int paramInt) throws SQLException {
    if (this.lifecycle != 1)
      return -1; 
    if (paramInt == 0) {
      return pingDatabase();
    }
    
    try {
      this.pingResult = -2;
      Thread thread = new Thread(new Runnable() {
            public void run() {
              try {
                PhysicalConnection.this.pingResult = PhysicalConnection.this.doPingDatabase();
              }
              catch (Throwable throwable) {}
            }
          });
      thread.start();
      thread.join((paramInt * 1000));
      return this.pingResult;
    }
    catch (InterruptedException interruptedException) {
      return -3;
    } 
  }




  
  int doPingDatabase() throws SQLException {
    Statement statement = null;

    
    try {
      statement = createStatement();
      
      ((OracleStatement)statement).defineColumnType(1, 12, 1);
      statement.executeQuery("SELECT 'x' FROM DUAL");
    }
    catch (SQLException sQLException) {
      
      return -1;
    }
    finally {
      
      if (statement != null) {
        statement.close();
      }
    } 
    return 0;
  }












  
  public synchronized Map getJavaObjectTypeMap() {
    return this.javaObjectMap;
  }






  
  public synchronized void setJavaObjectTypeMap(Map paramMap) {
    this.javaObjectMap = paramMap;
  }











  
  public void clearClientIdentifier(String paramString) throws SQLException {
    if (paramString != null && paramString.length() != 0) {


      
      String[] arrayOfString = getEndToEndMetrics();
      
      if (arrayOfString != null && paramString.equals(arrayOfString[1])) {

        
        arrayOfString[1] = null;
        
        setEndToEndMetrics(arrayOfString, getEndToEndECIDSequenceNumber());
      } 
    } 
  }
















  
  public void setClientIdentifier(String paramString) throws SQLException {
    String[] arrayOfString = getEndToEndMetrics();
    
    if (arrayOfString == null)
    {
      arrayOfString = new String[4];
    }

    
    arrayOfString[1] = paramString;
    
    setEndToEndMetrics(arrayOfString, getEndToEndECIDSequenceNumber());
  }







  
  protected PhysicalConnection()
  {
    this.sessionTimeZone = null;
    this.databaseTimeZone = null;
    this.dbTzCalendar = null;




































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































    
    this.timeZoneVersionNumber = -1;
    this.timeZoneTab = null; this.cancelInProgressLockForThin = new Object(); } public void setSessionTimeZone(String paramString) throws SQLException { Statement statement = null; Object object = null; try { statement = createStatement(); statement.executeUpdate("ALTER SESSION SET TIME_ZONE = '" + paramString + "'"); if (this.dbTzCalendar == null) setDbTzCalendar(getDatabaseTimeZone());  } catch (SQLException sQLException) { throw sQLException; } finally { if (statement != null) statement.close();  }  this.sessionTimeZone = paramString; } public String getDatabaseTimeZone() throws SQLException { if (this.databaseTimeZone == null) this.databaseTimeZone = getPropertyFromDatabase("SELECT DBTIMEZONE FROM DUAL");  return this.databaseTimeZone; } public String getSessionTimeZone() { return this.sessionTimeZone; } private static String to2DigitString(int paramInt) { String str; if (paramInt < 10) { str = "0" + paramInt; } else { str = "" + paramInt; }  return str; } public String tzToOffset(String paramString) { if (paramString == null) return paramString;  char c = paramString.charAt(0); if (c != '-' && c != '+') { TimeZone timeZone = TimeZone.getTimeZone(paramString); int i = timeZone.getOffset(System.currentTimeMillis()); if (i != 0) { int j = i / 60000; int k = j / 60; j -= k * 60; if (i > 0) { paramString = "+" + to2DigitString(k) + ":" + to2DigitString(j); } else { paramString = "-" + to2DigitString(-k) + ":" + to2DigitString(-j); }  } else { paramString = "+00:00"; }  }  return paramString; } public String getSessionTimeZoneOffset() throws SQLException { String str = getPropertyFromDatabase("SELECT SESSIONTIMEZONE FROM DUAL"); if (str != null) str = tzToOffset(str.trim());  return str; } private void setDbTzCalendar(String paramString) { char c = paramString.charAt(0); if (c == '-' || c == '+') paramString = "GMT" + paramString;  TimeZone timeZone = TimeZone.getTimeZone(paramString); this.dbTzCalendar = new GregorianCalendar(timeZone); } public Calendar getDbTzCalendar() throws SQLException { if (this.dbTzCalendar == null) setDbTzCalendar(getDatabaseTimeZone());  return this.dbTzCalendar; } public void setAccumulateBatchResult(boolean paramBoolean) { this.accumulateBatchResult = paramBoolean; } public boolean isAccumulateBatchResult() { return this.accumulateBatchResult; } public void setJ2EE13Compliant(boolean paramBoolean) { this.j2ee13Compliant = paramBoolean; } public boolean getJ2EE13Compliant() { return this.j2ee13Compliant; } public Class classForNameAndSchema(String paramString1, String paramString2) throws ClassNotFoundException { return Class.forName(paramString1); } public Class safelyGetClassForName(String paramString) throws ClassNotFoundException { return Class.forName(paramString); } public int getHeapAllocSize() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException1.fillInStackTrace(); throw sQLException1; }  SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public int getOCIEnvHeapAllocSize() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException1.fillInStackTrace(); throw sQLException1; }  SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public static OracleConnection unwrapCompletely(OracleConnection paramOracleConnection) { OracleConnection oracleConnection1 = paramOracleConnection; OracleConnection oracleConnection2 = oracleConnection1; while (true) { if (oracleConnection2 == null) return (OracleConnection)oracleConnection1;  oracleConnection1 = oracleConnection2; oracleConnection2 = oracleConnection1.unwrap(); }  } public void setWrapper(OracleConnection paramOracleConnection) { this.wrapper = paramOracleConnection; } public OracleConnection unwrap() { return null; } public OracleConnection getWrapper() { if (this.wrapper != null) return this.wrapper;  return (OracleConnection)this; } static OracleConnection _physicalConnectionWithin(Connection paramConnection) { OracleConnection oracleConnection = null; if (paramConnection != null) oracleConnection = unwrapCompletely((OracleConnection)paramConnection);  return oracleConnection; } public OracleConnection physicalConnectionWithin() { return this; } public long getTdoCState(String paramString1, String paramString2) throws SQLException { return 0L; } public void getOracleTypeADT(OracleTypeADT paramOracleTypeADT) throws SQLException {} public Datum toDatum(CustomDatum paramCustomDatum) throws SQLException { return paramCustomDatum.toDatum(this); } public short getNCharSet() { return this.conversion.getNCharSetId(); } public ResultSet newArrayDataResultSet(Datum[] paramArrayOfDatum, long paramLong, int paramInt, Map paramMap) throws SQLException { return (ResultSet)new ArrayDataResultSet(this, paramArrayOfDatum, paramLong, paramInt, paramMap); } public ResultSet newArrayDataResultSet(ARRAY paramARRAY, long paramLong, int paramInt, Map paramMap) throws SQLException { return (ResultSet)new ArrayDataResultSet(this, paramARRAY, paramLong, paramInt, paramMap); } public ResultSet newArrayLocatorResultSet(ArrayDescriptor paramArrayDescriptor, byte[] paramArrayOfbyte, long paramLong, int paramInt, Map paramMap) throws SQLException { return (ResultSet)new ArrayLocatorResultSet(this, paramArrayDescriptor, paramArrayOfbyte, paramLong, paramInt, paramMap); } public ResultSetMetaData newStructMetaData(StructDescriptor paramStructDescriptor) throws SQLException { return (ResultSetMetaData)new StructMetaData(paramStructDescriptor); } public int CHARBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt, char[] paramArrayOfchar) throws SQLException { int[] arrayOfInt = new int[1]; arrayOfInt[0] = paramInt; return this.conversion.CHARBytesToJavaChars(paramArrayOfbyte, 0, paramArrayOfchar, 0, arrayOfInt, paramArrayOfchar.length); } public int NCHARBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt, char[] paramArrayOfchar) throws SQLException { int[] arrayOfInt = new int[1]; return this.conversion.NCHARBytesToJavaChars(paramArrayOfbyte, 0, paramArrayOfchar, 0, arrayOfInt, paramArrayOfchar.length); } public boolean IsNCharFixedWith() { return this.conversion.IsNCharFixedWith(); } public short getDriverCharSet() { return this.conversion.getClientCharSet(); } public int getMaxCharSize() throws SQLException { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 58); sQLException.fillInStackTrace(); throw sQLException; } public int getMaxCharbyteSize() { return this.conversion.getMaxCharbyteSize(); } public int getMaxNCharbyteSize() { return this.conversion.getMaxNCharbyteSize(); } PhysicalConnection(String paramString, Properties paramProperties, OracleDriverExtension paramOracleDriverExtension) throws SQLException { this.sessionTimeZone = null; this.databaseTimeZone = null; this.dbTzCalendar = null; this.timeZoneVersionNumber = -1; this.timeZoneTab = null; this.cancelInProgressLockForThin = new Object(); readConnectionProperties(paramString, paramProperties); this.driverExtension = paramOracleDriverExtension; initialize((Hashtable)null, (Map)null, (Map)null); this.logicalConnectionAttached = null; try { needLine(); logon(); setAutoCommit(this.autocommit); if (getVersionNumber() >= 11202) { this.minVcsBindSize = 4001; this.maxRawBytesSql = 4000; this.maxRawBytesPlsql = 32766; this.maxVcsCharsSql = 32766; this.maxVcsNCharsSql = 32766; this.maxVcsBytesPlsql = 32766; this.maxIbtVarcharElementLength = 32766; this.endToEndMaxLength[0] = 64; this.endToEndMaxLength[1] = 64; this.endToEndMaxLength[2] = 64; this.endToEndMaxLength[3] = 64; } else if (getVersionNumber() >= 11000) { this.minVcsBindSize = 4001; this.maxRawBytesSql = 4000; this.maxRawBytesPlsql = 32766; this.maxVcsCharsSql = 32766; this.maxVcsNCharsSql = 32766; this.maxVcsBytesPlsql = 32766; this.maxIbtVarcharElementLength = 32766; this.endToEndMaxLength[0] = 32; this.endToEndMaxLength[1] = 64; this.endToEndMaxLength[2] = 64; this.endToEndMaxLength[3] = 48; } else if (getVersionNumber() >= 10000) { this.minVcsBindSize = 4001; this.maxRawBytesSql = 2000; this.maxRawBytesPlsql = 32512; this.maxVcsCharsSql = 32766; this.maxVcsNCharsSql = 32766; this.maxVcsBytesPlsql = 32512; this.maxIbtVarcharElementLength = 32766; this.endToEndMaxLength[0] = 32; this.endToEndMaxLength[1] = 64; this.endToEndMaxLength[2] = 64; this.endToEndMaxLength[3] = 48; } else if (getVersionNumber() >= 9200) { this.minVcsBindSize = 4001; this.maxRawBytesSql = 2000; this.maxRawBytesPlsql = 32512; this.maxVcsCharsSql = 32766; this.maxVcsNCharsSql = 32766; this.maxVcsBytesPlsql = 32512; this.maxIbtVarcharElementLength = 32766; this.endToEndMaxLength[0] = 32; this.endToEndMaxLength[1] = 64; this.endToEndMaxLength[2] = 64; this.endToEndMaxLength[3] = 48; } else { this.minVcsBindSize = 4001; this.maxRawBytesSql = 2000; this.maxRawBytesPlsql = 2000; this.maxVcsCharsSql = 4000; this.maxVcsNCharsSql = 4000; this.maxVcsBytesPlsql = 4000; this.maxIbtVarcharElementLength = 4000; this.endToEndMaxLength[0] = 32; this.endToEndMaxLength[1] = 64; this.endToEndMaxLength[2] = 64; this.endToEndMaxLength[3] = 48; }  if (getVersionNumber() >= 10000) this.retainV9BindBehavior = false;  initializeSetCHARCharSetObjs(); if (this.implicitStatementCacheSize > 0) { setStatementCacheSize(this.implicitStatementCacheSize); setImplicitCachingEnabled(true); }  } catch (SQLException sQLException) { this.lifecycle = 2; try { logoff(); } catch (SQLException sQLException1) {} this.lifecycle = 4; throw sQLException; }  this.txnMode = 0; }
  public boolean isCharSetMultibyte(short paramShort) { return DBConversion.isCharSetMultibyte(paramShort); }
  public int javaCharsToCHARBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException { return this.conversion.javaCharsToCHARBytes(paramArrayOfchar, paramInt, paramArrayOfbyte); }
  public int javaCharsToNCHARBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException { return this.conversion.javaCharsToNCHARBytes(paramArrayOfchar, paramInt, paramArrayOfbyte); }
  final void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection, String paramString) throws SQLException { Hashtable<Object, Object> hashtable = new Hashtable<Object, Object>(); hashtable.put("obj_type_map", this.javaObjectMap); Properties properties = new Properties(); properties.put("user", this.userName); properties.put("password", paramString); properties.put("connection_url", this.url); properties.put("connect_auto_commit", "" + this.autocommit); properties.put("trans_isolation", "" + this.txnLevel); if (getStatementCacheSize() != -1) { properties.put("stmt_cache_size", "" + getStatementCacheSize()); properties.put("implicit_cache_enabled", "" + getImplicitCachingEnabled()); properties.put("explict_cache_enabled", "" + getExplicitCachingEnabled()); }  properties.put("defaultExecuteBatch", "" + this.defaultExecuteBatch); properties.put("defaultRowPrefetch", "" + this.defaultRowPrefetch); properties.put("remarksReporting", "" + this.reportRemarks); properties.put("AccumulateBatchResult", "" + this.accumulateBatchResult); properties.put("oracle.jdbc.J2EE13Compliant", "" + this.j2ee13Compliant); properties.put("processEscapes", "" + this.processEscapes); properties.put("restrictGetTables", "" + this.restrictGettables); properties.put("includeSynonyms", "" + this.includeSynonyms); properties.put("fixedString", "" + this.fixedString); hashtable.put("connection_properties", properties); paramOraclePooledConnection.setProperties(hashtable); } public Properties getDBAccessProperties() throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public Properties getOCIHandles() throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } void logoff() throws SQLException {} int getDefaultStreamChunkSize() { return this.streamChunkSize; } public OracleStatement refCursorCursorToStatement(int paramInt) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public Connection getLogicalConnection(OraclePooledConnection paramOraclePooledConnection, boolean paramBoolean) throws SQLException { if (this.logicalConnectionAttached != null || paramOraclePooledConnection.getPhysicalHandle() != this) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 143); sQLException.fillInStackTrace(); throw sQLException; }  LogicalConnection logicalConnection = new LogicalConnection(paramOraclePooledConnection, this, paramBoolean); this.logicalConnectionAttached = logicalConnection; return (Connection)logicalConnection; } public void getForm(OracleTypeADT paramOracleTypeADT, OracleTypeCLOB paramOracleTypeCLOB, int paramInt) throws SQLException {} public CLOB createClob(byte[] paramArrayOfbyte) throws SQLException { NCLOB nCLOB; CLOB cLOB = new CLOB((OracleConnection)this, paramArrayOfbyte); if (cLOB.isNCLOB()) nCLOB = new NCLOB(cLOB);  return (CLOB)nCLOB; } public CLOB createClobWithUnpickledBytes(byte[] paramArrayOfbyte) throws SQLException { NCLOB nCLOB; CLOB cLOB = new CLOB((OracleConnection)this, paramArrayOfbyte, true); if (cLOB.isNCLOB()) nCLOB = new NCLOB(cLOB);  return (CLOB)nCLOB; } public CLOB createClob(byte[] paramArrayOfbyte, short paramShort) throws SQLException { return new CLOB((OracleConnection)this, paramArrayOfbyte, paramShort); } public BLOB createBlob(byte[] paramArrayOfbyte) throws SQLException { return new BLOB((OracleConnection)this, paramArrayOfbyte); } public BLOB createBlobWithUnpickledBytes(byte[] paramArrayOfbyte) throws SQLException { return new BLOB((OracleConnection)this, paramArrayOfbyte, true); } public BFILE createBfile(byte[] paramArrayOfbyte) throws SQLException { return new BFILE((OracleConnection)this, paramArrayOfbyte); } public ARRAY createARRAY(String paramString, Object paramObject) throws SQLException { ArrayDescriptor arrayDescriptor = ArrayDescriptor.createDescriptor(paramString, (Connection)this); return new ARRAY(arrayDescriptor, (Connection)this, paramObject); } public Array createOracleArray(String paramString, Object paramObject) throws SQLException { return (Array)createARRAY(paramString, paramObject); } public BINARY_DOUBLE createBINARY_DOUBLE(double paramDouble) throws SQLException { return new BINARY_DOUBLE(paramDouble); } public BINARY_FLOAT createBINARY_FLOAT(float paramFloat) throws SQLException { return new BINARY_FLOAT(paramFloat); } public DATE createDATE(Date paramDate) throws SQLException { return new DATE(paramDate); } public DATE createDATE(Time paramTime) throws SQLException { return new DATE(paramTime); } public DATE createDATE(Timestamp paramTimestamp) throws SQLException { return new DATE(paramTimestamp); } public DATE createDATE(Date paramDate, Calendar paramCalendar) throws SQLException { return new DATE(paramDate); } public DATE createDATE(Time paramTime, Calendar paramCalendar) throws SQLException { return new DATE(paramTime); } public DATE createDATE(Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException { return new DATE(paramTimestamp); } public DATE createDATE(String paramString) throws SQLException { return new DATE(paramString); } public INTERVALDS createINTERVALDS(String paramString) throws SQLException { return new INTERVALDS(paramString); } public INTERVALYM createINTERVALYM(String paramString) throws SQLException { return new INTERVALYM(paramString); } public NUMBER createNUMBER(boolean paramBoolean) throws SQLException { return new NUMBER(paramBoolean); } public NUMBER createNUMBER(byte paramByte) throws SQLException { return new NUMBER(paramByte); } public NUMBER createNUMBER(short paramShort) throws SQLException { return new NUMBER(paramShort); } public NUMBER createNUMBER(int paramInt) throws SQLException { return new NUMBER(paramInt); } public NUMBER createNUMBER(long paramLong) throws SQLException { return new NUMBER(paramLong); } public NUMBER createNUMBER(float paramFloat) throws SQLException { return new NUMBER(paramFloat); } public NUMBER createNUMBER(double paramDouble) throws SQLException { return new NUMBER(paramDouble); } public int getTimezoneVersionNumber() throws SQLException { return this.timeZoneVersionNumber; } public NUMBER createNUMBER(BigDecimal paramBigDecimal) throws SQLException { return new NUMBER(paramBigDecimal); } public NUMBER createNUMBER(BigInteger paramBigInteger) throws SQLException { return new NUMBER(paramBigInteger); } public NUMBER createNUMBER(String paramString, int paramInt) throws SQLException { return new NUMBER(paramString, paramInt); } public Array createArrayOf(String paramString, Object[] paramArrayOfObject) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public Struct createStruct(String paramString, Object[] paramArrayOfObject) throws SQLException { try { StructDescriptor structDescriptor = StructDescriptor.createDescriptor(paramString, (Connection)this); return (Struct)new STRUCT(structDescriptor, (Connection)this, paramArrayOfObject); } catch (SQLException sQLException) { if (sQLException.getErrorCode() == 17049) removeAllDescriptor();  throw sQLException; }  } public TIMESTAMP createTIMESTAMP(Date paramDate) throws SQLException { return new TIMESTAMP(paramDate); } public TIMESTAMP createTIMESTAMP(DATE paramDATE) throws SQLException { return new TIMESTAMP(paramDATE); } public TIMESTAMP createTIMESTAMP(Time paramTime) throws SQLException { return new TIMESTAMP(paramTime); } public TIMESTAMP createTIMESTAMP(Timestamp paramTimestamp) throws SQLException { return new TIMESTAMP(paramTimestamp); } public TIMESTAMP createTIMESTAMP(String paramString) throws SQLException { return new TIMESTAMP(paramString); } public TIMESTAMPTZ createTIMESTAMPTZ(Date paramDate) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramDate); } public TIMESTAMPTZ createTIMESTAMPTZ(Date paramDate, Calendar paramCalendar) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramDate, paramCalendar); } public TIMESTAMPTZ createTIMESTAMPTZ(Time paramTime) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramTime); } public TIMESTAMPTZ createTIMESTAMPTZ(Time paramTime, Calendar paramCalendar) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramTime, paramCalendar); } public TIMESTAMPTZ createTIMESTAMPTZ(Timestamp paramTimestamp) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramTimestamp); } public TIMESTAMPTZ createTIMESTAMPTZ(Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramTimestamp, paramCalendar); } public TIMESTAMPTZ createTIMESTAMPTZ(String paramString) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramString); } public TIMESTAMPTZ createTIMESTAMPTZ(String paramString, Calendar paramCalendar) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramString, paramCalendar); } public TIMESTAMPTZ createTIMESTAMPTZ(DATE paramDATE) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramDATE); } public TIMESTAMPLTZ createTIMESTAMPLTZ(Date paramDate, Calendar paramCalendar) throws SQLException { return new TIMESTAMPLTZ((Connection)this, paramCalendar, paramDate); } public TIMESTAMPLTZ createTIMESTAMPLTZ(Time paramTime, Calendar paramCalendar) throws SQLException { return new TIMESTAMPLTZ((Connection)this, paramCalendar, paramTime); } public TIMESTAMPLTZ createTIMESTAMPLTZ(Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException { return new TIMESTAMPLTZ((Connection)this, paramCalendar, paramTimestamp); } public TIMESTAMPLTZ createTIMESTAMPLTZ(String paramString, Calendar paramCalendar) throws SQLException { return new TIMESTAMPLTZ((Connection)this, paramCalendar, paramString); } public TIMESTAMPLTZ createTIMESTAMPLTZ(DATE paramDATE, Calendar paramCalendar) throws SQLException { return new TIMESTAMPLTZ((Connection)this, paramCalendar, paramDATE); } public boolean isDescriptorSharable(OracleConnection paramOracleConnection) throws SQLException { PhysicalConnection physicalConnection1 = this; PhysicalConnection physicalConnection2 = (PhysicalConnection)paramOracleConnection.getPhysicalConnection(); return (physicalConnection1 == physicalConnection2 || physicalConnection1.url.equals(physicalConnection2.url) || (physicalConnection2.protocol != null && physicalConnection2.protocol.equals("kprb"))); } boolean useLittleEndianSetCHARBinder() throws SQLException { return false; } public void setPlsqlWarnings(String paramString) throws SQLException { if (paramString == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  if (paramString != null && (paramString = paramString.trim()).length() > 0 && !OracleSql.isValidPlsqlWarning(paramString)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  String str1 = "ALTER SESSION SET PLSQL_WARNINGS=" + paramString; String str2 = "ALTER SESSION SET EVENTS='10933 TRACE NAME CONTEXT LEVEL 32768'"; Statement statement = null; try { statement = createStatement(-1, -1); statement.execute(str1); if (paramString.equals("'DISABLE:ALL'")) { this.plsqlCompilerWarnings = false; } else { statement.execute(str2); this.plsqlCompilerWarnings = true; }  } finally { if (statement != null) statement.close();  }  } void internalClose() throws SQLException { this.lifecycle = 4; OracleStatement oracleStatement = this.statements; while (oracleStatement != null) { OracleStatement oracleStatement1 = oracleStatement.nextChild; if (oracleStatement.serverCursor) { oracleStatement.internalClose(); removeStatement(oracleStatement); }  oracleStatement = oracleStatement1; }  oracleStatement = this.statements; while (oracleStatement != null) { OracleStatement oracleStatement1 = oracleStatement.next; oracleStatement.internalClose(); oracleStatement = oracleStatement1; }  this.statements = null; }
  public XAResource getXAResource() throws SQLException { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 164); sQLException.fillInStackTrace(); throw sQLException; }
  protected void doDescribeTable(AutoKeyInfo paramAutoKeyInfo) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
  public void setApplicationContext(String paramString1, String paramString2, String paramString3) throws SQLException { if (paramString1 == null || paramString2 == null || paramString3 == null) throw new NullPointerException();  if (paramString1.equals("")) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 170); sQLException.fillInStackTrace(); throw sQLException; }  if (paramString1.compareToIgnoreCase("CLIENTCONTEXT") != 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 174); sQLException.fillInStackTrace(); throw sQLException; }  if (paramString2.length() > 30) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 171); sQLException.fillInStackTrace(); throw sQLException; }  if (paramString3.length() > 4000) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 172); sQLException.fillInStackTrace(); throw sQLException; }  doSetApplicationContext(paramString1, paramString2, paramString3); }
  void doSetApplicationContext(String paramString1, String paramString2, String paramString3) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
  public void clearAllApplicationContext(String paramString) throws SQLException { if (paramString == null) throw new NullPointerException();  if (paramString.equals("")) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 170); sQLException.fillInStackTrace(); throw sQLException; }  doClearAllApplicationContext(paramString); }
  void doClearAllApplicationContext(String paramString) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
  public byte[] createLightweightSession(String paramString, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfint) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
  public void executeLightweightSessionRoundtrip(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfint) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
  public void executeLightweightSessionPiggyback(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
  public TIMEZONETAB getTIMEZONETAB() throws SQLException { if (this.timeZoneTab == null) {
      this.timeZoneTab = TIMEZONETAB.getInstance(getTimezoneVersionNumber());
    }
    return this.timeZoneTab; } public void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace, XSNamespace[][] paramArrayOfXSNamespace1) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void enqueue(String paramString, AQEnqueueOptions paramAQEnqueueOptions, AQMessage paramAQMessage) throws SQLException { AQMessageI aQMessageI = (AQMessageI)paramAQMessage; byte[][] arrayOfByte = new byte[1][]; doEnqueue(paramString, paramAQEnqueueOptions, aQMessageI.getMessagePropertiesI(), aQMessageI.getPayloadTOID(), aQMessageI.getPayload(), arrayOfByte, aQMessageI.isRAWPayload()); if (arrayOfByte[0] != null) aQMessageI.setMessageId(arrayOfByte[0]);  } public AQMessage dequeue(String paramString, AQDequeueOptions paramAQDequeueOptions, byte[] paramArrayOfbyte) throws SQLException { byte[][] arrayOfByte1 = new byte[1][]; AQMessagePropertiesI aQMessagePropertiesI = new AQMessagePropertiesI(); byte[][] arrayOfByte2 = new byte[1][]; boolean bool = false; bool = doDequeue(paramString, paramAQDequeueOptions, aQMessagePropertiesI, paramArrayOfbyte, arrayOfByte2, arrayOfByte1, AQMessageI.compareToid(paramArrayOfbyte, TypeDescriptor.RAWTOID)); AQMessageI aQMessageI = null; if (bool) { aQMessageI = new AQMessageI(aQMessagePropertiesI, (Connection)this); aQMessageI.setPayload(arrayOfByte2[0], paramArrayOfbyte); aQMessageI.setMessageId(arrayOfByte1[0]); }  return aQMessageI; } public AQMessage dequeue(String paramString1, AQDequeueOptions paramAQDequeueOptions, String paramString2) throws SQLException { byte[] arrayOfByte = null; TypeDescriptor typeDescriptor = null; if ("RAW".equals(paramString2) || "SYS.RAW".equals(paramString2)) { arrayOfByte = TypeDescriptor.RAWTOID; } else if ("SYS.ANYDATA".equals(paramString2)) { arrayOfByte = TypeDescriptor.ANYDATATOID; } else if ("SYS.XMLTYPE".equals(paramString2)) { arrayOfByte = TypeDescriptor.XMLTYPETOID; } else { typeDescriptor = TypeDescriptor.getTypeDescriptor(paramString2, (OracleConnection)this); arrayOfByte = ((OracleTypeADT)typeDescriptor.getPickler()).getTOID(); }  AQMessageI aQMessageI = (AQMessageI)dequeue(paramString1, paramAQDequeueOptions, arrayOfByte); if (aQMessageI != null) { aQMessageI.setTypeName(paramString2); aQMessageI.setTypeDescriptor(typeDescriptor); }  return aQMessageI; } synchronized void doEnqueue(String paramString, AQEnqueueOptions paramAQEnqueueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[][] paramArrayOfbyte, boolean paramBoolean) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } synchronized boolean doDequeue(String paramString, AQDequeueOptions paramAQDequeueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, byte[] paramArrayOfbyte, byte[][] paramArrayOfbyte1, byte[][] paramArrayOfbyte2, boolean paramBoolean) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public boolean isV8Compatible() throws SQLException { return this.mapDateToTimestamp; } public boolean getMapDateToTimestamp() { return this.mapDateToTimestamp; } public byte getInstanceProperty(OracleConnection.InstanceProperty paramInstanceProperty) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public AQNotificationRegistration[] registerAQNotification(String[] paramArrayOfString, Properties[] paramArrayOfProperties, Properties paramProperties) throws SQLException { String str = readNTFlocalhost(paramProperties); int i = readNTFtcpport(paramProperties); NTFAQRegistration[] arrayOfNTFAQRegistration = doRegisterAQNotification(paramArrayOfString, str, i, paramArrayOfProperties); return (AQNotificationRegistration[])arrayOfNTFAQRegistration; } NTFAQRegistration[] doRegisterAQNotification(String[] paramArrayOfString, String paramString, int paramInt, Properties[] paramArrayOfProperties) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void unregisterAQNotification(AQNotificationRegistration paramAQNotificationRegistration) throws SQLException { NTFAQRegistration nTFAQRegistration = (NTFAQRegistration)paramAQNotificationRegistration; doUnregisterAQNotification(nTFAQRegistration); } void doUnregisterAQNotification(NTFAQRegistration paramNTFAQRegistration) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } private String readNTFlocalhost(Properties paramProperties) throws SQLException { String str = null; try { str = paramProperties.getProperty("NTF_LOCAL_HOST", InetAddress.getLocalHost().getHostAddress()); } catch (UnknownHostException unknownHostException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 240); sQLException.fillInStackTrace(); throw sQLException; } catch (SecurityException securityException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 241); sQLException.fillInStackTrace(); throw sQLException; }  return str; } private int readNTFtcpport(Properties paramProperties) throws SQLException { int i = 0; try { i = Integer.parseInt(paramProperties.getProperty("NTF_LOCAL_TCP_PORT", "0")); if (i < 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 242); sQLException.fillInStackTrace(); throw sQLException; }  } catch (NumberFormatException numberFormatException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 242); sQLException.fillInStackTrace(); throw sQLException; }  return i; } int readNTFtimeout(Properties paramProperties) throws SQLException { int i = 0; try { i = Integer.parseInt(paramProperties.getProperty("NTF_TIMEOUT", "0")); } catch (NumberFormatException numberFormatException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 243); sQLException.fillInStackTrace(); throw sQLException; }  return i; } public DatabaseChangeRegistration registerDatabaseChangeNotification(Properties paramProperties) throws SQLException { String str = readNTFlocalhost(paramProperties); int i = readNTFtcpport(paramProperties); int j = readNTFtimeout(paramProperties); int k = 0; try { k = Integer.parseInt(paramProperties.getProperty("DCN_NOTIFY_CHANGELAG", "0")); } catch (NumberFormatException numberFormatException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 244); sQLException.fillInStackTrace(); throw sQLException; }  NTFDCNRegistration nTFDCNRegistration = doRegisterDatabaseChangeNotification(str, i, paramProperties, j, k); ntfManager.addRegistration(nTFDCNRegistration); return nTFDCNRegistration; } NTFDCNRegistration doRegisterDatabaseChangeNotification(String paramString, int paramInt1, Properties paramProperties, int paramInt2, int paramInt3) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public DatabaseChangeRegistration getDatabaseChangeRegistration(int paramInt) throws SQLException { return new NTFDCNRegistration(this.instanceName, paramInt, this.userName, this.versionNumber); } public void unregisterDatabaseChangeNotification(DatabaseChangeRegistration paramDatabaseChangeRegistration) throws SQLException { NTFDCNRegistration nTFDCNRegistration = (NTFDCNRegistration)paramDatabaseChangeRegistration; if (nTFDCNRegistration.getDatabaseName().compareToIgnoreCase(this.instanceName) != 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 245); sQLException.fillInStackTrace(); throw sQLException; }  doUnregisterDatabaseChangeNotification(nTFDCNRegistration); } void doUnregisterDatabaseChangeNotification(NTFDCNRegistration paramNTFDCNRegistration) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void unregisterDatabaseChangeNotification(int paramInt) throws SQLException { String str = null; try { str = InetAddress.getLocalHost().getHostAddress(); } catch (Exception exception) {} unregisterDatabaseChangeNotification(paramInt, str, 47632); } public void unregisterDatabaseChangeNotification(int paramInt1, String paramString, int paramInt2) throws SQLException { String str = "(ADDRESS=(PROTOCOL=tcp)(HOST=" + paramString + ")(PORT=" + paramInt2 + "))?PR=0"; unregisterDatabaseChangeNotification(paramInt1, str); } public void unregisterDatabaseChangeNotification(long paramLong, String paramString) throws SQLException { doUnregisterDatabaseChangeNotification(paramLong, paramString); }
  void doUnregisterDatabaseChangeNotification(long paramLong, String paramString) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
  public void addXSEventListener(XSEventListener paramXSEventListener) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
  public void addXSEventListener(XSEventListener paramXSEventListener, Executor paramExecutor) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
  public void removeXSEventListener(XSEventListener paramXSEventListener) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
  public TypeDescriptor[] getAllTypeDescriptorsInCurrentSchema() throws SQLException { TypeDescriptor[] arrayOfTypeDescriptor = null; Statement statement = null; try { statement = createStatement(); ResultSet resultSet = statement.executeQuery("SELECT schema_name, typename, typoid, typecode, version, tds  FROM TABLE(private_jdbc.Get_Type_Shape_Info())"); arrayOfTypeDescriptor = getTypeDescriptorsFromResultSet(resultSet); resultSet.close(); } catch (SQLException sQLException) { if (sQLException.getErrorCode() == 904) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 165); sQLException1.fillInStackTrace(); throw sQLException1; }  throw sQLException; } finally { if (statement != null) statement.close();  }  return arrayOfTypeDescriptor; }
  public TypeDescriptor[] getTypeDescriptorsFromListInCurrentSchema(String[] paramArrayOfString) throws SQLException { String str = "SELECT schema_name, typename, typoid, typecode, version, tds  FROM TABLE(private_jdbc.Get_Type_Shape_Info(?))"; TypeDescriptor[] arrayOfTypeDescriptor = null; PreparedStatement preparedStatement = null; try { preparedStatement = prepareStatement(str); int i = paramArrayOfString.length; StringBuffer stringBuffer = new StringBuffer(i * 8); for (byte b = 0; b < i; b++) { stringBuffer.append(paramArrayOfString[b]); if (b < i - 1) stringBuffer.append(',');  }  preparedStatement.setString(1, stringBuffer.toString()); ResultSet resultSet = preparedStatement.executeQuery(); arrayOfTypeDescriptor = getTypeDescriptorsFromResultSet(resultSet); resultSet.close(); } catch (SQLException sQLException) { if (sQLException.getErrorCode() == 904) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 165); sQLException1.fillInStackTrace(); throw sQLException1; }  throw sQLException; } finally { if (preparedStatement != null) preparedStatement.close();  }  return arrayOfTypeDescriptor; }
  public TypeDescriptor[] getTypeDescriptorsFromList(String[][] paramArrayOfString) throws SQLException { TypeDescriptor[] arrayOfTypeDescriptor = null; PreparedStatement preparedStatement = null; int i = paramArrayOfString.length; StringBuffer stringBuffer1 = new StringBuffer(i * 8); StringBuffer stringBuffer2 = new StringBuffer(i * 8); for (byte b = 0; b < i; b++) { stringBuffer1.append(paramArrayOfString[b][0]); stringBuffer2.append(paramArrayOfString[b][1]); if (b < i - 1) { stringBuffer1.append(','); stringBuffer2.append(','); }  }  try { String str = "SELECT schema_name, typename, typoid, typecode, version, tds FROM TABLE(private_jdbc.Get_All_Type_Shape_Info(?,?))"; preparedStatement = prepareStatement(str); preparedStatement.setString(1, stringBuffer1.toString()); preparedStatement.setString(2, stringBuffer2.toString()); ResultSet resultSet = preparedStatement.executeQuery(); arrayOfTypeDescriptor = getTypeDescriptorsFromResultSet(resultSet); resultSet.close(); } catch (SQLException sQLException) { if (sQLException.getErrorCode() == 904) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 165); sQLException1.fillInStackTrace(); throw sQLException1; }  throw sQLException; } finally { if (preparedStatement != null) preparedStatement.close();  }  return arrayOfTypeDescriptor; }
  TypeDescriptor[] getTypeDescriptorsFromResultSet(ResultSet paramResultSet) throws SQLException { ArrayList<StructDescriptor> arrayList = new ArrayList(); while (paramResultSet.next()) { String str1 = paramResultSet.getString(1); String str2 = paramResultSet.getString(2); byte[] arrayOfByte1 = paramResultSet.getBytes(3); String str3 = paramResultSet.getString(4); int i = paramResultSet.getInt(5); byte[] arrayOfByte2 = paramResultSet.getBytes(6); SQLName sQLName = new SQLName(str1, str2, (OracleConnection)this); if (str3.equals("OBJECT")) { StructDescriptor structDescriptor = StructDescriptor.createDescriptor(sQLName, arrayOfByte1, i, arrayOfByte2, this); putDescriptor(arrayOfByte1, structDescriptor); putDescriptor(structDescriptor.getName(), structDescriptor); arrayList.add(structDescriptor); continue; }  if (str3.equals("COLLECTION")) { ArrayDescriptor arrayDescriptor = ArrayDescriptor.createDescriptor(sQLName, arrayOfByte1, i, arrayOfByte2, this); putDescriptor(arrayOfByte1, arrayDescriptor); putDescriptor(arrayDescriptor.getName(), arrayDescriptor); arrayList.add(arrayDescriptor); }  }  TypeDescriptor[] arrayOfTypeDescriptor = new TypeDescriptor[arrayList.size()]; for (byte b = 0; b < arrayList.size(); b++) { TypeDescriptor typeDescriptor = (TypeDescriptor)arrayList.get(b); arrayOfTypeDescriptor[b] = typeDescriptor; }  return arrayOfTypeDescriptor; }
  public synchronized boolean isUsable() { return this.isUsable; }
  public void setUsable(boolean paramBoolean) { this.isUsable = paramBoolean; }
  void queryFCFProperties(Properties paramProperties) throws SQLException { Statement statement = null; ResultSet resultSet = null; String str = "select sys_context('userenv', 'instance_name'),sys_context('userenv', 'server_host'),sys_context('userenv', 'service_name'),sys_context('userenv', 'db_unique_name') from dual"; try { statement = createStatement(); statement.setFetchSize(1); resultSet = statement.executeQuery(str); while (resultSet.next()) { String str1 = null; str1 = resultSet.getString(1); if (str1 != null) paramProperties.put("INSTANCE_NAME", str1.trim());  str1 = resultSet.getString(2); if (str1 != null) paramProperties.put("SERVER_HOST", str1.trim());  str1 = resultSet.getString(3); if (str1 != null) paramProperties.put("SERVICE_NAME", str1.trim());  str1 = resultSet.getString(4); if (str1 != null) paramProperties.put("DATABASE_NAME", str1.trim());  }  } finally { if (resultSet != null) resultSet.close();  if (statement != null) statement.close();  }  }
  public void setDefaultTimeZone(TimeZone paramTimeZone) throws SQLException { this.defaultTimeZone = paramTimeZone; }
  public TimeZone getDefaultTimeZone() throws SQLException { return this.defaultTimeZone; }
  public boolean isDataInLocatorEnabled() throws SQLException { return ((getVersionNumber() >= 10200)) & ((getVersionNumber() < 11000)) & this.enableReadDataInLocator | this.overrideEnableReadDataInLocator; }






  
  public boolean isLobStreamPosStandardCompliant() throws SQLException {
    return this.lobStreamPosStandardCompliant;
  }



  
  public long getCurrentSCN() throws SQLException {
    return doGetCurrentSCN();
  }


  
  long doGetCurrentSCN() throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }



  
  void doSetSnapshotSCN(long paramLong) throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }


  
  public EnumSet<OracleConnection.TransactionState> getTransactionState() throws SQLException {
    return doGetTransactionState();
  }


  
  EnumSet<OracleConnection.TransactionState> doGetTransactionState() throws SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }



  
  public boolean isConnectionSocketKeepAlive() throws SocketException, SQLException {
    SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
    sQLException.fillInStackTrace();
    throw sQLException;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
  
  abstract void initializePassword(String paramString) throws SQLException;
  
  abstract void doAbort() throws SQLException;
  
  public abstract void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection) throws SQLException;
  
  abstract void logon() throws SQLException;
  
  abstract void open(OracleStatement paramOracleStatement) throws SQLException;
  
  abstract void cancelOperationOnServer(boolean paramBoolean) throws SQLException;
  
  abstract void doSetAutoCommit(boolean paramBoolean) throws SQLException;
  
  abstract void doCommit(int paramInt) throws SQLException;
  
  abstract void doRollback() throws SQLException;
  
  abstract String doGetDatabaseProductVersion() throws SQLException;
  
  abstract short doGetVersionNumber() throws SQLException;
  
  abstract OracleStatement RefCursorBytesToStatement(byte[] paramArrayOfbyte, OracleStatement paramOracleStatement) throws SQLException;
  
  public abstract BLOB createTemporaryBlob(Connection paramConnection, boolean paramBoolean, int paramInt) throws SQLException;
  
  public abstract CLOB createTemporaryClob(Connection paramConnection, boolean paramBoolean, int paramInt, short paramShort) throws SQLException;
}
