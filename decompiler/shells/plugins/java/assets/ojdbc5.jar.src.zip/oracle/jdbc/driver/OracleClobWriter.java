package oracle.jdbc.driver;

import java.io.IOException;
import java.io.Writer;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.CLOB;





















class OracleClobWriter
  extends Writer
{
  DBConversion dbConversion;
  CLOB clob;
  long lobOffset;
  char[] charBuf;
  byte[] nativeBuf;
  int pos;
  int count;
  int chunkSize;
  boolean isClosed;
  
  public OracleClobWriter(CLOB paramCLOB, int paramInt) throws SQLException {
    this(paramCLOB, paramInt, 1L);
  }













  
  public OracleClobWriter(CLOB paramCLOB, int paramInt, long paramLong) throws SQLException {
    if (paramCLOB == null || paramInt <= 0 || paramCLOB.getJavaSqlConnection() == null || paramLong < 1L)
    {
      
      throw new IllegalArgumentException();
    }
    
    this.dbConversion = ((PhysicalConnection)paramCLOB.getInternalConnection()).conversion;

    
    this.clob = paramCLOB;
    this.lobOffset = paramLong;
    
    this.charBuf = new char[paramInt];
    this.nativeBuf = new byte[paramInt * 3];
    this.pos = this.count = 0;
    this.chunkSize = paramInt;
    
    this.isClosed = false;
  }













  
  public void write(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws IOException {
    synchronized (this.lock) {
      
      ensureOpen();
      
      int i = paramInt1;
      int j = Math.min(paramInt2, paramArrayOfchar.length - paramInt1);
      
      if (j >= 2 * this.chunkSize) {





        
        if (this.count > 0) flushBuffer();
        
        try {
          this.lobOffset += this.clob.putChars(this.lobOffset, paramArrayOfchar, paramInt1, j);
        }
        catch (SQLException sQLException) {

          
          IOException iOException = DatabaseError.createIOException(sQLException);
          iOException.fillInStackTrace();
          throw iOException;
        } 
        
        return;
      } 
      
      int k = i + j;
      
      while (i < k) {
        
        int m = Math.min(this.chunkSize - this.count, k - i);
        
        System.arraycopy(paramArrayOfchar, i, this.charBuf, this.count, m);
        
        i += m;
        this.count += m;
        
        if (this.count >= this.chunkSize) {
          flushBuffer();
        }
      } 
    } 
  }












  
  public void flush() throws IOException {
    synchronized (this.lock) {
      
      ensureOpen();
      flushBuffer();
    } 
  }











  
  public void close() throws IOException {
    synchronized (this.lock) {
      
      flushBuffer();
      
      this.isClosed = true;
    } 
  }







  
  private void flushBuffer() throws IOException {
    synchronized (this.lock) {

      
      try {
        if (this.count > 0)
        {
          this.lobOffset += this.clob.putChars(this.lobOffset, this.charBuf, 0, this.count);
          this.count = 0;
        }
      
      } catch (SQLException sQLException) {

        
        IOException iOException = DatabaseError.createIOException(sQLException);
        iOException.fillInStackTrace();
        throw iOException;
      } 
    } 
  }











  
  void ensureOpen() throws IOException {
    try {
      if (this.isClosed)
      {
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 57, (Object)null);
        sQLException.fillInStackTrace();
        throw sQLException;
      }
    
    } catch (SQLException sQLException) {

      
      IOException iOException = DatabaseError.createIOException(sQLException);
      iOException.fillInStackTrace();
      throw iOException;
    } 
  }














  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    try {
      return this.clob.getInternalConnection();
    }
    catch (Exception exception) {
      
      return null;
    } 
  }



  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
