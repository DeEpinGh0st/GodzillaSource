package oracle.jdbc.driver;

import oracle.jdbc.Const;


















public class Const
  extends Const
{
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
