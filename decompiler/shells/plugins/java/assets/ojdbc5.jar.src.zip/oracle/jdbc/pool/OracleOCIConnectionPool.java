package oracle.jdbc.pool;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Properties;
import javax.naming.NamingException;
import javax.naming.Reference;
import javax.naming.StringRefAddr;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.driver.OracleDriver;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.oci.OracleOCIConnection;

























public class OracleOCIConnectionPool
  extends OracleDataSource
{
  public OracleOCIConnection m_connection_pool;
  public static final String IS_CONNECTION_POOLING = "is_connection_pooling";
  private int m_conn_min_limit = 0;
  private int m_conn_max_limit = 0;
  private int m_conn_increment = 0;
  private int m_conn_active_size = 0;
  private int m_conn_pool_size = 0;
  private int m_conn_timeout = 0;
  private String m_conn_nowait = "false";
  private int m_is_transactions_distributed = 0;
  
  public static final String CONNPOOL_OBJECT = "connpool_object";
  
  public static final String CONNPOOL_LOGON_MODE = "connection_pool";
  
  public static final String CONNECTION_POOL = "connection_pool";
  
  public static final String CONNPOOL_CONNECTION = "connpool_connection";
  
  public static final String CONNPOOL_PROXY_CONNECTION = "connpool_proxy_connection";
  
  public static final String CONNPOOL_ALIASED_CONNECTION = "connpool_alias_connection";
  
  public static final String PROXY_USER_NAME = "proxy_user_name";
  
  public static final String PROXY_DISTINGUISHED_NAME = "proxy_distinguished_name";
  
  public static final String PROXY_CERTIFICATE = "proxy_certificate";
  
  public static final String PROXY_ROLES = "proxy_roles";
  
  public static final String PROXY_NUM_ROLES = "proxy_num_roles";
  
  public static final String PROXY_PASSWORD = "proxy_password";
  
  public static final String PROXYTYPE = "proxytype";
  
  public static final String PROXYTYPE_USER_NAME = "proxytype_user_name";
  
  public static final String PROXYTYPE_DISTINGUISHED_NAME = "proxytype_distinguished_name";
  
  public static final String PROXYTYPE_CERTIFICATE = "proxytype_certificate";
  
  public static final String CONNECTION_ID = "connection_id";
  
  public static final String CONNPOOL_MIN_LIMIT = "connpool_min_limit";
  
  public static final String CONNPOOL_MAX_LIMIT = "connpool_max_limit";
  
  public static final String CONNPOOL_INCREMENT = "connpool_increment";
  
  public static final String CONNPOOL_ACTIVE_SIZE = "connpool_active_size";
  public static final String CONNPOOL_POOL_SIZE = "connpool_pool_size";
  public static final String CONNPOOL_TIMEOUT = "connpool_timeout";
  public static final String CONNPOOL_NOWAIT = "connpool_nowait";
  public static final String CONNPOOL_IS_POOLCREATED = "connpool_is_poolcreated";
  public static final String TRANSACTIONS_DISTRIBUTED = "transactions_distributed";
  private Hashtable m_lconnections = null;
  
  private enum Lifecycle { NEW, OPEN, CLOSING, CLOSED; }
  private Lifecycle lifecycle = Lifecycle.NEW;







  
  private void ensureOpen() throws SQLException {
    if (this.lifecycle == Lifecycle.NEW) {
      createConnectionPool((Properties)null);
    }
    if (this.lifecycle != Lifecycle.OPEN) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }




  
  private OracleDriver m_oracleDriver = new OracleDriver();

  
  protected int m_stmtCacheSize = 0;






  
  protected boolean m_stmtClearMetaData = false;






  
  public OracleOCIConnectionPool(String paramString1, String paramString2, String paramString3, Properties paramProperties) throws SQLException {
    this();
    
    setURL(paramString3);
    setUser(paramString1);
    setPassword(paramString2);
    createConnectionPool(paramProperties);
  }







  
  public OracleOCIConnectionPool(String paramString1, String paramString2, String paramString3) throws SQLException {
    this();
    
    setURL(paramString3);
    setUser(paramString1);
    setPassword(paramString2);
    createConnectionPool((Properties)null);
  }














  
  public OracleOCIConnectionPool() throws SQLException {
    this.isOracleDataSource = false;
    this.m_lconnections = new Hashtable<Object, Object>(10);
    
    setDriverType("oci8");
  }
















  
  public synchronized Connection getConnection() throws SQLException {
    ensureOpen();


    
    return getConnection(this.user, this.password);
  }











  
  public synchronized Connection getConnection(String paramString1, String paramString2) throws SQLException {
    Properties properties;
    ensureOpen();

    
    if (this.connectionProperties != null) {
      properties = new Properties(this.connectionProperties);
    } else {
      properties = new Properties();
    } 
    properties.put("is_connection_pooling", "true");
    properties.put("user", paramString1);
    properties.put("password", paramString2);
    properties.put("connection_pool", "connpool_connection");
    properties.put("connpool_object", this.m_connection_pool);
    
    OracleOCIConnection oracleOCIConnection = (OracleOCIConnection)this.m_oracleDriver.connect(this.url, properties);
    
    if (oracleOCIConnection == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    oracleOCIConnection.setStmtCacheSize(this.m_stmtCacheSize, this.m_stmtClearMetaData);
    
    this.m_lconnections.put(oracleOCIConnection, oracleOCIConnection);
    
    oracleOCIConnection.setConnectionPool(this);
    
    return (Connection)oracleOCIConnection;
  }









  
  public synchronized Reference getReference() throws NamingException {
    Reference reference = new Reference(getClass().getName(), "oracle.jdbc.pool.OracleDataSourceFactory", null);

    
    addRefProperties(reference);


    
    reference.add(new StringRefAddr("connpool_min_limit", String.valueOf(this.m_conn_min_limit)));

    
    reference.add(new StringRefAddr("connpool_max_limit", String.valueOf(this.m_conn_max_limit)));
    
    reference.add(new StringRefAddr("connpool_increment", String.valueOf(this.m_conn_increment)));

    
    reference.add(new StringRefAddr("connpool_active_size", String.valueOf(this.m_conn_active_size)));

    
    reference.add(new StringRefAddr("connpool_pool_size", String.valueOf(this.m_conn_pool_size)));

    
    reference.add(new StringRefAddr("connpool_timeout", String.valueOf(this.m_conn_timeout)));

    
    reference.add(new StringRefAddr("connpool_nowait", this.m_conn_nowait));
    
    reference.add(new StringRefAddr("connpool_is_poolcreated", String.valueOf(isPoolCreated())));

    
    reference.add(new StringRefAddr("transactions_distributed", String.valueOf(isDistributedTransEnabled())));

    
    return reference;
  }


























  
  public synchronized OracleConnection getProxyConnection(String paramString, Properties paramProperties) throws SQLException {
    ensureOpen();


    
    if ("proxytype_user_name".equals(paramString)) {
      paramProperties.put("user", paramProperties.getProperty("proxy_user_name"));
    } else if ("proxytype_distinguished_name".equals(paramString)) {
      paramProperties.put("user", paramProperties.getProperty("proxy_distinguished_name"));
    }
    else if ("proxytype_certificate".equals(paramString)) {
      paramProperties.put("user", String.valueOf(paramProperties.getProperty("proxy_user_name")));
    }
    else {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 107, "null properties");
      
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    paramProperties.put("is_connection_pooling", "true");
    paramProperties.put("proxytype", paramString);
    String[] arrayOfString;
    if ((arrayOfString = (String[])paramProperties.get("proxy_roles")) != null) {
      
      paramProperties.put("proxy_num_roles", new Integer(arrayOfString.length));
    }
    else {
      
      paramProperties.put("proxy_num_roles", new Integer(0));
    } 
    
    paramProperties.put("connection_pool", "connpool_proxy_connection");
    paramProperties.put("connpool_object", this.m_connection_pool);
    
    OracleOCIConnection oracleOCIConnection = (OracleOCIConnection)this.m_oracleDriver.connect(this.url, paramProperties);

    
    if (oracleOCIConnection == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    oracleOCIConnection.setStmtCacheSize(this.m_stmtCacheSize, this.m_stmtClearMetaData);
    
    this.m_lconnections.put(oracleOCIConnection, oracleOCIConnection);
    oracleOCIConnection.setConnectionPool(this);
    
    return (OracleConnection)oracleOCIConnection;
  }















  
  public synchronized OracleConnection getAliasedConnection(byte[] paramArrayOfbyte) throws SQLException {
    ensureOpen();
    Properties properties = new Properties();
    
    properties.put("is_connection_pooling", "true");
    properties.put("connection_id", paramArrayOfbyte);
    properties.put("connection_pool", "connpool_alias_connection");
    properties.put("connpool_object", this.m_connection_pool);
    
    OracleOCIConnection oracleOCIConnection = (OracleOCIConnection)this.m_oracleDriver.connect(this.url, properties);
    
    if (oracleOCIConnection == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    oracleOCIConnection.setStmtCacheSize(this.m_stmtCacheSize, this.m_stmtClearMetaData);
    
    this.m_lconnections.put(oracleOCIConnection, oracleOCIConnection);
    oracleOCIConnection.setConnectionPool(this);
    
    return (OracleConnection)oracleOCIConnection;
  }












  
  public synchronized void close() throws SQLException {
    if (this.lifecycle != Lifecycle.OPEN) {
      return;
    }
    this.lifecycle = Lifecycle.CLOSING;

    
    Iterator<OracleOCIConnection> iterator = this.m_lconnections.values().iterator();
    
    while (iterator.hasNext()) {
      
      OracleOCIConnection oracleOCIConnection = iterator.next();
      
      if (oracleOCIConnection != null && oracleOCIConnection != this.m_connection_pool)
      {
        oracleOCIConnection.close();
      }
      iterator.remove();
    } 

    
    this.m_connection_pool.close();
    
    this.lifecycle = Lifecycle.CLOSED;
  }
















  
  public synchronized void setPoolConfig(Properties paramProperties) throws SQLException {
    if (paramProperties == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 106, "null properties");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (!isPoolCreated()) {
      
      createConnectionPool(paramProperties);
    }
    else {
      
      Properties properties = new Properties();
      
      checkPoolConfig(paramProperties, properties);
      
      int[] arrayOfInt = new int[6];
      
      readPoolConfig(properties, arrayOfInt);

      
      this.m_connection_pool.setConnectionPoolInfo(arrayOfInt[0], arrayOfInt[1], arrayOfInt[2], arrayOfInt[3], arrayOfInt[4], arrayOfInt[5]);
    } 



    
    storePoolProperties();
  }

















  
  public static void readPoolConfig(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean1, boolean paramBoolean2, int[] paramArrayOfint) {
    for (byte b = 0; b < 6; b++)
      paramArrayOfint[b] = 0; 
    paramArrayOfint[0] = paramInt1;
    paramArrayOfint[1] = paramInt2;
    paramArrayOfint[2] = paramInt3;
    paramArrayOfint[3] = paramInt4;
    if (paramBoolean1)
      paramArrayOfint[4] = 1; 
    if (paramBoolean2) {
      paramArrayOfint[5] = 1;
    }
  }






  
  public static void readPoolConfig(Properties paramProperties, int[] paramArrayOfint) {
    String str = paramProperties.getProperty("connpool_min_limit");
    
    if (str != null) {
      paramArrayOfint[0] = Integer.parseInt(str);
    }
    str = paramProperties.getProperty("connpool_max_limit");
    
    if (str != null) {
      paramArrayOfint[1] = Integer.parseInt(str);
    }
    str = paramProperties.getProperty("connpool_increment");
    
    if (str != null) {
      paramArrayOfint[2] = Integer.parseInt(str);
    }
    str = paramProperties.getProperty("connpool_timeout");
    
    if (str != null) {
      paramArrayOfint[3] = Integer.parseInt(str);
    }
    str = paramProperties.getProperty("connpool_nowait");
    
    if (str != null && str.equalsIgnoreCase("true")) {
      paramArrayOfint[4] = 1;
    }
    str = paramProperties.getProperty("transactions_distributed");
    
    if (str != null && str.equalsIgnoreCase("true")) {
      paramArrayOfint[5] = 1;
    }
  }




  
  private void checkPoolConfig(Properties paramProperties1, Properties paramProperties2) throws SQLException {
    String str1 = (String)paramProperties1.get("transactions_distributed");
    String str2 = (String)paramProperties1.get("connpool_nowait");
    
    if ((str1 != null && !str1.equalsIgnoreCase("true")) || (str2 != null && !str2.equalsIgnoreCase("true")) || paramProperties1.get("connpool_min_limit") == null || paramProperties1.get("connpool_max_limit") == null || paramProperties1.get("connpool_increment") == null || Integer.decode((String)paramProperties1.get("connpool_min_limit")).intValue() < 0 || Integer.decode((String)paramProperties1.get("connpool_max_limit")).intValue() < 0 || Integer.decode((String)paramProperties1.get("connpool_increment")).intValue() < 0) {




















      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 106, "");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    Enumeration<?> enumeration = paramProperties1.propertyNames();


    
    while (enumeration.hasMoreElements()) {
      
      String str3 = (String)enumeration.nextElement();
      String str4 = paramProperties1.getProperty(str3);



      
      if ("transactions_distributed".equals(str3) || "connpool_nowait".equals(str3)) {
        paramProperties2.put(str3, "true"); continue;
      } 
      paramProperties2.put(str3, str4);
    } 
  }




  
  private synchronized void storePoolProperties() throws SQLException {
    Properties properties = getPoolConfig();
    
    this.m_conn_min_limit = Integer.decode(properties.getProperty("connpool_min_limit")).intValue();
    
    this.m_conn_max_limit = Integer.decode(properties.getProperty("connpool_max_limit")).intValue();
    
    this.m_conn_increment = Integer.decode(properties.getProperty("connpool_increment")).intValue();
    
    this.m_conn_active_size = Integer.decode(properties.getProperty("connpool_active_size")).intValue();
    
    this.m_conn_pool_size = Integer.decode(properties.getProperty("connpool_pool_size")).intValue();
    
    this.m_conn_timeout = Integer.decode(properties.getProperty("connpool_timeout")).intValue();
    
    this.m_conn_nowait = properties.getProperty("connpool_nowait");
  }





  
  public synchronized Properties getPoolConfig() throws SQLException {
    ensureOpen();


    
    Properties properties = this.m_connection_pool.getConnectionPoolInfo();
    
    properties.put("connpool_is_poolcreated", String.valueOf(isPoolCreated()));
    
    return properties;
  }












  
  public synchronized int getActiveSize() throws SQLException {
    ensureOpen();
    
    Properties properties = this.m_connection_pool.getConnectionPoolInfo();
    
    String str = properties.getProperty("connpool_active_size");
    return Integer.decode(str).intValue();
  }














  
  public synchronized int getPoolSize() throws SQLException {
    ensureOpen();
    
    Properties properties = this.m_connection_pool.getConnectionPoolInfo();
    
    String str = properties.getProperty("connpool_pool_size");
    return Integer.decode(str).intValue();
  }















  
  public synchronized int getTimeout() throws SQLException {
    ensureOpen();
    
    Properties properties = this.m_connection_pool.getConnectionPoolInfo();
    
    String str = properties.getProperty("connpool_timeout");
    return Integer.decode(str).intValue();
  }


















  
  public synchronized String getNoWait() throws SQLException {
    ensureOpen();
    
    Properties properties = this.m_connection_pool.getConnectionPoolInfo();
    
    return properties.getProperty("connpool_nowait");
  }











  
  public synchronized int getMinLimit() throws SQLException {
    ensureOpen();
    
    Properties properties = this.m_connection_pool.getConnectionPoolInfo();
    
    String str = properties.getProperty("connpool_min_limit");
    return Integer.decode(str).intValue();
  }











  
  public synchronized int getMaxLimit() throws SQLException {
    ensureOpen();
    
    Properties properties = this.m_connection_pool.getConnectionPoolInfo();
    
    String str = properties.getProperty("connpool_max_limit");
    return Integer.decode(str).intValue();
  }











  
  public synchronized int getConnectionIncrement() throws SQLException {
    ensureOpen();
    
    Properties properties = this.m_connection_pool.getConnectionPoolInfo();
    
    String str = properties.getProperty("connpool_increment");
    return Integer.decode(str).intValue();
  }







  
  public synchronized boolean isDistributedTransEnabled() {
    if (this.m_is_transactions_distributed == 1) {
      return true;
    }
    return false;
  }








  
  private void createConnectionPool(Properties paramProperties) throws SQLException {
    if (this.lifecycle != Lifecycle.NEW) {
      return;
    }
    if (this.user == null || this.password == null) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 106, " ");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    Properties properties = new Properties();

    
    if (paramProperties != null) {
      checkPoolConfig(paramProperties, properties);
    }
    properties.put("is_connection_pooling", "true");
    properties.put("user", this.user);
    properties.put("password", this.password);
    properties.put("connection_pool", "connection_pool");
    
    if (getURL() == null) {
      makeURL();
    }



    
    this.m_connection_pool = (OracleOCIConnection)this.m_oracleDriver.connect(this.url, properties);
    
    if (this.m_connection_pool == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 




    
    this.m_connection_pool.setConnectionPool(this);

    
    this.m_lconnections.put(this.m_connection_pool, this.m_connection_pool);
    
    this.lifecycle = Lifecycle.OPEN;




    
    storePoolProperties();
    
    if (paramProperties != null)
    {
      if ("true".equalsIgnoreCase(paramProperties.getProperty("transactions_distributed"))) {
        this.m_is_transactions_distributed = 1;
      }
    }
  }









  
  public synchronized boolean isPoolCreated() {
    return (this.lifecycle == Lifecycle.OPEN);
  }





  
  public synchronized void connectionClosed(OracleOCIConnection paramOracleOCIConnection) throws SQLException {
    if (this.lifecycle != Lifecycle.CLOSING)
    {
      if (this.m_lconnections.remove(paramOracleOCIConnection) == null) {
        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "internal OracleOCIConnectionPool error");
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    }
  }


















  
  public synchronized void setStmtCacheSize(int paramInt) throws SQLException {
    setStmtCacheSize(paramInt, false);
  }





















  
  public synchronized void setStmtCacheSize(int paramInt, boolean paramBoolean) throws SQLException {
    if (paramInt < 0) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.m_stmtCacheSize = paramInt;
    this.m_stmtClearMetaData = paramBoolean;
  }









  
  public synchronized int getStmtCacheSize() {
    return this.m_stmtCacheSize;
  }








  
  public synchronized boolean isStmtCacheEnabled() {
    if (this.m_stmtCacheSize > 0) {
      return true;
    }
    return false;
  }












  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
