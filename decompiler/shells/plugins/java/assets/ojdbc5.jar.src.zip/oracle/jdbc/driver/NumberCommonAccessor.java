package oracle.jdbc.driver;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.SQLException;
import java.util.Map;
import oracle.sql.Datum;
import oracle.sql.NUMBER;












class NumberCommonAccessor
  extends Accessor
{
  static final boolean GET_XXX_ROUNDS = false;
  
  void init(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean) throws SQLException {
    init(paramOracleStatement, 6, 6, paramShort, paramBoolean);
    initForDataAccess(paramInt2, paramInt1, (String)null);
  }





  
  void init(OracleStatement paramOracleStatement, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, short paramShort) throws SQLException {
    init(paramOracleStatement, 6, 6, paramShort, false);
    initForDescribe(paramInt1, paramInt2, paramBoolean, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramShort, null);
    
    initForDataAccess(0, paramInt2, (String)null);
  }




  
  void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
    if (paramInt1 != 0) {
      this.externalType = paramInt1;
    }
    this.internalTypeMaxLength = 21;
    
    if (paramInt2 > 0 && paramInt2 < this.internalTypeMaxLength) {
      this.internalTypeMaxLength = paramInt2;
    }
    this.byteLength = this.internalTypeMaxLength + 1;
  }














  
  int getInt(int paramInt) throws SQLException {
    int i = 0;
    
    if (this.rowSpaceIndicator == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      byte[] arrayOfByte = this.rowSpaceByte;
      int j = this.columnIndex + this.byteLength * paramInt + 1;
      byte b1 = arrayOfByte[j - 1];
      byte b2 = arrayOfByte[j];
      
      int k = 0;


      
      if ((b2 & Byte.MIN_VALUE) != 0) {



        
        byte b3 = (byte)((b2 & 0xFFFFFF7F) - 65);
        byte b4 = (byte)(b1 - 1);
        
        int m = (b4 > b3 + 1) ? (b3 + 2) : (b4 + 1);
        int n = m + j;
        
        if (b3 >= 4)
        {
          if (b3 > 4)
          {
            
            throwOverflow();
          }
          long l = 0L;
          
          if (m > 1) {
            
            l = (arrayOfByte[j + 1] - 1);
            
            for (int i2 = 2 + j; i2 < n; i2++) {
              l = l * 100L + (arrayOfByte[i2] - 1);
            }
          } 



          
          for (int i1 = b3 - b4; i1 >= 0; i1--) {
            l *= 100L;
          }
          if (l > 2147483647L) {
            throwOverflow();
          }
          k = (int)l;
        }
        else
        {
          if (m > 1) {
            
            k = arrayOfByte[j + 1] - 1;
            
            for (int i2 = 2 + j; i2 < n; i2++) {
              k = k * 100 + arrayOfByte[i2] - 1;
            }
          } 



          
          for (int i1 = b3 - b4; i1 >= 0; i1--) {
            k *= 100;
          
          }
        }
      
      }
      else {
        
        byte b3 = (byte)(((b2 ^ 0xFFFFFFFF) & 0xFFFFFF7F) - 65);
        byte b4 = (byte)(b1 - 1);
        
        if (b4 != 20 || arrayOfByte[j + b4] == 102) {
          b4 = (byte)(b4 - 1);
        }
        int m = (b4 > b3 + 1) ? (b3 + 2) : (b4 + 1);
        int n = m + j;








        
        if (b3 >= 4) {
          
          if (b3 > 4)
          {











            
            throwOverflow();
          }
          
          long l = 0L;
          
          if (m > 1) {
            
            l = (101 - arrayOfByte[j + 1]);
            
            for (int i2 = 2 + j; i2 < n; i2++) {
              l = l * 100L + (101 - arrayOfByte[i2]);
            }
          } 



          
          for (int i1 = b3 - b4; i1 >= 0; i1--) {
            l *= 100L;
          }
          l = -l;
          
          if (l < -2147483648L) {
            throwOverflow();
          }
          k = (int)l;
        }
        else {
          
          if (m > 1) {
            
            k = 101 - arrayOfByte[j + 1];
            
            for (int i2 = 2 + j; i2 < n; i2++) {
              k = k * 100 + 101 - arrayOfByte[i2];
            }
          } 



          
          for (int i1 = b3 - b4; i1 >= 0; i1--) {
            k *= 100;
          }
          k = -k;
        } 
      } 
      
      i = k;
    } 
    
    return i;
  }












  
  boolean getBoolean(int paramInt) throws SQLException {
    boolean bool = false;
    
    if (this.rowSpaceIndicator == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      byte[] arrayOfByte = this.rowSpaceByte;
      int i = this.columnIndex + this.byteLength * paramInt + 1;
      byte b = arrayOfByte[i - 1];
      
      bool = (b != 1 || arrayOfByte[i] != Byte.MIN_VALUE) ? true : false;
    } 
    
    return bool;
  }












  
  short getShort(int paramInt) throws SQLException {
    short s = 0;
    
    if (this.rowSpaceIndicator == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {

      
      byte[] arrayOfByte = this.rowSpaceByte;
      int i = this.columnIndex + this.byteLength * paramInt + 1;
      byte b1 = arrayOfByte[i - 1];
      
      byte b2 = arrayOfByte[i];
      
      int j = 0;


      
      if ((b2 & Byte.MIN_VALUE) != 0) {



        
        byte b3 = (byte)((b2 & 0xFFFFFF7F) - 65);
        
        if (b3 > 2)
        {
          
          throwOverflow();
        }
        byte b4 = (byte)(b1 - 1);
        
        int k = (b4 > b3 + 1) ? (b3 + 2) : (b4 + 1);
        int m = k + i;
        
        if (k > 1) {
          
          j = arrayOfByte[i + 1] - 1;
          
          for (int i1 = 2 + i; i1 < m; i1++) {
            j = j * 100 + arrayOfByte[i1] - 1;
          }
        } 



        
        for (int n = b3 - b4; n >= 0; n--) {
          j *= 100;
        }
        if (b3 == 2 && 
          j > 32767) {
          throwOverflow();
        
        }
      
      }
      else {
        
        byte b3 = (byte)(((b2 ^ 0xFFFFFFFF) & 0xFFFFFF7F) - 65);
        
        if (b3 > 2)
        {
          
          throwOverflow();
        }
        byte b4 = (byte)(b1 - 1);
        
        if (b4 != 20 || arrayOfByte[i + b4] == 102) {
          b4 = (byte)(b4 - 1);
        }
        int k = (b4 > b3 + 1) ? (b3 + 2) : (b4 + 1);
        int m = k + i;
        
        if (k > 1) {
          
          j = 101 - arrayOfByte[i + 1];
          
          for (int i1 = 2 + i; i1 < m; i1++) {
            j = j * 100 + 101 - arrayOfByte[i1];
          }
        } 



        
        for (int n = b3 - b4; n >= 0; n--) {
          j *= 100;
        }
        j = -j;
        
        if (b3 == 2 && 
          j < -32768) {
          throwOverflow();
        }
      } 
      s = (short)j;
    } 
    
    return s;
  }












  
  byte getByte(int paramInt) throws SQLException {
    byte b = 0;
    
    if (this.rowSpaceIndicator == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {

      
      byte[] arrayOfByte = this.rowSpaceByte;
      int i = this.columnIndex + this.byteLength * paramInt + 1;
      byte b1 = arrayOfByte[i - 1];
      
      byte b2 = arrayOfByte[i];
      
      int j = 0;


      
      if ((b2 & Byte.MIN_VALUE) != 0) {



        
        byte b3 = (byte)((b2 & 0xFFFFFF7F) - 65);
        
        if (b3 > 1)
        {
          
          throwOverflow();
        }
        byte b4 = (byte)(b1 - 1);
        
        if (b4 > b3 + 1) {
          
          switch (b3) {










            
            case 0:
              j = arrayOfByte[i + 1] - 1;
              break;




            
            case 1:
              j = (arrayOfByte[i + 1] - 1) * 100 + arrayOfByte[i + 2] - 1;




              
              if (j > 127) {
                throwOverflow();
              }
              break;
          } 
        
        } else if (b4 == 1) {
          
          if (b3 == 1) {
            
            j = (arrayOfByte[i + 1] - 1) * 100;
            
            if (j > 127) {
              throwOverflow();
            }
          } else {
            j = arrayOfByte[i + 1] - 1;
          } 
        } else if (b4 == 2) {
          
          j = (arrayOfByte[i + 1] - 1) * 100 + arrayOfByte[i + 2] - 1;

          
          if (j > 127) {
            throwOverflow();
          
          }
        }
      
      }
      else {
        
        byte b3 = (byte)(((b2 ^ 0xFFFFFFFF) & 0xFFFFFF7F) - 65);
        
        if (b3 > 1)
        {
          
          throwOverflow();
        }
        byte b4 = (byte)(b1 - 1);
        
        if (b4 != 20 || arrayOfByte[i + b4] == 102) {
          b4 = (byte)(b4 - 1);
        }
        if (b4 > b3 + 1) {
          
          switch (b3) {










            
            case 0:
              j = -(101 - arrayOfByte[i + 1]);
              break;




            
            case 1:
              j = -((101 - arrayOfByte[i + 1]) * 100 + 101 - arrayOfByte[i + 2]);




              
              if (j < -128) {
                throwOverflow();
              }
              break;
          } 
        
        } else if (b4 == 1) {
          
          if (b3 == 1) {
            
            j = -(101 - arrayOfByte[i + 1]) * 100;
            
            if (j < -128) {
              throwOverflow();
            }
          } else {
            j = -(101 - arrayOfByte[i + 1]);
          } 
        } else if (b4 == 2) {
          
          j = -((101 - arrayOfByte[i + 1]) * 100 + 101 - arrayOfByte[i + 2]);

          
          if (j < -128) {
            throwOverflow();
          }
        } 
      } 
      b = (byte)j;
    } 
    
    return b;
  }












  
  long getLong(int paramInt) throws SQLException {
    long l = 0L;
    
    if (this.rowSpaceIndicator == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {

      
      byte[] arrayOfByte = this.rowSpaceByte;
      int i = this.columnIndex + this.byteLength * paramInt + 1;
      byte b1 = arrayOfByte[i - 1];
      
      byte b2 = arrayOfByte[i];
      long l1 = 0L;






      
      if ((b2 & Byte.MIN_VALUE) != 0) {



        
        if (b2 == Byte.MIN_VALUE && b1 == 1) {
          return 0L;
        }
        byte b3 = (byte)((b2 & 0xFFFFFF7F) - 65);



        
        if (b3 > 9)
        {
          
          throwOverflow();
        }
        if (b3 == 9) {
          
          byte b = 1;
          byte b5 = b1;
          
          if (b1 > 11) {
            b5 = 11;
          }
          while (b < b5) {


            
            int n = arrayOfByte[i + b] & 0xFF;
            int i1 = MAX_LONG[b];
            
            if (n != i1) {
              
              if (n < i1) {
                break;
              }
              throwOverflow();
            } 
            
            b++;
          } 
          
          if (b == b5 && b1 > 11) {
            throwOverflow();
          }
        } 
        byte b4 = (byte)(b1 - 1);
        
        int j = (b4 > b3 + 1) ? (b3 + 2) : (b4 + 1);
        int k = j + i;
        
        if (j > 1) {
          
          l1 = (arrayOfByte[i + 1] - 1);
          
          for (int n = 2 + i; n < k; n++) {
            l1 = l1 * 100L + (arrayOfByte[n] - 1);
          }
        } 



        
        for (int m = b3 - b4; m >= 0; m--) {
          l1 *= 100L;
        
        }
      
      }
      else {
        
        byte b3 = (byte)(((b2 ^ 0xFFFFFFFF) & 0xFFFFFF7F) - 65);



        
        if (b3 > 9)
        {
          
          throwOverflow();
        }
        if (b3 == 9) {
          
          byte b = 1;
          byte b5 = b1;
          
          if (b1 > 12) {
            b5 = 12;
          }
          while (b < b5) {


            
            int n = arrayOfByte[i + b] & 0xFF;
            int i1 = MIN_LONG[b];
            
            if (n != i1) {
              
              if (n > i1) {
                break;
              }
              throwOverflow();
            } 
            
            b++;
          } 
          
          if (b == b5 && b1 < 12) {
            throwOverflow();
          }
        } 
        byte b4 = (byte)(b1 - 1);
        
        if (b4 != 20 || arrayOfByte[i + b4] == 102) {
          b4 = (byte)(b4 - 1);
        }
        int j = (b4 > b3 + 1) ? (b3 + 2) : (b4 + 1);
        int k = j + i;
        
        if (j > 1) {
          
          l1 = (101 - arrayOfByte[i + 1]);
          
          for (int n = 2 + i; n < k; n++) {
            l1 = l1 * 100L + (101 - arrayOfByte[n]);
          }
        } 



        
        for (int m = b3 - b4; m >= 0; m--) {
          l1 *= 100L;
        }
        l1 = -l1;
      } 
      
      l = l1;
    } 
    
    return l;
  }












  
  float getFloat(int paramInt) throws SQLException {
    float f = 0.0F;
    
    if (this.rowSpaceIndicator == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {

      
      byte[] arrayOfByte = this.rowSpaceByte;
      int i = this.columnIndex + this.byteLength * paramInt + 1;
      byte b1 = arrayOfByte[i - 1];
      
      byte b2 = arrayOfByte[i];

      
      double d = 0.0D;
      
      int j = i + 1;









      
      if ((b2 & Byte.MIN_VALUE) != 0) {



        
        if (b2 == Byte.MIN_VALUE && b1 == 1) {
          return 0.0F;
        }
        if (b1 == 2 && b2 == -1 && arrayOfByte[i + 1] == 101)
        {
          return Float.POSITIVE_INFINITY;
        }
        byte b = (byte)((b2 & 0xFFFFFF7F) - 65);
        
        int m = b1 - 1;
        
        while (arrayOfByte[j] == 1 && m > 0) {
          
          j++;
          m--;
          b = (byte)(b - 1);
        } 





        
        int k = (int)(127.0D - b);
        
        switch (m) {

          
          case 1:
            d = (arrayOfByte[j] - 1) * factorTable[k];
            break;

          
          case 2:
            d = ((arrayOfByte[j] - 1) * 100 + arrayOfByte[j + 1] - 1) * factorTable[k + 1];
            break;


          
          case 3:
            d = ((arrayOfByte[j] - 1) * 10000 + (arrayOfByte[j + 1] - 1) * 100 + arrayOfByte[j + 2] - 1) * factorTable[k + 2];
            break;



          
          case 4:
            d = ((arrayOfByte[j] - 1) * 1000000 + (arrayOfByte[j + 1] - 1) * 10000 + (arrayOfByte[j + 2] - 1) * 100 + arrayOfByte[j + 3] - 1) * factorTable[k + 3];
            break;



          
          case 5:
            d = ((arrayOfByte[j + 1] - 1) * 1000000 + (arrayOfByte[j + 2] - 1) * 10000 + (arrayOfByte[j + 3] - 1) * 100 + arrayOfByte[j + 4] - 1) * factorTable[k + 4] + (arrayOfByte[j] - 1) * factorTable[k];
            break;





          
          case 6:
            d = ((arrayOfByte[j + 2] - 1) * 1000000 + (arrayOfByte[j + 3] - 1) * 10000 + (arrayOfByte[j + 4] - 1) * 100 + arrayOfByte[j + 5] - 1) * factorTable[k + 5] + ((arrayOfByte[j] - 1) * 100 + arrayOfByte[j + 1] - 1) * factorTable[k + 1];
            break;





          
          default:
            d = ((arrayOfByte[j + 3] - 1) * 1000000 + (arrayOfByte[j + 4] - 1) * 10000 + (arrayOfByte[j + 5] - 1) * 100 + arrayOfByte[j + 6] - 1) * factorTable[k + 6] + ((arrayOfByte[j] - 1) * 10000 + (arrayOfByte[j + 1] - 1) * 100 + arrayOfByte[j + 2] - 1) * factorTable[k + 2];
            break;
        } 









      
      } else {
        if (b2 == 0 && b1 == 1) {
          return Float.NEGATIVE_INFINITY;
        }
        byte b = (byte)(((b2 ^ 0xFFFFFFFF) & 0xFFFFFF7F) - 65);
        
        int m = b1 - 1;
        
        if (m != 20 || arrayOfByte[i + m] == 102) {
          m--;
        }
        while (arrayOfByte[j] == 1 && m > 0) {
          
          j++;
          m--;
          b = (byte)(b - 1);
        } 





        
        int k = (int)(127.0D - b);
        
        switch (m) {

          
          case 1:
            d = -(101 - arrayOfByte[j]) * factorTable[k];
            break;

          
          case 2:
            d = -((101 - arrayOfByte[j]) * 100 + 101 - arrayOfByte[j + 1]) * factorTable[k + 1];
            break;


          
          case 3:
            d = -((101 - arrayOfByte[j]) * 10000 + (101 - arrayOfByte[j + 1]) * 100 + 101 - arrayOfByte[j + 2]) * factorTable[k + 2];
            break;



          
          case 4:
            d = -((101 - arrayOfByte[j]) * 1000000 + (101 - arrayOfByte[j + 1]) * 10000 + (101 - arrayOfByte[j + 2]) * 100 + 101 - arrayOfByte[j + 3]) * factorTable[k + 3];
            break;



          
          case 5:
            d = -(((101 - arrayOfByte[j + 1]) * 1000000 + (101 - arrayOfByte[j + 2]) * 10000 + (101 - arrayOfByte[j + 3]) * 100 + 101 - arrayOfByte[j + 4]) * factorTable[k + 4] + (101 - arrayOfByte[j]) * factorTable[k]);
            break;





          
          case 6:
            d = -(((101 - arrayOfByte[j + 2]) * 1000000 + (101 - arrayOfByte[j + 3]) * 10000 + (101 - arrayOfByte[j + 4]) * 100 + 101 - arrayOfByte[j + 5]) * factorTable[k + 5] + ((101 - arrayOfByte[j]) * 100 + 101 - arrayOfByte[j + 1]) * factorTable[k + 1]);
            break;





          
          default:
            d = -(((101 - arrayOfByte[j + 3]) * 1000000 + (101 - arrayOfByte[j + 4]) * 10000 + (101 - arrayOfByte[j + 5]) * 100 + 101 - arrayOfByte[j + 6]) * factorTable[k + 6] + ((101 - arrayOfByte[j]) * 10000 + (101 - arrayOfByte[j + 1]) * 100 + 101 - arrayOfByte[j + 2]) * factorTable[k + 2]);
            break;
        } 






      
      } 
      f = (float)d;
    } 
    
    return f;
  }












  
  double getDouble(int paramInt) throws SQLException {
    double d = 0.0D;
    
    if (this.rowSpaceIndicator == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      double d1; byte b3; int m;
      boolean bool1;
      byte[] arrayOfByte = this.rowSpaceByte;
      int i = this.columnIndex + this.byteLength * paramInt + 1;
      byte b1 = arrayOfByte[i - 1];

      
      byte b2 = arrayOfByte[i];
      
      int j = i + 1;
      int k = b1 - 1;



      
      boolean bool2 = true;








      
      if ((b2 & Byte.MIN_VALUE) != 0) {



        
        if (b2 == Byte.MIN_VALUE && b1 == 1) {
          return 0.0D;
        }
        if (b1 == 2 && b2 == -1 && arrayOfByte[i + 1] == 101)
        {
          return Double.POSITIVE_INFINITY;
        }
        b3 = (byte)((b2 & 0xFFFFFF7F) - 65);
        
        bool1 = ((arrayOfByte[j + k - 1] - 1) % 10 == 0) ? true : false;
        
        m = arrayOfByte[j] - 1;




      
      }
      else {




        
        bool2 = false;
        
        if (b2 == 0 && b1 == 1) {
          return Double.NEGATIVE_INFINITY;
        }
        b3 = (byte)(((b2 ^ 0xFFFFFFFF) & 0xFFFFFF7F) - 65);
        
        if (k != 20 || arrayOfByte[i + k] == 102) {
          k--;
        }
        bool1 = ((101 - arrayOfByte[j + k - 1]) % 10 == 0) ? true : false;
        
        m = 101 - arrayOfByte[j];
      } 






      
      int n = k << 1;
      
      if (bool1) {
        n--;
      }
      int i1 = (b3 + 1 << 1) - n;
      
      if (m < 10) {
        n--;
      }
      if (n <= 15 && ((i1 >= 0 && i1 <= 37 - n) || (i1 < 0 && i1 >= -22))) {
        double d2;


        
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        int i5 = 0;
        int i6 = 0;
        int i7 = 0;
        int i8 = 0;
        
        if (bool2) {
          switch (k) {

            
            default:
              i8 = arrayOfByte[j + 7] - 1;
            
            case 7:
              i7 = arrayOfByte[j + 6] - 1;
            
            case 6:
              i6 = arrayOfByte[j + 5] - 1;
            
            case 5:
              i5 = arrayOfByte[j + 4] - 1;
            
            case 4:
              i4 = arrayOfByte[j + 3] - 1;
            
            case 3:
              i3 = arrayOfByte[j + 2] - 1;
            
            case 2:
              i2 = arrayOfByte[j + 1] - 1;
              break;
            case 1:
              break;
          } 
        } else {
          switch (k) {

            
            default:
              i8 = 101 - arrayOfByte[j + 7];
            
            case 7:
              i7 = 101 - arrayOfByte[j + 6];
            
            case 6:
              i6 = 101 - arrayOfByte[j + 5];
            
            case 5:
              i5 = 101 - arrayOfByte[j + 4];
            
            case 4:
              i4 = 101 - arrayOfByte[j + 3];
            
            case 3:
              i3 = 101 - arrayOfByte[j + 2];
            
            case 2:
              i2 = 101 - arrayOfByte[j + 1];
              break;

            
            case 1:
              break;
          } 
        
        } 
        if (bool1) {
          int i9; int i10; switch (k) {

            
            default:
              d2 = (m / 10);
              break;

            
            case 2:
              d2 = (m * 10 + i2 / 10);
              break;

            
            case 3:
              d2 = (m * 1000 + i2 * 10 + i3 / 10);
              break;

            
            case 4:
              d2 = (m * 100000 + i2 * 1000 + i3 * 10 + i4 / 10);
              break;


            
            case 5:
              d2 = (m * 10000000 + i2 * 100000 + i3 * 1000 + i4 * 10 + i5 / 10);
              break;


            
            case 6:
              i9 = i2 * 10000000 + i3 * 100000 + i4 * 1000 + i5 * 10 + i6 / 10;
              
              d2 = (m * 1000000000L + i9);
              break;

            
            case 7:
              i9 = i3 * 10000000 + i4 * 100000 + i5 * 1000 + i6 * 10 + i7 / 10;
              
              i10 = m * 100 + i2;
              d2 = (i10 * 1000000000L + i9);
              break;

            
            case 8:
              i9 = i4 * 10000000 + i5 * 100000 + i6 * 1000 + i7 * 10 + i8 / 10;
              
              i10 = m * 10000 + i2 * 100 + i3;
              d2 = (i10 * 1000000000L + i9); break;
          } 
        } else {
          int i9;
          int i10;
          switch (k) {

            
            default:
              d2 = m;
              break;

            
            case 2:
              d2 = (m * 100 + i2);
              break;

            
            case 3:
              d2 = (m * 10000 + i2 * 100 + i3);
              break;

            
            case 4:
              d2 = (m * 1000000 + i2 * 10000 + i3 * 100 + i4);
              break;


            
            case 5:
              i9 = i2 * 1000000 + i3 * 10000 + i4 * 100 + i5;
              d2 = (m * 100000000L + i9);
              break;

            
            case 6:
              i9 = i3 * 1000000 + i4 * 10000 + i5 * 100 + i6;
              i10 = m * 100 + i2;
              d2 = (i10 * 100000000L + i9);
              break;

            
            case 7:
              i9 = i4 * 1000000 + i5 * 10000 + i6 * 100 + i7;
              i10 = m * 10000 + i2 * 100 + i3;
              d2 = (i10 * 100000000L + i9);
              break;

            
            case 8:
              i9 = i5 * 1000000 + i6 * 10000 + i7 * 100 + i8;
              i10 = m * 1000000 + i2 * 10000 + i3 * 100 + i4;
              d2 = (i10 * 100000000L + i9);
              break;
          } 



        
        } 
        if (i1 == 0 || d2 == 0.0D) {
          d1 = d2;
        } else if (i1 >= 0) {
          
          if (i1 <= 22)
          {




            
            d1 = d2 * small10pow[i1];
          }
          else
          {
            int i9 = 15 - n;






            
            d2 *= small10pow[i9];
            d1 = d2 * small10pow[i1 - i9];


          
          }


        
        }
        else {


          
          d1 = d2 / small10pow[-i1];
        }
      
      } else {
        
        int i23, i2 = 0;
        int i3 = 0;
        int i4 = 0;
        int i5 = 0;
        int i6 = 0;
        int i7 = 0;
        int i8 = 0;
        int i9 = 0;
        int i10 = 0;
        byte b4 = 0;





        
        int i14 = 0;
        int i15 = 0;
        int i16 = 0;
        int i17 = 0;
        int i18 = 0;


        
        boolean bool = false;
        int i21 = 0;
        
        if (bool2) {
          byte b;
          if ((k & 0x1) != 0) {
            
            b = 2;
            i2 = m;
          }
          else {
            
            b = 3;
            i2 = m * 100 + arrayOfByte[j + 1] - 1;
          } 
          
          for (; b < k; b += 2) {
            
            int i27 = (arrayOfByte[j + b - 1] - 1) * 100 + arrayOfByte[j + b] - 1 + i2 * 10000;

            
            switch (b4) {

              
              default:
                i2 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
                i3 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
                i4 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i5 * 10000;
                i5 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i6 * 10000;
                i6 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i7 * 10000;
                i7 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i8 * 10000;
                i8 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i9 * 10000;
                i9 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i10 * 10000;
                i10 = i27 & 0xFFFF;
                break;

              
              case true:
                i2 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
                i3 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
                i4 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i5 * 10000;
                i5 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i6 * 10000;
                i6 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i7 * 10000;
                i7 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i8 * 10000;
                i8 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i9 * 10000;
                i9 = i27 & 0xFFFF;
                break;

              
              case true:
                i2 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
                i3 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
                i4 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i5 * 10000;
                i5 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i6 * 10000;
                i6 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i7 * 10000;
                i7 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i8 * 10000;
                i8 = i27 & 0xFFFF;
                break;

              
              case true:
                i2 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
                i3 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
                i4 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i5 * 10000;
                i5 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i6 * 10000;
                i6 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i7 * 10000;
                i7 = i27 & 0xFFFF;
                break;

              
              case true:
                i2 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
                i3 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
                i4 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i5 * 10000;
                i5 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i6 * 10000;
                i6 = i27 & 0xFFFF;
                break;

              
              case true:
                i2 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
                i3 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
                i4 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i5 * 10000;
                i5 = i27 & 0xFFFF;
                break;

              
              case true:
                i2 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
                i3 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
                i4 = i27 & 0xFFFF;
                break;

              
              case true:
                i2 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
                i3 = i27 & 0xFFFF;
                break;

              
              case false:
                i2 = i27 & 0xFFFF;
                break;
            } 

            
            i27 = i27 >> 16 & 0xFFFF;
            
            if (i27 != 0) {
              
              b4++;
              
              switch (b4) {

                
                case 8:
                  i10 = i27;
                  break;

                
                case 7:
                  i9 = i27;
                  break;

                
                case 6:
                  i8 = i27;
                  break;

                
                case 5:
                  i7 = i27;
                  break;

                
                case 4:
                  i6 = i27;
                  break;

                
                case 3:
                  i5 = i27;
                  break;

                
                case 2:
                  i4 = i27;
                  break;

                
                case 1:
                  i3 = i27;
                  break;
              } 




            
            } 
          } 
        } else {
          byte b;
          if ((k & 0x1) != 0) {
            
            b = 2;
            i2 = m;
          }
          else {
            
            b = 3;
            i2 = m * 100 + 101 - arrayOfByte[j + 1];
          } 
          
          for (; b < k; b += 2) {
            
            int i27 = (101 - arrayOfByte[j + b - 1]) * 100 + 101 - arrayOfByte[j + b] + i2 * 10000;

            
            switch (b4) {

              
              default:
                i2 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
                i3 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
                i4 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i5 * 10000;
                i5 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i6 * 10000;
                i6 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i7 * 10000;
                i7 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i8 * 10000;
                i8 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i9 * 10000;
                i9 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i10 * 10000;
                i10 = i27 & 0xFFFF;
                break;

              
              case 7:
                i2 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
                i3 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
                i4 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i5 * 10000;
                i5 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i6 * 10000;
                i6 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i7 * 10000;
                i7 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i8 * 10000;
                i8 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i9 * 10000;
                i9 = i27 & 0xFFFF;
                break;

              
              case 6:
                i2 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
                i3 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
                i4 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i5 * 10000;
                i5 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i6 * 10000;
                i6 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i7 * 10000;
                i7 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i8 * 10000;
                i8 = i27 & 0xFFFF;
                break;

              
              case 5:
                i2 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
                i3 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
                i4 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i5 * 10000;
                i5 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i6 * 10000;
                i6 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i7 * 10000;
                i7 = i27 & 0xFFFF;
                break;

              
              case 4:
                i2 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
                i3 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
                i4 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i5 * 10000;
                i5 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i6 * 10000;
                i6 = i27 & 0xFFFF;
                break;

              
              case 3:
                i2 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
                i3 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
                i4 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i5 * 10000;
                i5 = i27 & 0xFFFF;
                break;

              
              case 2:
                i2 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
                i3 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i4 * 10000;
                i4 = i27 & 0xFFFF;
                break;

              
              case 1:
                i2 = i27 & 0xFFFF;
                i27 = (i27 >> 16 & 0xFFFF) + i3 * 10000;
                i3 = i27 & 0xFFFF;
                break;

              
              case 0:
                i2 = i27 & 0xFFFF;
                break;
            } 

            
            i27 = i27 >> 16 & 0xFFFF;
            
            if (i27 != 0) {
              
              b4++;
              
              switch (b4) {

                
                case 8:
                  i10 = i27;
                  break;

                
                case 7:
                  i9 = i27;
                  break;

                
                case 6:
                  i8 = i27;
                  break;

                
                case 5:
                  i7 = i27;
                  break;

                
                case 4:
                  i6 = i27;
                  break;

                
                case 3:
                  i5 = i27;
                  break;

                
                case 2:
                  i4 = i27;
                  break;

                
                case 1:
                  i3 = i27;
                  break;
              } 





































            
            } 
          } 
        } 
        byte b7 = b4;
        
        b4++;
        
        int i11 = 62 - b3 + k;
        
        int i12 = nexpdigstable[i11];
        int[] arrayOfInt = expdigstable[i11];
        i21 = b4 + 5;
        
        int i22 = 0;
        
        if (i12 > i21) {
          
          i22 = i12 - i21;
          i12 = i21;
        } 
        
        byte b6 = 0;
        int i13 = 0;
        int i19 = i12 - 1 + b4 - 1 - 4;
        byte b5;
        for (b5 = 0; b5 < i19; b5++) {
          
          int i27 = i13 & 0xFFFF;
          
          i13 = i13 >> 16 & 0xFFFF;
          
          byte b9 = (b4 < b5 + 1) ? b4 : (b5 + 1);
          
          for (byte b8 = (b5 - i12 + 1 > 0) ? (b5 - i12 + 1) : 0; b8 < b9; 
            b8++) {
            
            int i29, i28 = i22 + b5 - b8;

            
            switch (b8) {

              
              case 8:
                i29 = i10 * arrayOfInt[i28];
                break;

              
              case 7:
                i29 = i9 * arrayOfInt[i28];
                break;

              
              case 6:
                i29 = i8 * arrayOfInt[i28];
                break;

              
              case 5:
                i29 = i7 * arrayOfInt[i28];
                break;

              
              case 4:
                i29 = i6 * arrayOfInt[i28];
                break;

              
              case 3:
                i29 = i5 * arrayOfInt[i28];
                break;

              
              case 2:
                i29 = i4 * arrayOfInt[i28];
                break;

              
              case 1:
                i29 = i3 * arrayOfInt[i28];
                break;

              
              default:
                i29 = i2 * arrayOfInt[i28];
                break;
            } 

            
            i27 += i29 & 0xFFFF;
            i13 += i29 >> 16 & 0xFFFF;
          } 
          
          bool = (bool || (i27 & 0xFFFF) != 0) ? true : false;
          i13 += i27 >> 16 & 0xFFFF;
        } 
        
        i19 += 5;
        
        for (; b5 < i19; b5++) {
          
          int i27 = i13 & 0xFFFF;
          
          i13 = i13 >> 16 & 0xFFFF;
          
          byte b9 = (b4 < b5 + 1) ? b4 : (b5 + 1);
          
          for (byte b8 = (b5 - i12 + 1 > 0) ? (b5 - i12 + 1) : 0; b8 < b9; 
            b8++) {
            
            int i29, i28 = i22 + b5 - b8;

            
            switch (b8) {

              
              case 8:
                i29 = i10 * arrayOfInt[i28];
                break;




              
              case 7:
                i29 = i9 * arrayOfInt[i28];
                break;




              
              case 6:
                i29 = i8 * arrayOfInt[i28];
                break;




              
              case 5:
                i29 = i7 * arrayOfInt[i28];
                break;




              
              case 4:
                i29 = i6 * arrayOfInt[i28];
                break;




              
              case 3:
                i29 = i5 * arrayOfInt[i28];
                break;




              
              case 2:
                i29 = i4 * arrayOfInt[i28];
                break;




              
              case 1:
                i29 = i3 * arrayOfInt[i28];
                break;




              
              default:
                i29 = i2 * arrayOfInt[i28];
                break;
            } 




            
            i27 += i29 & 0xFFFF;
            i13 += i29 >> 16 & 0xFFFF;
          } 
          
          switch (b6++) {

            
            case 4:
              i18 = i27 & 0xFFFF;
              break;

            
            case 3:
              i17 = i27 & 0xFFFF;
              break;

            
            case 2:
              i16 = i27 & 0xFFFF;
              break;

            
            case 1:
              i15 = i27 & 0xFFFF;
              break;

            
            default:
              i14 = i27 & 0xFFFF;
              break;
          } 

          
          i13 += i27 >> 16 & 0xFFFF;
        } 
        
        while (i13 != 0) {
          
          if (b6 < 5) {
            switch (b6++) {

              
              case 4:
                i18 = i13 & 0xFFFF;
                break;

              
              case 3:
                i17 = i13 & 0xFFFF;
                break;

              
              case 2:
                i16 = i13 & 0xFFFF;
                break;

              
              case 1:
                i15 = i13 & 0xFFFF;
                break;

              
              default:
                i14 = i13 & 0xFFFF;
                break;
            } 

          
          } else {
            bool = (bool || i14 != 0) ? true : false;
            i14 = i15;
            i15 = i16;
            i16 = i17;
            i17 = i18;
            i18 = i13 & 0xFFFF;
          } 
          
          i13 = i13 >> 16 & 0xFFFF;
          b7++;
        } 
        
        int i20 = (binexpstable[i11] + b7) * 16 - 1;


        
        switch (b6) {

          
          case 5:
            i23 = i18;
            break;

          
          case 4:
            i23 = i17;
            break;

          
          case 3:
            i23 = i16;
            break;

          
          case 2:
            i23 = i15;
            break;

          
          default:
            i23 = i14;
            break;
        } 
        
        int i24;
        for (i24 = i23 >> 1; i24 != 0; i24 >>= 1) {
          i20++;
        }
        
        i24 = 5;
        int i25 = i23 << 5;
        int i26 = 0;
        
        i13 = 0;
        
        while ((i25 & 0x100000) == 0) {
          
          i25 <<= 1;
          i24++;
        } 
        
        switch (b6) {

          
          case 5:
            if (i24 > 16) {

              
              i25 |= i17 << i24 - 16 | i16 >> 32 - i24;
              i26 = i16 << i24 | i15 << i24 - 16 | i14 >> 32 - i24;
              
              i13 = i14 & 1 << 31 - i24;
              bool = (bool || i14 << i24 + 1 != 0) ? true : false;
              break;
            } 
            if (i24 == 16) {

              
              i25 |= i17;
              i26 = i16 << 16 | i15;
              i13 = i14 & 0x8000;
              bool = (bool || (i14 & 0x7FFF) != 0) ? true : false;

              
              break;
            } 
            
            i25 |= i17 >> 16 - i24;
            i26 = i17 << 16 + i24 | i16 << i24 | i15 >> 16 - i24;
            
            i13 = i15 & 1 << 15 - i24;
            
            if (i24 < 15) {
              bool = (bool || i15 << i24 + 17 != 0) ? true : false;
            }
            bool = (bool || i14 != 0) ? true : false;
            break;



          
          case 4:
            if (i24 > 16) {

              
              i25 |= i16 << i24 - 16 | i15 >> 32 - i24;
              i26 = i15 << i24 | i14 << i24 - 16;
              break;
            } 
            if (i24 == 16) {

              
              i25 |= i16;
              
              i26 = i15 << 16 | i14;

              
              break;
            } 
            
            i25 |= i16 >> 16 - i24;
            i26 = i16 << 16 + i24 | i15 << i24 | i14 >> 16 - i24;
            
            i13 = i14 & 1 << 15 - i24;
            
            if (i24 < 15) {
              bool = (bool || i14 << i24 + 17 != 0) ? true : false;
            }
            break;


          
          case 3:
            if (i24 > 16) {

              
              i25 |= i15 << i24 - 16 | i14 >> 32 - i24;
              i26 = i14 << i24;
              break;
            } 
            if (i24 == 16) {

              
              i25 |= i15;
              
              i26 = i14 << 16;

              
              break;
            } 
            
            i25 |= i15 >> 16 - i24;
            i26 = i15 << 16 + i24;
            
            i26 |= i14 << i24;
            break;



          
          case 2:
            if (i24 > 16) {

              
              i25 |= i14 << i24 - 16;
              break;
            } 
            if (i24 == 16) {

              
              i25 |= i14;

              
              break;
            } 
            
            i25 |= i14 >> 16 - i24;
            i26 = i14 << 16 + i24;
            break;
        } 






        
        if (i13 != 0 && (bool || (i26 & 0x1) != 0))
        {
          if (i26 == -1) {
            
            i26 = 0;
            i25++;
            
            if ((i25 & 0x200000) != 0) {
              
              i26 = i26 >> 1 | i25 << 31;
              i25 >>= 1;
              i20++;
            } 
          } else {
            
            i26++;
          } 
        }









        
        long l = i20 << 52L | (i25 & 0xFFFFF) << 32L | i26 & 0xFFFFFFFFL;

        
        d1 = Double.longBitsToDouble(l);
      } 






      
      d = bool2 ? d1 : -d1;
    } 
    
    return d;
  }













  
  double getDoubleImprecise(int paramInt) throws SQLException {
    double d = 0.0D;
    
    if (this.rowSpaceIndicator == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {

      
      byte[] arrayOfByte = this.rowSpaceByte;
      int i = this.columnIndex + this.byteLength * paramInt + 1;
      byte b1 = arrayOfByte[i - 1];
      
      byte b2 = arrayOfByte[i];

      
      double d1 = 0.0D;
      
      int j = i + 1;









      
      if ((b2 & Byte.MIN_VALUE) != 0) {



        
        if (b2 == Byte.MIN_VALUE && b1 == 1) {
          return 0.0D;
        }
        if (b1 == 2 && b2 == -1 && arrayOfByte[i + 1] == 101)
        {
          return Double.POSITIVE_INFINITY;
        }
        byte b = (byte)((b2 & 0xFFFFFF7F) - 65);
        
        int n = b1 - 1;






        
        int k = (int)(127.0D - b);
        
        int m = n % 4;
        
        switch (m) {

          
          case 1:
            d1 = (arrayOfByte[j] - 1) * factorTable[k];
            break;

          
          case 2:
            d1 = ((arrayOfByte[j] - 1) * 100 + arrayOfByte[j + 1] - 1) * factorTable[k + 1];
            break;


          
          case 3:
            d1 = ((arrayOfByte[j] - 1) * 10000 + (arrayOfByte[j + 1] - 1) * 100 + arrayOfByte[j + 2] - 1) * factorTable[k + 2];
            break;
        } 






        
        for (; m < n; m += 4) {
          d1 += ((arrayOfByte[j + m] - 1) * 1000000 + (arrayOfByte[j + m + 1] - 1) * 10000 + (arrayOfByte[j + m + 2] - 1) * 100 + arrayOfByte[j + m + 3] - 1) * factorTable[k + m + 3];

        
        }

      
      }
      else {

        
        if (b2 == 0 && b1 == 1) {
          return Double.NEGATIVE_INFINITY;
        }
        byte b = (byte)(((b2 ^ 0xFFFFFFFF) & 0xFFFFFF7F) - 65);
        
        int n = b1 - 1;
        
        if (n != 20 || arrayOfByte[i + n] == 102) {
          n--;
        }





        
        int k = (int)(127.0D - b);
        
        int m = n % 4;
        
        switch (m) {

          
          case 1:
            d1 = (101 - arrayOfByte[j]) * factorTable[k];
            break;

          
          case 2:
            d1 = ((101 - arrayOfByte[j]) * 100 + 101 - arrayOfByte[j + 1]) * factorTable[k + 1];
            break;


          
          case 3:
            d1 = ((101 - arrayOfByte[j]) * 10000 + (101 - arrayOfByte[j + 1]) * 100 + 101 - arrayOfByte[j + 2]) * factorTable[k + 2];
            break;
        } 






        
        for (; m < n; m += 4) {
          d1 += ((101 - arrayOfByte[j + m]) * 1000000 + (101 - arrayOfByte[j + m + 1]) * 10000 + (101 - arrayOfByte[j + m + 2]) * 100 + 101 - arrayOfByte[j + m + 3]) * factorTable[k + m + 3];
        }

        
        d1 = -d1;
      } 

      
      d = d1;
    } 
    
    return d;
  }












  
  int[] digs = new int[27]; static final int LNXSGNBT = 128; static final byte LNXDIGS = 20;
  static final byte LNXEXPBS = 64;
  static final int LNXEXPMX = 127;
  
  BigDecimal getBigDecimal(int paramInt) throws SQLException {
    BigDecimal bigDecimal = null;
    
    if (this.rowSpaceIndicator == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      int k, n, i1; byte b5;
      int i2;
      byte[] arrayOfByte2, arrayOfByte1 = this.rowSpaceByte;
      int i = this.columnIndex + this.byteLength * paramInt + 1;
      byte b1 = arrayOfByte1[i - 1];
      int j;
      for (j = 0; j < 27; j++) {
        this.digs[j] = 0;
      }
      j = 0;
      byte b2 = 1;
      
      byte b3 = 26;
      int m = 0;

      
      byte b4 = arrayOfByte1[i];



      
      boolean bool = false;
      
      if ((b4 & Byte.MIN_VALUE) != 0) {






        
        if (b4 == Byte.MIN_VALUE && b1 == 1) {
          return BIGDEC_ZERO;
        }
        if (b1 == 2 && b4 == -1 && arrayOfByte1[i + 1] == 101)
        {

          
          throwOverflow();
        }
        b5 = 1;
        byte b = (byte)((b4 & 0xFFFFFF7F) - 65);

        
        i1 = b1 - 1;
        k = i1 - 1;
        i2 = b - i1 + 1 << 1;
        
        if (i2 > 0) {
          
          i2 = 0;
          k = b;
        }
        else if (i2 < 0) {
          bool = ((arrayOfByte1[i + i1] - 1) % 10 == 0) ? true : false;
        } 
        b2 = (byte)(b2 + 1); j = arrayOfByte1[i + b2] - 1;
        
        while ((k & 0x1) != 0)
        {
          if (b2 > i1) {
            j *= 100;
          } else {
            b2 = (byte)(b2 + 1); j = j * 100 + arrayOfByte1[i + b2] - 1;
          } 
          k--;

        
        }


      
      }
      else {

        
        if (b4 == 0 && b1 == 1)
        {
          
          throwOverflow();
        }
        b5 = -1;
        byte b = (byte)(((b4 ^ 0xFFFFFFFF) & 0xFFFFFF7F) - 65);

        
        i1 = b1 - 1;
        
        if (i1 != 20 || arrayOfByte1[i + i1] == 102) {
          i1--;
        }
        k = i1 - 1;
        
        i2 = b - i1 + 1 << 1;
        
        if (i2 > 0) {
          
          i2 = 0;
          k = b;
        }
        else if (i2 < 0) {
          bool = ((101 - arrayOfByte1[i + i1]) % 10 == 0) ? true : false;
        } 
        b2 = (byte)(b2 + 1); j = 101 - arrayOfByte1[i + b2];
        
        while ((k & 0x1) != 0) {
          
          if (b2 > i1) {
            j *= 100;
          } else {
            b2 = (byte)(b2 + 1); j = j * 100 + 101 - arrayOfByte1[i + b2];
          } 
          k--;
        } 
      } 
      
      if (bool) {
        
        i2++;
        j /= 10;
      } 
      
      int i3 = i1 - 1;
      
      while (k != 0) {
        
        if (b5 == 1) {
          
          if (bool)
          {
            m = (arrayOfByte1[i + b2 - 1] - 1) % 10 * 1000 + (arrayOfByte1[i + b2] - 1) * 10 + (arrayOfByte1[i + b2 + 1] - 1) / 10 + j * 10000;

            
            b2 = (byte)(b2 + 2);
          }
          else if (b2 < i3)
          {
            m = (arrayOfByte1[i + b2] - 1) * 100 + arrayOfByte1[i + b2 + 1] - 1 + j * 10000;

            
            b2 = (byte)(b2 + 2);
          }
          else
          {
            m = 0;
            
            if (b2 <= i1) {
              
              byte b7 = 0;
              
              for (; b2 <= i1; b7++) {
                b2 = (byte)(b2 + 1); m = m * 100 + arrayOfByte1[i + b2] - 1;
              } 
              for (; b7 < 2; b7++) {
                m *= 100;
              }
            } 
            m += j * 10000;
          }
        
        } else if (bool) {
          
          m = (101 - arrayOfByte1[i + b2 - 1]) % 10 * 1000 + (101 - arrayOfByte1[i + b2]) * 10 + (101 - arrayOfByte1[i + b2 + 1]) / 10 + j * 10000;

          
          b2 = (byte)(b2 + 2);
        }
        else if (b2 < i3) {
          
          m = (101 - arrayOfByte1[i + b2]) * 100 + 101 - arrayOfByte1[i + b2 + 1] + j * 10000;

          
          b2 = (byte)(b2 + 2);
        }
        else {
          
          m = 0;
          
          if (b2 <= i1) {
            
            byte b7 = 0;
            
            for (; b2 <= i1; b7++) {
              b2 = (byte)(b2 + 1); m = m * 100 + 101 - arrayOfByte1[i + b2];
            } 
            for (; b7 < 2; b7++) {
              m *= 100;
            }
          } 
          m += j * 10000;
        } 
        
        j = m & 0xFFFF;
        
        for (byte b = 25; b >= b3; b--) {
          
          m = (m >> 16) + this.digs[b] * 10000;
          this.digs[b] = m & 0xFFFF;
        } 
        
        if (b3 > 0) {
          
          m >>= 16;
          if (m != 0) {
            b3 = (byte)(b3 - 1); this.digs[b3] = m;
          } 
        } 
        k -= 2;
      } 
      
      this.digs[26] = j;









      
      byte b6 = (byte)(this.digs[b3] >> 8 & 0xFF);
      
      if (b6 == 0) {
        
        n = 53 - (b3 << 1);
        arrayOfByte2 = new byte[n];
        
        for (byte b = 26; b > b3; b--) {
          
          int i4 = b - b3 << 1;
          
          arrayOfByte2[i4 - 1] = (byte)(this.digs[b] >> 8 & 0xFF);
          arrayOfByte2[i4] = (byte)(this.digs[b] & 0xFF);
        } 
        
        arrayOfByte2[0] = (byte)(this.digs[b3] & 0xFF);
      }
      else {
        
        n = 54 - (b3 << 1);
        arrayOfByte2 = new byte[n];
        
        for (byte b = 26; b > b3; b--) {
          
          int i4 = b - b3 << 1;
          
          arrayOfByte2[i4] = (byte)(this.digs[b] >> 8 & 0xFF);
          arrayOfByte2[i4 + 1] = (byte)(this.digs[b] & 0xFF);
        } 
        
        arrayOfByte2[0] = b6;
        arrayOfByte2[1] = (byte)(this.digs[b3] & 0xFF);
      } 
      
      if (i2 == 0 && n < 8 && n > 0) {
        long l = arrayOfByte2[0] & 0xFFL;
        for (byte b = 1; b < n; ) { l = l << 8L | (arrayOfByte2[b] & 0xFF); b++; }
         l *= b5;
        bigDecimal = new BigDecimal(l);
      
      }
      else {
        
        BigInteger bigInteger = new BigInteger(b5, arrayOfByte2);
        
        bigDecimal = new BigDecimal(bigInteger, -i2);
      } 
    } 

    
    return bigDecimal;
  }




  
  BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
    if (this.rowSpaceIndicator == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt1] == -1)
    {
      return null;
    }

    
    return getBigDecimal(paramInt1).setScale(paramInt2, 6);
  }














  
  String getString(int paramInt) throws SQLException {
    String str = null;
    
    if (this.rowSpaceIndicator == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {

      
      byte[] arrayOfByte1 = this.rowSpaceByte;
      int i = this.columnIndex + this.byteLength * paramInt + 1;
      byte b = arrayOfByte1[i - 1];























































































































































































































































































      
      byte[] arrayOfByte2 = new byte[b];
      
      System.arraycopy(arrayOfByte1, i, arrayOfByte2, 0, b);
      
      NUMBER nUMBER = new NUMBER(arrayOfByte2);







      
      String str1 = NUMBER.toString(arrayOfByte2);
      int j = str1.length();
      
      if (str1.startsWith("0.") || str1.startsWith("-0.")) {
        j--;
      }
      if (j > 38) {








        
        str1 = nUMBER.toText(-44, null);


        
        int k = str1.indexOf('E');
        int m = str1.indexOf('+');
        
        if (k == -1)
        {
          k = str1.indexOf('e');
        }
        
        int n = k - 1;
        
        while (str1.charAt(n) == '0')
        {
          n--;
        }
        
        String str2 = str1.substring(0, n + 1);
        String str3 = null;
        
        if (m > 0) {
          
          str3 = str1.substring(m + 1);
        }
        else {
          
          str3 = str1.substring(k + 1);
        } 
        
        return (str2 + "E" + str3).trim();
      } 
      
      return nUMBER.toText(38, null).trim();
    } 



    
    return str;
  }












  
  NUMBER getNUMBER(int paramInt) throws SQLException {
    NUMBER nUMBER = null;
    
    if (this.rowSpaceIndicator == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      int i = this.columnIndex + this.byteLength * paramInt + 1;
      byte b = this.rowSpaceByte[i - 1];
      byte[] arrayOfByte = new byte[b];
      
      System.arraycopy(this.rowSpaceByte, i, arrayOfByte, 0, b);
      
      nUMBER = new NUMBER(arrayOfByte);
    } 
    
    return nUMBER;
  }











  
  Object getObject(int paramInt) throws SQLException {
    BigDecimal bigDecimal;
    Double double_ = null;
    
    if (this.rowSpaceIndicator == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1)
    {
      if (this.externalType == 0) {




























        
        if (this.statement.connection.j2ee13Compliant && this.precision != 0 && this.scale == -127) {
          
          double_ = new Double(getDouble(paramInt));
        } else {
          bigDecimal = getBigDecimal(paramInt);
        } 
      } else {
        
        switch (this.externalType) {

          
          case -7:
            return Boolean.valueOf(getBoolean(paramInt));
          
          case -6:
            return Byte.valueOf(getByte(paramInt));
          
          case 5:
            return Short.valueOf(getShort(paramInt));
          
          case 4:
            return Integer.valueOf(getInt(paramInt));
          
          case -5:
            return Long.valueOf(getLong(paramInt));

          
          case 6:
          case 8:
            return Double.valueOf(getDouble(paramInt));
          
          case 7:
            return Float.valueOf(getFloat(paramInt));

          
          case 2:
          case 3:
            return getBigDecimal(paramInt);
        } 

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 
    }



    
    return bigDecimal;
  }












  
  Object getObject(int paramInt, Map paramMap) throws SQLException {
    return getObject(paramInt);
  }












  
  Datum getOracleObject(int paramInt) throws SQLException {
    return (Datum)getNUMBER(paramInt);
  }
















  
  byte[] getBytes(int paramInt) throws SQLException {
    byte[] arrayOfByte = null;
    
    if (this.rowSpaceIndicator == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      int i = this.columnIndex + this.byteLength * paramInt + 1;
      byte b = this.rowSpaceByte[i - 1];
      
      arrayOfByte = new byte[b];
      
      System.arraycopy(this.rowSpaceByte, i, arrayOfByte, 0, b);
    } 
    
    return arrayOfByte;
  }























  
  static final BigDecimal BIGDEC_ZERO = BigDecimal.valueOf(0L);
  
  static final byte MAX_LONG_EXPONENT = 9;
  
  static final byte MIN_LONG_EXPONENT = 9;
  static final byte MAX_INT_EXPONENT = 4;
  static final byte MIN_INT_EXPONENT = 4;
  static final byte MAX_SHORT_EXPONENT = 2;
  static final byte MIN_SHORT_EXPONENT = 2;
  static final byte MAX_BYTE_EXPONENT = 1;
  static final byte MIN_BYTE_EXPONENT = 1;
  static final int[] MAX_LONG = new int[] { 202, 10, 23, 34, 73, 4, 69, 55, 78, 59, 8 };


  
  static final int[] MIN_LONG = new int[] { 53, 92, 79, 68, 29, 98, 33, 47, 24, 43, 93, 102 };


  
  static final int MAX_LONG_length = 11;

  
  static final int MIN_LONG_length = 12;

  
  static final double[] factorTable = new double[] { 1.0E254D, 1.0E252D, 1.0E250D, 1.0E248D, 1.0E246D, 1.0E244D, 1.0E242D, 1.0E240D, 1.0E238D, 1.0E236D, 1.0E234D, 1.0E232D, 1.0E230D, 1.0E228D, 1.0E226D, 1.0E224D, 1.0E222D, 1.0E220D, 1.0E218D, 1.0E216D, 1.0E214D, 1.0E212D, 1.0E210D, 1.0E208D, 1.0E206D, 1.0E204D, 1.0E202D, 1.0E200D, 1.0E198D, 1.0E196D, 1.0E194D, 1.0E192D, 1.0E190D, 1.0E188D, 1.0E186D, 1.0E184D, 1.0E182D, 1.0E180D, 1.0E178D, 1.0E176D, 1.0E174D, 1.0E172D, 1.0E170D, 1.0E168D, 1.0E166D, 1.0E164D, 1.0E162D, 1.0E160D, 1.0E158D, 1.0E156D, 1.0E154D, 1.0E152D, 1.0E150D, 1.0E148D, 1.0E146D, 1.0E144D, 1.0E142D, 1.0E140D, 1.0E138D, 1.0E136D, 1.0E134D, 1.0E132D, 1.0E130D, 1.0E128D, 1.0E126D, 1.0E124D, 1.0E122D, 1.0E120D, 1.0E118D, 1.0E116D, 1.0E114D, 1.0E112D, 1.0E110D, 1.0E108D, 1.0E106D, 1.0E104D, 1.0E102D, 1.0E100D, 1.0E98D, 1.0E96D, 1.0E94D, 1.0E92D, 1.0E90D, 1.0E88D, 1.0E86D, 1.0E84D, 1.0E82D, 1.0E80D, 1.0E78D, 1.0E76D, 1.0E74D, 1.0E72D, 1.0E70D, 1.0E68D, 1.0E66D, 1.0E64D, 1.0E62D, 1.0E60D, 1.0E58D, 1.0E56D, 1.0E54D, 1.0E52D, 1.0E50D, 1.0E48D, 1.0E46D, 1.0E44D, 1.0E42D, 1.0E40D, 1.0E38D, 1.0E36D, 1.0E34D, 1.0E32D, 1.0E30D, 1.0E28D, 1.0E26D, 1.0E24D, 1.0E22D, 1.0E20D, 1.0E18D, 1.0E16D, 1.0E14D, 1.0E12D, 1.0E10D, 1.0E8D, 1000000.0D, 10000.0D, 100.0D, 1.0D, 0.01D, 1.0E-4D, 1.0E-6D, 1.0E-8D, 1.0E-10D, 1.0E-12D, 1.0E-14D, 1.0E-16D, 1.0E-18D, 1.0E-20D, 1.0E-22D, 1.0E-24D, 1.0E-26D, 1.0E-28D, 1.0E-30D, 1.0E-32D, 1.0E-34D, 1.0E-36D, 1.0E-38D, 1.0E-40D, 1.0E-42D, 1.0E-44D, 1.0E-46D, 1.0E-48D, 1.0E-50D, 1.0E-52D, 1.0E-54D, 1.0E-56D, 1.0E-58D, 1.0E-60D, 1.0E-62D, 1.0E-64D, 1.0E-66D, 1.0E-68D, 1.0E-70D, 1.0E-72D, 1.0E-74D, 1.0E-76D, 1.0E-78D, 1.0E-80D, 1.0E-82D, 1.0E-84D, 1.0E-86D, 1.0E-88D, 1.0E-90D, 1.0E-92D, 1.0E-94D, 1.0E-96D, 1.0E-98D, 1.0E-100D, 1.0E-102D, 1.0E-104D, 1.0E-106D, 1.0E-108D, 1.0E-110D, 1.0E-112D, 1.0E-114D, 1.0E-116D, 1.0E-118D, 1.0E-120D, 1.0E-122D, 1.0E-124D, 1.0E-126D, 1.0E-128D, 1.0E-130D, 1.0E-132D, 1.0E-134D, 1.0E-136D, 1.0E-138D, 1.0E-140D, 1.0E-142D, 1.0E-144D, 1.0E-146D, 1.0E-148D, 1.0E-150D, 1.0E-152D, 1.0E-154D, 1.0E-156D, 1.0E-158D, 1.0E-160D, 1.0E-162D, 1.0E-164D, 1.0E-166D, 1.0E-168D, 1.0E-170D, 1.0E-172D, 1.0E-174D, 1.0E-176D, 1.0E-178D, 1.0E-180D, 1.0E-182D, 1.0E-184D, 1.0E-186D, 1.0E-188D, 1.0E-190D, 1.0E-192D, 1.0E-194D, 1.0E-196D, 1.0E-198D, 1.0E-200D, 1.0E-202D, 1.0E-204D, 1.0E-206D, 1.0E-208D, 1.0E-210D, 1.0E-212D, 1.0E-214D, 1.0E-216D, 1.0E-218D, 1.0E-220D, 1.0E-222D, 1.0E-224D, 1.0E-226D, 1.0E-228D, 1.0E-230D, 1.0E-232D, 1.0E-234D, 1.0E-236D, 1.0E-238D, 1.0E-240D, 1.0E-242D, 1.0E-244D, 1.0E-246D, 1.0E-248D, 1.0E-250D, 1.0E-252D, 1.0E-254D };



































  
  static final double[] small10pow = new double[] { 1.0D, 10.0D, 100.0D, 1000.0D, 10000.0D, 100000.0D, 1000000.0D, 1.0E7D, 1.0E8D, 1.0E9D, 1.0E10D, 1.0E11D, 1.0E12D, 1.0E13D, 1.0E14D, 1.0E15D, 1.0E16D, 1.0E17D, 1.0E18D, 1.0E19D, 1.0E20D, 1.0E21D, 1.0E22D };





  
  static final int tablemax = factorTable.length;
  static final double tablemaxexponent = 127.0D;
  static final double tableminexponent = 127.0D - (tablemax - 20);

  
  static final int MANTISSA_SIZE = 53;
  
  static final int[] expdigs0 = new int[] { 25597, 55634, 18440, 18324, 42485, 50370, 56862, 11593, 45703, 57341, 10255, 12549, 59579, 5 };




  
  static final int[] expdigs1 = new int[] { 50890, 19916, 24149, 23777, 11324, 41057, 14921, 56274, 30917, 19462, 54968, 47943, 38791, 3872 };




  
  static final int[] expdigs2 = new int[] { 24101, 29690, 40218, 29073, 29604, 22037, 27674, 9082, 56670, 55244, 20865, 54874, 47573, 38 };




  
  static final int[] expdigs3 = new int[] { 22191, 40873, 1607, 45622, 23883, 24544, 32988, 43530, 61694, 55616, 43150, 32976, 27418, 25379 };




  
  static final int[] expdigs4 = new int[] { 55927, 44317, 6569, 54851, 238, 63160, 51447, 12231, 55667, 25459, 5674, 40962, 52047, 253 };




  
  static final int[] expdigs5 = new int[] { 56264, 8962, 51839, 64773, 39323, 49783, 15587, 30924, 36601, 56615, 27581, 36454, 35254, 2 };




  
  static final int[] expdigs6 = new int[] { 21545, 25466, 59727, 37873, 13099, 7602, 15571, 49963, 37664, 46896, 14328, 59258, 17403, 1663 };




  
  static final int[] expdigs7 = new int[] { 12011, 4842, 3874, 57395, 38141, 46606, 49307, 60792, 31833, 21440, 9318, 47123, 41461, 16 };




  
  static final int[] expdigs8 = new int[] { 52383, 25023, 56409, 43947, 51036, 17420, 62725, 5735, 53692, 44882, 64439, 36137, 24719, 10900 };




  
  static final int[] expdigs9 = new int[] { 65404, 27119, 57580, 26653, 42453, 19179, 26186, 42000, 1847, 62708, 14406, 12813, 247, 109 };




  
  static final int[] expdigs10 = new int[] { 36698, 50078, 40552, 35000, 49576, 56552, 261, 49572, 31475, 59609, 45363, 46658, 5900, 1 };




  
  static final int[] expdigs11 = new int[] { 33321, 54106, 42443, 60698, 47535, 24088, 45785, 18352, 47026, 40291, 5183, 35843, 24059, 714 };




  
  static final int[] expdigs12 = new int[] { 12129, 44450, 22706, 34030, 37175, 8760, 31915, 56544, 23407, 52176, 7260, 41646, 9415, 7 };




  
  static final int[] expdigs13 = new int[] { 43054, 17160, 43698, 6780, 36385, 52800, 62346, 52747, 33988, 2855, 31979, 38083, 44325, 4681 };




  
  static final int[] expdigs14 = new int[] { 60723, 40803, 16165, 19073, 2985, 9703, 41911, 37227, 41627, 1994, 38986, 27250, 53527, 46 };




  
  static final int[] expdigs15 = new int[] { 36481, 57623, 45627, 58488, 53274, 7238, 2063, 31221, 62631, 25319, 35409, 25293, 54667, 30681 };




  
  static final int[] expdigs16 = new int[] { 52138, 47106, 3077, 4517, 41165, 38738, 39997, 10142, 13078, 16637, 53438, 54647, 53630, 306 };




  
  static final int[] expdigs17 = new int[] { 25425, 24719, 55736, 8564, 12208, 3664, 51518, 17140, 61079, 30312, 2500, 30693, 4468, 3 };




  
  static final int[] expdigs18 = new int[] { 58368, 65134, 52675, 3178, 26300, 7986, 11833, 515, 23109, 63525, 29138, 19030, 50114, 2010 };




  
  static final int[] expdigs19 = new int[] { 41216, 15724, 12323, 26246, 59245, 58406, 46648, 13767, 11372, 15053, 61895, 48686, 7054, 20 };




  
  static final int[] expdigs20 = new int[] { 0, 29248, 62416, 1433, 14025, 43846, 39905, 44375, 137, 47955, 62409, 33386, 48983, 13177 };




  
  static final int[] expdigs21 = new int[] { 0, 21264, 53708, 60962, 25043, 64008, 31200, 50906, 9831, 56185, 43877, 36378, 50952, 131 };




  
  static final int[] expdigs22 = new int[] { 0, 50020, 25440, 60247, 44814, 39961, 6865, 26068, 34832, 9081, 17478, 44928, 20825, 1 };




  
  static final int[] expdigs23 = new int[] { 0, 0, 52929, 10084, 25506, 6346, 61348, 31525, 52689, 61296, 27615, 15903, 40426, 863 };




  
  static final int[] expdigs24 = new int[] { 0, 16384, 24122, 53840, 43508, 13170, 51076, 37670, 58198, 31414, 57292, 61762, 41691, 8 };




  
  static final int[] expdigs25 = new int[] { 0, 0, 4096, 29077, 42481, 30581, 10617, 59493, 46251, 1892, 5557, 4505, 52391, 5659 };




  
  static final int[] expdigs26 = new int[] { 0, 0, 58368, 11431, 1080, 29797, 47947, 36639, 42405, 50481, 29546, 9875, 39190, 56 };




  
  static final int[] expdigs27 = new int[] { 0, 0, 0, 57600, 63028, 53094, 12749, 18174, 21993, 48265, 14922, 59933, 4030, 37092 };




  
  static final int[] expdigs28 = new int[] { 0, 0, 0, 576, 1941, 35265, 9302, 42780, 50682, 28007, 29640, 28124, 60333, 370 };




  
  static final int[] expdigs29 = new int[] { 0, 0, 0, 5904, 8539, 12149, 36793, 43681, 12958, 60573, 21267, 35015, 46478, 3 };




  
  static final int[] expdigs30 = new int[] { 0, 0, 0, 0, 7268, 50548, 47962, 3644, 22719, 26999, 41893, 7421, 56711, 2430 };



  
  static final int[] expdigs31 = new int[] { 0, 0, 0, 0, 7937, 49002, 60772, 28216, 38893, 55975, 63988, 59711, 20227, 24 };



  
  static final int[] expdigs32 = new int[] { 0, 0, 0, 16384, 38090, 63404, 55657, 8801, 62648, 13666, 57656, 60234, 15930 };



  
  static final int[] expdigs33 = new int[] { 0, 0, 0, 4096, 37081, 37989, 16940, 55138, 17665, 39458, 9751, 20263, 159 };



  
  static final int[] expdigs34 = new int[] { 0, 0, 0, 58368, 35104, 16108, 61773, 14313, 30323, 54789, 57113, 38868, 1 };



  
  static final int[] expdigs35 = new int[] { 0, 0, 0, 8448, 18701, 29652, 51080, 65023, 27172, 37903, 3192, 1044 };



  
  static final int[] expdigs36 = new int[] { 0, 0, 0, 37440, 63101, 2917, 39177, 50457, 25830, 50186, 28867, 10 };



  
  static final int[] expdigs37 = new int[] { 0, 0, 0, 56080, 45850, 37384, 3668, 12301, 38269, 18196, 6842 };



  
  static final int[] expdigs38 = new int[] { 0, 0, 0, 46436, 13565, 50181, 34770, 37478, 5625, 27707, 68 };



  
  static final int[] expdigs39 = new int[] { 0, 0, 0, 32577, 45355, 38512, 38358, 3651, 36101, 44841 };



  
  static final int[] expdigs40 = new int[] { 0, 0, 16384, 28506, 5696, 56746, 15456, 50499, 27230, 448 };



  
  static final int[] expdigs41 = new int[] { 0, 0, 4096, 285, 9232, 58239, 57170, 38515, 31729, 4 };



  
  static final int[] expdigs42 = new int[] { 0, 0, 58368, 41945, 57108, 12378, 28752, 48226, 2938 };



  
  static final int[] expdigs43 = new int[] { 0, 0, 24832, 47605, 49067, 23716, 61891, 25385, 29 };



  
  static final int[] expdigs44 = new int[] { 0, 0, 8768, 2442, 50298, 23174, 19624, 19259 };



  
  static final int[] expdigs45 = new int[] { 0, 0, 40720, 45899, 1813, 31689, 38862, 192 };



  
  static final int[] expdigs46 = new int[] { 0, 0, 36452, 14221, 34752, 48813, 60681, 1 };



  
  static final int[] expdigs47 = new int[] { 0, 0, 61313, 34220, 16731, 11629, 1262 };



  
  static final int[] expdigs48 = new int[] { 0, 16384, 60906, 18036, 40144, 40748, 12 };



  
  static final int[] expdigs49 = new int[] { 0, 4096, 609, 15909, 52830, 8271 };



  
  static final int[] expdigs50 = new int[] { 0, 58368, 3282, 56520, 47058, 82 };



  
  static final int[] expdigs51 = new int[] { 0, 41216, 52461, 7118, 54210 };



  
  static final int[] expdigs52 = new int[] { 0, 45632, 51642, 6624, 542 };



  
  static final int[] expdigs53 = new int[] { 0, 25360, 24109, 27591, 5 };



  
  static final int[] expdigs54 = new int[] { 0, 42852, 46771, 3552 };



  
  static final int[] expdigs55 = new int[] { 0, 28609, 34546, 35 };



  
  static final int[] expdigs56 = new int[] { 16384, 4218, 23283 };



  
  static final int[] expdigs57 = new int[] { 4096, 54437, 232 };



  
  static final int[] expdigs58 = new int[] { 58368, 21515, 2 };



  
  static final int[] expdigs59 = new int[] { 57600, 1525 };



  
  static final int[] expdigs60 = new int[] { 16960, 15 };



  
  static final int[] expdigs61 = new int[] { 10000 };



  
  static final int[] expdigs62 = new int[] { 100 };



  
  static final int[] expdigs63 = new int[] { 1 };



  
  static final int[] expdigs64 = new int[] { 36700, 62914, 23592, 49807, 10485, 36700, 62914, 23592, 49807, 10485, 36700, 62914, 23592, 655 };




  
  static final int[] expdigs65 = new int[] { 14784, 18979, 33659, 19503, 2726, 9542, 629, 2202, 40475, 10590, 4299, 47815, 36280, 6 };




  
  static final int[] expdigs66 = new int[] { 16332, 9978, 33613, 31138, 35584, 64252, 13857, 14424, 62281, 46279, 36150, 46573, 63392, 4294 };




  
  static final int[] expdigs67 = new int[] { 6716, 24348, 22618, 23904, 21327, 3919, 44703, 19149, 28803, 48959, 6259, 50273, 62237, 42 };




  
  static final int[] expdigs68 = new int[] { 8471, 23660, 38254, 26440, 33662, 38879, 9869, 11588, 41479, 23225, 60127, 24310, 32615, 28147 };




  
  static final int[] expdigs69 = new int[] { 13191, 6790, 63297, 30410, 12788, 42987, 23691, 28296, 32527, 38898, 41233, 4830, 31128, 281 };




  
  static final int[] expdigs70 = new int[] { 4064, 53152, 62236, 29139, 46658, 12881, 31694, 4870, 19986, 24637, 9587, 28884, 53395, 2 };




  
  static final int[] expdigs71 = new int[] { 26266, 10526, 16260, 55017, 35680, 40443, 19789, 17356, 30195, 55905, 28426, 63010, 44197, 1844 };




  
  static final int[] expdigs72 = new int[] { 38273, 7969, 37518, 26764, 23294, 63974, 18547, 17868, 24550, 41191, 17323, 53714, 29277, 18 };




  
  static final int[] expdigs73 = new int[] { 16739, 37738, 38090, 26589, 43521, 1543, 15713, 10671, 11975, 41533, 18106, 9348, 16921, 12089 };




  
  static final int[] expdigs74 = new int[] { 14585, 61981, 58707, 16649, 25994, 39992, 28337, 17801, 37475, 22697, 31638, 16477, 58496, 120 };




  
  static final int[] expdigs75 = new int[] { 58472, 2585, 40564, 27691, 44824, 27269, 58610, 54572, 35108, 30373, 35050, 10650, 13692, 1 };




  
  static final int[] expdigs76 = new int[] { 50392, 58911, 41968, 49557, 29112, 29939, 43526, 63500, 55595, 27220, 25207, 38361, 18456, 792 };




  
  static final int[] expdigs77 = new int[] { 26062, 32046, 3696, 45060, 46821, 40931, 50242, 60272, 24148, 20588, 6150, 44948, 60477, 7 };




  
  static final int[] expdigs78 = new int[] { 12430, 30407, 320, 41980, 58777, 41755, 41041, 13609, 45167, 13348, 40838, 60354, 19454, 5192 };




  
  static final int[] expdigs79 = new int[] { 30926, 26518, 13110, 43018, 54982, 48258, 24658, 15209, 63366, 11929, 20069, 43857, 60487, 51 };




  
  static final int[] expdigs80 = new int[] { 51263, 54048, 48761, 48627, 30576, 49046, 4414, 61195, 61755, 48474, 19124, 55906, 15511, 34028 };




  
  static final int[] expdigs81 = new int[] { 39834, 11681, 47018, 3107, 64531, 54229, 41331, 41899, 51735, 42427, 59173, 13010, 18505, 340 };




  
  static final int[] expdigs82 = new int[] { 27268, 6670, 31272, 9861, 45865, 10372, 12865, 62678, 23454, 35158, 20252, 29621, 26399, 3 };




  
  static final int[] expdigs83 = new int[] { 57738, 46147, 66, 48154, 11239, 21430, 55809, 46003, 15044, 25138, 52780, 48043, 4883, 2230 };




  
  static final int[] expdigs84 = new int[] { 20893, 62065, 64225, 52254, 59094, 55919, 60195, 5702, 48647, 50058, 7736, 41768, 19709, 22 };




  
  static final int[] expdigs85 = new int[] { 37714, 32321, 45840, 36031, 33290, 47121, 5146, 28127, 9887, 25390, 52929, 2698, 1073, 14615 };




  
  static final int[] expdigs86 = new int[] { 35111, 8187, 18153, 56721, 40309, 59453, 51824, 4868, 45974, 3530, 43783, 8546, 9841, 146 };




  
  static final int[] expdigs87 = new int[] { 23288, 61030, 42779, 19572, 29894, 47780, 45082, 32816, 43713, 33458, 25341, 63655, 30244, 1 };




  
  static final int[] expdigs88 = new int[] { 58138, 33000, 62869, 37127, 61799, 298, 46353, 5693, 63898, 62040, 989, 23191, 53065, 957 };




  
  static final int[] expdigs89 = new int[] { 42524, 32442, 36673, 15444, 22900, 658, 61412, 32824, 21610, 64190, 1975, 11373, 37886, 9 };




  
  static final int[] expdigs90 = new int[] { 26492, 4357, 32437, 10852, 34233, 53968, 55056, 34692, 64553, 38226, 41929, 21646, 6667, 6277 };




  
  static final int[] expdigs91 = new int[] { 61213, 698, 16053, 50571, 2963, 50347, 13657, 48188, 46520, 19387, 33187, 25775, 50529, 62 };




  
  static final int[] expdigs92 = new int[] { 42864, 54351, 45226, 20476, 23443, 17724, 3780, 44701, 52910, 23402, 28374, 46862, 40234, 41137 };




  
  static final int[] expdigs93 = new int[] { 23366, 62147, 58123, 44113, 55284, 39498, 3314, 9622, 9704, 27759, 25187, 43722, 24650, 411 };




  
  static final int[] expdigs94 = new int[] { 38899, 44530, 19586, 37141, 1863, 9570, 32801, 31553, 51870, 62536, 51369, 30583, 7455, 4 };




  
  static final int[] expdigs95 = new int[] { 10421, 4321, 43699, 3472, 65252, 17057, 13858, 29819, 14733, 21490, 40602, 31315, 65186, 2695 };




  
  static final int[] expdigs96 = new int[] { 6002, 54438, 29272, 34113, 17036, 25074, 36183, 953, 25051, 12011, 20722, 4245, 62911, 26 };




  
  static final int[] expdigs97 = new int[] { 14718, 45935, 8408, 42891, 21312, 56531, 44159, 45581, 20325, 36295, 35509, 24455, 30844, 17668 };




  
  static final int[] expdigs98 = new int[] { 54542, 45023, 23021, 3050, 31015, 20881, 50904, 40432, 33626, 14125, 44264, 60537, 44872, 176 };




  
  static final int[] expdigs99 = new int[] { 60183, 8969, 14648, 17725, 11451, 50016, 34587, 46279, 19341, 42084, 16826, 5848, 50256, 1 };




  
  static final int[] expdigs100 = new int[] { 64999, 53685, 60382, 19151, 25736, 5357, 31302, 23283, 14225, 52622, 56781, 39489, 60351, 1157 };




  
  static final int[] expdigs101 = new int[] { 1305, 4469, 39270, 18541, 63827, 59035, 54707, 16616, 32910, 48367, 64137, 2360, 37959, 11 };




  
  static final int[] expdigs102 = new int[] { 45449, 32125, 19705, 56098, 51958, 5225, 18285, 13654, 9341, 25888, 50946, 26855, 36068, 7588 };




  
  static final int[] expdigs103 = new int[] { 27324, 53405, 43450, 25464, 3796, 3329, 46058, 53220, 26307, 53998, 33932, 23861, 58032, 75 };




  
  static final int[] expdigs104 = new int[] { 63080, 50735, 1844, 21406, 57926, 63607, 24936, 52889, 23469, 64488, 539, 8859, 21210, 49732 };




  
  static final int[] expdigs105 = new int[] { 62890, 39828, 3950, 32982, 39245, 21607, 40226, 50991, 18584, 10475, 59643, 40720, 21183, 497 };




  
  static final int[] expdigs106 = new int[] { 37329, 64623, 11835, 985, 46923, 48712, 28582, 21481, 28366, 41392, 13703, 49559, 63781, 4 };




  
  static final int[] expdigs107 = new int[] { 3316, 60011, 41933, 47959, 54404, 39790, 12283, 941, 46090, 42226, 18108, 38803, 16879, 3259 };




  
  static final int[] expdigs108 = new int[] { 46563, 56305, 5006, 45044, 49040, 12849, 778, 6563, 46336, 3043, 7390, 2354, 38835, 32 };




  
  static final int[] expdigs109 = new int[] { 28653, 3742, 33331, 2671, 39772, 29981, 56489, 1973, 26280, 26022, 56391, 56434, 57039, 21359 };




  
  static final int[] expdigs110 = new int[] { 9461, 17732, 7542, 26241, 8917, 24548, 61513, 13126, 59245, 41547, 1874, 41852, 39236, 213 };




  
  static final int[] expdigs111 = new int[] { 36794, 22459, 63645, 14024, 42032, 53329, 25518, 11272, 18287, 20076, 62933, 3039, 8912, 2 };




  
  static final int[] expdigs112 = new int[] { 14926, 15441, 32337, 42579, 26354, 35154, 22815, 36955, 12564, 8047, 856, 41917, 55080, 1399 };




  
  static final int[] expdigs113 = new int[] { 8668, 50617, 10153, 17465, 1574, 28532, 15301, 58041, 38791, 60373, 663, 29255, 65431, 13 };




  
  static final int[] expdigs114 = new int[] { 21589, 32199, 24754, 45321, 9349, 26230, 35019, 37508, 20896, 42986, 31405, 12458, 65173, 9173 };




  
  static final int[] expdigs115 = new int[] { 46746, 1632, 61196, 50915, 64318, 41549, 2971, 23968, 59191, 58756, 61917, 779, 48493, 91 };




  
  static final int[] expdigs116 = new int[] { 1609, 63382, 15744, 15685, 51627, 56348, 33838, 52458, 44148, 11077, 56293, 41906, 45227, 60122 };




  
  static final int[] expdigs117 = new int[] { 19676, 45198, 6055, 38823, 8380, 49060, 17377, 58196, 43039, 21737, 59545, 12870, 14870, 601 };




  
  static final int[] expdigs118 = new int[] { 4128, 2418, 28241, 13495, 26298, 3767, 31631, 5169, 8950, 27087, 56956, 4060, 804, 6 };




  
  static final int[] expdigs119 = new int[] { 39930, 40673, 19029, 54677, 38145, 23200, 41325, 24564, 24955, 54484, 23863, 52998, 13147, 3940 };




  
  static final int[] expdigs120 = new int[] { 3676, 24655, 34924, 27416, 23974, 887, 10899, 4833, 21221, 28725, 19899, 57546, 26345, 39 };




  
  static final int[] expdigs121 = new int[] { 28904, 41324, 18596, 42292, 12070, 52013, 30810, 61057, 55753, 32324, 38953, 6752, 32688, 25822 };




  
  static final int[] expdigs122 = new int[] { 42232, 26627, 2807, 27948, 50583, 49016, 32420, 64180, 3178, 3600, 21361, 52496, 14744, 258 };




  
  static final int[] expdigs123 = new int[] { 2388, 59904, 28863, 7488, 31963, 8354, 47510, 15059, 2653, 58363, 31670, 21496, 38158, 2 };




  
  static final int[] expdigs124 = new int[] { 50070, 5266, 26158, 10774, 15148, 6873, 30230, 33898, 63720, 51799, 4515, 50124, 19875, 1692 };




  
  static final int[] expdigs125 = new int[] { 54240, 3984, 12058, 2729, 13914, 11865, 38313, 39660, 10467, 20834, 36745, 57517, 60491, 16 };




  
  static final int[] expdigs126 = new int[] { 5387, 58214, 9214, 13883, 14445, 34873, 21745, 13490, 23334, 25008, 58535, 19372, 44484, 11090 };




  
  static final int[] expdigs127 = new int[] { 27578, 64807, 12543, 794, 13907, 61297, 12013, 64360, 15961, 20566, 24178, 15922, 59427, 110 };




  
  static final int[] expdigs128 = new int[] { 49427, 41935, 46000, 59645, 45358, 51075, 15848, 32756, 38170, 14623, 35631, 57175, 7147, 1 };




  
  static final int[] expdigs129 = new int[] { 33941, 39160, 55469, 45679, 22878, 60091, 37210, 18508, 1638, 57398, 65026, 41643, 54966, 726 };




  
  static final int[] expdigs130 = new int[] { 60632, 24639, 41842, 62060, 20544, 59583, 52800, 1495, 48513, 43827, 10480, 1727, 17589, 7 };




  
  static final int[] expdigs131 = new int[] { 5590, 60244, 53985, 26632, 53049, 33628, 58267, 54922, 21641, 62744, 58109, 2070, 26887, 4763 };




  
  static final int[] expdigs132 = new int[] { 62970, 37957, 34618, 29757, 24123, 2302, 17622, 58876, 44780, 6525, 33349, 36065, 41556, 47 };




  
  static final int[] expdigs133 = new int[] { 1615, 24878, 20040, 11487, 23235, 27766, 59005, 57847, 60881, 11588, 63635, 61281, 31817, 31217 };




  
  static final int[] expdigs134 = new int[] { 14434, 2870, 65081, 44023, 40864, 40254, 47120, 6476, 32066, 23053, 17020, 19618, 11459, 312 };




  
  static final int[] expdigs135 = new int[] { 43398, 40005, 36695, 8304, 12205, 16131, 42414, 38075, 63890, 2851, 61774, 59833, 7978, 3 };




  
  static final int[] expdigs136 = new int[] { 56426, 22060, 15473, 31824, 19088, 38788, 64386, 12875, 35770, 65519, 11824, 19623, 56959, 2045 };




  
  static final int[] expdigs137 = new int[] { 16292, 32333, 10640, 47504, 29026, 30534, 23581, 6682, 10188, 24248, 44027, 51969, 30060, 20 };




  
  static final int[] expdigs138 = new int[] { 29432, 37518, 55373, 2727, 33243, 22572, 16689, 35625, 34145, 15830, 59880, 32552, 52948, 13407 };




  
  static final int[] expdigs139 = new int[] { 61898, 27244, 41841, 33450, 18682, 13988, 24415, 11497, 1652, 34237, 34677, 325, 5117, 134 };




  
  static final int[] expdigs140 = new int[] { 16347, 3549, 48915, 22616, 21158, 51913, 32356, 21086, 3293, 8862, 1002, 26873, 22333, 1 };




  
  static final int[] expdigs141 = new int[] { 25966, 63733, 28215, 31946, 40858, 58538, 11004, 6877, 6109, 3965, 35478, 37365, 45488, 878 };




  
  static final int[] expdigs142 = new int[] { 45479, 34060, 17321, 19980, 1719, 16314, 29601, 8588, 58388, 22321, 14117, 63288, 51572, 8 };




  
  static final int[] expdigs143 = new int[] { 46861, 47640, 11481, 23766, 46730, 53756, 8682, 60589, 42028, 27453, 29714, 31598, 39954, 5758 };




  
  static final int[] expdigs144 = new int[] { 29304, 58803, 51232, 27762, 60760, 17576, 19092, 26820, 11561, 48771, 6850, 27841, 38410, 57 };




  
  static final int[] expdigs145 = new int[] { 2916, 49445, 34666, 46387, 18627, 58279, 60468, 190, 3545, 51889, 51605, 47909, 40910, 37739 };




  
  static final int[] expdigs146 = new int[] { 19034, 62098, 15419, 33887, 38852, 53011, 28129, 37357, 11176, 48360, 9035, 9654, 25968, 377 };




  
  static final int[] expdigs147 = new int[] { 25094, 10451, 7363, 55389, 57404, 27399, 11422, 39695, 28947, 12935, 61694, 26310, 50722, 3 };




  
  static final int[][] expdigstable = new int[][] { expdigs0, expdigs1, expdigs2, expdigs3, expdigs4, expdigs5, expdigs6, expdigs7, expdigs8, expdigs9, expdigs10, expdigs11, expdigs12, expdigs13, expdigs14, expdigs15, expdigs16, expdigs17, expdigs18, expdigs19, expdigs20, expdigs21, expdigs22, expdigs23, expdigs24, expdigs25, expdigs26, expdigs27, expdigs28, expdigs29, expdigs30, expdigs31, expdigs32, expdigs33, expdigs34, expdigs35, expdigs36, expdigs37, expdigs38, expdigs39, expdigs40, expdigs41, expdigs42, expdigs43, expdigs44, expdigs45, expdigs46, expdigs47, expdigs48, expdigs49, expdigs50, expdigs51, expdigs52, expdigs53, expdigs54, expdigs55, expdigs56, expdigs57, expdigs58, expdigs59, expdigs60, expdigs61, expdigs62, expdigs63, expdigs64, expdigs65, expdigs66, expdigs67, expdigs68, expdigs69, expdigs70, expdigs71, expdigs72, expdigs73, expdigs74, expdigs75, expdigs76, expdigs77, expdigs78, expdigs79, expdigs80, expdigs81, expdigs82, expdigs83, expdigs84, expdigs85, expdigs86, expdigs87, expdigs88, expdigs89, expdigs90, expdigs91, expdigs92, expdigs93, expdigs94, expdigs95, expdigs96, expdigs97, expdigs98, expdigs99, expdigs100, expdigs101, expdigs102, expdigs103, expdigs104, expdigs105, expdigs106, expdigs107, expdigs108, expdigs109, expdigs110, expdigs111, expdigs112, expdigs113, expdigs114, expdigs115, expdigs116, expdigs117, expdigs118, expdigs119, expdigs120, expdigs121, expdigs122, expdigs123, expdigs124, expdigs125, expdigs126, expdigs127, expdigs128, expdigs129, expdigs130, expdigs131, expdigs132, expdigs133, expdigs134, expdigs135, expdigs136, expdigs137, expdigs138, expdigs139, expdigs140, expdigs141, expdigs142, expdigs143, expdigs144, expdigs145, expdigs146, expdigs147 };



























  
  static final int[] nexpdigstable = new int[] { 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 13, 13, 13, 12, 12, 11, 11, 10, 10, 10, 9, 9, 8, 8, 8, 7, 7, 6, 6, 5, 5, 5, 4, 4, 3, 3, 3, 2, 2, 1, 1, 1, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14 };










  
  static final int[] binexpstable = new int[] { 90, 89, 89, 88, 88, 88, 87, 87, 86, 86, 86, 85, 85, 84, 84, 83, 83, 83, 82, 82, 81, 81, 81, 80, 80, 79, 79, 78, 78, 78, 77, 77, 76, 76, 76, 75, 75, 74, 74, 73, 73, 73, 72, 72, 71, 71, 71, 70, 70, 69, 69, 68, 68, 68, 67, 67, 66, 66, 66, 65, 65, 64, 64, 64, 63, 63, 62, 62, 61, 61, 61, 60, 60, 59, 59, 59, 58, 58, 57, 57, 56, 56, 56, 55, 55, 54, 54, 54, 53, 53, 52, 52, 51, 51, 51, 50, 50, 49, 49, 49, 48, 48, 47, 47, 46, 46, 46, 45, 45, 44, 44, 44, 43, 43, 42, 42, 41, 41, 41, 40, 40, 39, 39, 39, 38, 38, 37, 37, 37, 36, 36, 35, 35, 34, 34, 34, 33, 33, 32, 32, 32, 31, 31, 30, 30, 29, 29, 29 };














  
  void throwOverflow() throws SQLException {
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 26);
    sQLException.fillInStackTrace();
    throw sQLException;
  }




  
  long updateChecksum(long paramLong, int paramInt) throws SQLException {
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
      
      paramLong = CRC64.updateChecksum(paramLong, NULL_DATA_BYTES, 0, NULL_DATA_BYTES.length);
    
    }
    else {

      
      short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
      int i = this.columnIndex + this.byteLength * paramInt;
      
      paramLong = CRC64.updateChecksum(paramLong, this.rowSpaceByte, i + 1, s);
    } 



    
    return paramLong;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
