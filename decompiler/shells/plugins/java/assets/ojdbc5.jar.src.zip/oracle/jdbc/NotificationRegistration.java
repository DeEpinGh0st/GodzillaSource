package oracle.jdbc;

import java.util.Properties;































public interface NotificationRegistration
{
  Properties getRegistrationOptions();
  
  String getDatabaseName();
  
  String getUserName();
  
  RegistrationState getState();
  
  public enum RegistrationState
  {
    ACTIVE,


    
    CLOSED;
  }
}
