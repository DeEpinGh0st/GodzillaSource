package oracle.jdbc.rowset;

import java.io.InputStream;
import java.io.Reader;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.StringTokenizer;
import javax.sql.RowSet;
import javax.sql.RowSetInternal;
import javax.sql.RowSetWriter;
import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;








































public class OracleCachedRowSetWriter
  implements RowSetWriter, Serializable
{
  static final long serialVersionUID = 8932894189919931169L;
  private StringBuffer updateClause = new StringBuffer("");




  
  private StringBuffer deleteClause = new StringBuffer("");




  
  private StringBuffer insertClause = new StringBuffer("");



  
  private PreparedStatement insertStmt;



  
  private PreparedStatement updateStmt;



  
  private PreparedStatement deleteStmt;



  
  private ResultSetMetaData rsmd;



  
  private transient Connection connection;



  
  private int columnCount;



  
  static final int ASCII_STREAM = 1;



  
  static final int BINARY_STREAM = 2;



  
  static final int CHARACTER_STREAM = 3;



  
  static final int NCHARACTER_STREAM = 4;




  
  private String getSchemaName(RowSet paramRowSet) throws SQLException {
    return paramRowSet.getUsername();
  }





  
  private String getTableName(RowSet paramRowSet) throws SQLException {
    String str1 = ((OracleCachedRowSet)paramRowSet).getTableName();
    if (str1 != null) {
      return str1;
    }
    String str2 = paramRowSet.getCommand().toUpperCase();


    
    int i = str2.indexOf(" FROM ");


    
    if (i == -1) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 343, (str2.length() != 0) ? str2 : "Please use RowSet.setCommand (String) to set the SQL query string.");
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    String str3 = str2.substring(i + 6).trim();


    
    StringTokenizer stringTokenizer = new StringTokenizer(str3);
    if (stringTokenizer.hasMoreTokens()) {
      str3 = stringTokenizer.nextToken();
    }
    return str3;
  }








  
  private void initSQLStatement(RowSet paramRowSet) throws SQLException {
    this.insertClause = new StringBuffer("INSERT INTO " + getTableName(paramRowSet) + "(");
    this.updateClause = new StringBuffer("UPDATE " + getTableName(paramRowSet) + " SET ");
    this.deleteClause = new StringBuffer("DELETE FROM " + getTableName(paramRowSet) + " WHERE ");

    
    this.rsmd = paramRowSet.getMetaData();
    this.columnCount = this.rsmd.getColumnCount();
    
    byte b;
    
    for (b = 0; b < this.columnCount; b++) {
      
      if (b != 0) this.insertClause.append(", "); 
      this.insertClause.append(this.rsmd.getColumnName(b + 1));
      
      if (b != 0) this.updateClause.append(", "); 
      this.updateClause.append(this.rsmd.getColumnName(b + 1) + " = :" + b);
      
      if (b != 0) this.deleteClause.append(" AND "); 
      this.deleteClause.append(this.rsmd.getColumnName(b + 1) + " = :" + b);
    } 
    this.insertClause.append(") VALUES (");
    this.updateClause.append(" WHERE ");
    
    for (b = 0; b < this.columnCount; b++) {
      
      if (b != 0) this.insertClause.append(", "); 
      this.insertClause.append(":" + b);
      
      if (b != 0) this.updateClause.append(" AND "); 
      this.updateClause.append(this.rsmd.getColumnName(b + 1) + " = :" + b);
    } 
    this.insertClause.append(")");
    
    this.insertStmt = this.connection.prepareStatement(this.insertClause.substring(0, this.insertClause.length()));
    
    this.updateStmt = this.connection.prepareStatement(this.updateClause.substring(0, this.updateClause.length()));
    
    this.deleteStmt = this.connection.prepareStatement(this.deleteClause.substring(0, this.deleteClause.length()));
  }












  
  private boolean insertRow(OracleRow paramOracleRow) throws SQLException {
    this.insertStmt.clearParameters();
    for (byte b = 1; b <= this.columnCount; b++) {
      
      Object object = null;
      object = paramOracleRow.isColumnChanged(b) ? paramOracleRow.getModifiedColumn(b) : paramOracleRow.getColumn(b);



      
      if (object == null) {
        this.insertStmt.setNull(b, this.rsmd.getColumnType(b));
        paramOracleRow.markOriginalNull(b, true);
      } else {
        this.insertStmt.setObject(b, object);
      } 
    } 
    return (this.insertStmt.executeUpdate() == 1);
  }








  
  private boolean updateRow(RowSet paramRowSet, OracleRow paramOracleRow) throws SQLException {
    this.updateStmt.clearParameters(); byte b;
    for (b = 1; b <= this.columnCount; b++) {
      
      Object object = null;
      object = paramOracleRow.isColumnChanged(b) ? paramOracleRow.getModifiedColumn(b) : paramOracleRow.getColumn(b);



      
      if (object == null) {
        this.updateStmt.setNull(b, this.rsmd.getColumnType(b));
      
      }
      else if (object instanceof Reader) {
        
        OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)this.updateStmt;
        if (paramOracleRow.columnTypeInfo[b - 1][1] == 4) {
          oraclePreparedStatement.setFormOfUse(b, (short)2);
        } else if (paramOracleRow.columnTypeInfo[b - 1][1] == 3) {
          oraclePreparedStatement.setFormOfUse(b, (short)1);
        } 
        this.updateStmt.setCharacterStream(b, (Reader)object, paramOracleRow.columnTypeInfo[b - 1][0]);

      
      }
      else if (object instanceof InputStream) {
        
        if (paramOracleRow.columnTypeInfo[b - 1][1] == 2) {
          this.updateStmt.setBinaryStream(b, (InputStream)object, paramOracleRow.columnTypeInfo[b - 1][0]);
        
        }
        else if (paramOracleRow.columnTypeInfo[b - 1][1] == 1) {
          this.updateStmt.setAsciiStream(b, (InputStream)object, paramOracleRow.columnTypeInfo[b - 1][0]);
        }
      
      } else {
        
        this.updateStmt.setObject(b, object);
      } 
    } 
    for (b = 1; b <= this.columnCount; b++) {
      
      if (paramOracleRow.isOriginalNull(b)) {
        return updateRowWithNull(paramRowSet, paramOracleRow);
      }
      this.updateStmt.setObject(b + this.columnCount, paramOracleRow.getColumn(b));
    } 
    
    return (this.updateStmt.executeUpdate() == 1);
  }





  
  private boolean updateRowWithNull(RowSet paramRowSet, OracleRow paramOracleRow) throws SQLException {
    boolean bool = false;
    StringBuffer stringBuffer = new StringBuffer("UPDATE " + getTableName(paramRowSet) + " SET ");
    
    byte b;
    for (b = 1; b <= this.columnCount; b++) {
      
      if (b != 1) {
        stringBuffer.append(", ");
      }
      stringBuffer.append(this.rsmd.getColumnName(b) + " = :" + b);
    } 
    
    stringBuffer.append(" WHERE ");
    
    for (b = 1; b <= this.columnCount; b++) {
      
      if (b != 1)
        stringBuffer.append(" AND "); 
      if (paramOracleRow.isOriginalNull(b)) {
        stringBuffer.append(this.rsmd.getColumnName(b) + " IS NULL ");
      } else {
        stringBuffer.append(this.rsmd.getColumnName(b) + " = :" + b);
      } 
    } 
    PreparedStatement preparedStatement = null;
    
    try {
      preparedStatement = this.connection.prepareStatement(stringBuffer.substring(0, stringBuffer.length()));
      
      byte b1;
      for (b1 = 1; b1 <= this.columnCount; b1++) {
        
        Object object = null;
        object = paramOracleRow.isColumnChanged(b1) ? paramOracleRow.getModifiedColumn(b1) : paramOracleRow.getColumn(b1);



        
        if (object == null) {
          preparedStatement.setNull(b1, this.rsmd.getColumnType(b1));
        
        }
        else if (object instanceof Reader) {
          
          OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)preparedStatement;
          if (paramOracleRow.columnTypeInfo[b1 - 1][1] == 4) {
            oraclePreparedStatement.setFormOfUse(b1, (short)2);
          } else if (paramOracleRow.columnTypeInfo[b1 - 1][1] == 3) {
            oraclePreparedStatement.setFormOfUse(b1, (short)1);
          } 
          preparedStatement.setCharacterStream(b1, (Reader)object, paramOracleRow.columnTypeInfo[b1 - 1][0]);

        
        }
        else if (object instanceof InputStream) {
          
          if (paramOracleRow.columnTypeInfo[b1 - 1][1] == 2) {
            preparedStatement.setBinaryStream(b1, (InputStream)object, paramOracleRow.columnTypeInfo[b1 - 1][0]);
          
          }
          else if (paramOracleRow.columnTypeInfo[b1 - 1][1] == 1) {
            preparedStatement.setAsciiStream(b1, (InputStream)object, paramOracleRow.columnTypeInfo[b1 - 1][0]);
          }
        
        } else {
          
          preparedStatement.setObject(b1, object);
        } 
      } 
      byte b2;
      for (b1 = 1, b2 = 1; b1 <= this.columnCount; b1++) {
        
        if (!paramOracleRow.isOriginalNull(b1)) {

          
          preparedStatement.setObject(b2 + this.columnCount, paramOracleRow.getColumn(b1));
          
          b2++;
        } 
      }  bool = (preparedStatement.executeUpdate() == 1) ? true : false;
    } finally {
      
      if (preparedStatement != null) {
        preparedStatement.close();
      }
    } 
    return bool;
  }









  
  private boolean deleteRow(RowSet paramRowSet, OracleRow paramOracleRow) throws SQLException {
    this.deleteStmt.clearParameters();
    for (byte b = 1; b <= this.columnCount; b++) {
      
      if (paramOracleRow.isOriginalNull(b)) {
        return deleteRowWithNull(paramRowSet, paramOracleRow);
      }
      Object object = paramOracleRow.getColumn(b);
      if (object == null) {
        this.deleteStmt.setNull(b, this.rsmd.getColumnType(b));
      } else {
        this.deleteStmt.setObject(b, object);
      } 
    } 
    return (this.deleteStmt.executeUpdate() == 1);
  }






  
  private boolean deleteRowWithNull(RowSet paramRowSet, OracleRow paramOracleRow) throws SQLException {
    boolean bool = false;
    StringBuffer stringBuffer = new StringBuffer("DELETE FROM " + getTableName(paramRowSet) + " WHERE ");

    
    for (byte b = 1; b <= this.columnCount; b++) {
      
      if (b != 1)
        stringBuffer.append(" AND "); 
      if (paramOracleRow.isOriginalNull(b)) {
        stringBuffer.append(this.rsmd.getColumnName(b) + " IS NULL ");
      } else {
        stringBuffer.append(this.rsmd.getColumnName(b) + " = :" + b);
      } 
    } 
    PreparedStatement preparedStatement = null;
    
    try {
      preparedStatement = this.connection.prepareStatement(stringBuffer.substring(0, stringBuffer.length()));


      
      for (byte b1 = 1, b2 = 1; b1 <= this.columnCount; b1++) {
        
        if (!paramOracleRow.isOriginalNull(b1))
        {
          
          preparedStatement.setObject(b2++, paramOracleRow.getColumn(b1)); } 
      } 
      bool = (preparedStatement.executeUpdate() == 1) ? true : false;
    } finally {
      
      if (preparedStatement != null) {
        preparedStatement.close();
      }
    } 
    return bool;
  }





  
  public synchronized boolean writeData(RowSetInternal paramRowSetInternal) throws SQLException {
    OracleCachedRowSet oracleCachedRowSet = (OracleCachedRowSet)paramRowSetInternal;
    this.connection = ((OracleCachedRowSetReader)oracleCachedRowSet.getReader()).getConnection(paramRowSetInternal);



    
    if (this.connection == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 342);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (this.connection.getAutoCommit()) {
      this.connection.setAutoCommit(false);
    }
    
    try {
      this.connection.setTransactionIsolation(oracleCachedRowSet.getTransactionIsolation());
    }
    catch (Exception exception) {}



    
    initSQLStatement(oracleCachedRowSet);
    if (this.columnCount < 1) {
      
      this.connection.close();
      return true;
    } 
    boolean bool = oracleCachedRowSet.getShowDeleted();
    oracleCachedRowSet.setShowDeleted(true);
    oracleCachedRowSet.beforeFirst();
    boolean bool1 = true;
    boolean bool2 = true;
    boolean bool3 = true;
    OracleRow oracleRow = null;
    while (oracleCachedRowSet.next()) {
      
      if (oracleCachedRowSet.rowInserted()) {

        
        if (oracleCachedRowSet.rowDeleted())
          continue; 
        oracleRow = oracleCachedRowSet.getCurrentRow();
        
        bool2 = (insertRow(oracleRow) || bool2) ? true : false; continue;
      } 
      if (oracleCachedRowSet.rowUpdated()) {
        
        oracleRow = oracleCachedRowSet.getCurrentRow();
        
        bool1 = (updateRow(oracleCachedRowSet, oracleRow) || bool1) ? true : false; continue;
      } 
      if (oracleCachedRowSet.rowDeleted()) {
        
        oracleRow = oracleCachedRowSet.getCurrentRow();
        
        bool3 = (deleteRow(oracleCachedRowSet, oracleRow) || bool3) ? true : false;
      } 
    } 



    
    if (bool1 && bool2 && bool3) {

      
      this.connection.commit();
      
      oracleCachedRowSet.setOriginal();
    } else {
      
      this.connection.rollback();
    } 
    this.insertStmt.close();
    this.updateStmt.close();
    this.deleteStmt.close();


    
    if (!oracleCachedRowSet.isConnectionStayingOpen())
    {
      this.connection.close();
    }
    
    oracleCachedRowSet.setShowDeleted(bool);
    return true;
  }











  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return null;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
