package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.jdbc.internal.OracleStatement;
















class AutoKeyInfo
  extends OracleResultSetMetaData
{
  String originalSql;
  String newSql;
  String tableName;
  OracleStatement.SqlKind sqlKind = OracleStatement.SqlKind.UNINITIALIZED;
  
  int sqlParserParamCount;
  
  String[] sqlParserParamList;
  
  boolean useNamedParameter;
  
  int current_argument;
  
  String[] columnNames;
  
  int[] columnIndexes;
  
  int numColumns;
  
  String[] tableColumnNames;
  
  int[] tableColumnTypes;
  
  int[] tableMaxLengths;
  
  boolean[] tableNullables;
  short[] tableFormOfUses;
  int[] tablePrecisions;
  int[] tableScales;
  String[] tableTypeNames;
  int autoKeyType;
  static final int KEYFLAG = 0;
  static final int COLUMNAME = 1;
  static final int COLUMNINDEX = 2;
  static final char QMARK = '?';
  int[] returnTypes;
  Accessor[] returnAccessors;
  
  AutoKeyInfo(String paramString) {
    this.originalSql = paramString;
    this.autoKeyType = 0;
  }



  
  AutoKeyInfo(String paramString, String[] paramArrayOfString) {
    this.originalSql = paramString;
    this.columnNames = paramArrayOfString;
    this.autoKeyType = 1;
  }



  
  AutoKeyInfo(String paramString, int[] paramArrayOfint) {
    this.originalSql = paramString;
    this.columnIndexes = paramArrayOfint;
    this.autoKeyType = 2;
  }

  
  private void parseSql() throws SQLException {
    if (this.originalSql == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    OracleSql oracleSql = SQL_PARSER.get();
    oracleSql.initialize(this.originalSql);












    
    this.sqlKind = oracleSql.getSqlKind();

    
    if (this.sqlKind == OracleStatement.SqlKind.INSERT) {
      
      this.sqlParserParamCount = oracleSql.getParameterCount();
      this.sqlParserParamList = oracleSql.getParameterList();
      
      if (this.sqlParserParamList == OracleSql.EMPTY_LIST) {
        this.useNamedParameter = false;
      } else {
        
        this.useNamedParameter = true;
        
        this.current_argument = this.sqlParserParamCount;
      } 
    } 
  }



  
  private String generateUniqueNamedParameter() {
    boolean bool;
    String str;
    do {
      bool = false;
      str = Integer.toString(++this.current_argument).intern();
      
      for (byte b = 0; b < this.sqlParserParamCount; b++) {
        
        if (this.sqlParserParamList[b] == str) {
          
          bool = true;
          break;
        } 
      } 
    } while (bool);
    
    return ":" + str;
  }







  
  String getNewSql() throws SQLException {
    try {
      if (this.newSql != null) return this.newSql;
      
      if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) parseSql();
      
      switch (this.autoKeyType) {
        
        case 0:
          this.newSql = this.originalSql + " RETURNING ROWID INTO " + (this.useNamedParameter ? generateUniqueNamedParameter() : (String)Character.valueOf('?'));
          
          this.returnTypes = new int[1];
          this.returnTypes[0] = 104;
          break;
        case 1:
          getNewSqlByColumnName();
          break;
        case 2:
          getNewSqlByColumnIndexes();
          break;
      } 

      
      this.sqlKind = OracleStatement.SqlKind.UNINITIALIZED;
      this.sqlParserParamList = null;
      return this.newSql;
    }
    catch (Exception exception) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), exception);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
  }



  
  private String getNewSqlByColumnName() throws SQLException {
    this.returnTypes = new int[this.columnNames.length];

    
    this.columnIndexes = new int[this.columnNames.length];
    
    StringBuffer stringBuffer = new StringBuffer(this.originalSql);
    stringBuffer.append(" RETURNING ");
    
    byte b;
    for (b = 0; b < this.columnNames.length; b++) {
      
      int i = getReturnParamTypeCode(b, this.columnNames[b], this.columnIndexes);
      this.returnTypes[b] = i;
      
      stringBuffer.append(this.columnNames[b]);
      
      if (b < this.columnNames.length - 1) stringBuffer.append(", ");
    
    } 
    stringBuffer.append(" INTO ");
    
    for (b = 0; b < this.columnNames.length - 1; b++)
    {
      stringBuffer.append((this.useNamedParameter ? generateUniqueNamedParameter() : (String)Character.valueOf('?')) + ", ");
    }
    
    stringBuffer.append(this.useNamedParameter ? generateUniqueNamedParameter() : Character.valueOf('?'));
    
    this.newSql = new String(stringBuffer);
    return this.newSql;
  }

  
  private String getNewSqlByColumnIndexes() throws SQLException {
    this.returnTypes = new int[this.columnIndexes.length];
    
    StringBuffer stringBuffer = new StringBuffer(this.originalSql);
    stringBuffer.append(" RETURNING ");

    
    byte b;
    
    for (b = 0; b < this.columnIndexes.length; b++) {
      
      int j = this.columnIndexes[b] - 1;
      if (j < 0 || j > this.tableColumnNames.length) {

        
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
        sQLException.fillInStackTrace();
        throw sQLException;
      } 

      
      int i = this.tableColumnTypes[j];
      String str = this.tableColumnNames[j];
      this.returnTypes[b] = i;
      
      stringBuffer.append(str);
      
      if (b < this.columnIndexes.length - 1) stringBuffer.append(", ");
    
    } 
    stringBuffer.append(" INTO ");
    
    for (b = 0; b < this.columnIndexes.length - 1; b++)
    {
      stringBuffer.append((this.useNamedParameter ? generateUniqueNamedParameter() : (String)Character.valueOf('?')) + ", ");
    }
    
    stringBuffer.append(this.useNamedParameter ? generateUniqueNamedParameter() : Character.valueOf('?'));
    
    this.newSql = new String(stringBuffer);
    return this.newSql;
  }




  
  private final int getReturnParamTypeCode(int paramInt, String paramString, int[] paramArrayOfint) throws SQLException {
    for (byte b = 0; b < this.tableColumnNames.length; b++) {
      
      if (paramString.equalsIgnoreCase(this.tableColumnNames[b])) {
        
        paramArrayOfint[paramInt] = b + 1;
        return this.tableColumnTypes[b];
      } 
    } 


    
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
    sQLException.fillInStackTrace();
    throw sQLException;
  }


  
  private static final ThreadLocal<OracleSql> SQL_PARSER = new ThreadLocal<OracleSql>() {
      protected OracleSql initialValue() {
        return new OracleSql(null);
      }
    };

  
  final boolean isInsertSqlStmt() throws SQLException {
    if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) {
      parseSql();
    }
    return (this.sqlKind == OracleStatement.SqlKind.INSERT);
  }

  
  String getTableName() throws SQLException {
    if (this.tableName != null) return this.tableName;
    
    String str = this.originalSql.trim().toUpperCase();
    
    int i = str.indexOf("INSERT");
    i = str.indexOf("INTO", i);
    
    if (i < 0) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    int j = str.length();
    int k = i + 5;
    
    for (; k < j && str.charAt(k) == ' '; k++);
    
    if (k >= j) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    int m = k + 1;

    
    for (; m < j && str.charAt(m) != ' ' && str.charAt(m) != '('; m++);
    
    if (k == m - 1) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    this.tableName = str.substring(k, m);
    
    return this.tableName;
  }

  
  void allocateSpaceForDescribedData(int paramInt) throws SQLException {
    this.numColumns = paramInt;
    
    this.tableColumnNames = new String[paramInt];
    this.tableColumnTypes = new int[paramInt];
    this.tableMaxLengths = new int[paramInt];
    this.tableNullables = new boolean[paramInt];
    this.tableFormOfUses = new short[paramInt];
    this.tablePrecisions = new int[paramInt];
    this.tableScales = new int[paramInt];
    this.tableTypeNames = new String[paramInt];
  }




  
  void fillDescribedData(int paramInt1, String paramString1, int paramInt2, int paramInt3, boolean paramBoolean, short paramShort, int paramInt4, int paramInt5, String paramString2) throws SQLException {
    this.tableColumnNames[paramInt1] = paramString1;
    this.tableColumnTypes[paramInt1] = paramInt2;
    this.tableMaxLengths[paramInt1] = paramInt3;
    this.tableNullables[paramInt1] = paramBoolean;
    this.tableFormOfUses[paramInt1] = paramShort;
    this.tablePrecisions[paramInt1] = paramInt4;
    this.tableScales[paramInt1] = paramInt5;
    this.tableTypeNames[paramInt1] = paramString2;
  }

  
  void initMetaData(OracleReturnResultSet paramOracleReturnResultSet) throws SQLException {
    if (this.returnAccessors != null)
      return; 
    this.returnAccessors = paramOracleReturnResultSet.returnAccessors;

    
    switch (this.autoKeyType) {
      
      case 0:
        initMetaDataKeyFlag();
        break;
      case 1:
      case 2:
        initMetaDataColumnIndexes();
        break;
    } 
  }


  
  void initMetaDataKeyFlag() throws SQLException {
    (this.returnAccessors[0]).columnName = "ROWID";
    (this.returnAccessors[0]).describeType = 104;
    (this.returnAccessors[0]).describeMaxLength = 4;
    (this.returnAccessors[0]).nullable = true;
    (this.returnAccessors[0]).precision = 0;
    (this.returnAccessors[0]).scale = 0;
    (this.returnAccessors[0]).formOfUse = 0;
  }




  
  void initMetaDataColumnIndexes() throws SQLException {
    for (byte b = 0; b < this.returnAccessors.length; b++) {
      
      Accessor accessor = this.returnAccessors[b];
      int i = this.columnIndexes[b] - 1;
      
      accessor.columnName = this.tableColumnNames[i];
      accessor.describeType = this.tableColumnTypes[i];
      accessor.describeMaxLength = this.tableMaxLengths[i];
      accessor.nullable = this.tableNullables[i];
      accessor.precision = this.tablePrecisions[i];
      accessor.scale = this.tablePrecisions[i];
      accessor.formOfUse = this.tableFormOfUses[i];
    } 
  }





  
  int getValidColumnIndex(int paramInt) throws SQLException {
    if (paramInt <= 0 || paramInt > this.returnAccessors.length) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    return paramInt - 1;
  }

  
  public int getColumnCount() throws SQLException {
    return this.returnAccessors.length;
  }


  
  public String getColumnName(int paramInt) throws SQLException {
    if (paramInt <= 0 || paramInt > this.returnAccessors.length) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    return (this.returnAccessors[paramInt - 1]).columnName;
  }


  
  public String getTableName(int paramInt) throws SQLException {
    if (paramInt <= 0 || paramInt > this.returnAccessors.length) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    return getTableName();
  }

  
  Accessor[] getDescription() throws SQLException {
    return this.returnAccessors;
  }

  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
