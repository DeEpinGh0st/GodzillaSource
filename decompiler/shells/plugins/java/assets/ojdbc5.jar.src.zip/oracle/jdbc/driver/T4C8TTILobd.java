package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
















































































































class T4C8TTILobd
  extends T4CTTIMsg
{
  static final int LOBD_STATE0 = 0;
  static final int LOBD_STATE1 = 1;
  static final int LOBD_STATE2 = 2;
  static final int LOBD_STATE3 = 3;
  static final int LOBD_STATE_EXIT = 4;
  static final short TTCG_LNG = 254;
  static final short LOBDATALENGTH = 252;
  static byte[] ucs2Char = new byte[2];










  
  T4C8TTILobd(T4CConnection paramT4CConnection) {
    super(paramT4CConnection, (byte)14);
  }


































  
  void marshalLobData(byte[] paramArrayOfbyte, long paramLong1, long paramLong2, boolean paramBoolean) throws IOException {
    long l = paramLong2;

    
    marshalTTCcode();
    if (paramBoolean) {
      
      this.meg.outStream.flush();
      this.meg.outStream.writeZeroCopyIO(paramArrayOfbyte, (int)paramLong1, (int)paramLong2);
    }
    else {
      
      boolean bool = false;
      
      if (l > 252L) {
        
        bool = true;
        
        this.meg.marshalUB1((short)254);
      } 

      
      long l1 = 0L;
      
      for (; l > 252L; l1++, l -= 252L) {
        
        this.meg.marshalUB1((short)252);
        this.meg.marshalB1Array(paramArrayOfbyte, (int)(paramLong1 + l1 * 252L), 252);
      } 

      
      if (l > 0L) {
        
        this.meg.marshalUB1((short)(int)l);
        this.meg.marshalB1Array(paramArrayOfbyte, (int)(paramLong1 + l1 * 252L), (int)l);
      } 


      
      if (bool == true) {
        this.meg.marshalUB1((short)0);
      }
    } 
  }









  
  void marshalClobUB2_For9iDB(byte[] paramArrayOfbyte, long paramLong1, long paramLong2) throws IOException {
    long l1 = paramLong2;
    boolean bool = false;
    
    marshalTTCcode();

    
    if (l1 > 84L) {
      
      bool = true;
      
      this.meg.marshalUB1((short)254);
    } 



    
    long l2 = 0L;
    
    for (; l1 > 84L; l2++, l1 -= 84L) {


      
      this.meg.marshalUB1((short)252);



      
      for (byte b = 0; b < 84; b++) {


        
        this.meg.marshalUB1((short)2);

        
        this.meg.marshalB1Array(paramArrayOfbyte, (int)(paramLong1 + l2 * 168L + (b * 2)), 2);
      } 
    } 


    
    if (l1 > 0L) {


      
      long l = l1 * 3L;
      
      this.meg.marshalUB1((short)(int)l);



      
      for (byte b = 0; b < l1; b++) {


        
        this.meg.marshalUB1((short)2);

        
        this.meg.marshalB1Array(paramArrayOfbyte, (int)(paramLong1 + l2 * 168L + (b * 2)), 2);
      } 
    } 



    
    if (bool == true) {
      this.meg.marshalUB1((short)0);
    }
  }


























































  
  long unmarshalLobData(byte[] paramArrayOfbyte, int paramInt, boolean paramBoolean) throws SQLException, IOException {
    int i = 0;
    if (paramBoolean) {
      
      int j = 0;



      
      int[] arrayOfInt = new int[1];

      
      boolean bool = false;
      while (!bool) {
        
        bool = this.meg.inStream.readZeroCopyIO(paramArrayOfbyte, paramInt + j, arrayOfInt);


        
        j += arrayOfInt[0];
      } 
      i = j;
    
    }
    else {
      
      int j = paramInt;
      short s = 0;

      
      byte b = 0;

      
      while (b != 4) {
        
        switch (b) {


          
          case false:
            s = this.meg.unmarshalUB1();



            
            if (s == 254) {
              b = 2;

              
              continue;
            } 
            
            b = 1;









          
          case true:
            if (paramArrayOfbyte.length >= j + s) {
              
              this.meg.getNBytes(paramArrayOfbyte, j, s);
            }
            else {
              
              byte[] arrayOfByte = new byte[s];
              this.meg.getNBytes(arrayOfByte, 0, s);
              int k = Math.min(paramArrayOfbyte.length - j, s);
              System.arraycopy(arrayOfByte, 0, paramArrayOfbyte, j, k);
            } 
            
            i += s;
            b = 4;








          
          case true:
            s = this.meg.unmarshalUB1();

            
            if (s > 0) {
              b = 3;
              
              continue;
            } 
            
            b = 4;













          
          case true:
            if (paramArrayOfbyte.length >= j + s) {

              
              this.meg.getNBytes(paramArrayOfbyte, j, s);





            
            }
            else {





              
              byte[] arrayOfByte = new byte[s];
              this.meg.getNBytes(arrayOfByte, 0, s);
              int k = Math.min(paramArrayOfbyte.length - j, s);
              System.arraycopy(arrayOfByte, 0, paramArrayOfbyte, j, k);
            } 


            
            i += s;

            
            j += s;



            
            b = 2;
        } 











      
      } 
    } 
    return i;
  }






























  
  long unmarshalClobUB2_For9iDB(byte[] paramArrayOfbyte, int paramInt) throws SQLException, IOException {
    long l1 = 0L;
    long l2 = paramInt;
    short s = 0;
    int i = 0;
    int j = 0;

    
    byte b = 0;

    
    while (b != 4) {
      
      switch (b) {


        
        case false:
          s = this.meg.unmarshalUB1();



          
          if (s == 254) {
            b = 2;

            
            continue;
          } 
          
          b = 1;







        
        case true:
          for (i = 0; i < s; i += j, l2 += 2L, l1 += 2L)
          {
            j = this.meg.unmarshalUCS2(paramArrayOfbyte, l2);
          }
          
          b = 4;








        
        case true:
          s = this.meg.unmarshalUB1();

          
          if (s > 0) {
            b = 3;
            
            continue;
          } 
          
          b = 4;









        
        case true:
          for (i = 0; i < s; i += j, l2 += 2L, l1 += 2L)
          {
            j = this.meg.unmarshalUCS2(paramArrayOfbyte, l2);
          }




          
          b = 2;
      } 









    
    } 
    return l1;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
