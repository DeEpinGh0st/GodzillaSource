package oracle.jdbc.driver;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.BLOB;
























class OracleBlobOutputStream
  extends OutputStream
{
  long lobOffset;
  BLOB blob;
  byte[] buf;
  int count;
  int bufSize;
  boolean isClosed;
  
  public OracleBlobOutputStream(BLOB paramBLOB, int paramInt) throws SQLException {
    this(paramBLOB, paramInt, 1L);
  }













  
  public OracleBlobOutputStream(BLOB paramBLOB, int paramInt, long paramLong) throws SQLException {
    if (paramBLOB == null || paramInt <= 0 || paramLong < 1L)
    {
      throw new IllegalArgumentException("Illegal Arguments");
    }
    
    this.blob = paramBLOB;
    this.lobOffset = paramLong;
    
    PhysicalConnection physicalConnection = (PhysicalConnection)paramBLOB.getInternalConnection();
    synchronized (physicalConnection) {
      this.buf = physicalConnection.getByteBuffer(paramInt);
    } 
    this.count = 0;
    this.bufSize = paramInt;
    
    this.isClosed = false;
  }










  
  public void write(int paramInt) throws IOException {
    ensureOpen();
    
    if (this.count >= this.bufSize) {
      flushBuffer();
    }
    this.buf[this.count++] = (byte)paramInt;
  }













  
  public void write(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
    ensureOpen();
    
    int i = paramInt1;
    int j = Math.min(paramInt2, paramArrayOfbyte.length - paramInt1);
    
    if (j >= 2 * this.bufSize) {





      
      if (this.count > 0) flushBuffer();
      
      try {
        this.lobOffset += this.blob.setBytes(this.lobOffset, paramArrayOfbyte, paramInt1, j);
      }
      catch (SQLException sQLException) {

        
        IOException iOException = DatabaseError.createIOException(sQLException);
        iOException.fillInStackTrace();
        throw iOException;
      }
    
    }
    else {
      
      int k = i + j;
      
      while (i < k) {
        
        int m = Math.min(this.bufSize - this.count, k - i);
        
        System.arraycopy(paramArrayOfbyte, i, this.buf, this.count, m);
        
        i += m;
        this.count += m;
        
        if (this.count >= this.bufSize) {
          flushBuffer();
        }
      } 
    } 
  }









  
  public void flush() throws IOException {
    ensureOpen();
    
    flushBuffer();
  }










  
  public void close() throws IOException {
    if (this.isClosed) {
      return;
    }
    
    try {
      this.isClosed = true;
      flushBuffer();
    } finally {

      
      try {
        PhysicalConnection physicalConnection = (PhysicalConnection)this.blob.getInternalConnection();
        synchronized (physicalConnection) {
          
          if (this.buf != null) {
            
            physicalConnection.cacheBuffer(this.buf);
            this.buf = null;
          } 
        } 
      } catch (SQLException sQLException) {

        
        IOException iOException = DatabaseError.createIOException(sQLException);
        iOException.fillInStackTrace();
        throw iOException;
      } 
    } 
  }











  
  private void flushBuffer() throws IOException {
    try {
      if (this.count > 0)
      {
        this.lobOffset += this.blob.setBytes(this.lobOffset, this.buf, 0, this.count);
        this.count = 0;
      }
    
    } catch (SQLException sQLException) {

      
      IOException iOException = DatabaseError.createIOException(sQLException);
      iOException.fillInStackTrace();
      throw iOException;
    } 
  }











  
  void ensureOpen() throws IOException {
    try {
      if (this.isClosed)
      {
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 57, (Object)null);
        sQLException.fillInStackTrace();
        throw sQLException;
      }
    
    } catch (SQLException sQLException) {

      
      IOException iOException = DatabaseError.createIOException(sQLException);
      iOException.fillInStackTrace();
      throw iOException;
    } 
  }














  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    try {
      return this.blob.getInternalConnection();
    }
    catch (Exception exception) {
      
      return null;
    } 
  }



  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
