package oracle.jdbc.aq;

import java.util.EventListener;

public interface AQNotificationListener extends EventListener {
  void onAQNotification(AQNotificationEvent paramAQNotificationEvent);
}
