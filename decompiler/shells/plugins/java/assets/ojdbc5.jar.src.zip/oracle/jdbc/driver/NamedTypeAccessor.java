package oracle.jdbc.driver;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleDataFactory;
import oracle.jdbc.oracore.OracleType;
import oracle.jdbc.oracore.OracleTypeADT;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.Datum;
import oracle.sql.JAVA_STRUCT;
import oracle.sql.OPAQUE;
import oracle.sql.OpaqueDescriptor;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;
import oracle.sql.TypeDescriptor;















class NamedTypeAccessor
  extends TypeAccessor
{
  NamedTypeAccessor(OracleStatement paramOracleStatement, String paramString, short paramShort, int paramInt, boolean paramBoolean) throws SQLException {
    init(paramOracleStatement, 109, 109, paramShort, paramBoolean);
    initForDataAccess(paramInt, 0, paramString);
  }






  
  NamedTypeAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, String paramString) throws SQLException {
    init(paramOracleStatement, 109, 109, paramShort, false);
    initForDescribe(109, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, paramString);
    
    initForDataAccess(0, paramInt1, paramString);
  }






  
  NamedTypeAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, String paramString, OracleType paramOracleType) throws SQLException {
    init(paramOracleStatement, 109, 109, paramShort, false);
    
    this.describeOtype = paramOracleType;
    
    initForDescribe(109, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, paramString);

    
    this.internalOtype = paramOracleType;
    
    initForDataAccess(0, paramInt1, paramString);
  }



  
  OracleType otypeFromName(String paramString) throws SQLException {
    if (!this.outBind) {
      return (OracleType)TypeDescriptor.getTypeDescriptor(paramString, (OracleConnection)this.statement.connection).getPickler();
    }
    if (this.externalType == 2003) {
      return (OracleType)ArrayDescriptor.createDescriptor(paramString, (Connection)this.statement.connection).getOracleTypeCOLLECTION();
    }
    if (this.externalType == 2007)
    {


      
      return (OracleType)OpaqueDescriptor.createDescriptor(paramString, (Connection)this.statement.connection).getPickler();
    }
    
    return (OracleType)StructDescriptor.createDescriptor(paramString, (Connection)this.statement.connection).getOracleTypeADT();
  }





  
  void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
    super.initForDataAccess(paramInt1, paramInt2, paramString);
    
    this.byteLength = this.statement.connection.namedTypeAccessorByteLen;
  }












  
  Object getObject(int paramInt) throws SQLException {
    return getObject(paramInt, this.statement.connection.getTypeMap());
  }












  
  Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory) throws SQLException {
    return paramOracleDataFactory.create(getObject(paramInt, this.statement.connection.getTypeMap()), 0);
  }












  
  Object getObject(int paramInt, Map paramMap) throws SQLException {
    if (this.rowSpaceIndicator == null) {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 



    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      Datum datum;

      
      if (this.externalType == 0) {
        
        Datum datum1 = getOracleObject(paramInt);


        
        if (datum1 == null) {
          return null;
        }
        if (datum1 instanceof STRUCT) {
          return ((STRUCT)datum1).toJdbc(paramMap);
        }
        if (datum1 instanceof OPAQUE) {
          return ((OPAQUE)datum1).toJdbc(paramMap);
        }

        
        return datum1.toJdbc();
      } 


      
      switch (this.externalType) {



        
        case 2008:
          paramMap = null;



        
        case 2000:
        case 2002:
        case 2003:
        case 2007:
          datum = getOracleObject(paramInt);


          
          if (datum == null) {
            return null;
          }
          if (datum instanceof STRUCT) {
            return ((STRUCT)datum).toJdbc(paramMap);
          }
          return datum.toJdbc();
      } 






      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 




    
    return null;
  }










  
  Datum getOracleObject(int paramInt) throws SQLException {
    STRUCT sTRUCT;
    OPAQUE oPAQUE;
    ARRAY aRRAY = null;

    
    if (this.rowSpaceIndicator == null) {
      
      SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException1.fillInStackTrace();
      throw sQLException1;
    } 




    
    byte[] arrayOfByte = pickledBytes(paramInt);
    
    if (arrayOfByte == null || arrayOfByte.length == 0)
    {
      return null;
    }
    
    PhysicalConnection physicalConnection = this.statement.connection;
    OracleTypeADT oracleTypeADT = (OracleTypeADT)this.internalOtype;
    TypeDescriptor typeDescriptor = TypeDescriptor.getTypeDescriptor(oracleTypeADT.getFullName(), (OracleConnection)physicalConnection, arrayOfByte, 0L);

    
    switch (typeDescriptor.getTypeCode()) {

      
      case 2003:
        aRRAY = new ARRAY((ArrayDescriptor)typeDescriptor, arrayOfByte, (Connection)physicalConnection);


































        
        return (Datum)aRRAY;
      case 2002:
        return (Datum)new STRUCT((StructDescriptor)typeDescriptor, arrayOfByte, (Connection)physicalConnection);
      case 2007:
        return (Datum)new OPAQUE((OpaqueDescriptor)typeDescriptor, arrayOfByte, (Connection)physicalConnection);
      case 2008:
        return (Datum)new JAVA_STRUCT((StructDescriptor)typeDescriptor, arrayOfByte, (Connection)physicalConnection);
    } 
    SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
    sQLException.fillInStackTrace();
    throw sQLException;
  }


  
  ARRAY getARRAY(int paramInt) throws SQLException {
    return (ARRAY)getOracleObject(paramInt);
  }












  
  STRUCT getSTRUCT(int paramInt) throws SQLException {
    return (STRUCT)getOracleObject(paramInt);
  }












  
  OPAQUE getOPAQUE(int paramInt) throws SQLException {
    return (OPAQUE)getOracleObject(paramInt);
  }



  
  boolean isNull(int paramInt) throws SQLException {
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    byte[] arrayOfByte = pickledBytes(paramInt);
    return (arrayOfByte == null || arrayOfByte.length == 0);
  }







  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
