package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.jdbc.internal.OracleStatement;
import oracle.sql.ROWID;














class VarcharAccessor
  extends CharCommonAccessor
{
  VarcharAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean) throws SQLException {
    char c = 'ྠ';
    
    if (paramOracleStatement.sqlKind == OracleStatement.SqlKind.PLSQL_BLOCK) {
      c = paramOracleStatement.connection.plsqlVarcharParameter4KOnly ? 'ྠ' : '翾';
    }
    
    init(paramOracleStatement, 1, 9, paramInt1, paramShort, paramInt2, paramBoolean, c, 2000);
  }










  
  VarcharAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort) throws SQLException {
    char c = 'ྠ';
    
    if (paramOracleStatement.sqlKind == OracleStatement.SqlKind.PLSQL_BLOCK) {
      c = paramOracleStatement.connection.plsqlVarcharParameter4KOnly ? 'ྠ' : '翾';
    }
    
    init(paramOracleStatement, 1, 9, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, c, 2000);
  }










  
  ROWID getROWID(int paramInt) throws SQLException {
    if (this.rowSpaceIndicator == null) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    ROWID rOWID = null;
    
    if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
      
      byte[] arrayOfByte = getBytesInternal(paramInt);
      if (arrayOfByte != null)
        rOWID = new ROWID(arrayOfByte); 
    } 
    return rOWID;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
