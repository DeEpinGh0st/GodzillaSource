package oracle.jdbc.driver;

public interface Message {
  String msg(String paramString, Object paramObject);
}
