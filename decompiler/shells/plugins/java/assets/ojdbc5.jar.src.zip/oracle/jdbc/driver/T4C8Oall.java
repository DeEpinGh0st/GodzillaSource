package oracle.jdbc.driver;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Vector;
import oracle.jdbc.internal.KeywordValue;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.internal.OracleStatement;
import oracle.jdbc.oracore.OracleTypeADT;













































































































final class T4C8Oall
  extends T4CTTIfun
{
  Vector<IOException> nonFatalIOExceptions = null;
  
  static final byte[] EMPTY_BYTES = new byte[0];

  
  static final int UOPF_PRS = 1;

  
  static final int UOPF_BND = 8;
  
  static final int UOPF_EXE = 32;
  
  static final int UOPF_FEX = 512;
  
  static final int UOPF_FCH = 64;
  
  static final int UOPF_CAN = 128;
  
  static final int UOPF_COM = 256;
  
  static final int UOPF_DSY = 8192;
  
  static final int UOPF_SIO = 1024;
  
  static final int UOPF_NPL = 32768;
  
  static final int UOPF_DFN = 16;
  
  static final int EXE_COMMIT_ON_SUCCESS = 1;
  
  static final int EXE_LEAVE_CUR_MAPPED = 2;
  
  static final int EXE_BATCH_DML_ERRORS = 4;
  
  static final int EXE_SCROL_READ_ONLY = 8;
  
  static final int AL8KW_MAXLANG = 63;
  
  static final int AL8KW_TIMEZONE = 163;
  
  static final int AL8KW_ERR_OVLAP = 164;
  
  static final int AL8KW_SESSION_ID = 165;
  
  static final int AL8KW_SERIAL_NUM = 166;
  
  static final int AL8KW_TAG_FOUND = 167;
  
  static final int AL8KW_SCHEMA_NAME = 168;
  
  static final int AL8KW_SCHEMA_ID = 169;
  
  static final int AL8KW_ENABLED_ROLES = 170;
  
  static final int AL8KW_AUX_SESSSTATE = 171;
  
  static final String[] NLS_KEYS = new String[] { "AUTH_NLS_LXCCURRENCY", "AUTH_NLS_LXCISOCURR", "AUTH_NLS_LXCNUMERICS", null, null, null, null, "AUTH_NLS_LXCDATEFM", "AUTH_NLS_LXCDATELANG", "AUTH_NLS_LXCTERRITORY", "SESSION_NLS_LXCCHARSET", "AUTH_NLS_LXCSORT", "AUTH_NLS_LXCCALENDAR", null, null, null, "AUTH_NLS_LXLAN", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, "AUTH_NLS_LXCSORT", null, "AUTH_NLS_LXCUNIONCUR", null, null, null, null, "AUTH_NLS_LXCTIMEFM", "AUTH_NLS_LXCSTMPFM", "AUTH_NLS_LXCTTZNFM", "AUTH_NLS_LXCSTZNFM", "SESSION_NLS_LXCNLSLENSEM", "SESSION_NLS_LXCNCHAREXCP", "SESSION_NLS_LXCNCHARIMP" };









  
  static final int LDIREGIDFLAG = 120;









  
  static final int LDIREGIDSET = 181;









  
  static final int LDIMAXTIMEFIELD = 60;









  
  int rowsProcessed;









  
  int numberOfDefinePositions;









  
  long options;









  
  int cursor;








  
  byte[] sqlStmt = new byte[0];
  final long[] al8i4 = new long[13];

  
  boolean plsql = false;

  
  Accessor[] definesAccessors;

  
  int definesLength;

  
  Accessor[] outBindAccessors;

  
  int numberOfBindPositions;
  
  InputStream[][] parameterStream;
  
  byte[][][] parameterDatum;
  
  OracleTypeADT[][] parameterOtype;
  
  short[] bindIndicators;
  
  byte[] bindBytes;
  
  char[] bindChars;
  
  int bindIndicatorSubRange;
  
  byte[] tmpBindsByteArray;
  
  DBConversion conversion;
  
  byte[] ibtBindBytes;
  
  char[] ibtBindChars;
  
  short[] ibtBindIndicators;
  
  boolean sendBindsDefinition = false;
  
  OracleStatement oracleStatement;
  
  short dbCharSet;
  
  short NCharSet;
  
  T4CTTIrxd rxd;
  
  T4C8TTIrxh rxh;
  
  T4CTTIdcb dcb;
  
  OracleStatement.SqlKind typeOfStatement;
  
  int defCols = 0;

  
  int rowsToFetch;
  
  boolean aFetchWasDone = false;
  
  T4CTTIoac[] oacdefBindsSent;
  
  T4CTTIoac[] oacdefDefines;
  
  int[] definedColumnSize;
  
  int[] definedColumnType;
  
  int[] definedColumnFormOfUse;
  
  NTFDCNRegistration registration = null;
  
  static final int AL8TXCUR = 1;
  
  static final int AL8TXDON = 2;
  
  static final int AL8TXRON = 4;
  
  T4C8Oall(T4CConnection paramT4CConnection) {
    super(paramT4CConnection, (byte)3);
    
    setFunCode((short)94);
    this.rxh = new T4C8TTIrxh(paramT4CConnection);
    this.rxd = new T4CTTIrxd(paramT4CConnection);
    this.dcb = new T4CTTIdcb(paramT4CConnection);
  }





















  
  void doOALL(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, OracleStatement.SqlKind paramSqlKind, int paramInt1, byte[] paramArrayOfbyte1, int paramInt2, Accessor[] paramArrayOfAccessor1, int paramInt3, Accessor[] paramArrayOfAccessor2, int paramInt4, byte[] paramArrayOfbyte2, char[] paramArrayOfchar1, short[] paramArrayOfshort1, int paramInt5, DBConversion paramDBConversion, byte[] paramArrayOfbyte3, InputStream[][] paramArrayOfInputStream, byte[][][] paramArrayOfbyte, OracleTypeADT[][] paramArrayOfOracleTypeADT, OracleStatement paramOracleStatement, byte[] paramArrayOfbyte4, char[] paramArrayOfchar2, short[] paramArrayOfshort2, T4CTTIoac[] paramArrayOfT4CTTIoac, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3, NTFDCNRegistration paramNTFDCNRegistration) throws SQLException, IOException {
    this.typeOfStatement = paramSqlKind;
    this.cursor = paramInt1;
    this.sqlStmt = paramBoolean1 ? paramArrayOfbyte1 : EMPTY_BYTES;
    this.rowsToFetch = paramInt2;
    this.outBindAccessors = paramArrayOfAccessor1;
    this.numberOfBindPositions = paramInt3;
    this.definesAccessors = paramArrayOfAccessor2;
    this.definesLength = paramInt4;
    this.bindBytes = paramArrayOfbyte2;
    this.bindChars = paramArrayOfchar1;
    this.bindIndicators = paramArrayOfshort1;
    this.bindIndicatorSubRange = paramInt5;
    this.conversion = paramDBConversion;
    this.tmpBindsByteArray = paramArrayOfbyte3;
    this.parameterStream = paramArrayOfInputStream;
    this.parameterDatum = paramArrayOfbyte;
    this.parameterOtype = paramArrayOfOracleTypeADT;
    this.oracleStatement = paramOracleStatement;
    this.ibtBindBytes = paramArrayOfbyte4;
    this.ibtBindChars = paramArrayOfchar2;
    this.ibtBindIndicators = paramArrayOfshort2;
    this.oacdefBindsSent = paramArrayOfT4CTTIoac;
    this.definedColumnType = paramArrayOfint1;
    this.definedColumnSize = paramArrayOfint2;
    this.definedColumnFormOfUse = paramArrayOfint3;
    this.registration = paramNTFDCNRegistration;

    
    this.dbCharSet = paramDBConversion.getServerCharSetId();
    this.NCharSet = paramDBConversion.getNCharSetId();

    
    int i = 0;
    if (this.bindIndicators != null) {
      i = ((this.bindIndicators[this.bindIndicatorSubRange + 3] & 0xFFFF) << 16) + (this.bindIndicators[this.bindIndicatorSubRange + 4] & 0xFFFF);
    }

    
    if (paramArrayOfbyte1 == null) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 431);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    if (!this.typeOfStatement.isDML() && i > 1) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 433);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    this.rowsProcessed = 0;
    this.options = 0L;
    this.plsql = this.typeOfStatement.isPlsqlOrCall();
    this.sendBindsDefinition = false;

    
    if (this.receiveState != 0)
    {


      
      this.receiveState = 0;
    }
    
    this.rxh.init();
    this.rxd.init();
    this.oer.init();

    
    if (paramBoolean5) {
      initDefinesDefinition();
    }
    if (this.numberOfBindPositions > 0 && this.bindIndicators != null) {
      
      if (this.oacdefBindsSent == null)
        this.oacdefBindsSent = new T4CTTIoac[this.numberOfBindPositions]; 
      this.sendBindsDefinition = initBindsDefinition(this.oacdefBindsSent);
    } 







    
    this.options = setOptions(paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean5);
    
    if ((this.options & 0x1L) > 0L) {
      this.al8i4[0] = 1L;
    } else {
      this.al8i4[0] = 0L;
    } 
    
    if (this.plsql || this.typeOfStatement.isOTHER()) {
      this.al8i4[1] = 1L;
    } else if (paramBoolean4) {
      
      if (paramBoolean3 && this.oracleStatement.connection.useFetchSizeWithLongColumn) {
        this.al8i4[1] = this.rowsToFetch;
      } else {
        this.al8i4[1] = 0L;
      } 
    } else if (this.typeOfStatement.isDML()) {




      
      this.al8i4[1] = (i == 0) ? this.oracleStatement.batch : i;
    }
    else if (paramBoolean3 && !paramBoolean4) {
      
      this.al8i4[1] = this.rowsToFetch;
    } else {
      this.al8i4[1] = 0L;
    } 
    
    if (this.typeOfStatement.isSELECT()) {
      this.al8i4[7] = 1L;
    } else {
      this.al8i4[7] = 0L;
    } 
    long l = this.oracleStatement.inScn;
    int j = (int)l;
    int k = (int)(l >> 32L);
    this.al8i4[5] = j;
    this.al8i4[6] = k;
    
    this.rowsProcessed = 0;
    this.aFetchWasDone = false;

    
    this.rxd.setNumberOfColumns(this.definesLength);
    
    if ((this.options & 0x40L) != 0L && (this.options & 0x20L) == 0L && (this.options & 0x1L) == 0L && (this.options & 0x8L) == 0L && (this.options & 0x10L) == 0L && !this.oracleStatement.needToSendOalToFetch) {

      
      setFunCode((short)5);
    } else {
      setFunCode((short)94);
    } 
    this.nonFatalIOExceptions = null;
    doRPC();


    
    if ((this.options & 0x20L) != 0L) {
      this.oracleStatement.inScn = 0L;
    }
    
    this.ibtBindIndicators = null;
    this.ibtBindChars = null;
    this.ibtBindBytes = null;
    this.tmpBindsByteArray = null;
    this.outBindAccessors = null;
    this.bindBytes = null;
    this.bindChars = null;
    this.bindIndicators = null;
    this.oracleStatement = null;
    
    if (this.nonFatalIOExceptions != null) {
      
      IOException iOException = this.nonFatalIOExceptions.get(0);
      
      try {
        SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 266);
        sQLException.fillInStackTrace();
        throw sQLException;
      
      }
      catch (SQLException sQLException) {



        
        sQLException.initCause(iOException);
        throw sQLException;
      } 
    } 
  }








  
  void readBVC() throws IOException, SQLException {
    int i = this.meg.unmarshalUB2();

    
    this.rxd.unmarshalBVC(i);
  }



  
  void readIOV() throws IOException, SQLException {
    T4CTTIiov t4CTTIiov = new T4CTTIiov(this.connection, this.rxh, this.rxd);
    
    t4CTTIiov.init();
    t4CTTIiov.unmarshalV10();

    
    if (this.oracleStatement.returnParamAccessors == null && !t4CTTIiov.isIOVectorEmpty()) {

      
      byte[] arrayOfByte = t4CTTIiov.getIOVector();



      
      this.outBindAccessors = t4CTTIiov.processRXD(this.outBindAccessors, this.numberOfBindPositions, this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.conversion, this.tmpBindsByteArray, arrayOfByte, this.parameterStream, this.parameterDatum, this.parameterOtype, this.oracleStatement, null, null, null);
    } 
  }











  
  void readRXH() throws IOException, SQLException {
    this.rxh.init();
    this.rxh.unmarshalV10(this.rxd);
    
    if (this.rxh.uacBufLength > 0) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 405);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    if ((this.rxh.rxhflg & 0x8) == 8) {


      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 449);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 

    
    if ((this.rxh.rxhflg & 0x10) == 16)
    {



      
      for (byte b = 0; b < this.definesAccessors.length; b++) {
        
        if ((this.definesAccessors[b]).udskpos >= 0 && (this.definesAccessors[b]).udskpos != b) {

          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 450);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 
      } 
    }
  }


































































  
  void processSLG() throws IOException, SQLException {
    readRXH();

    
    int[] arrayOfInt = new int[this.numberOfBindPositions];
    for (byte b = 0; b < this.numberOfBindPositions; b++) {
      arrayOfInt[b] = (this.oacdefBindsSent[b]).oacmxl;
    }
    
    this.nonFatalIOExceptions = marshalBinds(arrayOfInt, true);
  }









  
  boolean readRXD() throws IOException, SQLException {
    this.aFetchWasDone = true;

    
    if (this.oracleStatement.returnParamAccessors != null && this.numberOfBindPositions > 0) {

      
      boolean bool = false;
      for (byte b = 0; b < this.oracleStatement.numberOfBindPositions; b++) {
        
        Accessor accessor = this.oracleStatement.returnParamAccessors[b];
        if (accessor != null) {
          
          int i = (int)this.meg.unmarshalUB4();
          if (!bool) {
            
            this.oracleStatement.rowsDmlReturned = i;
            this.oracleStatement.allocateDmlReturnStorage();
            this.oracleStatement.setupReturnParamAccessors();
            bool = true;
          } 
          
          for (byte b1 = 0; b1 < i; b1++)
          {


            
            accessor.unmarshalOneRow(); } 
        } 
      } 
      this.oracleStatement.returnParamsFetched = true;
    
    }
    else if (this.iovProcessed || (this.outBindAccessors != null && this.definesAccessors == null)) {


      
      if (this.rxd.unmarshal(this.outBindAccessors, this.numberOfBindPositions))
      {
        return true;
      
      }
    }
    else if (this.rxd.unmarshal(this.definesAccessors, this.definesLength)) {




      
      return true;
    } 
    
    return false;
  }






















  
  void readRPA() throws IOException, SQLException {
    int i = this.meg.unmarshalUB2();
    int[] arrayOfInt = new int[i];
    int j;
    for (j = 0; j < i; j++) {
      arrayOfInt[j] = (int)this.meg.unmarshalUB4();
    }
    j = arrayOfInt[0];
    int k = arrayOfInt[1];
    long l = j & 0xFFFFFFFFL | (k & 0xFFFFFFFFL) << 32L;

    
    if (l != 0L) {
      this.oracleStatement.connection.outScn = l;
    }

    
    this.cursor = arrayOfInt[2];

    
    int m = this.meg.unmarshalUB2();
    
    byte[] arrayOfByte = null;
    if (m > 0) {
      arrayOfByte = this.meg.unmarshalNBytes(m);
    }
    
    int n = this.meg.unmarshalUB2();
    
    KeywordValue[] arrayOfKeywordValue = new KeywordValue[n]; int i1;
    for (i1 = 0; i1 < n; i1++) {
      arrayOfKeywordValue[i1] = KeywordValueI.unmarshal(this.meg);
    }
    this.connection.updateSessionProperties(arrayOfKeywordValue);

    
    this.oracleStatement.dcnQueryId = -1L;
    this.oracleStatement.dcnTableName = null;
    if (this.connection.getTTCVersion() >= 4) {
      
      i1 = (int)this.meg.unmarshalUB4();
      byte[] arrayOfByte1 = this.meg.unmarshalNBytes(i1);
      if (i1 > 0 && this.registration != null) {
        
        boolean bool = false;
        Properties properties = this.registration.getRegistrationOptions();
        if (properties != null) {
          
          String str1 = properties.getProperty("DCN_QUERY_CHANGE_NOTIFICATION");
          if (str1 != null && str1.compareToIgnoreCase("true") == 0)
            bool = true; 
        } 
        int i2 = i1;
        if (bool) {
          i2 = i1 - 8;
        }
        String str = new String(arrayOfByte1, 0, i2);
        char[] arrayOfChar = { Character.MIN_VALUE };
        String[] arrayOfString = str.split(new String(arrayOfChar));
        this.registration.addTablesName(arrayOfString, arrayOfString.length);
        
        this.oracleStatement.dcnTableName = arrayOfString;
        
        if (bool) {

          
          int i3 = arrayOfByte1[i1 - 1] & 0xFF | (arrayOfByte1[i1 - 2] & 0xFF) << 8 | (arrayOfByte1[i1 - 3] & 0xFF) << 16 | (arrayOfByte1[i1 - 4] & 0xFF) << 24;



          
          int i4 = arrayOfByte1[i1 - 5] & 0xFF | (arrayOfByte1[i1 - 6] & 0xFF) << 8 | (arrayOfByte1[i1 - 7] & 0xFF) << 16 | (arrayOfByte1[i1 - 8] & 0xFF) << 24;



          
          long l1 = i4 & 0xFFFFFFFFL | (i3 & 0xFFFFFFFFL) << 32L;
          this.oracleStatement.dcnQueryId = l1;
        } 
      } 
    } 
  }






  
  void readDCB() throws IOException, SQLException {
    this.dcb.init(this.oracleStatement, 0);
    
    this.definesAccessors = this.dcb.receive(this.definesAccessors);
    this.numberOfDefinePositions = this.dcb.numuds;
    this.definesLength = this.numberOfDefinePositions;
    
    this.rxd.setNumberOfColumns(this.numberOfDefinePositions);
  }








  
  void processError() throws SQLException {
    this.cursor = this.oer.currCursorID;


    
    this.rowsProcessed = this.oer.getCurRowNumber();

    
    if (this.typeOfStatement.isSELECT() && this.oer.retCode == 1403)
    {
      this.aFetchWasDone = true;
    }
    if (!this.typeOfStatement.isSELECT() || (this.typeOfStatement.isSELECT() && this.oer.retCode != 1403)) {

      
      if (this.oracleStatement.connection.calculateChecksum && this.oer.retCode != 0) {
        
        long l = this.oer.updateChecksum(this.oracleStatement.checkSum);
        this.oracleStatement.checkSum = l;
      } 
      this.oer.processError(this.oracleStatement);
    } 
  }








  
  int getCursorId() {
    return this.cursor;
  }












  
  void continueReadRow(int paramInt, OracleStatement paramOracleStatement) throws SQLException, IOException {
    try {
      this.oracleStatement = paramOracleStatement;


      
      this.receiveState = 2;
      
      if (this.rxd.unmarshal(this.definesAccessors, paramInt, this.definesLength)) {




        
        this.receiveState = 3;

        
        return;
      } 
      
      resumeReceive();
    }
    finally {
      
      this.oracleStatement = null;
    } 
  }









  
  int getNumRows() {
    int i = 0;
    
    if (this.typeOfStatement == null)
      return i; 
    if (this.receiveState == 3) {
      i = -2;
    } else if (this.typeOfStatement != null) {

      
      switch (this.typeOfStatement) {




        
        case DELETE:
        case INSERT:
        case MERGE:
        case UPDATE:
        case ALTER_SESSION:
        case OTHER:
        case PLSQL_BLOCK:
        case CALL_BLOCK:
          i = this.rowsProcessed;
          break;

        
        case SELECT_FOR_UPDATE:
        case SELECT:
          i = (this.definesAccessors != null && this.definesLength > 0) ? (this.definesAccessors[0]).lastRowProcessed : 0;
          break;
      } 


    
    } 
    return i;
  }










  
  void marshal() throws IOException {
    if (getFunCode() == 5) {
      
      this.meg.marshalSWORD(this.cursor);
      this.meg.marshalSWORD((int)this.al8i4[1]);
    }
    else {
      
      if (this.oracleStatement.needToSendOalToFetch) {
        this.oracleStatement.needToSendOalToFetch = false;
      }
      marshalPisdef();




      
      this.meg.marshalCHR(this.sqlStmt);

      
      this.meg.marshalUB4Array(this.al8i4);

      
      int[] arrayOfInt = new int[this.numberOfBindPositions];
      byte b;
      for (b = 0; b < this.numberOfBindPositions; b++)
      {
        arrayOfInt[b] = (this.oacdefBindsSent[b]).oacmxl;
      }

      
      if ((this.options & 0x8L) != 0L && this.numberOfBindPositions > 0 && this.bindIndicators != null && this.sendBindsDefinition)
      {
        marshalBindsTypes(this.oacdefBindsSent);
      }

      
      if (this.connection.getTTCVersion() >= 2 && (this.options & 0x10L) != 0L)
      {
        for (b = 0; b < this.defCols; b++) {
          this.oacdefDefines[b].marshal();
        }
      }


      
      if ((this.options & 0x20L) != 0L && this.numberOfBindPositions > 0 && this.bindIndicators != null)
      {
        this.nonFatalIOExceptions = marshalBinds(arrayOfInt, false);
      }
    } 
  }














  
  void marshalPisdef() throws IOException {
    this.meg.marshalUB4(this.options);

    
    this.meg.marshalSWORD(this.cursor);


    
    if (this.sqlStmt.length == 0) {
      this.meg.marshalNULLPTR();
    } else {
      this.meg.marshalPTR();
    } 
    
    this.meg.marshalSWORD(this.sqlStmt.length);


    
    if (this.al8i4.length == 0) {
      this.meg.marshalNULLPTR();
    } else {
      this.meg.marshalPTR();
    } 
    
    this.meg.marshalSWORD(this.al8i4.length);


    
    this.meg.marshalNULLPTR();

    
    this.meg.marshalNULLPTR();

    
    if ((this.options & 0x40L) == 0L && (this.options & 0x20L) != 0L && (this.options & 0x1L) != 0L && this.typeOfStatement.isSELECT()) {




      
      this.meg.marshalUB4(Long.MAX_VALUE);
      this.meg.marshalUB4(this.rowsToFetch);
    
    }
    else {
      
      this.meg.marshalUB4(0L);
      
      this.meg.marshalUB4(0L);
    } 


    
    if (!this.typeOfStatement.isPlsqlOrCall()) {
      this.meg.marshalUB4(2147483647L);
    } else {
      this.meg.marshalUB4(32760L);
    } 
    
    if ((this.options & 0x8L) != 0L && this.numberOfBindPositions > 0 && this.sendBindsDefinition) {



      
      this.meg.marshalPTR();

      
      this.meg.marshalSWORD(this.numberOfBindPositions);
    
    }
    else {

      
      this.meg.marshalNULLPTR();

      
      this.meg.marshalSWORD(0);
    } 

    
    this.meg.marshalNULLPTR();

    
    this.meg.marshalNULLPTR();

    
    this.meg.marshalNULLPTR();

    
    this.meg.marshalNULLPTR();

    
    this.meg.marshalNULLPTR();



    
    if (this.connection.getTTCVersion() >= 2)
    {
      if (this.defCols > 0 && (this.options & 0x10L) != 0L) {


        
        this.meg.marshalPTR();

        
        this.meg.marshalSWORD(this.defCols);
      
      }
      else {

        
        this.meg.marshalNULLPTR();

        
        this.meg.marshalSWORD(0);
      } 
    }
    
    if (this.connection.getTTCVersion() >= 4) {







      
      int i = 0;
      int j = 0;
      if (this.registration != null) {
        
        long l = this.registration.getRegId();
        i = (int)(l & 0xFFFFFFFFFFFFFFFFL);
        j = (int)((l & 0xFFFFFFFF00000000L) >> 32L);
      } 

      
      this.meg.marshalUB4(i);
      
      this.meg.marshalNULLPTR();
      this.meg.marshalPTR();



















      
      if (this.connection.getTTCVersion() >= 5) {
        
        this.meg.marshalNULLPTR();
        this.meg.marshalUB4(0L);
        this.meg.marshalNULLPTR();
        this.meg.marshalUB4(0L);
        
        this.meg.marshalUB4(j);
      } 
    } 
  }









  
  boolean initBindsDefinition(T4CTTIoac[] paramArrayOfT4CTTIoac) throws SQLException, IOException {
    boolean bool = false;
    
    if (paramArrayOfT4CTTIoac.length != this.numberOfBindPositions) {
      
      bool = true;
      paramArrayOfT4CTTIoac = new T4CTTIoac[this.numberOfBindPositions];
    } 

    
    short[] arrayOfShort = this.bindIndicators;

    
    int i = 0;

    
    byte b1 = 0;

    
    for (byte b2 = 0; b2 < this.numberOfBindPositions; b2++) {
      SQLException sQLException; int arrayOfInt[], m;
      T4CTTIoac t4CTTIoac = new T4CTTIoac(this.connection);



      
      int j = this.bindIndicatorSubRange + 5 + 10 * b2;


      
      short s = arrayOfShort[j + 9];

      
      int k = arrayOfShort[j + 0] & 0xFFFF;



      
      switch (k) {

        
        case 8:
        case 24:
          if (this.plsql) {
            i = 32760;
          } else {
            i = Integer.MAX_VALUE;
          } 
          t4CTTIoac.init((short)k, i);
          t4CTTIoac.setFormOfUse(s);
          t4CTTIoac.setCharset((s == 2) ? this.NCharSet : this.dbCharSet);
          break;



        
        case 998:
          if (this.outBindAccessors != null && this.outBindAccessors[b2] != null) {
            
            PlsqlIndexTableAccessor plsqlIndexTableAccessor = (PlsqlIndexTableAccessor)this.outBindAccessors[b2];
            t4CTTIoac.init((short)plsqlIndexTableAccessor.elementInternalType, plsqlIndexTableAccessor.elementMaxLen);
            t4CTTIoac.setMal(plsqlIndexTableAccessor.maxNumberOfElements);
            t4CTTIoac.addFlg((short)64);
            b1++; break;
          } 
          if (this.ibtBindIndicators[6 + b1 * 8] != 0) {
            
            short s1 = this.ibtBindIndicators[6 + b1 * 8];
            int n = (this.ibtBindIndicators[6 + b1 * 8 + 2] & 0xFFFF) << 16 | this.ibtBindIndicators[6 + b1 * 8 + 3] & 0xFFFF;


            
            i = this.ibtBindIndicators[6 + b1 * 8 + 1] * this.conversion.sMaxCharSize;
            
            t4CTTIoac.init((short)s1, i);
            t4CTTIoac.setMal(n);
            t4CTTIoac.addFlg((short)64);
            b1++;
            
            break;
          } 
          sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), "INTERNAL ERROR: Binding PLSQL index-by table but no type defined", -1);
          sQLException.fillInStackTrace();
          throw sQLException;




        
        case 109:
        case 111:
          if (this.outBindAccessors != null && this.outBindAccessors[b2] != null) {
            
            if ((this.outBindAccessors[b2]).internalOtype != null) {
              
              t4CTTIoac.init((short)k, (k == 109) ? 11 : 4000);
              
              t4CTTIoac.setADT((OracleTypeADT)((TypeAccessor)this.outBindAccessors[b2]).internalOtype);
            } 
            break;
          } 
          if (this.parameterOtype != null && this.parameterOtype[this.oracleStatement.firstRowInBatch] != null) {

            
            t4CTTIoac.init((short)k, (k == 109) ? 11 : 4000);
            t4CTTIoac.setADT(this.parameterOtype[this.oracleStatement.firstRowInBatch][b2]);

            
            break;
          } 
          
          sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), "INTERNAL ERROR: Binding NAMED_TYPE but no type defined", -1);
          sQLException.fillInStackTrace();
          throw sQLException;





        
        case 994:
          arrayOfInt = this.oracleStatement.returnParamMeta;
          k = arrayOfInt[3 + b2 * 4 + 0];



          
          i = arrayOfInt[3 + b2 * 4 + 2];



          
          s = (short)arrayOfInt[3 + b2 * 4 + 3];



          
          if (k == 109 || k == 111) {
            
            TypeAccessor typeAccessor = (TypeAccessor)this.oracleStatement.returnParamAccessors[b2];

            
            t4CTTIoac.init((short)k, (k == 109) ? 11 : 4000);
            
            t4CTTIoac.setADT((OracleTypeADT)typeAccessor.internalOtype);
            
            break;
          } 
          t4CTTIoac.init((short)k, i);
          t4CTTIoac.setFormOfUse(s);
          t4CTTIoac.setCharset((s == 2) ? this.NCharSet : this.dbCharSet);
          break;



        
        case 180:
          i = arrayOfShort[j + 1] & 0xFFFF;


          
          t4CTTIoac.init((short)k, i);
          t4CTTIoac.addFlg2(134217728);






          
          t4CTTIoac.setTimestampFractionalSecondsPrecision((short)9);
          
          m = ((this.bindIndicators[this.bindIndicatorSubRange + 3] & 0xFFFF) << 16) + (this.bindIndicators[this.bindIndicatorSubRange + 4] & 0xFFFF);



          
          if (m == 1) {
            
            int n = ((arrayOfShort[j + 7] & 0xFFFF) << 16) + (arrayOfShort[j + 8] & 0xFFFF);

            
            short s1 = arrayOfShort[n];
            
            if (s1 == 7)
            {
              t4CTTIoac.setTimestampFractionalSecondsPrecision((short)0);
            }
          } 
          break;

        
        case 182:
        case 183:
          i = arrayOfShort[j + 1] & 0xFFFF;


          
          t4CTTIoac.init((short)k, i);
          t4CTTIoac.setFormOfUse(s);
          t4CTTIoac.setCharset((s == 2) ? this.NCharSet : this.dbCharSet);
          
          t4CTTIoac.setPrecision((short)9);
          break;





        
        default:
          i = arrayOfShort[j + 1] & 0xFFFF;





          
          if (i == 0) {
            
            i = arrayOfShort[j + 2] & 0xFFFF;


            
            if (k == 996) {
              i *= 2;
            }
            else if (i > 1) {
              i--;
            } 
            
            if (s == 2) {
              i *= this.conversion.maxNCharSize;
            }

            
            if (this.typeOfStatement == OracleStatement.SqlKind.PLSQL_BLOCK || (this.connection.versionNumber >= 10200 && this.typeOfStatement == OracleStatement.SqlKind.CALL_BLOCK)) {


              
              if (i == 0) {
                i = 32766;
              } else {
                i *= this.conversion.sMaxCharSize;
              } 
            } else if (this.typeOfStatement == OracleStatement.SqlKind.CALL_BLOCK) {





              
              if (i < 4001) {
                i = 4001;
              
              }
            
            }
            else if (s != 2) {









              
              if (((T4CConnection)this.oracleStatement.connection).retainV9BindBehavior && i <= 4000) {


                
                i = Math.min(i * this.conversion.sMaxCharSize, 4000);
              
              }
              else {
                
                i *= this.conversion.sMaxCharSize;
              } 
            } 


            
            if (i == 0) {
              i = 32;
            }
          } 
          t4CTTIoac.init((short)k, i);
          t4CTTIoac.setFormOfUse(s);
          t4CTTIoac.setCharset((s == 2) ? this.NCharSet : this.dbCharSet);
          break;
      } 

      
      if (paramArrayOfT4CTTIoac[b2] == null || !t4CTTIoac.isOldSufficient(paramArrayOfT4CTTIoac[b2])) {





        
        paramArrayOfT4CTTIoac[b2] = t4CTTIoac;
        bool = true;
      } 
    } 


    
    if (bool) {
      this.oracleStatement.nbPostPonedColumns[0] = 0;
    }
    return bool;
  }










  
  void initDefinesDefinition() throws SQLException, IOException {
    this.defCols = 0;
    int i;
    for (i = 0; i < this.definedColumnType.length; i++) {
      
      if (this.definedColumnType[i] == 0)
        break; 
      this.defCols++;
    } 
    this.oacdefDefines = new T4CTTIoac[this.defCols];
    i = 0;
    int j = 0;
    int k = 0;
    short s = 0;
    for (byte b = 0; b < this.oacdefDefines.length; b++) {
      
      this.oacdefDefines[b] = new T4CTTIoac(this.connection);
      s = (short)this.oracleStatement.getInternalType(this.definedColumnType[b]);
      j = Integer.MAX_VALUE;
      i = 0;
      k = 0;
      byte b1 = 1;
      if (this.definedColumnFormOfUse != null && this.definedColumnFormOfUse.length > b && this.definedColumnFormOfUse[b] == 2)
      {

        
        b1 = 2;
      }
      if (s == 8) {
        s = 1;
      } else if (s == 24) {
        s = 23;
      } else if (s == 1 || s == 96) {

        
        s = 1;




        
        j = 4000 * this.conversion.sMaxCharSize;
        
        if (this.definedColumnSize != null && this.definedColumnSize.length > b && this.definedColumnSize[b] > 0)
        {

          
          j = this.definedColumnSize[b] * this.conversion.sMaxCharSize;
        }
      } else if (this.connection.useLobPrefetch && (s == 113 || s == 112 || s == 114)) {



        
        j = 0;
        i = 33554432;
        if (this.definedColumnSize != null && this.definedColumnSize.length > b && this.definedColumnSize[b] > 0)
        {

          
          k = this.definedColumnSize[b];
        }
      } else if (s == 23) {
        j = 4000;
      } 
      this.oacdefDefines[b].init(s, j);
      this.oacdefDefines[b].addFlg2(i);
      this.oacdefDefines[b].setMxlc(k);
      this.oacdefDefines[b].setFormOfUse(b1);
      this.oacdefDefines[b].setCharset((b1 == 2) ? this.NCharSet : this.dbCharSet);
    } 
  }





  
  void marshalBindsTypes(T4CTTIoac[] paramArrayOfT4CTTIoac) throws IOException {
    if (paramArrayOfT4CTTIoac == null) {
      return;
    }
    for (byte b = 0; b < paramArrayOfT4CTTIoac.length; b++)
    {
      paramArrayOfT4CTTIoac[b].marshal();
    }
  }










  
  Vector<IOException> marshalBinds(int[] paramArrayOfint, boolean paramBoolean) throws IOException {
    byte b;
    boolean bool;
    Vector<IOException> vector = null;
    int i = ((this.bindIndicators[this.bindIndicatorSubRange + 3] & 0xFFFF) << 16) + (this.bindIndicators[this.bindIndicatorSubRange + 4] & 0xFFFF);






    
    if (paramBoolean) {
      
      b = this.rxh.iterNum;
      bool = true;
    }
    else {
      
      b = 0;
      bool = false;
    } 

    
    for (; b < i; b++) {
      
      int j = this.oracleStatement.firstRowInBatch + b;
      InputStream[] arrayOfInputStream = null;
      if (this.parameterStream != null)
        arrayOfInputStream = this.parameterStream[j]; 
      byte[][] arrayOfByte = (byte[][])null;
      if (this.parameterDatum != null)
        arrayOfByte = this.parameterDatum[j]; 
      OracleTypeADT[] arrayOfOracleTypeADT = null;
      if (this.parameterOtype != null) {
        arrayOfOracleTypeADT = this.parameterOtype[j];
      }
      
      Vector<IOException> vector1 = this.rxd.marshal(this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.tmpBindsByteArray, this.conversion, arrayOfInputStream, arrayOfByte, arrayOfOracleTypeADT, this.ibtBindBytes, this.ibtBindChars, this.ibtBindIndicators, null, b, paramArrayOfint, this.plsql, this.oracleStatement.returnParamMeta, this.oracleStatement.nbPostPonedColumns, this.oracleStatement.indexOfPostPonedColumn, bool);








      
      bool = false;
      
      if (vector1 != null) {
        
        if (vector == null)
          vector = new Vector(); 
        vector.addAll(vector1);
      } 
    } 
    return vector;
  }





  
  long setOptions(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) throws SQLException {
    long l = 0L;

    
    if (paramBoolean1 && !paramBoolean2 && !paramBoolean3) {
      l |= 0x1L;
    } else if (paramBoolean1 && paramBoolean2 && !paramBoolean3) {
      l = 32801L;
    } else if (paramBoolean2 && paramBoolean3) {
      SQLException sQLException;
      if (paramBoolean1) {
        l |= 0x1L;
      }


      
      switch (this.typeOfStatement) {

        
        case SELECT_FOR_UPDATE:
        case SELECT:
          l |= 0x8060L;
          break;


        
        case PLSQL_BLOCK:
        case CALL_BLOCK:
          if (this.numberOfBindPositions > 0) {

            
            l |= 0x420L | (this.oracleStatement.connection.autocommit ? 256L : 0L);

            
            if (this.sendBindsDefinition)
              l |= 0x8L; 
            break;
          } 
          l |= 0x20L | (this.oracleStatement.connection.autocommit ? 256L : 0L);
          break;






        
        case DELETE:
        case INSERT:
        case MERGE:
        case UPDATE:
        case ALTER_SESSION:
        case OTHER:
          if (this.oracleStatement.returnParamAccessors != null) {
            l |= 0x420L | (this.oracleStatement.connection.autocommit ? 256L : 0L);
            break;
          } 
          l |= 0x8020L | (this.oracleStatement.connection.autocommit ? 256L : 0L);
          break;




        
        default:
          sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 432);
          sQLException.fillInStackTrace();
          throw sQLException;
      } 

    
    } else if (!paramBoolean1 && !paramBoolean2 && paramBoolean3) {
      l = 32832L;
    }
    else {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 432);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 


    
    if (!this.typeOfStatement.isPlsqlOrCall()) {


      
      if (paramBoolean1 || paramBoolean2 || !paramBoolean3)
      {




        
        if (this.numberOfBindPositions > 0 && this.sendBindsDefinition) {
          l |= 0x8L;
        }
      }
      if (this.connection.versionNumber >= 9000 && paramBoolean4)
      {
        l |= 0x10L;
      }
    } 
    
    l &= 0xFFFFFFFFFFFFFFFFL;

    
    return l;
  }











  
  protected OracleConnection getConnectionDuringExceptionHandling() {
    return this.connection;
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
