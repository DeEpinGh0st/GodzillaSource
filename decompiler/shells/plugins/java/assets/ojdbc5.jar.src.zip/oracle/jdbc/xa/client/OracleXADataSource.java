package oracle.jdbc.xa.client;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;
import javax.sql.PooledConnection;
import javax.sql.XAConnection;
import javax.transaction.xa.XAException;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.driver.T2CConnection;
import oracle.jdbc.driver.T4CXAConnection;
import oracle.jdbc.xa.OracleXADataSource;




























public class OracleXADataSource
  extends OracleXADataSource
{
  private static final boolean DEBUG = false;
  private int rmid = -1;
  private String xaOpenString = null;
  
  private static boolean libraryLoaded = false;
  private static final String dbSuffix = "HeteroXA";
  private static final String dllName = "heteroxa11";
  private static final char atSignChar = '@';
  private static int rmidSeed = 0;
  
  private static final int MAX_RMID_SEED = 65536;
  
  private String driverCharSetIdString = null;


  
  private String oldTnsEntry = null;











  
  public OracleXADataSource() throws SQLException {
    this.isOracleDataSource = true;
  }













  
  public XAConnection getXAConnection() throws SQLException {
    Properties properties = new Properties(this.connectionProperties);

    
    if (this.user != null && this.password != null) {
      
      properties.setProperty("user", this.user);
      properties.setProperty("password", this.password);
    } 
    
    return getXAConnection(properties);
  }













  
  public XAConnection getXAConnection(String paramString1, String paramString2) throws SQLException {
    Properties properties = new Properties(this.connectionProperties);
    if (paramString1 != null && paramString2 != null) {
      
      properties.setProperty("user", paramString1);
      properties.setProperty("password", paramString2);
    } else {
      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    return getXAConnection(properties);
  }














  
  public XAConnection getXAConnection(Properties paramProperties) throws SQLException {
    if (this.connCachingEnabled) {

      
      SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 163);
      sQLException.fillInStackTrace();
      throw sQLException;
    } 
    
    return (XAConnection)getPooledConnection(paramProperties);
  }

















  
  public PooledConnection getPooledConnection(String paramString1, String paramString2) throws SQLException {
    Properties properties = new Properties();
    properties.setProperty("user", paramString1);
    properties.setProperty("password", paramString2);
    
    return getPooledConnection(properties);
  }



















  
  public PooledConnection getPooledConnection(Properties paramProperties) throws SQLException {
    try {
      String str1 = getURL();
      String str2 = paramProperties.getProperty("user");
      String str3 = paramProperties.getProperty("password");
      String str4 = null;
      String str5 = null;
      String str6 = null;
      int i = 0;



      
      if (this.useNativeXA && (str1.startsWith("jdbc:oracle:oci8") || str1.startsWith("jdbc:oracle:oci"))) {


        
        long[] arrayOfLong = { 0L, 0L };



        
        String str8 = null;
        String str9 = null;
        
        synchronized (this) {

          
          if (this.tnsEntry != null) {
            str8 = this.tnsEntry;
          } else {
            str8 = getTNSEntryFromUrl(str1);
          } 
          
          if ((str8 != null && str8.length() == 0) || str8.startsWith("(DESCRIPTION")) {



            
            SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 207);
            sQLException.fillInStackTrace();
            throw sQLException;
          } 

          
          if (!libraryLoaded)
          {
            synchronized (OracleXADataSource.class) {
              
              if (!libraryLoaded) {
                
                try {
                  
                  System.loadLibrary("heteroxa11");
                  
                  libraryLoaded = true;
                }
                catch (Error error) {




                  
                  libraryLoaded = false;
                  
                  throw error;
                } 
              }
            } 
          }



          
          if (this.connectionProperties != null)
          {
            str9 = this.connectionProperties.getProperty("oracle.jdbc.ociNlsLangBackwardCompatible");
          }
        } 

        
        if (str9 != null && str9.equalsIgnoreCase("true")) {





          
          short s = T2CConnection.getDriverCharSetIdFromNLS_LANG();
          this.driverCharSetIdString = Integer.toString(s);

        
        }
        else if (!str8.equals(this.oldTnsEntry)) {

          
          short s = T2CConnection.getClientCharSetId();
          
          this.driverCharSetIdString = Integer.toString(s);
          this.oldTnsEntry = str8;
        } 

        
        synchronized (this) {




          
          str4 = this.databaseName + "HeteroXA" + rmidSeed;
          
          this.rmid = i = rmidSeed;
          
          synchronized (OracleXADataSource.class) {
            
            rmidSeed = (rmidSeed + 1) % 65536;
          } 
          
          boolean bool = false;













          
          String str = (this.connectionProperties != null) ? this.connectionProperties.getProperty("oracle.jdbc.XATransLoose") : null;



          
          this.xaOpenString = str6 = generateXAOpenString(str4, str8, str2, str3, 60, 2000, true, true, ".", bool, false, (str != null && str.equalsIgnoreCase("true")), this.driverCharSetIdString, this.driverCharSetIdString);






          
          str5 = generateXACloseString(str4, false);
        } 


        
        int j = t2cDoXaOpen(str6, i, 0, 0);

        
        if (j != 0) {

          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), -1 * j);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 







        
        j = t2cConvertOciHandles(str4, arrayOfLong);
        
        if (j != 0) {



          
          SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), -1 * j);
          sQLException.fillInStackTrace();
          throw sQLException;
        } 








        
        paramProperties.put("OCISvcCtxHandle", String.valueOf(arrayOfLong[0]));
        paramProperties.put("OCIEnvHandle", String.valueOf(arrayOfLong[1]));
        paramProperties.put("JDBCDriverCharSetId", this.driverCharSetIdString);
        
        if (this.loginTimeout != 0) {
          paramProperties.put("oracle.net.CONNECT_TIMEOUT", "" + (this.loginTimeout * 1000));
        }


        
        Connection connection = this.driver.connect(getURL(), paramProperties);

        
        ((OracleConnection)connection).setStatementCacheSize(this.maxStatements);
        ((OracleConnection)connection).setExplicitCachingEnabled(this.explicitCachingEnabled);
        ((OracleConnection)connection).setImplicitCachingEnabled(this.implicitCachingEnabled);

        
        if (this.maxStatements > 0 && !this.explicitCachingEnabled && !this.implicitCachingEnabled) {


          
          ((OracleConnection)connection).setImplicitCachingEnabled(true);
          ((OracleConnection)connection).setExplicitCachingEnabled(true);
        } 


        
        OracleXAHeteroConnection oracleXAHeteroConnection = new OracleXAHeteroConnection(connection);
        
        if (str2 != null && str3 != null)
          oracleXAHeteroConnection.setUserName(str2, str3); 
        oracleXAHeteroConnection.setRmid(i);
        oracleXAHeteroConnection.setXaCloseString(str5);
        oracleXAHeteroConnection.registerCloseCallback(new OracleXAHeteroCloseCallback(), oracleXAHeteroConnection);
        
        return (PooledConnection)oracleXAHeteroConnection;
      } 
      if (this.thinUseNativeXA && str1.startsWith("jdbc:oracle:thin")) {





        
        Properties properties1 = new Properties();
        synchronized (this) {
          
          synchronized (OracleXADataSource.class) {
            
            rmidSeed = (rmidSeed + 1) % 65536;
            
            this.rmid = rmidSeed;
          } 

          
          if (this.connectionProperties == null) {
            this.connectionProperties = new Properties();
          }
          this.connectionProperties.put("RessourceManagerId", Integer.toString(this.rmid));
          if (str2 != null)
            properties1.setProperty("user", str2); 
          if (str3 != null)
            properties1.setProperty("password", str3); 
          properties1.setProperty("stmt_cache_size", "" + this.maxStatements);
          
          properties1.setProperty("ImplicitStatementCachingEnabled", "" + this.implicitCachingEnabled);

          
          properties1.setProperty("ExplicitStatementCachingEnabled", "" + this.explicitCachingEnabled);

          
          if (this.loginTimeout != 0)
          {
            properties1.setProperty("LoginTimeout", "" + this.loginTimeout);
          }
        } 


        
        T4CXAConnection t4CXAConnection = new T4CXAConnection(getPhysicalConnection(properties1));




        
        if (str2 != null && str3 != null) {
          t4CXAConnection.setUserName(str2, str3);
        }
        String str = (this.connectionProperties != null) ? this.connectionProperties.getProperty("oracle.jdbc.XATransLoose") : null;



        
        ((OracleXAConnection)t4CXAConnection).isXAResourceTransLoose = (str != null && (str.equals("true") || str.equalsIgnoreCase("true")));

        
        return (PooledConnection)t4CXAConnection;
      } 



      
      Properties properties = new Properties();
      synchronized (this) {
        
        if (str2 != null)
          properties.setProperty("user", str2); 
        if (str3 != null)
          properties.setProperty("password", str3); 
        properties.setProperty("stmt_cache_size", "" + this.maxStatements);
        
        properties.setProperty("ImplicitStatementCachingEnabled", "" + this.implicitCachingEnabled);

        
        properties.setProperty("ExplicitStatementCachingEnabled", "" + this.explicitCachingEnabled);

        
        if (this.loginTimeout != 0)
        {
          properties.setProperty("LoginTimeout", "" + this.loginTimeout);
        }
      } 


      
      OracleXAConnection oracleXAConnection = new OracleXAConnection(getPhysicalConnection(properties));



      
      if (str2 != null && str3 != null) {
        oracleXAConnection.setUserName(str2, str3);
      }
      String str7 = (this.connectionProperties != null) ? this.connectionProperties.getProperty("oracle.jdbc.XATransLoose") : null;



      
      oracleXAConnection.isXAResourceTransLoose = (str7 != null && (str7.equals("true") || str7.equalsIgnoreCase("true")));


      
      return (PooledConnection)oracleXAConnection;
    
    }
    catch (XAException xAException) {





      
      return null;
    } 
  }






  
  private native int t2cDoXaOpen(String paramString, int paramInt1, int paramInt2, int paramInt3);





  
  private native int t2cConvertOciHandles(String paramString, long[] paramArrayOflong);





  
  synchronized void setRmid(int paramInt) {
    this.rmid = paramInt;
  }











  
  synchronized int getRmid() {
    return this.rmid;
  }












  
  synchronized void setXaOpenString(String paramString) {
    this.xaOpenString = paramString;
  }











  
  synchronized String getXaOpenString() {
    return this.xaOpenString;
  }


















  
  private String generateXAOpenString(String paramString1, String paramString2, String paramString3, String paramString4, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, String paramString5, int paramInt3, boolean paramBoolean3, boolean paramBoolean4, String paramString6, String paramString7) {
    return "ORACLE_XA+DB=" + paramString1 + "+ACC=P/" + paramString3 + "/" + paramString4 + "+SESTM=" + paramInt2 + "+SESWT=" + paramInt1 + "+LOGDIR=" + paramString5 + "+SQLNET=" + paramString2 + (paramBoolean1 ? "+THREADS=true" : "") + (paramBoolean2 ? "+OBJECTS=true" : "") + "+DBGFL=0x" + paramInt3 + (paramBoolean3 ? "+CONNCACHE=t" : "+CONNCACHE=f") + (paramBoolean4 ? "+Loose_Coupling=t" : "") + "+CharSet=" + paramString6 + "+NCharSet=" + paramString7;
  }












  
  private String generateXACloseString(String paramString, boolean paramBoolean) {
    return "ORACLE_XA+DB=" + paramString + (paramBoolean ? "+CONNCACHE=t" : "+CONNCACHE=f");
  }





  
  private String getTNSEntryFromUrl(String paramString) {
    this; int i = paramString.indexOf('@');
    
    return paramString.substring(i + 1);
  }


  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
