package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.KeywordValueLong;















































final class T4CTTIoxsspo
  extends T4CTTIfun
{
  private int functionId;
  private byte[] sessionId;
  private KeywordValueLong[] inKV;
  private int inFlags;
  
  T4CTTIoxsspo(T4CConnection paramT4CConnection) {
    super(paramT4CConnection, (byte)17);
    
    setFunCode((short)157);
  }












  
  void doOXSSPO(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2) throws IOException, SQLException {
    this.functionId = paramInt1;
    this.sessionId = paramArrayOfbyte;
    this.inKV = paramArrayOfKeywordValueLong;
    this.inFlags = paramInt2;
    if (this.inKV != null)
      for (byte b = 0; b < this.inKV.length; b++)
        ((KeywordValueLongI)this.inKV[b]).doCharConversion(this.meg.conv);  
    doPigRPC();
  }



  
  void marshal() throws IOException {
    this.meg.marshalUB4(this.functionId);
    boolean bool1 = false;
    if (this.sessionId != null && this.sessionId.length > 0) {
      
      bool1 = true;
      this.meg.marshalPTR();
      this.meg.marshalUB4(this.sessionId.length);
    }
    else {
      
      this.meg.marshalNULLPTR();
      this.meg.marshalUB4(0L);
    } 
    
    boolean bool2 = false;
    if (this.inKV != null && this.inKV.length > 0) {
      
      bool2 = true;
      this.meg.marshalPTR();
      this.meg.marshalUB4(this.inKV.length);
    }
    else {
      
      this.meg.marshalNULLPTR();
      this.meg.marshalUB4(0L);
    } 
    this.meg.marshalUB4(this.inFlags);

    
    if (bool1)
      this.meg.marshalB1Array(this.sessionId); 
    if (bool2) {
      for (byte b = 0; b < this.inKV.length; b++) {
        ((KeywordValueLongI)this.inKV[b]).marshal(this.meg);
      }
    }
  }
  
  private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
  public static final boolean TRACE = false;
}
