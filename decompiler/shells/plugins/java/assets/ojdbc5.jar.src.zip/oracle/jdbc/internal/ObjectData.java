package oracle.jdbc.internal;

public interface ObjectData {}
