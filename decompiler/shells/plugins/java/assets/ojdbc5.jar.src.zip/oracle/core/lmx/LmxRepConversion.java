package oracle.core.lmx;























public class LmxRepConversion
{
  public static void printInHex(byte paramByte) {
    System.out.print((char)nibbleToHex((byte)((paramByte & 0xF0) >> 4)));
    System.out.print((char)nibbleToHex((byte)(paramByte & 0xF)));
  }










  
  public static byte nibbleToHex(byte paramByte) {
    paramByte = (byte)(paramByte & 0xF);
    return (byte)((paramByte < 10) ? (paramByte + 48) : (paramByte - 10 + 65));
  }















  
  public static byte asciiHexToNibble(byte paramByte) {
    byte b;
    if (paramByte >= 97 && paramByte <= 102) {
      b = (byte)(paramByte - 97 + 10);
    }
    else if (paramByte >= 65 && paramByte <= 70) {
      b = (byte)(paramByte - 65 + 10);
    }
    else if (paramByte >= 48 && paramByte <= 57) {
      b = (byte)(paramByte - 48);
    } else {
      
      b = paramByte;
    } 
    return b;
  }








  
  public static void bArray2nibbles(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    for (byte b = 0; b < paramArrayOfbyte1.length; b++) {
      
      paramArrayOfbyte2[b * 2] = nibbleToHex((byte)((paramArrayOfbyte1[b] & 0xF0) >> 4));
      paramArrayOfbyte2[b * 2 + 1] = nibbleToHex((byte)(paramArrayOfbyte1[b] & 0xF));
    } 
  }








  
  public static String bArray2String(byte[] paramArrayOfbyte) {
    StringBuffer stringBuffer = new StringBuffer(paramArrayOfbyte.length * 2);
    for (byte b = 0; b < paramArrayOfbyte.length; b++) {
      
      stringBuffer.append((char)nibbleToHex((byte)((paramArrayOfbyte[b] & 0xF0) >> 4)));
      stringBuffer.append((char)nibbleToHex((byte)(paramArrayOfbyte[b] & 0xF)));
    } 
    return stringBuffer.toString();
  }










  
  public static byte[] nibbles2bArray(byte[] paramArrayOfbyte) {
    byte[] arrayOfByte = new byte[paramArrayOfbyte.length / 2];

    
    for (byte b = 0; b < arrayOfByte.length; b++) {
      
      arrayOfByte[b] = (byte)(asciiHexToNibble(paramArrayOfbyte[b * 2]) << 4);
      arrayOfByte[b] = (byte)(arrayOfByte[b] | asciiHexToNibble(paramArrayOfbyte[b * 2 + 1]));
    } 
    return arrayOfByte;
  }

  
  public static void printInHex(long paramLong) {
    byte[] arrayOfByte = toHex(paramLong);
    System.out.print(new String(arrayOfByte, 0));
  }

  
  public static void printInHex(int paramInt) {
    byte[] arrayOfByte = toHex(paramInt);
    System.out.print(new String(arrayOfByte, 0));
  }

  
  public static void printInHex(short paramShort) {
    byte[] arrayOfByte = toHex(paramShort);
    System.out.print(new String(arrayOfByte, 0));
  }

  
  public static byte[] toHex(long paramLong) {
    byte b = 16;
    byte[] arrayOfByte = new byte[b];
    
    for (int i = b - 1; i >= 0; i--) {
      
      arrayOfByte[i] = nibbleToHex((byte)(int)(paramLong & 0xFL));
      paramLong >>= 4L;
    } 
    return arrayOfByte;
  }

  
  public static byte[] toHex(int paramInt) {
    byte b = 8;
    byte[] arrayOfByte = new byte[b];
    
    for (int i = b - 1; i >= 0; i--) {
      
      arrayOfByte[i] = nibbleToHex((byte)(paramInt & 0xF));
      paramInt >>= 4;
    } 
    return arrayOfByte;
  }

  
  public static byte[] toHex(short paramShort) {
    byte b = 4;
    byte[] arrayOfByte = new byte[b];
    
    for (int i = b - 1; i >= 0; i--) {
      
      arrayOfByte[i] = nibbleToHex((byte)(paramShort & 0xF));
      paramShort = (short)(paramShort >> 4);
    } 
    return arrayOfByte;
  }
}
