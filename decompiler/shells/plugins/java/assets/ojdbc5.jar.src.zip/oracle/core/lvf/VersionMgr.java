package oracle.core.lvf;

















































public final class VersionMgr
{
  public static final byte ALPHA = 1;
  public static final byte BETA = 2;
  public static final byte PROD = 3;
  public static final byte NONE = 4;
  private final byte MAX_LEN = 64;
  private final byte MAX_PRODLEN = 30;
  private final byte MAX_VERLEN = 15;
  private final byte MAX_DISTLEN = 5;
  private final String alpha = "Alpha";
  private final String beta = "Beta";
  private final String prod = "Production";









  
  private String version;










  
  public void setVersion(String paramString1, byte paramByte1, byte paramByte2, byte paramByte3, byte paramByte4, byte paramByte5, char paramChar, String paramString2, byte paramByte6, int paramInt) {
    String str1;
    char[] arrayOfChar = new char[64];



    
    String str2 = "";
    
    byte b3;
    if ((b3 = (byte)paramString1.length()) > 30) {
      b3 = 30;
    }
    
    byte b2 = 0;
    for (b3 = (byte)(b3 - 1); 0 < b3; ) {
      
      arrayOfChar[b2] = paramString1.charAt(b2);
      b2 = (byte)(b2 + 1);
    } 

    
    b2 = (byte)(b2 + 1); arrayOfChar[b2] = '\t';

    
    if (paramByte1 < 0)
      paramByte1 = 0; 
    if (paramByte2 < 0)
      paramByte2 = 0; 
    if (paramByte3 < 0)
      paramByte3 = 0; 
    if (paramByte4 < 0)
      paramByte4 = 0; 
    if (paramByte5 < 0) {
      paramByte5 = 0;
    }
    
    if (paramByte1 > 99)
      paramByte1 = 99; 
    if (paramByte2 > 99)
      paramByte2 = 99; 
    if (paramByte3 > 99)
      paramByte3 = 99; 
    if (paramByte4 > 99)
      paramByte4 = 99; 
    if (paramByte5 > 99) {
      paramByte5 = 99;
    }
    
    if (paramChar != '\000') {
      str1 = paramByte1 + "." + paramByte2 + "." + paramByte3 + "." + paramByte4 + "." + paramByte5 + paramChar;
    } else {
      str1 = paramByte1 + "." + paramByte2 + "." + paramByte3 + "." + paramByte4 + "." + paramByte5;
    }  byte b4 = (byte)str1.length();

    
    byte b1 = 0;
    for (b4 = (byte)(b4 - 1); 0 < b4; ) {
      b2 = (byte)(b2 + 1); b1 = (byte)(b1 + 1); arrayOfChar[b2] = str1.charAt(b1);
    } 
    if (paramByte6 != 4) {

      
      b2 = (byte)(b2 + 1); arrayOfChar[b2] = '\t';
      
      if (paramString2 != null) {
        
        byte b5 = 0;

        
        if ((b5 = (byte)paramString2.length()) > 5) {
          b5 = 5;
        }
        
        b1 = 0;
        for (b5 = (byte)(b5 - 1); 0 < b5; ) {
          b2 = (byte)(b2 + 1); b1 = (byte)(b1 + 1); arrayOfChar[b2] = paramString2.charAt(b1);
        } 
        
        b2 = (byte)(b2 + 1); arrayOfChar[b2] = '\t';
      } 

      
      switch (paramByte6) {
        
        case 1:
          str2 = "Alpha";
          break;
        case 2:
          str2 = "Beta";
          break;
        case 3:
          str2 = "Production";
          break;
      } 
      
      b1 = 0;
      byte b = (byte)str2.length();

      
      for (b = (byte)(b - 1); 0 < b; ) {
        b2 = (byte)(b2 + 1); b1 = (byte)(b1 + 1); arrayOfChar[b2] = str2.charAt(b1);
      } 
    } 
    
    this.version = new String(arrayOfChar, 0, b2);
  }





  
  public String getVersion() {
    return this.version;
  }
}
